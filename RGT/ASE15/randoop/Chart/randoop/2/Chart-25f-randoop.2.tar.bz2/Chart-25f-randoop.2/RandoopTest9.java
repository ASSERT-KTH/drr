
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     java.awt.Paint var3 = var2.getBackgroundPaint();
//     org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var7 = null;
//     var6.notifyListeners(var7);
//     var6.setValue((-1.0d));
//     java.awt.Stroke var11 = var6.getOutlineStroke();
//     org.jfree.chart.util.LengthAdjustmentType var12 = var6.getLabelOffsetType();
//     java.awt.Font var13 = var6.getLabelFont();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var18 = var17.getRed();
//     java.awt.Color var19 = var17.brighter();
//     java.awt.image.ColorModel var20 = null;
//     java.awt.Rectangle var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     java.awt.geom.AffineTransform var23 = null;
//     java.awt.RenderingHints var24 = null;
//     java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
//     float[] var29 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
//     float[] var30 = var19.getRGBColorComponents(var29);
//     org.jfree.chart.text.TextFragment var32 = new org.jfree.chart.text.TextFragment("rect", var13, (java.awt.Paint)var19, 0.0f);
//     var2.setItemFont(var13);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var34);
//     org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
//     var37.clearDomainMarkers(1);
//     org.jfree.data.category.CategoryDataset var41 = var37.getDataset((-16777216));
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var43 = var42.getFixedLegendItems();
//     java.awt.Stroke var44 = var42.getOutlineStroke();
//     java.awt.Stroke var45 = var42.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var46 = var42.getRangeAxis();
//     var42.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var50 = var42.getRangeAxisLocation(0);
//     org.jfree.chart.util.RectangleInsets var51 = var42.getAxisOffset();
//     var37.setInsets(var51, true);
//     var36.setItemLabelPadding(var51);
//     org.jfree.chart.axis.NumberAxis var56 = new org.jfree.chart.axis.NumberAxis();
//     var56.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var60 = var56.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var56.java2DToValue(0.0d, var62, var63);
//     org.jfree.data.Range var65 = null;
//     org.jfree.data.Range var67 = org.jfree.data.Range.expandToInclude(var65, 1.0d);
//     double var69 = var67.constrain((-1.0d));
//     var56.setRangeWithMargins(var67, true, false);
//     org.jfree.chart.block.RectangleConstraint var73 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var67);
//     org.jfree.chart.util.Size2D var74 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var75 = var73.calculateConstrainedSize(var74);
//     var75.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var81 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var82 = null;
//     var81.notifyListeners(var82);
//     var81.setValue((-1.0d));
//     java.awt.Stroke var86 = var81.getStroke();
//     org.jfree.chart.plot.ValueMarker var88 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var89 = new org.jfree.chart.axis.NumberAxis();
//     var89.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var93 = var89.getTickMarkStroke();
//     var88.setStroke(var93);
//     boolean var95 = var81.equals((java.lang.Object)var93);
//     org.jfree.chart.util.RectangleAnchor var96 = var81.getLabelAnchor();
//     java.awt.geom.Rectangle2D var97 = org.jfree.chart.util.RectangleAnchor.createRectangle(var75, 0.2d, 100.0d, var96);
//     var36.setLegendItemGraphicAnchor(var96);
//     var2.setLegendItemGraphicLocation(var96);
//     
//     // Checks the contract:  equals-hashcode on var0 and var34
//     assertTrue("Contract failed: equals-hashcode on var0 and var34", var0.equals(var34) ? var0.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var0
//     assertTrue("Contract failed: equals-hashcode on var34 and var0", var34.equals(var0) ? var34.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var81
//     assertTrue("Contract failed: equals-hashcode on var6 and var81", var6.equals(var81) ? var6.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var6
//     assertTrue("Contract failed: equals-hashcode on var81 and var6", var81.equals(var6) ? var81.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    java.awt.Stroke var13 = var0.lookupSeriesStroke((-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    var13.setBackgroundImageAlignment(100);
    int var18 = var13.getSubtitleCount();
    org.jfree.chart.title.LegendTitle var19 = var13.getLegend();
    var13.setTextAntiAlias(true);
    var13.removeLegend();
    float var23 = var13.getBackgroundImageAlpha();
    var13.setBackgroundImageAlignment(0);
    var13.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.5f);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var1 = null;
    var0.setNumberFormatOverride(var1);
    var0.setAutoTickUnitSelection(false);
    org.jfree.chart.axis.NumberTickUnit var5 = var0.getTickUnit();
    java.lang.Object var6 = null;
    int var7 = var5.compareTo(var6);
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var12 = var10.getSeriesNegativeItemLabelPosition(100);
    boolean var14 = var10.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var16 = var15.getFixedLegendItems();
    var10.setPlot(var15);
    java.awt.Paint var18 = var10.getErrorIndicatorPaint();
    java.awt.Paint var19 = var10.getBaseOutlinePaint();
    boolean var21 = var10.isSeriesVisible(0);
    java.awt.Paint var22 = null;
    var10.setErrorIndicatorPaint(var22);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = var10.getLegendItemLabelGenerator();
    java.awt.Stroke var27 = var10.getItemStroke(1, 10);
    var8.setSeriesOutlineStroke(255, var27);
    org.jfree.chart.labels.CategoryItemLabelGenerator var30 = var8.getSeriesItemLabelGenerator(10);
    var8.setBaseCreateEntities(false, false);
    org.jfree.chart.labels.ItemLabelPosition var34 = var8.getPositiveItemLabelPositionFallback();
    int var35 = var5.compareTo((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.text.NumberFormat var4 = null;
//     var0.setNumberFormatOverride(var4);
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var7 = null;
//     org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 1.0d);
//     double var11 = var9.constrain((-1.0d));
//     org.jfree.data.Range var12 = org.jfree.data.Range.combine(var6, var9);
//     boolean var15 = var9.intersects(0.05d, (-6.0d));
//     double var16 = var9.getLowerBound();
//     var0.setDefaultAutoRange(var9);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var20 = var19.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var21 = var19.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var27 = var22.getItemLabelPaint(0, 10);
//     var19.setNoDataMessagePaint(var27);
//     var19.configureDomainAxes();
//     float var30 = var19.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var19);
//     var31.setBackgroundImageAlpha(10.0f);
//     org.jfree.chart.title.LegendTitle var35 = var31.getLegend((-16777216));
//     org.jfree.chart.event.ChartProgressEvent var38 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var9, var31, 11, 10);
//     double var39 = var9.getLowerBound();
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     var40.zoomRange(100.0d, 100.0d);
//     var40.setLowerBound(10.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var46 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var48 = var46.getSeriesNegativeItemLabelPosition(100);
//     boolean var50 = var46.isSeriesVisible(10);
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var52 = var51.getFixedLegendItems();
//     var46.setPlot(var51);
//     java.awt.Paint var54 = var46.getErrorIndicatorPaint();
//     var46.setBase(100.0d);
//     boolean var59 = var46.getItemVisible(1, 1);
//     java.awt.Shape var61 = var46.lookupSeriesShape(100);
//     var40.setUpArrow(var61);
//     java.lang.String var63 = var40.getLabel();
//     double var64 = var40.getUpperMargin();
//     var40.setInverted(false);
//     var40.setLabel("Category Plot");
//     org.jfree.data.Range var69 = null;
//     org.jfree.data.Range var71 = org.jfree.data.Range.expandToInclude(var69, 1.0d);
//     double var73 = var71.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var76 = var75.getInsets();
//     java.lang.String var77 = var76.toString();
//     var74.setTickLabelInsets(var76);
//     boolean var79 = var71.equals((java.lang.Object)var74);
//     double var80 = var71.getCentralValue();
//     var40.setRangeWithMargins(var71, false, true);
//     org.jfree.data.Range var84 = org.jfree.data.Range.combine(var9, var71);
//     
//     // Checks the contract:  equals-hashcode on var19 and var75
//     assertTrue("Contract failed: equals-hashcode on var19 and var75", var19.equals(var75) ? var19.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var19
//     assertTrue("Contract failed: equals-hashcode on var75 and var19", var75.equals(var19) ? var75.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var48
//     assertTrue("Contract failed: equals-hashcode on var24 and var48", var24.equals(var48) ? var24.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var24
//     assertTrue("Contract failed: equals-hashcode on var48 and var24", var48.equals(var24) ? var48.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    var0.setDomainGridlinesVisible(true);
    boolean var7 = var0.isSubplot();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    int var9 = var0.getDomainAxisIndex(var8);
    var8.removeCategoryLabelToolTip((java.lang.Comparable)(short)0);
    java.awt.Paint[] var12 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var13 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var15 = var14.getFixedLegendItems();
    java.awt.Stroke var16 = var14.getOutlineStroke();
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    org.jfree.chart.plot.ValueMarker var19 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var20 = null;
    var19.notifyListeners(var20);
    var19.setValue((-1.0d));
    java.awt.Stroke var24 = var19.getStroke();
    java.awt.Stroke[] var25 = new java.awt.Stroke[] { var24};
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis();
    var26.zoomRange(100.0d, 100.0d);
    var26.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var32 = var26.getTickUnit();
    java.awt.Shape var33 = var26.getRightArrow();
    java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var13, var17, var25, var34);
    java.awt.Paint var36 = var35.getNextFillPaint();
    java.awt.Shape var37 = var35.getNextShape();
    java.awt.Stroke var38 = var35.getNextOutlineStroke();
    java.awt.Paint var39 = var35.getNextPaint();
    java.awt.Shape var40 = var35.getNextShape();
    boolean var41 = var8.equals((java.lang.Object)var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.util.GradientPaintTransformer var8 = null;
    var0.setGradientPaintTransformer(var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = var0.getPositiveItemLabelPositionFallback();
    boolean var12 = var0.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     var1.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var5 = var1.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.java2DToValue(0.0d, var7, var8);
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
//     double var14 = var12.constrain((-1.0d));
//     var1.setRangeWithMargins(var12, true, false);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var12);
//     double var19 = var12.getLength();
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var12, 1.0d);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     var23.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var27 = var23.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var23.java2DToValue(0.0d, var29, var30);
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 1.0d);
//     double var36 = var34.constrain((-1.0d));
//     var23.setRangeWithMargins(var34, true, false);
//     org.jfree.chart.block.RectangleConstraint var40 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var34);
//     double var41 = var40.getHeight();
//     org.jfree.data.Range var42 = null;
//     org.jfree.data.Range var44 = org.jfree.data.Range.expandToInclude(var42, 1.0d);
//     double var46 = var44.constrain((-1.0d));
//     org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var49 = var48.getInsets();
//     java.lang.String var50 = var49.toString();
//     var47.setTickLabelInsets(var49);
//     boolean var52 = var44.equals((java.lang.Object)var47);
//     java.lang.Object var53 = null;
//     boolean var54 = var44.equals(var53);
//     org.jfree.chart.block.RectangleConstraint var55 = var40.toRangeWidth(var44);
//     double var56 = var44.getCentralValue();
//     org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint(var21, var44);
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     double var59 = var58.getFixedAutoRange();
//     org.jfree.data.Range var60 = null;
//     org.jfree.data.Range var62 = org.jfree.data.Range.expandToInclude(var60, 1.0d);
//     double var64 = var62.constrain((-1.0d));
//     var58.setDefaultAutoRange(var62);
//     org.jfree.data.Range var66 = org.jfree.data.Range.combine(var44, var62);
//     double var68 = var62.constrain(9.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var50 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var50.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var56 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1.0d);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    var0.setDrawSharedDomainAxis(true);
    org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(10);
    org.jfree.chart.axis.AxisLocation var7 = var6.getOpposite();
    org.jfree.chart.axis.AxisLocation var8 = var7.getOpposite();
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT"+ "'", var9.equals("AxisLocation.BOTTOM_OR_RIGHT"));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    var0.setBase(100.0d);
    boolean var13 = var0.getItemVisible(1, 1);
    java.awt.Shape var15 = var0.lookupSeriesShape(100);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var15);
    java.lang.String var17 = var16.getShapeType();
    var16.setURLText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    java.lang.String var20 = var16.getURLText();
    java.lang.String var21 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "rect"+ "'", var17.equals("rect"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var20.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var21.equals("LegendItemEntity: seriesKey=null, dataset=null"));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.util.GradientPaintTransformer var8 = null;
    var0.setGradientPaintTransformer(var8);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = var0.getPositiveItemLabelPositionFallback();
    java.awt.Stroke var12 = var0.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
    double var4 = var2.constrain((-1.0d));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    java.lang.String var8 = var7.toString();
    var5.setTickLabelInsets(var7);
    boolean var10 = var2.equals((java.lang.Object)var5);
    var5.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    var5.setLabel("");
    org.jfree.chart.axis.TickUnitSource var15 = null;
    var5.setStandardTickUnits(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var8.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
    double var4 = var2.constrain((-1.0d));
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var7 = var6.getInsets();
    java.lang.String var8 = var7.toString();
    var5.setTickLabelInsets(var7);
    boolean var10 = var2.equals((java.lang.Object)var5);
    var5.setLabelToolTip("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    var5.setTickMarkOutsideLength(1.0f);
    var5.setVisible(false);
    java.awt.Stroke var17 = var5.getTickMarkStroke();
    var5.setLabel("java.awt.Color[r=255,g=255,b=2]");
    org.jfree.chart.plot.Plot var20 = null;
    var5.setPlot(var20);
    org.jfree.data.Range var24 = new org.jfree.data.Range((-92.0d), (-6.0d));
    var5.setRange(var24);
    var5.setAxisLineVisible(true);
    org.jfree.chart.text.TextLine var30 = new org.jfree.chart.text.TextLine("TextAnchor.CENTER");
    org.jfree.chart.util.StandardGradientPaintTransformer var31 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var32 = var31.getType();
    java.lang.Object var33 = var31.clone();
    java.lang.Object var34 = var31.clone();
    org.jfree.data.general.Dataset var35 = null;
    org.jfree.data.general.DatasetChangeEvent var36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var31, var35);
    boolean var37 = var30.equals((java.lang.Object)var31);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var39 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var41 = var39.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var42 = null;
    var39.setBaseURLGenerator(var42, true);
    int var45 = var39.getColumnCount();
    java.awt.Font var46 = var39.getBaseItemLabelFont();
    java.awt.Color var50 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var51 = var50.getRed();
    org.jfree.chart.text.TextLine var52 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var46, (java.awt.Paint)var50);
    org.jfree.chart.text.TextFragment var54 = new org.jfree.chart.text.TextFragment("hi!");
    var52.removeFragment(var54);
    var30.addFragment(var54);
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var60 = null;
    var59.notifyListeners(var60);
    var59.setValue((-1.0d));
    java.awt.Stroke var64 = var59.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var65 = var59.getLabelOffsetType();
    java.awt.Font var66 = var59.getLabelFont();
    java.awt.Color var70 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var71 = var70.getRed();
    java.awt.Color var72 = var70.brighter();
    java.awt.image.ColorModel var73 = null;
    java.awt.Rectangle var74 = null;
    java.awt.geom.Rectangle2D var75 = null;
    java.awt.geom.AffineTransform var76 = null;
    java.awt.RenderingHints var77 = null;
    java.awt.PaintContext var78 = var72.createContext(var73, var74, var75, var76, var77);
    float[] var82 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
    float[] var83 = var72.getRGBColorComponents(var82);
    org.jfree.chart.text.TextFragment var85 = new org.jfree.chart.text.TextFragment("rect", var66, (java.awt.Paint)var72, 0.0f);
    java.awt.Font var86 = var85.getFont();
    var30.addFragment(var85);
    java.awt.Font var88 = var85.getFont();
    org.jfree.chart.block.LabelBlock var89 = new org.jfree.chart.block.LabelBlock("rect", var88);
    var5.setTickLabelFont(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var8.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    org.jfree.data.category.CategoryDataset var15 = null;
    var1.setDataset(0, var15);
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
    java.awt.Stroke var19 = var17.getOutlineStroke();
    java.awt.Stroke var20 = var17.getOutlineStroke();
    org.jfree.chart.axis.ValueAxis var21 = var17.getRangeAxis();
    var17.setDomainGridlinesVisible(true);
    boolean var24 = var17.isSubplot();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
    int var26 = var17.getDomainAxisIndex(var25);
    int var27 = var1.getDomainAxisIndex(var25);
    org.jfree.chart.plot.Plot var28 = var1.getParent();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.lang.String var2 = var0.getPlotType();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var4.zoomRange(0.0d, 100.0d);
    java.text.NumberFormat var8 = null;
    var4.setNumberFormatOverride(var8);
    java.awt.Paint var10 = var4.getAxisLinePaint();
    java.lang.String var11 = var4.getLabelToolTip();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
//     org.jfree.chart.text.TextLine var7 = null;
//     var6.addLine(var7);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
//     java.util.List var11 = var9.getAnnotations();
//     int var12 = var9.getBackgroundImageAlignment();
//     boolean var13 = var6.equals((java.lang.Object)var12);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = null;
//     var15.setBaseURLGenerator(var18, true);
//     int var21 = var15.getColumnCount();
//     java.awt.Font var22 = var15.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
//     org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition();
//     boolean var25 = var23.equals((java.lang.Object)var24);
//     double var26 = var23.getContentXOffset();
//     var23.setURLText("NOID");
//     var23.setURLText("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (hi!).\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.util.HorizontalAlignment var31 = var23.getHorizontalAlignment();
//     var6.setLineAlignment(var31);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleEdge var34 = var33.getPosition();
//     org.jfree.chart.util.VerticalAlignment var35 = var33.getVerticalAlignment();
//     org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var31, var35, 2.0d, 24.0d);
//     var38.clear();
//     var38.clear();
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.clearDomainMarkers(1);
//     java.awt.Image var44 = var41.getBackgroundImage();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     java.awt.geom.Point2D var47 = null;
//     var41.zoomRangeAxes(100.0d, var46, var47);
//     var41.setRangeCrosshairValue(1.0d);
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var41);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var53 = var52.getFixedLegendItems();
//     java.awt.Stroke var54 = var52.getOutlineStroke();
//     org.jfree.chart.util.RectangleEdge var56 = var52.getRangeAxisEdge(255);
//     org.jfree.chart.util.RectangleEdge var57 = org.jfree.chart.util.RectangleEdge.opposite(var56);
//     var51.setLegendItemGraphicEdge(var57);
//     org.jfree.chart.event.TitleChangeEvent var59 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var51);
//     java.awt.Graphics2D var60 = null;
//     org.jfree.chart.util.Size2D var61 = var51.arrange(var60);
//     org.jfree.data.Range var62 = null;
//     org.jfree.data.Range var63 = null;
//     org.jfree.data.Range var65 = org.jfree.data.Range.expandToInclude(var63, 1.0d);
//     double var67 = var65.constrain((-1.0d));
//     org.jfree.data.Range var68 = org.jfree.data.Range.combine(var62, var65);
//     boolean var71 = var65.intersects(0.05d, (-6.0d));
//     org.jfree.data.Range var73 = org.jfree.data.Range.shift(var65, (-6.0d));
//     var38.add((org.jfree.chart.block.Block)var51, (java.lang.Object)var65);
//     
//     // Checks the contract:  equals-hashcode on var9 and var52
//     assertTrue("Contract failed: equals-hashcode on var9 and var52", var9.equals(var52) ? var9.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var9
//     assertTrue("Contract failed: equals-hashcode on var52 and var9", var52.equals(var9) ? var52.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getUpperClip();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var2 = var0.getLegendItemToolTipGenerator();
    java.awt.Paint var4 = var0.getSeriesItemLabelPaint(255);
    org.jfree.chart.urls.CategoryURLGenerator var6 = var0.getSeriesURLGenerator(14);
    java.awt.Paint var7 = var0.getBasePaint();
    java.awt.Font var10 = var0.getItemLabelFont(100, (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     double var1 = var0.getFixedAutoRange();
//     double var2 = var0.getUpperMargin();
//     var0.setAutoRangeMinimumSize(10.0d);
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis();
//     java.text.NumberFormat var6 = null;
//     var5.setNumberFormatOverride(var6);
//     var5.setAutoTickUnitSelection(false);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
//     double var11 = var10.getFixedAutoRange();
//     double var12 = var10.getUpperMargin();
//     var10.setAutoRangeMinimumSize(10.0d);
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
//     var15.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var19 = var15.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var15.java2DToValue(0.0d, var21, var22);
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 1.0d);
//     double var28 = var26.constrain((-1.0d));
//     var15.setRangeWithMargins(var26, true, false);
//     var10.setRange(var26, false, true);
//     var5.setRangeWithMargins(var26, true, false);
//     var0.setRange(var26, true, false);
//     org.jfree.data.Range var41 = var0.getDefaultAutoRange();
//     double var43 = var41.constrain((-6.0d));
//     double var45 = var41.constrain(Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NaN);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleConstraint[RectangleConstraintType.RANGE: width=1.2, height=1.0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(1.0d, (-11.0d));
    java.lang.Number var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 1.0d+ "'", var3.equals(1.0d));

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxis();
    var0.setDomainGridlinesVisible(true);
    boolean var7 = var0.isSubplot();
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    int var9 = var0.getDomainAxisIndex(var8);
    var8.removeCategoryLabelToolTip((java.lang.Comparable)(short)0);
    org.jfree.chart.axis.CategoryLabelPositions var12 = var8.getCategoryLabelPositions();
    var8.setCategoryMargin(4.0d);
    var8.setLabelURL("PlotOrientation.VERTICAL");
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    double var22 = var21.getHeight();
    org.jfree.chart.util.Size2D var23 = new org.jfree.chart.util.Size2D();
    double var24 = var23.getHeight();
    org.jfree.chart.util.Size2D var25 = var21.calculateConstrainedSize(var23);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var30 = null;
    var29.notifyListeners(var30);
    var29.setValue((-1.0d));
    java.awt.Stroke var34 = var29.getStroke();
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
    var37.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var41 = var37.getTickMarkStroke();
    var36.setStroke(var41);
    boolean var43 = var29.equals((java.lang.Object)var41);
    org.jfree.chart.util.RectangleAnchor var44 = var29.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var46 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(1.0d);
    org.jfree.chart.axis.CategoryLabelPosition var47 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var48 = var47.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var46, var47);
    org.jfree.chart.text.TextBlockAnchor var50 = var47.getLabelAnchor();
    org.jfree.chart.axis.CategoryLabelPosition var51 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var52 = var51.getCategoryAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var53 = var51.getWidthType();
    org.jfree.chart.axis.CategoryLabelPosition var55 = new org.jfree.chart.axis.CategoryLabelPosition(var44, var50, var53, 0.0f);
    java.awt.geom.Rectangle2D var56 = org.jfree.chart.util.RectangleAnchor.createRectangle(var23, 1.0d, 8.0d, var44);
    org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
    var57.clearDomainMarkers(1);
    java.awt.Image var60 = var57.getBackgroundImage();
    org.jfree.chart.plot.PlotRenderingInfo var62 = null;
    java.awt.geom.Point2D var63 = null;
    var57.zoomRangeAxes(100.0d, var62, var63);
    var57.setRangeCrosshairValue(1.0d);
    org.jfree.chart.title.LegendTitle var67 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var57);
    org.jfree.chart.util.RectangleEdge var69 = var57.getDomainAxisEdge(10);
    double var70 = var8.getCategoryEnd((-254), 14, var56, var69);
    java.lang.String var71 = var69.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var71 + "' != '" + "RectangleEdge.TOP"+ "'", var71.equals("RectangleEdge.TOP"));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearDomainMarkers(1);
//     org.jfree.data.category.CategoryDataset var7 = var3.getDataset((-16777216));
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var9 = var8.getFixedLegendItems();
//     java.awt.Stroke var10 = var8.getOutlineStroke();
//     java.awt.Stroke var11 = var8.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var12 = var8.getRangeAxis();
//     var8.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var16 = var8.getRangeAxisLocation(0);
//     org.jfree.chart.util.RectangleInsets var17 = var8.getAxisOffset();
//     var3.setInsets(var17, true);
//     var2.setItemLabelPadding(var17);
//     var2.setWidth(10.0d);
//     org.jfree.chart.util.HorizontalAlignment var23 = var2.getHorizontalAlignment();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var24 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var29 = var24.getItemLabelPaint(0, 10);
//     java.awt.Shape var31 = var24.getSeriesShape(1);
//     org.jfree.chart.labels.ItemLabelPosition var32 = var24.getNegativeItemLabelPositionFallback();
//     java.awt.Paint var33 = var24.getErrorIndicatorPaint();
//     var2.setBackgroundPaint(var33);
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var37 = null;
//     var36.notifyListeners(var37);
//     var36.setValue((-1.0d));
//     java.awt.Stroke var41 = var36.getStroke();
//     java.awt.Paint var42 = var36.getPaint();
//     java.awt.Stroke var43 = var36.getStroke();
//     org.jfree.chart.util.RectangleAnchor var44 = var36.getLabelAnchor();
//     var2.setLegendItemGraphicLocation(var44);
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var48 = null;
//     var47.notifyListeners(var48);
//     var47.setValue((-1.0d));
//     org.jfree.chart.util.RectangleInsets var52 = var47.getLabelOffset();
//     var2.setLegendItemGraphicPadding(var52);
//     
//     // Checks the contract:  equals-hashcode on var36 and var47
//     assertTrue("Contract failed: equals-hashcode on var36 and var47", var36.equals(var47) ? var36.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var36
//     assertTrue("Contract failed: equals-hashcode on var47 and var36", var47.equals(var36) ? var47.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var4 = var0.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var0.java2DToValue(0.0d, var6, var7);
//     java.awt.Font var9 = var0.getTickLabelFont();
//     org.jfree.chart.axis.MarkerAxisBand var10 = null;
//     var0.setMarkerBand(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.awt.Image var2 = var0.getLogo();
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getLibraries();
    var3.setInfo("hi!");
    var0.addLibrary((org.jfree.chart.ui.Library)var3);
    org.jfree.chart.ui.Library[] var8 = var3.getOptionalLibraries();
    var3.setVersion("RectangleConstraint[RectangleConstraintType.RANGE: width=1.2, height=1.0]");
    var3.setLicenceText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.text.TextMeasurer var5 = null;
    org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
    org.jfree.chart.text.TextLine var7 = null;
    var6.addLine(var7);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
    java.util.List var11 = var9.getAnnotations();
    int var12 = var9.getBackgroundImageAlignment();
    boolean var13 = var6.equals((java.lang.Object)var12);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var15 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var15.setBaseURLGenerator(var18, true);
    int var21 = var15.getColumnCount();
    java.awt.Font var22 = var15.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("", var22);
    org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition();
    boolean var25 = var23.equals((java.lang.Object)var24);
    double var26 = var23.getContentXOffset();
    var23.setURLText("NOID");
    var23.setURLText("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (hi!).\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.util.HorizontalAlignment var31 = var23.getHorizontalAlignment();
    var6.setLineAlignment(var31);
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleEdge var34 = var33.getPosition();
    org.jfree.chart.util.VerticalAlignment var35 = var33.getVerticalAlignment();
    org.jfree.chart.block.ColumnArrangement var38 = new org.jfree.chart.block.ColumnArrangement(var31, var35, 2.0d, 24.0d);
    var38.clear();
    org.jfree.chart.ui.ProjectInfo var40 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var41 = var40.getLibraries();
    java.lang.String var42 = var40.getName();
    boolean var43 = var38.equals((java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("DatasetRenderingOrder.REVERSE");
    int var2 = var1.getCategoryLabelPositionOffset();
    org.jfree.chart.axis.CategoryLabelPositions var3 = var1.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    float var4 = var0.getForegroundAlpha();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    java.awt.Stroke var7 = var5.getOutlineStroke();
    org.jfree.chart.axis.AxisLocation var9 = var5.getRangeAxisLocation(10);
    var0.setRangeAxisLocation(var9, true);
    org.jfree.chart.LegendItemCollection var12 = var0.getFixedLegendItems();
    java.awt.Paint var13 = null;
    var0.setBackgroundPaint(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.chart.block.BlockResult var0 = new org.jfree.chart.block.BlockResult();
    org.jfree.chart.entity.EntityCollection var1 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var2 = var0.getEntityCollection();
    org.jfree.chart.entity.EntityCollection var3 = null;
    var0.setEntityCollection(var3);
    org.jfree.chart.entity.EntityCollection var5 = null;
    var0.setEntityCollection(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("LegendItemEntity: seriesKey=null, dataset=null", "TextAnchor.CENTER", "3", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "hi!");
    org.jfree.chart.ui.ProjectInfo var6 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var7 = var6.getLibraries();
    java.lang.String var8 = var6.getName();
    java.awt.Image var9 = var6.getLogo();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var6);
    org.jfree.chart.ui.ProjectInfo var11 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var12 = var11.getLibraries();
    java.awt.Image var13 = var11.getLogo();
    org.jfree.chart.ui.ProjectInfo var14 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var15 = var14.getLibraries();
    var14.setInfo("hi!");
    var11.addLibrary((org.jfree.chart.ui.Library)var14);
    java.lang.String var19 = var14.getLicenceName();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.AxisState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    java.util.List var25 = var20.refreshTicks(var21, var22, var23, var24);
    var14.setContributors(var25);
    org.jfree.chart.ui.Library[] var27 = var14.getOptionalLibraries();
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var14);
    org.jfree.chart.ui.Library var33 = new org.jfree.chart.ui.Library("java.awt.Color[r=10,g=255,b=247]", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=3.0]", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:HorizontalAlignment.CENTER\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "2");
    var5.addLibrary(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.5f, 0.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    java.lang.Object var8 = var7.clone();
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    boolean var11 = var0.isSeriesVisibleInLegend(10);
    org.jfree.chart.urls.CategoryURLGenerator var13 = null;
    var0.setSeriesURLGenerator(11, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    boolean var5 = var3.equals((java.lang.Object)var4);
    java.awt.Paint var6 = var3.getPaint();
    org.jfree.chart.text.TextAnchor var7 = var3.getLabelTextAnchor();
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.block.BlockContainer var12 = new org.jfree.chart.block.BlockContainer();
    double var13 = var12.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 100.0d, 0.0d);
    var12.setArrangement((org.jfree.chart.block.Arrangement)var18);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var22 = null;
    var21.notifyListeners(var22);
    var21.setValue((-1.0d));
    java.awt.Stroke var26 = var21.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var27 = var21.getLabelOffsetType();
    java.awt.Font var28 = var21.getLabelFont();
    org.jfree.chart.text.TextAnchor var29 = var21.getLabelTextAnchor();
    boolean var30 = var18.equals((java.lang.Object)var21);
    org.jfree.chart.event.MarkerChangeEvent var31 = null;
    var21.notifyListeners(var31);
    org.jfree.chart.text.TextAnchor var33 = var21.getLabelTextAnchor();
    org.jfree.chart.text.TextAnchor var35 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var9, (-1.0f), (-1.0f), var33, (-5.0d), var35);
    org.jfree.chart.axis.NumberTick var38 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0.8f, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:null null (hi!).\nnull LICENCE TERMS:\nnull", var7, var33, (-6.0d));
    org.jfree.chart.axis.TickType var39 = var38.getTickType();
    double var40 = var38.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.800000011920929d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var2.zoomRange(100.0d, 100.0d);
    var2.setLowerBound(10.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var10 = var8.getSeriesNegativeItemLabelPosition(100);
    boolean var12 = var8.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    var8.setPlot(var13);
    java.awt.Paint var16 = var8.getErrorIndicatorPaint();
    var8.setBase(100.0d);
    boolean var21 = var8.getItemVisible(1, 1);
    java.awt.Shape var23 = var8.lookupSeriesShape(100);
    var2.setUpArrow(var23);
    java.lang.String var25 = var2.getLabel();
    double var26 = var2.getUpperMargin();
    var2.setAutoRange(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var29);
    org.jfree.data.Range var31 = var2.getDefaultAutoRange();
    java.awt.Shape var32 = var2.getUpArrow();
    org.jfree.data.RangeType var33 = var2.getRangeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 100.0d);
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)10);
//     org.jfree.data.general.Dataset var8 = var7.getDataset();
//     java.lang.Comparable var9 = var7.getSeriesKey();
//     var7.setURLText("Category Plot");
//     java.lang.String var12 = var7.getURLText();
//     var7.setMargin(24.0d, 0.0d, 0.0d, 3.0d);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var19.getSeriesNegativeItemLabelPosition(100);
//     int var22 = var19.getPassCount();
//     java.awt.Stroke var23 = var19.getErrorIndicatorStroke();
//     boolean var24 = var19.getAutoPopulateSeriesStroke();
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = var19.getLegendItemLabelGenerator();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var27 = var26.getFixedLegendItems();
//     java.awt.Stroke var28 = var26.getOutlineStroke();
//     java.awt.Stroke var29 = var26.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var30 = var26.getRangeAxis();
//     var26.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.AxisLocation var34 = var26.getRangeAxisLocation(0);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis();
//     var37.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var41 = var37.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var37.java2DToValue(0.0d, var43, var44);
//     org.jfree.data.Range var46 = null;
//     org.jfree.data.Range var48 = org.jfree.data.Range.expandToInclude(var46, 1.0d);
//     double var50 = var48.constrain((-1.0d));
//     var37.setRangeWithMargins(var48, true, false);
//     org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var48);
//     org.jfree.chart.util.Size2D var55 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var56 = var54.calculateConstrainedSize(var55);
//     var56.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var62.notifyListeners(var63);
//     var62.setValue((-1.0d));
//     java.awt.Stroke var67 = var62.getStroke();
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var70 = new org.jfree.chart.axis.NumberAxis();
//     var70.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var74 = var70.getTickMarkStroke();
//     var69.setStroke(var74);
//     boolean var76 = var62.equals((java.lang.Object)var74);
//     org.jfree.chart.util.RectangleAnchor var77 = var62.getLabelAnchor();
//     java.awt.geom.Rectangle2D var78 = org.jfree.chart.util.RectangleAnchor.createRectangle(var56, 0.2d, 100.0d, var77);
//     var26.drawBackgroundImage(var35, var78);
//     var19.setBaseShape((java.awt.Shape)var78, false);
//     org.jfree.chart.util.StandardGradientPaintTransformer var82 = new org.jfree.chart.util.StandardGradientPaintTransformer();
//     org.jfree.chart.util.GradientPaintTransformType var83 = var82.getType();
//     org.jfree.chart.block.BlockContainer var84 = new org.jfree.chart.block.BlockContainer();
//     java.util.List var85 = var84.getBlocks();
//     boolean var86 = var83.equals((java.lang.Object)var84);
//     org.jfree.chart.util.StandardGradientPaintTransformer var87 = new org.jfree.chart.util.StandardGradientPaintTransformer(var83);
//     java.lang.String var88 = var83.toString();
//     java.lang.Object var89 = var7.draw(var18, var78, (java.lang.Object)var88);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomRangeAxes(100.0d, var5, var6);
    var0.setRangeCrosshairValue(1.0d);
    org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0);
    org.jfree.chart.util.RectangleEdge var12 = var0.getDomainAxisEdge(10);
    boolean var13 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    org.jfree.chart.labels.ItemLabelPosition var8 = var0.getPositiveItemLabelPosition((-1), 100);
    var0.setAutoPopulateSeriesFillPaint(false);
    boolean var11 = var0.getBaseSeriesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     var1.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var5 = var1.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var1.java2DToValue(0.0d, var7, var8);
//     org.jfree.data.Range var10 = null;
//     org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 1.0d);
//     double var14 = var12.constrain((-1.0d));
//     var1.setRangeWithMargins(var12, true, false);
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var12);
//     double var19 = var12.getLength();
//     org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var12, 1.0d);
//     boolean var24 = var12.intersects(10.0d, 789.8499999999999d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var1 = null;
    var0.setNumberFormatOverride(var1);
    org.jfree.chart.axis.NumberTickUnit var3 = var0.getTickUnit();
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "[size=1]"+ "'", var4.equals("[size=1]"));

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.axis.AxisState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    java.util.List var5 = var0.refreshTicks(var1, var2, var3, var4);
    boolean var6 = var0.isTickMarksVisible();
    var0.setInverted(true);
    org.jfree.chart.axis.MarkerAxisBand var9 = null;
    var0.setMarkerBand(var9);
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var12 = null;
    org.jfree.data.Range var14 = org.jfree.data.Range.expandToInclude(var12, 1.0d);
    double var16 = var14.constrain((-1.0d));
    org.jfree.data.Range var17 = org.jfree.data.Range.combine(var11, var14);
    boolean var20 = var14.intersects(0.05d, (-6.0d));
    boolean var23 = var14.intersects(3.0d, (-5.0d));
    java.lang.Object var24 = null;
    boolean var25 = var14.equals(var24);
    org.jfree.data.Range var28 = org.jfree.data.Range.shift(var14, (-6.0d), false);
    double var29 = var14.getLength();
    var0.setRange(var14, true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
//     java.awt.Stroke var2 = var0.getOutlineStroke();
//     java.awt.Stroke var3 = var0.getOutlineStroke();
//     var0.setOutlineVisible(false);
//     org.jfree.chart.axis.AxisLocation var7 = var0.getDomainAxisLocation(0);
//     var0.setRangeCrosshairValue(10.0d, false);
//     var0.setBackgroundImageAlignment((-16777216));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var15 = var13.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var21 = var16.getItemLabelPaint(0, 10);
//     var13.setNoDataMessagePaint(var21);
//     var13.configureDomainAxes();
//     float var24 = var13.getBackgroundAlpha();
//     var13.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.category.CategoryDataset var28 = var13.getDataset(100);
//     boolean var29 = var13.isRangeCrosshairLockedOnData();
//     var0.setParent((org.jfree.chart.plot.Plot)var13);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.general.DatasetGroup var32 = var31.getDatasetGroup();
//     org.jfree.chart.util.RectangleEdge var33 = var31.getDomainAxisEdge();
//     boolean var34 = var31.isDomainZoomable();
//     org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
//     boolean var38 = var36.equals((java.lang.Object)var37);
//     org.jfree.chart.util.Layer var39 = null;
//     var31.addRangeMarker((org.jfree.chart.plot.Marker)var36, var39);
//     java.lang.String var41 = var36.getLabel();
//     org.jfree.chart.util.Layer var42 = null;
//     var13.addRangeMarker((org.jfree.chart.plot.Marker)var36, var42);
//     
//     // Checks the contract:  equals-hashcode on var13 and var31
//     assertTrue("Contract failed: equals-hashcode on var13 and var31", var13.equals(var31) ? var13.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var13
//     assertTrue("Contract failed: equals-hashcode on var31 and var13", var31.equals(var13) ? var31.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    var0.setTickLabelInsets(var2);
    double var6 = var2.calculateLeftInset(0.0d);
    org.jfree.chart.util.UnitType var7 = var2.getUnitType();
    org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
    var8.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var12 = var8.getTickMarkStroke();
    boolean var13 = var8.isAutoRange();
    double var14 = var8.getUpperBound();
    boolean var15 = var7.equals((java.lang.Object)var8);
    double var16 = var8.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 100.0d);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var3 = null;
    var0.setBaseURLGenerator(var3, true);
    int var6 = var0.getColumnCount();
    boolean var7 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getSeriesNegativeItemLabelPosition((-127));
    boolean var11 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.event.RendererChangeEvent var12 = null;
    var0.notifyListeners(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    boolean var3 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getItemFillPaint(255, 0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var8 = var7.getBaseOutlineStroke();
    var0.setBaseStroke(var8, false);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var12 = var11.getFixedLegendItems();
    java.awt.Stroke var13 = var11.getOutlineStroke();
    java.awt.Stroke var14 = var11.getOutlineStroke();
    var11.setOutlineVisible(false);
    org.jfree.chart.axis.AxisLocation var18 = var11.getDomainAxisLocation(0);
    var11.setRangeCrosshairValue(10.0d, false);
    var11.setBackgroundImageAlignment((-16777216));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var25 = var24.getFixedLegendItems();
    java.awt.Stroke var26 = var24.getOutlineStroke();
    var24.setDrawSharedDomainAxis(true);
    org.jfree.chart.axis.AxisLocation var30 = var24.getRangeAxisLocation(10);
    var11.setDomainAxisLocation(var30, false);
    boolean var33 = var11.isSubplot();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    var0.setAutoPopulateSeriesStroke(false);
    org.jfree.chart.urls.CategoryURLGenerator var37 = null;
    var0.setBaseURLGenerator(var37, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
//     org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
//     java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
//     var1.setNoDataMessagePaint(var9);
//     var1.configureDomainAxes();
//     float var12 = var1.getBackgroundAlpha();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.data.category.CategoryDataset var15 = null;
//     var1.setDataset(0, var15);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.LegendItemCollection var18 = var17.getFixedLegendItems();
//     java.awt.Stroke var19 = var17.getOutlineStroke();
//     java.awt.Stroke var20 = var17.getOutlineStroke();
//     org.jfree.chart.axis.ValueAxis var21 = var17.getRangeAxis();
//     var17.setDomainGridlinesVisible(true);
//     boolean var24 = var17.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     int var26 = var17.getDomainAxisIndex(var25);
//     int var27 = var1.getDomainAxisIndex(var25);
//     boolean var28 = var25.isTickMarksVisible();
//     java.awt.Paint var29 = var25.getAxisLinePaint();
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.axis.AxisState var32 = new org.jfree.chart.axis.AxisState(0.2d);
//     double var33 = var32.getCursor();
//     var32.cursorRight((-9.8d));
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis();
//     var36.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var40 = var36.getTickMarkStroke();
//     boolean var41 = var36.isAutoRange();
//     double var42 = var36.getUpperBound();
//     java.lang.String var43 = var36.getLabelToolTip();
//     org.jfree.chart.util.RectangleInsets var44 = var36.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis();
//     var46.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var50 = var46.getTickMarkStroke();
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     double var54 = var46.java2DToValue(0.0d, var52, var53);
//     org.jfree.data.Range var55 = null;
//     org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, 1.0d);
//     double var59 = var57.constrain((-1.0d));
//     var46.setRangeWithMargins(var57, true, false);
//     org.jfree.chart.block.RectangleConstraint var63 = new org.jfree.chart.block.RectangleConstraint(Double.NaN, var57);
//     org.jfree.chart.util.Size2D var64 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.util.Size2D var65 = var63.calculateConstrainedSize(var64);
//     var65.setHeight(3.0d);
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.event.MarkerChangeEvent var72 = null;
//     var71.notifyListeners(var72);
//     var71.setValue((-1.0d));
//     java.awt.Stroke var76 = var71.getStroke();
//     org.jfree.chart.plot.ValueMarker var78 = new org.jfree.chart.plot.ValueMarker(1.0d);
//     org.jfree.chart.axis.NumberAxis var79 = new org.jfree.chart.axis.NumberAxis();
//     var79.zoomRange(0.0d, 100.0d);
//     java.awt.Stroke var83 = var79.getTickMarkStroke();
//     var78.setStroke(var83);
//     boolean var85 = var71.equals((java.lang.Object)var83);
//     org.jfree.chart.util.RectangleAnchor var86 = var71.getLabelAnchor();
//     java.awt.geom.Rectangle2D var87 = org.jfree.chart.util.RectangleAnchor.createRectangle(var65, 0.2d, 100.0d, var86);
//     java.awt.Shape var90 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var87, 3.0d, 1.0E-8d);
//     java.awt.geom.Rectangle2D var93 = var44.createInsetRectangle(var87, false, true);
//     org.jfree.chart.util.RectangleEdge var94 = null;
//     java.util.List var95 = var25.refreshTicks(var30, var32, var87, var94);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var1 = var0.getFixedLegendItems();
    java.awt.Stroke var2 = var0.getOutlineStroke();
    java.awt.Stroke var3 = var0.getOutlineStroke();
    var0.setOutlineVisible(false);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    var6.zoomRange(100.0d, 100.0d);
    var6.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var12 = var6.getTickUnit();
    java.awt.Shape var13 = var6.getRightArrow();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var6);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    var6.setLeftArrow(var17);
    boolean var19 = var6.isNegativeArrowVisible();
    var6.centerRange(0.0d);
    boolean var22 = var6.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.axis.AxisState var2 = new org.jfree.chart.axis.AxisState();
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle("hi!");
    boolean var7 = var5.equals((java.lang.Object)"Category Plot");
    var5.setToolTipText("hi!");
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var12 = var11.getInsets();
    java.lang.String var13 = var12.toString();
    var10.setTickLabelInsets(var12);
    double var16 = var12.calculateLeftInset(0.0d);
    double var18 = var12.calculateLeftOutset(0.0d);
    var5.setPadding(var12);
    var5.setText("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
    org.jfree.chart.util.RectangleEdge var22 = var5.getPosition();
    var2.moveCursor(2.0d, var22);
    java.lang.String var24 = var22.toString();
    var0.ensureAtLeast((-9.0d), var22);
    java.lang.Object var26 = var0.clone();
    var0.setRight((-5.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var13.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "RectangleEdge.TOP"+ "'", var24.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    double var1 = var0.getContentXOffset();
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 100.0d, 0.0d);
    var0.setArrangement((org.jfree.chart.block.Arrangement)var6);
    org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var10 = null;
    var9.notifyListeners(var10);
    var9.setValue((-1.0d));
    java.awt.Stroke var14 = var9.getOutlineStroke();
    org.jfree.chart.util.LengthAdjustmentType var15 = var9.getLabelOffsetType();
    java.awt.Font var16 = var9.getLabelFont();
    org.jfree.chart.text.TextAnchor var17 = var9.getLabelTextAnchor();
    boolean var18 = var6.equals((java.lang.Object)var9);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    org.jfree.chart.title.LegendItemBlockContainer var21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, (org.jfree.data.general.Dataset)var19, (java.lang.Comparable)(byte)1);
    java.lang.Object var22 = var19.clone();
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var19, true);
    java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + Double.NaN+ "'", var25.equals(Double.NaN));

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    var0.setAutoPopulateSeriesPaint(false);
    java.lang.Object var7 = var0.clone();
    java.awt.Paint var10 = var0.getItemLabelPaint(1, 10);
    var0.setSeriesItemLabelsVisible(1, false);
    var0.setBaseCreateEntities(false, true);
    boolean var19 = var0.isItemLabelVisible((-1), 1);
    double var20 = var0.getItemLabelAnchorOffset();
    double var21 = var0.getUpperClip();
    boolean var22 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var4 = var2.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var7 = var5.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var10 = var5.getItemLabelPaint(0, 10);
    var2.setNoDataMessagePaint(var10);
    var2.configureDomainAxes();
    float var13 = var2.getBackgroundAlpha();
    boolean var14 = var0.equals((java.lang.Object)var13);
    java.lang.Comparable var15 = null;
    int var16 = var0.getIndex(var15);
    java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var22 = var21.getRed();
    java.awt.Color var23 = var21.brighter();
    int var24 = var21.getAlpha();
    java.awt.Color var31 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var32 = var31.getRed();
    java.awt.Color var33 = var31.brighter();
    float[] var37 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var38 = var31.getRGBColorComponents(var37);
    float[] var39 = java.awt.Color.RGBtoHSB(10, 10, 255, var37);
    float[] var40 = var21.getColorComponents(var39);
    java.awt.image.ColorModel var41 = null;
    java.awt.Rectangle var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    java.awt.geom.AffineTransform var44 = null;
    java.awt.RenderingHints var45 = null;
    java.awt.PaintContext var46 = var21.createContext(var41, var42, var43, var44, var45);
    java.awt.Color var47 = var21.darker();
    var0.addObject((java.lang.Comparable)(short)1, (java.lang.Object)var47);
    java.awt.Color var49 = var47.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var1 = var0.getLibraries();
    java.awt.Image var2 = var0.getLogo();
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    org.jfree.chart.ui.Library[] var4 = var3.getLibraries();
    var3.setInfo("hi!");
    var0.addLibrary((org.jfree.chart.ui.Library)var3);
    java.lang.String var8 = var3.getLicenceName();
    java.lang.String var9 = var3.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "hi!"+ "'", var9.equals("hi!"));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    double var1 = var0.getBottom();
    var0.setRight(8.00000001d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Image var3 = var0.getBackgroundImage();
    org.jfree.chart.plot.PlotRenderingInfo var5 = null;
    java.awt.geom.Point2D var6 = null;
    var0.zoomRangeAxes(100.0d, var5, var6);
    org.jfree.chart.axis.AxisSpace var8 = var0.getFixedDomainAxisSpace();
    var0.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var3 = var2.getFixedLegendItems();
    java.awt.Stroke var4 = var2.getOutlineStroke();
    java.awt.Stroke[] var5 = new java.awt.Stroke[] { var4};
    org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var8 = null;
    var7.notifyListeners(var8);
    var7.setValue((-1.0d));
    java.awt.Stroke var12 = var7.getStroke();
    java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis();
    var14.zoomRange(100.0d, 100.0d);
    var14.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var20 = var14.getTickUnit();
    java.awt.Shape var21 = var14.getRightArrow();
    java.awt.Shape[] var22 = new java.awt.Shape[] { var21};
    org.jfree.chart.plot.DefaultDrawingSupplier var23 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var5, var13, var22);
    java.awt.Paint var24 = var23.getNextFillPaint();
    java.awt.Shape var25 = var23.getNextShape();
    java.awt.Stroke var26 = var23.getNextOutlineStroke();
    java.awt.Stroke var27 = var23.getNextStroke();
    java.lang.Object var28 = var23.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    boolean var5 = var1.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
    var1.setPlot(var6);
    java.awt.Paint var9 = var1.getErrorIndicatorPaint();
    var1.setBase(100.0d);
    boolean var14 = var1.getItemVisible(1, 1);
    java.awt.Shape var16 = var1.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.0f, var16, "", "");
    java.lang.String var20 = var19.getShapeType();
    java.lang.Comparable var21 = var19.getKey();
    java.lang.String var22 = var19.getURLText();
    java.awt.Shape var23 = var19.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "rect"+ "'", var20.equals("rect"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 0.0f+ "'", var21.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + ""+ "'", var22.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(1);
    java.awt.Paint var3 = var0.getRangeCrosshairPaint();
    int var4 = var0.getWeight();
    org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("-3,-3,3,3");
    var6.setURLText("");
    java.awt.Font var9 = var6.getFont();
    var0.setNoDataMessageFont(var9);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.general.DatasetGroup var12 = var11.getDatasetGroup();
    org.jfree.chart.util.RectangleEdge var13 = var11.getDomainAxisEdge();
    boolean var14 = var11.isDomainZoomable();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    boolean var18 = var16.equals((java.lang.Object)var17);
    org.jfree.chart.util.Layer var19 = null;
    var11.addRangeMarker((org.jfree.chart.plot.Marker)var16, var19);
    java.awt.Stroke var21 = var16.getStroke();
    var0.setOutlineStroke(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(100.0d);
    var1.cursorLeft(15.0d);
    java.util.List var4 = var1.getTicks();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.util.RectangleInsets var2 = var1.getInsets();
    java.lang.String var3 = var2.toString();
    var0.setTickLabelInsets(var2);
    var0.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var8 = null;
    var7.setNumberFormatOverride(var8);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var13 = var11.getSeriesNegativeItemLabelPosition(100);
    boolean var15 = var11.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var17 = var16.getFixedLegendItems();
    var11.setPlot(var16);
    java.awt.Paint var19 = var11.getErrorIndicatorPaint();
    var11.setBase(100.0d);
    boolean var24 = var11.getItemVisible(1, 1);
    java.awt.Shape var26 = var11.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var29 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var26, "Category Plot", "");
    var7.setRightArrow(var26);
    var0.setDownArrow(var26);
    float var32 = var0.getTickMarkInsideLength();
    var0.setAutoRangeStickyZero(false);
    var0.setAutoRangeIncludesZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"+ "'", var3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0f);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var1.setBaseURLGenerator(var4, true);
//     int var7 = var1.getColumnCount();
//     java.awt.Font var8 = var1.getBaseItemLabelFont();
//     java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
//     int var13 = var12.getRed();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var8, (java.awt.Paint)var12);
//     org.jfree.chart.text.TextFragment var15 = var14.getFirstTextFragment();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.text.TextAnchor var20 = var19.getRotationAnchor();
//     var14.draw(var16, 0.0f, 0.0f, var20, 0.0f, 100.0f, 0.0d);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, var2, 0.0f, 1, var5);
//     org.jfree.chart.text.TextLine var7 = null;
//     var6.addLine(var7);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.RectangleInsets var10 = var9.getInsets();
//     java.util.List var11 = var9.getAnnotations();
//     int var12 = var9.getBackgroundImageAlignment();
//     boolean var13 = var6.equals((java.lang.Object)var12);
//     java.util.List var14 = var6.getLines();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.util.Size2D var16 = var6.calculateDimensions(var15);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    int var1 = var0.size();
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis();
    var2.zoomRange(100.0d, 100.0d);
    var2.setLowerBound(10.0d);
    org.jfree.chart.axis.NumberTickUnit var8 = var2.getTickUnit();
    java.lang.String var10 = var8.valueToString(3.0d);
    var0.add((org.jfree.chart.axis.TickUnit)var8);
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    var12.zoomRange(0.0d, 100.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
    boolean var20 = var16.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
    var16.setPlot(var21);
    java.awt.Paint var24 = var21.getBackgroundPaint();
    var12.setPlot((org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.axis.NumberTickUnit var26 = var12.getTickUnit();
    java.awt.Color var30 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var31 = var30.getRed();
    java.awt.Color var32 = var30.brighter();
    java.awt.image.ColorModel var33 = null;
    java.awt.Rectangle var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    java.awt.geom.AffineTransform var36 = null;
    java.awt.RenderingHints var37 = null;
    java.awt.PaintContext var38 = var32.createContext(var33, var34, var35, var36, var37);
    float[] var42 = new float[] { (-1.0f), (-1.0f), (-1.0f)};
    float[] var43 = var32.getRGBColorComponents(var42);
    boolean var44 = var26.equals((java.lang.Object)var42);
    org.jfree.chart.axis.TickUnit var45 = var0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit)var26);
    org.jfree.data.Range var46 = null;
    org.jfree.data.Range var47 = null;
    org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 1.0d);
    double var51 = var49.constrain((-1.0d));
    org.jfree.data.Range var52 = org.jfree.data.Range.combine(var46, var49);
    boolean var55 = var49.intersects(0.05d, (-6.0d));
    double var56 = var49.getCentralValue();
    boolean var57 = var0.equals((java.lang.Object)var49);
    java.lang.Object var58 = var0.clone();
    java.awt.Font var60 = null;
    java.awt.Paint var61 = null;
    org.jfree.chart.text.TextMeasurer var64 = null;
    org.jfree.chart.text.TextBlock var65 = org.jfree.chart.text.TextUtilities.createTextBlock("", var60, var61, 0.0f, 1, var64);
    boolean var66 = var0.equals((java.lang.Object)var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "3"+ "'", var10.equals("3"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-11.0d), 9.0d, 5.0d, 76.0d);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var2 = var1.getFixedLegendItems();
    org.jfree.data.category.CategoryDataset var3 = var1.getDataset();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var6 = var4.getSeriesNegativeItemLabelPosition(100);
    java.awt.Paint var9 = var4.getItemLabelPaint(0, 10);
    var1.setNoDataMessagePaint(var9);
    var1.configureDomainAxes();
    float var12 = var1.getBackgroundAlpha();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var1);
    var13.setBackgroundImageAlpha(10.0f);
    var13.setNotify(true);
    int var18 = var13.getSubtitleCount();
    java.lang.Object var19 = var13.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var3 = var1.getSeriesNegativeItemLabelPosition(100);
    boolean var5 = var1.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var7 = var6.getFixedLegendItems();
    var1.setPlot(var6);
    java.awt.Paint var9 = var1.getErrorIndicatorPaint();
    var1.setBase(100.0d);
    boolean var14 = var1.getItemVisible(1, 1);
    java.awt.Shape var16 = var1.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var19 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)0.0f, var16, "", "");
    var19.setToolTipText("UnitType.ABSOLUTE");
    java.lang.String var22 = var19.getToolTipText();
    java.lang.String var23 = var19.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "UnitType.ABSOLUTE"+ "'", var22.equals("UnitType.ABSOLUTE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartChangeEventType.GENERAL", "", var2);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.text.TextAnchor var11 = var10.getTextAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("AxisLabelEntity: label = null");
    java.awt.Font var3 = null;
    java.awt.Paint var4 = null;
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, var4, 0.0f, 1, var7);
    java.util.List var9 = var8.getLines();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var8.calculateDimensions(var10);
    java.util.List var12 = var8.getLines();
    java.util.List var13 = var8.getLines();
    org.jfree.chart.plot.ValueMarker var16 = new org.jfree.chart.plot.ValueMarker(1.0d);
    org.jfree.chart.event.MarkerChangeEvent var17 = null;
    var16.notifyListeners(var17);
    java.awt.Font var19 = var16.getLabelFont();
    org.jfree.chart.text.TextLine var20 = new org.jfree.chart.text.TextLine("TextBlockAnchor.BOTTOM_CENTER", var19);
    var8.addLine(var20);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var23 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var23.setBaseURLGenerator(var26, true);
    int var29 = var23.getColumnCount();
    java.awt.Font var30 = var23.getBaseItemLabelFont();
    java.awt.Color var34 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var35 = var34.getRed();
    org.jfree.chart.text.TextLine var36 = new org.jfree.chart.text.TextLine("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", var30, (java.awt.Paint)var34);
    org.jfree.chart.text.TextFragment var37 = var36.getFirstTextFragment();
    float var38 = var37.getBaselineOffset();
    var20.removeFragment(var37);
    var1.addFragment(var37);
    org.jfree.chart.text.TextFragment var41 = var1.getFirstTextFragment();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis();
    var43.zoomRange(0.0d, 100.0d);
    java.awt.Stroke var47 = var43.getTickMarkStroke();
    boolean var48 = var43.isAutoRange();
    double var49 = var43.getUpperBound();
    java.lang.String var50 = var43.getLabelToolTip();
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.ValueAxis var53 = var51.getRangeAxis(0);
    java.awt.Paint var54 = var51.getOutlinePaint();
    var43.setAxisLinePaint(var54);
    float var56 = var43.getTickMarkInsideLength();
    java.awt.Font var57 = var43.getTickLabelFont();
    org.jfree.chart.text.TextFragment var58 = new org.jfree.chart.text.TextFragment("CategoryLabelEntity: category=0.0, tooltip=, url=", var57);
    var1.addFragment(var58);
    org.jfree.chart.text.TextFragment var61 = new org.jfree.chart.text.TextFragment("RangeType.FULL");
    var1.removeFragment(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var6 = var5.getFixedLegendItems();
    var0.setPlot(var5);
    java.awt.Paint var8 = var0.getErrorIndicatorPaint();
    java.awt.Paint var9 = var0.getBaseOutlinePaint();
    boolean var11 = var0.isSeriesVisible(0);
    org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
    var0.setBaseToolTipGenerator(var12);
    org.jfree.chart.labels.ItemLabelPosition var15 = var0.getSeriesPositiveItemLabelPosition(255);
    var0.setBaseSeriesVisible(false);
    java.awt.Paint var18 = var0.getBaseFillPaint();
    boolean var19 = var0.getBaseCreateEntities();
    var0.setAutoPopulateSeriesShape(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis();
    var4.zoomRange(0.0d, 100.0d);
    java.text.NumberFormat var8 = null;
    var4.setNumberFormatOverride(var8);
    java.awt.Paint var10 = var4.getAxisLinePaint();
    double var11 = var4.getLowerBound();
    org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
    java.text.NumberFormat var13 = null;
    var12.setNumberFormatOverride(var13);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getSeriesNegativeItemLabelPosition(100);
    boolean var20 = var16.isSeriesVisible(10);
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.LegendItemCollection var22 = var21.getFixedLegendItems();
    var16.setPlot(var21);
    java.awt.Paint var24 = var16.getErrorIndicatorPaint();
    var16.setBase(100.0d);
    boolean var29 = var16.getItemVisible(1, 1);
    java.awt.Shape var31 = var16.lookupSeriesShape(100);
    org.jfree.chart.entity.CategoryLabelEntity var34 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)10L, var31, "Category Plot", "");
    var12.setRightArrow(var31);
    var4.setRightArrow(var31);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var38 = var37.getBaseOutlineStroke();
    boolean var40 = var37.isSeriesVisible(10);
    java.awt.Color var44 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var45 = var44.getRed();
    java.awt.Color var46 = var44.brighter();
    java.awt.image.ColorModel var47 = null;
    java.awt.Rectangle var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    java.awt.geom.AffineTransform var50 = null;
    java.awt.RenderingHints var51 = null;
    java.awt.PaintContext var52 = var46.createContext(var47, var48, var49, var50, var51);
    var37.setBaseFillPaint((java.awt.Paint)var46);
    int var54 = var46.getBlue();
    java.lang.String var55 = var46.toString();
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("RectangleEdge.TOP", "LegendItemEntity: seriesKey=10, dataset=null", "ChartChangeEventType.GENERAL", "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=3.0]", var31, (java.awt.Paint)var46);
    int var57 = var56.getSeriesIndex();
    boolean var58 = var56.isShapeFilled();
    java.lang.String var59 = var56.getURLText();
    int var60 = var56.getSeriesIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "java.awt.Color[r=14,g=255,b=255]"+ "'", var55.equals("java.awt.Color[r=14,g=255,b=255]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=3.0]"+ "'", var59.equals("RectangleConstraint[LengthConstraintType.FIXED: width=10.0, height=3.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    var0.setCategoryMargin(1.0d);
    var0.clearCategoryLabelToolTips();
    java.lang.String var5 = var0.getCategoryLabelToolTip((java.lang.Comparable)4.0d);
    float var6 = var0.getTickMarkOutsideLength();
    var0.setCategoryMargin((-5.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0f);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    boolean var3 = var0.isSeriesVisible(10);
    java.awt.Paint var6 = var0.getItemFillPaint(255, 0);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var0.notifyListeners(var7);
    java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var13 = var12.getRed();
    java.awt.Color var14 = var12.brighter();
    int var15 = var12.getAlpha();
    java.awt.Color var22 = java.awt.Color.getHSBColor(1.0f, 10.0f, (-1.0f));
    int var23 = var22.getRed();
    java.awt.Color var24 = var22.brighter();
    float[] var28 = new float[] { 100.0f, 10.0f, 100.0f};
    float[] var29 = var22.getRGBColorComponents(var28);
    float[] var30 = java.awt.Color.RGBtoHSB(10, 10, 255, var28);
    float[] var31 = var12.getColorComponents(var30);
    int var32 = var12.getTransparency();
    java.awt.Color var33 = var12.brighter();
    var0.setErrorIndicatorPaint((java.awt.Paint)var12);
    var0.setSeriesVisible(255, (java.lang.Boolean)false);
    boolean var38 = var0.getAutoPopulateSeriesShape();
    org.jfree.chart.labels.ItemLabelPosition var41 = var0.getNegativeItemLabelPosition(172, (-254));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(100);
    boolean var4 = var0.isSeriesVisible(10);
    org.jfree.chart.LegendItem var7 = var0.getLegendItem(0, 0);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var0.getBaseURLGenerator();
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getSeriesNegativeItemLabelPosition(1);
    java.awt.Shape var12 = var0.getSeriesShape(2);
    java.awt.Font var13 = var0.getBaseItemLabelFont();
    org.jfree.chart.labels.CategorySeriesLabelGenerator var14 = var0.getLegendItemToolTipGenerator();
    var0.setBaseSeriesVisibleInLegend(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var2 = new org.jfree.chart.block.BlockBorder(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)(-1), var1, "", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "", "hi!", "", false, var5, true, var7, false, var9, var10, true, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(0.0d, var1, var2, 10.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, (-1.0d), 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.color.ColorSpace var3 = null;
//     float[] var6 = new float[] { 100.0f, (-1.0f)};
//     float[] var7 = var2.getColorComponents(var3, var6);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var5 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, (java.awt.Paint)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("", "", "hi!", "", var4, var5, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, 100.0d, var2);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.block.Arrangement var1 = null;
    org.jfree.chart.block.Arrangement var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.awt.Color var15 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.awt.Stroke var16 = null;
    java.awt.Shape var18 = null;
    java.awt.Stroke var19 = null;
    java.awt.Color var22 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var23 = var22.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", true, var5, true, (java.awt.Paint)var10, true, (java.awt.Paint)var15, var16, false, var18, var19, (java.awt.Paint)var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Paint var2 = null;
//     org.jfree.chart.text.TextMeasurer var5 = null;
//     org.jfree.chart.text.TextBlock var6 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2, 0.0f, 1, var5);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)"hi!", (java.lang.Object)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, 0.0f, 1.0f, var5, 1.0f, 10.0f, 100.0d);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, 0.0d, 0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    org.jfree.chart.axis.Axis var0 = null;
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var4 = new org.jfree.chart.entity.AxisLabelEntity(var0, var1, "hi!", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)1, var1, var2, var3, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    org.jfree.chart.util.RectangleEdge var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.util.RectangleInsets var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("hi!", var1, (java.awt.Paint)var4, var5, var6, var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape[] var9 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "hi!");

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 10.0d, 0.0d, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    java.awt.Font var2 = null;
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var8, 10.0f, 0, var14);
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    org.jfree.chart.text.TextAnchor var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var19 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)"", var15, var16, var17, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape[] var9 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
//     java.lang.Object var11 = var10.clone();
//     java.awt.Shape var12 = var10.getNextShape();
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var7 = var6.brighter();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var7);
    float[] var9 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var10 = var7.getRGBComponents(var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 100.0d, 100.0d);
    java.awt.Paint var5 = var4.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 1.0d, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "hi!", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.clone(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("hi!", var1);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.ColumnArrangement var5 = new org.jfree.chart.block.ColumnArrangement(var1, var2, 100.0d, 10.0d);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 100.0d, 10.0d);
//     org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var10);
//     
//     // Checks the contract:  equals-hashcode on var5 and var10
//     assertTrue("Contract failed: equals-hashcode on var5 and var10", var5.equals(var10) ? var5.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var5
//     assertTrue("Contract failed: equals-hashcode on var10 and var5", var10.equals(var5) ? var10.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 1.0d, (-1.0f), 1.0f);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    java.awt.Font var1 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var4 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var11 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var12 = var11.brighter();
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var12);
    boolean var14 = var4.equals((java.lang.Object)var12);
    org.jfree.chart.util.RectangleEdge var15 = null;
    org.jfree.chart.util.HorizontalAlignment var16 = null;
    org.jfree.chart.util.VerticalAlignment var17 = null;
    org.jfree.chart.util.RectangleInsets var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle("hi!", var1, (java.awt.Paint)var12, var15, var16, var17, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
//     org.jfree.chart.block.LabelBlock var5 = new org.jfree.chart.block.LabelBlock("", var1, (java.awt.Paint)var4);
//     
//     // Checks the contract:  var5.equals(var5)
//     assertTrue("Contract failed: var5.equals(var5)", var5.equals(var5));
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     var2.draw(var3, 0.0f, 0.0f, var6, 0.0f, 0.0f, 10.0d);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)(byte)(-1), 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape[] var9 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
//     java.awt.Shape var11 = var10.getNextShape();
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }


    float[] var5 = new float[] { 100.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = java.awt.Color.RGBtoHSB(100, (-1), 1, var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "", "", var3, (java.lang.Comparable)(-1), (java.lang.Comparable)(-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var5.createContext(var9, var10, var11, var12, var13);
    int var15 = var5.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 253);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 0.0d, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    java.awt.Font var2 = null;
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var8, 10.0f, 0, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var0, (java.awt.Paint)var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, 1.0f, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem(var0, "", "", "hi!", var4, (java.awt.Paint)var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    var12.draw(var13, 0.0f, 1.0f, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var12.calculateBounds(var18, 10.0f, (-1.0f), var21, 0.0f, 100.0f, 1.0d);
    java.awt.Font var27 = null;
    java.awt.Color var31 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var33 = null;
    org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("", var27, (java.awt.Paint)var31, 1.0f, var33);
    java.awt.Stroke var35 = null;
    java.awt.Color var42 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var43 = var42.brighter();
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var43);
    boolean var46 = var43.equals((java.lang.Object)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem(var0, "hi!", "", "", var25, (java.awt.Paint)var31, var35, (java.awt.Paint)var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 10.0f, 0.0f, 0.0d, 0.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 100.0d, 10.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)"");
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 1.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("hi!", var1, 1.0f, 100.0f, 1.0d, 0.0f, 0.0f);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 10.0d, true);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.util.List var9 = var8.getLines();
    boolean var11 = var8.equals((java.lang.Object)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)'a', var1, var2, var3, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Font var3 = null;
//     java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var7, (-1.0f), var9);
//     org.jfree.chart.text.TextMeasurer var13 = null;
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var7, 10.0f, 0, var13);
//     java.awt.color.ColorSpace var15 = null;
//     java.awt.Color var18 = java.awt.Color.getColor("hi!", (-1));
//     int var19 = var18.getRed();
//     float[] var23 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var24 = var18.getColorComponents(var23);
//     float[] var25 = var7.getComponents(var15, var23);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.lang.Object var2 = null;
//     boolean var3 = var1.equals(var2);
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
//     float var7 = var6.getBaselineOffset();
//     var1.addFragment(var6);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextAnchor var10 = null;
//     float var11 = var6.calculateBaselineOffset(var9, var10);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "");

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0.0f);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (short)1};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { ' '};
//     double[][] var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var4);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    java.awt.Font var2 = null;
    java.awt.Color var6 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var8 = null;
    org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var6, 1.0f, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(var0, (java.awt.Paint)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 1.0d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
    float var7 = var6.getBaselineOffset();
    var1.addFragment(var6);
    float var9 = var6.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0f);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100.0d, var1, var2);
    java.lang.Object var4 = var3.getSource();
    org.jfree.chart.event.ChartChangeEventType var5 = null;
    var3.setType(var5);
    org.jfree.chart.JFreeChart var7 = null;
    var3.setChart(var7);
    java.lang.String var9 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 100.0d+ "'", var4.equals(100.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100.0]"+ "'", var9.equals("org.jfree.chart.event.ChartChangeEvent[source=100.0]"));

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1, var2);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.image.ColorModel var9 = null;
    java.awt.Rectangle var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    java.awt.geom.AffineTransform var12 = null;
    java.awt.RenderingHints var13 = null;
    java.awt.PaintContext var14 = var5.createContext(var9, var10, var11, var12, var13);
    org.jfree.chart.JFreeChart var16 = null;
    org.jfree.chart.event.ChartChangeEventType var17 = null;
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var16, var17);
    boolean var19 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, (java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0.0d);
// 
//   }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     org.jfree.chart.util.HorizontalAlignment var5 = null;
//     org.jfree.chart.util.VerticalAlignment var6 = null;
//     org.jfree.chart.block.ColumnArrangement var9 = new org.jfree.chart.block.ColumnArrangement(var5, var6, 100.0d, 10.0d);
//     boolean var11 = var9.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var12 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var9, var12, (java.lang.Comparable)(short)10);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.data.Range var16 = null;
//     org.jfree.chart.block.RectangleConstraint var18 = new org.jfree.chart.block.RectangleConstraint(var16, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var20 = var18.toFixedHeight(100.0d);
//     org.jfree.chart.util.Size2D var21 = var4.arrange((org.jfree.chart.block.BlockContainer)var14, var15, var20);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("hi!", var1, (java.awt.Paint)var4, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 100.0d, 1.0d);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var1, var2, 1.0d, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=255,g=253,b=100]", var1, 100.0f, (-1.0f), var4, 1.0d, var6);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     var8.draw(var9, 0.0f, 1.0f, var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
//     org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity(var21);
//     
//     // Checks the contract:  equals-hashcode on var22 and var23
//     assertTrue("Contract failed: equals-hashcode on var22 and var23", var22.equals(var23) ? var22.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var22
//     assertTrue("Contract failed: equals-hashcode on var23 and var22", var23.equals(var22) ? var23.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, (-1.0d), 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    int var10 = var9.getRed();
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    boolean var17 = var15.equals((java.lang.Object)253);
    java.awt.Stroke var18 = null;
    java.awt.Font var21 = null;
    java.awt.Color var25 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var27 = null;
    org.jfree.chart.text.TextBlock var28 = org.jfree.chart.text.TextUtilities.createTextBlock("", var21, (java.awt.Paint)var25, (-1.0f), var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    var28.draw(var29, 0.0f, 1.0f, var32);
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.text.TextBlockAnchor var37 = null;
    java.awt.Shape var41 = var28.calculateBounds(var34, 10.0f, (-1.0f), var37, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var42 = new org.jfree.chart.entity.ChartEntity(var41);
    java.awt.Stroke var43 = null;
    java.awt.Paint var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "90,53,90,53,90,53,90,53,90,53,90,53", "", "90,53,90,53,90,53,90,53,90,53,90,53", false, var5, false, (java.awt.Paint)var9, true, (java.awt.Paint)var15, var18, false, var41, var43, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition(var2, var3, var4, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemGraphicPadding(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    var12.draw(var13, 0.0f, 1.0f, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var12.calculateBounds(var18, 10.0f, (-1.0f), var21, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var25);
    java.awt.Stroke var27 = null;
    java.awt.Paint var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem(var0, "", "", "", var25, var27, var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    java.awt.Color var9 = java.awt.Color.getColor("java.awt.Color[r=255,g=253,b=100]", 1);
    java.awt.Stroke var10 = null;
    java.awt.Shape var15 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var18 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var26 = var25.brighter();
    org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var26);
    boolean var28 = var18.equals((java.lang.Object)var26);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var15, (java.awt.Paint)var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem(var0, "90,53,90,53,90,53,90,53,90,53,90,53", "hi!", "java.awt.Color[r=255,g=253,b=100]", var6, (java.awt.Paint)var9, var10, (java.awt.Paint)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    float[] var4 = new float[] { 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(100, 100, 10, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var10 = var9.brighter();
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var10);
    boolean var12 = var2.equals((java.lang.Object)var10);
    java.lang.Number var13 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 0.0f+ "'", var13.equals(0.0f));

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("90,53,90,53,90,53,90,53,90,53,90,53", var1);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
//     boolean var9 = var7.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
//     var1.setMargin(var14);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var1.removeChangeListener(var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var1.draw(var18, var19);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    java.awt.Font var1 = null;
    java.awt.Font var3 = null;
    java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var7, (-1.0f), var9);
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var7, 10.0f, 0, var13);
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setLineAlignment(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var3, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    org.jfree.data.general.Dataset var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var9 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var3, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(100.0d);
    org.jfree.data.Range var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = var4.toRangeHeight(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Font var2 = null;
//     java.awt.Color var6 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var8 = null;
//     org.jfree.chart.text.TextBlock var9 = org.jfree.chart.text.TextUtilities.createTextBlock("", var2, (java.awt.Paint)var6, (-1.0f), var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.text.TextBlockAnchor var13 = null;
//     var9.draw(var10, 0.0f, 1.0f, var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.text.TextBlockAnchor var18 = null;
//     java.awt.Shape var22 = var9.calculateBounds(var15, 10.0f, (-1.0f), var18, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var22, (-1.0d), 100.0f, (-1.0f));
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var12 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(var12, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var16 = var14.toFixedHeight(100.0d);
//     org.jfree.chart.util.Size2D var17 = var9.arrange(var11, var16);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.util.List var9 = var8.getLines();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var8.calculateDimensions(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    var8.draw(var12, 1.0f, 10.0f, var15, 0.0f, 10.0f, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)true);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("90,53,90,53,90,53,90,53,90,53,90,53", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 10.0d);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    java.lang.String var13 = var11.toString();
    java.awt.geom.Rectangle2D var14 = null;
    org.jfree.chart.util.LengthAdjustmentType var15 = null;
    org.jfree.chart.util.LengthAdjustmentType var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var17 = var11.createAdjustedRectangle(var14, var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.0d, (-1.0d), var2);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     java.lang.Object var11 = var9.clone();
//     
//     // Checks the contract:  equals-hashcode on var10 and var11
//     assertTrue("Contract failed: equals-hashcode on var10 and var11", var10.equals(var11) ? var10.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var10
//     assertTrue("Contract failed: equals-hashcode on var11 and var10", var11.equals(var10) ? var11.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
//     org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var1.draw(var4, var5);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var2, "");
    java.lang.String var5 = var4.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0"+ "'", var5.equals("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0"));

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     var9.setURLText("");
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.Paint var14 = null;
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Paint var16 = null;
//     java.awt.Paint[] var17 = new java.awt.Paint[] { var16};
//     java.awt.Paint[] var18 = null;
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape[] var23 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var24 = new org.jfree.chart.plot.DefaultDrawingSupplier(var15, var17, var18, var20, var22, var23);
//     java.lang.Object var25 = var24.clone();
//     java.lang.Object var26 = null;
//     boolean var27 = var24.equals(var26);
//     java.lang.Object var28 = var9.draw(var12, var13, var26);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
//     org.jfree.chart.entity.ChartEntity var5 = new org.jfree.chart.entity.ChartEntity(var3, "");
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var3, 0.0d, 10.0f, 0.0f);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var9.draw(var12, var13);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=253,b=100]", var1);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.chart.util.HorizontalAlignment var11 = null;
//     org.jfree.chart.util.VerticalAlignment var12 = null;
//     org.jfree.chart.block.ColumnArrangement var15 = new org.jfree.chart.block.ColumnArrangement(var11, var12, 100.0d, 10.0d);
//     boolean var17 = var15.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var18 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var15, var18, (java.lang.Comparable)(short)10);
//     java.lang.Object var21 = var20.clone();
//     org.jfree.chart.util.RectangleInsets var22 = var20.getMargin();
//     double var23 = var22.getRight();
//     var9.setMargin(var22);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var20
//     assertTrue("Contract failed: equals-hashcode on var9 and var20", var9.equals(var20) ? var9.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var9
//     assertTrue("Contract failed: equals-hashcode on var20 and var9", var20.equals(var9) ? var20.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var21
//     assertTrue("Contract failed: equals-hashcode on var10 and var21", var10.equals(var21) ? var10.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var10
//     assertTrue("Contract failed: equals-hashcode on var21 and var10", var21.equals(var10) ? var21.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1, var2);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 100.0d, "90,53,90,53,90,53,90,53,90,53,90,53", var3, var4, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100.0d, var1, var2);
    org.jfree.chart.event.ChartChangeEventType var4 = null;
    var3.setType(var4);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    org.jfree.chart.event.TitleChangeEvent var14 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var1);
    org.jfree.chart.util.RectangleEdge var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPosition(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("org.jfree.chart.event.ChartChangeEvent[source=100]", "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0");

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.LegendItemSource var13 = null;
//     org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
//     org.jfree.chart.util.RectangleAnchor var15 = var14.getLegendItemGraphicLocation();
//     java.awt.Font var17 = null;
//     java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var23 = null;
//     org.jfree.chart.text.TextBlock var24 = org.jfree.chart.text.TextUtilities.createTextBlock("", var17, (java.awt.Paint)var21, (-1.0f), var23);
//     int var25 = var21.getGreen();
//     var14.setBackgroundPaint((java.awt.Paint)var21);
//     org.jfree.chart.event.TitleChangeEvent var27 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title)var14);
//     java.lang.Object var28 = var9.draw(var11, var12, (java.lang.Object)var14);
// 
//   }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    var4.setName("");
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var18 = var15.equals((java.lang.Object)(byte)10);
    boolean var19 = var4.equals((java.lang.Object)var18);
    var4.setInfo("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    float[] var4 = new float[] { 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = java.awt.Color.RGBtoHSB(0, 10, 1, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 10.0d);
    var2.setHeight(10.0d);
    var2.setWidth((-1.0d));

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toFixedWidth(100.0d);
    org.jfree.data.Range var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.LegendItemSource[] var3 = var1.getSources();
//     org.jfree.chart.util.HorizontalAlignment var4 = var1.getHorizontalAlignment();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.Range var6 = null;
//     org.jfree.chart.block.RectangleConstraint var8 = new org.jfree.chart.block.RectangleConstraint(var6, 0.0d);
//     org.jfree.chart.util.Size2D var9 = var1.arrange(var5, var8);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateDimensions(var3);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     var8.draw(var9, 0.0f, 1.0f, var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
//     boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
//     var22.setToolTipText("");
//     java.lang.String var27 = var22.getShapeCoords();
//     var22.setURLText("90,53,90,53,90,53,90,53,90,53,90,53");
//     java.lang.String var30 = var22.getToolTipText();
//     java.lang.String var31 = var22.getURLText();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var32 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var33 = null;
//     java.lang.String var34 = var22.getImageMapAreaTag(var32, var33);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
//     java.lang.Object var12 = var9.clone();
//     
//     // Checks the contract:  equals-hashcode on var10 and var12
//     assertTrue("Contract failed: equals-hashcode on var10 and var12", var10.equals(var12) ? var10.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var10
//     assertTrue("Contract failed: equals-hashcode on var12 and var10", var12.equals(var10) ? var12.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("org.jfree.chart.event.ChartChangeEvent[source=100.0]");

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    java.awt.Color var1 = java.awt.Color.getColor("90,53,90,53,90,53,90,53,90,53,90,53");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getLegendItemGraphicLocation();
//     java.awt.Font var37 = null;
//     java.awt.Color var41 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var43 = null;
//     org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, (java.awt.Paint)var41, (-1.0f), var43);
//     int var45 = var41.getGreen();
//     var34.setBackgroundPaint((java.awt.Paint)var41);
//     java.awt.Font var47 = var34.getItemFont();
//     java.awt.Color var54 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var55 = var54.brighter();
//     org.jfree.chart.block.BlockBorder var56 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var55);
//     boolean var58 = var55.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var60 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var47, (java.awt.Paint)var55, 0.0f);
//     org.jfree.chart.block.LabelBlock var61 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var47);
//     var30.setFont(var47);
//     
//     // Checks the contract:  equals-hashcode on var25 and var56
//     assertTrue("Contract failed: equals-hashcode on var25 and var56", var25.equals(var56) ? var25.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var25
//     assertTrue("Contract failed: equals-hashcode on var56 and var25", var56.equals(var25) ? var56.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var61
//     assertTrue("Contract failed: equals-hashcode on var30 and var61", var30.equals(var61) ? var30.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var30
//     assertTrue("Contract failed: equals-hashcode on var61 and var30", var61.equals(var30) ? var61.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.awt.Graphics2D var31 = null;
//     java.awt.Paint var32 = null;
//     java.awt.Paint[] var33 = new java.awt.Paint[] { var32};
//     java.awt.Paint var34 = null;
//     java.awt.Paint[] var35 = new java.awt.Paint[] { var34};
//     java.awt.Paint[] var36 = null;
//     java.awt.Stroke var37 = null;
//     java.awt.Stroke[] var38 = new java.awt.Stroke[] { var37};
//     java.awt.Stroke var39 = null;
//     java.awt.Stroke[] var40 = new java.awt.Stroke[] { var39};
//     java.awt.Shape[] var41 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var42 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var35, var36, var38, var40, var41);
//     java.lang.Object var43 = var42.clone();
//     java.lang.Object var44 = null;
//     boolean var45 = var42.equals(var44);
//     org.jfree.data.Range var46 = null;
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var46, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var50 = var48.toFixedHeight(100.0d);
//     org.jfree.chart.block.LengthConstraintType var51 = var48.getWidthConstraintType();
//     boolean var52 = var42.equals((java.lang.Object)var48);
//     org.jfree.chart.util.Size2D var53 = var30.arrange(var31, var48);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    var4.setName("");
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var18 = var15.equals((java.lang.Object)(byte)10);
    boolean var19 = var4.equals((java.lang.Object)var18);
    org.jfree.chart.ui.Library[] var20 = var4.getLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, 10.0f, 0.0f, var4);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    java.awt.Shape var4 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var17 = var7.equals((java.lang.Object)var15);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var4, (java.awt.Paint)var15);
    java.lang.String var19 = var18.getLabel();
    java.lang.String var20 = var18.getDescription();
    java.lang.Comparable var21 = var18.getSeriesKey();
    org.jfree.chart.JFreeChart var22 = null;
    org.jfree.chart.event.ChartChangeEventType var23 = null;
    org.jfree.chart.event.ChartChangeEvent var24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var18, var22, var23);
    int var25 = var18.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var19.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "hi!"+ "'", var20.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1, var2);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 100.0d, 10.0d);
//     boolean var18 = var16.equals((java.lang.Object)(short)(-1));
//     var9.setArrangement((org.jfree.chart.block.Arrangement)var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    java.awt.Font var31 = null;
    java.awt.Color var35 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var37 = null;
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, (java.awt.Paint)var35, 1.0f, var37);
    org.jfree.data.general.Dataset var39 = null;
    org.jfree.data.general.DatasetChangeEvent var40 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var35, var39);
    org.jfree.chart.LegendItemSource var41 = null;
    org.jfree.chart.title.LegendTitle var42 = new org.jfree.chart.title.LegendTitle(var41);
    org.jfree.chart.LegendItemSource[] var43 = var42.getSources();
    org.jfree.chart.util.RectangleEdge var44 = var42.getLegendItemGraphicEdge();
    java.awt.Font var46 = null;
    java.awt.Color var50 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var52 = null;
    org.jfree.chart.text.TextBlock var53 = org.jfree.chart.text.TextUtilities.createTextBlock("", var46, (java.awt.Paint)var50, (-1.0f), var52);
    java.util.List var54 = var53.getLines();
    org.jfree.chart.LegendItemSource var55 = null;
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
    org.jfree.chart.util.RectangleAnchor var57 = var56.getLegendItemGraphicLocation();
    org.jfree.chart.LegendItemSource[] var58 = var56.getSources();
    org.jfree.chart.util.HorizontalAlignment var59 = var56.getHorizontalAlignment();
    boolean var60 = var53.equals((java.lang.Object)var59);
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.util.RectangleInsets var62 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("hi!", var16, (java.awt.Paint)var35, var44, var59, var61, var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=255,g=253,b=100]", var1, var2);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    var12.draw(var13, 0.0f, 1.0f, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var12.calculateBounds(var18, 10.0f, (-1.0f), var21, 0.0f, 100.0f, 1.0d);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.clone(var25);
    java.awt.Stroke var27 = null;
    java.awt.Shape var32 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var42 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var43 = var42.brighter();
    org.jfree.chart.block.BlockBorder var44 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var43);
    boolean var45 = var35.equals((java.lang.Object)var43);
    org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var32, (java.awt.Paint)var43);
    java.lang.String var47 = var46.getLabel();
    java.lang.String var48 = var46.getDescription();
    java.lang.Comparable var49 = var46.getSeriesKey();
    org.jfree.chart.JFreeChart var50 = null;
    org.jfree.chart.event.ChartChangeEventType var51 = null;
    org.jfree.chart.event.ChartChangeEvent var52 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var46, var50, var51);
    java.awt.Paint var53 = var46.getFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem(var0, "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "org.jfree.chart.event.ChartChangeEvent[source=100]", "hi!", var25, var27, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var47.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "hi!"+ "'", var48.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=253,b=100]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, 10.0f, 0.0f, var5, 10.0f, 100.0f, 10.0d);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 1};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 'a'};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("org.jfree.chart.event.ChartChangeEvent[source=100]", var1, 100.0f, 100.0f, 100.0d, 100.0f, 0.0f);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    org.jfree.chart.axis.NumberTickUnit var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var2, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    org.jfree.chart.entity.LegendItemEntity var23 = new org.jfree.chart.entity.LegendItemEntity(var21);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 1.0d, 0.0f, 1.0f);
    org.jfree.data.category.CategoryDataset var30 = null;
    java.lang.Comparable var31 = null;
    java.lang.Comparable var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var33 = new org.jfree.chart.entity.CategoryItemEntity(var27, "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", "org.jfree.chart.event.ChartChangeEvent[source=100]", var30, var31, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.ColumnArrangement var10 = new org.jfree.chart.block.ColumnArrangement(var6, var7, 100.0d, 10.0d);
//     boolean var12 = var10.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var13 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var13, (java.lang.Comparable)(short)10);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getMargin();
//     double var18 = var17.getRight();
//     java.lang.String var19 = var17.toString();
//     var5.setMargin(var17);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(-1.0d));
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1, var2);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
    org.jfree.chart.util.RectangleAnchor var9 = var8.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, 10.0d);
    boolean var16 = var14.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var14, var17, (java.lang.Comparable)(short)10);
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.util.RectangleInsets var21 = var19.getMargin();
    var8.setMargin(var21);
    java.awt.Color var25 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var26 = var25.getColorSpace();
    org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(var21, (java.awt.Paint)var25);
    java.awt.Stroke var28 = null;
    java.awt.Font var30 = null;
    java.awt.Color var34 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34, (-1.0f), var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var38 = new org.jfree.chart.LegendItem(var0, "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", "90,53,90,53,90,53,90,53,90,53,90,53", "", var6, (java.awt.Paint)var25, var28, (java.awt.Paint)var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    java.lang.String var4 = var3.toString();
    org.jfree.chart.JFreeChart var5 = null;
    var3.setChart(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100]"+ "'", var4.equals("org.jfree.chart.event.ChartChangeEvent[source=100]"));

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("hi!");
    java.lang.Object var8 = null;
    boolean var9 = var7.equals(var8);
    boolean var10 = var4.equals((java.lang.Object)var7);
    var4.setCopyright("90,53,90,53,90,53,90,53,90,53,90,53");
    var4.setLicenceName("java.awt.Color[r=255,g=253,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
    var22.setToolTipText("");
    java.lang.String var27 = var22.getShapeCoords();
    java.lang.Object var28 = null;
    boolean var29 = var22.equals(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var27.equals("90,53,90,53,90,53,90,53,90,53,90,53"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     var1.configure();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.LegendItemSource[] var9 = var8.getSources();
//     org.jfree.chart.util.RectangleEdge var10 = var8.getLegendItemGraphicEdge();
//     java.lang.String var11 = var10.toString();
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var1.draw(var3, 100.0d, var5, var6, var10, var12);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.LegendItemSource var4 = null;
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle(var4);
//     org.jfree.chart.LegendItemSource[] var6 = var5.getSources();
//     org.jfree.chart.util.RectangleEdge var7 = var5.getLegendItemGraphicEdge();
//     double var8 = var1.valueToJava2D((-1.0d), var3, var7);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    org.jfree.chart.util.RectangleInsets var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setMargin(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    org.jfree.chart.axis.NumberAxis var3 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var3.configure();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var7 = var6.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var10 = var9.getDefaultAutoRange();
    var6.setRangeWithMargins(var10, true, false);
    var3.setRangeWithMargins(var10, false, true);
    java.awt.Font var17 = var3.getTickLabelFont();
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    int var3 = java.awt.Color.HSBtoRGB((-1.0f), 1.0f, 100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-6553600));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.util.HorizontalAlignment var22 = var8.getLineAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    java.lang.String var23 = var22.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
//     boolean var9 = var7.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
//     var1.setMargin(var14);
//     java.awt.Color var18 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
//     java.awt.color.ColorSpace var19 = var18.getColorSpace();
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(var14, (java.awt.Paint)var18);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     var20.draw(var21, var22);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape[] var9 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
//     java.lang.Object var11 = var10.clone();
//     java.awt.Paint var12 = var10.getNextPaint();
//     java.awt.Shape var13 = var10.getNextShape();
// 
//   }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
//     java.awt.Shape var2 = var1.getDownArrow();
//     var1.setAutoRangeIncludesZero(true);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.LegendItemSource[] var9 = var8.getSources();
//     org.jfree.chart.util.RectangleEdge var10 = var8.getLegendItemGraphicEdge();
//     double var11 = var1.valueToJava2D(100.0d, var6, var10);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1, 100.0f, 10.0f, var4, (-1.0d), (-1.0f), (-1.0f));
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var1.setRangeWithMargins(var8, false, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1, var2, var3);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
    var22.setToolTipText("");
    java.lang.String var27 = var22.getShapeCoords();
    var22.setURLText("90,53,90,53,90,53,90,53,90,53,90,53");
    java.lang.String var30 = var22.getToolTipText();
    java.lang.String var31 = var22.getURLText();
    java.lang.String var32 = var22.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var27.equals("90,53,90,53,90,53,90,53,90,53,90,53"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + ""+ "'", var30.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var31.equals("90,53,90,53,90,53,90,53,90,53,90,53"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var32.equals("90,53,90,53,90,53,90,53,90,53,90,53"));

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Shape var2 = var1.getDownArrow();
    var1.setAutoRangeIncludesZero(true);
    double var5 = var1.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-8d);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var6 = var5.brighter();
//     var1.setPaint((java.awt.Paint)var6);
//     java.lang.Class var8 = null;
//     java.util.EventListener[] var9 = var1.getListeners(var8);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    org.jfree.chart.text.TextLine var7 = new org.jfree.chart.text.TextLine("hi!");
    java.lang.Object var8 = null;
    boolean var9 = var7.equals(var8);
    boolean var10 = var4.equals((java.lang.Object)var7);
    java.awt.Font var12 = null;
    java.awt.Color var16 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var18 = null;
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("", var12, (java.awt.Paint)var16, (-1.0f), var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.text.TextBlockAnchor var23 = null;
    var19.draw(var20, 0.0f, 1.0f, var23);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.text.TextBlockAnchor var28 = null;
    java.awt.Shape var32 = var19.calculateBounds(var25, 10.0f, (-1.0f), var28, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var32);
    org.jfree.chart.entity.LegendItemEntity var34 = new org.jfree.chart.entity.LegendItemEntity(var32);
    java.lang.String var35 = var34.toString();
    java.lang.Comparable var36 = var34.getSeriesKey();
    java.lang.Object var37 = var34.clone();
    boolean var38 = var7.equals(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var35.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.LegendItemSource[] var3 = var1.getSources();
    java.lang.Object var4 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }


    java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var7 = var6.brighter();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var7);
    java.awt.Stroke var9 = null;
    org.jfree.chart.util.HorizontalAlignment var10 = null;
    org.jfree.chart.util.VerticalAlignment var11 = null;
    org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, 10.0d);
    boolean var16 = var14.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var14, var17, (java.lang.Comparable)(short)10);
    java.lang.Object var20 = var19.clone();
    org.jfree.chart.util.RectangleInsets var21 = var19.getMargin();
    double var23 = var21.trimHeight((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var24 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var7, var9, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1.0d));

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }


    org.jfree.data.general.Dataset var1 = null;
    org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(-6553600), var1);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.LegendItemSource var33 = null;
//     org.jfree.chart.title.LegendTitle var34 = new org.jfree.chart.title.LegendTitle(var33);
//     org.jfree.chart.util.RectangleAnchor var35 = var34.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.ColumnArrangement var40 = new org.jfree.chart.block.ColumnArrangement(var36, var37, 100.0d, 10.0d);
//     boolean var42 = var40.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var43 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var45 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var40, var43, (java.lang.Comparable)(short)10);
//     java.lang.Object var46 = var45.clone();
//     org.jfree.chart.util.RectangleInsets var47 = var45.getMargin();
//     var34.setMargin(var47);
//     org.jfree.chart.LegendItemSource var49 = null;
//     org.jfree.chart.title.LegendTitle var50 = new org.jfree.chart.title.LegendTitle(var49);
//     org.jfree.chart.util.RectangleAnchor var51 = var50.getLegendItemGraphicLocation();
//     var34.setLegendItemGraphicLocation(var51);
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     var54.configure();
//     org.jfree.chart.axis.NumberAxis var57 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.data.Range var58 = var57.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.data.Range var61 = var60.getDefaultAutoRange();
//     var57.setRangeWithMargins(var61, true, false);
//     var54.setRangeWithMargins(var61, false, true);
//     java.awt.Font var68 = var54.getTickLabelFont();
//     boolean var69 = var51.equals((java.lang.Object)var54);
//     java.lang.Object var70 = var30.draw(var31, var32, (java.lang.Object)var54);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    java.lang.String var15 = var1.getID();
    java.awt.Font var16 = var1.getItemFont();
    var1.setPadding((-1.0d), 1.0d, 1.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     java.awt.Paint var2 = var1.getAxisLinePaint();
//     org.jfree.chart.axis.TickUnitSource var3 = null;
//     var1.setStandardTickUnits(var3);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.LegendItemSource[] var9 = var8.getSources();
//     org.jfree.chart.util.RectangleEdge var10 = var8.getLegendItemGraphicEdge();
//     java.lang.String var11 = var10.toString();
//     double var12 = var1.valueToJava2D(104.0d, var6, var10);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
//     org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
//     java.awt.Graphics2D var4 = null;
//     java.awt.Paint var5 = null;
//     java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
//     java.awt.Paint var7 = null;
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     java.awt.Paint[] var9 = null;
//     java.awt.Stroke var10 = null;
//     java.awt.Stroke[] var11 = new java.awt.Stroke[] { var10};
//     java.awt.Stroke var12 = null;
//     java.awt.Stroke[] var13 = new java.awt.Stroke[] { var12};
//     java.awt.Shape[] var14 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var15 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var8, var9, var11, var13, var14);
//     java.lang.Object var16 = var15.clone();
//     java.lang.Object var17 = null;
//     boolean var18 = var15.equals(var17);
//     org.jfree.data.Range var19 = null;
//     org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(var19, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var23 = var21.toFixedHeight(100.0d);
//     org.jfree.chart.block.LengthConstraintType var24 = var21.getWidthConstraintType();
//     boolean var25 = var15.equals((java.lang.Object)var21);
//     org.jfree.chart.util.Size2D var26 = var1.arrange(var4, var21);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 10.0f, 0.0f, var12, 100.0f, 1.0f, 104.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Font var3 = null;
//     java.awt.Color var7 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var9 = null;
//     org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var7, (-1.0f), var9);
//     org.jfree.chart.text.TextMeasurer var13 = null;
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var7, 10.0f, 0, var13);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.text.TextBlockAnchor var18 = null;
//     var14.draw(var15, 1.0f, 10.0f, var18, 0.0f, 1.0f, 0.0d);
//     org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("hi!");
//     java.lang.Object var25 = null;
//     boolean var26 = var24.equals(var25);
//     org.jfree.chart.text.TextLine var28 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var29 = var28.getLastTextFragment();
//     float var30 = var29.getBaselineOffset();
//     var24.addFragment(var29);
//     var14.addLine(var24);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.TextBlockAnchor var36 = null;
//     var14.draw(var33, 0.0f, (-1.0f), var36);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var3, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    java.util.List var8 = var7.getContributors();
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var13.setInfo("");
    org.jfree.chart.ui.Library[] var16 = var13.getLibraries();
    boolean var17 = var7.equals((java.lang.Object)var13);
    java.lang.String var18 = var7.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "hi!"+ "'", var18.equals("hi!"));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    org.jfree.chart.JFreeChart var4 = var3.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
//     boolean var9 = var7.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
//     var1.setMargin(var14);
//     org.jfree.chart.event.TitleChangeListener var16 = null;
//     var1.removeChangeListener(var16);
//     org.jfree.chart.util.RectangleInsets var18 = var1.getMargin();
//     java.awt.geom.Rectangle2D var19 = null;
//     var18.trim(var19);
// 
//   }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
//     java.lang.Class var3 = null;
//     java.util.EventListener[] var4 = var1.getListeners(var3);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    double var14 = var11.calculateRightInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.lang.String var31 = var30.getToolTipText();
//     java.awt.Font var32 = var30.getFont();
//     java.awt.Paint var33 = var30.getPaint();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     java.lang.Object var37 = var30.draw(var34, var35, (java.lang.Object)"org.jfree.chart.event.ChartChangeEvent[source=100.0]");
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.LegendItemSource[] var3 = var2.getSources();
//     org.jfree.chart.util.RectangleEdge var4 = var2.getLegendItemGraphicEdge();
//     java.lang.String var5 = var4.toString();
//     double var6 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var4);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
    java.awt.Paint var31 = var30.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(0.0d, 100.0d, 104.0d, 1.0d);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    var1.setPadding(10.0d, 10.0d, 10.0d, 10.0d);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1, 1.0f, 1.0f, var4, 0.0d, var6);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    var1.setRangeWithMargins(var5, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAutoRangeMinimumSize(0.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    java.lang.String var3 = var2.toString();
    java.awt.geom.Rectangle2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var5 = var2.createOutsetRectangle(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var3.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("90,53,90,53,90,53,90,53,90,53,90,53", var1, 10.0f, 10.0f, var4, 104.0d, var6);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 1.0d, 104.0d);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     var1.configure();
//     java.lang.Object var3 = var1.clone();
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.plot.Plot var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.LegendItemSource var7 = null;
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle(var7);
//     org.jfree.chart.LegendItemSource[] var9 = var8.getSources();
//     org.jfree.chart.util.RectangleEdge var10 = var8.getLegendItemGraphicEdge();
//     java.lang.String var11 = var10.toString();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     org.jfree.chart.axis.AxisSpace var13 = var1.reserveSpace(var4, var5, var6, var10, var12);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
    boolean var9 = var7.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
    var1.setMargin(var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleAnchor var18 = var17.getLegendItemGraphicLocation();
    var1.setLegendItemGraphicLocation(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var21.configure();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var25 = var24.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var28 = var27.getDefaultAutoRange();
    var24.setRangeWithMargins(var28, true, false);
    var21.setRangeWithMargins(var28, false, true);
    java.awt.Font var35 = var21.getTickLabelFont();
    boolean var36 = var18.equals((java.lang.Object)var21);
    org.jfree.chart.text.TextBlockAnchor var37 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var38 = new org.jfree.chart.axis.CategoryLabelPosition(var18, var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("RectangleConstraintType.RANGE");
    java.lang.String var33 = var30.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var33.equals("RectangleConstraintType.RANGE"));

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    java.lang.String var2 = var1.toString();
    java.lang.String var4 = var1.valueToString(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "[size=0]"+ "'", var2.equals("[size=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "10"+ "'", var4.equals("10"));

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     var9.setURLText("");
//     org.jfree.chart.util.HorizontalAlignment var12 = null;
//     org.jfree.chart.util.VerticalAlignment var13 = null;
//     org.jfree.chart.block.ColumnArrangement var16 = new org.jfree.chart.block.ColumnArrangement(var12, var13, 100.0d, 10.0d);
//     boolean var18 = var16.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var19 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var21 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var19, (java.lang.Comparable)(short)10);
//     var9.setArrangement((org.jfree.chart.block.Arrangement)var16);
//     
//     // Checks the contract:  equals-hashcode on var4 and var16
//     assertTrue("Contract failed: equals-hashcode on var4 and var16", var4.equals(var16) ? var4.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var4
//     assertTrue("Contract failed: equals-hashcode on var16 and var4", var16.equals(var4) ? var16.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var21
//     assertTrue("Contract failed: equals-hashcode on var9 and var21", var9.equals(var21) ? var9.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var9
//     assertTrue("Contract failed: equals-hashcode on var21 and var9", var21.equals(var9) ? var21.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape[] var9 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var6, var11, 100, (-1));
    int var15 = var14.getType();
    var14.setPercent(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 100);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0f), (java.lang.Number)(-1.0d));
    org.jfree.chart.ui.BasicProjectInfo var7 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var7.setName("");
    boolean var10 = var2.equals((java.lang.Object)"");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    org.jfree.chart.block.BlockFrame var10 = var9.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("[size=0]", var1);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     var8.draw(var9, 0.0f, 1.0f, var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var24 = var23.getFirstTextFragment();
//     boolean var26 = var23.equals((java.lang.Object)(short)1);
//     var8.addLine(var23);
//     org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var30 = var29.getLastTextFragment();
//     float var31 = var30.getBaselineOffset();
//     var23.addFragment(var30);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.TextAnchor var34 = null;
//     float var35 = var30.calculateBaselineOffset(var33, var34);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getHorizontalAlignment();
    java.lang.String var3 = var2.toString();
    java.lang.String var4 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var3.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var4.equals("HorizontalAlignment.CENTER"));

  }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("java.awt.Color[r=255,g=253,b=100]", var1);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    org.jfree.chart.JFreeChart var4 = null;
    var3.setChart(var4);
    java.lang.Object var6 = var3.getSource();
    org.jfree.chart.event.ChartChangeEventType var7 = var3.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    java.awt.Shape var4 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var17 = var7.equals((java.lang.Object)var15);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var4, (java.awt.Paint)var15);
    java.lang.String var19 = var18.getLabel();
    java.text.AttributedString var20 = var18.getAttributedLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var19.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 1.0f, var7);
    org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
    java.lang.String var10 = var9.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var10.equals("HorizontalAlignment.CENTER"));

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100]", 0);
    var1.setAxisLinePaint((java.awt.Paint)var4);
    java.awt.Color var8 = java.awt.Color.getColor("hi!", (-1));
    int var9 = var8.getRed();
    float[] var13 = new float[] { 100.0f, 1.0f, 1.0f};
    float[] var14 = var8.getColorComponents(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var15 = var4.getComponents(var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleAnchor var5 = var4.getLegendItemGraphicLocation();
    java.awt.Font var7 = null;
    java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11, (-1.0f), var13);
    int var15 = var11.getGreen();
    var4.setBackgroundPaint((java.awt.Paint)var11);
    java.awt.Font var17 = var4.getItemFont();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var25 = var24.brighter();
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var25);
    boolean var28 = var25.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17, (java.awt.Paint)var25, 0.0f);
    org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17);
    java.lang.String var32 = var31.getToolTipText();
    java.awt.Font var33 = var31.getFont();
    java.awt.Paint var34 = var31.getPaint();
    java.awt.Font var35 = var31.getFont();
    java.awt.Color var38 = java.awt.Color.getColor("hi!", (-1));
    int var39 = var38.getRed();
    float[] var43 = new float[] { 100.0f, 1.0f, 1.0f};
    float[] var44 = var38.getColorComponents(var43);
    org.jfree.chart.util.RectangleEdge var45 = null;
    org.jfree.chart.LegendItemSource var46 = null;
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var46);
    org.jfree.chart.util.HorizontalAlignment var48 = var47.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var49 = null;
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var52 = var51.getLabelOffset();
    double var54 = var52.calculateLeftInset((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.ChartChangeEvent[source=100]", var35, (java.awt.Paint)var38, var45, var48, var49, var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 3.0d);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("90,53,90,53,90,53,90,53,90,53,90,53", var1, (-1.0f), 10.0f, 0.0d, 10.0f, 0.0f);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    java.lang.String var15 = var1.getID();
    java.awt.Font var16 = var1.getItemFont();
    org.jfree.chart.block.BlockFrame var17 = var1.getFrame();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 104.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var2 = var1.getLastTextFragment();
    float var3 = var2.getBaselineOffset();
    float var4 = var2.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextAnchor var6 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 0.0f, var4, 1.0d, var6);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.util.List var9 = var8.getLines();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var8.calculateDimensions(var10);
    java.lang.String var12 = var11.toString();
    var11.setHeight(1.0d);
    boolean var16 = var11.equals((java.lang.Object)253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var12.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("hi!", var1);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    boolean var13 = var11.equals((java.lang.Object)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var6.setInfo("");
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var14 = var13.getLicenceName();
    var13.setName("");
    var13.setName("90,53,90,53,90,53,90,53,90,53,90,53");
    var6.addOptionalLibrary((org.jfree.chart.ui.Library)var13);
    boolean var20 = var1.equals((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    java.awt.Paint var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var31 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=253,b=100]", var16, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.jfree.chart.axis.AxisState var2 = new org.jfree.chart.axis.AxisState(10.0d);
    boolean var3 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)1.0f, (java.lang.Object)var2);
    var2.cursorUp(100.0d);
    var2.setMax(100.0d);
    double var8 = var2.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("RectangleConstraintType.RANGE");
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    java.lang.Object var36 = var30.draw(var33, var34, (java.lang.Object)(short)0);
    var30.setToolTipText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    java.awt.Graphics2D var39 = null;
    org.jfree.data.Range var40 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 0.0d);
    org.jfree.chart.block.RectangleConstraint var44 = var42.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var45 = var42.getWidthConstraintType();
    org.jfree.chart.block.LengthConstraintType var46 = var42.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var47 = var30.arrange(var39, var42);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    org.jfree.chart.text.TextBlockAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var1.setRangeWithMargins(var8, false, true);
    java.awt.Font var15 = var1.getTickLabelFont();
    org.jfree.chart.axis.NumberTickUnit var16 = var1.getTickUnit();
    var1.centerRange((-1.0d));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(104.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    var1.setPaint((java.awt.Paint)var6);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleAnchor var12 = var11.getLegendItemGraphicLocation();
    java.awt.Font var14 = null;
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18, (-1.0f), var20);
    int var22 = var18.getGreen();
    var11.setBackgroundPaint((java.awt.Paint)var18);
    java.awt.Font var24 = var11.getItemFont();
    java.awt.Color var31 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var32 = var31.brighter();
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var32);
    boolean var35 = var32.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var37 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var24, (java.awt.Paint)var32, 0.0f);
    org.jfree.chart.title.TextTitle var38 = new org.jfree.chart.title.TextTitle("", var24);
    var1.setLabelFont(var24);
    var1.setValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    var1.setCursor(10.0d);
    double var4 = var1.getCursor();
    var1.cursorRight(0.0d);
    double var7 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    java.awt.Paint var0 = null;
    java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
    java.awt.Paint var2 = null;
    java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
    java.awt.Paint[] var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
    java.awt.Stroke var7 = null;
    java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
    java.awt.Shape[] var9 = null;
    org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
    java.lang.Object var11 = var10.clone();
    java.lang.Object var12 = null;
    boolean var13 = var10.equals(var12);
    org.jfree.data.Range var14 = null;
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, 0.0d);
    org.jfree.chart.block.RectangleConstraint var18 = var16.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var19 = var16.getWidthConstraintType();
    boolean var20 = var10.equals((java.lang.Object)var16);
    org.jfree.chart.block.RectangleConstraint var22 = var16.toFixedHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    var1.setRangeWithMargins(var5, true, false);
    var1.setLowerMargin(104.0d);
    boolean var11 = var1.isInverted();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     org.jfree.chart.util.HorizontalAlignment var10 = null;
//     org.jfree.chart.util.VerticalAlignment var11 = null;
//     org.jfree.chart.block.ColumnArrangement var14 = new org.jfree.chart.block.ColumnArrangement(var10, var11, 100.0d, 10.0d);
//     boolean var16 = var14.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var17 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var14, var17, (java.lang.Comparable)(short)10);
//     var19.setURLText("");
//     var19.setURLText("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0");
//     java.lang.String var24 = var19.getToolTipText();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.data.Range var26 = null;
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var30 = var28.toFixedHeight(100.0d);
//     org.jfree.chart.block.LengthConstraintType var31 = var28.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var32 = var4.arrange((org.jfree.chart.block.BlockContainer)var19, var25, var28);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    var1.setPaint((java.awt.Paint)var6);
    var1.setValue(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 1.0f, var7);
    java.util.List var9 = var8.getLines();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var9);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("RectangleConstraintType.RANGE");
    double var33 = var30.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     java.lang.Comparable var11 = var9.getSeriesKey();
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 10.0d);
//     boolean var20 = var18.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var21 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var18, var21, (java.lang.Comparable)(short)10);
//     java.lang.Object var24 = var23.clone();
//     org.jfree.chart.util.RectangleInsets var25 = var23.getMargin();
//     double var26 = var25.getRight();
//     java.lang.Object var27 = var9.draw(var12, var13, (java.lang.Object)var26);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
//     java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var15 = var14.brighter();
//     org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
//     boolean var17 = var7.equals((java.lang.Object)var15);
//     org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var4, (java.awt.Paint)var15);
//     java.lang.String var19 = var18.getLabel();
//     java.awt.Paint var20 = var18.getLinePaint();
//     java.awt.Paint[] var21 = new java.awt.Paint[] { var20};
//     java.awt.Paint var22 = null;
//     java.awt.Paint[] var23 = new java.awt.Paint[] { var22};
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint[] var26 = null;
//     java.awt.Stroke var27 = null;
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     java.awt.Stroke var29 = null;
//     java.awt.Stroke[] var30 = new java.awt.Stroke[] { var29};
//     java.awt.Shape[] var31 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var32 = new org.jfree.chart.plot.DefaultDrawingSupplier(var23, var25, var26, var28, var30, var31);
//     java.awt.Paint var33 = null;
//     java.awt.Paint[] var34 = new java.awt.Paint[] { var33};
//     java.awt.Paint var35 = null;
//     java.awt.Paint[] var36 = new java.awt.Paint[] { var35};
//     java.awt.Paint[] var37 = null;
//     java.awt.Stroke var38 = null;
//     java.awt.Stroke[] var39 = new java.awt.Stroke[] { var38};
//     java.awt.Stroke var40 = null;
//     java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
//     java.awt.Shape[] var42 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier(var34, var36, var37, var39, var41, var42);
//     java.awt.Paint var44 = null;
//     java.awt.Paint[] var45 = new java.awt.Paint[] { var44};
//     java.awt.Paint var46 = null;
//     java.awt.Paint[] var47 = new java.awt.Paint[] { var46};
//     java.awt.Paint[] var48 = null;
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke var51 = null;
//     java.awt.Stroke[] var52 = new java.awt.Stroke[] { var51};
//     java.awt.Shape[] var53 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier(var45, var47, var48, var50, var52, var53);
//     java.awt.Paint var55 = null;
//     java.awt.Paint[] var56 = new java.awt.Paint[] { var55};
//     java.awt.Paint var57 = null;
//     java.awt.Paint[] var58 = new java.awt.Paint[] { var57};
//     java.awt.Paint[] var59 = null;
//     java.awt.Stroke var60 = null;
//     java.awt.Stroke[] var61 = new java.awt.Stroke[] { var60};
//     java.awt.Stroke var62 = null;
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Shape[] var64 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var65 = new org.jfree.chart.plot.DefaultDrawingSupplier(var56, var58, var59, var61, var63, var64);
//     java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, 0.0f);
//     java.awt.Shape[] var69 = new java.awt.Shape[] { var68};
//     org.jfree.chart.plot.DefaultDrawingSupplier var70 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var23, var37, var50, var63, var69);
//     
//     // Checks the contract:  equals-hashcode on var32 and var43
//     assertTrue("Contract failed: equals-hashcode on var32 and var43", var32.equals(var43) ? var32.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var54
//     assertTrue("Contract failed: equals-hashcode on var32 and var54", var32.equals(var54) ? var32.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var65
//     assertTrue("Contract failed: equals-hashcode on var32 and var65", var32.equals(var65) ? var32.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var32
//     assertTrue("Contract failed: equals-hashcode on var43 and var32", var43.equals(var32) ? var43.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var54
//     assertTrue("Contract failed: equals-hashcode on var43 and var54", var43.equals(var54) ? var43.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var65
//     assertTrue("Contract failed: equals-hashcode on var43 and var65", var43.equals(var65) ? var43.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var32
//     assertTrue("Contract failed: equals-hashcode on var54 and var32", var54.equals(var32) ? var54.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var43
//     assertTrue("Contract failed: equals-hashcode on var54 and var43", var54.equals(var43) ? var54.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var65
//     assertTrue("Contract failed: equals-hashcode on var54 and var65", var54.equals(var65) ? var54.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var32
//     assertTrue("Contract failed: equals-hashcode on var65 and var32", var65.equals(var32) ? var65.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var43
//     assertTrue("Contract failed: equals-hashcode on var65 and var43", var65.equals(var43) ? var65.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var54
//     assertTrue("Contract failed: equals-hashcode on var65 and var54", var65.equals(var54) ? var65.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var2 = var1.getFirstTextFragment();
//     boolean var4 = var1.equals((java.lang.Object)(short)1);
//     org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var7 = var6.getLastTextFragment();
//     float var8 = var7.getBaselineOffset();
//     var1.addFragment(var7);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.text.TextAnchor var13 = null;
//     var1.draw(var10, 0.0f, (-1.0f), var13, 0.0f, 1.0f, (-1.0d));
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("Size2D[width=100.0, height=0.0]", var1);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.trimWidth(104.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1, (-6553600));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, (-1.0f), (-1.0f), var17, 100.0f, 0.0f, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    var1.setMargin((-1.0d), 1.0d, 100.0d, 100.0d);
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setHorizontalAlignment(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.0d, 100.0d, 253, (java.lang.Comparable)"[size=0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    var1.setTickLabelPaint((java.awt.Paint)var4);
    boolean var7 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
//     java.lang.Object var2 = var1.clone();
//     java.awt.Font var4 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
//     java.awt.image.ColorModel var12 = null;
//     java.awt.Rectangle var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.AffineTransform var15 = null;
//     java.awt.RenderingHints var16 = null;
//     java.awt.PaintContext var17 = var8.createContext(var12, var13, var14, var15, var16);
//     boolean var18 = var1.equals((java.lang.Object)var15);
//     java.lang.Object var19 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var19
//     assertTrue("Contract failed: equals-hashcode on var2 and var19", var2.equals(var19) ? var2.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var2
//     assertTrue("Contract failed: equals-hashcode on var19 and var2", var19.equals(var2) ? var19.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 1.0f, 100.0f, 1.0d, 1.0f, 100.0f);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(10.0d, 100.0d, 1.0d, 104.0d);

  }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var30.draw(var31, var32);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    java.awt.Shape var4 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var17 = var7.equals((java.lang.Object)var15);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var4, (java.awt.Paint)var15);
    java.lang.String var19 = var18.getLabel();
    java.lang.String var20 = var18.getLabel();
    java.awt.Paint var21 = var18.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var19.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var20.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    var1.setPaint((java.awt.Paint)var6);
    org.jfree.chart.util.RectangleInsets var8 = var1.getLabelOffset();
    java.lang.Object var9 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    var12.draw(var13, 0.0f, 1.0f, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var12.calculateBounds(var18, 10.0f, (-1.0f), var21, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var25);
    org.jfree.chart.entity.LegendItemEntity var27 = new org.jfree.chart.entity.LegendItemEntity(var25);
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.rotateShape(var25, 1.0d, 0.0f, 1.0f);
    java.awt.Stroke var32 = null;
    java.awt.Shape var37 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var40 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var48 = var47.brighter();
    org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var48);
    boolean var50 = var40.equals((java.lang.Object)var48);
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var37, (java.awt.Paint)var48);
    java.lang.String var52 = var51.getLabel();
    java.lang.String var53 = var51.getLabel();
    java.lang.Comparable var54 = var51.getSeriesKey();
    java.awt.Paint var55 = var51.getLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem(var0, "90,53,90,53,90,53,90,53,90,53,90,53", "hi!", "hi!", var25, var32, var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var52.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var53.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(byte)10);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=100.0, height=0.0]");

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 100.0d, 100.0d);
    var1.setFrame((org.jfree.chart.block.BlockFrame)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    java.awt.Shape var7 = null;
    java.awt.Font var9 = null;
    java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, (-1.0f), var15);
    java.awt.Color var17 = var13.darker();
    int var18 = var13.getTransparency();
    org.jfree.chart.LegendItem var19 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=100.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "java.awt.Color[r=255,g=253,b=100]", "", var7, (java.awt.Paint)var13);
    org.jfree.chart.plot.ValueMarker var21 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var22 = var21.getLabelAnchor();
    java.awt.Stroke var23 = var21.getOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var25 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var2, (java.awt.Paint)var13, var23, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var4.setInfo("");
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    java.lang.String var8 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    var1.setTickLabelPaint((java.awt.Paint)var4);
    var1.setLabelAngle(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("org.jfree.chart.event.ChartChangeEvent[source=100.0]", "Size2D[width=100.0, height=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "");

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var4.setName("");
    var4.setName("Size2D[width=100.0, height=0.0]");

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var30.draw(var31, var32);
//     org.jfree.chart.LegendItemSource var36 = null;
//     org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var36);
//     org.jfree.chart.util.RectangleAnchor var38 = var37.getLegendItemGraphicLocation();
//     java.awt.Font var40 = null;
//     java.awt.Color var44 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var46 = null;
//     org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("", var40, (java.awt.Paint)var44, (-1.0f), var46);
//     int var48 = var44.getGreen();
//     var37.setBackgroundPaint((java.awt.Paint)var44);
//     java.awt.Font var50 = var37.getItemFont();
//     java.awt.Color var57 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var58 = var57.brighter();
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var58);
//     boolean var61 = var58.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var50, (java.awt.Paint)var58, 0.0f);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("", var50);
//     var30.setFont(var50);
//     
//     // Checks the contract:  equals-hashcode on var25 and var59
//     assertTrue("Contract failed: equals-hashcode on var25 and var59", var25.equals(var59) ? var25.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var25
//     assertTrue("Contract failed: equals-hashcode on var59 and var25", var59.equals(var25) ? var59.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     java.lang.Comparable var1 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, var1);
// 
//   }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.TickUnitSource var3 = null;
    var1.setStandardTickUnits(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var3 = var2.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var0, var3);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var5, var8);
    org.jfree.data.Range var10 = org.jfree.data.Range.combine(var3, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var13 = org.jfree.data.Range.expand(var5, 104.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    var1.setTickLabelPaint((java.awt.Paint)var4);
    float var7 = var1.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0f);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var1.setRangeWithMargins(var8, false, true);
    java.awt.Font var15 = var1.getTickLabelFont();
    org.jfree.data.RangeType var16 = var1.getRangeType();
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var20, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    java.util.List var25 = var24.getContributors();
    org.jfree.chart.ui.BasicProjectInfo var30 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var30.setInfo("");
    org.jfree.chart.ui.Library[] var33 = var30.getLibraries();
    boolean var34 = var24.equals((java.lang.Object)var30);
    boolean var35 = var16.equals((java.lang.Object)var30);
    java.lang.String var36 = var16.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "RangeType.FULL"+ "'", var36.equals("RangeType.FULL"));

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    var1.setPaint((java.awt.Paint)var6);
    java.lang.Object var8 = var1.clone();
    org.jfree.chart.util.LengthAdjustmentType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", "org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.lang.String var3 = var2.getEmail();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100.0]"+ "'", var3.equals("org.jfree.chart.event.ChartChangeEvent[source=100.0]"));

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var7 = var6.brighter();
    org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var7);
    java.awt.Color var11 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var12 = var11.getColorSpace();
    float[] var13 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var14 = var7.getColorComponents(var12, var13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var10, (java.lang.Comparable)true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var12
//     assertTrue("Contract failed: equals-hashcode on var9 and var12", var9.equals(var12) ? var9.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var9
//     assertTrue("Contract failed: equals-hashcode on var12 and var9", var12.equals(var9) ? var12.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.TickUnitSource var3 = null;
    var1.setStandardTickUnits(var3);
    double var5 = var1.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0E-8d);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    double var4 = var2.calculateTopInset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 3.0d);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
    var22.setToolTipText("");
    java.lang.String var27 = var22.getShapeCoords();
    java.lang.String var28 = var22.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "90,53,90,53,90,53,90,53,90,53,90,53"+ "'", var27.equals("90,53,90,53,90,53,90,53,90,53,90,53"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "poly"+ "'", var28.equals("poly"));

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.lang.Object var2 = null;
//     boolean var3 = var1.equals(var2);
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
//     float var7 = var6.getBaselineOffset();
//     var1.addFragment(var6);
//     org.jfree.chart.text.TextFragment var9 = var1.getLastTextFragment();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.text.TextAnchor var11 = null;
//     float var12 = var9.calculateBaselineOffset(var10, var11);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var24 = var23.getFirstTextFragment();
    boolean var26 = var23.equals((java.lang.Object)(short)1);
    var8.addLine(var23);
    org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var30 = var29.getLastTextFragment();
    float var31 = var30.getBaselineOffset();
    var23.addFragment(var30);
    java.lang.String var33 = var30.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "hi!"+ "'", var33.equals("hi!"));

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
//     double var4 = var2.calculateRightInset(100.0d);
//     double var6 = var2.calculateTopInset(0.0d);
//     java.awt.geom.Rectangle2D var7 = null;
//     var2.trim(var7);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     var1.configure();
//     java.lang.Object var3 = var1.clone();
//     var1.setVisible(false);
//     double var6 = var1.getLowerMargin();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.LegendItemSource var9 = null;
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
//     org.jfree.chart.LegendItemSource[] var11 = var10.getSources();
//     org.jfree.chart.util.RectangleEdge var12 = var10.getLegendItemGraphicEdge();
//     java.lang.String var13 = var12.toString();
//     double var14 = var1.lengthToJava2D(100.0d, var8, var12);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     var1.configure();
//     java.lang.Object var3 = var1.clone();
//     var1.setRangeAboutValue(100.0d, 100.0d);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.LegendItemSource var9 = null;
//     org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle(var9);
//     org.jfree.chart.LegendItemSource[] var11 = var10.getSources();
//     org.jfree.chart.util.RectangleEdge var12 = var10.getLegendItemGraphicEdge();
//     java.lang.String var13 = var12.toString();
//     double var14 = var1.valueToJava2D(104.0d, var8, var12);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleAnchor var3 = var2.getLabelAnchor();
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
//     org.jfree.chart.util.RectangleAnchor var6 = var5.getLabelAnchor();
//     java.awt.Color var9 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var10 = var9.brighter();
//     var5.setPaint((java.awt.Paint)var10);
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
//     org.jfree.chart.util.RectangleAnchor var16 = var15.getLegendItemGraphicLocation();
//     java.awt.Font var18 = null;
//     java.awt.Color var22 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var24 = null;
//     org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, (-1.0f), var24);
//     int var26 = var22.getGreen();
//     var15.setBackgroundPaint((java.awt.Paint)var22);
//     java.awt.Font var28 = var15.getItemFont();
//     java.awt.Color var35 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var36 = var35.brighter();
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var36);
//     boolean var39 = var36.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var28, (java.awt.Paint)var36, 0.0f);
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle("", var28);
//     var5.setLabelFont(var28);
//     org.jfree.chart.util.RectangleAnchor var44 = var5.getLabelAnchor();
//     var2.setLabelAnchor(var44);
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var0, var44);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    var1.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Shape var2 = var1.getDownArrow();
    var1.setAutoRangeIncludesZero(true);
    java.util.EventListener var5 = null;
    boolean var6 = var1.hasListener(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var4.setInfo("");
    org.jfree.chart.ui.Library[] var7 = var4.getLibraries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var7);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelOffset();
    java.lang.String var3 = var2.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var3.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.String var2 = var1.getID();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    boolean var7 = var1.equals((java.lang.Object)var5);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleAnchor var10 = var9.getLegendItemGraphicLocation();
    org.jfree.chart.LegendItemSource[] var11 = var9.getSources();
    boolean var12 = var1.equals((java.lang.Object)var9);
    java.awt.Font var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.setItemFont(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "hi!"+ "'", var2.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.data.Range var3 = var2.getDefaultAutoRange();
//     org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     org.jfree.data.Range var6 = var5.getDefaultAutoRange();
//     var2.setRangeWithMargins(var6, true, false);
//     var2.setLowerMargin(104.0d);
//     java.awt.Font var12 = var2.getLabelFont();
//     org.jfree.chart.plot.Plot var13 = null;
//     org.jfree.chart.JFreeChart var15 = new org.jfree.chart.JFreeChart("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var12, var13, true);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    java.lang.Object var3 = var1.clone();
    var1.setRangeAboutValue(100.0d, 100.0d);
    org.jfree.chart.util.RectangleInsets var7 = var1.getLabelInsets();
    java.awt.geom.Rectangle2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var9 = var7.createOutsetRectangle(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(104.0d);
    var1.setValue(104.0d);
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Color var8 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 100);
    var5.setPaint((java.awt.Paint)var8);
    var1.setLabelPaint((java.awt.Paint)var8);
    org.jfree.chart.util.RectangleAnchor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelAnchor(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1, 10.0f, 10.0f, var4, 10.0d, var6);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("");

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
//     java.awt.color.ColorSpace var5 = var4.getColorSpace();
//     var1.setTickLabelPaint((java.awt.Paint)var4);
//     var1.setUpperBound(0.0d);
//     var1.setTickMarkInsideLength(0.0f);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.plot.Plot var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var14);
//     org.jfree.chart.util.RectangleInsets var16 = var15.getItemLabelPadding();
//     var15.setWidth((-1.0d));
//     org.jfree.chart.LegendItemSource var19 = null;
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var19);
//     org.jfree.chart.LegendItemSource[] var21 = var20.getSources();
//     org.jfree.chart.util.RectangleEdge var22 = var20.getLegendItemGraphicEdge();
//     var15.setPosition(var22);
//     java.lang.String var24 = var22.toString();
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     org.jfree.chart.axis.AxisSpace var26 = var1.reserveSpace(var11, var12, var13, var22, var25);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }
// 
// 
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.LegendItemSource[] var3 = var2.getSources();
//     org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-1), (java.lang.Object)var3);
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     var13.draw(var14, 0.0f, 1.0f, var17);
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var13.calculateBounds(var19, 10.0f, (-1.0f), var22, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var26);
//     boolean var29 = var27.equals((java.lang.Object)(byte)(-1));
//     var27.setToolTipText("");
//     java.lang.String var32 = var27.getShapeCoords();
//     var27.setURLText("90,53,90,53,90,53,90,53,90,53,90,53");
//     java.lang.String var35 = var27.getToolTipText();
//     var4.setObject((java.lang.Object)var35);
//     java.lang.Object var37 = var4.clone();
//     java.lang.Object var38 = var4.clone();
//     
//     // Checks the contract:  equals-hashcode on var37 and var38
//     assertTrue("Contract failed: equals-hashcode on var37 and var38", var37.equals(var38) ? var37.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var37
//     assertTrue("Contract failed: equals-hashcode on var38 and var37", var38.equals(var37) ? var38.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.util.List var9 = var8.getLines();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var8.calculateDimensions(var10);
    java.lang.Object var12 = var11.clone();
    var11.setWidth(10.0d);
    java.lang.String var15 = var11.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "Size2D[width=10.0, height=0.0]"+ "'", var15.equals("Size2D[width=10.0, height=0.0]"));

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
//     boolean var9 = var7.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
//     java.lang.Object var13 = var12.clone();
//     org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
//     var1.setMargin(var14);
//     org.jfree.chart.LegendItemSource var16 = null;
//     org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
//     org.jfree.chart.util.RectangleAnchor var18 = var17.getLegendItemGraphicLocation();
//     var1.setLegendItemGraphicLocation(var18);
//     org.jfree.chart.util.HorizontalAlignment var20 = null;
//     org.jfree.chart.util.VerticalAlignment var21 = null;
//     org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, 10.0d);
//     boolean var26 = var24.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var27 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, var27, (java.lang.Comparable)(short)10);
//     java.lang.Object var30 = var29.clone();
//     org.jfree.chart.util.RectangleInsets var31 = var29.getMargin();
//     double var32 = var31.getRight();
//     java.lang.String var33 = var31.toString();
//     boolean var34 = var18.equals((java.lang.Object)var33);
//     
//     // Checks the contract:  equals-hashcode on var7 and var24
//     assertTrue("Contract failed: equals-hashcode on var7 and var24", var7.equals(var24) ? var7.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var7
//     assertTrue("Contract failed: equals-hashcode on var24 and var7", var24.equals(var7) ? var24.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var29
//     assertTrue("Contract failed: equals-hashcode on var12 and var29", var12.equals(var29) ? var12.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var12
//     assertTrue("Contract failed: equals-hashcode on var29 and var12", var29.equals(var12) ? var29.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var30
//     assertTrue("Contract failed: equals-hashcode on var13 and var30", var13.equals(var30) ? var13.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var13
//     assertTrue("Contract failed: equals-hashcode on var30 and var13", var30.equals(var13) ? var30.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    double var13 = var11.getLeft();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-246));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 1.0f, var7);
    org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
    boolean var11 = var9.equals((java.lang.Object)"90,53,90,53,90,53,90,53,90,53,90,53");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var24 = var23.getFirstTextFragment();
    boolean var26 = var23.equals((java.lang.Object)(short)1);
    var8.addLine(var23);
    org.jfree.chart.JFreeChart var28 = null;
    org.jfree.chart.event.ChartChangeEventType var29 = null;
    org.jfree.chart.event.ChartChangeEvent var30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var8, var28, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    boolean var3 = var1.isNegativeArrowVisible();
    boolean var4 = var1.isPositiveArrowVisible();
    var1.setUpperBound(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     java.awt.Font var4 = null;
//     java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var10 = null;
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
//     int var12 = var8.getGreen();
//     var1.setBackgroundPaint((java.awt.Paint)var8);
//     java.awt.Font var14 = var1.getItemFont();
//     java.lang.String var15 = var1.getID();
//     java.awt.Font var16 = var1.getItemFont();
//     org.jfree.chart.LegendItemSource var17 = null;
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
//     org.jfree.chart.util.HorizontalAlignment var19 = null;
//     org.jfree.chart.util.VerticalAlignment var20 = null;
//     org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 100.0d, 10.0d);
//     boolean var25 = var23.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var26 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var23, var26, (java.lang.Comparable)(short)10);
//     java.lang.Object var29 = var28.clone();
//     org.jfree.chart.util.RectangleInsets var30 = var28.getMargin();
//     var18.setLegendItemGraphicPadding(var30);
//     org.jfree.chart.LegendItemSource var32 = null;
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
//     org.jfree.chart.util.RectangleAnchor var34 = var33.getLegendItemGraphicLocation();
//     var18.setLegendItemGraphicAnchor(var34);
//     var1.setLegendItemGraphicLocation(var34);
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleAnchor var39 = var38.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 100.0d, 10.0d);
//     boolean var46 = var44.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var47 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var44, var47, (java.lang.Comparable)(short)10);
//     java.lang.Object var50 = var49.clone();
//     org.jfree.chart.util.RectangleInsets var51 = var49.getMargin();
//     var38.setMargin(var51);
//     java.awt.Color var55 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
//     java.awt.color.ColorSpace var56 = var55.getColorSpace();
//     org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder(var51, (java.awt.Paint)var55);
//     var1.setItemLabelPadding(var51);
//     
//     // Checks the contract:  equals-hashcode on var23 and var44
//     assertTrue("Contract failed: equals-hashcode on var23 and var44", var23.equals(var44) ? var23.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var23
//     assertTrue("Contract failed: equals-hashcode on var44 and var23", var44.equals(var23) ? var44.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var49
//     assertTrue("Contract failed: equals-hashcode on var28 and var49", var28.equals(var49) ? var28.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var28
//     assertTrue("Contract failed: equals-hashcode on var49 and var28", var49.equals(var28) ? var49.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var50
//     assertTrue("Contract failed: equals-hashcode on var29 and var50", var29.equals(var50) ? var29.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var29
//     assertTrue("Contract failed: equals-hashcode on var50 and var29", var50.equals(var29) ? var50.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    boolean var24 = var22.equals((java.lang.Object)(byte)(-1));
    var22.setToolTipText("");
    var22.setURLText("");
    var22.setURLText("Size2D[width=10.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.extendWidth(1.0d);
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var7 = var6.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var8 = null;
    var6.setMarkerBand(var8);
    java.awt.Shape var10 = var6.getLeftArrow();
    org.jfree.chart.axis.TickUnitSource var11 = null;
    var6.setStandardTickUnits(var11);
    var6.setTickMarkOutsideLength(100.0f);
    boolean var15 = var2.equals((java.lang.Object)100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }


    org.jfree.chart.LegendItemSource var3 = null;
    org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
    org.jfree.chart.util.RectangleAnchor var5 = var4.getLegendItemGraphicLocation();
    java.awt.Font var7 = null;
    java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var13 = null;
    org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11, (-1.0f), var13);
    int var15 = var11.getGreen();
    var4.setBackgroundPaint((java.awt.Paint)var11);
    java.awt.Font var17 = var4.getItemFont();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var25 = var24.brighter();
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var25);
    boolean var28 = var25.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17, (java.awt.Paint)var25, 0.0f);
    org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var17);
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17);
    double var33 = var32.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 104.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
//     boolean var6 = var4.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var7 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
//     java.lang.Object var10 = var9.clone();
//     var9.setURLText("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0");
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var9.draw(var13, var14);
// 
//   }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }
// 
// 
//     java.awt.Paint var0 = null;
//     java.awt.Paint[] var1 = new java.awt.Paint[] { var0};
//     java.awt.Paint var2 = null;
//     java.awt.Paint[] var3 = new java.awt.Paint[] { var2};
//     java.awt.Paint[] var4 = null;
//     java.awt.Stroke var5 = null;
//     java.awt.Stroke[] var6 = new java.awt.Stroke[] { var5};
//     java.awt.Stroke var7 = null;
//     java.awt.Stroke[] var8 = new java.awt.Stroke[] { var7};
//     java.awt.Shape[] var9 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var10 = new org.jfree.chart.plot.DefaultDrawingSupplier(var1, var3, var4, var6, var8, var9);
//     java.lang.Object var11 = var10.clone();
//     java.lang.Object var12 = null;
//     boolean var13 = var10.equals(var12);
//     org.jfree.data.Range var14 = null;
//     org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(var14, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var18 = var16.toFixedHeight(100.0d);
//     org.jfree.chart.block.LengthConstraintType var19 = var16.getWidthConstraintType();
//     boolean var20 = var10.equals((java.lang.Object)var16);
//     java.awt.Stroke var21 = var10.getNextOutlineStroke();
//     java.awt.Shape var22 = var10.getNextShape();
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(100.0d);
    double var5 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
    java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var17 = var16.brighter();
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var17);
    boolean var20 = var17.equals((java.lang.Object)(byte)10);
    boolean var21 = var8.equals((java.lang.Object)(byte)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.lang.Object var2 = null;
//     boolean var3 = var1.equals(var2);
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
//     float var7 = var6.getBaselineOffset();
//     var1.addFragment(var6);
//     java.lang.String var9 = var6.getText();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.text.TextAnchor var11 = null;
//     float var12 = var6.calculateBaselineOffset(var10, var11);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     var30.draw(var31, var32);
//     java.lang.String var34 = var30.getText();
//     org.jfree.chart.LegendItemSource var37 = null;
//     org.jfree.chart.title.LegendTitle var38 = new org.jfree.chart.title.LegendTitle(var37);
//     org.jfree.chart.util.RectangleAnchor var39 = var38.getLegendItemGraphicLocation();
//     java.awt.Font var41 = null;
//     java.awt.Color var45 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var47 = null;
//     org.jfree.chart.text.TextBlock var48 = org.jfree.chart.text.TextUtilities.createTextBlock("", var41, (java.awt.Paint)var45, (-1.0f), var47);
//     int var49 = var45.getGreen();
//     var38.setBackgroundPaint((java.awt.Paint)var45);
//     java.awt.Font var51 = var38.getItemFont();
//     java.awt.Color var58 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var59 = var58.brighter();
//     org.jfree.chart.block.BlockBorder var60 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var59);
//     boolean var62 = var59.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var51, (java.awt.Paint)var59, 0.0f);
//     org.jfree.chart.block.LabelBlock var65 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var51);
//     java.lang.String var66 = var65.getToolTipText();
//     java.awt.Font var67 = var65.getFont();
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
//     java.awt.Font var70 = var69.getTickLabelFont();
//     var65.setFont(var70);
//     var30.setFont(var70);
//     
//     // Checks the contract:  equals-hashcode on var25 and var60
//     assertTrue("Contract failed: equals-hashcode on var25 and var60", var25.equals(var60) ? var25.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var25
//     assertTrue("Contract failed: equals-hashcode on var60 and var25", var60.equals(var25) ? var60.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var1.setRangeWithMargins(var8, false, true);
    java.awt.Font var15 = var1.getTickLabelFont();
    org.jfree.data.RangeType var16 = var1.getRangeType();
    java.awt.Image var20 = null;
    org.jfree.chart.ui.ProjectInfo var24 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var20, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    java.util.List var25 = var24.getContributors();
    org.jfree.chart.ui.BasicProjectInfo var30 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var30.setInfo("");
    org.jfree.chart.ui.Library[] var33 = var30.getLibraries();
    boolean var34 = var24.equals((java.lang.Object)var30);
    boolean var35 = var16.equals((java.lang.Object)var30);
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle(var39);
    org.jfree.chart.util.RectangleAnchor var41 = var40.getLegendItemGraphicLocation();
    java.awt.Font var43 = null;
    java.awt.Color var47 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, (-1.0f), var49);
    int var51 = var47.getGreen();
    var40.setBackgroundPaint((java.awt.Paint)var47);
    java.awt.Font var53 = var40.getItemFont();
    java.awt.Color var60 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var61 = var60.brighter();
    org.jfree.chart.block.BlockBorder var62 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var61);
    boolean var64 = var61.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var66 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var53, (java.awt.Paint)var61, 0.0f);
    org.jfree.chart.title.TextTitle var67 = new org.jfree.chart.title.TextTitle("", var53);
    org.jfree.chart.block.LabelBlock var68 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var53);
    boolean var69 = var16.equals((java.lang.Object)var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "java.awt.Color[r=255,g=253,b=100]", "hi!", "Size2D[width=100.0, height=0.0]", "");

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
    org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
    java.lang.String var4 = var3.toString();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.title.LegendTitle var6 = new org.jfree.chart.title.LegendTitle(var5);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.block.ColumnArrangement var11 = new org.jfree.chart.block.ColumnArrangement(var7, var8, 100.0d, 10.0d);
    boolean var13 = var11.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var14 = null;
    org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, var14, (java.lang.Comparable)(short)10);
    java.lang.Object var17 = var16.clone();
    org.jfree.chart.util.RectangleInsets var18 = var16.getMargin();
    var6.setLegendItemGraphicPadding(var18);
    boolean var20 = var3.equals((java.lang.Object)var6);
    var6.setWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "RectangleEdge.LEFT"+ "'", var4.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var5 = var4.getLicenceName();
    var4.setName("");
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var18 = var15.equals((java.lang.Object)(byte)10);
    boolean var19 = var4.equals((java.lang.Object)var18);
    java.lang.String var20 = var4.getLicenceName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "hi!"+ "'", var20.equals("hi!"));

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(0.0f, (-1.0f));
    org.jfree.chart.entity.TickLabelEntity var5 = new org.jfree.chart.entity.TickLabelEntity(var2, "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var13 = var11.trimHeight((-1.0d));
    java.awt.geom.Rectangle2D var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var17 = var11.createOutsetRectangle(var14, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(100.0d);
//     org.jfree.chart.block.RectangleConstraint var6 = var2.toFixedWidth(100.0d);
//     org.jfree.data.Range var7 = var2.getWidthRange();
//     java.awt.Font var9 = null;
//     java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var15 = null;
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, (-1.0f), var15);
//     java.util.List var17 = var16.getLines();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.util.Size2D var19 = var16.calculateDimensions(var18);
//     java.lang.String var20 = var19.toString();
//     org.jfree.chart.util.Size2D var21 = var2.calculateConstrainedSize(var19);
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    java.awt.Shape var5 = var1.getLeftArrow();
    org.jfree.chart.axis.TickUnitSource var6 = null;
    var1.setStandardTickUnits(var6);
    var1.setTickMarkOutsideLength(10.0f);
    java.awt.Stroke var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setAxisLineStroke(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    org.jfree.data.category.CategoryDataset var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var1.generateLabel(var2, (-6553600));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLabelAnchor();
    java.awt.Stroke var3 = var1.getOutlineStroke();
    float var4 = var1.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.8f);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.lang.String var31 = var30.getToolTipText();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var30.draw(var32, var33);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
    int var7 = var6.getRed();
    float[] var11 = new float[] { 100.0f, 1.0f, 1.0f};
    float[] var12 = var6.getColorComponents(var11);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.0d, (java.awt.Paint)var6);
    boolean var15 = var6.equals((java.lang.Object)10);
    int var16 = var6.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    java.lang.String var15 = var1.getID();
    java.awt.Font var16 = var1.getItemFont();
    org.jfree.chart.LegendItemSource var17 = null;
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var17);
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 100.0d, 10.0d);
    boolean var25 = var23.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var26 = null;
    org.jfree.chart.title.LegendItemBlockContainer var28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var23, var26, (java.lang.Comparable)(short)10);
    java.lang.Object var29 = var28.clone();
    org.jfree.chart.util.RectangleInsets var30 = var28.getMargin();
    var18.setLegendItemGraphicPadding(var30);
    org.jfree.chart.LegendItemSource var32 = null;
    org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var32);
    org.jfree.chart.util.RectangleAnchor var34 = var33.getLegendItemGraphicLocation();
    var18.setLegendItemGraphicAnchor(var34);
    var1.setLegendItemGraphicLocation(var34);
    java.awt.Paint var37 = var1.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1, (-1.0d), 1.0f, 100.0f);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 0.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var4.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var7 = var4.getWidthConstraintType();
    org.jfree.data.Range var9 = null;
    org.jfree.data.Range var10 = null;
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var10, 0.0d);
    org.jfree.chart.block.RectangleConstraint var14 = var12.toFixedHeight(100.0d);
    org.jfree.chart.block.LengthConstraintType var15 = var12.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1, var7, 0.0d, var9, var15);
    java.lang.String var17 = var15.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var17.equals("RectangleConstraintType.RANGE"));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(104.0d);
    var1.setValue(104.0d);
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Color var8 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 100);
    var5.setPaint((java.awt.Paint)var8);
    var1.setLabelPaint((java.awt.Paint)var8);
    int var11 = var8.getGreen();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var1, 10.0f, 0.0f, 0.0d, 1.0f, 0.0f);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    var1.setRangeWithMargins(var5, true, false);
    boolean var9 = var1.isAutoTickUnitSelection();
    java.awt.Shape var15 = null;
    java.awt.Font var18 = null;
    java.awt.Color var22 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var24 = null;
    org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("", var18, (java.awt.Paint)var22, (-1.0f), var24);
    java.awt.Color var26 = var22.darker();
    java.awt.Color var31 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.lang.String var32 = var31.toString();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var35 = var34.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var38 = var37.getDefaultAutoRange();
    var34.setRangeWithMargins(var38, true, false);
    var34.setLowerMargin(104.0d);
    java.awt.Stroke var44 = var34.getTickMarkStroke();
    java.awt.Font var47 = null;
    java.awt.Color var51 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var53 = null;
    org.jfree.chart.text.TextBlock var54 = org.jfree.chart.text.TextUtilities.createTextBlock("", var47, (java.awt.Paint)var51, (-1.0f), var53);
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.text.TextBlockAnchor var58 = null;
    var54.draw(var55, 0.0f, 1.0f, var58);
    java.awt.Graphics2D var60 = null;
    org.jfree.chart.text.TextBlockAnchor var63 = null;
    java.awt.Shape var67 = var54.calculateBounds(var60, 10.0f, (-1.0f), var63, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var70 = var69.getLabelAnchor();
    java.awt.Stroke var71 = var69.getOutlineStroke();
    java.awt.Color var74 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var75 = var74.brighter();
    boolean var77 = var75.equals((java.lang.Object)253);
    org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("hi!", "Size2D[width=100.0, height=0.0]", "90,53,90,53,90,53,90,53,90,53,90,53", "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", false, var15, true, (java.awt.Paint)var22, false, (java.awt.Paint)var31, var44, false, var67, var71, (java.awt.Paint)var75);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDownArrow(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var32.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.calculateRightInset(100.0d);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var6 = new org.jfree.chart.block.BlockBorder(var2, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Shape var6 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var16 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var17 = var16.brighter();
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var17);
    boolean var19 = var9.equals((java.lang.Object)var17);
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var6, (java.awt.Paint)var17);
    java.lang.String var21 = var20.getLabel();
    java.lang.String var22 = var20.getLabel();
    java.lang.Comparable var23 = var20.getSeriesKey();
    int var24 = var20.getDatasetIndex();
    org.jfree.data.general.Dataset var25 = null;
    var20.setDataset(var25);
    boolean var27 = var20.isShapeVisible();
    boolean var28 = var1.equals((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var21.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var22.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }


    org.jfree.data.function.Function2D var0 = null;
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 10.0d, 10.0d, 100, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }


    java.lang.Number var0 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(var0, (java.lang.Number)100);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)100, "90,53,90,53,90,53,90,53,90,53,90,53 version java.awt.Color[r=255,g=253,b=100].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY 90,53,90,53,90,53,90,53,90,53,90,53:None\n90,53,90,53,90,53,90,53,90,53,90,53 LICENCE TERMS:\njava.awt.Color[r=255,g=253,b=100]", var2, var3, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var9 = null;
    java.awt.Color var13 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var15 = null;
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("", var9, (java.awt.Paint)var13, (-1.0f), var15);
    java.awt.Graphics2D var17 = null;
    org.jfree.chart.text.TextBlockAnchor var20 = null;
    var16.draw(var17, 0.0f, 1.0f, var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.text.TextBlockAnchor var25 = null;
    java.awt.Shape var29 = var16.calculateBounds(var22, 10.0f, (-1.0f), var25, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var29);
    org.jfree.chart.entity.LegendItemEntity var31 = new org.jfree.chart.entity.LegendItemEntity(var29);
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var29, 1.0d, 0.0f, 1.0f);
    org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var38 = var37.getLabelAnchor();
    java.awt.Stroke var39 = var37.getOutlineStroke();
    org.jfree.chart.LegendItemSource var40 = null;
    org.jfree.chart.title.LegendTitle var41 = new org.jfree.chart.title.LegendTitle(var40);
    org.jfree.chart.util.RectangleAnchor var42 = var41.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var43 = null;
    org.jfree.chart.util.VerticalAlignment var44 = null;
    org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 100.0d, 10.0d);
    boolean var49 = var47.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var50 = null;
    org.jfree.chart.title.LegendItemBlockContainer var52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var47, var50, (java.lang.Comparable)(short)10);
    java.lang.Object var53 = var52.clone();
    org.jfree.chart.util.RectangleInsets var54 = var52.getMargin();
    var41.setMargin(var54);
    org.jfree.chart.LegendItemSource var56 = null;
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var56);
    org.jfree.chart.util.RectangleAnchor var58 = var57.getLegendItemGraphicLocation();
    var41.setLegendItemGraphicLocation(var58);
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var61.configure();
    org.jfree.chart.axis.NumberAxis var64 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var65 = var64.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var68 = var67.getDefaultAutoRange();
    var64.setRangeWithMargins(var68, true, false);
    var61.setRangeWithMargins(var68, false, true);
    java.awt.Font var75 = var61.getTickLabelFont();
    boolean var76 = var58.equals((java.lang.Object)var61);
    java.awt.Paint var77 = var61.getTickLabelPaint();
    org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("RectangleConstraintType.RANGE", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", "[size=0]", var29, var39, var77);
    java.awt.Paint var79 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem(var0, "java.awt.Color[r=255,g=253,b=100]", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "org.jfree.chart.event.ChartChangeEvent[source=100]", var29, var79);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
//     org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
//     java.awt.Font var6 = null;
//     java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var12 = null;
//     org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
//     int var14 = var10.getGreen();
//     var3.setBackgroundPaint((java.awt.Paint)var10);
//     java.awt.Font var16 = var3.getItemFont();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var24 = var23.brighter();
//     org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
//     boolean var27 = var24.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16);
//     java.lang.String var31 = var30.getToolTipText();
//     java.awt.Font var32 = var30.getFont();
//     java.awt.Paint var33 = var30.getPaint();
//     var30.setID("");
//     java.lang.Object var36 = var30.clone();
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.util.Size2D var38 = var30.arrange(var37);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(104.0d);
    var1.setValue(104.0d);
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Color var8 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 100);
    var5.setPaint((java.awt.Paint)var8);
    var1.setLabelPaint((java.awt.Paint)var8);
    org.jfree.chart.event.MarkerChangeListener var11 = null;
    var1.removeChangeListener(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.lang.Number var3 = var2.getMean();
    java.lang.Number var4 = var2.getStandardDeviation();
    java.lang.Number var5 = var2.getStandardDeviation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (-1.0d)+ "'", var3.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.0f+ "'", var5.equals(0.0f));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    java.awt.Shape var4 = null;
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(-1.0d), (java.lang.Number)0.0f);
    java.awt.Color var14 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var15 = var14.brighter();
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var15);
    boolean var17 = var7.equals((java.lang.Object)var15);
    org.jfree.chart.LegendItem var18 = new org.jfree.chart.LegendItem("java.awt.Color[r=255,g=253,b=100]", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "90,53,90,53,90,53,90,53,90,53,90,53", var4, (java.awt.Paint)var15);
    java.lang.String var19 = var18.getLabel();
    java.lang.String var20 = var18.getLabel();
    java.lang.Comparable var21 = var18.getSeriesKey();
    java.awt.Paint var22 = var18.getLinePaint();
    int var23 = var18.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var19.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var20.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    float var2 = var1.getAlpha();
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelTextAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.8f);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)253, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var2, var3, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    java.awt.Shape var5 = null;
    java.awt.Font var8 = null;
    java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, (java.awt.Paint)var12, (-1.0f), var14);
    java.awt.Color var16 = var12.darker();
    java.awt.Color var21 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.lang.String var22 = var21.toString();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var25 = var24.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var28 = var27.getDefaultAutoRange();
    var24.setRangeWithMargins(var28, true, false);
    var24.setLowerMargin(104.0d);
    java.awt.Stroke var34 = var24.getTickMarkStroke();
    java.awt.Font var37 = null;
    java.awt.Color var41 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var43 = null;
    org.jfree.chart.text.TextBlock var44 = org.jfree.chart.text.TextUtilities.createTextBlock("", var37, (java.awt.Paint)var41, (-1.0f), var43);
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.text.TextBlockAnchor var48 = null;
    var44.draw(var45, 0.0f, 1.0f, var48);
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.text.TextBlockAnchor var53 = null;
    java.awt.Shape var57 = var44.calculateBounds(var50, 10.0f, (-1.0f), var53, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var60 = var59.getLabelAnchor();
    java.awt.Stroke var61 = var59.getOutlineStroke();
    java.awt.Color var64 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var65 = var64.brighter();
    boolean var67 = var65.equals((java.lang.Object)253);
    org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("hi!", "Size2D[width=100.0, height=0.0]", "90,53,90,53,90,53,90,53,90,53,90,53", "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", false, var5, true, (java.awt.Paint)var12, false, (java.awt.Paint)var21, var34, false, var57, var61, (java.awt.Paint)var65);
    org.jfree.data.category.CategoryDataset var71 = null;
    java.lang.Comparable var72 = null;
    java.lang.Comparable var73 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var74 = new org.jfree.chart.entity.CategoryItemEntity(var57, "org.jfree.chart.event.ChartChangeEvent[source=100]", "hi!", var71, var72, var73);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var22.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    double var4 = var2.extendWidth(1.0d);
    org.jfree.chart.axis.AxisState var6 = new org.jfree.chart.axis.AxisState(10.0d);
    boolean var7 = var2.equals((java.lang.Object)10.0d);
    org.jfree.chart.util.UnitType var8 = var2.getUnitType();
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "UnitType.ABSOLUTE"+ "'", var9.equals("UnitType.ABSOLUTE"));

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Shape var2 = var1.getDownArrow();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var4.setLowerMargin(104.0d);
    java.awt.Shape var14 = var4.getUpArrow();
    var1.setLeftArrow(var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleAnchor var18 = var17.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 100.0d, 10.0d);
    boolean var25 = var23.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var26 = null;
    org.jfree.chart.title.LegendItemBlockContainer var28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var23, var26, (java.lang.Comparable)(short)10);
    java.lang.Object var29 = var28.clone();
    org.jfree.chart.util.RectangleInsets var30 = var28.getMargin();
    var17.setMargin(var30);
    org.jfree.chart.event.TitleChangeListener var32 = null;
    var17.removeChangeListener(var32);
    org.jfree.chart.util.RectangleInsets var34 = var17.getMargin();
    var1.setTickLabelInsets(var34);
    var1.setLowerMargin((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
//     java.lang.String var3 = var2.toString();
//     org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)var3);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    java.lang.String var15 = var1.getID();
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleAnchor var18 = var17.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var19 = null;
    org.jfree.chart.util.VerticalAlignment var20 = null;
    org.jfree.chart.block.ColumnArrangement var23 = new org.jfree.chart.block.ColumnArrangement(var19, var20, 100.0d, 10.0d);
    boolean var25 = var23.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var26 = null;
    org.jfree.chart.title.LegendItemBlockContainer var28 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var23, var26, (java.lang.Comparable)(short)10);
    java.lang.Object var29 = var28.clone();
    org.jfree.chart.util.RectangleInsets var30 = var28.getMargin();
    var17.setMargin(var30);
    var1.setLegendItemGraphicPadding(var30);
    java.awt.Paint var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var34 = new org.jfree.chart.block.BlockBorder(var30, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.lang.Object var2 = null;
//     boolean var3 = var1.equals(var2);
//     org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var6 = var5.getLastTextFragment();
//     float var7 = var6.getBaselineOffset();
//     var1.addFragment(var6);
//     org.jfree.chart.text.TextFragment var9 = var1.getLastTextFragment();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.text.TextAnchor var13 = null;
//     var9.draw(var10, 1.0f, 1.0f, var13, 10.0f, 100.0f, (-1.0d));
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("90,53,90,53,90,53,90,53,90,53,90,53");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
//     org.jfree.chart.util.RectangleEdge var7 = var6.getPosition();
//     double var8 = var1.getCategoryEnd(1, 0, var4, var7);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("Size2D[width=100.0, height=0.0]", "", "RectangleConstraintType.RANGE", "10");

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    java.lang.String var13 = var11.toString();
    org.jfree.chart.JFreeChart var14 = null;
    org.jfree.chart.event.ChartProgressEvent var17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var13, var14, 100, 1);
    int var18 = var17.getType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 100);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var3, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    java.util.List var8 = var7.getContributors();
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var13.setInfo("");
    org.jfree.chart.ui.Library[] var16 = var13.getLibraries();
    boolean var17 = var7.equals((java.lang.Object)var13);
    java.lang.String var18 = var7.getLicenceName();
    java.lang.String var19 = var7.getLicenceText();
    var7.setVersion("10");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100.0]"+ "'", var18.equals("org.jfree.chart.event.ChartChangeEvent[source=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var19.equals("java.awt.Color[r=255,g=253,b=100]"));

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("RectangleConstraintType.RANGE");
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    java.lang.Object var36 = var30.draw(var33, var34, (java.lang.Object)(short)0);
    var30.setToolTipText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    java.lang.Object var39 = var30.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(100.0d);
    var1.setAlpha(0.0f);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }
// 
// 
//     java.awt.Color var6 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var7 = var6.brighter();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var8.draw(var9, var10);
// 
//   }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }
// 
// 
//     org.jfree.chart.LegendItemSource var4 = null;
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle(var4);
//     org.jfree.chart.util.RectangleAnchor var6 = var5.getLegendItemGraphicLocation();
//     java.awt.Font var8 = null;
//     java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var14 = null;
//     org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, (java.awt.Paint)var12, (-1.0f), var14);
//     int var16 = var12.getGreen();
//     var5.setBackgroundPaint((java.awt.Paint)var12);
//     java.awt.Font var18 = var5.getItemFont();
//     java.awt.Color var25 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var26 = var25.brighter();
//     org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var26);
//     boolean var29 = var26.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var18, (java.awt.Paint)var26, 0.0f);
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("", var18);
//     org.jfree.chart.text.TextLine var33 = new org.jfree.chart.text.TextLine("90,53,90,53,90,53,90,53,90,53,90,53 version java.awt.Color[r=255,g=253,b=100].\nhi!.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY 90,53,90,53,90,53,90,53,90,53,90,53:None\n90,53,90,53,90,53,90,53,90,53,90,53 LICENCE TERMS:\njava.awt.Color[r=255,g=253,b=100]", var18);
//     org.jfree.chart.LegendItemSource var34 = null;
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var34);
//     org.jfree.chart.util.RectangleAnchor var36 = var35.getLegendItemGraphicLocation();
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.ColumnArrangement var41 = new org.jfree.chart.block.ColumnArrangement(var37, var38, 100.0d, 10.0d);
//     boolean var43 = var41.equals((java.lang.Object)(short)(-1));
//     org.jfree.data.general.Dataset var44 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var46 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, var44, (java.lang.Comparable)(short)10);
//     java.lang.Object var47 = var46.clone();
//     org.jfree.chart.util.RectangleInsets var48 = var46.getMargin();
//     var35.setMargin(var48);
//     java.awt.Color var52 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
//     java.awt.color.ColorSpace var53 = var52.getColorSpace();
//     org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var48, (java.awt.Paint)var52);
//     java.lang.String var55 = var52.toString();
//     org.jfree.chart.text.TextMeasurer var58 = null;
//     org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraintType.RANGE", var18, (java.awt.Paint)var52, 0.0f, 1, var58);
// 
//   }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("90,53,90,53,90,53,90,53,90,53,90,53", "java.awt.Color[r=255,g=253,b=100]", "", var3, "hi!", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "java.awt.Color[r=255,g=253,b=100]");
    java.util.List var8 = var7.getContributors();
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    var13.setInfo("");
    org.jfree.chart.ui.Library[] var16 = var13.getLibraries();
    boolean var17 = var7.equals((java.lang.Object)var13);
    java.lang.String var18 = var7.getLicenceName();
    java.awt.Font var20 = null;
    java.awt.Color var24 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var26 = null;
    org.jfree.chart.text.TextBlock var27 = org.jfree.chart.text.TextUtilities.createTextBlock("", var20, (java.awt.Paint)var24, 1.0f, var26);
    java.util.List var28 = var27.getLines();
    var7.setContributors(var28);
    var7.setLicenceText("java.awt.Color[r=255,g=253,b=100]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100.0]"+ "'", var18.equals("org.jfree.chart.event.ChartChangeEvent[source=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Font var2 = var1.getTickLabelFont();
    var1.zoomRange(0.0d, 104.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
    boolean var9 = var7.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
    var1.setMargin(var14);
    java.awt.Color var18 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var19 = var18.getColorSpace();
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(var14, (java.awt.Paint)var18);
    double var22 = var14.calculateBottomOutset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.LegendItemSource[] var2 = var1.getSources();
    org.jfree.chart.util.RectangleEdge var3 = var1.getLegendItemGraphicEdge();
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getBackgroundPaint();
    org.jfree.chart.util.RectangleInsets var6 = var1.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 0);
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var1.draw(var2, var3);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    var1.setTickLabelPaint((java.awt.Paint)var4);
    var1.setUpperBound(0.0d);
    org.jfree.data.Range var9 = var1.getDefaultAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, (-1.0d), 1.0d, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", (-1));
    int var3 = var2.getRed();
    float[] var7 = new float[] { 100.0f, 1.0f, 1.0f};
    float[] var8 = var2.getColorComponents(var7);
    int var9 = var2.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 255);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.chart.event.AxisChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var1.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", var1);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.text.TextBlockAnchor var12 = null;
    var8.draw(var9, 0.0f, 1.0f, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.text.TextBlockAnchor var17 = null;
    java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
    org.jfree.chart.entity.LegendItemEntity var23 = new org.jfree.chart.entity.LegendItemEntity(var21);
    java.lang.String var24 = var23.toString();
    java.lang.Comparable var25 = var23.getSeriesKey();
    java.lang.String var26 = var23.getShapeType();
    java.lang.Object var27 = var23.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null"+ "'", var24.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "poly"+ "'", var26.equals("poly"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    double var6 = var5.getCentralValue();
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var5, 1.0d);
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "hi!", "");
    java.lang.String var14 = var13.getLicenceName();
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleInsets var17 = var16.getItemLabelPadding();
    double var19 = var17.extendHeight(100.0d);
    boolean var20 = var13.equals((java.lang.Object)100.0d);
    boolean var21 = var5.equals((java.lang.Object)100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 104.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }


    java.text.AttributedString var0 = null;
    java.awt.Font var5 = null;
    java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var11 = null;
    org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    var12.draw(var13, 0.0f, 1.0f, var16);
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    java.awt.Shape var25 = var12.calculateBounds(var18, 10.0f, (-1.0f), var21, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var26 = new org.jfree.chart.entity.ChartEntity(var25);
    org.jfree.chart.entity.LegendItemEntity var27 = new org.jfree.chart.entity.LegendItemEntity(var25);
    org.jfree.data.general.Dataset var28 = var27.getDataset();
    java.awt.Font var30 = null;
    java.awt.Color var34 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var36 = null;
    org.jfree.chart.text.TextBlock var37 = org.jfree.chart.text.TextUtilities.createTextBlock("", var30, (java.awt.Paint)var34, (-1.0f), var36);
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.text.TextBlockAnchor var41 = null;
    var37.draw(var38, 0.0f, 1.0f, var41);
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.text.TextBlockAnchor var46 = null;
    java.awt.Shape var50 = var37.calculateBounds(var43, 10.0f, (-1.0f), var46, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var51 = new org.jfree.chart.entity.ChartEntity(var50);
    var27.setArea(var50);
    java.awt.Font var54 = null;
    java.awt.Color var58 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var60 = null;
    org.jfree.chart.text.TextBlock var61 = org.jfree.chart.text.TextUtilities.createTextBlock("", var54, (java.awt.Paint)var58, (-1.0f), var60);
    java.awt.Color var62 = var58.darker();
    int var63 = var58.getTransparency();
    org.jfree.chart.plot.ValueMarker var65 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var66 = var65.getLabelAnchor();
    java.awt.Stroke var67 = var65.getOutlineStroke();
    org.jfree.chart.LegendItemSource var68 = null;
    org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle(var68);
    org.jfree.chart.util.RectangleInsets var70 = var69.getItemLabelPadding();
    double var72 = var70.extendWidth(1.0d);
    org.jfree.chart.block.LineBorder var73 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var58, var67, var70);
    java.awt.Color var76 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem(var0, "[size=0]", "", "RectangleConstraintType.RANGE", var50, var67, (java.awt.Paint)var76);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 5.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(104.0d);
    org.jfree.chart.event.MarkerChangeListener var2 = null;
    var1.removeChangeListener(var2);
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, 100.0d, 10.0d);
    boolean var9 = var7.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var10, (java.lang.Comparable)(short)10);
    java.lang.Object var13 = var12.clone();
    org.jfree.chart.util.RectangleInsets var14 = var12.getMargin();
    var1.setMargin(var14);
    org.jfree.chart.LegendItemSource var16 = null;
    org.jfree.chart.title.LegendTitle var17 = new org.jfree.chart.title.LegendTitle(var16);
    org.jfree.chart.util.RectangleAnchor var18 = var17.getLegendItemGraphicLocation();
    var1.setLegendItemGraphicLocation(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var21.configure();
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var25 = var24.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var28 = var27.getDefaultAutoRange();
    var24.setRangeWithMargins(var28, true, false);
    var21.setRangeWithMargins(var28, false, true);
    java.awt.Font var35 = var21.getTickLabelFont();
    boolean var36 = var18.equals((java.lang.Object)var21);
    java.awt.Paint var37 = var21.getTickLabelPaint();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var39.configure();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var43 = var42.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var46 = var45.getDefaultAutoRange();
    var42.setRangeWithMargins(var46, true, false);
    var39.setRangeWithMargins(var46, false, true);
    var21.setRange(var46, false, false);
    java.awt.Paint var56 = var21.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    java.lang.String var13 = var11.toString();
    double var14 = var11.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
//     org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
//     org.jfree.chart.LegendItemSource[] var3 = var1.getSources();
//     org.jfree.chart.block.BlockBorder var8 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, 100.0d, 100.0d);
//     var1.setFrame((org.jfree.chart.block.BlockFrame)var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var8.draw(var10, var11);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.title.LegendTitle var3 = new org.jfree.chart.title.LegendTitle(var2);
    org.jfree.chart.util.RectangleAnchor var4 = var3.getLegendItemGraphicLocation();
    java.awt.Font var6 = null;
    java.awt.Color var10 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var12 = null;
    org.jfree.chart.text.TextBlock var13 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, (java.awt.Paint)var10, (-1.0f), var12);
    int var14 = var10.getGreen();
    var3.setBackgroundPaint((java.awt.Paint)var10);
    java.awt.Font var16 = var3.getItemFont();
    java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var24 = var23.brighter();
    org.jfree.chart.block.BlockBorder var25 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var24);
    boolean var27 = var24.equals((java.lang.Object)(byte)10);
    org.jfree.chart.text.TextFragment var29 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var16, (java.awt.Paint)var24, 0.0f);
    org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle("", var16);
    var30.setToolTipText("RectangleConstraintType.RANGE");
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    java.lang.Object var36 = var30.draw(var33, var34, (java.lang.Object)(short)0);
    java.lang.String var37 = var30.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var37.equals("RectangleConstraintType.RANGE"));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, 100.0f, 0.0d, (-1.0f), 0.0f);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Font var2 = var1.getTickLabelFont();
    java.awt.Font var8 = null;
    java.awt.Color var12 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var14 = null;
    org.jfree.chart.text.TextBlock var15 = org.jfree.chart.text.TextUtilities.createTextBlock("", var8, (java.awt.Paint)var12, (-1.0f), var14);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    var15.draw(var16, 0.0f, 1.0f, var19);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.text.TextBlockAnchor var24 = null;
    java.awt.Shape var28 = var15.calculateBounds(var21, 10.0f, (-1.0f), var24, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.entity.ChartEntity var29 = new org.jfree.chart.entity.ChartEntity(var28);
    org.jfree.chart.entity.LegendItemEntity var30 = new org.jfree.chart.entity.LegendItemEntity(var28);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.rotateShape(var28, 1.0d, 0.0f, 1.0f);
    org.jfree.chart.plot.ValueMarker var36 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var37 = var36.getLabelAnchor();
    java.awt.Stroke var38 = var36.getOutlineStroke();
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.title.LegendTitle var40 = new org.jfree.chart.title.LegendTitle(var39);
    org.jfree.chart.util.RectangleAnchor var41 = var40.getLegendItemGraphicLocation();
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 100.0d, 10.0d);
    boolean var48 = var46.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var49 = null;
    org.jfree.chart.title.LegendItemBlockContainer var51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var46, var49, (java.lang.Comparable)(short)10);
    java.lang.Object var52 = var51.clone();
    org.jfree.chart.util.RectangleInsets var53 = var51.getMargin();
    var40.setMargin(var53);
    org.jfree.chart.LegendItemSource var55 = null;
    org.jfree.chart.title.LegendTitle var56 = new org.jfree.chart.title.LegendTitle(var55);
    org.jfree.chart.util.RectangleAnchor var57 = var56.getLegendItemGraphicLocation();
    var40.setLegendItemGraphicLocation(var57);
    org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var60.configure();
    org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var64 = var63.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var67 = var66.getDefaultAutoRange();
    var63.setRangeWithMargins(var67, true, false);
    var60.setRangeWithMargins(var67, false, true);
    java.awt.Font var74 = var60.getTickLabelFont();
    boolean var75 = var57.equals((java.lang.Object)var60);
    java.awt.Paint var76 = var60.getTickLabelPaint();
    org.jfree.chart.LegendItem var77 = new org.jfree.chart.LegendItem("RectangleConstraintType.RANGE", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "", "[size=0]", var28, var38, var76);
    var1.setAxisLinePaint(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(-1L), "org.jfree.chart.event.ChartChangeEvent[source=100]", var2, var3, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, (-1.0f), var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlockAnchor var12 = null;
//     var8.draw(var9, 0.0f, 1.0f, var12);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.text.TextBlockAnchor var17 = null;
//     java.awt.Shape var21 = var8.calculateBounds(var14, 10.0f, (-1.0f), var17, 0.0f, 100.0f, 1.0d);
//     org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var21);
//     org.jfree.chart.entity.LegendItemEntity var23 = new org.jfree.chart.entity.LegendItemEntity(var21);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.rotateShape(var21, 1.0d, 0.0f, 1.0f);
//     org.jfree.chart.entity.ChartEntity var28 = new org.jfree.chart.entity.ChartEntity(var21);
//     
//     // Checks the contract:  equals-hashcode on var22 and var28
//     assertTrue("Contract failed: equals-hashcode on var22 and var28", var22.equals(var28) ? var22.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var22
//     assertTrue("Contract failed: equals-hashcode on var28 and var22", var28.equals(var22) ? var28.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    org.jfree.data.Range var5 = var1.getDefaultAutoRange();
    double var6 = var5.getCentralValue();
    org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var5, 1.0d);
    boolean var11 = var8.intersects(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.5d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.ColumnArrangement var6 = new org.jfree.chart.block.ColumnArrangement(var2, var3, 100.0d, 10.0d);
    boolean var8 = var6.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var9, (java.lang.Comparable)(short)10);
    java.lang.Object var12 = var11.clone();
    org.jfree.chart.util.RectangleInsets var13 = var11.getMargin();
    var1.setLegendItemGraphicPadding(var13);
    org.jfree.chart.LegendItemSource var15 = null;
    org.jfree.chart.title.LegendTitle var16 = new org.jfree.chart.title.LegendTitle(var15);
    org.jfree.chart.util.RectangleAnchor var17 = var16.getLegendItemGraphicLocation();
    var1.setLegendItemGraphicAnchor(var17);
    java.awt.Color var21 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", (-1));
    boolean var22 = var17.equals((java.lang.Object)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Color var14 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
    java.awt.color.ColorSpace var15 = var14.getColorSpace();
    var11.setTickLabelPaint((java.awt.Paint)var14);
    boolean var17 = var4.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }
// 
// 
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.title.LegendTitle var2 = new org.jfree.chart.title.LegendTitle(var1);
//     org.jfree.chart.util.RectangleAnchor var3 = var2.getLegendItemGraphicLocation();
//     java.awt.Font var5 = null;
//     java.awt.Color var9 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var11 = null;
//     org.jfree.chart.text.TextBlock var12 = org.jfree.chart.text.TextUtilities.createTextBlock("", var5, (java.awt.Paint)var9, (-1.0f), var11);
//     int var13 = var9.getGreen();
//     var2.setBackgroundPaint((java.awt.Paint)var9);
//     java.awt.Font var15 = var2.getItemFont();
//     java.lang.String var16 = var2.getID();
//     java.awt.Font var17 = var2.getItemFont();
//     java.awt.Font var19 = null;
//     java.awt.Color var23 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var25 = null;
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23, (-1.0f), var25);
//     java.awt.Color var27 = var23.darker();
//     org.jfree.chart.text.TextMeasurer var29 = null;
//     org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartChangeEvent[source=100.0]", var17, (java.awt.Paint)var27, 1.0f, var29);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(100.0d, 10.0d);
    var2.setHeight(10.0d);
    var2.setHeight(0.0d);
    java.lang.String var7 = var2.toString();
    double var8 = var2.getWidth();
    double var9 = var2.getWidth();
    java.lang.Object var10 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "Size2D[width=100.0, height=0.0]"+ "'", var7.equals("Size2D[width=100.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    var1.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    var1.setRangeAboutValue(1.0d, 1.0d);
    java.lang.String var8 = var1.getLabelToolTip();
    var1.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }


    java.lang.Object var1 = null;
    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)(-1L), var1);
    java.lang.Object var3 = var2.getObject();
    java.lang.Comparable var4 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (-1L)+ "'", var4.equals((-1L)));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEventType var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100, var1, var2);
    org.jfree.chart.JFreeChart var4 = null;
    var3.setChart(var4);
    java.lang.Object var6 = var3.getSource();
    org.jfree.chart.event.ChartChangeEventType var7 = null;
    var3.setType(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=255,g=253,b=100]");
    java.awt.Shape var2 = var1.getDownArrow();
    java.lang.String var3 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }
// 
// 
//     org.jfree.chart.LegendItemSource var3 = null;
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
//     org.jfree.chart.util.RectangleAnchor var5 = var4.getLegendItemGraphicLocation();
//     java.awt.Font var7 = null;
//     java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var13 = null;
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11, (-1.0f), var13);
//     int var15 = var11.getGreen();
//     var4.setBackgroundPaint((java.awt.Paint)var11);
//     java.awt.Font var17 = var4.getItemFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var25);
//     boolean var28 = var25.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17, (java.awt.Paint)var25, 0.0f);
//     org.jfree.chart.block.LabelBlock var31 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17);
//     org.jfree.chart.plot.Plot var32 = null;
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=100.0, height=0.0]", var17, var32, false);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(0.0d, 0.0d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleInsets var2 = var1.getItemLabelPadding();
    org.jfree.chart.util.RectangleInsets var3 = var1.getLegendItemGraphicPadding();
    org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(100.0d);
    java.awt.Color var8 = java.awt.Color.getColor("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", 100);
    var5.setPaint((java.awt.Paint)var8);
    org.jfree.chart.LegendItemSource var10 = null;
    org.jfree.chart.title.LegendTitle var11 = new org.jfree.chart.title.LegendTitle(var10);
    org.jfree.chart.util.RectangleAnchor var12 = var11.getLegendItemGraphicLocation();
    java.awt.Font var14 = null;
    java.awt.Color var18 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var20 = null;
    org.jfree.chart.text.TextBlock var21 = org.jfree.chart.text.TextUtilities.createTextBlock("", var14, (java.awt.Paint)var18, (-1.0f), var20);
    int var22 = var18.getGreen();
    var11.setBackgroundPaint((java.awt.Paint)var18);
    java.awt.Font var24 = var11.getItemFont();
    java.lang.String var25 = var11.getID();
    org.jfree.chart.util.RectangleInsets var26 = var11.getItemLabelPadding();
    var5.setLabelOffset(var26);
    var1.setLegendItemGraphicPadding(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.title.LegendTitle var13 = new org.jfree.chart.title.LegendTitle(var12);
    org.jfree.chart.util.HorizontalAlignment var14 = var13.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 0.0d, (-1.0d));
    var9.setArrangement((org.jfree.chart.block.Arrangement)var18);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.util.Size2D var21 = var9.arrange(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    var1.configure();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var8 = var7.getDefaultAutoRange();
    var4.setRangeWithMargins(var8, true, false);
    var1.setRangeWithMargins(var8, false, true);
    java.awt.Shape var20 = null;
    java.awt.Font var23 = null;
    java.awt.Color var27 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var29 = null;
    org.jfree.chart.text.TextBlock var30 = org.jfree.chart.text.TextUtilities.createTextBlock("", var23, (java.awt.Paint)var27, (-1.0f), var29);
    java.awt.Color var31 = var27.darker();
    java.awt.Color var36 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    java.lang.String var37 = var36.toString();
    org.jfree.chart.axis.NumberAxis var39 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var40 = var39.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var42 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var43 = var42.getDefaultAutoRange();
    var39.setRangeWithMargins(var43, true, false);
    var39.setLowerMargin(104.0d);
    java.awt.Stroke var49 = var39.getTickMarkStroke();
    java.awt.Font var52 = null;
    java.awt.Color var56 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var58 = null;
    org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("", var52, (java.awt.Paint)var56, (-1.0f), var58);
    java.awt.Graphics2D var60 = null;
    org.jfree.chart.text.TextBlockAnchor var63 = null;
    var59.draw(var60, 0.0f, 1.0f, var63);
    java.awt.Graphics2D var65 = null;
    org.jfree.chart.text.TextBlockAnchor var68 = null;
    java.awt.Shape var72 = var59.calculateBounds(var65, 10.0f, (-1.0f), var68, 0.0f, 100.0f, 1.0d);
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(100.0d);
    org.jfree.chart.util.RectangleAnchor var75 = var74.getLabelAnchor();
    java.awt.Stroke var76 = var74.getOutlineStroke();
    java.awt.Color var79 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var80 = var79.brighter();
    boolean var82 = var80.equals((java.lang.Object)253);
    org.jfree.chart.LegendItem var83 = new org.jfree.chart.LegendItem("hi!", "Size2D[width=100.0, height=0.0]", "90,53,90,53,90,53,90,53,90,53,90,53", "1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", false, var20, true, (java.awt.Paint)var27, false, (java.awt.Paint)var36, var49, false, var72, var76, (java.awt.Paint)var80);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRightArrow(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "java.awt.Color[r=255,g=253,b=100]"+ "'", var37.equals("java.awt.Color[r=255,g=253,b=100]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }
// 
// 
//     org.jfree.chart.LegendItemSource var3 = null;
//     org.jfree.chart.title.LegendTitle var4 = new org.jfree.chart.title.LegendTitle(var3);
//     org.jfree.chart.util.RectangleAnchor var5 = var4.getLegendItemGraphicLocation();
//     java.awt.Font var7 = null;
//     java.awt.Color var11 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
//     org.jfree.chart.text.TextMeasurer var13 = null;
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("", var7, (java.awt.Paint)var11, (-1.0f), var13);
//     int var15 = var11.getGreen();
//     var4.setBackgroundPaint((java.awt.Paint)var11);
//     java.awt.Font var17 = var4.getItemFont();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", (-1));
//     java.awt.Color var25 = var24.brighter();
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(1.0d, 10.0d, 0.0d, 10.0d, (java.awt.Paint)var25);
//     boolean var28 = var25.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.text.TextFragment var30 = new org.jfree.chart.text.TextFragment("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17, (java.awt.Paint)var25, 0.0f);
//     org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var17);
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var17);
//     java.awt.Font var33 = var32.getFont();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     java.awt.Color var42 = java.awt.Color.getColor("hi!", (-1));
//     int var43 = var42.getRed();
//     float[] var47 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var48 = var42.getColorComponents(var47);
//     org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.0d, (java.awt.Paint)var42);
//     java.lang.Object var50 = var32.draw(var34, var35, (java.lang.Object)1.0d);
// 
//   }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     java.awt.Color var4 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100]", 0);
//     var1.setAxisLinePaint((java.awt.Paint)var4);
//     java.awt.Color var12 = java.awt.Color.getColor("hi!", (-1));
//     int var13 = var12.getRed();
//     float[] var17 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var18 = var12.getColorComponents(var17);
//     org.jfree.chart.block.BlockBorder var19 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.0d, (java.awt.Paint)var12);
//     java.awt.color.ColorSpace var20 = var12.getColorSpace();
//     java.awt.Color var23 = java.awt.Color.getColor("hi!", (-1));
//     int var24 = var23.getRed();
//     float[] var28 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var29 = var23.getColorComponents(var28);
//     float[] var30 = var4.getColorComponents(var20, var29);
//     java.awt.Color var33 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", 100);
//     java.awt.color.ColorSpace var34 = var33.getColorSpace();
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
//     java.awt.Color var39 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100]", 0);
//     var36.setAxisLinePaint((java.awt.Paint)var39);
//     java.awt.Color var47 = java.awt.Color.getColor("hi!", (-1));
//     int var48 = var47.getRed();
//     float[] var52 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var53 = var47.getColorComponents(var52);
//     org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(100.0d, 100.0d, 1.0d, 0.0d, (java.awt.Paint)var47);
//     java.awt.color.ColorSpace var55 = var47.getColorSpace();
//     java.awt.Color var58 = java.awt.Color.getColor("hi!", (-1));
//     int var59 = var58.getRed();
//     float[] var63 = new float[] { 100.0f, 1.0f, 1.0f};
//     float[] var64 = var58.getColorComponents(var63);
//     float[] var65 = var39.getColorComponents(var55, var64);
//     float[] var66 = var4.getColorComponents(var34, var64);
//     
//     // Checks the contract:  equals-hashcode on var19 and var54
//     assertTrue("Contract failed: equals-hashcode on var19 and var54", var19.equals(var54) ? var19.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var19
//     assertTrue("Contract failed: equals-hashcode on var54 and var19", var54.equals(var19) ? var54.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var2 = var1.getDefaultAutoRange();
    org.jfree.chart.axis.NumberAxis var4 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var5 = var4.getDefaultAutoRange();
    var1.setRangeWithMargins(var5, true, false);
    var1.setLowerMargin(104.0d);
    java.awt.Font var11 = var1.getLabelFont();
    org.jfree.chart.plot.Plot var12 = null;
    var1.setPlot(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.title.LegendTitle var1 = new org.jfree.chart.title.LegendTitle(var0);
    org.jfree.chart.util.RectangleAnchor var2 = var1.getLegendItemGraphicLocation();
    java.awt.Font var4 = null;
    java.awt.Color var8 = java.awt.Color.getHSBColor(1.0f, 100.0f, 1.0f);
    org.jfree.chart.text.TextMeasurer var10 = null;
    org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("", var4, (java.awt.Paint)var8, (-1.0f), var10);
    int var12 = var8.getGreen();
    var1.setBackgroundPaint((java.awt.Paint)var8);
    java.awt.Font var14 = var1.getItemFont();
    java.lang.String var15 = var1.getID();
    org.jfree.chart.util.RectangleInsets var16 = var1.getItemLabelPadding();
    double var17 = var16.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 253);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2.0d);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var13 = var11.trimHeight((-1.0d));
    double var15 = var11.calculateBottomInset(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("1,-1,-1,1,0,1,1,1,-1,-1,-1,0,-1,1,1,-1,0,-1,-1,-1,1,1,1,0,1,0", var1);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    java.awt.Paint var2 = var1.getAxisLinePaint();
    org.jfree.chart.axis.MarkerAxisBand var3 = null;
    var1.setMarkerBand(var3);
    var1.setRangeAboutValue(1.0d, 1.0d);
    java.awt.Font var8 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");
    java.lang.String var2 = var1.getID();
    java.awt.Color var5 = java.awt.Color.getColor("hi!", (-1));
    java.awt.Color var6 = var5.brighter();
    boolean var7 = var1.equals((java.lang.Object)var5);
    org.jfree.chart.LegendItemSource var8 = null;
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle(var8);
    org.jfree.chart.util.RectangleAnchor var10 = var9.getLegendItemGraphicLocation();
    org.jfree.chart.LegendItemSource[] var11 = var9.getSources();
    boolean var12 = var1.equals((java.lang.Object)var9);
    org.jfree.chart.LegendItemSource var13 = null;
    org.jfree.chart.title.LegendTitle var14 = new org.jfree.chart.title.LegendTitle(var13);
    org.jfree.chart.util.RectangleAnchor var15 = var14.getLegendItemGraphicLocation();
    org.jfree.chart.LegendItemSource[] var16 = var14.getSources();
    org.jfree.chart.util.HorizontalAlignment var17 = var14.getHorizontalAlignment();
    double var18 = var14.getHeight();
    double var19 = var14.getHeight();
    boolean var20 = var1.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "hi!"+ "'", var2.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    int var2 = var1.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 100.0d, 10.0d);
    boolean var6 = var4.equals((java.lang.Object)(short)(-1));
    org.jfree.data.general.Dataset var7 = null;
    org.jfree.chart.title.LegendItemBlockContainer var9 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var7, (java.lang.Comparable)(short)10);
    java.lang.Object var10 = var9.clone();
    org.jfree.chart.util.RectangleInsets var11 = var9.getMargin();
    double var12 = var11.getRight();
    java.lang.String var13 = var11.toString();
    org.jfree.chart.JFreeChart var14 = null;
    org.jfree.chart.event.ChartProgressEvent var17 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var13, var14, 100, 1);
    org.jfree.chart.JFreeChart var18 = var17.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"+ "'", var13.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.axis.NumberAxis var2 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=100.0]");
    org.jfree.data.Range var3 = var2.getDefaultAutoRange();
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var0, var3);
    double var5 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

}
