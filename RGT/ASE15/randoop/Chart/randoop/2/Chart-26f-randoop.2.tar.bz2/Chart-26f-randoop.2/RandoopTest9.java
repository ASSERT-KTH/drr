
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var2.valueToJava2D(1.0d, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     var2.setPlot((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
//     var22.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var22.valueToJava2D(1.0d, var26, var27);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.axis.AxisState var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     var35.handleClick(10, 0, var38);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearRangeMarkers(1);
    org.jfree.chart.util.RectangleEdge var7 = var4.getDomainAxisEdge();
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    var4.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
    int var9 = var4.getIndexOf(var8);
    java.awt.Stroke var10 = var4.getDomainGridlineStroke();
    var4.setAnchorValue(10.0d, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var3, var10);
    org.jfree.data.general.Dataset var12 = var11.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var45);
    org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
    var35.setRangeGridlinePaint((java.awt.Paint)var45);
    java.lang.Object var49 = null;
    boolean var50 = var35.equals(var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var35.setFixedDomainAxisSpace(var51);
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("hi!");
    var54.setAxisLineVisible(false);
    org.jfree.data.Range var57 = var35.getDataRange((org.jfree.chart.axis.ValueAxis)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0.0d, "hi!", var2, var3, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.chart.plot.CategoryMarker var1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)1.0f);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var45);
    org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
    var35.setRangeGridlinePaint((java.awt.Paint)var45);
    java.lang.Object var49 = null;
    boolean var50 = var35.equals(var49);
    org.jfree.data.category.CategoryDataset var52 = null;
    org.jfree.chart.axis.CategoryAxis var53 = null;
    org.jfree.chart.axis.ValueAxis var54 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
    int var57 = var56.getDomainAxisCount();
    var56.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    int var61 = var56.getIndexOf(var60);
    org.jfree.chart.axis.AxisLocation var62 = var56.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var35.setDomainAxisLocation((-459), var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    var3.setAdjustForDaylightSaving(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     var5.clearRangeMarkers(1);
//     float var8 = var5.getForegroundAlpha();
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
//     var5.setBackgroundImageAlignment(0);
//     org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
//     var14.setAntiAlias(false);
//     org.jfree.chart.ChartRenderingInfo var19 = null;
//     var14.handleClick(1, 0, var19);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    double var5 = var4.getAnchorValue();
    double var6 = var4.getRangeCrosshairValue();
    var4.mapDatasetToRangeAxis(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.clearRangeMarkers(1);
    float var8 = var5.getForegroundAlpha();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
    var5.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    var14.setBackgroundImageAlignment(10);
    org.jfree.chart.title.Title var17 = null;
    var14.removeSubtitle(var17);
    var14.setNotify(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     int var5 = var4.getDomainAxisCount();
//     org.jfree.chart.event.PlotChangeListener var6 = null;
//     var4.removeChangeListener(var6);
//     org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var17);
//     var8.setItemPaint((java.awt.Paint)var17);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     var25.clearRangeMarkers(1);
//     float var28 = var25.getForegroundAlpha();
//     org.jfree.chart.util.Layer var30 = null;
//     java.util.Collection var31 = var25.getRangeMarkers((-1), var30);
//     var25.setBackgroundImageAlignment(0);
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var25);
//     var34.setAntiAlias(false);
//     var8.addChangeListener((org.jfree.chart.event.TitleChangeListener)var34);
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.DateAxis var40 = new org.jfree.chart.axis.DateAxis("hi!");
//     var40.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var40.valueToJava2D(1.0d, var44, var45);
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.axis.AxisState var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     java.util.List var51 = var40.refreshTicks(var47, var48, var49, var50);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var52, var53, var54, var55);
//     double var57 = var56.getAnchorValue();
//     var40.setPlot((org.jfree.chart.plot.Plot)var56);
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("hi!");
//     var60.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var64 = null;
//     org.jfree.chart.util.RectangleEdge var65 = null;
//     double var66 = var60.valueToJava2D(1.0d, var64, var65);
//     java.awt.Graphics2D var67 = null;
//     org.jfree.chart.axis.AxisState var68 = null;
//     java.awt.geom.Rectangle2D var69 = null;
//     org.jfree.chart.util.RectangleEdge var70 = null;
//     java.util.List var71 = var60.refreshTicks(var67, var68, var69, var70);
//     org.jfree.chart.renderer.xy.XYItemRenderer var72 = null;
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var40, (org.jfree.chart.axis.ValueAxis)var60, var72);
//     java.awt.Stroke var74 = var73.getRangeCrosshairStroke();
//     boolean var75 = var34.equals((java.lang.Object)var73);
//     
//     // Checks the contract:  equals-hashcode on var4 and var56
//     assertTrue("Contract failed: equals-hashcode on var4 and var56", var4.equals(var56) ? var4.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var4
//     assertTrue("Contract failed: equals-hashcode on var56 and var4", var56.equals(var4) ? var56.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearRangeMarkers(1);
    java.awt.Paint var7 = var4.getDomainGridlinePaint();
    org.jfree.chart.util.RectangleInsets var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setInsets(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 100.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-668));

  }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
//     org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var2, 1.0d, 1.0f, 0.0f);
// 
//   }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var2.valueToJava2D(1.0d, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     var2.setPlot((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
//     var22.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var22.valueToJava2D(1.0d, var26, var27);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.axis.AxisState var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
//     double var36 = var35.getDomainCrosshairValue();
//     boolean var37 = var35.isRangeGridlinesVisible();
//     java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var45);
//     org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
//     var35.setRangeGridlinePaint((java.awt.Paint)var45);
//     java.lang.Object var49 = null;
//     boolean var50 = var35.equals(var49);
//     java.awt.Shape var55 = null;
//     java.awt.Color var63 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var64 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var63);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var55, (java.awt.Paint)var63);
//     java.lang.String var66 = var65.getURLText();
//     boolean var67 = var65.isShapeVisible();
//     java.awt.Paint var68 = var65.getFillPaint();
//     java.awt.Paint var69 = var65.getFillPaint();
//     var35.setDomainZeroBaselinePaint(var69);
//     
//     // Checks the contract:  equals-hashcode on var46 and var64
//     assertTrue("Contract failed: equals-hashcode on var46 and var64", var46.equals(var64) ? var46.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var46
//     assertTrue("Contract failed: equals-hashcode on var64 and var46", var64.equals(var46) ? var64.hashCode() == var46.hashCode() : true);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.centerRange((-1.0d));
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("hi!");
    var5.setAxisLineVisible(false);
    var5.setLowerMargin(0.0d);
    var5.centerRange(1.0d);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    org.jfree.chart.entity.TickLabelEntity var16 = new org.jfree.chart.entity.TickLabelEntity(var13, "", "hi!");
    var5.setUpArrow(var13);
    var1.setDownArrow(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var17);
    var8.setItemPaint((java.awt.Paint)var17);
    boolean var21 = var8.equals((java.lang.Object)"#030303");
    java.lang.Object var22 = var8.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    long var10 = var7.getSegmentsExcludedSize();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var11, 13, 10);
    var7.addException(0L, 10L);
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var19.valueToJava2D(1.0d, var23, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var19.refreshTicks(var26, var27, var28, var29);
    java.util.Date var31 = var19.getMinimumDate();
    long var32 = var7.getTime(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0L);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.clearRangeMarkers(1);
    float var8 = var5.getForegroundAlpha();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
    var5.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    var14.setBackgroundImageAlignment(10);
    java.lang.Object var17 = var14.getTextAntiAlias();
    var14.setBackgroundImageAlpha(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.centerRange((-1.0d));
    java.text.DateFormat var4 = var1.getDateFormatOverride();
    var1.setLowerBound((-3.1536E10d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var1.refreshTicks(var8, var9, var10, var11);
    org.jfree.data.Range var13 = var1.getRange();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var15.valueToJava2D(1.0d, var19, var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.AxisState var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    java.util.List var26 = var15.refreshTicks(var22, var23, var24, var25);
    org.jfree.data.Range var27 = var15.getRange();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var13, var27);
    boolean var30 = var27.contains(0.0d);
    double var31 = var27.getLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    java.util.List var8 = var4.getAnnotations();
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 100.0d, 0.0d);
    double var14 = var13.getRight();
    boolean var15 = var4.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.clearRangeMarkers(1);
    float var8 = var5.getForegroundAlpha();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
    var5.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    var14.setBackgroundImageAlignment(10);
    java.lang.Object var17 = var14.getTextAntiAlias();
    boolean var19 = var14.equals((java.lang.Object)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     int var5 = var4.getDomainAxisCount();
//     org.jfree.chart.event.AxisChangeEvent var6 = null;
//     var4.axisChanged(var6);
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("hi!");
//     var10.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.valueToJava2D(1.0d, var14, var15);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.axis.AxisState var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     java.util.List var21 = var10.refreshTicks(var17, var18, var19, var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     double var27 = var26.getAnchorValue();
//     var10.setPlot((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("hi!");
//     var30.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var30.valueToJava2D(1.0d, var34, var35);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.axis.AxisState var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     java.util.List var41 = var30.refreshTicks(var37, var38, var39, var40);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var30, var42);
//     java.awt.Stroke var44 = var43.getRangeCrosshairStroke();
//     var4.setRangeGridlineStroke(var44);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.Range var14 = var2.getRange();
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    var16.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var16.valueToJava2D(1.0d, var20, var21);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.axis.AxisState var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    java.util.List var27 = var16.refreshTicks(var23, var24, var25, var26);
    org.jfree.data.Range var28 = var16.getRange();
    org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(var14, var28);
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    org.jfree.chart.ChartRenderingInfo var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
    java.awt.geom.Point2D var40 = null;
    var35.zoomDomainAxes(10.0d, var39, var40);
    org.jfree.chart.event.MarkerChangeEvent var42 = null;
    var35.markerChanged(var42);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
    int var49 = var48.getDomainAxisCount();
    var48.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    int var53 = var48.getIndexOf(var52);
    org.jfree.chart.axis.AxisLocation var54 = var48.getDomainAxisLocation();
    var35.setDomainAxisLocation(var54, false);
    org.jfree.chart.axis.SegmentedTimeline var60 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var64 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var65 = var64.getAdjustForDaylightSaving();
    var60.setBaseTimeline(var64);
    org.jfree.data.general.Dataset var67 = null;
    org.jfree.data.general.DatasetChangeEvent var68 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var60, var67);
    var35.datasetChanged(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    var4.setBackgroundImageAlpha(1.0f);
    var4.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var45);
    org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
    var35.setRangeGridlinePaint((java.awt.Paint)var45);
    org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("hi!");
    var51.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var51.valueToJava2D(1.0d, var55, var56);
    java.awt.Graphics2D var58 = null;
    org.jfree.chart.axis.AxisState var59 = null;
    java.awt.geom.Rectangle2D var60 = null;
    org.jfree.chart.util.RectangleEdge var61 = null;
    java.util.List var62 = var51.refreshTicks(var58, var59, var60, var61);
    org.jfree.data.category.CategoryDataset var63 = null;
    org.jfree.chart.axis.CategoryAxis var64 = null;
    org.jfree.chart.axis.ValueAxis var65 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var63, var64, var65, var66);
    double var68 = var67.getAnchorValue();
    var51.setPlot((org.jfree.chart.plot.Plot)var67);
    boolean var70 = var51.isVerticalTickLabels();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var35.setDomainAxis((-435), (org.jfree.chart.axis.ValueAxis)var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearRangeMarkers(1);
    float var7 = var4.getForegroundAlpha();
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var4.getRangeMarkers((-1), var9);
    boolean var11 = var4.isDomainGridlinesVisible();
    org.jfree.chart.axis.SegmentedTimeline var15 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var19 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var20 = var19.getAdjustForDaylightSaving();
    var15.setBaseTimeline(var19);
    long var22 = var19.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var24 = var19.getSegment(100L);
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.awt.Color var29 = var28.brighter();
    java.lang.String var30 = org.jfree.chart.util.PaintUtilities.colorToString(var29);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("hi!");
    var32.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var32.valueToJava2D(1.0d, var36, var37);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.axis.AxisState var40 = null;
    java.awt.geom.Rectangle2D var41 = null;
    org.jfree.chart.util.RectangleEdge var42 = null;
    java.util.List var43 = var32.refreshTicks(var39, var40, var41, var42);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
    double var49 = var48.getAnchorValue();
    var32.setPlot((org.jfree.chart.plot.Plot)var48);
    java.awt.Stroke var51 = var48.getDomainGridlineStroke();
    org.jfree.chart.plot.CategoryMarker var52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var24, (java.awt.Paint)var29, var51);
    var4.addRangeMarker((org.jfree.chart.plot.Marker)var52);
    org.jfree.chart.event.MarkerChangeEvent var54 = null;
    var52.notifyListeners(var54);
    java.awt.Stroke var56 = var52.getOutlineStroke();
    org.jfree.chart.event.MarkerChangeEvent var57 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "#030303"+ "'", var30.equals("#030303"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var18 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var17);
    var8.setItemPaint((java.awt.Paint)var17);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    var25.clearRangeMarkers(1);
    float var28 = var25.getForegroundAlpha();
    org.jfree.chart.util.Layer var30 = null;
    java.util.Collection var31 = var25.getRangeMarkers((-1), var30);
    var25.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var25);
    var34.setAntiAlias(false);
    var8.addChangeListener((org.jfree.chart.event.TitleChangeListener)var34);
    var8.setPadding((-1.0d), (-3.1536E10d), 0.0d, 10.0d);
    org.jfree.chart.util.RectangleAnchor var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setLegendItemGraphicAnchor(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var1.refreshTicks(var8, var9, var10, var11);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    double var18 = var17.getAnchorValue();
    var1.setPlot((org.jfree.chart.plot.Plot)var17);
    boolean var20 = var1.isVerticalTickLabels();
    var1.setInverted(false);
    var1.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    org.jfree.chart.event.AxisChangeEvent var8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    java.text.DateFormat var9 = var1.getDateFormatOverride();
    boolean var10 = var1.isAutoTickUnitSelection();
    java.awt.Paint var11 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    long var10 = var7.getSegmentsExcludedSize();
    org.jfree.chart.JFreeChart var11 = null;
    org.jfree.chart.event.ChartProgressEvent var14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var7, var11, 13, 10);
    var7.addException(0L, 10L);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    int var23 = var22.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var24 = null;
    var22.removeChangeListener(var24);
    java.util.List var26 = var22.getAnnotations();
    var7.addExceptions(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    java.awt.Stroke var36 = var35.getRangeCrosshairStroke();
    org.jfree.chart.util.Layer var37 = null;
    java.util.Collection var38 = var35.getDomainMarkers(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    org.jfree.chart.event.AxisChangeEvent var8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    var1.setTickLabelsVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    long var10 = var7.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var12 = var7.getSegment(100L);
    int var13 = var7.getSegmentsExcluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 13);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var45);
    org.jfree.chart.block.BlockBorder var47 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var45);
    var35.setRangeGridlinePaint((java.awt.Paint)var45);
    java.lang.Object var49 = null;
    boolean var50 = var35.equals(var49);
    org.jfree.chart.axis.AxisSpace var51 = null;
    var35.setFixedDomainAxisSpace(var51);
    org.jfree.chart.plot.DatasetRenderingOrder var53 = var35.getDatasetRenderingOrder();
    org.jfree.chart.util.RectangleEdge var54 = var35.getRangeAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("#030303", var1, (-1.0f), 1.0f, var4, 10.0d, var6);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     var4.clearRangeMarkers(1);
//     org.jfree.chart.axis.SegmentedTimeline var10 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
//     org.jfree.chart.axis.SegmentedTimeline var14 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
//     boolean var15 = var14.getAdjustForDaylightSaving();
//     var10.setBaseTimeline(var14);
//     long var17 = var14.getSegmentsExcludedSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var19 = var14.getSegment(100L);
//     java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     java.awt.Color var24 = var23.brighter();
//     java.lang.String var25 = org.jfree.chart.util.PaintUtilities.colorToString(var24);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("hi!");
//     var27.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var27.valueToJava2D(1.0d, var31, var32);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.axis.AxisState var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     java.util.List var38 = var27.refreshTicks(var34, var35, var36, var37);
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var39, var40, var41, var42);
//     double var44 = var43.getAnchorValue();
//     var27.setPlot((org.jfree.chart.plot.Plot)var43);
//     java.awt.Stroke var46 = var43.getDomainGridlineStroke();
//     org.jfree.chart.plot.CategoryMarker var47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var19, (java.awt.Paint)var24, var46);
//     var4.addDomainMarker(var47);
//     
//     // Checks the contract:  equals-hashcode on var4 and var43
//     assertTrue("Contract failed: equals-hashcode on var4 and var43", var4.equals(var43) ? var4.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var4
//     assertTrue("Contract failed: equals-hashcode on var43 and var4", var43.equals(var4) ? var43.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    java.util.List var8 = var4.getAnnotations();
    org.jfree.chart.plot.Plot var9 = var4.getRootPlot();
    org.jfree.chart.event.PlotChangeEvent var10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var4);
    org.jfree.chart.plot.Plot var11 = var10.getPlot();
    org.jfree.chart.plot.Plot var12 = var10.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.AxisChangeEvent var6 = null;
    var4.axisChanged(var6);
    org.jfree.chart.util.RectangleInsets var12 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 100.0d, 0.0d);
    double var13 = var12.getTop();
    var4.setAxisOffset(var12);
    java.awt.Shape var19 = null;
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var27);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var19, (java.awt.Paint)var27);
    java.lang.String var30 = var29.getURLText();
    boolean var31 = var29.isShapeVisible();
    java.awt.Paint var32 = var29.getFillPaint();
    java.awt.Paint var33 = var29.getFillPaint();
    var4.setNoDataMessagePaint(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "hi!"+ "'", var30.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
//     var2.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleEdge var7 = null;
//     double var8 = var2.valueToJava2D(1.0d, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     double var19 = var18.getAnchorValue();
//     var2.setPlot((org.jfree.chart.plot.Plot)var18);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
//     var22.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var22.valueToJava2D(1.0d, var26, var27);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.axis.AxisState var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
//     org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
//     double var36 = var35.getDomainCrosshairValue();
//     boolean var37 = var35.isRangeGridlinesVisible();
//     org.jfree.chart.axis.SegmentedTimeline var41 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
//     org.jfree.chart.axis.SegmentedTimeline var45 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
//     boolean var46 = var45.getAdjustForDaylightSaving();
//     var41.setBaseTimeline(var45);
//     long var48 = var45.getSegmentsExcludedSize();
//     org.jfree.chart.axis.SegmentedTimeline.Segment var50 = var45.getSegment(100L);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     java.awt.Color var55 = var54.brighter();
//     java.lang.String var56 = org.jfree.chart.util.PaintUtilities.colorToString(var55);
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("hi!");
//     var58.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var58.valueToJava2D(1.0d, var62, var63);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.axis.AxisState var66 = null;
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.util.RectangleEdge var68 = null;
//     java.util.List var69 = var58.refreshTicks(var65, var66, var67, var68);
//     org.jfree.data.category.CategoryDataset var70 = null;
//     org.jfree.chart.axis.CategoryAxis var71 = null;
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var73 = null;
//     org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var70, var71, var72, var73);
//     double var75 = var74.getAnchorValue();
//     var58.setPlot((org.jfree.chart.plot.Plot)var74);
//     java.awt.Stroke var77 = var74.getDomainGridlineStroke();
//     org.jfree.chart.plot.CategoryMarker var78 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var50, (java.awt.Paint)var55, var77);
//     var35.setRangeZeroBaselinePaint((java.awt.Paint)var55);
//     
//     // Checks the contract:  equals-hashcode on var18 and var74
//     assertTrue("Contract failed: equals-hashcode on var18 and var74", var18.equals(var74) ? var18.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var18
//     assertTrue("Contract failed: equals-hashcode on var74 and var18", var74.equals(var18) ? var74.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    int var6 = var5.getDomainAxisCount();
    var5.setBackgroundImageAlpha(1.0f);
    java.awt.Paint var9 = var5.getBackgroundPaint();
    double var10 = var5.getAnchorValue();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    var11.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    var4.setOutlineVisible(true);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    java.util.List var11 = var4.getCategoriesForAxis(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    java.text.DateFormat var3 = var1.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var3, var10);
    var3.addBaseTimelineException(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 100.0d, 0.0d);
    double var5 = var4.getRight();
    double var6 = var4.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.Comparable var3 = var2.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleInsets[t=0.0,l=-1.0,b=100.0,r=0.0]");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    java.text.DateFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(10, 0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    var8.clearRangeMarkers(1);
    float var11 = var8.getForegroundAlpha();
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var8.getRangeMarkers((-1), var13);
    var8.setBackgroundImageAlignment(0);
    boolean var17 = var8.isDomainGridlinesVisible();
    org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("hi!");
    var19.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var19.valueToJava2D(1.0d, var23, var24);
    java.awt.Graphics2D var26 = null;
    org.jfree.chart.axis.AxisState var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    java.util.List var30 = var19.refreshTicks(var26, var27, var28, var29);
    org.jfree.data.Range var31 = var19.getRange();
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("hi!");
    var33.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var33.valueToJava2D(1.0d, var37, var38);
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.axis.AxisState var41 = null;
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    java.util.List var44 = var33.refreshTicks(var40, var41, var42, var43);
    org.jfree.data.Range var45 = var33.getRange();
    org.jfree.chart.block.RectangleConstraint var46 = new org.jfree.chart.block.RectangleConstraint(var31, var45);
    boolean var47 = var8.equals((java.lang.Object)var45);
    boolean var48 = var3.equals((java.lang.Object)var8);
    org.jfree.chart.axis.AxisLocation var50 = var8.getDomainAxisLocation((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }
// 
// 
//     java.awt.Shape var4 = null;
//     java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var12);
//     org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var4, (java.awt.Paint)var12);
//     java.lang.String var15 = var14.getDescription();
//     java.lang.String var16 = var14.getURLText();
//     java.lang.String var17 = var14.getURLText();
//     java.awt.Shape var18 = var14.getLine();
//     org.jfree.chart.entity.TickLabelEntity var21 = new org.jfree.chart.entity.TickLabelEntity(var18, "", "");
//     java.awt.Shape var26 = null;
//     java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var34);
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var26, (java.awt.Paint)var34);
//     org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var18, (java.awt.Paint)var34);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var13
//     assertTrue("Contract failed: equals-hashcode on var35 and var13", var35.equals(var13) ? var35.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var36
//     assertTrue("Contract failed: equals-hashcode on var14 and var36", var14.equals(var36) ? var14.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var14
//     assertTrue("Contract failed: equals-hashcode on var36 and var14", var36.equals(var14) ? var36.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.clearRangeMarkers(1);
    float var8 = var5.getForegroundAlpha();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
    var5.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("hi!");
    var16.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var16.valueToJava2D(1.0d, var20, var21);
    java.awt.Graphics2D var23 = null;
    org.jfree.chart.axis.AxisState var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    java.util.List var27 = var16.refreshTicks(var23, var24, var25, var26);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var28, var29, var30, var31);
    double var33 = var32.getAnchorValue();
    var16.setPlot((org.jfree.chart.plot.Plot)var32);
    boolean var35 = var16.isTickMarksVisible();
    var5.setRangeAxis((org.jfree.chart.axis.ValueAxis)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    org.jfree.chart.entity.LegendItemEntity var2 = new org.jfree.chart.entity.LegendItemEntity(var1);
    java.lang.Object var3 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 100.0d, 0.0d);
    double var43 = var42.getLeft();
    java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.awt.Color var48 = var47.brighter();
    org.jfree.chart.block.BlockBorder var49 = new org.jfree.chart.block.BlockBorder(var42, (java.awt.Paint)var47);
    var35.setRangeTickBandPaint((java.awt.Paint)var47);
    java.io.ObjectOutputStream var51 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint)var47, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    int var5 = var4.getDomainAxisCount();
    org.jfree.chart.event.PlotChangeListener var6 = null;
    var4.removeChangeListener(var6);
    org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    int var14 = var13.getDomainAxisCount();
    org.jfree.chart.event.AxisChangeEvent var15 = null;
    var13.axisChanged(var15);
    org.jfree.chart.util.RectangleInsets var21 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 100.0d, 0.0d);
    double var22 = var21.getTop();
    var13.setAxisOffset(var21);
    var8.setItemLabelPadding(var21);
    double var25 = var8.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    java.awt.Shape var4 = null;
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var4, (java.awt.Paint)var12);
    java.lang.String var15 = var14.getURLText();
    boolean var16 = var14.isShapeVisible();
    boolean var17 = var14.isLineVisible();
    org.jfree.data.general.Dataset var18 = null;
    var14.setDataset(var18);
    var14.setDatasetIndex(0);
    boolean var22 = var14.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "hi!"+ "'", var15.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "", "");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "", "", "", "");
    var5.addLibrary((org.jfree.chart.ui.Library)var11);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    org.jfree.chart.axis.TickUnitSource var2 = var1.getStandardTickUnits();
    boolean var3 = var1.isPositiveArrowVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    org.jfree.chart.ChartRenderingInfo var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = new org.jfree.chart.plot.PlotRenderingInfo(var38);
    java.awt.geom.Point2D var40 = null;
    var35.zoomDomainAxes(10.0d, var39, var40);
    org.jfree.chart.event.MarkerChangeEvent var42 = null;
    var35.markerChanged(var42);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
    int var49 = var48.getDomainAxisCount();
    var48.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    int var53 = var48.getIndexOf(var52);
    org.jfree.chart.axis.AxisLocation var54 = var48.getDomainAxisLocation();
    var35.setDomainAxisLocation(var54, false);
    org.jfree.chart.renderer.xy.XYItemRenderer var57 = null;
    var35.setRenderer(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, 10.0d);
    double var3 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(0, (-1), var2);
//     int var4 = var3.getCalendarField();
//     int var6 = var3.compareTo((java.lang.Object)false);
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
//     var9.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var9.valueToJava2D(1.0d, var13, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.AxisState var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     java.util.List var20 = var9.refreshTicks(var16, var17, var18, var19);
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     double var26 = var25.getAnchorValue();
//     var9.setPlot((org.jfree.chart.plot.Plot)var25);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
//     var29.setAxisLineVisible(false);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var29.valueToJava2D(1.0d, var33, var34);
//     java.awt.Graphics2D var36 = null;
//     org.jfree.chart.axis.AxisState var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     java.util.List var40 = var29.refreshTicks(var36, var37, var38, var39);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var29, var41);
//     java.awt.Stroke var43 = var42.getRangeCrosshairStroke();
//     boolean var44 = var3.equals((java.lang.Object)var42);
//     java.lang.String var46 = var3.valueToString(1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var46 + "' != '" + "12/31/69"+ "'", var46.equals("12/31/69"));
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.clearRangeMarkers(1);
    float var8 = var5.getForegroundAlpha();
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var5.getRangeMarkers((-1), var10);
    var5.setBackgroundImageAlignment(0);
    org.jfree.chart.JFreeChart var14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var5);
    var14.setBackgroundImageAlignment(10);
    org.jfree.chart.util.RectangleInsets var17 = var14.getPadding();
    org.jfree.chart.event.ChartChangeListener var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.addChangeListener(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    java.awt.Shape var14 = var2.getDownArrow();
    org.jfree.data.KeyedObject var15 = new org.jfree.data.KeyedObject((java.lang.Comparable)(byte)(-1), (java.lang.Object)var2);
    java.awt.Font var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelFont(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var1.refreshTicks(var8, var9, var10, var11);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    int var18 = var17.getDomainAxisCount();
    var17.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    int var22 = var17.getIndexOf(var21);
    org.jfree.chart.axis.AxisLocation var23 = var17.getDomainAxisLocation();
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var17);
    java.awt.Paint var25 = var17.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var1.refreshTicks(var8, var9, var10, var11);
    java.awt.Shape var13 = var1.getDownArrow();
    var1.setLabelAngle(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, 10.0d);
    java.awt.Paint var3 = var2.getWallPaint();
    var2.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("hi!");
    var2.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var2.valueToJava2D(1.0d, var6, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.axis.AxisState var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var2.refreshTicks(var9, var10, var11, var12);
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    double var19 = var18.getAnchorValue();
    var2.setPlot((org.jfree.chart.plot.Plot)var18);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("hi!");
    var22.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var22.valueToJava2D(1.0d, var26, var27);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.AxisState var30 = null;
    java.awt.geom.Rectangle2D var31 = null;
    org.jfree.chart.util.RectangleEdge var32 = null;
    java.util.List var33 = var22.refreshTicks(var29, var30, var31, var32);
    org.jfree.chart.renderer.xy.XYItemRenderer var34 = null;
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var22, var34);
    double var36 = var35.getDomainCrosshairValue();
    boolean var37 = var35.isRangeGridlinesVisible();
    int var38 = var35.getDomainAxisCount();
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    var35.setRenderer(var39);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = var35.getRenderer((-435));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    java.util.List var12 = var1.refreshTicks(var8, var9, var10, var11);
    org.jfree.data.Range var13 = var1.getRange();
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("hi!");
    var15.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var19 = null;
    org.jfree.chart.util.RectangleEdge var20 = null;
    double var21 = var15.valueToJava2D(1.0d, var19, var20);
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.AxisState var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    java.util.List var26 = var15.refreshTicks(var22, var23, var24, var25);
    org.jfree.data.Range var27 = var15.getRange();
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var13, var27);
    org.jfree.chart.block.RectangleConstraint var30 = var28.toFixedWidth((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    var1.setLowerMargin(0.0d);
    java.awt.Stroke var6 = var1.getAxisLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    java.awt.Shape var4 = null;
    java.awt.Color var12 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(10.0d, 0.0d, 1.0d, 0.0d, (java.awt.Paint)var12);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("", "hi!", "hi!", "hi!", var4, (java.awt.Paint)var12);
    java.awt.Shape var15 = var14.getShape();
    org.jfree.chart.util.GradientPaintTransformer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setFillPaintTransformer(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("hi!");

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }


    org.jfree.chart.axis.SegmentedTimeline var3 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    org.jfree.chart.axis.SegmentedTimeline var7 = new org.jfree.chart.axis.SegmentedTimeline(100L, 0, 13);
    boolean var8 = var7.getAdjustForDaylightSaving();
    var3.setBaseTimeline(var7);
    long var10 = var7.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var12 = var7.getSegment(100L);
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 0.0f, 0.0f);
    java.awt.Color var17 = var16.brighter();
    java.lang.String var18 = org.jfree.chart.util.PaintUtilities.colorToString(var17);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("hi!");
    var20.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var20.valueToJava2D(1.0d, var24, var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.axis.AxisState var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    java.util.List var31 = var20.refreshTicks(var27, var28, var29, var30);
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var32, var33, var34, var35);
    double var37 = var36.getAnchorValue();
    var20.setPlot((org.jfree.chart.plot.Plot)var36);
    java.awt.Stroke var39 = var36.getDomainGridlineStroke();
    org.jfree.chart.plot.CategoryMarker var40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var12, (java.awt.Paint)var17, var39);
    org.jfree.data.category.CategoryDataset var41 = null;
    org.jfree.chart.axis.CategoryAxis var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var44 = null;
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot(var41, var42, var43, var44);
    int var46 = var45.getDomainAxisCount();
    var45.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    int var50 = var45.getIndexOf(var49);
    java.awt.Stroke var51 = var45.getDomainGridlineStroke();
    var40.setStroke(var51);
    java.awt.Font var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var40.setLabelFont(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1300L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "#030303"+ "'", var18.equals("#030303"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.clearRangeMarkers(1);
    float var7 = var4.getForegroundAlpha();
    org.jfree.chart.util.Layer var9 = null;
    java.util.Collection var10 = var4.getRangeMarkers((-1), var9);
    var4.setBackgroundImageAlignment(0);
    java.lang.Object var13 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    java.text.DateFormat var2 = null;
    org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(0, (-1), var2);
    int var4 = var3.getCalendarField();
    int var6 = var3.compareTo((java.lang.Object)false);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var9.valueToJava2D(1.0d, var13, var14);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var9.refreshTicks(var16, var17, var18, var19);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    var9.setPlot((org.jfree.chart.plot.Plot)var25);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    var29.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var29.valueToJava2D(1.0d, var33, var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.axis.AxisState var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    java.util.List var40 = var29.refreshTicks(var36, var37, var38, var39);
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var29, var41);
    java.awt.Stroke var43 = var42.getRangeCrosshairStroke();
    boolean var44 = var3.equals((java.lang.Object)var42);
    java.awt.Paint var45 = var42.getRangeGridlinePaint();
    java.awt.Paint var46 = var42.getRangeCrosshairPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, 13, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.data.category.CategoryDataset var6 = null;
    var4.setDataset(13, var6);
    org.jfree.data.category.CategoryDataset var9 = null;
    var4.setDataset(10, var9);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.util.RectangleEdge var6 = null;
    double var7 = var1.valueToJava2D(1.0d, var5, var6);
    org.jfree.chart.event.AxisChangeEvent var8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    java.text.DateFormat var9 = var1.getDateFormatOverride();
    var1.setAutoRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth((-1.0d));
    double var5 = var2.getWidth();
    org.jfree.chart.block.RectangleConstraint var7 = var2.toFixedWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    java.text.DateFormat var2 = null;
    org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(0, (-1), var2);
    int var4 = var3.getCalendarField();
    int var6 = var3.compareTo((java.lang.Object)false);
    org.jfree.data.xy.XYDataset var7 = null;
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("hi!");
    var9.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var9.valueToJava2D(1.0d, var13, var14);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.axis.AxisState var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    java.util.List var20 = var9.refreshTicks(var16, var17, var18, var19);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
    double var26 = var25.getAnchorValue();
    var9.setPlot((org.jfree.chart.plot.Plot)var25);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("hi!");
    var29.setAxisLineVisible(false);
    java.awt.geom.Rectangle2D var33 = null;
    org.jfree.chart.util.RectangleEdge var34 = null;
    double var35 = var29.valueToJava2D(1.0d, var33, var34);
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.axis.AxisState var37 = null;
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    java.util.List var40 = var29.refreshTicks(var36, var37, var38, var39);
    org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var29, var41);
    java.awt.Stroke var43 = var42.getRangeCrosshairStroke();
    boolean var44 = var3.equals((java.lang.Object)var42);
    var42.clearDomainMarkers((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

}
