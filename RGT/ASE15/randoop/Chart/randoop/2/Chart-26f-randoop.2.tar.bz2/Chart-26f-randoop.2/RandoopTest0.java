
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)(byte)1);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    org.jfree.chart.util.VerticalAlignment var5 = null;
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("", var1, var2, var3, var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.labels.CategoryToolTipGenerator var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-1), var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getMeanValue(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.awt.Shape var0 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "hi!", "", (org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)(byte)100, (java.lang.Comparable)(-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var1 = var0.clone();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var0.getCategoryEnd(100, 1, var4, var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var0.draw(var7, 1.0d, var9, var10, var11, var12);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.lang.Boolean var3 = null;
    var0.setSeriesCreateEntities(10, var3, true);
    org.jfree.chart.event.RendererChangeListener var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeChangeListener(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(100, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.awt.geom.Rectangle2D var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = null;
    double var2 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.axis.AxisState var12 = var0.draw(var6, 0.25d, var8, var9, var10, var11);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "", "", "");

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.util.Date var1 = null;
//     var0.addBaseTimelineException(var1);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.lang.String[] var1 = new java.lang.String[] { ""};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     java.lang.Number[] var4 = null;
//     java.lang.Number[][] var5 = new java.lang.Number[][] { var4};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3, var5);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.CategoryPlot var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.drawBackground(var1, var2, var3);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    java.io.ObjectOutputStream var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
    var0.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    var3.setAutoPopulateSeriesShape(false);
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.plot.CategoryPlot var9 = null;
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var12 = var11.getBaseStroke();
    var10.setAxisLineStroke(var12);
    var10.setLabelURL("hi!");
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.drawItem(var6, var7, var8, var9, (org.jfree.chart.axis.CategoryAxis)var10, var16, (org.jfree.data.category.CategoryDataset)var17, 1, 10, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.data.Range var2 = new org.jfree.data.Range(0.25d, Double.NaN);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieToolTipGenerator var2 = var1.getToolTipGenerator();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    java.awt.Paint var7 = null;
    var6.setLabelShadowPaint(var7);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    var6.handleClick(0, 1, var11);
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var15 = var1.initialise(var3, var4, (org.jfree.chart.plot.PiePlot)var6, (java.lang.Integer)0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var0 = null;
//     org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
//     java.awt.geom.Rectangle2D var2 = null;
//     var1.setChartArea(var2);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
//     double var4 = var3.getYOffset();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var9 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var11 = var10.getBaseStroke();
//     boolean var12 = var9.equals((java.lang.Object)var10);
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var14 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var16 = var14.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var17 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var13, var16);
//     java.awt.geom.Rectangle2D var18 = null;
//     var3.drawRangeMarker(var5, var6, var7, (org.jfree.chart.plot.Marker)var17, var18);
// 
//   }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var4 = var3.getBaseStroke();
    boolean var5 = var2.equals((java.lang.Object)var3);
    java.awt.Paint var6 = var2.getBaseOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var7 = org.jfree.chart.text.TextUtilities.createTextBlock("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var11 = var10.getBaseStroke();
    var9.setAxisLineStroke(var11);
    var9.setLabelURL("hi!");
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var16 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.drawItem(var5, var6, var7, var8, (org.jfree.chart.axis.CategoryAxis)var9, var15, (org.jfree.data.category.CategoryDataset)var16, (-1), 1, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
//     java.awt.Stroke var6 = var0.getTickMarkStroke();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.axis.AxisState var13 = var0.draw(var7, Double.NaN, var9, var10, var11, var12);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var2 = var1.getBaseStroke();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     boolean var4 = var0.getRenderAsPercentages();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var8 = var7.getBaseStroke();
//     boolean var9 = var6.equals((java.lang.Object)var7);
//     java.awt.Paint var10 = var7.getBasePaint();
//     var0.setSeriesPaint(100, var10);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.lang.Boolean var3 = null;
    var0.setSeriesCreateEntities(10, var3, true);
    org.jfree.chart.plot.CategoryPlot var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPlot(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    java.lang.Object var2 = var0.clone();
    double var3 = var0.getYOffset();
    var0.setDrawOutlines(false);
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 8.0d);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-1), var1);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.awt.Font var1 = null;
    java.awt.Color var5 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1, (java.awt.Paint)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var0, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    java.awt.Shape var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShape((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(0L);
//     java.util.List var3 = null;
//     var0.addExceptions(var3);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var5.getCategoryMiddle(1, 100, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    java.lang.Comparable[] var12 = null;
    java.lang.Comparable[] var14 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var15 = null;
    java.lang.Number[][] var16 = new java.lang.Number[][] { var15};
    java.lang.Number[][] var17 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var18 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var12, var14, var16, var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, var3, var4, (org.jfree.chart.axis.CategoryAxis)var5, var11, (org.jfree.data.category.CategoryDataset)var18, (-1), 1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     java.util.Date var1 = null;
//     java.util.Date var2 = null;
//     org.jfree.data.gantt.Task var3 = new org.jfree.data.gantt.Task("WMAP_Plot", var1, var2);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    double var4 = var0.getMinimumBarLength();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var7 = var6.getBaseStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlineStroke((-1), var7, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test62() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test63() {}
//   public void test63() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var5 = var0.getLegendItem(0, (-1));
//     java.awt.Paint var7 = null;
//     var0.setSeriesPaint(10, var7);
//     java.awt.Color var11 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D(var12);
//     org.jfree.chart.labels.PieSectionLabelGenerator var14 = var13.getLabelGenerator();
//     var13.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var17 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var18 = var17.getEndType();
//     java.awt.Stroke var19 = var17.getBaseOutlineStroke();
//     var13.setOutlineStroke(var19);
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var21.getCategoryMiddle(1, 100, var24, var25);
//     org.jfree.chart.util.RectangleInsets var31 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var21.setLabelInsets(var31);
//     org.jfree.chart.block.LineBorder var33 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var11, var19, var31);
//     var0.setSeriesItemLabelPaint(100, (java.awt.Paint)var11, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var0.", var17.equals(var0) == var0.equals(var17));
// 
//   }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var1.getBaseURLGenerator();
    java.lang.Boolean var4 = var1.getSeriesLinesVisible(100);
    var1.setBaseLinesVisible(false);
    boolean var7 = var1.getAutoPopulateSeriesFillPaint();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)1L, (java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     java.lang.Object var2 = var0.clone();
//     var0.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.renderer.category.LineRenderer3D var6 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var7 = var6.getBaseOutlineStroke();
//     java.lang.Object var8 = var6.clone();
//     double var9 = var6.getYOffset();
//     java.awt.Font var12 = var6.getItemLabelFont(1, 100);
//     var0.setSeriesItemLabelFont(10, var12);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var0.", var6.equals(var0) == var0.equals(var6));
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var5 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var6 = var5.getEndType();
    java.awt.Stroke var7 = var5.getBaseOutlineStroke();
    var1.setOutlineStroke(var7);
    org.jfree.chart.util.Rotation var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var1 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var1, (java.lang.Comparable)100.0f);
    java.util.List var4 = var1.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var7 = var0.generateToolTip((org.jfree.data.category.CategoryDataset)var1, 100, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(100.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
    int var4 = var1.getColumnIndex((java.lang.Comparable)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var6 = new org.jfree.chart.title.LegendItemBlockContainer(var0, (org.jfree.data.general.Dataset)var1, (java.lang.Comparable)2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)100.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getColumnKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var1);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     java.lang.Comparable[] var2 = null;
//     java.lang.Comparable[] var4 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var5 = null;
//     java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
//     java.lang.Number[][] var7 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var2, var4, var6, var7);
//     org.jfree.data.category.CategoryDataset var9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("October", "hi!", var7);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var5 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var6 = var5.getEndType();
    java.awt.Stroke var7 = var5.getBaseOutlineStroke();
    var1.setOutlineStroke(var7);
    java.lang.Object var9 = var1.clone();
    var1.setShadowXOffset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = var7.getLabelGenerator();
//     var7.zoom(0.0d);
//     boolean var11 = var7.getLabelLinksVisible();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
//     org.jfree.chart.labels.PieSectionLabelGenerator var15 = var14.getLabelGenerator();
//     org.jfree.chart.labels.PieToolTipGenerator var16 = null;
//     var14.setToolTipGenerator(var16);
//     java.awt.Stroke var19 = var14.getSectionOutlineStroke((java.lang.Comparable)(-1));
//     var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
//     
//     // Checks the contract:  equals-hashcode on var7 and var14
//     assertTrue("Contract failed: equals-hashcode on var7 and var14", var7.equals(var14) ? var7.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var7
//     assertTrue("Contract failed: equals-hashcode on var14 and var7", var14.equals(var7) ? var14.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var15
//     assertTrue("Contract failed: equals-hashcode on var8 and var15", var8.equals(var15) ? var8.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var8
//     assertTrue("Contract failed: equals-hashcode on var15 and var8", var15.equals(var8) ? var15.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("October", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var3);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.util.Date var1 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var2 = var0.getSegment(var1);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.block.Arrangement var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendItemBlockContainer var3 = new org.jfree.chart.title.LegendItemBlockContainer(var0, var1, (java.lang.Comparable)'#');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.25d, 10.0f, 1.0f);
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var5 = null;
    var1.setSeriesOutlinePaint(100, var5);
    double var7 = var1.getLowerClip();
    java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesFillPaint((-1), (java.awt.Paint)var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    double var1 = var0.getTranslateY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 100.0d, 1.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var5.getMeanValue(2, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    java.lang.Comparable var5 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var8 = var7.getBaseOutlineStroke();
    java.lang.Object var9 = var7.clone();
    double var10 = var7.getYOffset();
    java.awt.Font var13 = var7.getItemLabelFont(1, 100);
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var18.getCategoryMiddle(1, 100, var21, var22);
    java.awt.Stroke var24 = var18.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var28 = var27.getBaseStroke();
    boolean var29 = var26.equals((java.lang.Object)var27);
    java.awt.Paint var30 = var26.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var33 = var31.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var30, var33);
    org.jfree.chart.renderer.category.LineRenderer3D var35 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var37 = var35.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var17, var24, var30, var37, 0.0f);
    org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("October", var13, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSectionPaint(var5, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Pie 3D Plot", var1, 1.0f, (-1.0f), 0.0d, 1.0f, 1.0f);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var2 = var1.getBaseOutlineStroke();
    java.lang.Object var3 = var1.clone();
    org.jfree.chart.event.RendererChangeEvent var4 = new org.jfree.chart.event.RendererChangeEvent(var3);
    var0.rendererChanged(var4);
    org.jfree.data.general.WaferMapDataset var6 = var0.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.awt.Color var6 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    double var12 = var7.getCategoryMiddle(1, 100, var10, var11);
    java.awt.Stroke var13 = var7.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var15 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var17 = var16.getBaseStroke();
    boolean var18 = var15.equals((java.lang.Object)var16);
    java.awt.Paint var19 = var15.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var20 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var22 = var20.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var23 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var19, var22);
    org.jfree.chart.renderer.category.LineRenderer3D var24 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var26 = var24.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var28 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var6, var13, var19, var26, 0.0f);
    org.jfree.chart.renderer.category.AreaRenderer var29 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var31 = var29.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var34 = var29.getLegendItem(0, (-1));
    boolean var35 = var29.getAutoPopulateSeriesFillPaint();
    boolean var36 = var6.equals((java.lang.Object)var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-1), (java.awt.Paint)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = var7.getLabelGenerator();
//     var7.zoom(0.0d);
//     boolean var11 = var7.getLabelLinksVisible();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var7.drawBackground(var13, var14);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.ui.Licences var0 = org.jfree.chart.ui.Licences.getInstance();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 1, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    float[] var3 = new float[] { (-1.0f)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = var1.getComponents(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var4 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var2, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("October");

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    var1.setIncludeBaseInRange(false);
    java.awt.Paint var7 = var1.getSeriesItemLabelPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var8 = var7.getBaseStroke();
    boolean var9 = var6.equals((java.lang.Object)var7);
    java.awt.Paint var10 = var6.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var11 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var13 = var11.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var14 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var10, var13);
    org.jfree.chart.util.Layer var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(10, (org.jfree.chart.plot.Marker)var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
//     java.lang.Boolean var3 = var0.getSeriesLinesVisible(100);
//     var0.setBaseLinesVisible(false);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var7);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
//     int var13 = var10.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var15 = var14.clone();
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var14.getCategoryEnd(100, 1, var18, var19);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var26 = null;
//     var25.setBaseItemLabelFont(var26, true);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, (org.jfree.chart.axis.CategoryAxis)var14, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setRangeAxisLocation(10, var31);
//     org.jfree.chart.axis.ValueAxis var33 = var29.getRangeAxis();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     boolean var38 = var29.render(var34, var35, 100, var37);
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var40 = var39.clone();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var39.getCategoryStart(1, 0, var43, var44);
//     java.lang.String var47 = var39.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     java.awt.Color var51 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var52.getCategoryMiddle(1, 100, var55, var56);
//     java.awt.Stroke var58 = var52.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var60 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var62 = var61.getBaseStroke();
//     boolean var63 = var60.equals((java.lang.Object)var61);
//     java.awt.Paint var64 = var60.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var65 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var67 = var65.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var68 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var64, var67);
//     org.jfree.chart.renderer.category.LineRenderer3D var69 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var71 = var69.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var73 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var51, var58, var64, var71, 0.0f);
//     var39.setAxisLinePaint(var64);
//     org.jfree.chart.axis.ValueAxis var75 = null;
//     org.jfree.data.category.CategoryDataset var76 = null;
//     var0.drawItem(var6, var8, var9, var29, (org.jfree.chart.axis.CategoryAxis)var39, var75, var76, 100, 1, 2);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var3.setSeriesItemLabelGenerator(2, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var8);
//     int var11 = var8.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var13 = var12.clone();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var12.getCategoryEnd(100, 1, var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var24 = null;
//     var23.setBaseItemLabelFont(var24, true);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var12, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var27.setRangeAxisLocation(10, var29);
//     org.jfree.chart.axis.ValueAxis var31 = var27.getRangeAxis();
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     java.awt.Color var36 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var37.getCategoryMiddle(1, 100, var40, var41);
//     java.awt.Stroke var43 = var37.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var45 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var47 = var46.getBaseStroke();
//     boolean var48 = var45.equals((java.lang.Object)var46);
//     java.awt.Paint var49 = var45.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var50 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var52 = var50.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var49, var52);
//     org.jfree.chart.renderer.category.LineRenderer3D var54 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var56 = var54.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var58 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var36, var43, var49, var56, 0.0f);
//     var58.setStartValue(100.0d);
//     java.awt.geom.Rectangle2D var61 = null;
//     var3.drawRangeMarker(var7, var27, var32, (org.jfree.chart.plot.Marker)var58, var61);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var24.getLabelGenerator();
    var24.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var28 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var29 = var28.getEndType();
    java.awt.Stroke var30 = var28.getBaseOutlineStroke();
    var24.setOutlineStroke(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var32.getCategoryMiddle(1, 100, var35, var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var32.setLabelInsets(var42);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var30, var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setSeriesOutlineStroke((-1), var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlineStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var20 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var21 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var20);
//     int var23 = var20.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var25 = var24.clone();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var24.getCategoryEnd(100, 1, var28, var29);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var35 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var36 = null;
//     var35.setBaseItemLabelFont(var36, true);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, (org.jfree.chart.axis.CategoryAxis)var24, var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
//     org.jfree.chart.util.RectangleEdge var41 = var39.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotOrientation var42 = var39.getOrientation();
//     var19.setOrientation(var42);
//     
//     // Checks the contract:  equals-hashcode on var0 and var20
//     assertTrue("Contract failed: equals-hashcode on var0 and var20", var0.equals(var20) ? var0.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var0
//     assertTrue("Contract failed: equals-hashcode on var20 and var0", var20.equals(var0) ? var20.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var39
//     assertTrue("Contract failed: equals-hashcode on var19 and var39", var19.equals(var39) ? var19.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var19
//     assertTrue("Contract failed: equals-hashcode on var39 and var19", var39.equals(var19) ? var39.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     double var1 = var0.getRangeCrosshairValue();
//     org.jfree.chart.axis.ValueAxis[] var2 = null;
//     var0.setDomainAxes(var2);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.lang.Boolean var3 = null;
    var0.setSeriesCreateEntities(10, var3, true);
    java.awt.Stroke var6 = var0.getBaseOutlineStroke();
    org.jfree.chart.renderer.category.AreaRenderer var8 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var9 = var8.getEndType();
    java.awt.Paint var11 = var8.lookupSeriesOutlinePaint(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), var11, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.LengthAdjustmentType var10 = null;
    org.jfree.chart.util.LengthAdjustmentType var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var12 = var5.createAdjustedRectangle(var9, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    var0.add(1.0d, (-1.0d), (java.lang.Comparable)2, (java.lang.Comparable)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.data.Range var3 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var1);
    boolean var4 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var1 = var0.clone();
//     java.lang.String var2 = var0.getLabelToolTip();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.axis.AxisState var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     int var9 = var6.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var11 = var10.clone();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.getCategoryEnd(100, 1, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var22 = null;
//     var21.setBaseItemLabelFont(var22, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     org.jfree.chart.util.RectangleEdge var27 = var25.getRangeAxisEdge(1);
//     java.util.List var28 = var0.refreshTicks(var3, var4, var5, var27);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.awt.Color var1 = java.awt.Color.getColor("WMAP_Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 10.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
    java.awt.Stroke var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(0L);
//     long var4 = var0.toMillisecond(10L);
//     java.util.Date var5 = null;
//     boolean var6 = var0.containsDomainValue(var5);
// 
//   }

//  public void test119() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Pie 3D Plot", var1);
//
//  }
//
  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("Other", var1, var2);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var4.getCategoryMiddle(1, 100, var7, var8);
//     java.awt.Stroke var10 = var4.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var14 = var13.getBaseStroke();
//     boolean var15 = var12.equals((java.lang.Object)var13);
//     java.awt.Paint var16 = var12.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var17 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var19 = var17.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var16, var19);
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var3, var10, var16, var23, 0.0f);
//     java.lang.Class var26 = null;
//     java.util.EventListener[] var27 = var25.getListeners(var26);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)100.0f);
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var3 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, (java.lang.Comparable)100.0f);
    java.util.List var6 = var3.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add(var6, (java.lang.Comparable)'4', (java.lang.Comparable)"");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.chart.renderer.category.AreaRenderer var2 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var7 = var2.getLegendItem(0, (-1));
//     boolean var8 = var2.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
//     org.jfree.chart.renderer.category.AreaRenderer var11 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var16 = var11.getLegendItem(0, (-1));
//     boolean var17 = var11.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var11.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var19 = var18.getRotationAnchor();
//     org.jfree.chart.axis.DateTick var21 = new org.jfree.chart.axis.DateTick(var0, "({0}, {1}) = {3} - {4}", var10, var19, 1.0d);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.axis.ValueAxis var1 = var0.getAxis();
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    boolean var3 = var0.equals((java.lang.Object)var2);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var7 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var8 = var7.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var9 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var10 = var7.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var2.generateToolTip((org.jfree.data.category.CategoryDataset)var9, 100, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(1, (-1), var2);
//     java.util.Date var4 = null;
//     java.util.TimeZone var5 = null;
//     java.util.Date var6 = var3.addToDate(var4, var5);
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var44 = null;
//     var40.draw(var41, 1.0f, 0.0f, var44, 1.0f, 0.0f, 0.25d);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.LegendItemCollection var2 = null;
    var0.setFixedLegendItems(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     java.lang.Object var2 = var0.clone();
//     var0.setAutoPopulateSeriesFillPaint(true);
//     var0.setAutoPopulateSeriesOutlineStroke(false);
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var11.getCategoryMiddle(1, 100, var14, var15);
//     java.awt.Stroke var17 = var11.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var19 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var21 = var20.getBaseStroke();
//     boolean var22 = var19.equals((java.lang.Object)var20);
//     java.awt.Paint var23 = var19.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var24 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var26 = var24.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var23, var26);
//     org.jfree.chart.renderer.category.LineRenderer3D var28 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var30 = var28.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var32 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var10, var17, var23, var30, 0.0f);
//     var0.setBaseStroke(var30, false);
//     org.jfree.chart.renderer.category.AreaRenderer var36 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var38 = var36.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var41 = var36.getLegendItem(0, (-1));
//     boolean var42 = var36.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var43 = var36.getBaseNegativeItemLabelPosition();
//     var0.setSeriesPositiveItemLabelPosition(0, var43, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var0.", var24.equals(var0) == var0.equals(var24));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var28 and var0.", var28.equals(var0) == var0.equals(var28));
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     int var7 = var6.getColumnCount();
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    var3.setAutoPopulateSeriesPaint(true);
    var3.setIncludeBaseInRange(true);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    var19.setWeight(1);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    var19.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
    org.jfree.chart.util.SortOrder var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setColumnRenderingOrder(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = null;
    org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var3);
    int var6 = var3.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var8 = var7.clone();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var7.getCategoryEnd(100, 1, var11, var12);
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var19 = null;
    var18.setBaseItemLabelFont(var19, true);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, (org.jfree.chart.axis.CategoryAxis)var7, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.util.RectangleEdge var24 = var22.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryLabelPosition var25 = var2.getLabelPosition(var24);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var26 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var0, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + Double.NaN+ "'", var4.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var4 = var0.getBaseOutlinePaint();
    org.jfree.data.KeyToGroupMap var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToGroupMap(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     int var10 = var6.getRowIndex((java.lang.Comparable)"WMAP_Plot");
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var24);
//     int var27 = var24.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var29 = var28.clone();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var28.getCategoryEnd(100, 1, var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var40 = null;
//     var39.setBaseItemLabelFont(var40, true);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var28, var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setRangeAxisLocation(10, var45);
//     boolean var47 = var43.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var48 = var43.getDomainAxisLocation();
//     java.lang.String var49 = var48.toString();
//     var19.setDomainAxisLocation(var48);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var43
//     assertTrue("Contract failed: equals-hashcode on var19 and var43", var19.equals(var43) ? var19.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var19
//     assertTrue("Contract failed: equals-hashcode on var43 and var19", var43.equals(var19) ? var43.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getAxis();
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     boolean var3 = var0.equals((java.lang.Object)var2);
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.Point var7 = var0.translateValueThetaRadiusToJava2D(0.0d, 4.0d, var6);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var3 = var1.getTimeFromLong(0L);
//     long var5 = var1.toTimelineValue(100L);
//     var0.setBaseTimeline(var1);
//     java.util.Date var7 = null;
//     long var8 = var1.getTime(var7);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     var0.setSeriesItemLabelsVisible(0, false);
//     java.awt.Font var4 = null;
//     var0.setBaseItemLabelFont(var4, true);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var8);
//     org.jfree.chart.renderer.category.AreaRenderer var11 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var16 = var11.getLegendItem(0, (-1));
//     java.awt.Paint var18 = null;
//     var11.setSeriesPaint(10, var18);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var21 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var11.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var21, true);
//     java.lang.String var24 = var21.getLabelFormat();
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.CategoryToolTipGenerator)var21);
//     org.jfree.chart.renderer.category.AreaRenderer var26 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = var26.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var31 = var26.getLegendItem(0, (-1));
//     boolean var32 = var26.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var33 = var26.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var34 = var33.getRotationAnchor();
//     var0.setBaseNegativeItemLabelPosition(var33);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var11.", var26.equals(var11) == var11.equals(var26));
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    java.lang.String var3 = var2.getPlotType();
    org.jfree.data.category.CategoryDataset var4 = null;
    var2.setDataset(var4);
    java.lang.Comparable var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setAggregatedItemsKey(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Multiple Pie Plot"+ "'", var3.equals("Multiple Pie Plot"));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setAxisLineVisible(false);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)100.0f);
    java.util.List var3 = var0.getRowKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.List var6 = var0.getOutliers(2, (-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    java.lang.String var5 = var0.getPlotType();
    org.jfree.chart.annotations.XYAnnotation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var7 = var0.removeAnnotation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "XY Plot"+ "'", var5.equals("XY Plot"));

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     int var7 = var6.getCategoryCount();
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(0, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    int var13 = var10.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var15 = var14.clone();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var14.getCategoryEnd(100, 1, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var26 = null;
    var25.setBaseItemLabelFont(var26, true);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, (org.jfree.chart.axis.CategoryAxis)var14, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.util.RectangleEdge var31 = var29.getRangeAxisEdge(1);
    java.awt.Font var32 = var29.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var33.getCategoryStart(1, 0, var37, var38);
    java.lang.String var41 = var33.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var45 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var46 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var49 = null;
    org.jfree.chart.util.RectangleEdge var50 = null;
    double var51 = var46.getCategoryMiddle(1, 100, var49, var50);
    java.awt.Stroke var52 = var46.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var54 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var56 = var55.getBaseStroke();
    boolean var57 = var54.equals((java.lang.Object)var55);
    java.awt.Paint var58 = var54.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var59 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var61 = var59.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var62 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var58, var61);
    org.jfree.chart.renderer.category.LineRenderer3D var63 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var65 = var63.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var67 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var45, var52, var58, var65, 0.0f);
    var33.setAxisLineStroke(var65);
    org.jfree.data.general.PieDataset var69 = null;
    org.jfree.chart.plot.PiePlot3D var70 = new org.jfree.chart.plot.PiePlot3D(var69);
    java.awt.Paint var71 = null;
    var70.setLabelShadowPaint(var71);
    org.jfree.chart.plot.PlotRenderingInfo var75 = null;
    var70.handleClick(0, 1, var75);
    var33.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var70);
    java.awt.Paint var78 = var33.getTickMarkPaint();
    java.util.List var79 = var29.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.add(var79, (java.lang.Comparable)0L, (java.lang.Comparable)0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(var0, var1);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     boolean var23 = var19.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
//     java.lang.String var25 = var24.toString();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var26);
//     int var29 = var26.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var31 = var30.clone();
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var30.getCategoryEnd(100, 1, var34, var35);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var42 = null;
//     var41.setBaseItemLabelFont(var42, true);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var30, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     org.jfree.chart.util.RectangleEdge var47 = var45.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotOrientation var48 = var45.getOrientation();
//     org.jfree.chart.util.RectangleEdge var49 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var24, var48);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var45
//     assertTrue("Contract failed: equals-hashcode on var19 and var45", var19.equals(var45) ? var19.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var19
//     assertTrue("Contract failed: equals-hashcode on var45 and var19", var45.equals(var19) ? var45.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var5 = var0.getLegendItem(0, (-1));
//     boolean var6 = var0.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var7 = var0.getBaseNegativeItemLabelPosition();
//     java.awt.Paint var9 = var0.getSeriesOutlinePaint((-1));
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
//     var14.setAutoPopulateSeriesShape(false);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = null;
//     var14.setSeriesURLGenerator(100, var18, false);
//     org.jfree.chart.renderer.category.AreaRenderer var22 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var22.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var27 = var22.getLegendItem(0, (-1));
//     boolean var28 = var22.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var29 = var22.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var30 = var29.getRotationAnchor();
//     var14.setSeriesPositiveItemLabelPosition(1, var29);
//     var0.setSeriesPositiveItemLabelPosition(1, var29, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var0.", var22.equals(var0) == var0.equals(var22));
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    var0.setAxisLineStroke(var2);
    java.io.ObjectOutputStream var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
    java.awt.Stroke var6 = var0.getTickMarkStroke();
    java.awt.Font var7 = var0.getLabelFont();
    var0.setTickMarkOutsideLength(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var25 = var24.clone();
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.RectangleEdge var29 = null;
    double var30 = var24.getCategoryStart(1, 0, var28, var29);
    java.lang.String var32 = var24.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    var19.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var24);
    java.awt.Paint var34 = var24.getLabelPaint();
    org.jfree.data.general.PieDataset var35 = null;
    org.jfree.chart.plot.PiePlot3D var36 = new org.jfree.chart.plot.PiePlot3D(var35);
    org.jfree.chart.labels.PieSectionLabelGenerator var37 = var36.getLabelGenerator();
    var36.zoom(0.0d);
    boolean var40 = var36.getLabelLinksVisible();
    org.jfree.data.general.PieDataset var41 = null;
    org.jfree.chart.plot.PiePlot3D var42 = new org.jfree.chart.plot.PiePlot3D(var41);
    java.awt.Paint var43 = null;
    var42.setLabelShadowPaint(var43);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    var42.handleClick(0, 1, var47);
    org.jfree.chart.event.PlotChangeListener var49 = null;
    var42.addChangeListener(var49);
    var36.setParent((org.jfree.chart.plot.Plot)var42);
    java.awt.Paint var52 = var42.getLabelPaint();
    boolean var53 = var24.hasListener((java.util.EventListener)var42);
    var42.setLabelLinkMargin(0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.RectangleEdge var21 = var19.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryAnchor var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDomainGridlinePosition(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
    java.awt.Stroke var6 = var0.getTickMarkStroke();
    var0.setCategoryMargin(0.0d);
    boolean var9 = var0.isTickMarksVisible();
    double var10 = var0.getFixedDimension();
    double var11 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var44 = null;
//     var40.draw(var41, 100.0f, 10.0f, var44);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var5.getQ3Value(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = null;
    var0.setBaseItemLabelGenerator(var1, true);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var9 = var8.getBaseStroke();
    var7.setAxisLineStroke(var9);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var14 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var15 = var14.getYOffset();
    java.awt.Paint var16 = var14.getWallPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var17 = new org.jfree.chart.LegendItem(var0, "", "", "October", var6, var9, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)'#', (java.lang.Object)2);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    java.lang.Object var2 = var0.clone();
    double var3 = var0.getYOffset();
    boolean var4 = var0.getDrawOutlines();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
    org.jfree.chart.labels.PieToolTipGenerator var7 = var6.getToolTipGenerator();
    java.awt.Stroke var8 = var6.getLabelOutlineStroke();
    double var9 = var6.getShadowXOffset();
    var6.setShadowYOffset(0.05d);
    boolean var12 = var0.equals((java.lang.Object)0.05d);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var14 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-1), (org.jfree.chart.labels.CategoryToolTipGenerator)var14, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.entity.EntityCollection var2 = null;
//     org.jfree.chart.ChartRenderingInfo var3 = new org.jfree.chart.ChartRenderingInfo(var2);
//     org.jfree.chart.entity.EntityCollection var4 = var3.getEntityCollection();
//     java.awt.geom.Rectangle2D var5 = var3.getChartArea();
//     java.awt.geom.Point2D var6 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(Double.NaN, 3.0d, var5);
//     
//     // Checks the contract:  var6.equals(var6)
//     assertTrue("Contract failed: var6.equals(var6)", var6.equals(var6));
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var5 = var0.getLegendItem(0, (-1));
    org.jfree.chart.renderer.AreaRendererEndType var6 = var0.getEndType();
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    boolean var8 = var7.isDomainZoomable();
    org.jfree.chart.axis.ValueAxis var9 = var7.getAxis();
    var7.clearCornerTextItems();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
    boolean var14 = var0.getItemVisible(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var5.getColumnKey(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0d+ "'", var7.equals(0.0d));

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var3 = var1.getTimeFromLong(0L);
    long var5 = var1.toTimelineValue(100L);
    var0.setBaseTimeline(var1);
    var0.addBaseTimelineException((-1L));
    long var9 = var0.getSegmentsGroupSize();
    int var10 = var0.getSegmentsExcluded();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 644288400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 68);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(0, 10);
//     java.util.Date var3 = null;
//     java.lang.String var4 = var2.dateToString(var3);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    var0.setSeriesLinesVisible(10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    boolean var5 = var1.getLabelLinksVisible();
    org.jfree.chart.util.RectangleInsets var6 = new org.jfree.chart.util.RectangleInsets();
    var1.setInsets(var6, true);
    java.awt.Paint var9 = var1.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    var19.setDrawSharedDomainAxis(false);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var26);
    int var29 = var26.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var31 = var30.clone();
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.util.RectangleEdge var35 = null;
    double var36 = var30.getCategoryEnd(100, 1, var34, var35);
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var42 = null;
    var41.setBaseItemLabelFont(var42, true);
    org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var30, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    org.jfree.chart.axis.AxisLocation var47 = null;
    var45.setRangeAxisLocation(10, var47);
    boolean var49 = var45.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var50 = var45.getDomainAxisLocation();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setRangeAxisLocation((-16777216), var50);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + Double.NaN+ "'", var27.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     float var2 = var1.getBaselineOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeCrosshairLockedOnData();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryMarker var9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
//     boolean var10 = var9.getDrawAsLine();
//     org.jfree.chart.util.Layer var11 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var9, var11);
//     org.jfree.chart.text.TextAnchor var13 = var9.getLabelTextAnchor();
//     float var14 = var1.calculateBaselineOffset(var3, var13);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isDomainZoomable();
//     boolean var2 = var0.isDomainZoomable();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.entity.EntityCollection var4 = null;
//     org.jfree.chart.ChartRenderingInfo var5 = new org.jfree.chart.ChartRenderingInfo(var4);
//     org.jfree.chart.entity.EntityCollection var6 = var5.getEntityCollection();
//     java.awt.geom.Rectangle2D var7 = var5.getChartArea();
//     var0.drawOutline(var3, var7);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    boolean var5 = var1.getLabelLinksVisible();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    var7.handleClick(0, 1, var12);
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var7.addChangeListener(var14);
    var1.setParent((org.jfree.chart.plot.Plot)var7);
    java.awt.Paint var17 = var7.getLabelPaint();
    double var18 = var7.getLabelLinkMargin();
    var7.setShadowXOffset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    java.lang.Comparable[] var2 = null;
    java.lang.Comparable[] var4 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var5 = null;
    java.lang.Number[][] var6 = new java.lang.Number[][] { var5};
    java.lang.Number[][] var7 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var8 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var2, var4, var6, var7);
    java.lang.Comparable[] var9 = null;
    java.lang.Comparable[] var11 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var12 = null;
    java.lang.Number[][] var13 = new java.lang.Number[][] { var12};
    java.lang.Number[][] var14 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var15 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var9, var11, var13, var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var16 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var6, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEventType var28 = null;
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var27, var28);
//     org.jfree.chart.axis.AxisLocation var30 = var19.getRangeAxisLocation();
//     org.jfree.chart.plot.Marker var32 = null;
//     org.jfree.chart.util.Layer var33 = null;
//     var19.addRangeMarker(0, var32, var33);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(0, 1, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var1.addChangeListener(var8);
    java.awt.Paint var10 = var1.getLabelShadowPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var5 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
//     double var6 = var5.getYOffset();
//     java.awt.Paint var7 = var5.getWallPaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var8);
//     int var11 = var8.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var13 = var12.clone();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var12.getCategoryEnd(100, 1, var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var24 = null;
//     var23.setBaseItemLabelFont(var24, true);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var12, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var27.setRangeAxisLocation(10, var29);
//     org.jfree.chart.axis.ValueAxis var31 = var27.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var33 = var27.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var34 = var27.getRangeAxisEdge();
//     org.jfree.chart.util.RectangleEdge var35 = org.jfree.chart.util.RectangleEdge.opposite(var34);
//     boolean var36 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var34);
//     org.jfree.chart.title.TextTitle var37 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var38 = var37.getBackgroundPaint();
//     org.jfree.chart.util.HorizontalAlignment var39 = var37.getHorizontalAlignment();
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.VerticalAlignment var41 = var40.getVerticalAlignment();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot3D var43 = new org.jfree.chart.plot.PiePlot3D(var42);
//     org.jfree.chart.labels.PieSectionLabelGenerator var44 = var43.getLabelGenerator();
//     var43.zoom(0.0d);
//     boolean var47 = var43.getLabelLinksVisible();
//     org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets();
//     var43.setInsets(var48, true);
//     double var52 = var48.calculateBottomInset(100.0d);
//     double var54 = var48.calculateBottomOutset((-100.0d));
//     org.jfree.chart.title.TextTitle var55 = new org.jfree.chart.title.TextTitle("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", var1, var7, var34, var39, var41, var48);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    double var7 = var3.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 100.0d);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedString var1 = org.jfree.chart.util.SerialUtilities.readAttributedString(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    int var1 = var0.getColumnCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getRowKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.handleClick(0, 1, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var1.addChangeListener(var8);
//     org.jfree.chart.event.PlotChangeEvent var10 = null;
//     var1.notifyListeners(var10);
//     java.awt.Color var13 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
//     org.jfree.chart.labels.PieSectionLabelGenerator var16 = var15.getLabelGenerator();
//     var15.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var19 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var20 = var19.getEndType();
//     java.awt.Stroke var21 = var19.getBaseOutlineStroke();
//     var15.setOutlineStroke(var21);
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var23.getCategoryMiddle(1, 100, var26, var27);
//     org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var23.setLabelInsets(var33);
//     org.jfree.chart.block.LineBorder var35 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var13, var21, var33);
//     var1.setOutlinePaint((java.awt.Paint)var13);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot3D var38 = new org.jfree.chart.plot.PiePlot3D(var37);
//     java.awt.Paint var39 = null;
//     var38.setLabelShadowPaint(var39);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     var38.handleClick(0, 1, var43);
//     org.jfree.chart.event.PlotChangeListener var45 = null;
//     var38.addChangeListener(var45);
//     org.jfree.chart.event.PlotChangeEvent var47 = null;
//     var38.notifyListeners(var47);
//     java.awt.Color var50 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var51 = null;
//     org.jfree.chart.plot.PiePlot3D var52 = new org.jfree.chart.plot.PiePlot3D(var51);
//     org.jfree.chart.labels.PieSectionLabelGenerator var53 = var52.getLabelGenerator();
//     var52.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var56 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var57 = var56.getEndType();
//     java.awt.Stroke var58 = var56.getBaseOutlineStroke();
//     var52.setOutlineStroke(var58);
//     org.jfree.chart.axis.CategoryAxis3D var60 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.util.RectangleEdge var64 = null;
//     double var65 = var60.getCategoryMiddle(1, 100, var63, var64);
//     org.jfree.chart.util.RectangleInsets var70 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var60.setLabelInsets(var70);
//     org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var50, var58, var70);
//     var38.setOutlinePaint((java.awt.Paint)var50);
//     boolean var74 = var13.equals((java.lang.Object)var38);
//     
//     // Checks the contract:  equals-hashcode on var1 and var38
//     assertTrue("Contract failed: equals-hashcode on var1 and var38", var1.equals(var38) ? var1.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var52
//     assertTrue("Contract failed: equals-hashcode on var15 and var52", var15.equals(var52) ? var15.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var1
//     assertTrue("Contract failed: equals-hashcode on var38 and var1", var38.equals(var1) ? var38.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var15
//     assertTrue("Contract failed: equals-hashcode on var52 and var15", var52.equals(var15) ? var52.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var53
//     assertTrue("Contract failed: equals-hashcode on var16 and var53", var16.equals(var53) ? var16.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var16
//     assertTrue("Contract failed: equals-hashcode on var53 and var16", var53.equals(var16) ? var53.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var72
//     assertTrue("Contract failed: equals-hashcode on var35 and var72", var35.equals(var72) ? var35.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var35
//     assertTrue("Contract failed: equals-hashcode on var72 and var35", var72.equals(var35) ? var72.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.awt.Stroke var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setBaseStroke(var7, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var2);
//     int var5 = var2.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var7 = var6.clone();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var6.getCategoryEnd(100, 1, var10, var11);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var18 = null;
//     var17.setBaseItemLabelFont(var18, true);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, (org.jfree.chart.axis.CategoryAxis)var6, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
//     org.jfree.data.Range var22 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     org.jfree.data.Range var24 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(10.0d, var24);
//     org.jfree.chart.block.LengthConstraintType var26 = var25.getWidthConstraintType();
//     org.jfree.data.time.DateRange var30 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     org.jfree.data.Range var32 = null;
//     org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(10.0d, var32);
//     org.jfree.chart.block.LengthConstraintType var34 = var33.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(0.05d, var22, var26, (-1.0d), (org.jfree.data.Range)var30, var34);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var36 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var38 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var37);
//     int var40 = var37.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var42 = var41.clone();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var41.getCategoryEnd(100, 1, var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var53 = null;
//     var52.setBaseItemLabelFont(var53, true);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var37, (org.jfree.chart.axis.CategoryAxis)var41, var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var52);
//     org.jfree.data.Range var57 = var36.findRangeBounds((org.jfree.data.category.CategoryDataset)var37);
//     org.jfree.chart.block.RectangleConstraint var58 = var35.toRangeHeight(var57);
//     
//     // Checks the contract:  equals-hashcode on var2 and var37
//     assertTrue("Contract failed: equals-hashcode on var2 and var37", var2.equals(var37) ? var2.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var2
//     assertTrue("Contract failed: equals-hashcode on var37 and var2", var37.equals(var2) ? var37.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var56
//     assertTrue("Contract failed: equals-hashcode on var21 and var56", var21.equals(var56) ? var21.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var21
//     assertTrue("Contract failed: equals-hashcode on var56 and var21", var56.equals(var21) ? var56.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.chart.renderer.category.AreaRenderer var2 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var2.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var7 = var2.getLegendItem(0, (-1));
//     boolean var8 = var2.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var10 = var9.getRotationAnchor();
//     java.lang.String var11 = var10.toString();
//     java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var16.getCategoryMiddle(1, 100, var19, var20);
//     java.awt.Stroke var22 = var16.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var24 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var26 = var25.getBaseStroke();
//     boolean var27 = var24.equals((java.lang.Object)var25);
//     java.awt.Paint var28 = var24.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var29 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var31 = var29.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var28, var31);
//     org.jfree.chart.renderer.category.LineRenderer3D var33 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var35 = var33.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var37 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var15, var22, var28, var35, 0.0f);
//     var37.setStartValue(100.0d);
//     org.jfree.chart.text.TextAnchor var40 = var37.getLabelTextAnchor();
//     org.jfree.chart.axis.DateTick var42 = new org.jfree.chart.axis.DateTick(var0, "", var10, var40, 8.0d);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0f, 2.0f, 1.0d, 0.5f, 0.5f);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)(byte)(-1));
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addValue(var8, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
//     boolean var5 = var4.isRangeCrosshairLockedOnData();
//     var4.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryMarker var9 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
//     boolean var10 = var9.getDrawAsLine();
//     org.jfree.chart.util.Layer var11 = null;
//     var4.addRangeMarker((org.jfree.chart.plot.Marker)var9, var11);
//     org.jfree.chart.text.TextAnchor var13 = var9.getLabelTextAnchor();
//     org.jfree.chart.renderer.category.AreaRenderer var15 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var17 = var15.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var20 = var15.getLegendItem(0, (-1));
//     boolean var21 = var15.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var22 = var15.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var23 = var22.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("TextAnchor.CENTER", var1, 100.0f, 0.0f, var13, 10.0d, var23);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.25d, 3.0d, var2);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var2 = var1.getBaseStroke();
//     var0.setAxisLineStroke(var2);
//     boolean var4 = var0.isTickLabelsVisible();
//     java.lang.Object var5 = var0.clone();
//     org.jfree.chart.axis.CategoryAnchor var6 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var9);
//     int var12 = var9.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var14 = var13.clone();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var13.getCategoryEnd(100, 1, var17, var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var25 = null;
//     var24.setBaseItemLabelFont(var25, true);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, (org.jfree.chart.axis.CategoryAxis)var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
//     var28.setWeight(1);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     org.jfree.chart.entity.EntityCollection var34 = var33.getEntityCollection();
//     java.awt.geom.Rectangle2D var35 = var33.getChartArea();
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot();
//     var36.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var39 = var36.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var40 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var28.draw(var31, var35, var39, var40, var41);
//     org.jfree.chart.axis.CategoryLabelPositions var44 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var45 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var46 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var45);
//     int var48 = var45.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var49 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var50 = var49.clone();
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     double var55 = var49.getCategoryEnd(100, 1, var53, var54);
//     org.jfree.chart.axis.ValueAxis var56 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var60 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var61 = null;
//     var60.setBaseItemLabelFont(var61, true);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var45, (org.jfree.chart.axis.CategoryAxis)var49, var56, (org.jfree.chart.renderer.category.CategoryItemRenderer)var60);
//     org.jfree.chart.util.RectangleEdge var66 = var64.getRangeAxisEdge(1);
//     org.jfree.chart.axis.CategoryLabelPosition var67 = var44.getLabelPosition(var66);
//     double var68 = var0.getCategoryJava2DCoordinate(var6, 2, 100, var35, var66);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
//     var1.setBaseSeriesVisibleInLegend(true);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var5);
//     int var8 = var5.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var10 = var9.clone();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var9.getCategoryEnd(100, 1, var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var21 = null;
//     var20.setBaseItemLabelFont(var21, true);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var9, var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(1);
//     org.jfree.chart.axis.AxisSpace var27 = var24.getFixedRangeAxisSpace();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var29 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var28);
//     int var31 = var28.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var33 = var32.clone();
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var32.getCategoryEnd(100, 1, var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var44 = null;
//     var43.setBaseItemLabelFont(var44, true);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, (org.jfree.chart.axis.CategoryAxis)var32, var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var43);
//     var47.setWeight(1);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.entity.EntityCollection var51 = null;
//     org.jfree.chart.ChartRenderingInfo var52 = new org.jfree.chart.ChartRenderingInfo(var51);
//     org.jfree.chart.entity.EntityCollection var53 = var52.getEntityCollection();
//     java.awt.geom.Rectangle2D var54 = var52.getChartArea();
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     var55.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var58 = var55.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var59 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     var47.draw(var50, var54, var58, var59, var60);
//     var1.drawOutline(var4, var24, var54);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.handleClick(0, 1, var6);
//     org.jfree.chart.event.PlotChangeListener var8 = null;
//     var1.addChangeListener(var8);
//     java.awt.Paint var10 = var1.getBaseSectionOutlinePaint();
//     org.jfree.data.general.PieDataset var11 = var1.getDataset();
//     double var12 = var1.getMaximumExplodePercent();
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.awt.Paint var3 = var0.lookupSeriesOutlinePaint(0);
    org.jfree.chart.urls.CategoryURLGenerator var4 = null;
    var0.setBaseURLGenerator(var4, true);
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var9 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var8);
    double var10 = var9.getBarWidth();
    org.jfree.chart.entity.EntityCollection var11 = null;
    org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo(var11);
    org.jfree.chart.entity.EntityCollection var13 = var12.getEntityCollection();
    java.awt.geom.Rectangle2D var14 = var12.getChartArea();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var15 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var16 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var15);
    int var18 = var15.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var20 = var19.clone();
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.util.RectangleEdge var24 = null;
    double var25 = var19.getCategoryEnd(100, 1, var23, var24);
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var30 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var31 = null;
    var30.setBaseItemLabelFont(var31, true);
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, (org.jfree.chart.axis.CategoryAxis)var19, var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setRangeAxisLocation(10, var36);
    boolean var38 = var34.getDrawSharedDomainAxis();
    org.jfree.chart.axis.CategoryAxis var39 = null;
    org.jfree.chart.axis.ValueAxis var40 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var45 = var44.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var46 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var47 = var44.findRangeBounds((org.jfree.data.category.CategoryDataset)var46);
    java.lang.Comparable var49 = null;
    java.lang.Number var50 = var46.getQ1Value((java.lang.Comparable)10.0d, var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var7, var9, var14, var34, var39, var40, (org.jfree.data.category.CategoryDataset)var46, (-1), 1, (-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + Double.NaN+ "'", var16.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
//     var1.zoom(0.0d);
//     boolean var5 = var1.getLabelLinksVisible();
//     var1.setIgnoreNullValues(true);
//     org.jfree.data.general.DatasetChangeEvent var8 = null;
//     var1.datasetChanged(var8);
//     java.lang.Comparable var10 = null;
//     double var11 = var1.getExplodePercent(var10);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var3 = var1.getTimeFromLong(0L);
//     long var5 = var1.toTimelineValue(100L);
//     var0.setBaseTimeline(var1);
//     var0.addBaseTimelineException((-1L));
//     java.util.Date var9 = null;
//     boolean var10 = var0.containsDomainValue(var9);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    java.lang.Object var2 = var0.clone();
    var0.setAutoPopulateSeriesFillPaint(true);
    java.awt.Paint var6 = var0.getSeriesItemLabelPaint(0);
    java.lang.Boolean var8 = var0.getSeriesShapesFilled(0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     var19.setDrawSharedDomainAxis(false);
//     var19.setRangeCrosshairVisible(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var28 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var29 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var28);
//     int var31 = var28.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var33 = var32.clone();
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var32.getCategoryEnd(100, 1, var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var43 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var44 = null;
//     var43.setBaseItemLabelFont(var44, true);
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, (org.jfree.chart.axis.CategoryAxis)var32, var39, (org.jfree.chart.renderer.category.CategoryItemRenderer)var43);
//     org.jfree.chart.axis.AxisLocation var49 = null;
//     var47.setRangeAxisLocation(10, var49);
//     org.jfree.chart.axis.ValueAxis var51 = var47.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var53 = var47.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var54 = var47.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var55 = null;
//     org.jfree.chart.event.ChartChangeEventType var56 = null;
//     org.jfree.chart.event.ChartChangeEvent var57 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var47, var55, var56);
//     org.jfree.chart.axis.AxisLocation var58 = var47.getRangeAxisLocation();
//     var19.setRangeAxisLocation(0, var58);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     java.awt.Paint var26 = null;
//     var25.setLabelShadowPaint(var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var25.handleClick(0, 1, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var25.addChangeListener(var32);
//     java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
//     var19.setRangeCrosshairPaint(var34);
//     boolean var36 = var19.isDomainZoomable();
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var38 = var37.clone();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var37.getCategoryStart(1, 0, var41, var42);
//     java.lang.String var45 = var37.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     java.awt.Color var49 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleEdge var54 = null;
//     double var55 = var50.getCategoryMiddle(1, 100, var53, var54);
//     java.awt.Stroke var56 = var50.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var58 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var59 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var60 = var59.getBaseStroke();
//     boolean var61 = var58.equals((java.lang.Object)var59);
//     java.awt.Paint var62 = var58.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var63 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var65 = var63.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var62, var65);
//     org.jfree.chart.renderer.category.LineRenderer3D var67 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var69 = var67.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var71 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var49, var56, var62, var69, 0.0f);
//     var37.setAxisLineStroke(var69);
//     org.jfree.data.general.PieDataset var73 = null;
//     org.jfree.chart.plot.PiePlot3D var74 = new org.jfree.chart.plot.PiePlot3D(var73);
//     java.awt.Paint var75 = null;
//     var74.setLabelShadowPaint(var75);
//     org.jfree.chart.plot.PlotRenderingInfo var79 = null;
//     var74.handleClick(0, 1, var79);
//     var37.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var74);
//     java.awt.Stroke var82 = var37.getTickMarkStroke();
//     java.util.List var83 = var19.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var37);
//     
//     // Checks the contract:  equals-hashcode on var25 and var74
//     assertTrue("Contract failed: equals-hashcode on var25 and var74", var25.equals(var74) ? var25.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var25
//     assertTrue("Contract failed: equals-hashcode on var74 and var25", var74.equals(var25) ? var74.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.AxisLabelEntity var5 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var2, "Multiple Pie Plot", "RectangleInsets[t=1.0,l=-1.0,b=1.0,r=8.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var2);
//     int var5 = var2.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var7 = var6.clone();
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var6.getCategoryEnd(100, 1, var10, var11);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var17 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var18 = null;
//     var17.setBaseItemLabelFont(var18, true);
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var2, (org.jfree.chart.axis.CategoryAxis)var6, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
//     org.jfree.data.Range var22 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     org.jfree.data.Range var24 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(10.0d, var24);
//     org.jfree.chart.block.LengthConstraintType var26 = var25.getWidthConstraintType();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var28 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var30 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var29);
//     int var32 = var29.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var33 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var34 = var33.clone();
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var33.getCategoryEnd(100, 1, var37, var38);
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var44 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var45 = null;
//     var44.setBaseItemLabelFont(var45, true);
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, (org.jfree.chart.axis.CategoryAxis)var33, var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
//     org.jfree.data.Range var49 = var28.findRangeBounds((org.jfree.data.category.CategoryDataset)var29);
//     double var50 = var49.getLength();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var52 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var53 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var54 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var53);
//     int var56 = var53.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var58 = var57.clone();
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var57.getCategoryEnd(100, 1, var61, var62);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var68 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var69 = null;
//     var68.setBaseItemLabelFont(var69, true);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var53, (org.jfree.chart.axis.CategoryAxis)var57, var64, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
//     org.jfree.data.Range var73 = var52.findRangeBounds((org.jfree.data.category.CategoryDataset)var53);
//     org.jfree.data.Range var75 = null;
//     org.jfree.chart.block.RectangleConstraint var76 = new org.jfree.chart.block.RectangleConstraint(10.0d, var75);
//     org.jfree.chart.block.LengthConstraintType var77 = var76.getWidthConstraintType();
//     org.jfree.data.time.DateRange var81 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     org.jfree.data.Range var83 = null;
//     org.jfree.chart.block.RectangleConstraint var84 = new org.jfree.chart.block.RectangleConstraint(10.0d, var83);
//     org.jfree.chart.block.LengthConstraintType var85 = var84.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var86 = new org.jfree.chart.block.RectangleConstraint(0.05d, var73, var77, (-1.0d), (org.jfree.data.Range)var81, var85);
//     org.jfree.chart.block.RectangleConstraint var87 = new org.jfree.chart.block.RectangleConstraint(8.0d, var22, var26, 0.0d, var49, var85);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var53
//     assertTrue("Contract failed: equals-hashcode on var2 and var53", var2.equals(var53) ? var2.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var53
//     assertTrue("Contract failed: equals-hashcode on var29 and var53", var29.equals(var53) ? var29.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var2
//     assertTrue("Contract failed: equals-hashcode on var53 and var2", var53.equals(var2) ? var53.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var29
//     assertTrue("Contract failed: equals-hashcode on var53 and var29", var53.equals(var29) ? var53.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var48
//     assertTrue("Contract failed: equals-hashcode on var21 and var48", var21.equals(var48) ? var21.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var72
//     assertTrue("Contract failed: equals-hashcode on var21 and var72", var21.equals(var72) ? var21.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var21
//     assertTrue("Contract failed: equals-hashcode on var48 and var21", var48.equals(var21) ? var48.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var72
//     assertTrue("Contract failed: equals-hashcode on var48 and var72", var48.equals(var72) ? var48.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var21
//     assertTrue("Contract failed: equals-hashcode on var72 and var21", var72.equals(var21) ? var72.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var48
//     assertTrue("Contract failed: equals-hashcode on var72 and var48", var72.equals(var48) ? var72.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(0, 1, var6);
    int var8 = var1.getPieIndex();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    int var13 = var10.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var15 = var14.clone();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var14.getCategoryEnd(100, 1, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var26 = null;
    var25.setBaseItemLabelFont(var26, true);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, (org.jfree.chart.axis.CategoryAxis)var14, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.axis.AxisLocation var31 = null;
    var29.setRangeAxisLocation(10, var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var35 = var34.clone();
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var34.getCategoryStart(1, 0, var38, var39);
    java.lang.String var42 = var34.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    var29.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var34);
    java.awt.Paint var44 = var34.getLabelPaint();
    var1.setSectionOutlinePaint((java.lang.Comparable)(-2208927599990L), var44);
    java.awt.Graphics2D var46 = null;
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var47 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var48 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var47);
    int var50 = var47.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var52 = var51.clone();
    java.awt.geom.Rectangle2D var55 = null;
    org.jfree.chart.util.RectangleEdge var56 = null;
    double var57 = var51.getCategoryEnd(100, 1, var55, var56);
    org.jfree.chart.axis.ValueAxis var58 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var62 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var63 = null;
    var62.setBaseItemLabelFont(var63, true);
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var47, (org.jfree.chart.axis.CategoryAxis)var51, var58, (org.jfree.chart.renderer.category.CategoryItemRenderer)var62);
    var66.setWeight(1);
    java.awt.Graphics2D var69 = null;
    org.jfree.chart.entity.EntityCollection var70 = null;
    org.jfree.chart.ChartRenderingInfo var71 = new org.jfree.chart.ChartRenderingInfo(var70);
    org.jfree.chart.entity.EntityCollection var72 = var71.getEntityCollection();
    java.awt.geom.Rectangle2D var73 = var71.getChartArea();
    org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot();
    var74.setDomainCrosshairVisible(true);
    java.awt.geom.Point2D var77 = var74.getQuadrantOrigin();
    org.jfree.chart.plot.PlotState var78 = new org.jfree.chart.plot.PlotState();
    org.jfree.chart.plot.PlotRenderingInfo var79 = null;
    var66.draw(var69, var73, var77, var78, var79);
    org.jfree.data.general.PieDataset var81 = null;
    org.jfree.chart.plot.PiePlot3D var82 = new org.jfree.chart.plot.PiePlot3D(var81);
    org.jfree.chart.labels.PieSectionLabelGenerator var83 = var82.getLabelGenerator();
    java.awt.Font var84 = var82.getLabelFont();
    java.lang.Integer var85 = null;
    org.jfree.chart.plot.PlotRenderingInfo var86 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var87 = var1.initialise(var46, var73, (org.jfree.chart.plot.PiePlot)var82, var85, var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + Double.NaN+ "'", var48.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(68);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)(byte)(-1));
    java.lang.String var8 = var4.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     boolean var23 = var19.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
//     boolean var25 = var19.isDomainZoomable();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var26);
//     org.jfree.chart.plot.MultiplePiePlot var28 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var26);
//     org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var31.getBaseOutlineStroke();
//     java.lang.Object var33 = var31.clone();
//     double var34 = var31.getYOffset();
//     java.awt.Font var37 = var31.getItemLabelFont(1, 100);
//     java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var42.getCategoryMiddle(1, 100, var45, var46);
//     java.awt.Stroke var48 = var42.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var50 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var52 = var51.getBaseStroke();
//     boolean var53 = var50.equals((java.lang.Object)var51);
//     java.awt.Paint var54 = var50.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var55 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var57 = var55.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var54, var57);
//     org.jfree.chart.renderer.category.LineRenderer3D var59 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var61 = var59.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var63 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var41, var48, var54, var61, 0.0f);
//     org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("October", var37, var54);
//     java.awt.Color var68 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var37, (java.awt.Paint)var68);
//     boolean var70 = var28.equals((java.lang.Object)var37);
//     var19.setParent((org.jfree.chart.plot.Plot)var28);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
//     double var4 = var3.getYOffset();
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
//     java.lang.Comparable var8 = null;
//     java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
//     java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
//     org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, 0);
//     double var14 = var5.getRangeUpperBound(true);
//     org.jfree.data.Range var16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var5, true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var19 = var5.getMaxOutlier((-16777216), 68);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var2 = var1.getBaseOutlineStroke();
//     java.lang.Object var3 = var1.clone();
//     org.jfree.chart.event.RendererChangeEvent var4 = new org.jfree.chart.event.RendererChangeEvent(var3);
//     var0.rendererChanged(var4);
//     java.lang.String var6 = var0.getPlotType();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     double var8 = var7.getRangeCrosshairValue();
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.category.LineRenderer3D var10 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var11 = var10.getBaseOutlineStroke();
//     java.lang.Object var12 = var10.clone();
//     org.jfree.chart.event.RendererChangeEvent var13 = new org.jfree.chart.event.RendererChangeEvent(var12);
//     var9.rendererChanged(var13);
//     var7.rendererChanged(var13);
//     var0.rendererChanged(var13);
//     
//     // Checks the contract:  equals-hashcode on var0 and var9
//     assertTrue("Contract failed: equals-hashcode on var0 and var9", var0.equals(var9) ? var0.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var0
//     assertTrue("Contract failed: equals-hashcode on var9 and var0", var9.equals(var0) ? var9.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    var0.setAxisLineStroke(var2);
    var0.setLabelURL("");
    org.jfree.chart.util.RectangleInsets var6 = var0.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.statistics.BoxAndWhiskerItem var3 = var0.getItem(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var0.getCategoryStart(1, 0, var4, var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
    java.awt.Stroke var19 = var13.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    boolean var24 = var21.equals((java.lang.Object)var22);
    java.awt.Paint var25 = var21.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
    org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
    var0.setAxisLineStroke(var32);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
    java.awt.Paint var38 = null;
    var37.setLabelShadowPaint(var38);
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    var37.handleClick(0, 1, var42);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
    java.lang.String var45 = var37.getPlotType();
    org.jfree.chart.labels.PieSectionLabelGenerator var46 = var37.getLabelGenerator();
    org.jfree.chart.labels.PieToolTipGenerator var47 = var37.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + "Pie 3D Plot"+ "'", var45.equals("Pie 3D Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    java.lang.Comparable var7 = null;
    var0.add((-100.0d), 0.0d, (java.lang.Comparable)"Polar Plot", var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
//     var3.setSeriesItemLabelGenerator(2, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var8 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var8);
//     int var11 = var8.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var13 = var12.clone();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var12.getCategoryEnd(100, 1, var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var23 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var24 = null;
//     var23.setBaseItemLabelFont(var24, true);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, (org.jfree.chart.axis.CategoryAxis)var12, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.axis.AxisLocation var29 = null;
//     var27.setRangeAxisLocation(10, var29);
//     boolean var31 = var27.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var32 = var27.getDomainAxisLocation();
//     boolean var33 = var27.isDomainZoomable();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var35 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var34);
//     int var37 = var34.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var39 = var38.clone();
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var38.getCategoryEnd(100, 1, var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var50 = null;
//     var49.setBaseItemLabelFont(var50, true);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, (org.jfree.chart.axis.CategoryAxis)var38, var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
//     var53.setWeight(1);
//     java.awt.Graphics2D var56 = null;
//     org.jfree.chart.entity.EntityCollection var57 = null;
//     org.jfree.chart.ChartRenderingInfo var58 = new org.jfree.chart.ChartRenderingInfo(var57);
//     org.jfree.chart.entity.EntityCollection var59 = var58.getEntityCollection();
//     java.awt.geom.Rectangle2D var60 = var58.getChartArea();
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     var61.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var64 = var61.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var65 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     var53.draw(var56, var60, var64, var65, var66);
//     var3.drawBackground(var7, var27, var60);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var6.getCategoryMiddle(1, 100, var9, var10);
    java.awt.Stroke var12 = var6.getTickMarkStroke();
    java.awt.Font var13 = var6.getLabelFont();
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var13);
    java.awt.Font var15 = var14.getFont();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var17);
    int var20 = var17.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var22 = var21.clone();
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var21.getCategoryEnd(100, 1, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var33 = null;
    var32.setBaseItemLabelFont(var33, true);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.util.RectangleEdge var38 = var36.getRangeAxisEdge(1);
    java.awt.Font var39 = var36.getNoDataMessageFont();
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var39);
    var14.setFont(var39);
    org.jfree.chart.axis.MarkerAxisBand var42 = new org.jfree.chart.axis.MarkerAxisBand(var0, 0.05d, 8.0d, 0.0d, Double.NaN, var39);
    org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine();
    org.jfree.chart.text.TextFragment var45 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    float var46 = var45.getBaselineOffset();
    boolean var48 = var45.equals((java.lang.Object)'a');
    var43.removeFragment(var45);
    boolean var50 = var42.equals((java.lang.Object)var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + Double.NaN+ "'", var18.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 0.05d, true);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("RectangleInsets[t=1.0,l=-1.0,b=1.0,r=8.0]", "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     double var1 = var0.getRangeCrosshairValue();
//     org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var4 = var3.getBaseOutlineStroke();
//     java.lang.Object var5 = var3.clone();
//     org.jfree.chart.event.RendererChangeEvent var6 = new org.jfree.chart.event.RendererChangeEvent(var5);
//     var2.rendererChanged(var6);
//     var0.rendererChanged(var6);
//     org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.0d);
//     var0.addDomainMarker((org.jfree.chart.plot.Marker)var11);
//     java.lang.Class var13 = null;
//     java.util.EventListener[] var14 = var11.getListeners(var13);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
    org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    boolean var27 = var26.isRangeCrosshairLockedOnData();
    var26.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
    boolean var32 = var31.getDrawAsLine();
    org.jfree.chart.util.Layer var33 = null;
    var26.addRangeMarker((org.jfree.chart.plot.Marker)var31, var33);
    org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var37 = var36.getBaseOutlineStroke();
    java.lang.Object var38 = var36.clone();
    double var39 = var36.getYOffset();
    java.awt.Font var42 = var36.getItemLabelFont(1, 100);
    java.awt.Color var46 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var50 = null;
    org.jfree.chart.util.RectangleEdge var51 = null;
    double var52 = var47.getCategoryMiddle(1, 100, var50, var51);
    java.awt.Stroke var53 = var47.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var57 = var56.getBaseStroke();
    boolean var58 = var55.equals((java.lang.Object)var56);
    java.awt.Paint var59 = var55.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var60 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var62 = var60.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var59, var62);
    org.jfree.chart.renderer.category.LineRenderer3D var64 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var66 = var64.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var68 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var46, var53, var59, var66, 0.0f);
    org.jfree.chart.text.TextFragment var69 = new org.jfree.chart.text.TextFragment("October", var42, var59);
    boolean var70 = var31.equals((java.lang.Object)var69);
    org.jfree.chart.util.Layer var71 = null;
    var19.addRangeMarker((org.jfree.chart.plot.Marker)var31, var71);
    org.jfree.chart.axis.CategoryAnchor var73 = var19.getDomainGridlinePosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     java.lang.Number var9 = var6.getEndValue((java.lang.Comparable)0L, (java.lang.Comparable)"WMAP_Plot");
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)(byte)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getValue((java.lang.Comparable)"RectangleInsets[t=1.0,l=-1.0,b=1.0,r=8.0]");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("TextAnchor.CENTER", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    java.lang.String var5 = var0.getPlotType();
    org.jfree.chart.axis.ValueAxis var6 = var0.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "XY Plot"+ "'", var5.equals("XY Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var2 = var0.getValue(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var2 = var0.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.category.AreaRenderer var4 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var5 = var4.getEndType();
//     java.awt.Stroke var6 = var4.getBaseOutlineStroke();
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var9 = var8.clone();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var8.getCategoryStart(1, 0, var12, var13);
//     java.lang.String var16 = var8.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     java.awt.Color var20 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var21.getCategoryMiddle(1, 100, var24, var25);
//     java.awt.Stroke var27 = var21.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var29 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var30 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var31 = var30.getBaseStroke();
//     boolean var32 = var29.equals((java.lang.Object)var30);
//     java.awt.Paint var33 = var29.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var34 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var36 = var34.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var37 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var33, var36);
//     org.jfree.chart.renderer.category.LineRenderer3D var38 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var40 = var38.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var20, var27, var33, var40, 0.0f);
//     var8.setAxisLineStroke(var40);
//     org.jfree.chart.renderer.category.LineRenderer3D var44 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var45 = var44.getBaseOutlineStroke();
//     java.lang.Object var46 = var44.clone();
//     double var47 = var44.getYOffset();
//     java.awt.Font var50 = var44.getItemLabelFont(1, 100);
//     var8.setLabelFont(var50);
//     var4.setSeriesItemLabelFont(100, var50, true);
//     var0.setSeriesItemLabelFont(100, var50, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var0.", var34.equals(var0) == var0.equals(var34));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var38 and var0.", var38.equals(var0) == var0.equals(var38));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var44 and var0.", var44.equals(var0) == var0.equals(var44));
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var22 = var0.getValue(2, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var2 = var1.getBaseStroke();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     java.awt.Paint var4 = var0.getBaseOutlinePaint();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     int var9 = var6.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var11 = var10.clone();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.getCategoryEnd(100, 1, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var22 = null;
//     var21.setBaseItemLabelFont(var22, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setRangeAxisLocation(10, var27);
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var31 = var30.clone();
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var30.getCategoryStart(1, 0, var34, var35);
//     java.lang.String var38 = var30.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     var25.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var30);
//     java.awt.geom.Rectangle2D var40 = null;
//     var0.drawBackground(var5, var25, var40);
// 
//   }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     java.lang.Object var2 = var0.clone();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var4);
//     int var7 = var4.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var9 = var8.clone();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var8.getCategoryEnd(100, 1, var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var20 = null;
//     var19.setBaseItemLabelFont(var20, true);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, (org.jfree.chart.axis.CategoryAxis)var8, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     org.jfree.chart.axis.ValueAxis var25 = var23.getRangeAxisForDataset(1);
//     org.jfree.chart.entity.EntityCollection var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo(var26);
//     org.jfree.chart.entity.EntityCollection var28 = var27.getEntityCollection();
//     java.awt.geom.Rectangle2D var29 = var27.getChartArea();
//     var0.drawOutline(var3, var23, var29);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var20.getCategoryMiddle(1, 100, var23, var24);
//     org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var20.setLabelInsets(var30);
//     var4.setLabelInsets(var30);
//     double var34 = var30.calculateBottomOutset(10.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var37 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var36);
//     int var39 = var36.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var41 = var40.clone();
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var40.getCategoryEnd(100, 1, var44, var45);
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var51 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var52 = null;
//     var51.setBaseItemLabelFont(var52, true);
//     org.jfree.chart.plot.CategoryPlot var55 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var36, (org.jfree.chart.axis.CategoryAxis)var40, var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
//     org.jfree.chart.util.RectangleEdge var57 = var55.getRangeAxisEdge(1);
//     java.awt.Font var58 = var55.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var58);
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     java.awt.geom.Rectangle2D var63 = var30.createOutsetRectangle(var60, false, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     java.lang.Number var12 = var6.getValue(0, 2);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    var14.setBorderVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var26 = var14.getSubtitle(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(0);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var11 = var9.calculateRightOutset(8.0d);
    var4.setMargin(var9);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D(var13);
    java.awt.Paint var15 = null;
    var14.setLabelShadowPaint(var15);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    var14.handleClick(0, 1, var19);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var14.addChangeListener(var21);
    org.jfree.chart.event.PlotChangeEvent var23 = null;
    var14.notifyListeners(var23);
    java.awt.Color var26 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot3D var28 = new org.jfree.chart.plot.PiePlot3D(var27);
    org.jfree.chart.labels.PieSectionLabelGenerator var29 = var28.getLabelGenerator();
    var28.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var32 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var33 = var32.getEndType();
    java.awt.Stroke var34 = var32.getBaseOutlineStroke();
    var28.setOutlineStroke(var34);
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var36.getCategoryMiddle(1, 100, var39, var40);
    org.jfree.chart.util.RectangleInsets var46 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var36.setLabelInsets(var46);
    org.jfree.chart.block.LineBorder var48 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var26, var34, var46);
    var14.setOutlinePaint((java.awt.Paint)var26);
    org.jfree.chart.block.BlockBorder var50 = new org.jfree.chart.block.BlockBorder(var9, (java.awt.Paint)var26);
    java.awt.Color var51 = var26.brighter();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var52 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var53 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var52);
    int var55 = var52.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var57 = var56.clone();
    java.awt.geom.Rectangle2D var60 = null;
    org.jfree.chart.util.RectangleEdge var61 = null;
    double var62 = var56.getCategoryEnd(100, 1, var60, var61);
    org.jfree.chart.axis.ValueAxis var63 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var68 = null;
    var67.setBaseItemLabelFont(var68, true);
    org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var52, (org.jfree.chart.axis.CategoryAxis)var56, var63, (org.jfree.chart.renderer.category.CategoryItemRenderer)var67);
    org.jfree.chart.axis.AxisLocation var73 = null;
    var71.setRangeAxisLocation(10, var73);
    boolean var75 = var71.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var76 = var71.getDomainAxisLocation();
    boolean var77 = var71.isDomainZoomable();
    java.awt.Stroke var78 = var71.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var83 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var85 = var83.calculateRightOutset(8.0d);
    org.jfree.chart.block.LineBorder var86 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var51, var78, var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesOutlinePaint((-1), (java.awt.Paint)var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + Double.NaN+ "'", var53.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 8.0d);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var27 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var28 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var27);
//     int var30 = var27.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var32 = var31.clone();
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleEdge var36 = null;
//     double var37 = var31.getCategoryEnd(100, 1, var35, var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var42 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var43 = null;
//     var42.setBaseItemLabelFont(var43, true);
//     org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, (org.jfree.chart.axis.CategoryAxis)var31, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var42);
//     org.jfree.chart.axis.AxisLocation var48 = null;
//     var46.setRangeAxisLocation(10, var48);
//     boolean var50 = var46.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var51 = var46.getDomainAxisLocation();
//     java.lang.String var52 = var51.toString();
//     org.jfree.chart.axis.AxisLocation var53 = org.jfree.chart.axis.AxisLocation.getOpposite(var51);
//     var19.setRangeAxisLocation(2, var51);
//     
//     // Checks the contract:  equals-hashcode on var0 and var27
//     assertTrue("Contract failed: equals-hashcode on var0 and var27", var0.equals(var27) ? var0.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var0
//     assertTrue("Contract failed: equals-hashcode on var27 and var0", var27.equals(var0) ? var27.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var20.getCategoryMiddle(1, 100, var23, var24);
//     org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var20.setLabelInsets(var30);
//     var4.setLabelInsets(var30);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var34 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var33);
//     int var36 = var33.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var38 = var37.clone();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var37.getCategoryEnd(100, 1, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var49 = null;
//     var48.setBaseItemLabelFont(var49, true);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, (org.jfree.chart.axis.CategoryAxis)var37, var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
//     org.jfree.chart.axis.AxisLocation var54 = null;
//     var52.setRangeAxisLocation(10, var54);
//     var52.setDrawSharedDomainAxis(false);
//     double var58 = var52.getRangeCrosshairValue();
//     boolean var59 = var4.hasListener((java.util.EventListener)var52);
//     
//     // Checks the contract:  equals-hashcode on var0 and var33
//     assertTrue("Contract failed: equals-hashcode on var0 and var33", var0.equals(var33) ? var0.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var5.getMaxOutlier(10, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0.0d+ "'", var7.equals(0.0d));

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var5.getQ1Value((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
    java.awt.Stroke var2 = var0.getBaseOutlineStroke();
    org.jfree.chart.axis.NumberAxis var3 = null;
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    float var10 = var9.getBaselineOffset();
    boolean var12 = var9.equals((java.lang.Object)'a');
    java.awt.Font var13 = var9.getFont();
    org.jfree.chart.axis.MarkerAxisBand var14 = new org.jfree.chart.axis.MarkerAxisBand(var3, (-1.0d), 0.2d, 10.0d, 0.25d, var13);
    var0.setBaseItemLabelFont(var13, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var3 = var1.getTimeFromLong(0L);
//     long var5 = var1.toTimelineValue(100L);
//     var0.setBaseTimeline(var1);
//     var0.addBaseTimelineException((-1L));
//     long var9 = var0.getSegmentsGroupSize();
//     java.util.Date var10 = null;
//     var0.addException(var10);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    var0.setDomainGridlinesVisible(false);
    var0.setDomainZeroBaselineVisible(false);
    boolean var6 = var0.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.ValueAxis var2 = null;
    int var3 = var0.getRangeAxisIndex(var2);
    var0.setRangeCrosshairValue(1.0d, false);
    java.awt.Font var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setNoDataMessageFont(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getAxis();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var3);
//     int var6 = var3.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var7.getCategoryEnd(100, 1, var11, var12);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var19 = null;
//     var18.setBaseItemLabelFont(var19, true);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, (org.jfree.chart.axis.CategoryAxis)var7, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setRangeAxisLocation(10, var24);
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var28 = var27.clone();
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.util.RectangleEdge var32 = null;
//     double var33 = var27.getCategoryStart(1, 0, var31, var32);
//     java.lang.String var35 = var27.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     var22.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var27);
//     java.awt.Paint var37 = var27.getLabelPaint();
//     var0.setAngleGridlinePaint(var37);
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var39.getRangeMarkers(1, var41);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var43 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var44 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var43);
//     int var46 = var43.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var48 = var47.clone();
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     double var53 = var47.getCategoryEnd(100, 1, var51, var52);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var58 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var59 = null;
//     var58.setBaseItemLabelFont(var59, true);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var43, (org.jfree.chart.axis.CategoryAxis)var47, var54, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setRangeAxisLocation(10, var64);
//     org.jfree.chart.axis.ValueAxis var66 = var62.getRangeAxis();
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot3D var68 = new org.jfree.chart.plot.PiePlot3D(var67);
//     java.awt.Paint var69 = null;
//     var68.setLabelShadowPaint(var69);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var68.handleClick(0, 1, var73);
//     org.jfree.chart.event.PlotChangeListener var75 = null;
//     var68.addChangeListener(var75);
//     java.awt.Paint var77 = var68.getBaseSectionOutlinePaint();
//     var62.setRangeCrosshairPaint(var77);
//     boolean var79 = var62.isDomainZoomable();
//     boolean var80 = var62.isDomainZoomable();
//     org.jfree.chart.renderer.category.LineRenderer3D var81 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var82 = var81.getBaseOutlineStroke();
//     java.lang.Object var83 = var81.clone();
//     org.jfree.chart.event.RendererChangeEvent var84 = new org.jfree.chart.event.RendererChangeEvent(var83);
//     org.jfree.chart.JFreeChart var85 = var84.getChart();
//     var62.rendererChanged(var84);
//     var39.rendererChanged(var84);
//     var0.rendererChanged(var84);
//     
//     // Checks the contract:  equals-hashcode on var3 and var43
//     assertTrue("Contract failed: equals-hashcode on var3 and var43", var3.equals(var43) ? var3.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var3
//     assertTrue("Contract failed: equals-hashcode on var43 and var3", var43.equals(var3) ? var43.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var4 = var3.getBaseOutlineStroke();
//     java.lang.Object var5 = var3.clone();
//     double var6 = var3.getYOffset();
//     java.awt.Font var9 = var3.getItemLabelFont(1, 100);
//     java.awt.Color var13 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var14.getCategoryMiddle(1, 100, var17, var18);
//     java.awt.Stroke var20 = var14.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var22 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var24 = var23.getBaseStroke();
//     boolean var25 = var22.equals((java.lang.Object)var23);
//     java.awt.Paint var26 = var22.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var27 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var29 = var27.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var30 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var26, var29);
//     org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var33 = var31.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var35 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var13, var20, var26, var33, 0.0f);
//     org.jfree.chart.text.TextFragment var36 = new org.jfree.chart.text.TextFragment("October", var9, var26);
//     java.awt.Color var40 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var41 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var9, (java.awt.Paint)var40);
//     org.jfree.chart.renderer.category.LineRenderer3D var44 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var45 = var44.getBaseOutlineStroke();
//     java.lang.Object var46 = var44.clone();
//     double var47 = var44.getYOffset();
//     java.awt.Font var50 = var44.getItemLabelFont(1, 100);
//     java.awt.Color var54 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var55 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var55.getCategoryMiddle(1, 100, var58, var59);
//     java.awt.Stroke var61 = var55.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var63 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var65 = var64.getBaseStroke();
//     boolean var66 = var63.equals((java.lang.Object)var64);
//     java.awt.Paint var67 = var63.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var68 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var70 = var68.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var67, var70);
//     org.jfree.chart.renderer.category.LineRenderer3D var72 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var74 = var72.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var76 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var54, var61, var67, var74, 0.0f);
//     org.jfree.chart.text.TextFragment var77 = new org.jfree.chart.text.TextFragment("October", var50, var67);
//     java.awt.Color var81 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var82 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var50, (java.awt.Paint)var81);
//     org.jfree.chart.text.TextMeasurer var84 = null;
//     org.jfree.chart.text.TextBlock var85 = org.jfree.chart.text.TextUtilities.createTextBlock("UnitType.ABSOLUTE", var9, (java.awt.Paint)var81, 10.0f, var84);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.entity.EntityCollection var2 = var1.getEntityCollection();
    java.awt.geom.Rectangle2D var3 = var1.getChartArea();
    org.jfree.chart.util.RectangleAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape)var3, var4, 100.0d, 8.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    java.lang.Object var2 = var0.clone();
    double var3 = var0.getYOffset();
    boolean var4 = var0.getDrawOutlines();
    var0.setUseFillPaint(false);
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, true);
//     java.awt.Color var7 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var8.getCategoryMiddle(1, 100, var11, var12);
//     java.awt.Stroke var14 = var8.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var18 = var17.getBaseStroke();
//     boolean var19 = var16.equals((java.lang.Object)var17);
//     java.awt.Paint var20 = var16.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var20, var23);
//     org.jfree.chart.renderer.category.LineRenderer3D var25 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var27 = var25.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var7, var14, var20, var27, 0.0f);
//     org.jfree.chart.renderer.category.AreaRenderer var30 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var35 = var30.getLegendItem(0, (-1));
//     boolean var36 = var30.getAutoPopulateSeriesFillPaint();
//     boolean var37 = var7.equals((java.lang.Object)var36);
//     var0.setWallPaint((java.awt.Paint)var7);
//     org.jfree.chart.renderer.category.LineRenderer3D var40 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var41 = var40.getBaseOutlineStroke();
//     java.lang.Object var42 = var40.clone();
//     var40.setAutoPopulateSeriesFillPaint(true);
//     var40.setAutoPopulateSeriesOutlineStroke(false);
//     java.awt.Color var50 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     double var56 = var51.getCategoryMiddle(1, 100, var54, var55);
//     java.awt.Stroke var57 = var51.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var59 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var61 = var60.getBaseStroke();
//     boolean var62 = var59.equals((java.lang.Object)var60);
//     java.awt.Paint var63 = var59.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var64 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var66 = var64.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var63, var66);
//     org.jfree.chart.renderer.category.LineRenderer3D var68 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var70 = var68.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var72 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var50, var57, var63, var70, 0.0f);
//     var40.setBaseStroke(var70, false);
//     var0.setSeriesOutlineStroke(1, var70, false);
//     
//     // Checks the contract:  equals-hashcode on var29 and var72
//     assertTrue("Contract failed: equals-hashcode on var29 and var72", var29.equals(var72) ? var29.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var29
//     assertTrue("Contract failed: equals-hashcode on var72 and var29", var72.equals(var29) ? var72.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    boolean var23 = var19.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
    java.lang.String var25 = var24.toString();
    org.jfree.chart.axis.AxisLocation var26 = org.jfree.chart.axis.AxisLocation.getOpposite(var24);
    java.lang.String var27 = var26.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var25.equals("AxisLocation.BOTTOM_OR_LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "AxisLocation.TOP_OR_RIGHT"+ "'", var27.equals("AxisLocation.TOP_OR_RIGHT"));

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.renderer.category.IntervalBarRenderer var0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    int var1 = var0.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
    java.lang.Comparable var3 = var2.getAggregatedItemsKey();
    double var4 = var2.getLimit();
    org.jfree.chart.util.ObjectList var5 = new org.jfree.chart.util.ObjectList();
    boolean var6 = var2.equals((java.lang.Object)var5);
    double var7 = var2.getLimit();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Other"+ "'", var3.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var1);
//     java.lang.Comparable var4 = var3.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var5 = var3.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5, var6);
//     org.jfree.chart.event.TitleChangeEvent var8 = null;
//     var5.titleChanged(var8);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     var19.setWeight(1);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     var19.handleClick(1, 10, var24);
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(100);
    var0.setAutoPopulateSeriesFillPaint(true);
    var0.setAutoPopulateSeriesOutlineStroke(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    org.jfree.data.KeyToGroupMap var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToGroupMap(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var44 = null;
//     java.awt.Shape var48 = var40.calculateBounds(var41, 0.0f, 1.0f, var44, (-1.0f), 0.5f, 0.0d);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    org.jfree.chart.entity.EntityCollection var26 = null;
    org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo(var26);
    org.jfree.chart.entity.EntityCollection var28 = var27.getEntityCollection();
    var27.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var30 = var14.createBufferedImage(0, 10, 1, var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)100.0f);
    java.util.List var3 = var0.getRowKeys();
    java.util.List var6 = var0.getOutliers((java.lang.Comparable)(byte)100, (java.lang.Comparable)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.statistics.BoxAndWhiskerItem var9 = var0.getItem(1, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     boolean var23 = var19.getDrawSharedDomainAxis();
//     org.jfree.chart.LegendItemCollection var24 = var19.getLegendItems();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var25);
//     org.jfree.chart.plot.MultiplePiePlot var27 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var25);
//     org.jfree.data.Range var29 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var25, 0.0d);
//     var19.setDataset((org.jfree.data.category.CategoryDataset)var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var42 = var40.calculateDimensions(var41);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var1 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var2 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var2);
//     org.jfree.chart.plot.MultiplePiePlot var4 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var2);
//     java.lang.Comparable var5 = var4.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var6 = var4.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var6, var7);
//     org.jfree.chart.block.BlockParams var9 = new org.jfree.chart.block.BlockParams();
//     boolean var10 = var9.getGenerateEntities();
//     var9.setGenerateEntities(true);
//     var9.setTranslateY(4.0d);
//     boolean var15 = var6.equals((java.lang.Object)4.0d);
//     org.jfree.chart.event.ChartChangeEventType var16 = null;
//     org.jfree.chart.event.ChartChangeEvent var17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)86400000L, var6, var16);
//     java.awt.Graphics2D var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var6.draw(var18, var19);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 100, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     float var2 = var1.getBaselineOffset();
//     boolean var4 = var1.equals((java.lang.Object)'a');
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var6 = null;
//     float var7 = var1.calculateBaselineOffset(var5, var6);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 0.25d, 0.05d, 1, (java.lang.Comparable)100L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "", var3);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(0);
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieToolTipGenerator var2 = var1.getToolTipGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var3 = var1.getLegendLabelGenerator();
    org.jfree.chart.plot.AbstractPieLabelDistributor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    java.awt.Paint var11 = null;
    var10.setLabelShadowPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var10.handleClick(0, 1, var15);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var10.addChangeListener(var17);
    org.jfree.chart.event.PlotChangeEvent var19 = null;
    var10.notifyListeners(var19);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var24.getLabelGenerator();
    var24.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var28 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var29 = var28.getEndType();
    java.awt.Stroke var30 = var28.getBaseOutlineStroke();
    var24.setOutlineStroke(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var32.getCategoryMiddle(1, 100, var35, var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var32.setLabelInsets(var42);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var30, var42);
    var10.setOutlinePaint((java.awt.Paint)var22);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var5, (java.awt.Paint)var22);
    java.awt.Color var47 = var22.brighter();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.axis.AxisLocation var69 = null;
    var67.setRangeAxisLocation(10, var69);
    boolean var71 = var67.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var72 = var67.getDomainAxisLocation();
    boolean var73 = var67.isDomainZoomable();
    java.awt.Stroke var74 = var67.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var79 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var81 = var79.calculateRightOutset(8.0d);
    org.jfree.chart.block.LineBorder var82 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var47, var74, var79);
    org.jfree.chart.entity.EntityCollection var83 = null;
    org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo(var83);
    org.jfree.chart.entity.EntityCollection var85 = var84.getEntityCollection();
    java.awt.geom.Rectangle2D var86 = var84.getChartArea();
    java.awt.geom.Rectangle2D var87 = var79.createInsetRectangle(var86);
    org.jfree.chart.renderer.category.LineRenderer3D var88 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var89 = var88.getBaseURLGenerator();
    java.lang.Boolean var91 = var88.getSeriesLinesVisible(100);
    java.awt.Paint var93 = var88.lookupSeriesPaint(100);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var86, var93);
    java.awt.Shape var97 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var94.setLine(var97);
    java.awt.Shape var99 = var94.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(10.0d, (-1.0d));
    double var3 = var2.getWidth();
    double var4 = var2.getHeight();
    var2.setWidth(8.0d);
    double var7 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1.0d));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var1 = var0.getColumnKeys();
    var0.removeColumn((java.lang.Comparable)86400000L);
    java.lang.Comparable var4 = null;
    org.jfree.data.KeyedObjects var5 = new org.jfree.data.KeyedObjects();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var10 = var7.getEndOfCurrentMonth(var9);
    java.lang.Object var11 = var5.getObject((java.lang.Comparable)var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(var4, (java.lang.Comparable)var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     var0.setRangeAxis(100, var3);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     var0.handleClick(0, (-1), var7);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var10 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var12 = var11.getBaseStroke();
    boolean var13 = var10.equals((java.lang.Object)var11);
    java.awt.Paint var14 = var11.getBasePaint();
    var0.setSeriesFillPaint(0, var14, false);
    var0.setSeriesVisibleInLegend(2, (java.lang.Boolean)true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     var19.setWeight(1);
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     var19.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
//     java.awt.Color var29 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var30.getCategoryMiddle(1, 100, var33, var34);
//     java.awt.Stroke var36 = var30.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var38 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var40 = var39.getBaseStroke();
//     boolean var41 = var38.equals((java.lang.Object)var39);
//     java.awt.Paint var42 = var38.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var43 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var45 = var43.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var46 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var42, var45);
//     org.jfree.chart.renderer.category.LineRenderer3D var47 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var49 = var47.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var51 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var29, var36, var42, var49, 0.0f);
//     org.jfree.chart.renderer.category.AreaRenderer var52 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var54 = var52.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var57 = var52.getLegendItem(0, (-1));
//     boolean var58 = var52.getAutoPopulateSeriesFillPaint();
//     boolean var59 = var29.equals((java.lang.Object)var58);
//     java.awt.Color var60 = var29.darker();
//     var19.setRangeGridlinePaint((java.awt.Paint)var60);
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var65 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var66 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var65);
//     int var68 = var65.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var69 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var70 = var69.clone();
//     java.awt.geom.Rectangle2D var73 = null;
//     org.jfree.chart.util.RectangleEdge var74 = null;
//     double var75 = var69.getCategoryEnd(100, 1, var73, var74);
//     org.jfree.chart.axis.ValueAxis var76 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var80 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var81 = null;
//     var80.setBaseItemLabelFont(var81, true);
//     org.jfree.chart.plot.CategoryPlot var84 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var65, (org.jfree.chart.axis.CategoryAxis)var69, var76, (org.jfree.chart.renderer.category.CategoryItemRenderer)var80);
//     var84.setWeight(1);
//     java.awt.Graphics2D var87 = null;
//     org.jfree.chart.entity.EntityCollection var88 = null;
//     org.jfree.chart.ChartRenderingInfo var89 = new org.jfree.chart.ChartRenderingInfo(var88);
//     org.jfree.chart.entity.EntityCollection var90 = var89.getEntityCollection();
//     java.awt.geom.Rectangle2D var91 = var89.getChartArea();
//     org.jfree.chart.plot.XYPlot var92 = new org.jfree.chart.plot.XYPlot();
//     var92.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var95 = var92.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var96 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var97 = null;
//     var84.draw(var87, var91, var95, var96, var97);
//     var19.zoomDomainAxes(0.0d, 3.0d, var64, var95);
//     
//     // Checks the contract:  equals-hashcode on var0 and var65
//     assertTrue("Contract failed: equals-hashcode on var0 and var65", var0.equals(var65) ? var0.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var0
//     assertTrue("Contract failed: equals-hashcode on var65 and var0", var65.equals(var0) ? var65.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getInteriorGap();
    org.jfree.data.general.PieDataset var3 = var1.getDataset();
    org.jfree.chart.util.PaintList var4 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var6 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var8 = var7.getBaseStroke();
    boolean var9 = var6.equals((java.lang.Object)var7);
    java.awt.Paint var10 = var7.getBasePaint();
    var4.setPaint(10, var10);
    var1.setLabelLinkPaint(var10);
    java.awt.Stroke var13 = var1.getLabelLinkStroke();
    java.awt.Color var15 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    java.awt.color.ColorSpace var16 = var15.getColorSpace();
    var1.setLabelOutlinePaint((java.awt.Paint)var15);
    float[] var21 = new float[] { (-1.0f), 10.0f, 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var22 = var15.getComponents(var21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.setDomainCrosshairVisible(true);
    java.awt.geom.Point2D var3 = var0.getQuadrantOrigin();
    boolean var4 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("({0}, {1}) = {3} - {4}", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var3 = var1.getTimeFromLong(0L);
    long var5 = var1.toTimelineValue(100L);
    var0.setBaseTimeline(var1);
    var0.addBaseTimelineException((-1L));
    long var9 = var0.getSegmentsGroupSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var11 = var0.getSegment(100L);
    var0.addException(25200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 644288400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 86400000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     java.util.Date var3 = var2.getLowerDate();
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3, var4);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var1 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var2 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var3 = var2.getBaseStroke();
//     boolean var4 = var1.equals((java.lang.Object)var2);
//     java.awt.Paint var5 = var1.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var6 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var8 = var6.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var5, var8);
//     java.awt.Paint var10 = var9.getPaint();
//     java.awt.Stroke var11 = var9.getOutlineStroke();
//     java.lang.Class var12 = null;
//     java.util.EventListener[] var13 = var9.getListeners(var12);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    org.jfree.chart.title.TextTitle var23 = var14.getTitle();
    org.jfree.chart.entity.EntityCollection var27 = null;
    org.jfree.chart.ChartRenderingInfo var28 = new org.jfree.chart.ChartRenderingInfo(var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var29 = var14.createBufferedImage(1, (-1), 10, var28);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     var0.setUseOutlinePaint(false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
//     org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
//     org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
//     java.lang.Comparable var13 = var12.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var14 = var12.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var15 = null;
//     org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var18 = var17.getBackgroundPaint();
//     java.lang.Object var19 = var17.clone();
//     org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
//     var14.setTitle(var17);
//     var8.setChart(var14);
//     org.jfree.chart.title.TextTitle var23 = var14.getTitle();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var24);
//     int var27 = var24.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var29 = var28.clone();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var28.getCategoryEnd(100, 1, var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var40 = null;
//     var39.setBaseItemLabelFont(var40, true);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var28, var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.util.RectangleEdge var45 = var43.getRangeAxisEdge(1);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var47 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var48 = var47.getBaseStroke();
//     boolean var49 = var46.equals((java.lang.Object)var47);
//     boolean var50 = var45.equals((java.lang.Object)var49);
//     var23.setPosition(var45);
//     
//     // Checks the contract:  equals-hashcode on var10 and var24
//     assertTrue("Contract failed: equals-hashcode on var10 and var24", var10.equals(var24) ? var10.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var10
//     assertTrue("Contract failed: equals-hashcode on var24 and var10", var24.equals(var10) ? var24.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("PlotOrientation.VERTICAL", "", var3);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     java.awt.Paint var26 = null;
//     var25.setLabelShadowPaint(var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var25.handleClick(0, 1, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var25.addChangeListener(var32);
//     java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
//     var19.setRangeCrosshairPaint(var34);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = null;
//     var39.setSeriesItemLabelGenerator(2, var41);
//     var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     boolean var45 = var44.isRangeCrosshairLockedOnData();
//     var44.setDomainGridlinesVisible(false);
//     org.jfree.chart.axis.AxisSpace var48 = null;
//     var44.setFixedDomainAxisSpace(var48);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var51 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var50);
//     int var53 = var50.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var55 = var54.clone();
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var54.getCategoryEnd(100, 1, var58, var59);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var66 = null;
//     var65.setBaseItemLabelFont(var66, true);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var50, (org.jfree.chart.axis.CategoryAxis)var54, var61, (org.jfree.chart.renderer.category.CategoryItemRenderer)var65);
//     org.jfree.chart.axis.AxisLocation var71 = null;
//     var69.setRangeAxisLocation(10, var71);
//     boolean var73 = var69.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var74 = var69.getDomainAxisLocation();
//     boolean var75 = var69.isDomainZoomable();
//     java.awt.Stroke var76 = var69.getDomainGridlineStroke();
//     var44.setDomainZeroBaselineStroke(var76);
//     var39.setBaseStroke(var76, false);
//     
//     // Checks the contract:  equals-hashcode on var0 and var50
//     assertTrue("Contract failed: equals-hashcode on var0 and var50", var0.equals(var50) ? var0.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var0
//     assertTrue("Contract failed: equals-hashcode on var50 and var0", var50.equals(var0) ? var50.hashCode() == var0.hashCode() : true);
// 
//   }

//  public void test302() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("October", var1);
//
//  }
//
  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    boolean var23 = var19.getDrawSharedDomainAxis();
    org.jfree.chart.LegendItemCollection var24 = var19.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.mapDatasetToRangeAxis((-1), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     var1.setDomainCrosshairVisible(true);
//     boolean var4 = var1.isRangeGridlinesVisible();
//     org.jfree.chart.JFreeChart var5 = new org.jfree.chart.JFreeChart("October", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     var5.setTitle(var6);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     var9.setDomainCrosshairVisible(true);
//     boolean var12 = var9.isRangeGridlinesVisible();
//     org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("October", (org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     var13.setTitle(var14);
//     var6.addChangeListener((org.jfree.chart.event.TitleChangeListener)var13);
//     
//     // Checks the contract:  equals-hashcode on var1 and var9
//     assertTrue("Contract failed: equals-hashcode on var1 and var9", var1.equals(var9) ? var1.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var1
//     assertTrue("Contract failed: equals-hashcode on var9 and var1", var9.equals(var1) ? var9.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var13
//     assertTrue("Contract failed: equals-hashcode on var5 and var13", var5.equals(var13) ? var5.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var5
//     assertTrue("Contract failed: equals-hashcode on var13 and var5", var13.equals(var5) ? var13.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     java.util.List var10 = var6.getColumnKeys();
//     java.lang.Comparable var12 = var6.getColumnKey(0);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    java.awt.Paint var11 = null;
    var10.setLabelShadowPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var10.handleClick(0, 1, var15);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var10.addChangeListener(var17);
    org.jfree.chart.event.PlotChangeEvent var19 = null;
    var10.notifyListeners(var19);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var24.getLabelGenerator();
    var24.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var28 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var29 = var28.getEndType();
    java.awt.Stroke var30 = var28.getBaseOutlineStroke();
    var24.setOutlineStroke(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var32.getCategoryMiddle(1, 100, var35, var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var32.setLabelInsets(var42);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var30, var42);
    var10.setOutlinePaint((java.awt.Paint)var22);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var5, (java.awt.Paint)var22);
    java.awt.Color var47 = var22.brighter();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.axis.AxisLocation var69 = null;
    var67.setRangeAxisLocation(10, var69);
    boolean var71 = var67.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var72 = var67.getDomainAxisLocation();
    boolean var73 = var67.isDomainZoomable();
    java.awt.Stroke var74 = var67.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var79 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var81 = var79.calculateRightOutset(8.0d);
    org.jfree.chart.block.LineBorder var82 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var47, var74, var79);
    org.jfree.chart.entity.EntityCollection var83 = null;
    org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo(var83);
    org.jfree.chart.entity.EntityCollection var85 = var84.getEntityCollection();
    java.awt.geom.Rectangle2D var86 = var84.getChartArea();
    java.awt.geom.Rectangle2D var87 = var79.createInsetRectangle(var86);
    org.jfree.chart.renderer.category.LineRenderer3D var88 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var89 = var88.getBaseURLGenerator();
    java.lang.Boolean var91 = var88.getSeriesLinesVisible(100);
    java.awt.Paint var93 = var88.lookupSeriesPaint(100);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var86, var93);
    java.awt.Shape var97 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var94.setLine(var97);
    boolean var99 = var94.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var99 == false);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    org.jfree.chart.util.HorizontalAlignment var2 = var0.getHorizontalAlignment();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var3.equals("HorizontalAlignment.CENTER"));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    java.awt.Paint var11 = null;
    var10.setLabelShadowPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var10.handleClick(0, 1, var15);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var10.addChangeListener(var17);
    org.jfree.chart.event.PlotChangeEvent var19 = null;
    var10.notifyListeners(var19);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var24.getLabelGenerator();
    var24.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var28 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var29 = var28.getEndType();
    java.awt.Stroke var30 = var28.getBaseOutlineStroke();
    var24.setOutlineStroke(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var32.getCategoryMiddle(1, 100, var35, var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var32.setLabelInsets(var42);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var30, var42);
    var10.setOutlinePaint((java.awt.Paint)var22);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var5, (java.awt.Paint)var22);
    java.awt.Color var47 = var22.brighter();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.axis.AxisLocation var69 = null;
    var67.setRangeAxisLocation(10, var69);
    boolean var71 = var67.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var72 = var67.getDomainAxisLocation();
    boolean var73 = var67.isDomainZoomable();
    java.awt.Stroke var74 = var67.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var79 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var81 = var79.calculateRightOutset(8.0d);
    org.jfree.chart.block.LineBorder var82 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var47, var74, var79);
    org.jfree.chart.entity.EntityCollection var83 = null;
    org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo(var83);
    org.jfree.chart.entity.EntityCollection var85 = var84.getEntityCollection();
    java.awt.geom.Rectangle2D var86 = var84.getChartArea();
    java.awt.geom.Rectangle2D var87 = var79.createInsetRectangle(var86);
    org.jfree.chart.renderer.category.LineRenderer3D var88 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var89 = var88.getBaseURLGenerator();
    java.lang.Boolean var91 = var88.getSeriesLinesVisible(100);
    java.awt.Paint var93 = var88.lookupSeriesPaint(100);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var86, var93);
    java.awt.Shape var97 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var94.setLine(var97);
    java.awt.Paint var99 = var94.getFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.data.general.PieDataset var3 = var1.getDataset();
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryStart(1, 0, var8, var9);
//     java.lang.String var12 = var4.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     java.awt.Color var16 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var17.getCategoryMiddle(1, 100, var20, var21);
//     java.awt.Stroke var23 = var17.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var25 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var27 = var26.getBaseStroke();
//     boolean var28 = var25.equals((java.lang.Object)var26);
//     java.awt.Paint var29 = var25.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var33 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var29, var32);
//     org.jfree.chart.renderer.category.LineRenderer3D var34 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var36 = var34.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var38 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var16, var23, var29, var36, 0.0f);
//     var4.setAxisLineStroke(var36);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D(var40);
//     java.awt.Paint var42 = null;
//     var41.setLabelShadowPaint(var42);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var41.handleClick(0, 1, var46);
//     var4.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var41);
//     java.awt.Stroke var49 = var4.getTickMarkStroke();
//     var1.setBaseSectionOutlineStroke(var49);
//     java.awt.Color var54 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var55 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var55.getCategoryMiddle(1, 100, var58, var59);
//     java.awt.Stroke var61 = var55.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var63 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var65 = var64.getBaseStroke();
//     boolean var66 = var63.equals((java.lang.Object)var64);
//     java.awt.Paint var67 = var63.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var68 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var70 = var68.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var67, var70);
//     org.jfree.chart.renderer.category.LineRenderer3D var72 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var74 = var72.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var76 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var54, var61, var67, var74, 0.0f);
//     var1.setLabelLinkPaint((java.awt.Paint)var54);
//     
//     // Checks the contract:  equals-hashcode on var38 and var76
//     assertTrue("Contract failed: equals-hashcode on var38 and var76", var38.equals(var76) ? var38.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var38
//     assertTrue("Contract failed: equals-hashcode on var76 and var38", var76.equals(var38) ? var76.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.RectangleEdge var21 = var19.getRangeAxisEdge(1);
    java.awt.Font var22 = var19.getNoDataMessageFont();
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    double var24 = var23.getRangeCrosshairValue();
    boolean var25 = var23.isRangeCrosshairLockedOnData();
    java.awt.Stroke var26 = var23.getDomainGridlineStroke();
    var19.setRangeGridlineStroke(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Polar Plot", var1, 0.0f, 0.0f, 0.0d, (-1.0f), 0.5f);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
    var0.setBaseLinesVisible(true);
    boolean var5 = var0.getItemShapeFilled(2, 2);
    boolean var7 = var0.isSeriesItemLabelsVisible(0);
    org.jfree.chart.block.Arrangement var8 = null;
    org.jfree.chart.block.Arrangement var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-16777216), (-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var1 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.ValueAxis var2 = var1.getAxis();
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var3 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var5.getCategoryMiddle(1, 100, var8, var9);
//     java.awt.Stroke var11 = var5.getTickMarkStroke();
//     java.awt.Font var12 = var5.getLabelFont();
//     var1.setAngleLabelFont(var12);
//     org.jfree.chart.util.PaintList var18 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var20 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var22 = var21.getBaseStroke();
//     boolean var23 = var20.equals((java.lang.Object)var21);
//     java.awt.Paint var24 = var20.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var25 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var27 = var25.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var24, var27);
//     boolean var29 = var18.equals((java.lang.Object)var27);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var31);
//     int var34 = var31.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var36 = var35.clone();
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var35.getCategoryEnd(100, 1, var39, var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var47 = null;
//     var46.setBaseItemLabelFont(var47, true);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var31, (org.jfree.chart.axis.CategoryAxis)var35, var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var50.setRangeAxisLocation(10, var52);
//     org.jfree.chart.axis.ValueAxis var54 = var50.getRangeAxis();
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot3D var56 = new org.jfree.chart.plot.PiePlot3D(var55);
//     java.awt.Paint var57 = null;
//     var56.setLabelShadowPaint(var57);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     var56.handleClick(0, 1, var61);
//     org.jfree.chart.event.PlotChangeListener var63 = null;
//     var56.addChangeListener(var63);
//     java.awt.Paint var65 = var56.getBaseSectionOutlinePaint();
//     var50.setRangeCrosshairPaint(var65);
//     var18.setPaint(0, var65);
//     org.jfree.chart.block.BlockBorder var68 = new org.jfree.chart.block.BlockBorder(0.2d, 3.0d, 0.0d, Double.NaN, var65);
//     org.jfree.chart.text.TextMeasurer var70 = null;
//     org.jfree.chart.text.TextBlock var71 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLocation.TOP_OR_RIGHT", var12, var65, 10.0f, var70);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)(byte)1, (java.lang.Number)(byte)(-1));

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     int var11 = var6.getColumnIndex((java.lang.Comparable)"Multiple Pie Plot");
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("AxisLocation.BOTTOM_OR_LEFT");

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.removeCornerTextItem("WMAP_Plot");
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     boolean var4 = var3.isDomainZoomable();
//     var3.setRadiusGridlinesVisible(true);
//     org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var8 = var7.getBaseOutlineStroke();
//     java.lang.Object var9 = var7.clone();
//     org.jfree.chart.event.RendererChangeEvent var10 = new org.jfree.chart.event.RendererChangeEvent(var9);
//     var3.rendererChanged(var10);
//     var0.rendererChanged(var10);
//     
//     // Checks the contract:  equals-hashcode on var0 and var3
//     assertTrue("Contract failed: equals-hashcode on var0 and var3", var0.equals(var3) ? var0.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var0
//     assertTrue("Contract failed: equals-hashcode on var3 and var0", var3.equals(var0) ? var3.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
//     org.jfree.chart.labels.PieToolTipGenerator var3 = null;
//     var1.setToolTipGenerator(var3);
//     var1.setMinimumArcAngleToDraw(100.0d);
//     java.awt.Color var9 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
//     org.jfree.chart.labels.PieSectionLabelGenerator var12 = var11.getLabelGenerator();
//     var11.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var15 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var16 = var15.getEndType();
//     java.awt.Stroke var17 = var15.getBaseOutlineStroke();
//     var11.setOutlineStroke(var17);
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.util.RectangleEdge var23 = null;
//     double var24 = var19.getCategoryMiddle(1, 100, var22, var23);
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var19.setLabelInsets(var29);
//     org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var9, var17, var29);
//     int var32 = var9.getTransparency();
//     java.awt.Color var33 = java.awt.Color.getColor("XY Plot", var9);
//     var1.setLabelOutlinePaint((java.awt.Paint)var9);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var2 = var0.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var5 = var0.getLegendItem(0, (-1));
    org.jfree.chart.renderer.AreaRendererEndType var6 = var0.getEndType();
    org.jfree.chart.plot.PolarPlot var7 = new org.jfree.chart.plot.PolarPlot();
    boolean var8 = var7.isDomainZoomable();
    org.jfree.chart.axis.ValueAxis var9 = var7.getAxis();
    var7.clearCornerTextItems();
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var7);
    org.jfree.chart.renderer.category.AreaRenderer var12 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var13 = var12.getEndType();
    java.awt.Paint var15 = var12.lookupSeriesOutlinePaint(0);
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var12.setBaseURLGenerator(var16, true);
    org.jfree.chart.renderer.category.AreaRenderer var19 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var19.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var24 = var19.getLegendItem(0, (-1));
    org.jfree.chart.renderer.AreaRendererEndType var25 = var19.getEndType();
    org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine();
    boolean var27 = var25.equals((java.lang.Object)var26);
    var12.setEndType(var25);
    org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    double var34 = var29.getCategoryMiddle(1, 100, var32, var33);
    java.awt.Stroke var35 = var29.getTickMarkStroke();
    var29.setCategoryMargin(0.0d);
    java.awt.Font var39 = var29.getTickLabelFont((java.lang.Comparable)2);
    boolean var40 = var25.equals((java.lang.Object)2);
    var0.setEndType(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.data.general.PieDataset var3 = var1.getDataset();
//     org.jfree.data.general.DatasetChangeEvent var4 = null;
//     var1.datasetChanged(var4);
//     int var6 = var1.getPieIndex();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleAnchor var10 = null;
//     java.awt.geom.Point2D var11 = org.jfree.chart.util.RectangleAnchor.coordinates(var9, var10);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var12);
//     int var15 = var12.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var17 = var16.clone();
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var16.getCategoryEnd(100, 1, var20, var21);
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var27 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var28 = null;
//     var27.setBaseItemLabelFont(var28, true);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var12, (org.jfree.chart.axis.CategoryAxis)var16, var23, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
//     var31.setWeight(1);
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.entity.EntityCollection var35 = null;
//     org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
//     org.jfree.chart.entity.EntityCollection var37 = var36.getEntityCollection();
//     java.awt.geom.Rectangle2D var38 = var36.getChartArea();
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     var39.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var42 = var39.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var43 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     var31.draw(var34, var38, var42, var43, var44);
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     var1.draw(var7, var8, var11, var43, var46);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(100);
    java.awt.Paint var5 = var0.lookupSeriesPaint(100);
    boolean var8 = var0.getItemShapeFilled(2, 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var5 = null;
    var1.setSeriesOutlinePaint(100, var5);
    double var7 = var1.getLowerClip();
    org.jfree.chart.renderer.category.AreaRenderer var9 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var9.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var14 = var9.getLegendItem(0, (-1));
    java.awt.Paint var16 = null;
    var9.setSeriesPaint(10, var16);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var19 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var9.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var19, true);
    java.lang.String var22 = var19.getLabelFormat();
    java.lang.String var23 = var19.getLabelFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesToolTipGenerator((-16777216), (org.jfree.chart.labels.CategoryToolTipGenerator)var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "({0}, {1}) = {3} - {4}"+ "'", var22.equals("({0}, {1}) = {3} - {4}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "({0}, {1}) = {3} - {4}"+ "'", var23.equals("({0}, {1}) = {3} - {4}"));

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var1);
    java.lang.Comparable var4 = var3.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var5 = var3.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5, var6);
    org.jfree.chart.block.BlockParams var8 = new org.jfree.chart.block.BlockParams();
    boolean var9 = var8.getGenerateEntities();
    var8.setGenerateEntities(true);
    var8.setTranslateY(4.0d);
    boolean var14 = var5.equals((java.lang.Object)4.0d);
    var5.removeLegend();
    org.jfree.chart.event.ChartChangeListener var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addChangeListener(var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Other"+ "'", var4.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.event.ChartChangeEventType var9 = null;
    var8.setType(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var0.getCategoryStart(1, 0, var4, var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
    java.awt.Stroke var19 = var13.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    boolean var24 = var21.equals((java.lang.Object)var22);
    java.awt.Paint var25 = var21.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
    org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
    var0.setAxisLinePaint(var25);
    org.jfree.data.general.PieDataset var36 = null;
    org.jfree.chart.plot.PiePlot3D var37 = new org.jfree.chart.plot.PiePlot3D(var36);
    org.jfree.chart.labels.PieSectionLabelGenerator var38 = var37.getLabelGenerator();
    var37.zoom(0.0d);
    boolean var41 = var37.getLabelLinksVisible();
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets();
    var37.setInsets(var42, true);
    double var46 = var42.calculateBottomInset(100.0d);
    double var47 = var42.getLeft();
    var0.setTickLabelInsets(var42);
    org.jfree.chart.plot.Plot var49 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryLabelEntity var4 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)"AxisLocation.TOP_OR_RIGHT", var1, "LegendItemEntity: seriesKey=null, dataset=null", "Pie 3D Plot");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var20.getCategoryMiddle(1, 100, var23, var24);
//     org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var20.setLabelInsets(var30);
//     var4.setLabelInsets(var30);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var35 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var36 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var35);
//     int var38 = var35.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var40 = var39.clone();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var39.getCategoryEnd(100, 1, var43, var44);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var51 = null;
//     var50.setBaseItemLabelFont(var51, true);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var35, (org.jfree.chart.axis.CategoryAxis)var39, var46, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
//     org.jfree.chart.axis.AxisLocation var56 = null;
//     var54.setRangeAxisLocation(10, var56);
//     org.jfree.chart.axis.ValueAxis var58 = var54.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var60 = var54.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var61 = var54.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var62 = null;
//     org.jfree.chart.event.ChartChangeEventType var63 = null;
//     org.jfree.chart.event.ChartChangeEvent var64 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var54, var62, var63);
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.entity.EntityCollection var66 = null;
//     org.jfree.chart.ChartRenderingInfo var67 = new org.jfree.chart.ChartRenderingInfo(var66);
//     org.jfree.chart.entity.EntityCollection var68 = var67.getEntityCollection();
//     java.awt.geom.Rectangle2D var69 = var67.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     boolean var72 = var54.render(var65, var69, 100, var71);
//     org.jfree.chart.axis.CategoryLabelPositions var74 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var75 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var76 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var75);
//     int var78 = var75.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var79 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var80 = var79.clone();
//     java.awt.geom.Rectangle2D var83 = null;
//     org.jfree.chart.util.RectangleEdge var84 = null;
//     double var85 = var79.getCategoryEnd(100, 1, var83, var84);
//     org.jfree.chart.axis.ValueAxis var86 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var90 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var91 = null;
//     var90.setBaseItemLabelFont(var91, true);
//     org.jfree.chart.plot.CategoryPlot var94 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var75, (org.jfree.chart.axis.CategoryAxis)var79, var86, (org.jfree.chart.renderer.category.CategoryItemRenderer)var90);
//     org.jfree.chart.util.RectangleEdge var96 = var94.getRangeAxisEdge(1);
//     org.jfree.chart.axis.CategoryLabelPosition var97 = var74.getLabelPosition(var96);
//     double var98 = var4.getCategoryStart(0, 100, var69, var96);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var75
//     assertTrue("Contract failed: equals-hashcode on var0 and var75", var0.equals(var75) ? var0.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var75
//     assertTrue("Contract failed: equals-hashcode on var35 and var75", var35.equals(var75) ? var35.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var0
//     assertTrue("Contract failed: equals-hashcode on var75 and var0", var75.equals(var0) ? var75.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var35
//     assertTrue("Contract failed: equals-hashcode on var75 and var35", var75.equals(var35) ? var75.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var94
//     assertTrue("Contract failed: equals-hashcode on var54 and var94", var54.equals(var94) ? var54.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var54
//     assertTrue("Contract failed: equals-hashcode on var94 and var54", var94.equals(var54) ? var94.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     boolean var23 = var19.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var26 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var25);
//     int var28 = var25.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var30 = var29.clone();
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var29.getCategoryEnd(100, 1, var33, var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var40 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var41 = null;
//     var40.setBaseItemLabelFont(var41, true);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var25, (org.jfree.chart.axis.CategoryAxis)var29, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
//     org.jfree.chart.util.RectangleEdge var46 = var44.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotOrientation var47 = var44.getOrientation();
//     org.jfree.chart.util.RectangleEdge var48 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var24, var47);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var44
//     assertTrue("Contract failed: equals-hashcode on var19 and var44", var19.equals(var44) ? var19.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var19
//     assertTrue("Contract failed: equals-hashcode on var44 and var19", var44.equals(var19) ? var44.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var3);
//     int var6 = var3.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var7.getCategoryEnd(100, 1, var11, var12);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var19 = null;
//     var18.setBaseItemLabelFont(var19, true);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, (org.jfree.chart.axis.CategoryAxis)var7, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setRangeAxisLocation(10, var24);
//     org.jfree.chart.axis.ValueAxis var26 = var22.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var28 = var22.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var29 = var22.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var30 = null;
//     org.jfree.chart.event.ChartChangeEventType var31 = null;
//     org.jfree.chart.event.ChartChangeEvent var32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var30, var31);
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.entity.EntityCollection var34 = null;
//     org.jfree.chart.ChartRenderingInfo var35 = new org.jfree.chart.ChartRenderingInfo(var34);
//     org.jfree.chart.entity.EntityCollection var36 = var35.getEntityCollection();
//     java.awt.geom.Rectangle2D var37 = var35.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     boolean var40 = var22.render(var33, var37, 100, var39);
//     org.jfree.chart.entity.ChartEntity var41 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var37);
//     java.awt.Point var42 = var0.translateValueThetaRadiusToJava2D(6.0d, (-100.0d), var37);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var6.getCategoryMiddle(1, 100, var9, var10);
    java.awt.Stroke var12 = var6.getTickMarkStroke();
    java.awt.Font var13 = var6.getLabelFont();
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var13);
    java.awt.Font var15 = var14.getFont();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var17);
    int var20 = var17.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var22 = var21.clone();
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var21.getCategoryEnd(100, 1, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var33 = null;
    var32.setBaseItemLabelFont(var33, true);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.util.RectangleEdge var38 = var36.getRangeAxisEdge(1);
    java.awt.Font var39 = var36.getNoDataMessageFont();
    org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var39);
    var14.setFont(var39);
    org.jfree.chart.axis.MarkerAxisBand var42 = new org.jfree.chart.axis.MarkerAxisBand(var0, 0.05d, 8.0d, 0.0d, Double.NaN, var39);
    java.awt.Graphics2D var43 = null;
    double var44 = var42.getHeight(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + Double.NaN+ "'", var18.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var5 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var6 = var5.getEndType();
    java.awt.Stroke var7 = var5.getBaseOutlineStroke();
    var1.setOutlineStroke(var7);
    java.lang.Object var9 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInteriorGap(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    var0.setAxisLineStroke(var2);
    var0.setAxisLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     java.lang.Comparable var7 = null;
//     int var8 = var6.indexOf(var7);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var22 = var0.getStdDevValue(68, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     int var11 = var6.indexOf((java.lang.Comparable)"Other");
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
//     double var4 = var3.getBarWidth();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     int var9 = var6.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var11 = var10.clone();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.getCategoryEnd(100, 1, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var22 = null;
//     var21.setBaseItemLabelFont(var22, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     org.jfree.chart.util.RectangleEdge var27 = var25.getRangeAxisEdge(1);
//     java.awt.Font var28 = var25.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var28);
//     java.awt.geom.Rectangle2D var30 = var29.getBounds();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var31);
//     int var34 = var31.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var36 = var35.clone();
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var35.getCategoryEnd(100, 1, var39, var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var47 = null;
//     var46.setBaseItemLabelFont(var47, true);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var31, (org.jfree.chart.axis.CategoryAxis)var35, var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var50.setRangeAxisLocation(10, var52);
//     org.jfree.chart.axis.ValueAxis var54 = var50.getRangeAxis();
//     java.awt.Graphics2D var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     boolean var59 = var50.render(var55, var56, 100, var58);
//     org.jfree.chart.axis.CategoryAxis3D var60 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.renderer.category.BarRenderer var61 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var62 = var61.getBaseStroke();
//     var60.setAxisLineStroke(var62);
//     boolean var64 = var60.isTickLabelsVisible();
//     java.lang.Object var65 = var60.clone();
//     float var66 = var60.getTickMarkOutsideLength();
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     java.lang.Comparable[] var68 = null;
//     java.lang.Comparable[] var70 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var71 = null;
//     java.lang.Number[][] var72 = new java.lang.Number[][] { var71};
//     java.lang.Number[][] var73 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var74 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var68, var70, var72, var73);
//     org.jfree.data.general.SeriesChangeEvent var75 = null;
//     var74.seriesChanged(var75);
//     java.util.List var77 = var74.getColumnKeys();
//     var0.drawItem(var1, var3, var30, var50, (org.jfree.chart.axis.CategoryAxis)var60, var67, (org.jfree.data.category.CategoryDataset)var74, 0, 1, 1);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2, var1);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var1 = var0.getBaseStroke();
    var0.setMaximumBarWidth(8.0d);
    var0.setItemLabelAnchorOffset(0.0d);
    java.awt.Font var7 = var0.getSeriesItemLabelFont(2);
    org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
    boolean var10 = var9.isDomainZoomable();
    java.awt.Color var14 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
    var9.setAngleLabelPaint((java.awt.Paint)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPaint((-1), (java.awt.Paint)var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleInsets[t=1.0,l=-1.0,b=1.0,r=8.0]", var1, 0.0f, 2.0f, Double.NaN, 0.0f, 10.0f);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var25 = var24.clone();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var24.getCategoryStart(1, 0, var28, var29);
//     java.lang.String var32 = var24.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     var19.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var24);
//     java.awt.Paint var34 = var24.getLabelPaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var35 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var36 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var35);
//     int var38 = var35.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var40 = var39.clone();
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var39.getCategoryEnd(100, 1, var43, var44);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var50 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var51 = null;
//     var50.setBaseItemLabelFont(var51, true);
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var35, (org.jfree.chart.axis.CategoryAxis)var39, var46, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
//     org.jfree.chart.axis.AxisLocation var56 = null;
//     var54.setRangeAxisLocation(10, var56);
//     org.jfree.chart.axis.ValueAxis var58 = var54.getRangeAxis();
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D(var59);
//     java.awt.Paint var61 = null;
//     var60.setLabelShadowPaint(var61);
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     var60.handleClick(0, 1, var65);
//     org.jfree.chart.event.PlotChangeListener var67 = null;
//     var60.addChangeListener(var67);
//     java.awt.Paint var69 = var60.getBaseSectionOutlinePaint();
//     var54.setRangeCrosshairPaint(var69);
//     var24.setTickLabelPaint(var69);
//     
//     // Checks the contract:  equals-hashcode on var0 and var35
//     assertTrue("Contract failed: equals-hashcode on var0 and var35", var0.equals(var35) ? var0.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var0
//     assertTrue("Contract failed: equals-hashcode on var35 and var0", var35.equals(var0) ? var35.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     double var2 = var0.getSeriesBarWidth((-16777216));
//     java.awt.Color var7 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var8.getCategoryMiddle(1, 100, var11, var12);
//     java.awt.Stroke var14 = var8.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var18 = var17.getBaseStroke();
//     boolean var19 = var16.equals((java.lang.Object)var17);
//     java.awt.Paint var20 = var16.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var20, var23);
//     org.jfree.chart.renderer.category.LineRenderer3D var25 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var27 = var25.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var7, var14, var20, var27, 0.0f);
//     org.jfree.chart.renderer.category.AreaRenderer var30 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var35 = var30.getLegendItem(0, (-1));
//     boolean var36 = var30.getAutoPopulateSeriesFillPaint();
//     boolean var37 = var7.equals((java.lang.Object)var36);
//     java.awt.Color var38 = var7.darker();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSeriesPaint((-1), (java.awt.Paint)var38, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryMiddle(1, 100, var4, var5);
//     java.awt.Stroke var7 = var1.getTickMarkStroke();
//     java.awt.Font var8 = var1.getLabelFont();
//     org.jfree.chart.block.LabelBlock var9 = new org.jfree.chart.block.LabelBlock("", var8);
//     org.jfree.chart.renderer.category.AreaRenderer var10 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var11 = var10.getEndType();
//     java.awt.Paint var13 = var10.lookupSeriesOutlinePaint(0);
//     var9.setPaint(var13);
//     org.jfree.chart.plot.PolarPlot var15 = new org.jfree.chart.plot.PolarPlot();
//     boolean var16 = var15.isDomainZoomable();
//     java.awt.Color var20 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     var15.setAngleLabelPaint((java.awt.Paint)var20);
//     var9.setPaint((java.awt.Paint)var20);
//     org.jfree.chart.renderer.category.AreaRenderer var23 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var28 = var23.getLegendItem(0, (-1));
//     java.awt.Paint var30 = null;
//     var23.setSeriesPaint(10, var30);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var33 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var23.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var33, true);
//     java.lang.String var36 = var33.getLabelFormat();
//     java.lang.String var37 = var33.getLabelFormat();
//     boolean var38 = var9.equals((java.lang.Object)var37);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var10 and var23.", var10.equals(var23) == var23.equals(var10));
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var7 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     double var9 = var7.calculateRightOutset(8.0d);
//     var2.setMargin(var7);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     java.awt.Paint var13 = null;
//     var12.setLabelShadowPaint(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     var12.handleClick(0, 1, var17);
//     org.jfree.chart.event.PlotChangeListener var19 = null;
//     var12.addChangeListener(var19);
//     org.jfree.chart.event.PlotChangeEvent var21 = null;
//     var12.notifyListeners(var21);
//     java.awt.Color var24 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D(var25);
//     org.jfree.chart.labels.PieSectionLabelGenerator var27 = var26.getLabelGenerator();
//     var26.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var30 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var31 = var30.getEndType();
//     java.awt.Stroke var32 = var30.getBaseOutlineStroke();
//     var26.setOutlineStroke(var32);
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var34.getCategoryMiddle(1, 100, var37, var38);
//     org.jfree.chart.util.RectangleInsets var44 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var34.setLabelInsets(var44);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var24, var32, var44);
//     var12.setOutlinePaint((java.awt.Paint)var24);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(var7, (java.awt.Paint)var24);
//     java.awt.Color var49 = var24.brighter();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var50 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var51 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var50);
//     int var53 = var50.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var55 = var54.clone();
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleEdge var59 = null;
//     double var60 = var54.getCategoryEnd(100, 1, var58, var59);
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var65 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var66 = null;
//     var65.setBaseItemLabelFont(var66, true);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var50, (org.jfree.chart.axis.CategoryAxis)var54, var61, (org.jfree.chart.renderer.category.CategoryItemRenderer)var65);
//     org.jfree.chart.axis.AxisLocation var71 = null;
//     var69.setRangeAxisLocation(10, var71);
//     boolean var73 = var69.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var74 = var69.getDomainAxisLocation();
//     boolean var75 = var69.isDomainZoomable();
//     java.awt.Stroke var76 = var69.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleInsets var81 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     double var83 = var81.calculateRightOutset(8.0d);
//     org.jfree.chart.block.LineBorder var84 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var49, var76, var81);
//     org.jfree.chart.entity.EntityCollection var85 = null;
//     org.jfree.chart.ChartRenderingInfo var86 = new org.jfree.chart.ChartRenderingInfo(var85);
//     org.jfree.chart.entity.EntityCollection var87 = var86.getEntityCollection();
//     java.awt.geom.Rectangle2D var88 = var86.getChartArea();
//     java.awt.geom.Rectangle2D var89 = var81.createInsetRectangle(var88);
//     org.jfree.chart.renderer.category.LineRenderer3D var90 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var91 = var90.getBaseURLGenerator();
//     java.lang.Boolean var93 = var90.getSeriesLinesVisible(100);
//     java.awt.Paint var95 = var90.lookupSeriesPaint(100);
//     org.jfree.chart.title.LegendGraphic var96 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var88, var95);
//     java.lang.Object var97 = null;
//     java.lang.Object var98 = var0.draw(var1, var88, var97);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("AxisLocation.TOP_OR_RIGHT", 0, (-1));
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getRowKey((-16777216));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    java.util.List var1 = var0.getColumnKeys();
    var0.removeColumn((java.lang.Comparable)86400000L);
    java.lang.Object var4 = var0.clone();
    int var6 = var0.getRowIndex((java.lang.Comparable)0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("Polar Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    var0.setAxisLineStroke(var2);
    boolean var4 = var0.isTickLabelsVisible();
    java.lang.Object var5 = var0.clone();
    boolean var6 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var3);
//     int var6 = var3.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var8 = var7.clone();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var7.getCategoryEnd(100, 1, var11, var12);
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var18 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var19 = null;
//     var18.setBaseItemLabelFont(var19, true);
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, (org.jfree.chart.axis.CategoryAxis)var7, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.util.RectangleEdge var24 = var22.getRangeAxisEdge(1);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var25 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var27 = var26.getBaseStroke();
//     boolean var28 = var25.equals((java.lang.Object)var26);
//     boolean var29 = var24.equals((java.lang.Object)var28);
//     double var30 = var0.valueToJava2D(0.0d, var2, var24);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
    java.awt.Color var7 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var8.getCategoryMiddle(1, 100, var11, var12);
    java.awt.Stroke var14 = var8.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var16 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var18 = var17.getBaseStroke();
    boolean var19 = var16.equals((java.lang.Object)var17);
    java.awt.Paint var20 = var16.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var24 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var20, var23);
    org.jfree.chart.renderer.category.LineRenderer3D var25 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var27 = var25.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var7, var14, var20, var27, 0.0f);
    org.jfree.chart.renderer.category.AreaRenderer var30 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var32 = var30.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var35 = var30.getLegendItem(0, (-1));
    boolean var36 = var30.getAutoPopulateSeriesFillPaint();
    boolean var37 = var7.equals((java.lang.Object)var36);
    float[] var41 = new float[] { 100.0f, 0.0f, 1.0f};
    float[] var42 = var7.getRGBColorComponents(var41);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var43 = var3.getRGBComponents(var42);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
    boolean var6 = var5.getDrawAsLine();
    org.jfree.chart.util.Layer var7 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5, var7);
    java.awt.Stroke var9 = var0.getRangeZeroBaselineStroke();
    int var10 = var0.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);

  }

  public void test357() {}
//   public void test357() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 0.0d);
//     java.lang.Number var7 = var0.getValue((java.lang.Comparable)(byte)10, (java.lang.Comparable)(-16777216));
//     double var9 = var0.getRangeUpperBound(true);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
//     org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
//     org.jfree.chart.LegendItemCollection var13 = var12.getLegendItems();
//     java.lang.Comparable var14 = var12.getAggregatedItemsKey();
//     boolean var15 = var0.hasListener((java.util.EventListener)var12);
//     
//     // Checks the contract:  equals-hashcode on var0 and var10
//     assertTrue("Contract failed: equals-hashcode on var0 and var10", var0.equals(var10) ? var0.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var0
//     assertTrue("Contract failed: equals-hashcode on var10 and var0", var10.equals(var0) ? var10.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var12
//     assertTrue("Contract failed: equals-hashcode on var2 and var12", var2.equals(var12) ? var2.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var2
//     assertTrue("Contract failed: equals-hashcode on var12 and var2", var12.equals(var2) ? var12.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.setDomainCrosshairVisible(true);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var5 = var4.getBaseStroke();
    boolean var6 = var3.equals((java.lang.Object)var4);
    java.awt.Paint var7 = var3.getBaseOutlinePaint();
    var0.setRangeGridlinePaint(var7);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var9);
    int var12 = var9.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var14 = var13.clone();
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    double var19 = var13.getCategoryEnd(100, 1, var17, var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var24 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var25 = null;
    var24.setBaseItemLabelFont(var25, true);
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, (org.jfree.chart.axis.CategoryAxis)var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.chart.axis.AxisLocation var30 = null;
    var28.setRangeAxisLocation(10, var30);
    org.jfree.chart.axis.ValueAxis var32 = var28.getRangeAxis();
    org.jfree.data.general.PieDataset var33 = null;
    org.jfree.chart.plot.PiePlot3D var34 = new org.jfree.chart.plot.PiePlot3D(var33);
    java.awt.Paint var35 = null;
    var34.setLabelShadowPaint(var35);
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    var34.handleClick(0, 1, var39);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var34.addChangeListener(var41);
    java.awt.Paint var43 = var34.getBaseSectionOutlinePaint();
    var28.setRangeCrosshairPaint(var43);
    boolean var45 = var28.isDomainZoomable();
    boolean var46 = var28.isDomainZoomable();
    org.jfree.chart.renderer.category.LineRenderer3D var47 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var48 = var47.getBaseOutlineStroke();
    java.lang.Object var49 = var47.clone();
    org.jfree.chart.event.RendererChangeEvent var50 = new org.jfree.chart.event.RendererChangeEvent(var49);
    org.jfree.chart.JFreeChart var51 = var50.getChart();
    var28.rendererChanged(var50);
    var0.rendererChanged(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + Double.NaN+ "'", var10.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    double var1 = var0.getRangeCrosshairValue();
    boolean var2 = var0.isDomainZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
    java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setSeriesKeys((java.lang.Comparable[])var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var25 = var24.clone();
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleEdge var29 = null;
//     double var30 = var24.getCategoryStart(1, 0, var28, var29);
//     java.lang.String var32 = var24.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     var19.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var24);
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var19.setDomainAxisLocation(1, var35);
//     java.awt.Graphics2D var37 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var38 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var39 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var38);
//     int var41 = var38.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var43 = var42.clone();
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleEdge var47 = null;
//     double var48 = var42.getCategoryEnd(100, 1, var46, var47);
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var53 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var54 = null;
//     var53.setBaseItemLabelFont(var54, true);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var38, (org.jfree.chart.axis.CategoryAxis)var42, var49, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
//     org.jfree.chart.axis.AxisLocation var59 = null;
//     var57.setRangeAxisLocation(10, var59);
//     org.jfree.chart.axis.ValueAxis var61 = var57.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var63 = var57.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var64 = var57.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var65 = null;
//     org.jfree.chart.event.ChartChangeEventType var66 = null;
//     org.jfree.chart.event.ChartChangeEvent var67 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var57, var65, var66);
//     java.awt.Graphics2D var68 = null;
//     org.jfree.chart.entity.EntityCollection var69 = null;
//     org.jfree.chart.ChartRenderingInfo var70 = new org.jfree.chart.ChartRenderingInfo(var69);
//     org.jfree.chart.entity.EntityCollection var71 = var70.getEntityCollection();
//     java.awt.geom.Rectangle2D var72 = var70.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     boolean var75 = var57.render(var68, var72, 100, var74);
//     var19.drawBackground(var37, var72);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
    var0.setSeriesItemLabelsVisible(0, false);
    java.awt.Font var4 = null;
    var0.setBaseItemLabelFont(var4, true);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var8);
    java.lang.Object var10 = var8.clone();
    org.jfree.data.category.CategoryDataset var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var13 = var8.generateLabel(var11, 255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var1);
//     java.lang.Comparable var4 = var3.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var5 = var3.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5, var6);
//     org.jfree.chart.block.BlockParams var8 = new org.jfree.chart.block.BlockParams();
//     boolean var9 = var8.getGenerateEntities();
//     var8.setGenerateEntities(true);
//     var8.setTranslateY(4.0d);
//     boolean var14 = var5.equals((java.lang.Object)4.0d);
//     org.jfree.chart.renderer.category.LineRenderer3D var16 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var17 = var16.getBaseOutlineStroke();
//     java.lang.Object var18 = var16.clone();
//     double var19 = var16.getYOffset();
//     java.awt.Font var22 = var16.getItemLabelFont(1, 100);
//     java.awt.Color var26 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var27.getCategoryMiddle(1, 100, var30, var31);
//     java.awt.Stroke var33 = var27.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var35 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var37 = var36.getBaseStroke();
//     boolean var38 = var35.equals((java.lang.Object)var36);
//     java.awt.Paint var39 = var35.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var40 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var42 = var40.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var39, var42);
//     org.jfree.chart.renderer.category.LineRenderer3D var44 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var46 = var44.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var26, var33, var39, var46, 0.0f);
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("October", var22, var39);
//     boolean var50 = var5.equals((java.lang.Object)var22);
//     org.jfree.chart.event.TitleChangeEvent var51 = null;
//     var5.titleChanged(var51);
// 
//   }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeCrosshairLockedOnData();
//     var0.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryMarker var5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
//     boolean var6 = var5.getDrawAsLine();
//     org.jfree.chart.util.Layer var7 = null;
//     var0.addRangeMarker((org.jfree.chart.plot.Marker)var5, var7);
//     boolean var9 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     var0.setRangeAxis(1, var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var13 = null;
//     var0.setRenderers(var13);
// 
//   }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
    org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
    org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
    org.jfree.chart.JFreeChart var27 = null;
    org.jfree.chart.event.ChartChangeEventType var28 = null;
    org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var27, var28);
    java.awt.Graphics2D var30 = null;
    org.jfree.chart.entity.EntityCollection var31 = null;
    org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo(var31);
    org.jfree.chart.entity.EntityCollection var33 = var32.getEntityCollection();
    java.awt.geom.Rectangle2D var34 = var32.getChartArea();
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    boolean var37 = var19.render(var30, var34, 100, var36);
    var19.setAnchorValue((-100.0d), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     org.jfree.chart.util.HorizontalAlignment var41 = var40.getLineAlignment();
//     org.jfree.chart.title.TextTitle var42 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.VerticalAlignment var43 = var42.getVerticalAlignment();
//     org.jfree.chart.axis.CategoryAxis3D var44 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var45 = var44.clone();
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.chart.util.RectangleEdge var49 = null;
//     double var50 = var44.getCategoryStart(1, 0, var48, var49);
//     java.lang.String var52 = var44.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     java.awt.Color var56 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.chart.util.RectangleEdge var61 = null;
//     double var62 = var57.getCategoryMiddle(1, 100, var60, var61);
//     java.awt.Stroke var63 = var57.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var65 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var66 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var67 = var66.getBaseStroke();
//     boolean var68 = var65.equals((java.lang.Object)var66);
//     java.awt.Paint var69 = var65.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var70 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var72 = var70.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var73 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var69, var72);
//     org.jfree.chart.renderer.category.LineRenderer3D var74 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var76 = var74.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var78 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var56, var63, var69, var76, 0.0f);
//     var44.setAxisLineStroke(var76);
//     org.jfree.data.general.PieDataset var80 = null;
//     org.jfree.chart.plot.PiePlot3D var81 = new org.jfree.chart.plot.PiePlot3D(var80);
//     java.awt.Paint var82 = null;
//     var81.setLabelShadowPaint(var82);
//     org.jfree.chart.plot.PlotRenderingInfo var86 = null;
//     var81.handleClick(0, 1, var86);
//     var44.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var81);
//     java.awt.Paint var89 = var44.getTickMarkPaint();
//     boolean var90 = var43.equals((java.lang.Object)var44);
//     org.jfree.chart.block.FlowArrangement var93 = new org.jfree.chart.block.FlowArrangement(var41, var43, 0.2d, 3.0d);
//     
//     // Checks the contract:  equals-hashcode on var34 and var78
//     assertTrue("Contract failed: equals-hashcode on var34 and var78", var34.equals(var78) ? var34.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var34
//     assertTrue("Contract failed: equals-hashcode on var78 and var34", var78.equals(var34) ? var78.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     java.util.Date var3 = var2.getLowerDate();
//     java.lang.String var4 = var2.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"+ "'", var4.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("AxisLocation.TOP_OR_RIGHT", 10, (-16777216));
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    org.jfree.chart.labels.PieToolTipGenerator var3 = null;
    var1.setToolTipGenerator(var3);
    var1.setMinimumArcAngleToDraw(100.0d);
    var1.setOutlineVisible(true);
    var1.setDepthFactor(1.0d);
    org.jfree.chart.plot.AbstractPieLabelDistributor var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var4.getCategoryMiddle(1, 100, var7, var8);
    java.awt.Stroke var10 = var4.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var14 = var13.getBaseStroke();
    boolean var15 = var12.equals((java.lang.Object)var13);
    java.awt.Paint var16 = var12.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var17 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var19 = var17.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var16, var19);
    org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var3, var10, var16, var23, 0.0f);
    var25.setStartValue(100.0d);
    org.jfree.chart.util.LengthAdjustmentType var28 = var25.getLabelOffsetType();
    org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo();
    boolean var30 = var28.equals((java.lang.Object)var29);
    var29.setLicenceName("AxisLocation.TOP_OR_RIGHT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.RectangleEdge var21 = var19.getRangeAxisEdge(1);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    boolean var23 = var22.isRangeCrosshairLockedOnData();
    var22.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
    boolean var28 = var27.getDrawAsLine();
    org.jfree.chart.util.Layer var29 = null;
    var22.addRangeMarker((org.jfree.chart.plot.Marker)var27, var29);
    org.jfree.chart.renderer.category.LineRenderer3D var32 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var33 = var32.getBaseOutlineStroke();
    java.lang.Object var34 = var32.clone();
    double var35 = var32.getYOffset();
    java.awt.Font var38 = var32.getItemLabelFont(1, 100);
    java.awt.Color var42 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var46 = null;
    org.jfree.chart.util.RectangleEdge var47 = null;
    double var48 = var43.getCategoryMiddle(1, 100, var46, var47);
    java.awt.Stroke var49 = var43.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var51 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var53 = var52.getBaseStroke();
    boolean var54 = var51.equals((java.lang.Object)var52);
    java.awt.Paint var55 = var51.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var56 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var58 = var56.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var55, var58);
    org.jfree.chart.renderer.category.LineRenderer3D var60 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var62 = var60.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var64 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var42, var49, var55, var62, 0.0f);
    org.jfree.chart.text.TextFragment var65 = new org.jfree.chart.text.TextFragment("October", var38, var55);
    boolean var66 = var27.equals((java.lang.Object)var65);
    org.jfree.chart.util.Layer var67 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.addDomainMarker(var27, var67);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(0, 1, var6);
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var1.addChangeListener(var8);
    org.jfree.chart.event.PlotChangeEvent var10 = null;
    var1.notifyListeners(var10);
    java.awt.Color var13 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
    org.jfree.chart.labels.PieSectionLabelGenerator var16 = var15.getLabelGenerator();
    var15.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var19 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var20 = var19.getEndType();
    java.awt.Stroke var21 = var19.getBaseOutlineStroke();
    var15.setOutlineStroke(var21);
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var23.getCategoryMiddle(1, 100, var26, var27);
    org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var23.setLabelInsets(var33);
    org.jfree.chart.block.LineBorder var35 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var13, var21, var33);
    var1.setOutlinePaint((java.awt.Paint)var13);
    org.jfree.chart.util.Rotation var37 = var1.getDirection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getPadding();
    var0.setID("hi!");
    java.awt.Paint var6 = var0.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var1 = null;
//     var0.setBaseURLGenerator(var1, true);
//     boolean var4 = var0.getAutoPopulateSeriesOutlinePaint();
//     var0.setAutoPopulateSeriesFillPaint(true);
//     java.awt.Font var9 = var0.getItemLabelFont(2, (-1));
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var12.getCategoryMiddle(1, 100, var15, var16);
//     java.awt.Stroke var18 = var12.getTickMarkStroke();
//     java.awt.Font var19 = var12.getLabelFont();
//     org.jfree.chart.renderer.category.AreaRenderer var20 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var20.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var25 = var20.getLegendItem(0, (-1));
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.urls.CategoryURLGenerator var27 = var26.getBaseURLGenerator();
//     java.lang.Boolean var29 = var26.getSeriesLinesVisible(100);
//     java.awt.Paint var31 = var26.lookupSeriesPaint(100);
//     var20.setBasePaint(var31, false);
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
//     boolean var35 = var34.isRangeCrosshairLockedOnData();
//     int var36 = var34.getWeight();
//     java.awt.Stroke var37 = var34.getRangeCrosshairStroke();
//     org.jfree.chart.util.RectangleEdge var39 = var34.getRangeAxisEdge(100);
//     org.jfree.chart.renderer.category.LineRenderer3D var42 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var43 = var42.getBaseOutlineStroke();
//     java.lang.Object var44 = var42.clone();
//     double var45 = var42.getYOffset();
//     java.awt.Font var48 = var42.getItemLabelFont(1, 100);
//     java.awt.Color var52 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var53 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var56 = null;
//     org.jfree.chart.util.RectangleEdge var57 = null;
//     double var58 = var53.getCategoryMiddle(1, 100, var56, var57);
//     java.awt.Stroke var59 = var53.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var61 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var62 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var63 = var62.getBaseStroke();
//     boolean var64 = var61.equals((java.lang.Object)var62);
//     java.awt.Paint var65 = var61.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var66 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var68 = var66.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var65, var68);
//     org.jfree.chart.renderer.category.LineRenderer3D var70 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var72 = var70.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var74 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var52, var59, var65, var72, 0.0f);
//     org.jfree.chart.text.TextFragment var75 = new org.jfree.chart.text.TextFragment("October", var48, var65);
//     java.awt.Color var79 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var80 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var48, (java.awt.Paint)var79);
//     org.jfree.chart.util.HorizontalAlignment var81 = var80.getLineAlignment();
//     org.jfree.chart.title.TextTitle var82 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.VerticalAlignment var83 = var82.getVerticalAlignment();
//     org.jfree.data.general.PieDataset var84 = null;
//     org.jfree.chart.plot.PiePlot3D var85 = new org.jfree.chart.plot.PiePlot3D(var84);
//     org.jfree.chart.labels.PieSectionLabelGenerator var86 = var85.getLabelGenerator();
//     var85.zoom(0.0d);
//     boolean var89 = var85.getLabelLinksVisible();
//     org.jfree.chart.util.RectangleInsets var90 = new org.jfree.chart.util.RectangleInsets();
//     var85.setInsets(var90, true);
//     double var94 = var90.calculateBottomInset(100.0d);
//     double var95 = var90.getLeft();
//     double var96 = var90.getLeft();
//     org.jfree.chart.title.TextTitle var97 = new org.jfree.chart.title.TextTitle("DateTickUnit[MONTH, -1]", var19, var31, var39, var81, var83, var90);
//     var0.setSeriesOutlinePaint(2, var31, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var26 and var0.", var26.equals(var0) == var0.equals(var26));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var0.", var42.equals(var0) == var0.equals(var42));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var0.", var66.equals(var0) == var0.equals(var66));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var70 and var0.", var70.equals(var0) == var0.equals(var70));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(100);
    var0.setBaseLinesVisible(false);
    boolean var6 = var0.getAutoPopulateSeriesFillPaint();
    var0.setSeriesVisible(1, (java.lang.Boolean)false);
    boolean var10 = var0.getBaseLinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
    int var4 = var1.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var6 = var5.clone();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var5.getCategoryEnd(100, 1, var9, var10);
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var16 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var17 = null;
    var16.setBaseItemLabelFont(var17, true);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var1, (org.jfree.chart.axis.CategoryAxis)var5, var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.axis.AxisLocation var22 = null;
    var20.setRangeAxisLocation(10, var22);
    org.jfree.chart.axis.ValueAxis var24 = var20.getRangeAxis();
    org.jfree.chart.axis.CategoryAxis var26 = var20.getDomainAxisForDataset(100);
    org.jfree.chart.util.RectangleEdge var27 = var20.getRangeAxisEdge();
    boolean var28 = var0.equals((java.lang.Object)var20);
    java.awt.Stroke var30 = var0.getStroke(68);
    java.awt.Stroke var32 = var0.getStroke(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var12 = var11.clone();
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleEdge var16 = null;
    double var17 = var11.getCategoryStart(1, 0, var15, var16);
    java.lang.String var19 = var11.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var23 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var24.getCategoryMiddle(1, 100, var27, var28);
    java.awt.Stroke var30 = var24.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var34 = var33.getBaseStroke();
    boolean var35 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var36 = var32.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var37 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var39 = var37.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var36, var39);
    org.jfree.chart.renderer.category.LineRenderer3D var41 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var43 = var41.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var23, var30, var36, var43, 0.0f);
    var11.setAxisLinePaint(var36);
    org.jfree.chart.event.AxisChangeEvent var47 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var11);
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var11, var48, var49);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var53 = var5.getMeanValue(68, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     java.lang.Comparable var11 = var6.getColumnKey(2);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
    org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var1);
    java.lang.Comparable var4 = var3.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var5 = var3.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var6 = null;
    org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5, var6);
    org.jfree.chart.block.BlockParams var8 = new org.jfree.chart.block.BlockParams();
    boolean var9 = var8.getGenerateEntities();
    var8.setGenerateEntities(true);
    var8.setTranslateY(4.0d);
    boolean var14 = var5.equals((java.lang.Object)4.0d);
    org.jfree.chart.renderer.category.LineRenderer3D var16 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var17 = var16.getBaseOutlineStroke();
    java.lang.Object var18 = var16.clone();
    double var19 = var16.getYOffset();
    java.awt.Font var22 = var16.getItemLabelFont(1, 100);
    java.awt.Color var26 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var27.getCategoryMiddle(1, 100, var30, var31);
    java.awt.Stroke var33 = var27.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var35 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var37 = var36.getBaseStroke();
    boolean var38 = var35.equals((java.lang.Object)var36);
    java.awt.Paint var39 = var35.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var40 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var42 = var40.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var39, var42);
    org.jfree.chart.renderer.category.LineRenderer3D var44 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var46 = var44.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var26, var33, var39, var46, 0.0f);
    org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("October", var22, var39);
    boolean var50 = var5.equals((java.lang.Object)var22);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var51 = var5.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "Other"+ "'", var4.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesNegativeItemLabelPosition(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var2 = var1.getBaseStroke();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     java.awt.Paint var4 = var1.getBasePaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var5);
//     int var8 = var5.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var10 = var9.clone();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var9.getCategoryEnd(100, 1, var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var21 = null;
//     var20.setBaseItemLabelFont(var21, true);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var9, var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var24.setRangeAxisLocation(10, var26);
//     org.jfree.chart.axis.ValueAxis var28 = var24.getRangeAxis();
//     int var29 = var24.getDomainAxisCount();
//     var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     boolean var31 = var24.isDomainZoomable();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var34 = var33.getBaseStroke();
//     boolean var35 = var32.equals((java.lang.Object)var33);
//     java.awt.Paint var36 = var33.getBasePaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var38 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var37);
//     int var40 = var37.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var42 = var41.clone();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var41.getCategoryEnd(100, 1, var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var53 = null;
//     var52.setBaseItemLabelFont(var53, true);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var37, (org.jfree.chart.axis.CategoryAxis)var41, var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var52);
//     org.jfree.chart.axis.AxisLocation var58 = null;
//     var56.setRangeAxisLocation(10, var58);
//     org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxis();
//     int var61 = var56.getDomainAxisCount();
//     var33.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var56);
//     org.jfree.chart.axis.CategoryAxis var64 = var56.getDomainAxisForDataset(0);
//     double var65 = var64.getCategoryMargin();
//     java.util.List var66 = var24.getCategoriesForAxis(var64);
//     
//     // Checks the contract:  equals-hashcode on var5 and var37
//     assertTrue("Contract failed: equals-hashcode on var5 and var37", var5.equals(var37) ? var5.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var5
//     assertTrue("Contract failed: equals-hashcode on var37 and var5", var37.equals(var5) ? var37.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var56
//     assertTrue("Contract failed: equals-hashcode on var24 and var56", var24.equals(var56) ? var24.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var24
//     assertTrue("Contract failed: equals-hashcode on var56 and var24", var56.equals(var24) ? var56.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    double var1 = var0.getRangeCrosshairValue();
    org.jfree.chart.plot.WaferMapPlot var2 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var4 = var3.getBaseOutlineStroke();
    java.lang.Object var5 = var3.clone();
    org.jfree.chart.event.RendererChangeEvent var6 = new org.jfree.chart.event.RendererChangeEvent(var5);
    var2.rendererChanged(var6);
    var0.rendererChanged(var6);
    org.jfree.chart.plot.IntervalMarker var11 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.0d);
    var0.addDomainMarker((org.jfree.chart.plot.Marker)var11);
    int var13 = var0.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     var0.setSeriesItemLabelsVisible(0, false);
//     java.awt.Font var4 = null;
//     var0.setBaseItemLabelFont(var4, true);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var8);
//     org.jfree.chart.renderer.category.AreaRenderer var11 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var11.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var16 = var11.getLegendItem(0, (-1));
//     java.awt.Paint var18 = null;
//     var11.setSeriesPaint(10, var18);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var21 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var11.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var21, true);
//     java.lang.String var24 = var21.getLabelFormat();
//     var0.setSeriesToolTipGenerator(100, (org.jfree.chart.labels.CategoryToolTipGenerator)var21);
//     java.lang.Comparable[] var26 = null;
//     java.lang.Comparable[] var28 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var29 = null;
//     java.lang.Number[][] var30 = new java.lang.Number[][] { var29};
//     java.lang.Number[][] var31 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var32 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var26, var28, var30, var31);
//     org.jfree.data.general.SeriesChangeEvent var33 = null;
//     var32.seriesChanged(var33);
//     var32.validateObject();
//     java.util.List var36 = var32.getColumnKeys();
//     java.lang.String var38 = var21.generateRowLabel((org.jfree.data.category.CategoryDataset)var32, 0);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    java.awt.Paint var4 = var0.getRangeZeroBaselinePaint();
    var0.setRangeZeroBaselineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    int var1 = var0.getColumnCount();
    java.lang.Object var2 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var2 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var3 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var4 = var3.getBaseStroke();
    boolean var5 = var2.equals((java.lang.Object)var3);
    java.awt.Paint var6 = var3.getBasePaint();
    var0.setPaint(10, var6);
    java.awt.Paint var9 = var0.getPaint(100);
    java.awt.Paint var11 = var0.getPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     org.jfree.chart.LegendItemCollection var4 = var2.getLegendItems();
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.data.general.DatasetChangeEvent var2 = null;
//     var0.datasetChanged(var2);
//     java.awt.Stroke var4 = var0.getDomainZeroBaselineStroke();
//     var0.clearRangeMarkers(0);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     var0.handleClick((-1), 2, var9);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.renderer.category.WaterfallBarRenderer var0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = null;
    var0.setBaseURLGenerator(var1, true);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var4);
    int var7 = var4.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var9 = var8.clone();
    java.awt.geom.Rectangle2D var12 = null;
    org.jfree.chart.util.RectangleEdge var13 = null;
    double var14 = var8.getCategoryEnd(100, 1, var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var20 = null;
    var19.setBaseItemLabelFont(var20, true);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, (org.jfree.chart.axis.CategoryAxis)var8, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setRangeAxisLocation(10, var25);
    org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var29 = var28.clone();
    java.awt.geom.Rectangle2D var32 = null;
    org.jfree.chart.util.RectangleEdge var33 = null;
    double var34 = var28.getCategoryStart(1, 0, var32, var33);
    java.lang.String var36 = var28.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    var23.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var28);
    org.jfree.chart.axis.AxisLocation var39 = null;
    var23.setDomainAxisLocation(1, var39);
    var0.setPlot(var23);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var23.zoomDomainAxes(0.05d, var43, var46);
    var23.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     double var2 = var1.getInteriorGap();
//     org.jfree.data.general.PieDataset var3 = var1.getDataset();
//     double var4 = var1.getMaximumLabelWidth();
//     double var5 = var1.getMaximumExplodePercent();
// 
//   }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(0L);
//     org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     java.util.Date var6 = var5.getLowerDate();
//     var0.addException(var6);
//     java.util.TimeZone var8 = null;
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var6, var8);
// 
//   }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
    boolean var6 = var5.getDrawAsLine();
    org.jfree.chart.util.Layer var7 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5, var7);
    boolean var9 = var0.isRangeCrosshairLockedOnData();
    java.awt.Color var11 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    var0.setRangeTickBandPaint((java.awt.Paint)var11);
    boolean var13 = var0.isDomainCrosshairVisible();
    org.jfree.chart.util.RectangleEdge var15 = var0.getRangeAxisEdge((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var2 = var1.getBaseOutlineStroke();
    var1.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var1.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var6);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var11 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = null;
    var11.setSeriesItemLabelGenerator(2, var13);
    boolean var15 = var1.equals((java.lang.Object)var11);
    org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var17.getCategoryMiddle(1, 100, var20, var21);
    java.awt.Stroke var23 = var17.getTickMarkStroke();
    java.awt.Font var24 = var17.getLabelFont();
    var11.setSeriesItemLabelFont(0, var24, true);
    org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var30 = null;
    org.jfree.chart.util.RectangleEdge var31 = null;
    double var32 = var27.getCategoryMiddle(1, 100, var30, var31);
    java.awt.Stroke var33 = var27.getTickMarkStroke();
    var27.setCategoryMargin(0.0d);
    java.awt.Font var37 = var27.getTickLabelFont((java.lang.Comparable)2);
    org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.util.RectangleEdge var43 = null;
    double var44 = var39.getCategoryMiddle(1, 100, var42, var43);
    java.awt.Stroke var45 = var39.getTickMarkStroke();
    java.awt.Font var46 = var39.getLabelFont();
    org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("", var46);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.axis.AxisLocation var69 = null;
    var67.setRangeAxisLocation(10, var69);
    org.jfree.chart.axis.CategoryAxis3D var72 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var73 = var72.clone();
    java.awt.geom.Rectangle2D var76 = null;
    org.jfree.chart.util.RectangleEdge var77 = null;
    double var78 = var72.getCategoryStart(1, 0, var76, var77);
    java.lang.String var80 = var72.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    var67.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var72);
    java.awt.Paint var82 = var72.getLabelPaint();
    var47.setPaint(var82);
    var27.setLabelPaint(var82);
    org.jfree.chart.text.TextLine var85 = new org.jfree.chart.text.TextLine("LegendItemEntity: seriesKey=null, dataset=null", var24, var82);
    boolean var87 = var85.equals((java.lang.Object)"DateTickUnit[MONTH, -1]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var0.getCategoryStart(1, 0, var4, var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
    java.awt.Stroke var19 = var13.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    boolean var24 = var21.equals((java.lang.Object)var22);
    java.awt.Paint var25 = var21.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
    org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
    var0.setAxisLineStroke(var32);
    org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var37 = var36.getBaseOutlineStroke();
    java.lang.Object var38 = var36.clone();
    double var39 = var36.getYOffset();
    java.awt.Font var42 = var36.getItemLabelFont(1, 100);
    var0.setLabelFont(var42);
    var0.clearCategoryLabelToolTips();
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    org.jfree.chart.entity.LegendItemEntity var48 = new org.jfree.chart.entity.LegendItemEntity(var47);
    org.jfree.chart.entity.AxisLabelEntity var51 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var47, "AxisLocation.TOP_OR_RIGHT", "");
    java.lang.String var52 = var51.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + ""+ "'", var52.equals(""));

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    var0.setRangeGridlinesVisible(false);
    var0.setDomainCrosshairValue((-100.0d));

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     boolean var27 = var26.isRangeCrosshairLockedOnData();
//     var26.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.CategoryMarker var31 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
//     boolean var32 = var31.getDrawAsLine();
//     org.jfree.chart.util.Layer var33 = null;
//     var26.addRangeMarker((org.jfree.chart.plot.Marker)var31, var33);
//     org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var37 = var36.getBaseOutlineStroke();
//     java.lang.Object var38 = var36.clone();
//     double var39 = var36.getYOffset();
//     java.awt.Font var42 = var36.getItemLabelFont(1, 100);
//     java.awt.Color var46 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var50 = null;
//     org.jfree.chart.util.RectangleEdge var51 = null;
//     double var52 = var47.getCategoryMiddle(1, 100, var50, var51);
//     java.awt.Stroke var53 = var47.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var55 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var57 = var56.getBaseStroke();
//     boolean var58 = var55.equals((java.lang.Object)var56);
//     java.awt.Paint var59 = var55.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var60 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var62 = var60.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var63 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var59, var62);
//     org.jfree.chart.renderer.category.LineRenderer3D var64 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var66 = var64.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var68 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var46, var53, var59, var66, 0.0f);
//     org.jfree.chart.text.TextFragment var69 = new org.jfree.chart.text.TextFragment("October", var42, var59);
//     boolean var70 = var31.equals((java.lang.Object)var69);
//     org.jfree.chart.util.Layer var71 = null;
//     var19.addRangeMarker((org.jfree.chart.plot.Marker)var31, var71);
//     var31.setAlpha(1.0f);
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     boolean var76 = var75.isRangeCrosshairLockedOnData();
//     var75.setDomainGridlinesVisible(false);
//     var75.clearRangeAxes();
//     java.awt.Stroke var80 = var75.getOutlineStroke();
//     boolean var81 = var31.equals((java.lang.Object)var80);
//     
//     // Checks the contract:  equals-hashcode on var26 and var75
//     assertTrue("Contract failed: equals-hashcode on var26 and var75", var26.equals(var75) ? var26.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var26
//     assertTrue("Contract failed: equals-hashcode on var75 and var26", var75.equals(var26) ? var75.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    var0.setDomainGridlinesVisible(false);
    org.jfree.chart.plot.CategoryMarker var5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f);
    boolean var6 = var5.getDrawAsLine();
    org.jfree.chart.util.Layer var7 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var5, var7);
    java.awt.Paint var9 = var0.getDomainCrosshairPaint();
    java.awt.Color var14 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var15.getCategoryMiddle(1, 100, var18, var19);
    java.awt.Stroke var21 = var15.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var23 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var25 = var24.getBaseStroke();
    boolean var26 = var23.equals((java.lang.Object)var24);
    java.awt.Paint var27 = var23.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var28 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var30 = var28.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var27, var30);
    org.jfree.chart.renderer.category.LineRenderer3D var32 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var34 = var32.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var36 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var14, var21, var27, var34, 0.0f);
    var36.setStartValue(100.0d);
    org.jfree.chart.util.LengthAdjustmentType var39 = var36.getLabelOffsetType();
    org.jfree.chart.axis.CategoryAxis3D var40 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var43 = null;
    org.jfree.chart.util.RectangleEdge var44 = null;
    double var45 = var40.getCategoryMiddle(1, 100, var43, var44);
    java.awt.Stroke var46 = var40.getTickMarkStroke();
    var36.setOutlineStroke(var46);
    org.jfree.chart.util.Layer var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((-16777216), (org.jfree.chart.plot.Marker)var36, var48);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var5);
    int var8 = var5.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var10 = var9.clone();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var9.getCategoryEnd(100, 1, var13, var14);
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var21 = null;
    var20.setBaseItemLabelFont(var21, true);
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var9, var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(1);
    java.awt.Font var27 = var24.getNoDataMessageFont();
    org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var27);
    java.awt.geom.Rectangle2D var29 = var28.getBounds();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var30 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var31 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var30);
    int var33 = var30.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var35 = var34.clone();
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var34.getCategoryEnd(100, 1, var38, var39);
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var45 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var46 = null;
    var45.setBaseItemLabelFont(var46, true);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var30, (org.jfree.chart.axis.CategoryAxis)var34, var41, (org.jfree.chart.renderer.category.CategoryItemRenderer)var45);
    var49.setWeight(1);
    org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
    var49.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53, false);
    org.jfree.chart.axis.AxisSpace var56 = null;
    var49.setFixedDomainAxisSpace(var56);
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.TickUnitSource var60 = null;
    var59.setStandardTickUnits(var60);
    var59.setVerticalTickLabels(true);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var67 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var68 = var67.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var69 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var70 = var67.findRangeBounds((org.jfree.data.category.CategoryDataset)var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var3, var29, var49, var58, (org.jfree.chart.axis.ValueAxis)var59, (org.jfree.data.category.CategoryDataset)var69, 1, 100, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + Double.NaN+ "'", var6.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + Double.NaN+ "'", var31.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.renderer.category.MinMaxCategoryRenderer var0 = new org.jfree.chart.renderer.category.MinMaxCategoryRenderer();
    javax.swing.Icon var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setMinIcon(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEventType var28 = null;
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var27, var28);
//     org.jfree.chart.axis.AxisLocation var30 = var19.getRangeAxisLocation();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var31 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var31);
//     int var34 = var31.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var36 = var35.clone();
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var35.getCategoryEnd(100, 1, var39, var40);
//     org.jfree.chart.axis.ValueAxis var42 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var46 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var47 = null;
//     var46.setBaseItemLabelFont(var47, true);
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var31, (org.jfree.chart.axis.CategoryAxis)var35, var42, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
//     org.jfree.chart.util.RectangleEdge var52 = var50.getRangeAxisEdge(1);
//     org.jfree.chart.plot.PlotOrientation var53 = var50.getOrientation();
//     java.lang.String var54 = var53.toString();
//     org.jfree.chart.util.RectangleEdge var55 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var30, var53);
//     
//     // Checks the contract:  equals-hashcode on var0 and var31
//     assertTrue("Contract failed: equals-hashcode on var0 and var31", var0.equals(var31) ? var0.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var0
//     assertTrue("Contract failed: equals-hashcode on var31 and var0", var31.equals(var0) ? var31.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var50
//     assertTrue("Contract failed: equals-hashcode on var19 and var50", var19.equals(var50) ? var19.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var19
//     assertTrue("Contract failed: equals-hashcode on var50 and var19", var50.equals(var19) ? var50.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.data.general.PieDataset var12 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var5, 0);
    double var13 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     boolean var23 = var19.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
//     boolean var25 = var19.isDomainZoomable();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var26 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var27 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var26);
//     int var29 = var26.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var30 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var31 = var30.clone();
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var30.getCategoryEnd(100, 1, var34, var35);
//     org.jfree.chart.axis.ValueAxis var37 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var41 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var42 = null;
//     var41.setBaseItemLabelFont(var42, true);
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, (org.jfree.chart.axis.CategoryAxis)var30, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     org.jfree.chart.axis.AxisLocation var47 = null;
//     var45.setRangeAxisLocation(10, var47);
//     org.jfree.chart.axis.ValueAxis var49 = var45.getRangeAxis();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var51 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var52 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var53 = var52.getBaseStroke();
//     boolean var54 = var51.equals((java.lang.Object)var52);
//     java.awt.Paint var55 = var51.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var56 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var58 = var56.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var55, var58);
//     var59.setValue((-1.0d));
//     var45.addRangeMarker((org.jfree.chart.plot.Marker)var59);
//     java.awt.Stroke var63 = var59.getOutlineStroke();
//     var19.setDomainGridlineStroke(var63);
//     
//     // Checks the contract:  equals-hashcode on var0 and var26
//     assertTrue("Contract failed: equals-hashcode on var0 and var26", var0.equals(var26) ? var0.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var0
//     assertTrue("Contract failed: equals-hashcode on var26 and var0", var26.equals(var0) ? var26.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     double var9 = var4.getCategoryMiddle(1, 100, var7, var8);
//     java.awt.Stroke var10 = var4.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var14 = var13.getBaseStroke();
//     boolean var15 = var12.equals((java.lang.Object)var13);
//     java.awt.Paint var16 = var12.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var17 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var19 = var17.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var16, var19);
//     org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var3, var10, var16, var23, 0.0f);
//     var25.setStartValue(100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var28 = var25.getLabelOffsetType();
//     org.jfree.chart.ui.ProjectInfo var29 = new org.jfree.chart.ui.ProjectInfo();
//     boolean var30 = var28.equals((java.lang.Object)var29);
//     java.awt.Color var34 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var35.getCategoryMiddle(1, 100, var38, var39);
//     java.awt.Stroke var41 = var35.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var43 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var45 = var44.getBaseStroke();
//     boolean var46 = var43.equals((java.lang.Object)var44);
//     java.awt.Paint var47 = var43.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var48 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var50 = var48.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var47, var50);
//     org.jfree.chart.renderer.category.LineRenderer3D var52 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var54 = var52.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var56 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var34, var41, var47, var54, 0.0f);
//     var56.setStartValue(100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var59 = var56.getLabelOffsetType();
//     org.jfree.chart.ui.ProjectInfo var60 = new org.jfree.chart.ui.ProjectInfo();
//     boolean var61 = var59.equals((java.lang.Object)var60);
//     var29.addOptionalLibrary((org.jfree.chart.ui.Library)var60);
//     
//     // Checks the contract:  equals-hashcode on var25 and var56
//     assertTrue("Contract failed: equals-hashcode on var25 and var56", var25.equals(var56) ? var25.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var25
//     assertTrue("Contract failed: equals-hashcode on var56 and var25", var56.equals(var25) ? var56.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    java.awt.Paint var23 = var14.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", 1, (-16777216));
// 
//   }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.TickUnitSource var1 = null;
    var0.setStandardTickUnits(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(0.0d, (-100.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     int var1 = var0.getSegmentsExcluded();
//     java.lang.Object var2 = null;
//     boolean var3 = var0.equals(var2);
//     long var4 = var0.getStartTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-2208927600000L));
// 
//   }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(255);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker((-100.0d), (-100.0d));

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryMiddle(1, 100, var3, var4);
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot3D var7 = new org.jfree.chart.plot.PiePlot3D(var6);
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = var7.getLabelGenerator();
//     var7.zoom(0.0d);
//     boolean var11 = var7.getLabelLinksVisible();
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     java.awt.Paint var14 = var13.getBackgroundPaint();
//     java.lang.Object var15 = var13.clone();
//     org.jfree.chart.util.RectangleInsets var16 = var13.getPadding();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot3D var18 = new org.jfree.chart.plot.PiePlot3D(var17);
//     org.jfree.chart.labels.PieSectionLabelGenerator var19 = var18.getLabelGenerator();
//     var18.zoom(0.0d);
//     boolean var22 = var18.getLabelLinksVisible();
//     org.jfree.chart.util.RectangleInsets var23 = new org.jfree.chart.util.RectangleInsets();
//     var18.setInsets(var23, true);
//     double var27 = var23.calculateBottomInset(100.0d);
//     var13.setPadding(var23);
//     double var30 = var23.calculateRightOutset(0.2d);
//     var0.setLabelInsets(var23);
//     
//     // Checks the contract:  equals-hashcode on var8 and var19
//     assertTrue("Contract failed: equals-hashcode on var8 and var19", var8.equals(var19) ? var8.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var8
//     assertTrue("Contract failed: equals-hashcode on var19 and var8", var19.equals(var8) ? var19.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryMiddle(1, 100, var4, var5);
//     java.awt.Stroke var7 = var1.getTickMarkStroke();
//     java.awt.Font var8 = var1.getLabelFont();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var9 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var11 = var10.getBaseStroke();
//     boolean var12 = var9.equals((java.lang.Object)var10);
//     java.awt.Paint var13 = var9.getBaseOutlinePaint();
//     org.jfree.chart.text.TextBlock var14 = org.jfree.chart.text.TextUtilities.createTextBlock("java.awt.Color[r=255,g=255,b=223]", var8, var13);
//     org.jfree.chart.util.HorizontalAlignment var15 = var14.getLineAlignment();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.util.Size2D var17 = var14.calculateDimensions(var16);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(3.0d, 10.0d);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var3 = var2.getBaseOutlineStroke();
//     java.lang.Object var4 = var2.clone();
//     double var5 = var2.getYOffset();
//     java.awt.Font var8 = var2.getItemLabelFont(1, 100);
//     java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.util.RectangleEdge var17 = null;
//     double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
//     java.awt.Stroke var19 = var13.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var23 = var22.getBaseStroke();
//     boolean var24 = var21.equals((java.lang.Object)var22);
//     java.awt.Paint var25 = var21.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
//     org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
//     org.jfree.chart.text.TextFragment var35 = new org.jfree.chart.text.TextFragment("October", var8, var25);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
//     org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var8, (java.awt.Paint)var39);
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var45 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var46 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var47 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var46);
//     int var49 = var46.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var51 = var50.clone();
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     double var56 = var50.getCategoryEnd(100, 1, var54, var55);
//     org.jfree.chart.axis.ValueAxis var57 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var61 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var62 = null;
//     var61.setBaseItemLabelFont(var62, true);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var46, (org.jfree.chart.axis.CategoryAxis)var50, var57, (org.jfree.chart.renderer.category.CategoryItemRenderer)var61);
//     org.jfree.chart.util.RectangleEdge var67 = var65.getRangeAxisEdge(1);
//     org.jfree.chart.axis.CategoryLabelPosition var68 = var45.getLabelPosition(var67);
//     org.jfree.chart.axis.CategoryLabelPosition var69 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var70 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var45, var69);
//     org.jfree.chart.text.TextBlockAnchor var71 = var69.getLabelAnchor();
//     org.jfree.chart.text.TextLine var72 = new org.jfree.chart.text.TextLine();
//     java.awt.Graphics2D var73 = null;
//     org.jfree.chart.util.Size2D var74 = var72.calculateDimensions(var73);
//     double var75 = var74.getWidth();
//     boolean var76 = var71.equals((java.lang.Object)var75);
//     java.awt.Shape var80 = var40.calculateBounds(var41, 100.0f, 10.0f, var71, 0.0f, 0.5f, 8.0d);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     var6.validateObject();
//     java.lang.Number var12 = null;
//     var6.setStartValue(0, (java.lang.Comparable)0.0f, var12);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieToolTipGenerator var2 = var1.getToolTipGenerator();
    java.awt.Stroke var3 = var1.getLabelOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInteriorGap(4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var1);
//     org.jfree.chart.plot.MultiplePiePlot var3 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var1);
//     java.lang.Comparable var4 = var3.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var5 = var3.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var5, var6);
//     org.jfree.chart.block.BlockParams var8 = new org.jfree.chart.block.BlockParams();
//     boolean var9 = var8.getGenerateEntities();
//     var8.setGenerateEntities(true);
//     var8.setTranslateY(4.0d);
//     boolean var14 = var5.equals((java.lang.Object)4.0d);
//     org.jfree.chart.renderer.category.LineRenderer3D var16 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var17 = var16.getBaseOutlineStroke();
//     java.lang.Object var18 = var16.clone();
//     double var19 = var16.getYOffset();
//     java.awt.Font var22 = var16.getItemLabelFont(1, 100);
//     java.awt.Color var26 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var27.getCategoryMiddle(1, 100, var30, var31);
//     java.awt.Stroke var33 = var27.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var35 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var37 = var36.getBaseStroke();
//     boolean var38 = var35.equals((java.lang.Object)var36);
//     java.awt.Paint var39 = var35.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var40 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var42 = var40.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var43 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var39, var42);
//     org.jfree.chart.renderer.category.LineRenderer3D var44 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var46 = var44.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var26, var33, var39, var46, 0.0f);
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("October", var22, var39);
//     boolean var50 = var5.equals((java.lang.Object)var22);
//     java.awt.Graphics2D var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var53 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var54 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var53);
//     int var56 = var53.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var58 = var57.clone();
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var57.getCategoryEnd(100, 1, var61, var62);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var68 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var69 = null;
//     var68.setBaseItemLabelFont(var69, true);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var53, (org.jfree.chart.axis.CategoryAxis)var57, var64, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
//     var72.setWeight(1);
//     java.awt.Graphics2D var75 = null;
//     org.jfree.chart.entity.EntityCollection var76 = null;
//     org.jfree.chart.ChartRenderingInfo var77 = new org.jfree.chart.ChartRenderingInfo(var76);
//     org.jfree.chart.entity.EntityCollection var78 = var77.getEntityCollection();
//     java.awt.geom.Rectangle2D var79 = var77.getChartArea();
//     org.jfree.chart.plot.XYPlot var80 = new org.jfree.chart.plot.XYPlot();
//     var80.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var83 = var80.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var84 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var85 = null;
//     var72.draw(var75, var79, var83, var84, var85);
//     org.jfree.chart.entity.EntityCollection var87 = null;
//     org.jfree.chart.ChartRenderingInfo var88 = new org.jfree.chart.ChartRenderingInfo(var87);
//     org.jfree.chart.entity.EntityCollection var89 = var88.getEntityCollection();
//     var88.clear();
//     var5.draw(var51, var52, var83, var88);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     java.awt.Paint var26 = null;
//     var25.setLabelShadowPaint(var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var25.handleClick(0, 1, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var25.addChangeListener(var32);
//     java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
//     var19.setRangeCrosshairPaint(var34);
//     var19.clearAnnotations();
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.TickUnitSource var38 = null;
//     var37.setStandardTickUnits(var38);
//     var37.setVerticalTickLabels(true);
//     org.jfree.data.Range var42 = var19.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var43 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var44 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var43);
//     int var46 = var43.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var48 = var47.clone();
//     java.awt.geom.Rectangle2D var51 = null;
//     org.jfree.chart.util.RectangleEdge var52 = null;
//     double var53 = var47.getCategoryEnd(100, 1, var51, var52);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var58 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var59 = null;
//     var58.setBaseItemLabelFont(var59, true);
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var43, (org.jfree.chart.axis.CategoryAxis)var47, var54, (org.jfree.chart.renderer.category.CategoryItemRenderer)var58);
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setRangeAxisLocation(10, var64);
//     org.jfree.chart.axis.ValueAxis var66 = var62.getRangeAxis();
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot3D var68 = new org.jfree.chart.plot.PiePlot3D(var67);
//     java.awt.Paint var69 = null;
//     var68.setLabelShadowPaint(var69);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     var68.handleClick(0, 1, var73);
//     org.jfree.chart.event.PlotChangeListener var75 = null;
//     var68.addChangeListener(var75);
//     java.awt.Paint var77 = var68.getBaseSectionOutlinePaint();
//     var62.setRangeCrosshairPaint(var77);
//     boolean var79 = var62.isDomainZoomable();
//     boolean var80 = var62.isDomainZoomable();
//     org.jfree.chart.renderer.category.LineRenderer3D var81 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var82 = var81.getBaseOutlineStroke();
//     java.lang.Object var83 = var81.clone();
//     org.jfree.chart.event.RendererChangeEvent var84 = new org.jfree.chart.event.RendererChangeEvent(var83);
//     org.jfree.chart.JFreeChart var85 = var84.getChart();
//     var62.rendererChanged(var84);
//     var19.rendererChanged(var84);
//     
//     // Checks the contract:  equals-hashcode on var0 and var43
//     assertTrue("Contract failed: equals-hashcode on var0 and var43", var0.equals(var43) ? var0.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var0
//     assertTrue("Contract failed: equals-hashcode on var43 and var0", var43.equals(var0) ? var43.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var62
//     assertTrue("Contract failed: equals-hashcode on var19 and var62", var19.equals(var62) ? var19.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var19
//     assertTrue("Contract failed: equals-hashcode on var62 and var19", var62.equals(var19) ? var62.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var68
//     assertTrue("Contract failed: equals-hashcode on var25 and var68", var25.equals(var68) ? var25.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var25
//     assertTrue("Contract failed: equals-hashcode on var68 and var25", var68.equals(var25) ? var68.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var2 = var1.getBaseStroke();
    boolean var3 = var0.equals((java.lang.Object)var1);
    var1.setAutoPopulateSeriesPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getPadding();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var5.getLabelGenerator();
    var5.zoom(0.0d);
    boolean var9 = var5.getLabelLinksVisible();
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets();
    var5.setInsets(var10, true);
    double var14 = var10.calculateBottomInset(100.0d);
    var0.setPadding(var10);
    double var17 = var10.calculateRightOutset(0.2d);
    double var19 = var10.calculateRightInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var1 = var0.getBackgroundPaint();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.RectangleInsets var3 = var0.getPadding();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var5.getLabelGenerator();
    var5.zoom(0.0d);
    boolean var9 = var5.getLabelLinksVisible();
    org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets();
    var5.setInsets(var10, true);
    double var14 = var10.calculateBottomInset(100.0d);
    var0.setPadding(var10);
    double var17 = var10.calculateRightOutset(0.2d);
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
    boolean var19 = var10.equals((java.lang.Object)var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var3 = var1.getTimeFromLong(0L);
    long var5 = var1.toTimelineValue(100L);
    var0.setBaseTimeline(var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var1.containsDomainRange(0L, (-1L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 644288400000L);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     boolean var1 = var0.isDomainZoomable();
//     org.jfree.chart.axis.ValueAxis var2 = var0.getAxis();
//     var0.clearCornerTextItems();
//     boolean var4 = var0.isAngleGridlinesVisible();
//     var0.clearCornerTextItems();
//     java.awt.Color var9 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var10.getCategoryMiddle(1, 100, var13, var14);
//     java.awt.Stroke var16 = var10.getTickMarkStroke();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var18 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var20 = var19.getBaseStroke();
//     boolean var21 = var18.equals((java.lang.Object)var19);
//     java.awt.Paint var22 = var18.getBaseOutlinePaint();
//     org.jfree.chart.renderer.category.LineRenderer3D var23 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var25 = var23.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var22, var25);
//     org.jfree.chart.renderer.category.LineRenderer3D var27 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var29 = var27.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var9, var16, var22, var29, 0.0f);
//     var0.setNoDataMessagePaint(var22);
//     var0.setRadiusGridlinesVisible(false);
//     var0.zoom(3.0d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer();
    var0.mapDatasetToRangeAxis(0, 68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var1 = var0.getBaseOutlineStroke();
//     var0.setUseOutlinePaint(false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
//     var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
//     var10.setSeriesItemLabelGenerator(2, var12);
//     boolean var14 = var0.equals((java.lang.Object)var10);
//     java.lang.Object var15 = var0.clone();
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var17);
//     int var20 = var17.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var22 = var21.clone();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var21.getCategoryEnd(100, 1, var25, var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var33 = null;
//     var32.setBaseItemLabelFont(var33, true);
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
//     org.jfree.chart.axis.ValueAxis var38 = var36.getRangeAxisForDataset(1);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var39 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var40 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var39);
//     int var42 = var39.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var43 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var44 = var43.clone();
//     java.awt.geom.Rectangle2D var47 = null;
//     org.jfree.chart.util.RectangleEdge var48 = null;
//     double var49 = var43.getCategoryEnd(100, 1, var47, var48);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var54 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var55 = null;
//     var54.setBaseItemLabelFont(var55, true);
//     org.jfree.chart.plot.CategoryPlot var58 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var39, (org.jfree.chart.axis.CategoryAxis)var43, var50, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
//     var58.setWeight(1);
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.entity.EntityCollection var62 = null;
//     org.jfree.chart.ChartRenderingInfo var63 = new org.jfree.chart.ChartRenderingInfo(var62);
//     org.jfree.chart.entity.EntityCollection var64 = var63.getEntityCollection();
//     java.awt.geom.Rectangle2D var65 = var63.getChartArea();
//     org.jfree.chart.plot.XYPlot var66 = new org.jfree.chart.plot.XYPlot();
//     var66.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var69 = var66.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var70 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var58.draw(var61, var65, var69, var70, var71);
//     var0.drawOutline(var16, var36, var65);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var2 = var1.getBaseOutlineStroke();
//     java.lang.Object var3 = var1.clone();
//     org.jfree.chart.event.RendererChangeEvent var4 = new org.jfree.chart.event.RendererChangeEvent(var3);
//     var0.rendererChanged(var4);
//     org.jfree.data.general.WaferMapDataset var6 = null;
//     var0.setDataset(var6);
//     java.lang.String var8 = var0.getPlotType();
//     org.jfree.chart.renderer.WaferMapRenderer var9 = null;
//     var0.setRenderer(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var14 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var13);
//     int var16 = var13.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var18 = var17.clone();
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var17.getCategoryEnd(100, 1, var21, var22);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var28 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var29 = null;
//     var28.setBaseItemLabelFont(var29, true);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, (org.jfree.chart.axis.CategoryAxis)var17, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
//     var32.setWeight(1);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.entity.EntityCollection var36 = null;
//     org.jfree.chart.ChartRenderingInfo var37 = new org.jfree.chart.ChartRenderingInfo(var36);
//     org.jfree.chart.entity.EntityCollection var38 = var37.getEntityCollection();
//     java.awt.geom.Rectangle2D var39 = var37.getChartArea();
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     var40.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var43 = var40.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var44 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     var32.draw(var35, var39, var43, var44, var45);
//     org.jfree.chart.entity.CategoryLabelEntity var49 = new org.jfree.chart.entity.CategoryLabelEntity((java.lang.Comparable)'a', (java.awt.Shape)var39, "hi!", "Nearest");
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var51 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var52 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var51);
//     int var54 = var51.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var55 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var56 = var55.clone();
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var55.getCategoryEnd(100, 1, var59, var60);
//     org.jfree.chart.axis.ValueAxis var62 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var66 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var67 = null;
//     var66.setBaseItemLabelFont(var67, true);
//     org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var51, (org.jfree.chart.axis.CategoryAxis)var55, var62, (org.jfree.chart.renderer.category.CategoryItemRenderer)var66);
//     org.jfree.chart.util.RectangleEdge var72 = var70.getRangeAxisEdge(1);
//     java.awt.Font var73 = var70.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var74 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var73);
//     java.awt.geom.Rectangle2D var75 = var74.getBounds();
//     org.jfree.chart.util.RectangleAnchor var76 = null;
//     java.awt.geom.Point2D var77 = org.jfree.chart.util.RectangleAnchor.coordinates(var75, var76);
//     org.jfree.chart.plot.PlotState var78 = new org.jfree.chart.plot.PlotState();
//     java.util.Map var79 = var78.getSharedAxisStates();
//     org.jfree.chart.plot.PlotRenderingInfo var80 = null;
//     var0.draw(var11, var39, var77, var78, var80);
//     
//     // Checks the contract:  equals-hashcode on var13 and var51
//     assertTrue("Contract failed: equals-hashcode on var13 and var51", var13.equals(var51) ? var13.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var13
//     assertTrue("Contract failed: equals-hashcode on var51 and var13", var51.equals(var13) ? var51.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     var19.setWeight(1);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.entity.EntityCollection var23 = null;
//     org.jfree.chart.ChartRenderingInfo var24 = new org.jfree.chart.ChartRenderingInfo(var23);
//     org.jfree.chart.entity.EntityCollection var25 = var24.getEntityCollection();
//     java.awt.geom.Rectangle2D var26 = var24.getChartArea();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     var27.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var30 = var27.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var31 = new org.jfree.chart.plot.PlotState();
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     var19.draw(var22, var26, var30, var31, var32);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.util.RectangleInsets var35 = new org.jfree.chart.util.RectangleInsets();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var37 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var36);
//     org.jfree.chart.plot.MultiplePiePlot var38 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var36);
//     java.lang.Comparable var39 = var38.getAggregatedItemsKey();
//     org.jfree.chart.JFreeChart var40 = var38.getPieChart();
//     org.jfree.chart.event.ChartChangeEventType var41 = null;
//     org.jfree.chart.event.ChartChangeEvent var42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var40, var41);
//     org.jfree.chart.block.BlockParams var43 = new org.jfree.chart.block.BlockParams();
//     boolean var44 = var43.getGenerateEntities();
//     var43.setGenerateEntities(true);
//     var43.setTranslateY(4.0d);
//     boolean var49 = var40.equals((java.lang.Object)4.0d);
//     var40.removeLegend();
//     var19.addChangeListener((org.jfree.chart.event.PlotChangeListener)var40);
//     
//     // Checks the contract:  equals-hashcode on var0 and var36
//     assertTrue("Contract failed: equals-hashcode on var0 and var36", var0.equals(var36) ? var0.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var0
//     assertTrue("Contract failed: equals-hashcode on var36 and var0", var36.equals(var0) ? var36.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     org.jfree.data.general.SeriesChangeEvent var7 = null;
//     var6.seriesChanged(var7);
//     java.util.List var9 = var6.getColumnKeys();
//     int var10 = var6.getRowCount();
// 
//   }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.renderer.OutlierListCollection var0 = new org.jfree.chart.renderer.OutlierListCollection();
    var0.setHighFarOut(true);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
    java.awt.Paint var26 = null;
    var25.setLabelShadowPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    var25.handleClick(0, 1, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var25.addChangeListener(var32);
    java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
    var19.setRangeCrosshairPaint(var34);
    org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var41 = null;
    var39.setSeriesItemLabelGenerator(2, var41);
    var19.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
    org.jfree.chart.axis.AxisLocation var45 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setRangeAxisLocation((-16777216), var45);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(68, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)(byte)(-1));
    java.lang.Object var8 = var0.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var0.getValue(68);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("Polar Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setShape((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(short)10, var1, 10, 1);
    var4.setType(100);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    var8.setDomainCrosshairVisible(true);
    boolean var11 = var8.isRangeGridlinesVisible();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("October", (org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    var12.setTitle(var13);
    var4.setChart(var12);
    org.jfree.chart.title.Title var16 = null;
    var12.removeSubtitle(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.renderer.category.StackedBarRenderer3D var3 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(100.0d, 0.0d, true);
    double var4 = var3.getYOffset();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var5 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.Range var6 = var3.findRangeBounds((org.jfree.data.category.CategoryDataset)var5);
    java.lang.Comparable var8 = null;
    java.lang.Number var9 = var5.getQ1Value((java.lang.Comparable)10.0d, var8);
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset)var5);
    org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var12 = var11.clone();
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.util.RectangleEdge var16 = null;
    double var17 = var11.getCategoryStart(1, 0, var15, var16);
    java.lang.String var19 = var11.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var23 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var24.getCategoryMiddle(1, 100, var27, var28);
    java.awt.Stroke var30 = var24.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var32 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var34 = var33.getBaseStroke();
    boolean var35 = var32.equals((java.lang.Object)var33);
    java.awt.Paint var36 = var32.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var37 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var39 = var37.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var40 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var36, var39);
    org.jfree.chart.renderer.category.LineRenderer3D var41 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var43 = var41.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var23, var30, var36, var43, 0.0f);
    var11.setAxisLinePaint(var36);
    org.jfree.chart.event.AxisChangeEvent var47 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var11);
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var11, var48, var49);
    org.jfree.data.general.DatasetChangeEvent var51 = null;
    var50.datasetChanged(var51);
    java.awt.Stroke var53 = var50.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     int var5 = var0.getRowIndex((java.lang.Comparable)(-2208927600001L));
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     int var9 = var6.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var11 = var10.clone();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.getCategoryEnd(100, 1, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var22 = null;
//     var21.setBaseItemLabelFont(var22, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     var25.setWeight(1);
//     org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
//     var25.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29, false);
//     boolean var33 = var29.isSeriesVisible(1);
//     boolean var34 = var0.equals((java.lang.Object)1);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
    java.awt.Paint var2 = var1.getPaint();
    java.awt.Paint var3 = var1.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor((-1), (-16777216), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
    java.awt.Paint var26 = null;
    var25.setLabelShadowPaint(var26);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    var25.handleClick(0, 1, var30);
    org.jfree.chart.event.PlotChangeListener var32 = null;
    var25.addChangeListener(var32);
    java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
    var19.setRangeCrosshairPaint(var34);
    var19.clearAnnotations();
    org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.TickUnitSource var38 = null;
    var37.setStandardTickUnits(var38);
    var37.setVerticalTickLabels(true);
    org.jfree.data.Range var42 = var19.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
    java.text.DateFormat var43 = null;
    var37.setDateFormatOverride(var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var37.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var27 = null;
//     org.jfree.chart.event.ChartChangeEventType var28 = null;
//     org.jfree.chart.event.ChartChangeEvent var29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var19, var27, var28);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.entity.EntityCollection var31 = null;
//     org.jfree.chart.ChartRenderingInfo var32 = new org.jfree.chart.ChartRenderingInfo(var31);
//     org.jfree.chart.entity.EntityCollection var33 = var32.getEntityCollection();
//     java.awt.geom.Rectangle2D var34 = var32.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     boolean var37 = var19.render(var30, var34, 100, var36);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var41 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var42 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var41);
//     int var44 = var41.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var45 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var46 = var45.clone();
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var45.getCategoryEnd(100, 1, var49, var50);
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var56 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var57 = null;
//     var56.setBaseItemLabelFont(var57, true);
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var41, (org.jfree.chart.axis.CategoryAxis)var45, var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var56);
//     org.jfree.chart.axis.AxisLocation var62 = null;
//     var60.setRangeAxisLocation(10, var62);
//     org.jfree.chart.axis.ValueAxis var64 = var60.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var66 = var60.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var67 = var60.getRangeAxisEdge();
//     org.jfree.chart.JFreeChart var68 = null;
//     org.jfree.chart.event.ChartChangeEventType var69 = null;
//     org.jfree.chart.event.ChartChangeEvent var70 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var60, var68, var69);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     java.awt.geom.Rectangle2D var74 = null;
//     org.jfree.chart.util.RectangleAnchor var75 = null;
//     java.awt.geom.Point2D var76 = org.jfree.chart.util.RectangleAnchor.coordinates(var74, var75);
//     var60.zoomDomainAxes(1.0d, 0.25d, var73, var76);
//     var19.zoomRangeAxes(0.2d, 0.2d, var40, var76);
//     
//     // Checks the contract:  equals-hashcode on var0 and var41
//     assertTrue("Contract failed: equals-hashcode on var0 and var41", var0.equals(var41) ? var0.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var0
//     assertTrue("Contract failed: equals-hashcode on var41 and var0", var41.equals(var0) ? var41.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var60
//     assertTrue("Contract failed: equals-hashcode on var19 and var60", var19.equals(var60) ? var19.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var19
//     assertTrue("Contract failed: equals-hashcode on var60 and var19", var60.equals(var19) ? var60.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var2 = var1.getBaseStroke();
//     boolean var3 = var0.equals((java.lang.Object)var1);
//     java.awt.Paint var4 = var1.getBasePaint();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var6 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var5);
//     int var8 = var5.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var10 = var9.clone();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var9.getCategoryEnd(100, 1, var13, var14);
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var20 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var21 = null;
//     var20.setBaseItemLabelFont(var21, true);
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, (org.jfree.chart.axis.CategoryAxis)var9, var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var24.setRangeAxisLocation(10, var26);
//     org.jfree.chart.axis.ValueAxis var28 = var24.getRangeAxis();
//     int var29 = var24.getDomainAxisCount();
//     var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
//     boolean var31 = var24.isDomainZoomable();
//     org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var34 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var35 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var34);
//     int var37 = var34.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var39 = var38.clone();
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var38.getCategoryEnd(100, 1, var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var49 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var50 = null;
//     var49.setBaseItemLabelFont(var50, true);
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, (org.jfree.chart.axis.CategoryAxis)var38, var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
//     org.jfree.chart.util.RectangleEdge var55 = var53.getRangeAxisEdge(1);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var56 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var58 = var57.getBaseStroke();
//     boolean var59 = var56.equals((java.lang.Object)var57);
//     boolean var60 = var55.equals((java.lang.Object)var59);
//     var32.ensureAtLeast(Double.NaN, var55);
//     var32.setBottom(4.0d);
//     var32.setBottom(3.0d);
//     var24.setFixedRangeAxisSpace(var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var34
//     assertTrue("Contract failed: equals-hashcode on var5 and var34", var5.equals(var34) ? var5.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var5
//     assertTrue("Contract failed: equals-hashcode on var34 and var5", var34.equals(var5) ? var34.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    java.lang.String var5 = var4.toString();
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var9 = new org.jfree.chart.axis.DateTickUnit(1, 2);
    var6.setTickUnit(var9);
    java.awt.Shape var11 = var6.getDownArrow();
    java.util.Date var12 = var6.getMaximumDate();
    org.jfree.chart.axis.Timeline var13 = var6.getTimeline();
    boolean var14 = var4.equals((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var5.equals("DatasetRenderingOrder.REVERSE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    var0.clear();

  }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     java.util.List var3 = var0.getColumnKeys();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var4 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var4);
//     int var7 = var4.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var9 = var8.clone();
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var8.getCategoryEnd(100, 1, var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var19 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var20 = null;
//     var19.setBaseItemLabelFont(var20, true);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, (org.jfree.chart.axis.CategoryAxis)var8, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
//     org.jfree.chart.util.RectangleEdge var25 = var23.getRangeAxisEdge(1);
//     java.awt.Font var26 = var23.getNoDataMessageFont();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var27 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
//     java.awt.Stroke var29 = var28.getBaseStroke();
//     boolean var30 = var27.equals((java.lang.Object)var28);
//     int var31 = var23.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var32 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.general.PieDataset var34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var32, (java.lang.Comparable)100.0f);
//     java.util.List var35 = var32.getRowKeys();
//     java.util.List var38 = var32.getOutliers((java.lang.Comparable)(byte)100, (java.lang.Comparable)'#');
//     org.jfree.chart.plot.MultiplePiePlot var39 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var32);
//     java.lang.Number var42 = var32.getMedianValue((java.lang.Comparable)"Pie 3D Plot", (java.lang.Comparable)(short)0);
//     org.jfree.data.Range var43 = var27.findRangeBounds((org.jfree.data.category.CategoryDataset)var32);
//     org.jfree.data.general.DatasetGroup var44 = var32.getGroup();
//     var0.setGroup(var44);
//     
//     // Checks the contract:  equals-hashcode on var0 and var4
//     assertTrue("Contract failed: equals-hashcode on var0 and var4", var0.equals(var4) ? var0.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var0
//     assertTrue("Contract failed: equals-hashcode on var4 and var0", var4.equals(var0) ? var4.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var39
//     assertTrue("Contract failed: equals-hashcode on var2 and var39", var2.equals(var39) ? var2.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var2
//     assertTrue("Contract failed: equals-hashcode on var39 and var2", var39.equals(var2) ? var39.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.renderer.category.AreaRenderer var5 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var7 = var5.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var10 = var5.getLegendItem(0, (-1));
//     boolean var11 = var5.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var5.getBaseNegativeItemLabelPosition();
//     org.jfree.chart.text.TextAnchor var13 = var12.getRotationAnchor();
//     java.lang.String var14 = var13.toString();
//     var1.draw(var2, 0.0f, 10.0f, var13, 0.0f, 2.0f, 1.0E-5d);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.awt.Color var3 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.util.RectangleEdge var8 = null;
    double var9 = var4.getCategoryMiddle(1, 100, var7, var8);
    java.awt.Stroke var10 = var4.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var12 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var14 = var13.getBaseStroke();
    boolean var15 = var12.equals((java.lang.Object)var13);
    java.awt.Paint var16 = var12.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var17 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var19 = var17.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var20 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var16, var19);
    org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var23 = var21.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var3, var10, var16, var23, 0.0f);
    var25.setStartValue(100.0d);
    org.jfree.chart.text.TextAnchor var28 = var25.getLabelTextAnchor();
    org.jfree.chart.util.GradientPaintTransformer var29 = var25.getGradientPaintTransformer();
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot3D var31 = new org.jfree.chart.plot.PiePlot3D(var30);
    org.jfree.chart.labels.PieToolTipGenerator var32 = var31.getToolTipGenerator();
    org.jfree.chart.labels.PieSectionLabelGenerator var33 = var31.getLegendLabelGenerator();
    org.jfree.chart.renderer.category.AreaRenderer var34 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var34.getSeriesItemLabelGenerator(0);
    org.jfree.chart.LegendItem var39 = var34.getLegendItem(0, (-1));
    org.jfree.chart.renderer.AreaRendererEndType var40 = var34.getEndType();
    org.jfree.chart.plot.PolarPlot var41 = new org.jfree.chart.plot.PolarPlot();
    boolean var42 = var41.isDomainZoomable();
    org.jfree.chart.axis.ValueAxis var43 = var41.getAxis();
    var41.clearCornerTextItems();
    var34.addChangeListener((org.jfree.chart.event.RendererChangeListener)var41);
    boolean var46 = var31.equals((java.lang.Object)var34);
    double var47 = var31.getMaximumLabelWidth();
    java.awt.Stroke var48 = var31.getLabelLinkStroke();
    var25.setStroke(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var1 = var0.clone();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var0.getCategoryStart(1, 0, var4, var5);
    java.lang.String var8 = var0.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var12 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var13 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleEdge var17 = null;
    double var18 = var13.getCategoryMiddle(1, 100, var16, var17);
    java.awt.Stroke var19 = var13.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var21 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var23 = var22.getBaseStroke();
    boolean var24 = var21.equals((java.lang.Object)var22);
    java.awt.Paint var25 = var21.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var26 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var28 = var26.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var29 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var25, var28);
    org.jfree.chart.renderer.category.LineRenderer3D var30 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var32 = var30.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var34 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var12, var19, var25, var32, 0.0f);
    var0.setAxisLineStroke(var32);
    org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var37 = var36.getBaseOutlineStroke();
    java.lang.Object var38 = var36.clone();
    double var39 = var36.getYOffset();
    java.awt.Font var42 = var36.getItemLabelFont(1, 100);
    var0.setLabelFont(var42);
    var0.setCategoryLabelPositionOffset(1);
    org.jfree.chart.axis.CategoryLabelPositions var47 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(100.0d);
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.util.RectangleEdge var69 = var67.getRangeAxisEdge(1);
    org.jfree.chart.axis.CategoryLabelPosition var70 = var47.getLabelPosition(var69);
    org.jfree.chart.axis.CategoryLabelPosition var71 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var72 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var47, var71);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var73 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var74 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var75 = var74.getBaseStroke();
    boolean var76 = var73.equals((java.lang.Object)var74);
    double var77 = var73.getMinimumBarLength();
    boolean var78 = var72.equals((java.lang.Object)var77);
    var0.setCategoryLabelPositions(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    var0.setValue((java.lang.Comparable)var4, (java.lang.Number)(byte)(-1));
    var0.addValue((java.lang.Comparable)"Polar Plot", 8.0d);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var17 = var14.getEndOfCurrentMonth(var16);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.insertValue((-16777216), (java.lang.Comparable)var16, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("AxisLocation.TOP_OR_RIGHT");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var0);
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, 0.0d);
//     java.lang.Number var7 = var0.getValue((java.lang.Comparable)(byte)10, (java.lang.Comparable)(-16777216));
//     double var9 = var0.getRangeUpperBound(true);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var12 = var0.getStdDevValue((-16777216), 100);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
    org.jfree.data.general.SeriesChangeEvent var7 = null;
    var6.seriesChanged(var7);
    java.util.List var9 = var6.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var6.getValue(2, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var2 = var0.getTimeFromLong(0L);
//     long var4 = var0.toTimelineValue(100L);
//     org.jfree.chart.axis.SegmentedTimeline var5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     long var7 = var5.getTimeFromLong(0L);
//     long var9 = var5.toMillisecond(10L);
//     var0.setBaseTimeline(var5);
//     java.util.Date var11 = null;
//     org.jfree.chart.axis.SegmentedTimeline.Segment var12 = var5.getSegment(var11);
// 
//   }

  public void test462() {}
//   public void test462() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }
// 
// 
//     org.jfree.chart.renderer.category.AreaRenderer var0 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var1 = var0.getEndType();
//     java.awt.Paint var3 = var0.lookupSeriesOutlinePaint(0);
//     org.jfree.chart.urls.CategoryURLGenerator var4 = null;
//     var0.setBaseURLGenerator(var4, true);
//     org.jfree.chart.renderer.category.AreaRenderer var7 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var7.getSeriesItemLabelGenerator(0);
//     org.jfree.chart.LegendItem var12 = var7.getLegendItem(0, (-1));
//     org.jfree.chart.renderer.AreaRendererEndType var13 = var7.getEndType();
//     org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine();
//     boolean var15 = var13.equals((java.lang.Object)var14);
//     var0.setEndType(var13);
//     org.jfree.chart.renderer.category.LineRenderer3D var18 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     java.awt.Stroke var20 = var18.lookupSeriesOutlineStroke(100);
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var22 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
//     org.jfree.chart.labels.ItemLabelPosition var24 = var22.getSeriesPositiveItemLabelPosition(1);
//     var18.setSeriesPositiveItemLabelPosition(1, var24, true);
//     var0.setSeriesPositiveItemLabelPosition(100, var24, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var7 and var0.", var7.equals(var0) == var0.equals(var7));
// 
//   }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    var0.clear();

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    org.jfree.chart.title.TextTitle var23 = var14.getTitle();
    boolean var24 = var14.isBorderVisible();
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var27 = var26.getBackgroundPaint();
    java.lang.Object var28 = var26.clone();
    org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var32 = var31.getBaseOutlineStroke();
    java.lang.Object var33 = var31.clone();
    double var34 = var31.getYOffset();
    java.awt.Font var37 = var31.getItemLabelFont(1, 100);
    java.awt.Color var41 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var42 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var45 = null;
    org.jfree.chart.util.RectangleEdge var46 = null;
    double var47 = var42.getCategoryMiddle(1, 100, var45, var46);
    java.awt.Stroke var48 = var42.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var50 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var52 = var51.getBaseStroke();
    boolean var53 = var50.equals((java.lang.Object)var51);
    java.awt.Paint var54 = var50.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var55 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var57 = var55.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var58 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var54, var57);
    org.jfree.chart.renderer.category.LineRenderer3D var59 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var61 = var59.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var63 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var41, var48, var54, var61, 0.0f);
    org.jfree.chart.text.TextFragment var64 = new org.jfree.chart.text.TextFragment("October", var37, var54);
    java.awt.Color var68 = java.awt.Color.getHSBColor(1.0f, 100.0f, 10.0f);
    org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("WMAP_Plot", var37, (java.awt.Paint)var68);
    org.jfree.chart.util.HorizontalAlignment var70 = var69.getLineAlignment();
    var26.setHorizontalAlignment(var70);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.addSubtitle(10, (org.jfree.chart.title.Title)var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var27.getRangeMarkers(1, var29);
//     java.awt.Paint var31 = var27.getRangeZeroBaselinePaint();
//     java.util.List var32 = var27.getAnnotations();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var33 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var34 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var33);
//     int var36 = var33.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var38 = var37.clone();
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.util.RectangleEdge var42 = null;
//     double var43 = var37.getCategoryEnd(100, 1, var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var48 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var49 = null;
//     var48.setBaseItemLabelFont(var49, true);
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, (org.jfree.chart.axis.CategoryAxis)var37, var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
//     org.jfree.chart.axis.AxisLocation var54 = null;
//     var52.setRangeAxisLocation(10, var54);
//     boolean var56 = var52.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var57 = var52.getDomainAxisLocation();
//     java.lang.String var58 = var57.toString();
//     org.jfree.chart.axis.AxisLocation var59 = org.jfree.chart.axis.AxisLocation.getOpposite(var57);
//     var27.setDomainAxisLocation(var57);
//     var19.setDomainAxisLocation(var57);
//     
//     // Checks the contract:  equals-hashcode on var0 and var33
//     assertTrue("Contract failed: equals-hashcode on var0 and var33", var0.equals(var33) ? var0.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var0
//     assertTrue("Contract failed: equals-hashcode on var33 and var0", var33.equals(var0) ? var33.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)(short)0);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.axis.ValueAxis var1 = var0.getAxis();
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     boolean var3 = var0.equals((java.lang.Object)var2);
//     java.lang.String var4 = var0.getPlotType();
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     var8.setDomainCrosshairVisible(true);
//     java.awt.geom.Point2D var11 = var8.getQuadrantOrigin();
//     var0.zoomRangeAxes((-100.0d), 4.0d, var7, var11);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.TickUnitSource var1 = null;
//     var0.setStandardTickUnits(var1);
//     boolean var3 = var0.isAutoTickUnitSelection();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var6 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var7 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     int var9 = var6.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var11 = var10.clone();
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.chart.util.RectangleEdge var15 = null;
//     double var16 = var10.getCategoryEnd(100, 1, var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var21 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var22 = null;
//     var21.setBaseItemLabelFont(var22, true);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, (org.jfree.chart.axis.CategoryAxis)var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
//     org.jfree.data.Range var26 = var5.findRangeBounds((org.jfree.data.category.CategoryDataset)var6);
//     org.jfree.data.Range var28 = null;
//     org.jfree.chart.block.RectangleConstraint var29 = new org.jfree.chart.block.RectangleConstraint(10.0d, var28);
//     org.jfree.chart.block.LengthConstraintType var30 = var29.getWidthConstraintType();
//     org.jfree.data.time.DateRange var34 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     org.jfree.data.Range var36 = null;
//     org.jfree.chart.block.RectangleConstraint var37 = new org.jfree.chart.block.RectangleConstraint(10.0d, var36);
//     org.jfree.chart.block.LengthConstraintType var38 = var37.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(0.05d, var26, var30, (-1.0d), (org.jfree.data.Range)var34, var38);
//     org.jfree.chart.renderer.category.WaterfallBarRenderer var40 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
//     boolean var41 = var34.equals((java.lang.Object)var40);
//     java.util.Date var42 = var34.getLowerDate();
//     org.jfree.chart.entity.EntityCollection var43 = null;
//     org.jfree.chart.ChartRenderingInfo var44 = new org.jfree.chart.ChartRenderingInfo(var43);
//     org.jfree.chart.entity.EntityCollection var45 = var44.getEntityCollection();
//     java.awt.geom.Rectangle2D var46 = var44.getChartArea();
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
//     boolean var48 = var47.isRangeCrosshairLockedOnData();
//     int var49 = var47.getWeight();
//     java.awt.Stroke var50 = var47.getRangeCrosshairStroke();
//     org.jfree.chart.util.RectangleEdge var52 = var47.getRangeAxisEdge(100);
//     double var53 = var0.dateToJava2D(var42, var46, var52);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var54 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var55 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var54);
//     int var57 = var54.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var59 = var58.clone();
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.util.RectangleEdge var63 = null;
//     double var64 = var58.getCategoryEnd(100, 1, var62, var63);
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var69 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var70 = null;
//     var69.setBaseItemLabelFont(var70, true);
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var54, (org.jfree.chart.axis.CategoryAxis)var58, var65, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
//     org.jfree.chart.axis.AxisLocation var75 = null;
//     var73.setRangeAxisLocation(10, var75);
//     org.jfree.chart.axis.ValueAxis var77 = var73.getRangeAxis();
//     org.jfree.chart.axis.CategoryAxis var79 = var73.getDomainAxisForDataset(100);
//     org.jfree.chart.util.RectangleEdge var80 = var73.getRangeAxisEdge();
//     double var81 = org.jfree.chart.util.RectangleEdge.coordinate(var46, var80);
//     
//     // Checks the contract:  equals-hashcode on var6 and var54
//     assertTrue("Contract failed: equals-hashcode on var6 and var54", var6.equals(var54) ? var6.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var6
//     assertTrue("Contract failed: equals-hashcode on var54 and var6", var54.equals(var6) ? var54.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var73
//     assertTrue("Contract failed: equals-hashcode on var25 and var73", var25.equals(var73) ? var25.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var25
//     assertTrue("Contract failed: equals-hashcode on var73 and var25", var73.equals(var25) ? var73.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeCrosshairLockedOnData();
//     int var2 = var0.getWeight();
//     org.jfree.chart.axis.DateAxis var4 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickUnit var7 = new org.jfree.chart.axis.DateTickUnit(1, 2);
//     var4.setTickUnit(var7);
//     org.jfree.chart.axis.SegmentedTimeline var9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     int var10 = var9.getSegmentsExcluded();
//     java.lang.Object var11 = null;
//     boolean var12 = var9.equals(var11);
//     var4.setTimeline((org.jfree.chart.axis.Timeline)var9);
//     var0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis)var4);
//     org.jfree.chart.axis.DateTickUnit var15 = null;
//     java.util.Date var16 = var4.calculateHighestVisibleTickValue(var15);
// 
//   }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     boolean var1 = var0.isRangeCrosshairLockedOnData();
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     int var3 = var0.getRangeAxisIndex(var2);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var10 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     double var12 = var10.calculateRightOutset(8.0d);
//     var5.setMargin(var10);
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D(var14);
//     java.awt.Paint var16 = null;
//     var15.setLabelShadowPaint(var16);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     var15.handleClick(0, 1, var20);
//     org.jfree.chart.event.PlotChangeListener var22 = null;
//     var15.addChangeListener(var22);
//     org.jfree.chart.event.PlotChangeEvent var24 = null;
//     var15.notifyListeners(var24);
//     java.awt.Color var27 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
//     org.jfree.chart.labels.PieSectionLabelGenerator var30 = var29.getLabelGenerator();
//     var29.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var33 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var34 = var33.getEndType();
//     java.awt.Stroke var35 = var33.getBaseOutlineStroke();
//     var29.setOutlineStroke(var35);
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var37.getCategoryMiddle(1, 100, var40, var41);
//     org.jfree.chart.util.RectangleInsets var47 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var37.setLabelInsets(var47);
//     org.jfree.chart.block.LineBorder var49 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var27, var35, var47);
//     var15.setOutlinePaint((java.awt.Paint)var27);
//     org.jfree.chart.block.BlockBorder var51 = new org.jfree.chart.block.BlockBorder(var10, (java.awt.Paint)var27);
//     java.awt.Color var52 = var27.brighter();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var53 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var54 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var53);
//     int var56 = var53.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var57 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var58 = var57.clone();
//     java.awt.geom.Rectangle2D var61 = null;
//     org.jfree.chart.util.RectangleEdge var62 = null;
//     double var63 = var57.getCategoryEnd(100, 1, var61, var62);
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var68 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var69 = null;
//     var68.setBaseItemLabelFont(var69, true);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var53, (org.jfree.chart.axis.CategoryAxis)var57, var64, (org.jfree.chart.renderer.category.CategoryItemRenderer)var68);
//     org.jfree.chart.axis.AxisLocation var74 = null;
//     var72.setRangeAxisLocation(10, var74);
//     boolean var76 = var72.getDrawSharedDomainAxis();
//     org.jfree.chart.axis.AxisLocation var77 = var72.getDomainAxisLocation();
//     boolean var78 = var72.isDomainZoomable();
//     java.awt.Stroke var79 = var72.getDomainGridlineStroke();
//     org.jfree.chart.util.RectangleInsets var84 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     double var86 = var84.calculateRightOutset(8.0d);
//     org.jfree.chart.block.LineBorder var87 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var52, var79, var84);
//     org.jfree.chart.entity.EntityCollection var88 = null;
//     org.jfree.chart.ChartRenderingInfo var89 = new org.jfree.chart.ChartRenderingInfo(var88);
//     org.jfree.chart.entity.EntityCollection var90 = var89.getEntityCollection();
//     java.awt.geom.Rectangle2D var91 = var89.getChartArea();
//     java.awt.geom.Rectangle2D var92 = var84.createInsetRectangle(var91);
//     org.jfree.chart.util.RectangleAnchor var93 = null;
//     java.awt.geom.Point2D var94 = org.jfree.chart.util.RectangleAnchor.coordinates(var91, var93);
//     var0.drawBackground(var4, var91);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset)var0, true);
//     org.jfree.data.general.DatasetGroup var7 = new org.jfree.data.general.DatasetGroup("({0}, {1}) = {3} - {4}");
//     var0.setGroup(var7);
//     java.awt.Color var10 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot3D var12 = new org.jfree.chart.plot.PiePlot3D(var11);
//     org.jfree.chart.labels.PieSectionLabelGenerator var13 = var12.getLabelGenerator();
//     var12.zoom(0.0d);
//     org.jfree.chart.renderer.category.AreaRenderer var16 = new org.jfree.chart.renderer.category.AreaRenderer();
//     org.jfree.chart.renderer.AreaRendererEndType var17 = var16.getEndType();
//     java.awt.Stroke var18 = var16.getBaseOutlineStroke();
//     var12.setOutlineStroke(var18);
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     double var25 = var20.getCategoryMiddle(1, 100, var23, var24);
//     org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
//     var20.setLabelInsets(var30);
//     org.jfree.chart.block.LineBorder var32 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var18, var30);
//     double var34 = var30.calculateRightInset(4.0d);
//     boolean var35 = var7.equals((java.lang.Object)var30);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var37 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var38 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var37);
//     int var40 = var37.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var42 = var41.clone();
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var41.getCategoryEnd(100, 1, var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var52 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var53 = null;
//     var52.setBaseItemLabelFont(var53, true);
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var37, (org.jfree.chart.axis.CategoryAxis)var41, var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var52);
//     org.jfree.chart.util.RectangleEdge var58 = var56.getRangeAxisEdge(1);
//     java.awt.Font var59 = var56.getNoDataMessageFont();
//     org.jfree.chart.title.TextTitle var60 = new org.jfree.chart.title.TextTitle("WMAP_Plot", var59);
//     java.awt.geom.Rectangle2D var61 = var60.getBounds();
//     java.awt.geom.Rectangle2D var64 = var30.createInsetRectangle(var61, true, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var37
//     assertTrue("Contract failed: equals-hashcode on var0 and var37", var0.equals(var37) ? var0.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var0
//     assertTrue("Contract failed: equals-hashcode on var37 and var0", var37.equals(var0) ? var37.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.renderer.category.AreaRenderer var1 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var2 = var1.getEndType();
    java.awt.Stroke var3 = var1.getBaseOutlineStroke();
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var6 = var5.clone();
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.util.RectangleEdge var10 = null;
    double var11 = var5.getCategoryStart(1, 0, var9, var10);
    java.lang.String var13 = var5.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var17 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var18.getCategoryMiddle(1, 100, var21, var22);
    java.awt.Stroke var24 = var18.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var26 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var28 = var27.getBaseStroke();
    boolean var29 = var26.equals((java.lang.Object)var27);
    java.awt.Paint var30 = var26.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var33 = var31.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var30, var33);
    org.jfree.chart.renderer.category.LineRenderer3D var35 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var37 = var35.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var39 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var17, var24, var30, var37, 0.0f);
    var5.setAxisLineStroke(var37);
    org.jfree.chart.renderer.category.LineRenderer3D var41 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var42 = var41.getBaseOutlineStroke();
    java.lang.Object var43 = var41.clone();
    double var44 = var41.getYOffset();
    java.awt.Font var47 = var41.getItemLabelFont(1, 100);
    var5.setLabelFont(var47);
    var1.setSeriesItemLabelFont(100, var47, true);
    org.jfree.chart.plot.WaferMapPlot var51 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.renderer.category.LineRenderer3D var52 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var53 = var52.getBaseOutlineStroke();
    java.lang.Object var54 = var52.clone();
    org.jfree.chart.event.RendererChangeEvent var55 = new org.jfree.chart.event.RendererChangeEvent(var54);
    var51.rendererChanged(var55);
    boolean var57 = var1.equals((java.lang.Object)var51);
    java.awt.Paint var60 = var1.getItemLabelPaint(0, 10);
    org.jfree.data.KeyedObject var61 = new org.jfree.data.KeyedObject((java.lang.Comparable)0.25d, (java.lang.Object)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var1 = var0.getBaseOutlineStroke();
    var0.setUseOutlinePaint(false);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var7);
    org.jfree.chart.util.RectangleInsets var9 = new org.jfree.chart.util.RectangleInsets();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.plot.MultiplePiePlot var12 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var10);
    java.lang.Comparable var13 = var12.getAggregatedItemsKey();
    org.jfree.chart.JFreeChart var14 = var12.getPieChart();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var9, var14, var15);
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    java.awt.Paint var18 = var17.getBackgroundPaint();
    java.lang.Object var19 = var17.clone();
    org.jfree.chart.util.RectangleInsets var20 = var17.getPadding();
    var14.setTitle(var17);
    var8.setChart(var14);
    org.jfree.chart.title.TextTitle var23 = var14.getTitle();
    boolean var24 = var14.isBorderVisible();
    org.jfree.chart.title.Title var25 = null;
    var14.removeSubtitle(var25);
    var14.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Other"+ "'", var13.equals("Other"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.util.Layer var2 = null;
    java.util.Collection var3 = var0.getRangeMarkers(1, var2);
    org.jfree.chart.plot.DatasetRenderingOrder var4 = var0.getDatasetRenderingOrder();
    var0.setOutlineVisible(false);
    org.jfree.chart.LegendItemCollection var7 = var0.getFixedLegendItems();
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    int var9 = var0.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     org.jfree.chart.labels.PieToolTipGenerator var2 = var1.getToolTipGenerator();
//     java.awt.Stroke var3 = var1.getLabelOutlineStroke();
//     double var4 = var1.getShadowXOffset();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot3D var6 = new org.jfree.chart.plot.PiePlot3D(var5);
//     double var7 = var6.getInteriorGap();
//     org.jfree.chart.labels.PieSectionLabelGenerator var8 = var6.getLegendLabelGenerator();
//     var1.setLabelGenerator(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot3D var25 = new org.jfree.chart.plot.PiePlot3D(var24);
//     java.awt.Paint var26 = null;
//     var25.setLabelShadowPaint(var26);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     var25.handleClick(0, 1, var30);
//     org.jfree.chart.event.PlotChangeListener var32 = null;
//     var25.addChangeListener(var32);
//     java.awt.Paint var34 = var25.getBaseSectionOutlinePaint();
//     var19.setRangeCrosshairPaint(var34);
//     var19.clearAnnotations();
//     org.jfree.chart.axis.DateAxis var37 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.TickUnitSource var38 = null;
//     var37.setStandardTickUnits(var38);
//     var37.setVerticalTickLabels(true);
//     org.jfree.data.Range var42 = var19.getDataRange((org.jfree.chart.axis.ValueAxis)var37);
//     java.text.DateFormat var43 = null;
//     var37.setDateFormatOverride(var43);
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var46 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var47 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var48 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var47);
//     int var50 = var47.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var52 = var51.clone();
//     java.awt.geom.Rectangle2D var55 = null;
//     org.jfree.chart.util.RectangleEdge var56 = null;
//     double var57 = var51.getCategoryEnd(100, 1, var55, var56);
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var62 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var63 = null;
//     var62.setBaseItemLabelFont(var63, true);
//     org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var47, (org.jfree.chart.axis.CategoryAxis)var51, var58, (org.jfree.chart.renderer.category.CategoryItemRenderer)var62);
//     org.jfree.data.Range var67 = var46.findRangeBounds((org.jfree.data.category.CategoryDataset)var47);
//     org.jfree.data.Range var69 = null;
//     org.jfree.chart.block.RectangleConstraint var70 = new org.jfree.chart.block.RectangleConstraint(10.0d, var69);
//     org.jfree.chart.block.LengthConstraintType var71 = var70.getWidthConstraintType();
//     org.jfree.data.time.DateRange var75 = new org.jfree.data.time.DateRange(10.0d, 100.0d);
//     org.jfree.data.Range var77 = null;
//     org.jfree.chart.block.RectangleConstraint var78 = new org.jfree.chart.block.RectangleConstraint(10.0d, var77);
//     org.jfree.chart.block.LengthConstraintType var79 = var78.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var80 = new org.jfree.chart.block.RectangleConstraint(0.05d, var67, var71, (-1.0d), (org.jfree.data.Range)var75, var79);
//     var37.setRange((org.jfree.data.Range)var75, false, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var47
//     assertTrue("Contract failed: equals-hashcode on var0 and var47", var0.equals(var47) ? var0.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var0
//     assertTrue("Contract failed: equals-hashcode on var47 and var0", var47.equals(var0) ? var47.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("RectangleInsets[t=1.0,l=-1.0,b=1.0,r=8.0]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    java.text.AttributedString var0 = null;
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot3D var5 = new org.jfree.chart.plot.PiePlot3D(var4);
    java.awt.Paint var6 = null;
    var5.setLabelShadowPaint(var6);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    var5.handleClick(0, 1, var10);
    org.jfree.chart.event.PlotChangeListener var12 = null;
    var5.addChangeListener(var12);
    var5.setIgnoreNullValues(false);
    java.awt.Shape var16 = var5.getLegendItemShape();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var17 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var18 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var17);
    int var20 = var17.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var22 = var21.clone();
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var21.getCategoryEnd(100, 1, var25, var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var32 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var33 = null;
    var32.setBaseItemLabelFont(var33, true);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, (org.jfree.chart.axis.CategoryAxis)var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setRangeAxisLocation(10, var38);
    boolean var40 = var36.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var41 = var36.getDomainAxisLocation();
    boolean var42 = var36.isDomainZoomable();
    java.awt.Stroke var43 = var36.getDomainGridlineStroke();
    java.awt.Paint var44 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull", "0,0,1,1", "Polar Plot", var16, var43, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + Double.NaN+ "'", var18.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 68);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    java.lang.Comparable[] var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var6.getStartValue(255, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var1 = var0.getBaseURLGenerator();
    java.lang.Boolean var3 = var0.getSeriesLinesVisible(100);
    java.awt.Paint var5 = var0.lookupSeriesPaint(100);
    org.jfree.chart.urls.CategoryURLGenerator var7 = var0.getSeriesURLGenerator(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var2 = var0.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var3 = var2.getYear();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    long var2 = var0.getTimeFromLong(0L);
    var0.addException(1L, 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.RangeType var1 = var0.getRangeType();
    boolean var2 = var0.getAutoRangeIncludesZero();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize((-100.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("XY Plot", var1);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var2 = var1.getLabelGenerator();
    var1.zoom(0.0d);
    boolean var5 = var1.getLabelLinksVisible();
    org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var6 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)100.0f);
    java.util.List var9 = var6.getRowKeys();
    java.util.List var12 = var6.getOutliers((java.lang.Comparable)(byte)100, (java.lang.Comparable)'#');
    org.jfree.chart.plot.MultiplePiePlot var13 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.data.general.PieDataset var15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var6, (java.lang.Comparable)(byte)0);
    var1.setDataset(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.RectangleEdge var21 = var19.getRangeAxisEdge(1);
    java.awt.Font var22 = var19.getNoDataMessageFont();
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var24 = var23.clone();
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.util.RectangleEdge var28 = null;
    double var29 = var23.getCategoryStart(1, 0, var27, var28);
    java.lang.String var31 = var23.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    java.awt.Color var35 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var36.getCategoryMiddle(1, 100, var39, var40);
    java.awt.Stroke var42 = var36.getTickMarkStroke();
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var44 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Stroke var46 = var45.getBaseStroke();
    boolean var47 = var44.equals((java.lang.Object)var45);
    java.awt.Paint var48 = var44.getBaseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var49 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var51 = var49.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.ValueMarker var52 = new org.jfree.chart.plot.ValueMarker(Double.NaN, var48, var51);
    org.jfree.chart.renderer.category.LineRenderer3D var53 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var55 = var53.lookupSeriesOutlineStroke(100);
    org.jfree.chart.plot.IntervalMarker var57 = new org.jfree.chart.plot.IntervalMarker(1.0d, 0.0d, (java.awt.Paint)var35, var42, var48, var55, 0.0f);
    var23.setAxisLineStroke(var55);
    org.jfree.data.general.PieDataset var59 = null;
    org.jfree.chart.plot.PiePlot3D var60 = new org.jfree.chart.plot.PiePlot3D(var59);
    java.awt.Paint var61 = null;
    var60.setLabelShadowPaint(var61);
    org.jfree.chart.plot.PlotRenderingInfo var65 = null;
    var60.handleClick(0, 1, var65);
    var23.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var60);
    java.awt.Paint var68 = var23.getTickMarkPaint();
    java.util.List var69 = var19.getCategoriesForAxis((org.jfree.chart.axis.CategoryAxis)var23);
    org.jfree.chart.renderer.category.LineRenderer3D var71 = new org.jfree.chart.renderer.category.LineRenderer3D();
    java.awt.Stroke var72 = var71.getBaseOutlineStroke();
    java.lang.Object var73 = var71.clone();
    double var74 = var71.getYOffset();
    boolean var75 = var71.getDrawOutlines();
    org.jfree.data.general.PieDataset var76 = null;
    org.jfree.chart.plot.PiePlot3D var77 = new org.jfree.chart.plot.PiePlot3D(var76);
    org.jfree.chart.labels.PieToolTipGenerator var78 = var77.getToolTipGenerator();
    java.awt.Stroke var79 = var77.getLabelOutlineStroke();
    double var80 = var77.getShadowXOffset();
    var77.setShadowYOffset(0.05d);
    boolean var83 = var71.equals((java.lang.Object)0.05d);
    var19.setRenderer(10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var71, false);
    var19.mapDatasetToDomainAxis(68, 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    var1.handleClick(0, 1, var6);
    int var8 = var1.getPieIndex();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var10 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var10);
    int var13 = var10.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var15 = var14.clone();
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.util.RectangleEdge var19 = null;
    double var20 = var14.getCategoryEnd(100, 1, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var25 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var26 = null;
    var25.setBaseItemLabelFont(var26, true);
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, (org.jfree.chart.axis.CategoryAxis)var14, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.axis.AxisLocation var31 = null;
    var29.setRangeAxisLocation(10, var31);
    org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var35 = var34.clone();
    java.awt.geom.Rectangle2D var38 = null;
    org.jfree.chart.util.RectangleEdge var39 = null;
    double var40 = var34.getCategoryStart(1, 0, var38, var39);
    java.lang.String var42 = var34.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
    var29.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var34);
    java.awt.Paint var44 = var34.getLabelPaint();
    var1.setSectionOutlinePaint((java.lang.Comparable)(-2208927599990L), var44);
    org.jfree.chart.plot.PolarPlot var46 = new org.jfree.chart.plot.PolarPlot();
    boolean var47 = var46.isDomainZoomable();
    org.jfree.chart.axis.ValueAxis var48 = var46.getAxis();
    var46.clearCornerTextItems();
    boolean var50 = var46.isAngleGridlinesVisible();
    java.awt.Stroke var51 = var46.getRadiusGridlineStroke();
    var1.setBaseSectionOutlineStroke(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + Double.NaN+ "'", var11.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot3D var10 = new org.jfree.chart.plot.PiePlot3D(var9);
    java.awt.Paint var11 = null;
    var10.setLabelShadowPaint(var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    var10.handleClick(0, 1, var15);
    org.jfree.chart.event.PlotChangeListener var17 = null;
    var10.addChangeListener(var17);
    org.jfree.chart.event.PlotChangeEvent var19 = null;
    var10.notifyListeners(var19);
    java.awt.Color var22 = org.jfree.chart.util.PaintUtilities.stringToColor("null version null.\nnull.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:null\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY null:None\nnull LICENCE TERMS:\nnull");
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.PiePlot3D var24 = new org.jfree.chart.plot.PiePlot3D(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var24.getLabelGenerator();
    var24.zoom(0.0d);
    org.jfree.chart.renderer.category.AreaRenderer var28 = new org.jfree.chart.renderer.category.AreaRenderer();
    org.jfree.chart.renderer.AreaRendererEndType var29 = var28.getEndType();
    java.awt.Stroke var30 = var28.getBaseOutlineStroke();
    var24.setOutlineStroke(var30);
    org.jfree.chart.axis.CategoryAxis3D var32 = new org.jfree.chart.axis.CategoryAxis3D();
    java.awt.geom.Rectangle2D var35 = null;
    org.jfree.chart.util.RectangleEdge var36 = null;
    double var37 = var32.getCategoryMiddle(1, 100, var35, var36);
    org.jfree.chart.util.RectangleInsets var42 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    var32.setLabelInsets(var42);
    org.jfree.chart.block.LineBorder var44 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var30, var42);
    var10.setOutlinePaint((java.awt.Paint)var22);
    org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder(var5, (java.awt.Paint)var22);
    java.awt.Color var47 = var22.brighter();
    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var48 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var49 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var48);
    int var51 = var48.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var52 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var53 = var52.clone();
    java.awt.geom.Rectangle2D var56 = null;
    org.jfree.chart.util.RectangleEdge var57 = null;
    double var58 = var52.getCategoryEnd(100, 1, var56, var57);
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var63 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var64 = null;
    var63.setBaseItemLabelFont(var64, true);
    org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, (org.jfree.chart.axis.CategoryAxis)var52, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.axis.AxisLocation var69 = null;
    var67.setRangeAxisLocation(10, var69);
    boolean var71 = var67.getDrawSharedDomainAxis();
    org.jfree.chart.axis.AxisLocation var72 = var67.getDomainAxisLocation();
    boolean var73 = var67.isDomainZoomable();
    java.awt.Stroke var74 = var67.getDomainGridlineStroke();
    org.jfree.chart.util.RectangleInsets var79 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var81 = var79.calculateRightOutset(8.0d);
    org.jfree.chart.block.LineBorder var82 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var47, var74, var79);
    org.jfree.chart.entity.EntityCollection var83 = null;
    org.jfree.chart.ChartRenderingInfo var84 = new org.jfree.chart.ChartRenderingInfo(var83);
    org.jfree.chart.entity.EntityCollection var85 = var84.getEntityCollection();
    java.awt.geom.Rectangle2D var86 = var84.getChartArea();
    java.awt.geom.Rectangle2D var87 = var79.createInsetRectangle(var86);
    org.jfree.chart.renderer.category.LineRenderer3D var88 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.urls.CategoryURLGenerator var89 = var88.getBaseURLGenerator();
    java.lang.Boolean var91 = var88.getSeriesLinesVisible(100);
    java.awt.Paint var93 = var88.lookupSeriesPaint(100);
    org.jfree.chart.title.LegendGraphic var94 = new org.jfree.chart.title.LegendGraphic((java.awt.Shape)var86, var93);
    java.awt.Shape var97 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(10.0f, 10.0f);
    var94.setLine(var97);
    java.awt.Paint var99 = var94.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + Double.NaN+ "'", var49.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var99);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     int var3 = var2.getSeriesCount();
//     org.jfree.chart.renderer.xy.XYItemRenderer var5 = var2.getRenderer(0);
//     org.jfree.chart.JFreeChart var7 = new org.jfree.chart.JFreeChart("LengthConstraintType.FIXED", var1, (org.jfree.chart.plot.Plot)var2, true);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     boolean var10 = var9.isRangeCrosshairLockedOnData();
//     org.jfree.data.general.DatasetChangeEvent var11 = null;
//     var9.datasetChanged(var11);
//     java.awt.Stroke var13 = var9.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.IntervalMarker var16 = new org.jfree.chart.plot.IntervalMarker(0.0d, 0.0d);
//     var9.addDomainMarker((org.jfree.chart.plot.Marker)var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.entity.EntityCollection var19 = null;
//     org.jfree.chart.ChartRenderingInfo var20 = new org.jfree.chart.ChartRenderingInfo(var19);
//     org.jfree.chart.entity.EntityCollection var21 = var20.getEntityCollection();
//     java.awt.geom.Rectangle2D var22 = var20.getChartArea();
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     var9.drawAnnotations(var18, var22, var23);
//     org.jfree.chart.entity.EntityCollection var25 = null;
//     org.jfree.chart.ChartRenderingInfo var26 = new org.jfree.chart.ChartRenderingInfo(var25);
//     var7.draw(var8, var22, var26);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    boolean var1 = var0.isRangeCrosshairLockedOnData();
    org.jfree.chart.axis.ValueAxis var2 = null;
    int var3 = var0.getRangeAxisIndex(var2);
    org.jfree.chart.axis.AxisSpace var4 = null;
    var0.setFixedRangeAxisSpace(var4);
    boolean var6 = var0.isRangeCrosshairLockedOnData();
    int var7 = var0.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
//     int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var5 = var4.clone();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var4.getCategoryEnd(100, 1, var8, var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var16 = null;
//     var15.setBaseItemLabelFont(var16, true);
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(10, var21);
//     org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var24 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var24);
//     int var27 = var24.getColumnIndex((java.lang.Comparable)'#');
//     org.jfree.chart.axis.CategoryAxis3D var28 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var29 = var28.clone();
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var28.getCategoryEnd(100, 1, var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var39 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
//     java.awt.Font var40 = null;
//     var39.setBaseItemLabelFont(var40, true);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, (org.jfree.chart.axis.CategoryAxis)var28, var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setRangeAxisLocation(10, var45);
//     org.jfree.chart.axis.CategoryAxis3D var48 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.lang.Object var49 = var48.clone();
//     java.awt.geom.Rectangle2D var52 = null;
//     org.jfree.chart.util.RectangleEdge var53 = null;
//     double var54 = var48.getCategoryStart(1, 0, var52, var53);
//     java.lang.String var56 = var48.getCategoryLabelToolTip((java.lang.Comparable)0.25d);
//     var43.setDomainAxis(0, (org.jfree.chart.axis.CategoryAxis)var48);
//     org.jfree.chart.axis.AxisLocation var59 = null;
//     var43.setDomainAxisLocation(1, var59);
//     org.jfree.chart.axis.AxisLocation var62 = var43.getDomainAxisLocation(100);
//     org.jfree.chart.util.SortOrder var63 = var43.getColumnRenderingOrder();
//     var19.setRowRenderingOrder(var63);
//     
//     // Checks the contract:  equals-hashcode on var0 and var24
//     assertTrue("Contract failed: equals-hashcode on var0 and var24", var0.equals(var24) ? var0.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var0
//     assertTrue("Contract failed: equals-hashcode on var24 and var0", var24.equals(var0) ? var24.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var43
//     assertTrue("Contract failed: equals-hashcode on var19 and var43", var19.equals(var43) ? var19.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var19
//     assertTrue("Contract failed: equals-hashcode on var43 and var19", var43.equals(var19) ? var43.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(1.0d, (-1.0d), 1.0d, 8.0d);
    double var7 = var5.calculateRightOutset(8.0d);
    var0.setMargin(var5);
    double var10 = var5.calculateRightOutset(4.0d);
    double var12 = var5.calculateBottomInset(0.25d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    int var3 = var0.getColumnIndex((java.lang.Comparable)'#');
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D();
    java.lang.Object var5 = var4.clone();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var4.getCategoryEnd(100, 1, var8, var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.StackedBarRenderer3D var15 = new org.jfree.chart.renderer.category.StackedBarRenderer3D((-1.0d), 100.0d, true);
    java.awt.Font var16 = null;
    var15.setBaseItemLabelFont(var16, true);
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, (org.jfree.chart.axis.CategoryAxis)var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(10, var21);
    org.jfree.chart.axis.ValueAxis var23 = var19.getRangeAxis();
    org.jfree.chart.axis.CategoryAxis var25 = var19.getDomainAxisForDataset(100);
    org.jfree.chart.util.RectangleEdge var26 = var19.getRangeAxisEdge();
    var19.setDrawSharedDomainAxis(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit((-16777216), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     java.lang.Comparable[] var0 = null;
//     java.lang.Comparable[] var2 = new java.lang.Comparable[] { 0L};
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var0, var2, var4, var5);
//     java.lang.String[] var8 = org.jfree.data.time.SerialDate.getMonths(true);
//     double[] var9 = null;
//     double[][] var10 = new double[][] { var9};
//     org.jfree.data.category.CategoryDataset var11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var2, (java.lang.Comparable[])var8, var10);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.DefaultKeyedValues2D var0 = new org.jfree.data.DefaultKeyedValues2D();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getRowKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

}
