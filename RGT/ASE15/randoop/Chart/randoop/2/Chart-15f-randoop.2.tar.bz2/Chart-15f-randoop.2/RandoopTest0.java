
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { (short)100};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 10.0f, 0.0f, var4, 0.0d, (-1.0f), 0.0f);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelPadding(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInsets(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.plot.PiePlotState var12 = var1.initialise(var4, var5, var7, (java.lang.Integer)1, var11);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(10.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var3 = new org.jfree.chart.plot.ValueMarker(1.0d, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.text.NumberFormat var1 = null;
    java.text.NumberFormat var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("hi!", var1, (-1.0f), 100.0f, var4);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)'4');
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setVerticalAlignment(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     var1.setLabelFont(var8);
//     
//     // Checks the contract:  equals-hashcode on var1 and var5
//     assertTrue("Contract failed: equals-hashcode on var1 and var5", var1.equals(var5) ? var1.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var1
//     assertTrue("Contract failed: equals-hashcode on var5 and var1", var5.equals(var1) ? var5.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.awt.Font var5 = var2.getLabelFont();
//     java.awt.Color var9 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var10 = null;
//     java.awt.Rectangle var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     java.awt.geom.AffineTransform var13 = null;
//     java.awt.RenderingHints var14 = null;
//     java.awt.PaintContext var15 = var9.createContext(var10, var11, var12, var13, var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.awt.Stroke var20 = var17.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
//     var22.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     var22.setPadding(var26);
//     org.jfree.chart.block.LineBorder var28 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var9, var20, var26);
//     org.jfree.chart.text.TextLine var29 = new org.jfree.chart.text.TextLine("hi!", var5, (java.awt.Paint)var9);
//     
//     // Checks the contract:  equals-hashcode on var2 and var17
//     assertTrue("Contract failed: equals-hashcode on var2 and var17", var2.equals(var17) ? var2.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var2
//     assertTrue("Contract failed: equals-hashcode on var17 and var2", var17.equals(var2) ? var17.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setLabelLinkMargin((-1.0d));
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var1.drawBackground(var7, var8);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    org.jfree.chart.event.ChartChangeEventType var3 = null;
    var2.setType(var3);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Stroke var9 = var1.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var11 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var11);
    java.text.AttributedString var14 = null;
    var11.setAttributedLabel(10, var14);
    java.text.AttributedString var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setAttributedLabel((-1), var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var8 = null;
//     var3.draw(var5, 1.0f, 0.0f, var8, 10.0f, 0.0f, 100.0d);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseSectionOutlinePaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    org.jfree.chart.plot.PieLabelRecord var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(100);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     var16.setLabelGap((-1.0d));
//     java.lang.Object var19 = var16.clone();
//     java.awt.Shape var20 = var16.getLegendItemShape();
//     var0.setLeftArrow(var20);
//     
//     // Checks the contract:  equals-hashcode on var5 and var19
//     assertTrue("Contract failed: equals-hashcode on var5 and var19", var5.equals(var19) ? var5.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var5
//     assertTrue("Contract failed: equals-hashcode on var19 and var5", var19.equals(var5) ? var19.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 10.0d, false);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, Double.POSITIVE_INFINITY);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    org.jfree.chart.axis.CategoryLabelPositions var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setHeight(1.0d);
    double var5 = var1.getContentXOffset();
    java.awt.Graphics2D var6 = null;
    org.jfree.data.Range var7 = null;
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var7, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var10 = var1.arrange(var6, var9);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.text.TextAnchor var5 = null;
//     var1.draw(var2, (-1.0f), 10.0f, var5, 100.0f, 1.0f, 0.0d);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.data.Range var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var1, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    var1.setIgnoreZeroValues(true);
    var1.setOutlineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.Marker var20 = null;
//     boolean var21 = var19.removeDomainMarker(var20);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.LengthConstraintType var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(Double.POSITIVE_INFINITY, var1, var2, Double.POSITIVE_INFINITY, var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    org.jfree.chart.plot.DatasetRenderingOrder var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDatasetRenderingOrder(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
    org.jfree.chart.block.BlockContainer var1 = null;
    java.awt.Graphics2D var2 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(var3, 100.0d);
    org.jfree.chart.block.RectangleConstraint var6 = var5.toUnconstrainedWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var7 = var0.arrange(var1, var2, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    org.jfree.chart.plot.Marker var29 = null;
    org.jfree.chart.util.Layer var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.addDomainMarker(0, var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setUpperMargin(1.0d);
    java.text.NumberFormat var3 = null;
    var0.setNumberFormatOverride(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var4 = null;
    java.awt.Rectangle var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    java.awt.geom.AffineTransform var7 = null;
    java.awt.RenderingHints var8 = null;
    java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    var11.setLabelGap((-1.0d));
    java.awt.Stroke var14 = var11.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
    var16.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
    var16.setPadding(var20);
    org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
    java.awt.geom.Rectangle2D var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var26 = var20.createInsetRectangle(var23, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, Double.POSITIVE_INFINITY, Double.POSITIVE_INFINITY, 1, (java.lang.Comparable)"org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    var20.setLabelGap((-1.0d));
    java.awt.Font var23 = var20.getLabelFont();
    var7.setNoDataMessageFont(var23);
    org.jfree.chart.labels.PieSectionLabelGenerator var25 = var7.getLegendLabelToolTipGenerator();
    org.jfree.chart.util.Rotation var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setDirection(var26);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    org.jfree.chart.util.Layer var29 = null;
    java.util.Collection var30 = var19.getRangeMarkers(0, var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var32 = var19.getDomainAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var30 = var29.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setLabelGap((-1.0d));
//     java.lang.Object var36 = var33.clone();
//     java.awt.Paint var37 = var33.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var33.setURLGenerator(var38);
//     java.awt.Stroke var41 = var33.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var33.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var43);
//     boolean var45 = var31.equals((java.lang.Object)var33);
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var31, var46);
//     java.awt.Paint var48 = var47.getDomainZeroBaselinePaint();
//     java.awt.Stroke var49 = var47.getRangeZeroBaselineStroke();
//     var19.setRangeGridlineStroke(var49);
//     
//     // Checks the contract:  equals-hashcode on var5 and var33
//     assertTrue("Contract failed: equals-hashcode on var5 and var33", var5.equals(var33) ? var5.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var5
//     assertTrue("Contract failed: equals-hashcode on var33 and var5", var33.equals(var5) ? var33.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var36
//     assertTrue("Contract failed: equals-hashcode on var8 and var36", var8.equals(var36) ? var8.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var8
//     assertTrue("Contract failed: equals-hashcode on var36 and var8", var36.equals(var8) ? var36.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var43
//     assertTrue("Contract failed: equals-hashcode on var15 and var43", var15.equals(var43) ? var15.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var15
//     assertTrue("Contract failed: equals-hashcode on var43 and var15", var43.equals(var15) ? var43.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    float var2 = var1.getMaximumCategoryLabelWidthRatio();
    double var3 = var1.getUpperMargin();
    org.jfree.chart.axis.CategoryLabelPositions var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     java.awt.Paint var23 = null;
//     var22.setLabelShadowPaint(var23);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     var28.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var38 = null;
//     org.jfree.chart.plot.PiePlotState var39 = var22.initialise(var25, var26, var28, (java.lang.Integer)0, var38);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.awt.Font var44 = var41.getLabelFont();
//     var28.setNoDataMessageFont(var44);
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("", var44);
//     var1.setTickLabelFont(var44);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.axis.DateTickMarkPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickMarkPosition(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.awt.Font var1 = null;
    org.jfree.chart.block.LineBorder var2 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var3 = var2.getPaint();
    org.jfree.chart.util.RectangleEdge var4 = null;
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var7 = var6.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getTextAlignment();
    var10.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var14 = new org.jfree.chart.util.RectangleInsets();
    var10.setPadding(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("", var1, var3, var4, var7, var8, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     var12.setLabelGap((-1.0d));
//     java.lang.Object var15 = var12.clone();
//     var12.setShadowXOffset((-1.0d));
//     var12.setShadowXOffset(10.0d);
//     boolean var20 = var12.getSimpleLabels();
//     java.awt.Stroke var21 = var12.getLabelOutlineStroke();
//     var1.setBaseSectionOutlineStroke(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var12
//     assertTrue("Contract failed: equals-hashcode on var1 and var12", var1.equals(var12) ? var1.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var1
//     assertTrue("Contract failed: equals-hashcode on var12 and var1", var12.equals(var1) ? var12.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var15
//     assertTrue("Contract failed: equals-hashcode on var4 and var15", var4.equals(var15) ? var4.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var4
//     assertTrue("Contract failed: equals-hashcode on var15 and var4", var15.equals(var4) ? var15.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("");
//     var1.addFragment(var6);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.util.Size2D var9 = var6.calculateDimensions(var8);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var13 = var11.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    java.util.Date var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinimumDate(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainMarkers();
    org.jfree.chart.axis.AxisLocation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setRangeAxisLocation(0, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var34 = var33.getTextAlignment();
//     var33.setHeight(1.0d);
//     double var37 = var33.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var39 = var38.getLabelFont();
//     boolean var40 = var33.equals((java.lang.Object)var39);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     java.awt.Paint var43 = null;
//     var42.setLabelShadowPaint(var43);
//     java.awt.Graphics2D var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.PiePlot var48 = new org.jfree.chart.plot.PiePlot(var47);
//     var48.setLabelGap((-1.0d));
//     java.lang.Object var51 = var48.clone();
//     java.awt.Paint var52 = var48.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var53 = null;
//     var48.setURLGenerator(var53);
//     var48.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     org.jfree.chart.plot.PiePlotState var59 = var42.initialise(var45, var46, var48, (java.lang.Integer)0, var58);
//     java.awt.Paint var60 = var42.getLabelOutlinePaint();
//     var42.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot(var63);
//     java.awt.Paint var65 = null;
//     var64.setLabelShadowPaint(var65);
//     java.awt.Paint var67 = var64.getLabelOutlinePaint();
//     var42.setOutlinePaint(var67);
//     org.jfree.chart.text.TextBlock var69 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var39, var67);
//     var19.setDomainGridlinePaint(var67);
//     
//     // Checks the contract:  equals-hashcode on var8 and var51
//     assertTrue("Contract failed: equals-hashcode on var8 and var51", var8.equals(var51) ? var8.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var8
//     assertTrue("Contract failed: equals-hashcode on var51 and var8", var51.equals(var8) ? var51.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var1.valueToJava2D(10.0d, var3, var4);
    org.jfree.chart.axis.MarkerAxisBand var6 = var1.getMarkerBand();
    java.awt.Font var7 = var1.getLabelFont();
    java.awt.Color var11 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var12 = null;
    java.awt.Rectangle var13 = null;
    java.awt.geom.Rectangle2D var14 = null;
    java.awt.geom.AffineTransform var15 = null;
    java.awt.RenderingHints var16 = null;
    java.awt.PaintContext var17 = var11.createContext(var12, var13, var14, var15, var16);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    var19.setLabelGap((-1.0d));
    java.awt.Stroke var22 = var19.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var25 = var24.getTextAlignment();
    var24.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
    var24.setPadding(var28);
    org.jfree.chart.block.LineBorder var30 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var11, var22, var28);
    org.jfree.chart.util.RectangleEdge var31 = null;
    org.jfree.chart.title.TextTitle var33 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var34 = var33.getTextAlignment();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var37 = var36.getTextAlignment();
    var33.setHorizontalAlignment(var37);
    org.jfree.chart.util.VerticalAlignment var39 = null;
    org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var7, (java.awt.Paint)var11, var31, var37, var39, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var3 = var1.getTickLabelPaint((java.lang.Comparable)255);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     double var10 = var1.getCategorySeriesMiddle((java.lang.Comparable)"", (java.lang.Comparable)'#', var6, Double.POSITIVE_INFINITY, var8, var9);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     float var2 = var1.getMaximumCategoryLabelWidthRatio();
//     double var3 = var1.getUpperMargin();
//     org.jfree.data.category.CategoryDataset var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var11 = var10.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     var14.setLabelGap((-1.0d));
//     java.lang.Object var17 = var14.clone();
//     java.awt.Paint var18 = var14.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var19 = null;
//     var14.setURLGenerator(var19);
//     java.awt.Stroke var22 = var14.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var14.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
//     boolean var26 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var27);
//     org.jfree.chart.util.RectangleEdge var30 = var28.getRangeAxisEdge(100);
//     double var31 = var1.getCategorySeriesMiddle((java.lang.Comparable)100L, (java.lang.Comparable)(byte)(-1), var6, 0.14d, var8, var30);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.chart.plot.Plot var1 = null;
//     org.jfree.chart.JFreeChart var2 = new org.jfree.chart.JFreeChart("", var1);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.Size2D var3 = var1.calculateDimensions(var2);
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var1, 0.0f, 100.0f, 1.0d, 1.0f, 2.0f);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    java.awt.Graphics2D var1 = null;
    java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.0f, 1.0f, 1.0d, 100.0f, 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0E-8d, 1.0f, 2.0f);
// 
//   }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)' ');
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.mapDatasetToRangeAxis(4, 100);
    org.jfree.chart.axis.AxisLocation var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDomainAxisLocation(var24, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.geom.Rectangle2D var2 = null;
//     org.jfree.chart.util.RectangleEdge var3 = null;
//     double var4 = var0.valueToJava2D(10.0d, var2, var3);
//     org.jfree.chart.axis.MarkerAxisBand var5 = var0.getMarkerBand();
//     java.awt.Font var6 = var0.getLabelFont();
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var11 = var10.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     var14.setLabelGap((-1.0d));
//     java.lang.Object var17 = var14.clone();
//     java.awt.Paint var18 = var14.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var19 = null;
//     var14.setURLGenerator(var19);
//     java.awt.Stroke var22 = var14.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var14.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
//     boolean var26 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var27);
//     org.jfree.chart.util.RectangleEdge var30 = var28.getRangeAxisEdge(100);
//     double var31 = var0.valueToJava2D((-1.0d), var8, var30);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     java.awt.geom.Point2D var24 = null;
//     var20.zoomRangeAxes(0.05d, 10.0d, var23, var24);
//     var20.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var30 = null;
//     java.util.Collection var31 = var20.getRangeMarkers(0, var30);
//     boolean var32 = var20.isDomainZoomable();
//     java.awt.Paint var33 = var20.getNoDataMessagePaint();
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var36 = var35.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     var39.setLabelGap((-1.0d));
//     java.lang.Object var42 = var39.clone();
//     java.awt.Paint var43 = var39.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var44 = null;
//     var39.setURLGenerator(var44);
//     java.awt.Stroke var47 = var39.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var49 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var39.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var49);
//     boolean var51 = var37.equals((java.lang.Object)var39);
//     org.jfree.chart.renderer.xy.XYItemRenderer var52 = null;
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, (org.jfree.chart.axis.ValueAxis)var37, var52);
//     java.awt.Paint var54 = var53.getDomainZeroBaselinePaint();
//     java.awt.Stroke var55 = var53.getRangeZeroBaselineStroke();
//     java.awt.Stroke var56 = var53.getOutlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
//     var57.setTickMarkOutsideLength(1.0f);
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
//     java.awt.Paint var62 = null;
//     var61.setLabelShadowPaint(var62);
//     java.awt.Graphics2D var64 = null;
//     java.awt.geom.Rectangle2D var65 = null;
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.PiePlot var67 = new org.jfree.chart.plot.PiePlot(var66);
//     var67.setLabelGap((-1.0d));
//     java.lang.Object var70 = var67.clone();
//     java.awt.Paint var71 = var67.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var72 = null;
//     var67.setURLGenerator(var72);
//     var67.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var77 = null;
//     org.jfree.chart.plot.PiePlotState var78 = var61.initialise(var64, var65, var67, (java.lang.Integer)0, var77);
//     java.awt.Paint var79 = var61.getLabelOutlinePaint();
//     var57.setAxisLinePaint(var79);
//     org.jfree.data.general.PieDataset var81 = null;
//     org.jfree.chart.plot.PiePlot var82 = new org.jfree.chart.plot.PiePlot(var81);
//     var82.setLabelGap((-1.0d));
//     java.awt.Stroke var85 = var82.getLabelLinkStroke();
//     org.jfree.chart.plot.ValueMarker var87 = new org.jfree.chart.plot.ValueMarker((-1.0d), var33, var56, var79, var85, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var6 and var39
//     assertTrue("Contract failed: equals-hashcode on var6 and var39", var6.equals(var39) ? var6.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var6
//     assertTrue("Contract failed: equals-hashcode on var39 and var6", var39.equals(var6) ? var39.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var42
//     assertTrue("Contract failed: equals-hashcode on var9 and var42", var9.equals(var42) ? var9.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var70
//     assertTrue("Contract failed: equals-hashcode on var9 and var70", var9.equals(var70) ? var9.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var9
//     assertTrue("Contract failed: equals-hashcode on var42 and var9", var42.equals(var9) ? var42.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var70
//     assertTrue("Contract failed: equals-hashcode on var42 and var70", var42.equals(var70) ? var42.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var9
//     assertTrue("Contract failed: equals-hashcode on var70 and var9", var70.equals(var9) ? var70.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var42
//     assertTrue("Contract failed: equals-hashcode on var70 and var42", var70.equals(var42) ? var70.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var49
//     assertTrue("Contract failed: equals-hashcode on var16 and var49", var16.equals(var49) ? var16.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var16
//     assertTrue("Contract failed: equals-hashcode on var49 and var16", var49.equals(var16) ? var49.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleAnchor var4 = null;
//     java.awt.geom.Point2D var5 = org.jfree.chart.util.RectangleAnchor.coordinates(var3, var4);
//     var0.zoomRangeAxes(100.0d, var2, var5);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var21 = var19.getRangeAxisForDataset(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
//     java.awt.Stroke var22 = var19.getOutlineStroke();
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var25 = var24.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var41);
//     var42.clearDomainAxes();
//     var42.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var45 = null;
//     int var46 = var42.indexOf(var45);
//     org.jfree.chart.axis.AxisLocation var47 = var42.getDomainAxisLocation();
//     var19.setDomainAxisLocation(var47);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var38
//     assertTrue("Contract failed: equals-hashcode on var15 and var38", var15.equals(var38) ? var15.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var15
//     assertTrue("Contract failed: equals-hashcode on var38 and var15", var38.equals(var15) ? var38.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var19
//     assertTrue("Contract failed: equals-hashcode on var42 and var19", var42.equals(var19) ? var42.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var42 and var19.", var42.equals(var19) == var19.equals(var42));
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0d), var1, 10, (-1));
    java.lang.String var5 = var4.toString();
    org.jfree.chart.JFreeChart var6 = null;
    var4.setChart(var6);
    java.lang.Object var8 = var4.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1.0]"+ "'", var5.equals("org.jfree.chart.event.ChartProgressEvent[source=-1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1.0d)+ "'", var8.equals((-1.0d)));

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    var6.setLabelGap((-1.0d));
    java.lang.Object var9 = var6.clone();
    var6.setShadowXOffset((-1.0d));
    var6.setShadowXOffset(10.0d);
    boolean var14 = var6.getSimpleLabels();
    java.awt.Stroke var15 = var6.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var16, 0, 0);
    org.jfree.chart.event.ChartChangeListener var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.addChangeListener(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryStart(0, (-1), var4, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.axis.AxisState var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     java.util.List var11 = var1.refreshTicks(var7, var8, var9, var10);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.setUpperMargin(1.0d);
//     boolean var3 = var0.isTickMarksVisible();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     var5.setLabelLinkMargin((-1.0d));
//     java.awt.Paint var11 = var5.getBaseSectionPaint();
//     boolean var12 = var0.hasListener((java.util.EventListener)var5);
//     var0.setTickMarksVisible(false);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var17 = var16.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     var20.setLabelGap((-1.0d));
//     java.lang.Object var23 = var20.clone();
//     java.awt.Paint var24 = var20.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var25 = null;
//     var20.setURLGenerator(var25);
//     java.awt.Stroke var28 = var20.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var30 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var20.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var30);
//     boolean var32 = var18.equals((java.lang.Object)var20);
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var33);
//     java.awt.Paint var35 = var34.getDomainZeroBaselinePaint();
//     java.awt.Paint var36 = var34.getRangeCrosshairPaint();
//     var0.setLabelPaint(var36);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var22 = null;
//     int var23 = var19.indexOf(var22);
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     java.awt.Paint var30 = var26.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var26.setURLGenerator(var31);
//     java.awt.Stroke var34 = var26.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var26.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var36);
//     boolean var38 = var24.equals((java.lang.Object)var26);
//     var24.configure();
//     double var40 = var24.getLowerMargin();
//     boolean var41 = var24.getAutoRangeIncludesZero();
//     int var42 = var19.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var24);
//     
//     // Checks the contract:  equals-hashcode on var5 and var26
//     assertTrue("Contract failed: equals-hashcode on var5 and var26", var5.equals(var26) ? var5.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var5
//     assertTrue("Contract failed: equals-hashcode on var26 and var5", var26.equals(var5) ? var26.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var36
//     assertTrue("Contract failed: equals-hashcode on var15 and var36", var15.equals(var36) ? var15.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var15
//     assertTrue("Contract failed: equals-hashcode on var36 and var15", var36.equals(var15) ? var36.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
    var1.setPadding(var5);
    java.lang.Object var7 = var1.clone();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var10 = var9.getTextAlignment();
    var9.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
    var9.setPadding(var13);
    var1.setMargin(var13);
    double var17 = var13.trimHeight(0.0d);
    java.awt.geom.Rectangle2D var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var21 = var13.createOutsetRectangle(var18, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-2.0d));

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Stroke var9 = var1.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var1.setLegendLabelURLGenerator(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInteriorGap((-2.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setHeight(1.0d);
    double var5 = var1.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var6 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var7 = var6.getLabelFont();
    boolean var8 = var1.equals((java.lang.Object)var7);
    org.jfree.chart.util.RectangleInsets var9 = var1.getPadding();
    double var11 = var9.calculateRightOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0d);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var1);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Paint var3 = null;
//     var2.setLabelShadowPaint(var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setLabelGap((-1.0d));
//     java.lang.Object var11 = var8.clone();
//     java.awt.Paint var12 = var8.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var13 = null;
//     var8.setURLGenerator(var13);
//     var8.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.plot.PiePlotState var19 = var2.initialise(var5, var6, var8, (java.lang.Integer)0, var18);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     var21.setLabelGap((-1.0d));
//     java.awt.Font var24 = var21.getLabelFont();
//     var8.setNoDataMessageFont(var24);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
//     java.awt.Font var27 = var26.getFont();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var30 = var29.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setLabelGap((-1.0d));
//     java.lang.Object var36 = var33.clone();
//     java.awt.Paint var37 = var33.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var33.setURLGenerator(var38);
//     java.awt.Stroke var41 = var33.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var33.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var43);
//     boolean var45 = var31.equals((java.lang.Object)var33);
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var31, var46);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     java.awt.geom.Point2D var51 = null;
//     var47.zoomRangeAxes(0.05d, 10.0d, var50, var51);
//     var47.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var57 = null;
//     java.util.Collection var58 = var47.getRangeMarkers(0, var57);
//     boolean var59 = var47.isDomainZoomable();
//     java.awt.Paint var60 = var47.getNoDataMessagePaint();
//     var26.setBackgroundPaint(var60);
//     
//     // Checks the contract:  equals-hashcode on var11 and var36
//     assertTrue("Contract failed: equals-hashcode on var11 and var36", var11.equals(var36) ? var11.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var11
//     assertTrue("Contract failed: equals-hashcode on var36 and var11", var36.equals(var11) ? var36.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.RectangleAnchor.coordinates(var6, var7);
//     var0.zoomDomainAxes(0.0d, (-1.0d), var5, var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleAnchor var13 = null;
//     java.awt.geom.Point2D var14 = org.jfree.chart.util.RectangleAnchor.coordinates(var12, var13);
//     org.jfree.chart.plot.PlotState var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     var0.draw(var10, var11, var14, var15, var16);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     var19.setDomainGridlinesVisible(true);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     boolean var35 = var19.removeDomainMarker((org.jfree.chart.plot.Marker)var34);
// 
//   }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }


    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var3 = var2.getTextAlignment();
    var2.setHeight(1.0d);
    double var6 = var2.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var8 = var7.getLabelFont();
    boolean var9 = var2.equals((java.lang.Object)var8);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    java.awt.Paint var12 = null;
    var11.setLabelShadowPaint(var12);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    var17.setLabelGap((-1.0d));
    java.lang.Object var20 = var17.clone();
    java.awt.Paint var21 = var17.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var22 = null;
    var17.setURLGenerator(var22);
    var17.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
    java.awt.Paint var29 = var11.getLabelOutlinePaint();
    var11.setSimpleLabels(true);
    org.jfree.data.general.PieDataset var32 = null;
    org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
    java.awt.Paint var34 = null;
    var33.setLabelShadowPaint(var34);
    java.awt.Paint var36 = var33.getLabelOutlinePaint();
    var11.setOutlinePaint(var36);
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var8, var36);
    java.awt.Font var40 = null;
    org.jfree.chart.block.LineBorder var41 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var42 = var41.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var38.addLine("java.awt.Color[r=255,g=255,b=254]", var40, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=255,g=255,b=254]", var1, 0.05d, 0.0f, 1.0f);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var24 = var23.getTextAlignment();
//     var23.setHeight(1.0d);
//     double var27 = var23.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var29 = var28.getLabelFont();
//     boolean var30 = var23.equals((java.lang.Object)var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     java.awt.Paint var33 = null;
//     var32.setLabelShadowPaint(var33);
//     java.awt.Graphics2D var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     java.awt.Paint var42 = var38.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var43 = null;
//     var38.setURLGenerator(var43);
//     var38.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.plot.PiePlotState var49 = var32.initialise(var35, var36, var38, (java.lang.Integer)0, var48);
//     java.awt.Paint var50 = var32.getLabelOutlinePaint();
//     var32.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var53 = null;
//     org.jfree.chart.plot.PiePlot var54 = new org.jfree.chart.plot.PiePlot(var53);
//     java.awt.Paint var55 = null;
//     var54.setLabelShadowPaint(var55);
//     java.awt.Paint var57 = var54.getLabelOutlinePaint();
//     var32.setOutlinePaint(var57);
//     org.jfree.chart.text.TextBlock var59 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var29, var57);
//     var19.setRangeZeroBaselinePaint(var57);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     var32.setLabelGap((-1.0d));
//     java.lang.Object var35 = var32.clone();
//     var32.setShadowXOffset((-1.0d));
//     var32.setShadowXOffset(10.0d);
//     boolean var40 = var32.getSimpleLabels();
//     java.awt.Stroke var41 = var32.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var42 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var32);
//     var19.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var42);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("hi!");
    var1.setTickMarkInsideLength(10.0f);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     java.util.Date var2 = null;
//     java.util.Date var3 = null;
//     var1.setRange(var2, var3);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    var11.setName("hi!");
    java.lang.String var15 = var11.getVersion();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.block.ColumnArrangement var3 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.title.LegendTitle var5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var3, (org.jfree.chart.block.Arrangement)var4);
//     
//     // Checks the contract:  equals-hashcode on var3 and var4
//     assertTrue("Contract failed: equals-hashcode on var3 and var4", var3.equals(var4) ? var3.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var3
//     assertTrue("Contract failed: equals-hashcode on var4 and var3", var4.equals(var3) ? var4.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(0.08d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var3 = var1.getTickLabelPaint((java.lang.Comparable)255);
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.xy.XYDataset var7 = null;
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var9 = var8.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     var12.setLabelGap((-1.0d));
//     java.lang.Object var15 = var12.clone();
//     java.awt.Paint var16 = var12.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var17 = null;
//     var12.setURLGenerator(var17);
//     java.awt.Stroke var20 = var12.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var22 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var12.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var22);
//     boolean var24 = var10.equals((java.lang.Object)var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var25 = null;
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot(var7, (org.jfree.chart.axis.ValueAxis)var8, (org.jfree.chart.axis.ValueAxis)var10, var25);
//     org.jfree.chart.util.RectangleEdge var28 = var26.getRangeAxisEdge(100);
//     double var29 = var1.getCategoryEnd(255, 1, var6, var28);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var8 = var7.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.lang.Object var14 = var11.clone();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var16 = null;
//     var11.setURLGenerator(var16);
//     java.awt.Stroke var19 = var11.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
//     boolean var23 = var9.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     var25.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot();
//     var29.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     org.jfree.chart.util.RectangleAnchor var36 = null;
//     java.awt.geom.Point2D var37 = org.jfree.chart.util.RectangleAnchor.coordinates(var35, var36);
//     var29.zoomDomainAxes(0.0d, (-1.0d), var34, var37);
//     var25.zoomRangeAxes(100.0d, var28, var37);
//     var0.zoomDomainAxes(0.08d, (-1.0d), var5, var37);
//     
//     // Checks the contract:  equals-hashcode on var0 and var29
//     assertTrue("Contract failed: equals-hashcode on var0 and var29", var0.equals(var29) ? var0.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var0
//     assertTrue("Contract failed: equals-hashcode on var29 and var0", var29.equals(var0) ? var29.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.data.xy.XYDataset var2 = null;
    var0.setDataset(0, var2);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.setUpperMargin(1.0d);
//     boolean var3 = var0.isTickMarksVisible();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     var5.setLabelLinkMargin((-1.0d));
//     java.awt.Paint var11 = var5.getBaseSectionPaint();
//     boolean var12 = var0.hasListener((java.util.EventListener)var5);
//     var0.setTickMarksVisible(false);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     var16.setLabelGap((-1.0d));
//     java.lang.Object var19 = var16.clone();
//     java.awt.Shape var20 = var16.getLegendItemShape();
//     var0.setDownArrow(var20);
//     
//     // Checks the contract:  equals-hashcode on var8 and var19
//     assertTrue("Contract failed: equals-hashcode on var8 and var19", var8.equals(var19) ? var8.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var8
//     assertTrue("Contract failed: equals-hashcode on var19 and var8", var19.equals(var8) ? var19.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    int var28 = var19.getRangeAxisCount();
    org.jfree.chart.axis.ValueAxis var30 = var19.getDomainAxis(4);
    boolean var31 = var19.isDomainZeroBaselineVisible();
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDomainZeroBaselinePaint(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     java.awt.color.ColorSpace var23 = var3.getColorSpace();
//     java.awt.color.ColorSpace var24 = null;
//     float[] var28 = new float[] { 0.0f, (-1.0f), (-1.0f)};
//     float[] var29 = var3.getComponents(var24, var28);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var1);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    org.jfree.chart.event.ChartChangeListener var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.removeChangeListener(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.Title var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.addSubtitle(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var1.setTickMarkOutsideLength(1.0f);
//     java.lang.String var5 = var1.getCategoryLabelToolTip((java.lang.Comparable)(byte)1);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.AxisState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.util.RectangleEdge var9 = null;
//     java.util.List var10 = var1.refreshTicks(var6, var7, var8, var9);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    var1.handleClick(0, 10, var8);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var1.setLegendLabelURLGenerator(var10);
    var1.setShadowXOffset(0.0d);
    java.awt.Image var14 = var1.getBackgroundImage();
    java.awt.Paint var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelPaint(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var35 = var19.getRootPlot();
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var39 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var40 = var39.getPercentFormat();
//     var37.setNumberFormatOverride(var40);
//     var19.setRangeAxis(255, (org.jfree.chart.axis.ValueAxis)var37, true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var39
//     assertTrue("Contract failed: equals-hashcode on var15 and var39", var15.equals(var39) ? var15.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var15
//     assertTrue("Contract failed: equals-hashcode on var39 and var15", var39.equals(var15) ? var39.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     java.text.DateFormat var3 = var1.getDateFormatOverride();
//     java.util.Date var4 = null;
//     java.util.Date var5 = null;
//     var1.setRange(var4, var5);
// 
//   }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)1L, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryStart(0, (-1), var4, var5);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.general.WaferMapDataset var8 = null;
//     org.jfree.chart.plot.WaferMapPlot var9 = new org.jfree.chart.plot.WaferMapPlot(var8);
//     org.jfree.chart.event.RendererChangeEvent var10 = null;
//     var9.rendererChanged(var10);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var15 = var14.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     java.awt.Stroke var26 = var18.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var18.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var28);
//     boolean var30 = var16.equals((java.lang.Object)var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var31);
//     org.jfree.chart.util.RectangleEdge var34 = var32.getRangeAxisEdge(100);
//     boolean var35 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var34);
//     org.jfree.chart.axis.AxisSpace var36 = null;
//     org.jfree.chart.axis.AxisSpace var37 = var1.reserveSpace(var7, (org.jfree.chart.plot.Plot)var9, var12, var34, var36);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.draw(var3, var4);
    org.jfree.chart.util.HorizontalAlignment var6 = var1.getHorizontalAlignment();
    java.awt.Graphics2D var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(var8, 100.0d);
    java.lang.String var11 = var10.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var12 = var1.arrange(var7, var10);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var11.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)(byte)100);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Point2D var4 = null;
//     org.jfree.chart.plot.PlotState var5 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     var1.draw(var2, var3, var4, var5, var6);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     org.jfree.chart.event.ChartProgressListener var13 = null;
//     var11.removeProgressListener(var13);
//     org.jfree.chart.event.PlotChangeEvent var15 = null;
//     var11.plotChanged(var15);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var8 = var7.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.lang.Object var14 = var11.clone();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var16 = null;
//     var11.setURLGenerator(var16);
//     java.awt.Stroke var19 = var11.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
//     boolean var23 = var9.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     org.jfree.chart.util.RectangleEdge var27 = var25.getRangeAxisEdge(100);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.axis.AxisState var29 = var1.draw(var2, Double.POSITIVE_INFINITY, var4, var5, var27, var28);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var2 = var1.clone();
//     org.jfree.chart.event.MarkerChangeEvent var3 = null;
//     var1.notifyListeners(var3);
//     java.lang.Object var5 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var5
//     assertTrue("Contract failed: equals-hashcode on var2 and var5", var2.equals(var5) ? var2.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var2
//     assertTrue("Contract failed: equals-hashcode on var5 and var2", var5.equals(var2) ? var5.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.RectangleAnchor.coordinates(var6, var7);
//     var0.zoomDomainAxes(0.0d, (-1.0d), var5, var8);
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var11.configure();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var11);
//     double var14 = var0.getMaxRadius();
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     var6.setShadowXOffset((-1.0d));
//     var6.setShadowXOffset(10.0d);
//     boolean var14 = var6.getSimpleLabels();
//     java.awt.Stroke var15 = var6.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var16, 0, 0);
//     var16.fireChartChanged();
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var25 = var24.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var41);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var42.zoomRangeAxes(0.05d, 10.0d, var45, var46);
//     var42.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var52 = null;
//     java.util.Collection var53 = var42.getRangeMarkers(0, var52);
//     boolean var54 = var42.isDomainZoomable();
//     java.awt.Paint var55 = var42.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     org.jfree.chart.plot.PolarPlot var58 = new org.jfree.chart.plot.PolarPlot();
//     var58.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var63 = null;
//     java.awt.geom.Rectangle2D var64 = null;
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Point2D var66 = org.jfree.chart.util.RectangleAnchor.coordinates(var64, var65);
//     var58.zoomDomainAxes(0.0d, (-1.0d), var63, var66);
//     var42.zoomRangeAxes((-1.0d), var57, var66);
//     org.jfree.chart.ChartRenderingInfo var69 = null;
//     var16.draw(var21, var22, var66, var69);
// 
//   }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     java.awt.Paint var5 = var1.getNoDataMessagePaint();
//     java.awt.Paint var6 = var1.getNoDataMessagePaint();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setLabelGap((-1.0d));
//     java.lang.Object var11 = var8.clone();
//     java.awt.Paint var12 = var8.getNoDataMessagePaint();
//     java.awt.Paint var13 = var8.getNoDataMessagePaint();
//     var1.setLabelShadowPaint(var13);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     var7.setLabelGap((-1.0d));
//     java.lang.Object var10 = var7.clone();
//     java.awt.Paint var11 = var7.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var12 = null;
//     var7.setURLGenerator(var12);
//     var7.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
//     java.awt.Paint var19 = var1.getLabelOutlinePaint();
//     var1.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Paint var24 = null;
//     var23.setLabelShadowPaint(var24);
//     java.awt.Paint var26 = var23.getLabelOutlinePaint();
//     var1.setOutlinePaint(var26);
//     org.jfree.chart.event.PlotChangeEvent var28 = null;
//     var1.notifyListeners(var28);
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setLabelGap((-1.0d));
//     java.lang.Object var36 = var33.clone();
//     java.awt.Paint var37 = var33.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var33.setURLGenerator(var38);
//     java.awt.Stroke var41 = var33.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var33.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var43);
//     boolean var45 = var31.equals((java.lang.Object)var33);
//     java.awt.Color var49 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var49.createContext(var50, var51, var52, var53, var54);
//     java.awt.color.ColorSpace var56 = var49.getColorSpace();
//     var33.setNoDataMessagePaint((java.awt.Paint)var49);
//     org.jfree.chart.block.LineBorder var58 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var59 = var58.getPaint();
//     java.awt.Stroke var60 = var58.getStroke();
//     org.jfree.chart.plot.ValueMarker var61 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var49, var60);
//     var1.setLabelOutlineStroke(var60);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.chart.LegendItemCollection var19 = var1.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var21 = var19.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    java.awt.Stroke var9 = var1.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var1.setLegendLabelURLGenerator(var10);
    boolean var12 = var1.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var35 = var19.getRootPlot();
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var40 = new org.jfree.chart.text.TextFragment("");
//     var38.removeFragment(var40);
//     org.jfree.chart.text.TextFragment var42 = var38.getFirstTextFragment();
//     java.awt.Font var43 = var42.getFont();
//     org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var47 = var46.getTextAlignment();
//     var46.setHeight(1.0d);
//     double var50 = var46.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var51 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var52 = var51.getLabelFont();
//     boolean var53 = var46.equals((java.lang.Object)var52);
//     org.jfree.data.general.PieDataset var54 = null;
//     org.jfree.chart.plot.PiePlot var55 = new org.jfree.chart.plot.PiePlot(var54);
//     java.awt.Paint var56 = null;
//     var55.setLabelShadowPaint(var56);
//     java.awt.Graphics2D var58 = null;
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.data.general.PieDataset var60 = null;
//     org.jfree.chart.plot.PiePlot var61 = new org.jfree.chart.plot.PiePlot(var60);
//     var61.setLabelGap((-1.0d));
//     java.lang.Object var64 = var61.clone();
//     java.awt.Paint var65 = var61.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var66 = null;
//     var61.setURLGenerator(var66);
//     var61.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     org.jfree.chart.plot.PiePlotState var72 = var55.initialise(var58, var59, var61, (java.lang.Integer)0, var71);
//     java.awt.Paint var73 = var55.getLabelOutlinePaint();
//     var55.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var76 = null;
//     org.jfree.chart.plot.PiePlot var77 = new org.jfree.chart.plot.PiePlot(var76);
//     java.awt.Paint var78 = null;
//     var77.setLabelShadowPaint(var78);
//     java.awt.Paint var80 = var77.getLabelOutlinePaint();
//     var55.setOutlinePaint(var80);
//     org.jfree.chart.text.TextLine var82 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var52, var80);
//     org.jfree.chart.text.TextBlock var83 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var43, var80);
//     var19.setRangeCrosshairPaint(var80);
//     
//     // Checks the contract:  equals-hashcode on var8 and var64
//     assertTrue("Contract failed: equals-hashcode on var8 and var64", var8.equals(var64) ? var8.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var8
//     assertTrue("Contract failed: equals-hashcode on var64 and var8", var64.equals(var8) ? var64.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, 0.0d, (-1.0d));
    double var6 = var4.calculateTopInset(0.14d);
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var4.createInsetRectangle(var7, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.0d));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(100.0d, var2, var3);
    var0.setUpperMargin(10.0d);
    boolean var7 = var0.isInverted();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRange(1.0E-8d, (-1.95d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var1.java2DToValue(100.0d, var3, var4);
//     var1.setUpperMargin(10.0d);
//     boolean var8 = var1.isInverted();
//     org.jfree.chart.renderer.PolarItemRenderer var9 = null;
//     org.jfree.chart.plot.PolarPlot var10 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var9);
//     java.awt.Graphics2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.axis.NumberAxis3D var14 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var15 = var14.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     java.awt.Stroke var26 = var18.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var28 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var18.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var28);
//     boolean var30 = var16.equals((java.lang.Object)var18);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot(var13, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.axis.ValueAxis)var16, var31);
//     var32.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot();
//     var36.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleAnchor var43 = null;
//     java.awt.geom.Point2D var44 = org.jfree.chart.util.RectangleAnchor.coordinates(var42, var43);
//     var36.zoomDomainAxes(0.0d, (-1.0d), var41, var44);
//     var32.zoomRangeAxes(100.0d, var35, var44);
//     org.jfree.chart.plot.PlotState var47 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     var10.draw(var11, var12, var44, var47, var48);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     java.awt.Paint var21 = var19.getRangeCrosshairPaint();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var24 = var23.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var32 = null;
//     var27.setURLGenerator(var32);
//     java.awt.Stroke var35 = var27.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var27.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     boolean var39 = var25.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var40);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var41.zoomRangeAxes(0.05d, 10.0d, var44, var45);
//     var41.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var51 = null;
//     java.util.Collection var52 = var41.getRangeMarkers(0, var51);
//     boolean var53 = var41.isDomainZoomable();
//     var41.mapDatasetToRangeAxis(4, 0);
//     org.jfree.chart.axis.NumberAxis3D var57 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleEdge var60 = null;
//     double var61 = var57.valueToJava2D(10.0d, var59, var60);
//     org.jfree.chart.axis.ValueAxis[] var62 = new org.jfree.chart.axis.ValueAxis[] { var57};
//     var41.setRangeAxes(var62);
//     var19.setDomainAxes(var62);
//     
//     // Checks the contract:  equals-hashcode on var5 and var27
//     assertTrue("Contract failed: equals-hashcode on var5 and var27", var5.equals(var27) ? var5.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var5
//     assertTrue("Contract failed: equals-hashcode on var27 and var5", var27.equals(var5) ? var27.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var15
//     assertTrue("Contract failed: equals-hashcode on var37 and var15", var37.equals(var15) ? var37.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     org.jfree.chart.block.ColumnArrangement var0 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     var2.setShadowXOffset((-1.0d));
//     var2.setShadowXOffset(10.0d);
//     boolean var10 = var2.getSimpleLabels();
//     java.awt.Stroke var11 = var2.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.plot.Plot var13 = var12.getPlot();
//     java.awt.RenderingHints var14 = var12.getRenderingHints();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var19 = var18.getGreen();
//     var12.setBorderPaint((java.awt.Paint)var18);
//     org.jfree.chart.title.LegendTitle var21 = var12.getLegend();
//     org.jfree.chart.block.BlockContainer var22 = var21.getItemContainer();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.Range var24 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, 100.0d);
//     org.jfree.chart.util.Size2D var27 = var0.arrange(var22, var23, var26);
// 
//   }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var10 = var9.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 0.0f, 1.0f, var6, 0.0d, var10);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.data.xy.XYDataset var2 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var4 = var3.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    java.awt.Stroke var15 = var7.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var7.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var17);
    boolean var19 = var5.equals((java.lang.Object)var7);
    org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
    org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var20);
    org.jfree.data.Range var22 = var3.getDefaultAutoRange();
    var1.setRange(var22);
    var1.setRangeAboutValue(0.05d, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRange(0.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     org.jfree.chart.event.TitleChangeEvent var13 = null;
//     var11.titleChanged(var13);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var1.setTickMarkOutsideLength(1.0f);
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Paint var7 = null;
    var6.setLabelShadowPaint(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    var12.setLabelGap((-1.0d));
    java.lang.Object var15 = var12.clone();
    java.awt.Paint var16 = var12.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var17 = null;
    var12.setURLGenerator(var17);
    var12.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PiePlotState var23 = var6.initialise(var9, var10, var12, (java.lang.Integer)0, var22);
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    var25.setLabelGap((-1.0d));
    java.awt.Font var28 = var25.getLabelFont();
    var12.setNoDataMessageFont(var28);
    boolean var30 = var1.equals((java.lang.Object)var12);
    var1.setMaximumCategoryLabelLines(254);
    int var33 = var1.getMaximumCategoryLabelLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 254);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var3 = var2.getTextAlignment();
//     var2.setHeight(1.0d);
//     double var6 = var2.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var8 = var7.getLabelFont();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Paint var12 = null;
//     var11.setLabelShadowPaint(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     var17.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
//     java.awt.Paint var29 = var11.getLabelOutlinePaint();
//     var11.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Paint var34 = null;
//     var33.setLabelShadowPaint(var34);
//     java.awt.Paint var36 = var33.getLabelOutlinePaint();
//     var11.setOutlinePaint(var36);
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var8, var36);
//     org.jfree.chart.text.TextLine var42 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var44 = new org.jfree.chart.text.TextFragment("");
//     var42.removeFragment(var44);
//     org.jfree.chart.text.TextFragment var46 = var42.getFirstTextFragment();
//     java.awt.Font var47 = var46.getFont();
//     org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var51 = var50.getTextAlignment();
//     var50.setHeight(1.0d);
//     double var54 = var50.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var55 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var56 = var55.getLabelFont();
//     boolean var57 = var50.equals((java.lang.Object)var56);
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot var59 = new org.jfree.chart.plot.PiePlot(var58);
//     java.awt.Paint var60 = null;
//     var59.setLabelShadowPaint(var60);
//     java.awt.Graphics2D var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     var65.setLabelGap((-1.0d));
//     java.lang.Object var68 = var65.clone();
//     java.awt.Paint var69 = var65.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var70 = null;
//     var65.setURLGenerator(var70);
//     var65.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     org.jfree.chart.plot.PiePlotState var76 = var59.initialise(var62, var63, var65, (java.lang.Integer)0, var75);
//     java.awt.Paint var77 = var59.getLabelOutlinePaint();
//     var59.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var80 = null;
//     org.jfree.chart.plot.PiePlot var81 = new org.jfree.chart.plot.PiePlot(var80);
//     java.awt.Paint var82 = null;
//     var81.setLabelShadowPaint(var82);
//     java.awt.Paint var84 = var81.getLabelOutlinePaint();
//     var59.setOutlinePaint(var84);
//     org.jfree.chart.text.TextLine var86 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var56, var84);
//     org.jfree.chart.text.TextBlock var87 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var47, var84);
//     org.jfree.data.general.PieDataset var88 = null;
//     org.jfree.chart.plot.PiePlot var89 = new org.jfree.chart.plot.PiePlot(var88);
//     java.awt.Paint var90 = null;
//     var89.setLabelShadowPaint(var90);
//     java.awt.Paint var92 = var89.getLabelOutlinePaint();
//     var38.addLine("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var47, var92);
//     
//     // Checks the contract:  equals-hashcode on var11 and var59
//     assertTrue("Contract failed: equals-hashcode on var11 and var59", var11.equals(var59) ? var11.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var65
//     assertTrue("Contract failed: equals-hashcode on var17 and var65", var17.equals(var65) ? var17.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var81
//     assertTrue("Contract failed: equals-hashcode on var33 and var81", var33.equals(var81) ? var33.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var89
//     assertTrue("Contract failed: equals-hashcode on var33 and var89", var33.equals(var89) ? var33.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var11
//     assertTrue("Contract failed: equals-hashcode on var59 and var11", var59.equals(var11) ? var59.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var17
//     assertTrue("Contract failed: equals-hashcode on var65 and var17", var65.equals(var17) ? var65.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var33
//     assertTrue("Contract failed: equals-hashcode on var81 and var33", var81.equals(var33) ? var81.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var89
//     assertTrue("Contract failed: equals-hashcode on var81 and var89", var81.equals(var89) ? var81.hashCode() == var89.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var33
//     assertTrue("Contract failed: equals-hashcode on var89 and var33", var89.equals(var33) ? var89.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var89 and var81
//     assertTrue("Contract failed: equals-hashcode on var89 and var81", var89.equals(var81) ? var89.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var68
//     assertTrue("Contract failed: equals-hashcode on var20 and var68", var20.equals(var68) ? var20.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var20
//     assertTrue("Contract failed: equals-hashcode on var68 and var20", var68.equals(var20) ? var68.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var7 = var6.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var10.setURLGenerator(var15);
//     java.awt.Stroke var18 = var10.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     boolean var22 = var8.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(100);
//     boolean var27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var26);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.axis.AxisState var29 = var0.draw(var1, 0.14d, var3, var4, var26, var28);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     var1.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     var10.setShadowXOffset((-1.0d));
//     var10.setShadowXOffset(10.0d);
//     boolean var18 = var10.getSimpleLabels();
//     java.awt.Stroke var19 = var10.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var20, 0, 0);
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var20);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     var26.setShadowXOffset((-1.0d));
//     var26.setShadowXOffset(10.0d);
//     boolean var34 = var26.getSimpleLabels();
//     java.awt.Stroke var35 = var26.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.plot.Plot var37 = var36.getPlot();
//     var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var36);
//     
//     // Checks the contract:  equals-hashcode on var10 and var26
//     assertTrue("Contract failed: equals-hashcode on var10 and var26", var10.equals(var26) ? var10.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var10
//     assertTrue("Contract failed: equals-hashcode on var26 and var10", var26.equals(var10) ? var26.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var29
//     assertTrue("Contract failed: equals-hashcode on var13 and var29", var13.equals(var29) ? var13.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var13
//     assertTrue("Contract failed: equals-hashcode on var29 and var13", var29.equals(var13) ? var29.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var36
//     assertTrue("Contract failed: equals-hashcode on var20 and var36", var20.equals(var36) ? var20.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var20
//     assertTrue("Contract failed: equals-hashcode on var36 and var20", var36.equals(var20) ? var36.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     java.awt.color.ColorSpace var23 = var3.getColorSpace();
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
//     java.awt.Graphics2D var25 = null;
//     java.awt.geom.Rectangle2D var26 = null;
//     var24.draw(var25, var26);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    double var1 = var0.getAutoRangeMinimumSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-8d);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var1, 1.0f, 0.0f, 0.05d, 1.0f, 100.0f);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     var0.configure();
//     var0.setTickMarkInsideLength(2.0f);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var22 = var21.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     java.awt.Paint var29 = var25.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var30 = null;
//     var25.setURLGenerator(var30);
//     java.awt.Stroke var33 = var25.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var35);
//     boolean var37 = var23.equals((java.lang.Object)var25);
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var23, var38);
//     org.jfree.chart.util.RectangleEdge var41 = var39.getRangeAxisEdge(100);
//     boolean var42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var41);
//     java.lang.String var43 = var41.toString();
//     double var44 = var0.lengthToJava2D(0.0d, var19, var41);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    var11.setBackgroundImageAlignment(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var35 = var19.getRootPlot();
//     var19.setNoDataMessage("poly");
//     java.awt.Graphics2D var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     var19.drawBackground(var38, var39);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var4 = var3.getTextAlignment();
//     var3.setHeight(1.0d);
//     double var7 = var3.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var9 = var8.getLabelFont();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Paint var13 = null;
//     var12.setLabelShadowPaint(var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     var18.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.PiePlotState var29 = var12.initialise(var15, var16, var18, (java.lang.Integer)0, var28);
//     java.awt.Paint var30 = var12.getLabelOutlinePaint();
//     var12.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Paint var37 = var34.getLabelOutlinePaint();
//     var12.setOutlinePaint(var37);
//     org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var9, var37);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.awt.Font var44 = var41.getLabelFont();
//     org.jfree.chart.title.TextTitle var47 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var48 = var47.getTextAlignment();
//     var47.setHeight(1.0d);
//     double var51 = var47.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var52 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var53 = var52.getLabelFont();
//     boolean var54 = var47.equals((java.lang.Object)var53);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot var56 = new org.jfree.chart.plot.PiePlot(var55);
//     java.awt.Paint var57 = null;
//     var56.setLabelShadowPaint(var57);
//     java.awt.Graphics2D var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot(var61);
//     var62.setLabelGap((-1.0d));
//     java.lang.Object var65 = var62.clone();
//     java.awt.Paint var66 = var62.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var67 = null;
//     var62.setURLGenerator(var67);
//     var62.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     org.jfree.chart.plot.PiePlotState var73 = var56.initialise(var59, var60, var62, (java.lang.Integer)0, var72);
//     java.awt.Paint var74 = var56.getLabelOutlinePaint();
//     var56.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var77 = null;
//     org.jfree.chart.plot.PiePlot var78 = new org.jfree.chart.plot.PiePlot(var77);
//     java.awt.Paint var79 = null;
//     var78.setLabelShadowPaint(var79);
//     java.awt.Paint var81 = var78.getLabelOutlinePaint();
//     var56.setOutlinePaint(var81);
//     org.jfree.chart.text.TextLine var83 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var53, var81);
//     var41.setLabelShadowPaint(var81);
//     org.jfree.chart.text.TextLine var85 = new org.jfree.chart.text.TextLine("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var9, var81);
//     
//     // Checks the contract:  equals-hashcode on var12 and var56
//     assertTrue("Contract failed: equals-hashcode on var12 and var56", var12.equals(var56) ? var12.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var62
//     assertTrue("Contract failed: equals-hashcode on var18 and var62", var18.equals(var62) ? var18.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var78
//     assertTrue("Contract failed: equals-hashcode on var34 and var78", var34.equals(var78) ? var34.hashCode() == var78.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var12
//     assertTrue("Contract failed: equals-hashcode on var56 and var12", var56.equals(var12) ? var56.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var18
//     assertTrue("Contract failed: equals-hashcode on var62 and var18", var62.equals(var18) ? var62.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var78 and var34
//     assertTrue("Contract failed: equals-hashcode on var78 and var34", var78.equals(var34) ? var78.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var65
//     assertTrue("Contract failed: equals-hashcode on var21 and var65", var21.equals(var65) ? var21.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var21
//     assertTrue("Contract failed: equals-hashcode on var65 and var21", var65.equals(var21) ? var65.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.awt.Stroke var4 = var1.getLabelLinkStroke();
    org.jfree.chart.labels.PieSectionLabelGenerator var5 = null;
    var1.setLabelGenerator(var5);
    double var8 = var1.getExplodePercent((java.lang.Comparable)1.0d);
    java.lang.Comparable var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var10 = var1.getSectionOutlinePaint(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var2 = null;
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var4 = var3.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     var7.setLabelGap((-1.0d));
//     java.lang.Object var10 = var7.clone();
//     java.awt.Paint var11 = var7.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var12 = null;
//     var7.setURLGenerator(var12);
//     java.awt.Stroke var15 = var7.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var17 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var7.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var17);
//     boolean var19 = var5.equals((java.lang.Object)var7);
//     org.jfree.chart.renderer.xy.XYItemRenderer var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot(var2, (org.jfree.chart.axis.ValueAxis)var3, (org.jfree.chart.axis.ValueAxis)var5, var20);
//     org.jfree.data.Range var22 = var3.getDefaultAutoRange();
//     var1.setRange(var22);
//     org.jfree.chart.axis.DateTickUnit var24 = null;
//     java.util.Date var25 = var1.calculateLowestVisibleTickValue(var24);
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     var0.configure();
//     double var16 = var0.getAutoRangeMinimumSize();
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var23 = var22.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     java.awt.Paint var30 = var26.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var26.setURLGenerator(var31);
//     java.awt.Stroke var34 = var26.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var26.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var36);
//     boolean var38 = var24.equals((java.lang.Object)var26);
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var39);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Point2D var44 = null;
//     var40.zoomRangeAxes(0.05d, 10.0d, var43, var44);
//     var40.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var50 = null;
//     java.util.Collection var51 = var40.getRangeMarkers(0, var50);
//     boolean var52 = var40.isDomainZoomable();
//     java.awt.Paint var53 = var40.getNoDataMessagePaint();
//     var40.configureDomainAxes();
//     var40.setBackgroundAlpha(100.0f);
//     var40.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.RectangleEdge var60 = var40.getRangeAxisEdge(0);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.axis.AxisState var62 = var0.draw(var17, (-2.0d), var19, var20, var60, var61);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("poly", "java.awt.Color[r=255,g=255,b=254]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var3, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "", "hi!");
    var7.setLicenceName("poly");

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     java.awt.Paint var7 = var1.getBaseSectionOutlinePaint();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var7};
//     org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var11 = var10.getPaint();
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     org.jfree.chart.block.LineBorder var13 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var14 = var13.getPaint();
//     java.awt.Stroke var15 = var13.getStroke();
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     var18.setShadowXOffset((-1.0d));
//     var18.setShadowXOffset(10.0d);
//     boolean var26 = var18.getSimpleLabels();
//     java.awt.Stroke var27 = var18.getLabelOutlineStroke();
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var27};
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     var30.setLabelGap((-1.0d));
//     java.lang.Object var33 = var30.clone();
//     java.awt.Shape var34 = var30.getLegendItemShape();
//     java.awt.Shape[] var35 = new java.awt.Shape[] { var34};
//     org.jfree.chart.plot.DefaultDrawingSupplier var36 = new org.jfree.chart.plot.DefaultDrawingSupplier(var8, var12, var16, var28, var35);
//     
//     // Checks the contract:  equals-hashcode on var4 and var21
//     assertTrue("Contract failed: equals-hashcode on var4 and var21", var4.equals(var21) ? var4.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var33
//     assertTrue("Contract failed: equals-hashcode on var4 and var33", var4.equals(var33) ? var4.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var4
//     assertTrue("Contract failed: equals-hashcode on var21 and var4", var21.equals(var4) ? var21.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var33
//     assertTrue("Contract failed: equals-hashcode on var21 and var33", var21.equals(var33) ? var21.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var4
//     assertTrue("Contract failed: equals-hashcode on var33 and var4", var33.equals(var4) ? var33.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var21
//     assertTrue("Contract failed: equals-hashcode on var33 and var21", var33.equals(var21) ? var33.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     boolean var31 = var19.isDomainZoomable();
//     var19.mapDatasetToRangeAxis(4, 0);
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var35.valueToJava2D(10.0d, var37, var38);
//     org.jfree.chart.axis.ValueAxis[] var40 = new org.jfree.chart.axis.ValueAxis[] { var35};
//     var19.setRangeAxes(var40);
//     java.util.List var42 = var19.getAnnotations();
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
//     java.awt.Paint var45 = null;
//     var44.setLabelShadowPaint(var45);
//     java.awt.Graphics2D var47 = null;
//     java.awt.geom.Rectangle2D var48 = null;
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.PiePlot var50 = new org.jfree.chart.plot.PiePlot(var49);
//     var50.setLabelGap((-1.0d));
//     java.lang.Object var53 = var50.clone();
//     java.awt.Paint var54 = var50.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var55 = null;
//     var50.setURLGenerator(var55);
//     var50.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.plot.PiePlotState var61 = var44.initialise(var47, var48, var50, (java.lang.Integer)0, var60);
//     org.jfree.chart.LegendItemCollection var62 = var44.getLegendItems();
//     int var63 = var62.getItemCount();
//     java.util.Iterator var64 = var62.iterator();
//     var19.setFixedLegendItems(var62);
//     
//     // Checks the contract:  equals-hashcode on var8 and var53
//     assertTrue("Contract failed: equals-hashcode on var8 and var53", var8.equals(var53) ? var8.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var8
//     assertTrue("Contract failed: equals-hashcode on var53 and var8", var53.equals(var8) ? var53.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var1.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var4 = var1.getLabelFont();
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var10 = var9.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     java.awt.Stroke var21 = var13.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var13.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     boolean var25 = var11.equals((java.lang.Object)var13);
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var26);
//     org.jfree.chart.util.RectangleEdge var29 = var27.getRangeAxisEdge(100);
//     double var30 = var1.getCategoryStart(100, 0, var7, var29);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     var19.setDomainCrosshairVisible(false);
//     org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.util.RectangleEdge var27 = null;
//     double var28 = var24.java2DToValue(100.0d, var26, var27);
//     var24.setUpperMargin(10.0d);
//     boolean var31 = var24.isInverted();
//     var19.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var24, false);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     var19.handleClick(255, 255, var36);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
    java.awt.Stroke var22 = var19.getOutlineStroke();
    org.jfree.chart.axis.AxisSpace var23 = null;
    var19.setFixedDomainAxisSpace(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    var3.setLabelGap((-1.0d));
    java.lang.Object var6 = var3.clone();
    java.awt.Paint var7 = var3.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var3.setURLGenerator(var8);
    java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
    boolean var15 = var1.equals((java.lang.Object)var3);
    java.awt.Color var19 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var20 = null;
    java.awt.Rectangle var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    java.awt.geom.AffineTransform var23 = null;
    java.awt.RenderingHints var24 = null;
    java.awt.PaintContext var25 = var19.createContext(var20, var21, var22, var23, var24);
    java.awt.color.ColorSpace var26 = var19.getColorSpace();
    var3.setNoDataMessagePaint((java.awt.Paint)var19);
    org.jfree.chart.block.LineBorder var28 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var29 = var28.getPaint();
    java.awt.Stroke var30 = var28.getStroke();
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var19, var30);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setAlpha(100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     var1.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var19);
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var25 = var24.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var41);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Point2D var46 = null;
//     var42.zoomRangeAxes(0.05d, 10.0d, var45, var46);
//     var42.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var52 = null;
//     java.util.Collection var53 = var42.getRangeMarkers(0, var52);
//     boolean var54 = var42.isDomainZoomable();
//     java.awt.Paint var55 = var42.getNoDataMessagePaint();
//     var42.configureDomainAxes();
//     var42.setBackgroundAlpha(100.0f);
//     var42.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.RectangleEdge var62 = var42.getRangeAxisEdge(0);
//     double var63 = var1.valueToJava2D(0.14d, var22, var62);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     var23.setLabelGap((-1.0d));
//     java.lang.Object var26 = var23.clone();
//     var23.setShadowXOffset((-1.0d));
//     var23.setShadowXOffset(10.0d);
//     boolean var31 = var23.getSimpleLabels();
//     java.awt.Stroke var32 = var23.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     org.jfree.chart.plot.Plot var34 = var33.getPlot();
//     java.awt.RenderingHints var35 = var33.getRenderingHints();
//     java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var40 = var39.getGreen();
//     var33.setBorderPaint((java.awt.Paint)var39);
//     org.jfree.chart.title.LegendTitle var42 = var33.getLegend();
//     org.jfree.chart.util.RectangleAnchor var43 = var42.getLegendItemGraphicAnchor();
//     var20.setLegendItemGraphicAnchor(var43);
//     
//     // Checks the contract:  equals-hashcode on var1 and var23
//     assertTrue("Contract failed: equals-hashcode on var1 and var23", var1.equals(var23) ? var1.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var1
//     assertTrue("Contract failed: equals-hashcode on var23 and var1", var23.equals(var1) ? var23.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var26
//     assertTrue("Contract failed: equals-hashcode on var4 and var26", var4.equals(var26) ? var4.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var4
//     assertTrue("Contract failed: equals-hashcode on var26 and var4", var26.equals(var4) ? var26.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var33
//     assertTrue("Contract failed: equals-hashcode on var11 and var33", var11.equals(var33) ? var11.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var11
//     assertTrue("Contract failed: equals-hashcode on var33 and var11", var33.equals(var11) ? var33.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var34
//     assertTrue("Contract failed: equals-hashcode on var12 and var34", var12.equals(var34) ? var12.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var12
//     assertTrue("Contract failed: equals-hashcode on var34 and var12", var34.equals(var12) ? var34.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("HorizontalAlignment.CENTER", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    var6.setLabelGap((-1.0d));
    java.lang.Object var9 = var6.clone();
    var6.setShadowXOffset((-1.0d));
    var6.setShadowXOffset(10.0d);
    boolean var14 = var6.getSimpleLabels();
    java.awt.Stroke var15 = var6.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
    org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var16, 0, 0);
    org.jfree.chart.ChartRenderingInfo var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var24 = var16.createBufferedImage(0, 255, 255, var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var7 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var1, 0.5f, (-1.0f), var6);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
//     int var22 = var19.getDomainAxisCount();
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var25 = var24.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var41);
//     java.awt.Paint var43 = var42.getDomainZeroBaselinePaint();
//     java.awt.Stroke var44 = var42.getRangeZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var46 = var42.getRangeAxisLocation(1);
//     var19.setDomainAxisLocation(var46, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var28
//     assertTrue("Contract failed: equals-hashcode on var5 and var28", var5.equals(var28) ? var5.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var5
//     assertTrue("Contract failed: equals-hashcode on var28 and var5", var28.equals(var5) ? var28.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var31
//     assertTrue("Contract failed: equals-hashcode on var8 and var31", var8.equals(var31) ? var8.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var8
//     assertTrue("Contract failed: equals-hashcode on var31 and var8", var31.equals(var8) ? var31.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var38
//     assertTrue("Contract failed: equals-hashcode on var15 and var38", var15.equals(var38) ? var15.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var15
//     assertTrue("Contract failed: equals-hashcode on var38 and var15", var38.equals(var15) ? var38.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.awt.Color var1 = java.awt.Color.getColor("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var3 = null;
//     org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
//     var4.setLabelGap((-1.0d));
//     java.lang.Object var7 = var4.clone();
//     java.awt.Paint var8 = var4.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var9 = null;
//     var4.setURLGenerator(var9);
//     java.awt.Stroke var12 = var4.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var14 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var4.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var14);
//     boolean var16 = var2.equals((java.lang.Object)var4);
//     var2.configure();
//     var2.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var20 = null;
//     org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, var20);
//     org.jfree.data.xy.XYDataset var22 = null;
//     var21.setDataset(var22);
//     org.jfree.chart.plot.PlotOrientation var24 = var21.getOrientation();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var27 = var26.getTextAlignment();
//     var26.setHeight(1.0d);
//     double var30 = var26.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var32 = var31.getLabelFont();
//     boolean var33 = var26.equals((java.lang.Object)var32);
//     var21.setAngleLabelFont(var32);
//     java.awt.Paint var35 = null;
//     java.awt.Graphics2D var37 = null;
//     org.jfree.chart.text.G2TextMeasurer var38 = new org.jfree.chart.text.G2TextMeasurer(var37);
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var32, var35, (-1.0f), (org.jfree.chart.text.TextMeasurer)var38);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 0};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { "java.awt.Color[r=255,g=255,b=254]"};
//     double[][] var4 = null;
//     org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var4);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var2 = var1.getURLText();
    java.awt.Graphics2D var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(var4, 100.0d);
    double var7 = var6.getWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var1.arrange(var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     boolean var31 = var19.isDomainZoomable();
//     java.awt.Paint var32 = var19.getNoDataMessagePaint();
//     var19.configureDomainAxes();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     var19.drawBackground(var34, var35);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartChangeEventType var24 = null;
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var23, var24);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     var22.draw(var26, var27);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     var2.setShadowXOffset((-1.0d));
//     var2.setShadowXOffset(10.0d);
//     boolean var10 = var2.getSimpleLabels();
//     java.awt.Stroke var11 = var2.getLabelOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var14 = var13.getPercentFormat();
//     var2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", (org.jfree.chart.plot.Plot)var2);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var19 = var18.getTextAlignment();
//     var18.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     var18.setID("poly");
//     var16.addSubtitle((org.jfree.chart.title.Title)var18);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     var26.setShadowXOffset((-1.0d));
//     var26.setShadowXOffset(10.0d);
//     boolean var34 = var26.getSimpleLabels();
//     java.awt.Stroke var35 = var26.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var26);
//     var18.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var36);
//     
//     // Checks the contract:  equals-hashcode on var5 and var29
//     assertTrue("Contract failed: equals-hashcode on var5 and var29", var5.equals(var29) ? var5.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var5
//     assertTrue("Contract failed: equals-hashcode on var29 and var5", var29.equals(var5) ? var29.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var5 = var4.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setLabelGap((-1.0d));
    java.lang.Object var11 = var8.clone();
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var8.setURLGenerator(var13);
    java.awt.Stroke var16 = var8.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var18);
    boolean var20 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var21);
    org.jfree.data.Range var23 = var4.getDefaultAutoRange();
    var2.setRange(var23);
    org.jfree.data.Range var25 = null;
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 100.0d);
    org.jfree.chart.block.RectangleConstraint var28 = var27.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var29 = var28.getHeightConstraintType();
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var31, 1.0E-8d);
    double var36 = var35.getLength();
    org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var35, (-1.95d));
    double var39 = var38.getUpperBound();
    org.jfree.data.Range var40 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 100.0d);
    double var43 = var42.getWidth();
    org.jfree.chart.block.LengthConstraintType var44 = var42.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(0.0d, var23, var29, 10.0d, var38, var44);
    double var46 = var45.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 10.0d);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "java.awt.Color[r=255,g=255,b=254]", var3, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "java.awt.Color[r=255,g=255,b=254]", "");
    java.awt.Image var8 = null;
    var7.setLogo(var8);
    java.util.List var10 = var7.getContributors();
    org.jfree.chart.ui.Library[] var11 = var7.getLibraries();
    java.util.List var12 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     var0.configure();
//     double var16 = var0.getAutoRangeMinimumSize();
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var23 = var22.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     java.awt.Paint var30 = var26.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var26.setURLGenerator(var31);
//     java.awt.Stroke var34 = var26.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var26.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var36);
//     boolean var38 = var24.equals((java.lang.Object)var26);
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var39);
//     org.jfree.chart.util.RectangleEdge var42 = var40.getRangeAxisEdge(100);
//     boolean var43 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var42);
//     java.lang.String var44 = var42.toString();
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     org.jfree.chart.axis.AxisState var46 = var0.draw(var17, 0.14d, var19, var20, var42, var45);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets((-1.0d), 10.0d, 0.0d, (-1.0d));
//     java.awt.geom.Rectangle2D var5 = null;
//     var4.trim(var5);
// 
//   }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     var2.setShadowXOffset((-1.0d));
//     var2.setShadowXOffset(10.0d);
//     boolean var10 = var2.getSimpleLabels();
//     java.awt.Stroke var11 = var2.getLabelOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var14 = var13.getPercentFormat();
//     var2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", (org.jfree.chart.plot.Plot)var2);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot();
//     var19.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleAnchor var26 = null;
//     java.awt.geom.Point2D var27 = org.jfree.chart.util.RectangleAnchor.coordinates(var25, var26);
//     var19.zoomDomainAxes(0.0d, (-1.0d), var24, var27);
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     var16.draw(var17, var18, var27, var29);
// 
//   }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setTickMarkOutsideLength(1.0f);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.PiePlot var4 = new org.jfree.chart.plot.PiePlot(var3);
    java.awt.Paint var5 = null;
    var4.setLabelShadowPaint(var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.data.general.PieDataset var9 = null;
    org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
    var10.setLabelGap((-1.0d));
    java.lang.Object var13 = var10.clone();
    java.awt.Paint var14 = var10.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var15 = null;
    var10.setURLGenerator(var15);
    var10.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    org.jfree.chart.plot.PiePlotState var21 = var4.initialise(var7, var8, var10, (java.lang.Integer)0, var20);
    java.awt.Paint var22 = var4.getLabelOutlinePaint();
    var0.setAxisLinePaint(var22);
    org.jfree.data.RangeType var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeType(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     java.awt.Paint var35 = var19.getQuadrantPaint(1);
//     var19.clearRangeMarkers();
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var40 = var39.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     var43.setLabelGap((-1.0d));
//     java.lang.Object var46 = var43.clone();
//     java.awt.Paint var47 = var43.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var48 = null;
//     var43.setURLGenerator(var48);
//     java.awt.Stroke var51 = var43.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var53 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var43.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var53);
//     boolean var55 = var41.equals((java.lang.Object)var43);
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var56);
//     var57.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     org.jfree.chart.plot.PolarPlot var61 = new org.jfree.chart.plot.PolarPlot();
//     var61.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     java.awt.geom.Rectangle2D var67 = null;
//     org.jfree.chart.util.RectangleAnchor var68 = null;
//     java.awt.geom.Point2D var69 = org.jfree.chart.util.RectangleAnchor.coordinates(var67, var68);
//     var61.zoomDomainAxes(0.0d, (-1.0d), var66, var69);
//     var57.zoomRangeAxes(100.0d, var60, var69);
//     float var72 = var57.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var73 = var57.getRootPlot();
//     var57.setNoDataMessage("poly");
//     org.jfree.chart.axis.AxisLocation var77 = var57.getRangeAxisLocation(254);
//     var19.setRangeAxisLocation(255, var77, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var43
//     assertTrue("Contract failed: equals-hashcode on var5 and var43", var5.equals(var43) ? var5.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var5
//     assertTrue("Contract failed: equals-hashcode on var43 and var5", var43.equals(var5) ? var43.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var46
//     assertTrue("Contract failed: equals-hashcode on var8 and var46", var8.equals(var46) ? var8.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var8
//     assertTrue("Contract failed: equals-hashcode on var46 and var8", var46.equals(var8) ? var46.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var53
//     assertTrue("Contract failed: equals-hashcode on var15 and var53", var15.equals(var53) ? var15.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var15
//     assertTrue("Contract failed: equals-hashcode on var53 and var15", var53.equals(var15) ? var53.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var61
//     assertTrue("Contract failed: equals-hashcode on var23 and var61", var23.equals(var61) ? var23.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var23
//     assertTrue("Contract failed: equals-hashcode on var61 and var23", var61.equals(var23) ? var61.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     org.jfree.chart.axis.CategoryAnchor var2 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var8 = var7.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.lang.Object var14 = var11.clone();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var16 = null;
//     var11.setURLGenerator(var16);
//     java.awt.Stroke var19 = var11.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
//     boolean var23 = var9.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Point2D var29 = null;
//     var25.zoomRangeAxes(0.05d, 10.0d, var28, var29);
//     var25.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var35 = null;
//     java.util.Collection var36 = var25.getRangeMarkers(0, var35);
//     boolean var37 = var25.isDomainZoomable();
//     java.awt.Paint var38 = var25.getNoDataMessagePaint();
//     var25.configureDomainAxes();
//     var25.setBackgroundAlpha(100.0f);
//     var25.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.RectangleEdge var45 = var25.getRangeAxisEdge(0);
//     double var46 = var1.getCategoryJava2DCoordinate(var2, 255, 0, var5, var45);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var22 = var21.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     java.awt.Paint var29 = var25.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var30 = null;
//     var25.setURLGenerator(var30);
//     java.awt.Stroke var33 = var25.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var35);
//     boolean var37 = var23.equals((java.lang.Object)var25);
//     org.jfree.chart.renderer.xy.XYItemRenderer var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var20, (org.jfree.chart.axis.ValueAxis)var21, (org.jfree.chart.axis.ValueAxis)var23, var38);
//     var39.clearDomainAxes();
//     var39.clearDomainMarkers();
//     boolean var42 = var39.isDomainGridlinesVisible();
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var45 = var44.getTextAlignment();
//     var44.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var48 = new org.jfree.chart.util.RectangleInsets();
//     var44.setPadding(var48);
//     double var51 = var48.trimHeight(0.05d);
//     var39.setInsets(var48, true);
//     var11.setPadding(var48);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.plot.PiePlotState var1 = new org.jfree.chart.plot.PiePlotState(var0);

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    var19.setOutlineVisible(true);
    java.lang.String var30 = var19.getNoDataMessage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Shape var5 = var1.getLegendItemShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.lang.String var7 = var6.getShapeType();
    var6.setURLText("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "poly"+ "'", var7.equals("poly"));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.chart.event.RendererChangeEvent var2 = null;
    var1.rendererChanged(var2);
    org.jfree.chart.event.MarkerChangeEvent var4 = null;
    var1.markerChanged(var4);

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setLabelLinkMargin((-1.0d));
    org.jfree.chart.plot.PieLabelDistributor var8 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    java.lang.String var9 = var8.toString();
    var1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor)var8);
    var8.distributeLabels(1.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));

  }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.plot.PlotRenderingInfo var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
//     var3.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleAnchor var10 = null;
//     java.awt.geom.Point2D var11 = org.jfree.chart.util.RectangleAnchor.coordinates(var9, var10);
//     var3.zoomDomainAxes(0.0d, (-1.0d), var8, var11);
//     var0.zoomRangeAxes(1.0d, var2, var11);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.data.category.CategoryDataset var3 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var8 = var7.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.lang.Object var14 = var11.clone();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var16 = null;
//     var11.setURLGenerator(var16);
//     java.awt.Stroke var19 = var11.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
//     boolean var23 = var9.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     org.jfree.chart.util.RectangleEdge var27 = var25.getRangeAxisEdge(100);
//     boolean var28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var27);
//     java.lang.String var29 = var27.toString();
//     java.awt.Image var33 = null;
//     org.jfree.chart.ui.ProjectInfo var37 = new org.jfree.chart.ui.ProjectInfo("", "org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "java.awt.Color[r=255,g=255,b=254]", var33, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "java.awt.Color[r=255,g=255,b=254]", "");
//     java.awt.Image var38 = null;
//     var37.setLogo(var38);
//     java.util.List var40 = var37.getContributors();
//     org.jfree.chart.ui.Library[] var41 = var37.getLibraries();
//     boolean var42 = var27.equals((java.lang.Object)var41);
//     double var43 = var0.getCategorySeriesMiddle((java.lang.Comparable)"Size2D[width=0.0, height=0.0]", (java.lang.Comparable)(byte)(-1), var3, (-1.0d), var5, var27);
// 
//   }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var4 = new org.jfree.chart.text.TextFragment("");
    var2.removeFragment(var4);
    org.jfree.chart.text.TextFragment var6 = var2.getFirstTextFragment();
    java.awt.Font var7 = var6.getFont();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getTextAlignment();
    var10.setHeight(1.0d);
    double var14 = var10.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var16 = var15.getLabelFont();
    boolean var17 = var10.equals((java.lang.Object)var16);
    org.jfree.data.general.PieDataset var18 = null;
    org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
    java.awt.Paint var20 = null;
    var19.setLabelShadowPaint(var20);
    java.awt.Graphics2D var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    var25.setLabelGap((-1.0d));
    java.lang.Object var28 = var25.clone();
    java.awt.Paint var29 = var25.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var30 = null;
    var25.setURLGenerator(var30);
    var25.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    org.jfree.chart.plot.PiePlotState var36 = var19.initialise(var22, var23, var25, (java.lang.Integer)0, var35);
    java.awt.Paint var37 = var19.getLabelOutlinePaint();
    var19.setSimpleLabels(true);
    org.jfree.data.general.PieDataset var40 = null;
    org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
    java.awt.Paint var42 = null;
    var41.setLabelShadowPaint(var42);
    java.awt.Paint var44 = var41.getLabelOutlinePaint();
    var19.setOutlinePaint(var44);
    org.jfree.chart.text.TextLine var46 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var16, var44);
    org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var7, var44);
    org.jfree.chart.text.TextLine var48 = var47.getLastLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)true, 10.0d, 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     var1.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     var10.setShadowXOffset((-1.0d));
//     var10.setShadowXOffset(10.0d);
//     boolean var18 = var10.getSimpleLabels();
//     java.awt.Stroke var19 = var10.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var20, 0, 0);
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var20);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var26.setExpandToFitSpace(true);
//     var20.setTitle(var26);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     java.awt.Paint var32 = null;
//     var31.setLabelShadowPaint(var32);
//     java.awt.Paint var34 = var31.getLabelOutlinePaint();
//     var26.setBackgroundPaint(var34);
//     org.jfree.data.xy.XYDataset var37 = null;
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var39 = var38.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     var42.setLabelGap((-1.0d));
//     java.lang.Object var45 = var42.clone();
//     java.awt.Paint var46 = var42.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var42.setURLGenerator(var47);
//     java.awt.Stroke var50 = var42.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var52 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var42.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var52);
//     boolean var54 = var40.equals((java.lang.Object)var42);
//     org.jfree.chart.renderer.xy.XYItemRenderer var55 = null;
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot(var37, (org.jfree.chart.axis.ValueAxis)var38, (org.jfree.chart.axis.ValueAxis)var40, var55);
//     var56.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var59 = null;
//     var56.setRangeAxisLocation(4, var59, false);
//     org.jfree.chart.JFreeChart var62 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var56);
//     var26.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var62);
//     
//     // Checks the contract:  equals-hashcode on var13 and var45
//     assertTrue("Contract failed: equals-hashcode on var13 and var45", var13.equals(var45) ? var13.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var13
//     assertTrue("Contract failed: equals-hashcode on var45 and var13", var45.equals(var13) ? var45.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var7 = var6.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var10.setURLGenerator(var15);
//     java.awt.Stroke var18 = var10.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     boolean var22 = var8.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(100);
//     double var27 = var1.java2DToValue(100.0d, var4, var26);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    var3.setLabelGap((-1.0d));
    java.lang.Object var6 = var3.clone();
    var3.setShadowXOffset((-1.0d));
    var3.setShadowXOffset(10.0d);
    boolean var11 = var3.getSimpleLabels();
    java.awt.Stroke var12 = var3.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.plot.Plot var14 = var13.getPlot();
    java.awt.RenderingHints var15 = var13.getRenderingHints();
    java.awt.Color var19 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var20 = var19.getGreen();
    var13.setBorderPaint((java.awt.Paint)var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var1, (java.awt.Paint)var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 255);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     org.jfree.chart.axis.DateTickUnit var3 = null;
//     var1.setTickUnit(var3, false, false);
//     var1.configure();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var14 = var13.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     java.awt.Stroke var25 = var17.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var27 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var17.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var27);
//     boolean var29 = var15.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var30);
//     org.jfree.chart.util.RectangleEdge var33 = var31.getRangeAxisEdge(100);
//     boolean var34 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var33);
//     java.lang.String var35 = var33.toString();
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     org.jfree.chart.axis.AxisState var37 = var1.draw(var8, 0.14d, var10, var11, var33, var36);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     java.text.DateFormat var3 = var1.getDateFormatOverride();
//     org.jfree.chart.axis.DateTickUnit var4 = null;
//     var1.setTickUnit(var4, false, false);
//     org.jfree.chart.axis.DateTickUnit var8 = null;
//     java.util.Date var9 = var1.calculateLowestVisibleTickValue(var8);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setID("poly");
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setLabelGap((-1.0d));
    java.lang.Object var11 = var8.clone();
    var8.setShadowXOffset((-1.0d));
    var8.setShadowXOffset(10.0d);
    boolean var16 = var8.getSimpleLabels();
    java.awt.Stroke var17 = var8.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.plot.Plot var19 = var18.getPlot();
    java.awt.RenderingHints var20 = var18.getRenderingHints();
    java.awt.Color var24 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var25 = var24.getGreen();
    var18.setBorderPaint((java.awt.Paint)var24);
    org.jfree.chart.title.LegendTitle var27 = var18.getLegend();
    org.jfree.chart.title.TextTitle var29 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var30 = var29.getTextAlignment();
    var29.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var33 = new org.jfree.chart.util.RectangleInsets();
    var29.setPadding(var33);
    double var36 = var33.trimHeight(0.05d);
    var27.setLegendItemGraphicPadding(var33);
    org.jfree.chart.util.RectangleInsets var38 = var27.getLegendItemGraphicPadding();
    var1.setPadding(var38);
    java.awt.geom.Rectangle2D var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var41 = var38.createInsetRectangle(var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");
//     java.lang.String var2 = var1.getText();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var1.calculateDimensions(var3);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var5 = var4.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setLabelGap((-1.0d));
    java.lang.Object var11 = var8.clone();
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var8.setURLGenerator(var13);
    java.awt.Stroke var16 = var8.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var18);
    boolean var20 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var21);
    org.jfree.data.Range var23 = var4.getDefaultAutoRange();
    var2.setRange(var23);
    org.jfree.data.Range var25 = null;
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 100.0d);
    org.jfree.chart.block.RectangleConstraint var28 = var27.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var29 = var28.getHeightConstraintType();
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var31, 1.0E-8d);
    double var36 = var35.getLength();
    org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var35, (-1.95d));
    double var39 = var38.getUpperBound();
    org.jfree.data.Range var40 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 100.0d);
    double var43 = var42.getWidth();
    org.jfree.chart.block.LengthConstraintType var44 = var42.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(0.0d, var23, var29, 10.0d, var38, var44);
    java.lang.String var46 = var44.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var46.equals("RectangleConstraintType.RANGE"));

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.lang.Object var2 = var0.handleGetObject("java.awt.Color[r=255,g=255,b=254]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var4 = var0.getObject("Multiple Pie Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.util.RectangleEdge var5 = null;
    double var6 = var2.valueToJava2D(10.0d, var4, var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = null;
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, var7);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var8.setFixedRangeAxisSpace(var9);
    org.jfree.chart.plot.ValueMarker var13 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.event.MarkerChangeEvent var15 = null;
    var13.notifyListeners(var15);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var20 = var18.getTickLabelPaint((java.lang.Comparable)255);
    var13.setLabelPaint(var20);
    org.jfree.chart.util.Layer var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(0, (org.jfree.chart.plot.Marker)var13, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");

  }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     var1.setTickMarkOutsideLength(1.0f);
//     float var4 = var1.getTickMarkOutsideLength();
//     java.awt.Color var8 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var9 = null;
//     java.awt.Rectangle var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.awt.geom.AffineTransform var12 = null;
//     java.awt.RenderingHints var13 = null;
//     java.awt.PaintContext var14 = var8.createContext(var9, var10, var11, var12, var13);
//     java.lang.String var15 = var8.toString();
//     float[] var16 = null;
//     float[] var17 = var8.getRGBComponents(var16);
//     var1.setAxisLinePaint((java.awt.Paint)var8);
//     java.awt.Color var19 = var8.brighter();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     java.awt.Paint var22 = null;
//     var21.setLabelShadowPaint(var22);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var32 = null;
//     var27.setURLGenerator(var32);
//     var27.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     org.jfree.chart.plot.PiePlotState var38 = var21.initialise(var24, var25, var27, (java.lang.Integer)0, var37);
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     var40.setLabelGap((-1.0d));
//     java.awt.Font var43 = var40.getLabelFont();
//     var27.setNoDataMessageFont(var43);
//     boolean var45 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var19, (java.lang.Object)var43);
//     java.awt.Color var49 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     java.awt.geom.AffineTransform var53 = null;
//     java.awt.RenderingHints var54 = null;
//     java.awt.PaintContext var55 = var49.createContext(var50, var51, var52, var53, var54);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot var57 = new org.jfree.chart.plot.PiePlot(var56);
//     var57.setLabelGap((-1.0d));
//     java.awt.Stroke var60 = var57.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var63 = var62.getTextAlignment();
//     var62.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var66 = new org.jfree.chart.util.RectangleInsets();
//     var62.setPadding(var66);
//     org.jfree.chart.block.LineBorder var68 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var49, var60, var66);
//     java.awt.Color var72 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var73 = null;
//     java.awt.Rectangle var74 = null;
//     java.awt.geom.Rectangle2D var75 = null;
//     java.awt.geom.AffineTransform var76 = null;
//     java.awt.RenderingHints var77 = null;
//     java.awt.PaintContext var78 = var72.createContext(var73, var74, var75, var76, var77);
//     java.lang.String var79 = var72.toString();
//     float[] var80 = null;
//     float[] var81 = var72.getRGBComponents(var80);
//     float[] var82 = var49.getRGBColorComponents(var81);
//     org.jfree.chart.text.TextFragment var84 = new org.jfree.chart.text.TextFragment("", var43, (java.awt.Paint)var49, 1.0f);
//     
//     // Checks the contract:  equals-hashcode on var40 and var57
//     assertTrue("Contract failed: equals-hashcode on var40 and var57", var40.equals(var57) ? var40.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var40
//     assertTrue("Contract failed: equals-hashcode on var57 and var40", var57.equals(var40) ? var57.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var1.configure();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3, false, false);
    var1.configure();
    java.util.TimeZone var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.util.RectangleEdge var5 = null;
//     double var6 = var1.getCategoryStart(0, (-1), var4, var5);
//     java.awt.Color var10 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var11 = null;
//     java.awt.Rectangle var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.AffineTransform var14 = null;
//     java.awt.RenderingHints var15 = null;
//     java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.awt.Stroke var21 = var18.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var24 = var23.getTextAlignment();
//     var23.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var27 = new org.jfree.chart.util.RectangleInsets();
//     var23.setPadding(var27);
//     org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var21, var27);
//     var1.setAxisLineStroke(var21);
//     var1.addCategoryLabelToolTip((java.lang.Comparable)"org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     var1.clearCategoryLabelToolTips();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.axis.AxisState var36 = null;
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var40 = var39.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     var43.setLabelGap((-1.0d));
//     java.lang.Object var46 = var43.clone();
//     java.awt.Paint var47 = var43.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var48 = null;
//     var43.setURLGenerator(var48);
//     java.awt.Stroke var51 = var43.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var53 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var43.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var53);
//     boolean var55 = var41.equals((java.lang.Object)var43);
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var56);
//     org.jfree.chart.util.RectangleEdge var59 = var57.getRangeAxisEdge(100);
//     boolean var60 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var59);
//     java.util.List var61 = var1.refreshTicks(var35, var36, var37, var59);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     float var2 = var1.getMaximumCategoryLabelWidthRatio();
//     double var3 = var1.getUpperMargin();
//     int var4 = var1.getCategoryLabelPositionOffset();
//     java.awt.Font var5 = var1.getTickLabelFont();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.AxisState var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var11 = var10.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     var14.setLabelGap((-1.0d));
//     java.lang.Object var17 = var14.clone();
//     java.awt.Paint var18 = var14.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var19 = null;
//     var14.setURLGenerator(var19);
//     java.awt.Stroke var22 = var14.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var14.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
//     boolean var26 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var27);
//     org.jfree.chart.util.RectangleEdge var30 = var28.getRangeAxisEdge(100);
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.util.List var32 = var1.refreshTicks(var6, var7, var8, var30);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var2 = var0.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.chart.plot.PlotRenderingInfo var19 = var18.getInfo();
    java.awt.geom.Rectangle2D var20 = null;
    var18.setExplodedPieArea(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    java.lang.String var2 = var1.getPlotType();
    var1.setLimit(1.0E-8d);
    var1.setLimit(Double.POSITIVE_INFINITY);
    org.jfree.chart.util.TableOrder var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Multiple Pie Plot"+ "'", var2.equals("Multiple Pie Plot"));

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var20 = var11.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     java.awt.Paint var5 = var1.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var6 = null;
//     var1.setURLGenerator(var6);
//     java.awt.Stroke var9 = var1.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.xy.XYDataset var12 = null;
//     org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var14 = var13.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var15 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     java.awt.Stroke var25 = var17.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var27 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var17.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var27);
//     boolean var29 = var15.equals((java.lang.Object)var17);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot(var12, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.axis.ValueAxis)var15, var30);
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     java.awt.geom.Point2D var35 = null;
//     var31.zoomRangeAxes(0.05d, 10.0d, var34, var35);
//     var31.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var41 = null;
//     java.util.Collection var42 = var31.getRangeMarkers(0, var41);
//     boolean var43 = var31.isDomainZoomable();
//     java.awt.Paint var44 = var31.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var46 = null;
//     org.jfree.chart.plot.PolarPlot var47 = new org.jfree.chart.plot.PolarPlot();
//     var47.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     org.jfree.chart.util.RectangleAnchor var54 = null;
//     java.awt.geom.Point2D var55 = org.jfree.chart.util.RectangleAnchor.coordinates(var53, var54);
//     var47.zoomDomainAxes(0.0d, (-1.0d), var52, var55);
//     var31.zoomRangeAxes((-1.0d), var46, var55);
//     org.jfree.chart.plot.PlotState var58 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     var1.draw(var10, var11, var55, var58, var59);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setRangeAxisLocation(4, var23, false);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
//     var20.setBackgroundAlpha(1.0f);
//     boolean var29 = var20.isDomainGridlinesVisible();
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var32 = var31.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     var35.setLabelGap((-1.0d));
//     java.lang.Object var38 = var35.clone();
//     java.awt.Paint var39 = var35.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var40 = null;
//     var35.setURLGenerator(var40);
//     java.awt.Stroke var43 = var35.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var35.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var45);
//     boolean var47 = var33.equals((java.lang.Object)var35);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.axis.ValueAxis)var33, var48);
//     java.awt.Paint var50 = var49.getDomainZeroBaselinePaint();
//     java.awt.Stroke var51 = var49.getRangeZeroBaselineStroke();
//     org.jfree.chart.axis.AxisLocation var53 = var49.getRangeAxisLocation(1);
//     var20.setDomainAxisLocation(var53);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var38
//     assertTrue("Contract failed: equals-hashcode on var9 and var38", var9.equals(var38) ? var9.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var9
//     assertTrue("Contract failed: equals-hashcode on var38 and var9", var38.equals(var9) ? var38.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var45
//     assertTrue("Contract failed: equals-hashcode on var16 and var45", var16.equals(var45) ? var16.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var16
//     assertTrue("Contract failed: equals-hashcode on var45 and var16", var45.equals(var16) ? var45.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.awt.Font var4 = var1.getLabelFont();
    boolean var5 = var1.isOutlineVisible();
    var1.setStartAngle(1.0E-8d);
    org.jfree.chart.LegendItemCollection var8 = var1.getLegendItems();
    java.util.Iterator var9 = var8.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test246() {}
//   public void test246() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     float var23 = var22.getTickMarkOutsideLength();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     java.awt.Shape var29 = var25.getLegendItemShape();
//     var22.setUpArrow(var29);
//     org.jfree.chart.axis.ValueAxis[] var31 = new org.jfree.chart.axis.ValueAxis[] { var22};
//     var19.setRangeAxes(var31);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     java.lang.String var23 = var3.toString();
//     java.awt.Color var24 = var3.darker();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     java.awt.Color var44 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     java.awt.geom.AffineTransform var48 = null;
//     java.awt.RenderingHints var49 = null;
//     java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
//     java.awt.color.ColorSpace var51 = var44.getColorSpace();
//     var28.setNoDataMessagePaint((java.awt.Paint)var44);
//     org.jfree.chart.block.LineBorder var53 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var54 = var53.getPaint();
//     java.awt.Stroke var55 = var53.getStroke();
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var44, var55);
//     java.awt.Color var60 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var61 = null;
//     java.awt.Rectangle var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     java.awt.geom.AffineTransform var64 = null;
//     java.awt.RenderingHints var65 = null;
//     java.awt.PaintContext var66 = var60.createContext(var61, var62, var63, var64, var65);
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot(var67);
//     var68.setLabelGap((-1.0d));
//     java.awt.Stroke var71 = var68.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var74 = var73.getTextAlignment();
//     var73.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var77 = new org.jfree.chart.util.RectangleInsets();
//     var73.setPadding(var77);
//     org.jfree.chart.block.LineBorder var79 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var60, var71, var77);
//     java.awt.Color var83 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var84 = null;
//     java.awt.Rectangle var85 = null;
//     java.awt.geom.Rectangle2D var86 = null;
//     java.awt.geom.AffineTransform var87 = null;
//     java.awt.RenderingHints var88 = null;
//     java.awt.PaintContext var89 = var83.createContext(var84, var85, var86, var87, var88);
//     java.lang.String var90 = var83.toString();
//     float[] var91 = null;
//     float[] var92 = var83.getRGBComponents(var91);
//     float[] var93 = var60.getRGBColorComponents(var92);
//     float[] var94 = var44.getComponents(var93);
//     float[] var95 = var3.getRGBComponents(var94);
//     
//     // Checks the contract:  equals-hashcode on var11 and var68
//     assertTrue("Contract failed: equals-hashcode on var11 and var68", var11.equals(var68) ? var11.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var11
//     assertTrue("Contract failed: equals-hashcode on var68 and var11", var68.equals(var11) ? var68.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var79
//     assertTrue("Contract failed: equals-hashcode on var22 and var79", var22.equals(var79) ? var22.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var22
//     assertTrue("Contract failed: equals-hashcode on var79 and var22", var79.equals(var22) ? var79.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     var1.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     var10.setShadowXOffset((-1.0d));
//     var10.setShadowXOffset(10.0d);
//     boolean var18 = var10.getSimpleLabels();
//     java.awt.Stroke var19 = var10.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var20, 0, 0);
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var20);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var26.setExpandToFitSpace(true);
//     var20.setTitle(var26);
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var32 = var31.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     var35.setLabelGap((-1.0d));
//     java.lang.Object var38 = var35.clone();
//     java.awt.Paint var39 = var35.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var40 = null;
//     var35.setURLGenerator(var40);
//     java.awt.Stroke var43 = var35.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var35.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var45);
//     boolean var47 = var33.equals((java.lang.Object)var35);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.axis.ValueAxis)var33, var48);
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     java.awt.geom.Point2D var53 = null;
//     var49.zoomRangeAxes(0.05d, 10.0d, var52, var53);
//     var49.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var59 = null;
//     java.util.Collection var60 = var49.getRangeMarkers(0, var59);
//     boolean var61 = var49.isDomainZoomable();
//     java.awt.Paint var62 = var49.getNoDataMessagePaint();
//     var49.configureDomainAxes();
//     var49.setBackgroundAlpha(100.0f);
//     var49.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.RectangleEdge var69 = var49.getRangeAxisEdge(0);
//     var26.setPosition(var69);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.RectangleInsets var2 = new org.jfree.chart.util.RectangleInsets();
    double var4 = var2.calculateRightOutset(10.0d);
    double var6 = var2.calculateBottomOutset((-1.0d));
    org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
    var7.setTickMarkOutsideLength(1.0f);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    java.awt.Paint var12 = null;
    var11.setLabelShadowPaint(var12);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
    var17.setLabelGap((-1.0d));
    java.lang.Object var20 = var17.clone();
    java.awt.Paint var21 = var17.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var22 = null;
    var17.setURLGenerator(var22);
    var17.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var27 = null;
    org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
    java.awt.Paint var29 = var11.getLabelOutlinePaint();
    var7.setAxisLinePaint(var29);
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var2, var29);
    var1.setTickMarkPaint(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 0.12d, 1.0E-8d, (-1.95d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var12 = var11.getBorderStroke();
//     org.jfree.chart.event.ChartProgressListener var13 = null;
//     var11.addProgressListener(var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     var16.setLabelGap((-1.0d));
//     java.lang.Object var19 = var16.clone();
//     var16.setShadowXOffset((-1.0d));
//     var16.setShadowXOffset(10.0d);
//     boolean var24 = var16.getSimpleLabels();
//     java.awt.Stroke var25 = var16.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var16);
//     org.jfree.chart.plot.Plot var27 = var26.getPlot();
//     java.awt.RenderingHints var28 = var26.getRenderingHints();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var33 = var32.getGreen();
//     var26.setBorderPaint((java.awt.Paint)var32);
//     org.jfree.chart.title.LegendTitle var35 = var26.getLegend();
//     java.awt.Paint var36 = var35.getBackgroundPaint();
//     org.jfree.chart.block.BlockFrame var37 = var35.getFrame();
//     var11.addLegend(var35);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var19
//     assertTrue("Contract failed: equals-hashcode on var4 and var19", var4.equals(var19) ? var4.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var4
//     assertTrue("Contract failed: equals-hashcode on var19 and var4", var19.equals(var4) ? var19.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var3 = var0.getObject("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var1.configure();
    org.jfree.chart.axis.DateTickUnit var3 = null;
    var1.setTickUnit(var3);
    java.util.Date var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinimumDate(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var1.setRangeWithMargins(0.0d, 100.0d);
    var1.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     var1.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var19);
//     var20.removeCornerTextItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     java.awt.Paint var29 = var25.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var30 = null;
//     var25.setURLGenerator(var30);
//     java.awt.Stroke var33 = var25.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var35);
//     boolean var37 = var23.equals((java.lang.Object)var25);
//     java.awt.Color var41 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var42 = null;
//     java.awt.Rectangle var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     java.awt.geom.AffineTransform var45 = null;
//     java.awt.RenderingHints var46 = null;
//     java.awt.PaintContext var47 = var41.createContext(var42, var43, var44, var45, var46);
//     java.awt.color.ColorSpace var48 = var41.getColorSpace();
//     var25.setNoDataMessagePaint((java.awt.Paint)var41);
//     var20.setAngleGridlinePaint((java.awt.Paint)var41);
//     
//     // Checks the contract:  equals-hashcode on var6 and var28
//     assertTrue("Contract failed: equals-hashcode on var6 and var28", var6.equals(var28) ? var6.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var6
//     assertTrue("Contract failed: equals-hashcode on var28 and var6", var28.equals(var6) ? var28.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var35
//     assertTrue("Contract failed: equals-hashcode on var13 and var35", var13.equals(var35) ? var13.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var13
//     assertTrue("Contract failed: equals-hashcode on var35 and var13", var35.equals(var13) ? var35.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.event.ChartChangeEvent var1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(short)100);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    var3.setLabelGap((-1.0d));
    java.lang.Object var6 = var3.clone();
    var3.setShadowXOffset((-1.0d));
    var3.setShadowXOffset(10.0d);
    boolean var11 = var3.getSimpleLabels();
    java.awt.Stroke var12 = var3.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.plot.Plot var14 = var13.getPlot();
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var13.removeProgressListener(var15);
    var1.setChart(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var18 = var13.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var1 = var0.getLabelFont();
    var0.setVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
    org.jfree.data.Range var4 = var3.getHeightRange();
    java.lang.String var5 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]"+ "'", var5.equals("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]"));

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    var1.handleClick(0, 10, var8);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var1.setLegendLabelURLGenerator(var10);
    var1.setMinimumArcAngleToDraw(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     java.awt.Paint var21 = var20.getBackgroundPaint();
//     org.jfree.chart.block.BlockFrame var22 = var20.getFrame();
//     org.jfree.chart.util.RectangleInsets var23 = var20.getLegendItemGraphicPadding();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     var25.setShadowXOffset((-1.0d));
//     var25.setShadowXOffset(10.0d);
//     boolean var33 = var25.getSimpleLabels();
//     java.awt.Stroke var34 = var25.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var25);
//     org.jfree.chart.plot.Plot var36 = var35.getPlot();
//     java.awt.RenderingHints var37 = var35.getRenderingHints();
//     java.awt.Color var41 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var42 = var41.getGreen();
//     var35.setBorderPaint((java.awt.Paint)var41);
//     org.jfree.chart.title.LegendTitle var44 = var35.getLegend();
//     org.jfree.chart.util.RectangleAnchor var45 = var44.getLegendItemGraphicAnchor();
//     java.lang.String var46 = var45.toString();
//     var20.setLegendItemGraphicLocation(var45);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var12
//     assertTrue("Contract failed: equals-hashcode on var36 and var12", var36.equals(var12) ? var36.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setDarkerSides(false);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var7 = var6.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var10.setURLGenerator(var15);
//     java.awt.Stroke var18 = var10.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     boolean var22 = var8.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var23);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Point2D var28 = null;
//     var24.zoomRangeAxes(0.05d, 10.0d, var27, var28);
//     var24.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var34 = null;
//     java.util.Collection var35 = var24.getRangeMarkers(0, var34);
//     boolean var36 = var24.isDomainZoomable();
//     java.awt.Paint var37 = var24.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.plot.PolarPlot var40 = new org.jfree.chart.plot.PolarPlot();
//     var40.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     java.awt.geom.Rectangle2D var46 = null;
//     org.jfree.chart.util.RectangleAnchor var47 = null;
//     java.awt.geom.Point2D var48 = org.jfree.chart.util.RectangleAnchor.coordinates(var46, var47);
//     var40.zoomDomainAxes(0.0d, (-1.0d), var45, var48);
//     var24.zoomRangeAxes((-1.0d), var39, var48);
//     org.jfree.chart.plot.PlotState var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     var0.draw(var3, var4, var48, var51, var52);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setLabelLinkMargin((-1.0d));
    org.jfree.chart.plot.PieLabelDistributor var8 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    java.lang.String var9 = var8.toString();
    var1.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor)var8);
    java.lang.String var11 = var8.toString();
    org.jfree.chart.plot.PieLabelRecord var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addPieLabelRecord(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + ""+ "'", var9.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));

  }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    boolean var6 = var1.getSectionOutlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
    double var22 = var21.getHeight();
    var21.setPadding(0.14d, (-2.0d), 0.14d, (-1.95d));
    org.jfree.chart.block.Arrangement var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setArrangement(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Font var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
//     double var2 = var0.calculateRightOutset(10.0d);
//     double var4 = var0.calculateBottomOutset((-1.0d));
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.trim(var5);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     var1.setRange((-1.0d), 0.05d);
//     java.util.Date var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var10 = var9.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var11 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     java.awt.Stroke var21 = var13.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var23 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var13.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var23);
//     boolean var25 = var11.equals((java.lang.Object)var13);
//     org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var8, (org.jfree.chart.axis.ValueAxis)var9, (org.jfree.chart.axis.ValueAxis)var11, var26);
//     org.jfree.chart.util.RectangleEdge var29 = var27.getRangeAxisEdge(100);
//     double var30 = var1.dateToJava2D(var6, var7, var29);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var3 = null;
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var5 = var4.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setLabelGap((-1.0d));
//     java.lang.Object var11 = var8.clone();
//     java.awt.Paint var12 = var8.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var13 = null;
//     var8.setURLGenerator(var13);
//     java.awt.Stroke var16 = var8.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var18);
//     boolean var20 = var6.equals((java.lang.Object)var8);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var21);
//     org.jfree.data.Range var23 = var4.getDefaultAutoRange();
//     var2.setRange(var23);
//     org.jfree.data.Range var25 = null;
//     org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var28 = var27.toUnconstrainedWidth();
//     org.jfree.chart.block.LengthConstraintType var29 = var28.getHeightConstraintType();
//     org.jfree.data.Range var31 = null;
//     org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var31, 1.0E-8d);
//     double var36 = var35.getLength();
//     org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var35, (-1.95d));
//     double var39 = var38.getUpperBound();
//     org.jfree.data.Range var40 = null;
//     org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 100.0d);
//     double var43 = var42.getWidth();
//     org.jfree.chart.block.LengthConstraintType var44 = var42.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(0.0d, var23, var29, 10.0d, var38, var44);
//     org.jfree.chart.block.RectangleConstraint var47 = var45.toFixedHeight(10.0d);
//     org.jfree.chart.util.Size2D var48 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.JFreeChart var49 = null;
//     org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var48, var49);
//     org.jfree.chart.util.Size2D var51 = var45.calculateConstrainedSize(var48);
//     
//     // Checks the contract:  equals-hashcode on var48 and var51
//     assertTrue("Contract failed: equals-hashcode on var48 and var51", var48.equals(var51) ? var48.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var48
//     assertTrue("Contract failed: equals-hashcode on var51 and var48", var51.equals(var48) ? var51.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.xy.XYDataset var1 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var3 = var2.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    var6.setLabelGap((-1.0d));
    java.lang.Object var9 = var6.clone();
    java.awt.Paint var10 = var6.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var11 = null;
    var6.setURLGenerator(var11);
    java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
    boolean var18 = var4.equals((java.lang.Object)var6);
    org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
    var20.clearDomainAxes();
    org.jfree.chart.axis.AxisLocation var23 = null;
    var20.setRangeAxisLocation(4, var23, false);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
    org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var29 = var28.getPaint();
    boolean var30 = var26.equals((java.lang.Object)var29);
    var26.clearSubtitles();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var33 = var26.getSubtitle(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     var7.setLabelGap((-1.0d));
//     java.lang.Object var10 = var7.clone();
//     java.awt.Paint var11 = var7.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var12 = null;
//     var7.setURLGenerator(var12);
//     var7.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
//     java.awt.Paint var19 = var1.getLabelOutlinePaint();
//     var1.setSimpleLabels(true);
//     org.jfree.data.xy.XYDataset var23 = null;
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var25 = var24.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var41 = null;
//     org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot(var23, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.axis.ValueAxis)var26, var41);
//     var42.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var42.setRangeAxisLocation(4, var45, false);
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var42);
//     var42.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var51 = var42.getRangeZeroBaselineStroke();
//     var1.setLabelLinkStroke(var51);
//     
//     // Checks the contract:  equals-hashcode on var10 and var31
//     assertTrue("Contract failed: equals-hashcode on var10 and var31", var10.equals(var31) ? var10.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var10
//     assertTrue("Contract failed: equals-hashcode on var31 and var10", var31.equals(var10) ? var31.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var4 = var3.getTextAlignment();
//     var3.setHeight(1.0d);
//     double var7 = var3.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var9 = var8.getLabelFont();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.chart.text.TextLine var11 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=254]", var9);
//     boolean var12 = var0.equals((java.lang.Object)"java.awt.Color[r=255,g=255,b=254]");
//     var0.removeCornerTextItem("RectangleEdge.RIGHT");
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var19 = var18.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     var22.setLabelGap((-1.0d));
//     java.lang.Object var25 = var22.clone();
//     java.awt.Paint var26 = var22.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var27 = null;
//     var22.setURLGenerator(var27);
//     java.awt.Stroke var30 = var22.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var22.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var32);
//     boolean var34 = var20.equals((java.lang.Object)var22);
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var20, var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var36.zoomRangeAxes(0.05d, 10.0d, var39, var40);
//     var36.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var36.getRangeMarkers(0, var46);
//     boolean var48 = var36.isDomainZoomable();
//     java.awt.Paint var49 = var36.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.chart.plot.PolarPlot var52 = new org.jfree.chart.plot.PolarPlot();
//     var52.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     org.jfree.chart.util.RectangleAnchor var59 = null;
//     java.awt.geom.Point2D var60 = org.jfree.chart.util.RectangleAnchor.coordinates(var58, var59);
//     var52.zoomDomainAxes(0.0d, (-1.0d), var57, var60);
//     var36.zoomRangeAxes((-1.0d), var51, var60);
//     var0.zoomDomainAxes(Double.NaN, var16, var60, true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var52
//     assertTrue("Contract failed: equals-hashcode on var0 and var52", var0.equals(var52) ? var0.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var0
//     assertTrue("Contract failed: equals-hashcode on var52 and var0", var52.equals(var0) ? var52.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateY(0.12d);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    double var20 = var3.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);

  }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     var1.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     var10.setShadowXOffset((-1.0d));
//     var10.setShadowXOffset(10.0d);
//     boolean var18 = var10.getSimpleLabels();
//     java.awt.Stroke var19 = var10.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var20, 0, 0);
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var20);
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     var26.setExpandToFitSpace(true);
//     var20.setTitle(var26);
//     java.awt.Paint var30 = var26.getPaint();
//     java.awt.Graphics2D var31 = null;
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     var40.setLabelGap((-1.0d));
//     java.lang.Object var43 = var40.clone();
//     java.awt.Paint var44 = var40.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var45 = null;
//     var40.setURLGenerator(var45);
//     var40.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.chart.plot.PiePlotState var51 = var34.initialise(var37, var38, var40, (java.lang.Integer)0, var50);
//     var51.setPieWRadius(Double.POSITIVE_INFINITY);
//     double var54 = var51.getPieWRadius();
//     var51.setPieWRadius(100.0d);
//     var51.setPieHRadius((-1.95d));
//     java.lang.Object var59 = var26.draw(var31, var32, (java.lang.Object)(-1.95d));
//     
//     // Checks the contract:  equals-hashcode on var13 and var43
//     assertTrue("Contract failed: equals-hashcode on var13 and var43", var13.equals(var43) ? var13.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var13
//     assertTrue("Contract failed: equals-hashcode on var43 and var13", var43.equals(var13) ? var43.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.data.Range var20 = var1.getDefaultAutoRange();
    double var21 = var20.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("RectangleAnchor.CENTER", 1, (-1));
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     boolean var31 = var19.isDomainZoomable();
//     var19.mapDatasetToRangeAxis(4, 0);
//     var19.clearDomainMarkers();
//     java.lang.Object var36 = var19.clone();
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     java.awt.Paint var41 = null;
//     var40.setLabelShadowPaint(var41);
//     java.awt.Graphics2D var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.data.general.PieDataset var45 = null;
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot(var45);
//     var46.setLabelGap((-1.0d));
//     java.lang.Object var49 = var46.clone();
//     java.awt.Paint var50 = var46.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var51 = null;
//     var46.setURLGenerator(var51);
//     var46.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var56 = null;
//     org.jfree.chart.plot.PiePlotState var57 = var40.initialise(var43, var44, var46, (java.lang.Integer)0, var56);
//     java.awt.Paint var58 = var40.getLabelOutlinePaint();
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.PiePlot var60 = new org.jfree.chart.plot.PiePlot(var59);
//     var60.setLabelGap((-1.0d));
//     java.awt.Stroke var63 = var60.getLabelLinkStroke();
//     org.jfree.chart.labels.PieSectionLabelGenerator var64 = null;
//     var60.setLabelGenerator(var64);
//     double var67 = var60.getExplodePercent((java.lang.Comparable)1.0d);
//     java.awt.Paint var68 = var60.getLabelBackgroundPaint();
//     java.awt.Color var72 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var73 = null;
//     java.awt.Rectangle var74 = null;
//     java.awt.geom.Rectangle2D var75 = null;
//     java.awt.geom.AffineTransform var76 = null;
//     java.awt.RenderingHints var77 = null;
//     java.awt.PaintContext var78 = var72.createContext(var73, var74, var75, var76, var77);
//     org.jfree.data.general.PieDataset var79 = null;
//     org.jfree.chart.plot.PiePlot var80 = new org.jfree.chart.plot.PiePlot(var79);
//     var80.setLabelGap((-1.0d));
//     java.awt.Stroke var83 = var80.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var86 = var85.getTextAlignment();
//     var85.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var89 = new org.jfree.chart.util.RectangleInsets();
//     var85.setPadding(var89);
//     org.jfree.chart.block.LineBorder var91 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var72, var83, var89);
//     org.jfree.chart.JFreeChart var92 = null;
//     org.jfree.chart.event.ChartChangeEventType var93 = null;
//     org.jfree.chart.event.ChartChangeEvent var94 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var91, var92, var93);
//     java.awt.Stroke var95 = var91.getStroke();
//     var60.setBaseSectionOutlineStroke(var95);
//     org.jfree.chart.plot.ValueMarker var97 = new org.jfree.chart.plot.ValueMarker(0.0d, var58, var95);
//     org.jfree.chart.util.Layer var98 = null;
//     boolean var99 = var19.removeDomainMarker(4, (org.jfree.chart.plot.Marker)var97, var98);
// 
//   }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     var0.setUpperMargin(1.0d);
//     boolean var3 = var0.isTickMarksVisible();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     var5.setLabelLinkMargin((-1.0d));
//     java.awt.Paint var11 = var5.getBaseSectionPaint();
//     boolean var12 = var0.hasListener((java.util.EventListener)var5);
//     var0.setTickMarksVisible(false);
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var19 = var18.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var20 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     var22.setLabelGap((-1.0d));
//     java.lang.Object var25 = var22.clone();
//     java.awt.Paint var26 = var22.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var27 = null;
//     var22.setURLGenerator(var27);
//     java.awt.Stroke var30 = var22.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var32 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var22.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var32);
//     boolean var34 = var20.equals((java.lang.Object)var22);
//     org.jfree.chart.renderer.xy.XYItemRenderer var35 = null;
//     org.jfree.chart.plot.XYPlot var36 = new org.jfree.chart.plot.XYPlot(var17, (org.jfree.chart.axis.ValueAxis)var18, (org.jfree.chart.axis.ValueAxis)var20, var35);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     java.awt.geom.Point2D var40 = null;
//     var36.zoomRangeAxes(0.05d, 10.0d, var39, var40);
//     var36.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var46 = null;
//     java.util.Collection var47 = var36.getRangeMarkers(0, var46);
//     boolean var48 = var36.isDomainZoomable();
//     java.awt.Paint var49 = var36.getNoDataMessagePaint();
//     var36.configureDomainAxes();
//     var36.setBackgroundAlpha(100.0f);
//     var36.setDomainGridlinesVisible(false);
//     org.jfree.chart.util.RectangleEdge var56 = var36.getRangeAxisEdge(0);
//     double var57 = var0.lengthToJava2D(10.0d, var16, var56);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var0, 1.0E-8d);
    double var5 = var4.getLength();
    java.lang.String var6 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Range[1.0E-8,1.0E-8]"+ "'", var6.equals("Range[1.0E-8,1.0E-8]"));

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    var0.draw(var1, 10.0f, 1.0f, var4);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
//     int var22 = var19.getDomainAxisCount();
//     org.jfree.chart.axis.ValueAxis var23 = var19.getDomainAxis();
//     org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var28 = var27.getTextAlignment();
//     var27.setHeight(1.0d);
//     double var31 = var27.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var33 = var32.getLabelFont();
//     boolean var34 = var27.equals((java.lang.Object)var33);
//     org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=254]", var33);
//     boolean var36 = var24.equals((java.lang.Object)"java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Stroke var37 = var24.getRadiusGridlineStroke();
//     var19.setDomainGridlineStroke(var37);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var44 = var43.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     var47.setLabelGap((-1.0d));
//     java.lang.Object var50 = var47.clone();
//     java.awt.Paint var51 = var47.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var52 = null;
//     var47.setURLGenerator(var52);
//     java.awt.Stroke var55 = var47.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var57 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var47.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var57);
//     boolean var59 = var45.equals((java.lang.Object)var47);
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var42, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.axis.ValueAxis)var45, var60);
//     var61.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot();
//     var65.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var70 = null;
//     java.awt.geom.Rectangle2D var71 = null;
//     org.jfree.chart.util.RectangleAnchor var72 = null;
//     java.awt.geom.Point2D var73 = org.jfree.chart.util.RectangleAnchor.coordinates(var71, var72);
//     var65.zoomDomainAxes(0.0d, (-1.0d), var70, var73);
//     var61.zoomRangeAxes(100.0d, var64, var73);
//     var19.zoomRangeAxes(0.0d, 0.0d, var41, var73);
//     
//     // Checks the contract:  equals-hashcode on var5 and var47
//     assertTrue("Contract failed: equals-hashcode on var5 and var47", var5.equals(var47) ? var5.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var5
//     assertTrue("Contract failed: equals-hashcode on var47 and var5", var47.equals(var5) ? var47.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var50
//     assertTrue("Contract failed: equals-hashcode on var8 and var50", var8.equals(var50) ? var8.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var8
//     assertTrue("Contract failed: equals-hashcode on var50 and var8", var50.equals(var8) ? var50.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var57
//     assertTrue("Contract failed: equals-hashcode on var15 and var57", var15.equals(var57) ? var15.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var15
//     assertTrue("Contract failed: equals-hashcode on var57 and var15", var57.equals(var15) ? var57.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var65
//     assertTrue("Contract failed: equals-hashcode on var24 and var65", var24.equals(var65) ? var24.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var24
//     assertTrue("Contract failed: equals-hashcode on var65 and var24", var65.equals(var24) ? var65.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraintType.RANGE", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var24 = var23.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var32 = null;
//     var27.setURLGenerator(var32);
//     java.awt.Stroke var35 = var27.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var27.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     boolean var39 = var25.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var40);
//     org.jfree.data.Range var42 = var23.getDefaultAutoRange();
//     boolean var43 = var21.equals((java.lang.Object)var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.awt.Font var4 = var1.getLabelFont();
//     boolean var5 = var1.isOutlineVisible();
//     double var6 = var1.getLabelGap();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.chart.plot.PolarPlot var9 = new org.jfree.chart.plot.PolarPlot();
//     var9.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleAnchor var16 = null;
//     java.awt.geom.Point2D var17 = org.jfree.chart.util.RectangleAnchor.coordinates(var15, var16);
//     var9.zoomDomainAxes(0.0d, (-1.0d), var14, var17);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleAnchor var22 = null;
//     java.awt.geom.Point2D var23 = org.jfree.chart.util.RectangleAnchor.coordinates(var21, var22);
//     var9.zoomDomainAxes(Double.POSITIVE_INFINITY, var20, var23, false);
//     org.jfree.chart.plot.PlotState var26 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var1.draw(var7, var8, var23, var26, var27);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setUpperMargin(1.0d);
    java.text.NumberFormat var3 = null;
    var0.setNumberFormatOverride(var3);
    java.awt.Font var5 = var0.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     boolean var21 = var19.isRangeGridlinesVisible();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.lang.Object var28 = var25.clone();
//     java.awt.Paint var29 = var25.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var30 = null;
//     var25.setURLGenerator(var30);
//     java.awt.Stroke var33 = var25.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var35 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var35);
//     boolean var37 = var23.equals((java.lang.Object)var25);
//     var23.configure();
//     var23.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var41 = null;
//     org.jfree.chart.plot.PolarPlot var42 = new org.jfree.chart.plot.PolarPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, var41);
//     java.awt.Font var43 = var42.getAngleLabelFont();
//     var19.setNoDataMessageFont(var43);
//     
//     // Checks the contract:  equals-hashcode on var5 and var25
//     assertTrue("Contract failed: equals-hashcode on var5 and var25", var5.equals(var25) ? var5.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var5
//     assertTrue("Contract failed: equals-hashcode on var25 and var5", var25.equals(var5) ? var25.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var35
//     assertTrue("Contract failed: equals-hashcode on var15 and var35", var15.equals(var35) ? var15.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var15
//     assertTrue("Contract failed: equals-hashcode on var35 and var15", var35.equals(var15) ? var35.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     org.jfree.chart.text.TextFragment var5 = var1.getFirstTextFragment();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var5.calculateDimensions(var6);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.awt.Paint var2 = var1.getLabelPaint();
    org.jfree.chart.util.RectangleInsets var3 = new org.jfree.chart.util.RectangleInsets();
    double var5 = var3.calculateRightOutset(10.0d);
    var1.setLabelOffset(var3);
    org.jfree.chart.util.LengthAdjustmentType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelOffsetType(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    var3.setLabelGap((-1.0d));
    java.lang.Object var6 = var3.clone();
    java.awt.Shape var7 = var3.getLegendItemShape();
    var0.setUpArrow(var7);
    org.jfree.chart.axis.MarkerAxisBand var9 = null;
    var0.setMarkerBand(var9);
    var0.setLabelToolTip("Size2D[width=0.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test295() {}
//   public void test295() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     boolean var21 = var19.isRangeGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     java.awt.Paint var30 = var26.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var26.setURLGenerator(var31);
//     java.awt.Stroke var34 = var26.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var26.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var36);
//     boolean var38 = var24.equals((java.lang.Object)var26);
//     java.awt.Color var42 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var43 = null;
//     java.awt.Rectangle var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     java.awt.geom.AffineTransform var46 = null;
//     java.awt.RenderingHints var47 = null;
//     java.awt.PaintContext var48 = var42.createContext(var43, var44, var45, var46, var47);
//     java.awt.color.ColorSpace var49 = var42.getColorSpace();
//     var26.setNoDataMessagePaint((java.awt.Paint)var42);
//     org.jfree.chart.block.LineBorder var51 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var52 = var51.getPaint();
//     java.awt.Stroke var53 = var51.getStroke();
//     org.jfree.chart.plot.ValueMarker var54 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var42, var53);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var59 = null;
//     java.awt.Rectangle var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     java.awt.geom.AffineTransform var62 = null;
//     java.awt.RenderingHints var63 = null;
//     java.awt.PaintContext var64 = var58.createContext(var59, var60, var61, var62, var63);
//     java.awt.color.ColorSpace var65 = var58.getColorSpace();
//     var54.setPaint((java.awt.Paint)var58);
//     java.awt.Paint var67 = var54.getOutlinePaint();
//     org.jfree.chart.util.Layer var68 = null;
//     var19.addRangeMarker(0, (org.jfree.chart.plot.Marker)var54, var68);
//     
//     // Checks the contract:  equals-hashcode on var8 and var29
//     assertTrue("Contract failed: equals-hashcode on var8 and var29", var8.equals(var29) ? var8.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var8
//     assertTrue("Contract failed: equals-hashcode on var29 and var8", var29.equals(var8) ? var29.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var36
//     assertTrue("Contract failed: equals-hashcode on var15 and var36", var15.equals(var36) ? var15.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var15
//     assertTrue("Contract failed: equals-hashcode on var36 and var15", var36.equals(var15) ? var36.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.RectangleAnchor.coordinates(var6, var7);
//     var0.zoomDomainAxes(0.0d, (-1.0d), var5, var8);
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var11.configure();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.chart.event.RendererChangeEvent var14 = null;
//     var0.rendererChanged(var14);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.data.xy.XYDataset var18 = null;
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var20 = var19.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     var23.setLabelGap((-1.0d));
//     java.lang.Object var26 = var23.clone();
//     java.awt.Paint var27 = var23.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var28 = null;
//     var23.setURLGenerator(var28);
//     java.awt.Stroke var31 = var23.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var23.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var33);
//     boolean var35 = var21.equals((java.lang.Object)var23);
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = null;
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot(var18, (org.jfree.chart.axis.ValueAxis)var19, (org.jfree.chart.axis.ValueAxis)var21, var36);
//     org.jfree.chart.plot.PlotRenderingInfo var40 = null;
//     java.awt.geom.Point2D var41 = null;
//     var37.zoomRangeAxes(0.05d, 10.0d, var40, var41);
//     var37.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var47 = null;
//     java.util.Collection var48 = var37.getRangeMarkers(0, var47);
//     boolean var49 = var37.isDomainZoomable();
//     java.awt.Paint var50 = var37.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var52 = null;
//     org.jfree.chart.plot.PolarPlot var53 = new org.jfree.chart.plot.PolarPlot();
//     var53.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var58 = null;
//     java.awt.geom.Rectangle2D var59 = null;
//     org.jfree.chart.util.RectangleAnchor var60 = null;
//     java.awt.geom.Point2D var61 = org.jfree.chart.util.RectangleAnchor.coordinates(var59, var60);
//     var53.zoomDomainAxes(0.0d, (-1.0d), var58, var61);
//     var37.zoomRangeAxes((-1.0d), var52, var61);
//     var0.zoomDomainAxes(0.08d, var17, var61);
//     
//     // Checks the contract:  equals-hashcode on var0 and var53
//     assertTrue("Contract failed: equals-hashcode on var0 and var53", var0.equals(var53) ? var0.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var0
//     assertTrue("Contract failed: equals-hashcode on var53 and var0", var53.equals(var0) ? var53.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var15 = var14.getTextAlignment();
//     var14.setHeight(1.0d);
//     double var18 = var14.getContentXOffset();
//     java.lang.Object var19 = var14.clone();
//     double var20 = var14.getContentYOffset();
//     var11.setTitle(var14);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var27 = var26.getTextAlignment();
//     var26.setHeight(1.0d);
//     double var30 = var26.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var31 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var32 = var31.getLabelFont();
//     boolean var33 = var26.equals((java.lang.Object)var32);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     java.awt.Paint var36 = null;
//     var35.setLabelShadowPaint(var36);
//     java.awt.Graphics2D var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     java.awt.Paint var45 = var41.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var46 = null;
//     var41.setURLGenerator(var46);
//     var41.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.chart.plot.PiePlotState var52 = var35.initialise(var38, var39, var41, (java.lang.Integer)0, var51);
//     java.awt.Paint var53 = var35.getLabelOutlinePaint();
//     var35.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.PiePlot var57 = new org.jfree.chart.plot.PiePlot(var56);
//     java.awt.Paint var58 = null;
//     var57.setLabelShadowPaint(var58);
//     java.awt.Paint var60 = var57.getLabelOutlinePaint();
//     var35.setOutlinePaint(var60);
//     org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var32, var60);
//     org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var65 = var64.getTextAlignment();
//     var62.setLineAlignment(var65);
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.FlowArrangement var70 = new org.jfree.chart.block.FlowArrangement(var65, var67, (-1.0d), (-1.0d));
//     org.jfree.chart.block.BlockContainer var71 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var70);
//     var71.setID("");
//     java.lang.Object var74 = var14.draw(var22, var23, (java.lang.Object)var71);
//     
//     // Checks the contract:  equals-hashcode on var4 and var44
//     assertTrue("Contract failed: equals-hashcode on var4 and var44", var4.equals(var44) ? var4.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var4
//     assertTrue("Contract failed: equals-hashcode on var44 and var4", var44.equals(var4) ? var44.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var13 = var12.getPercentFormat();
//     var1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.data.general.PieDataset var15 = null;
//     java.text.AttributedString var17 = var12.generateAttributedSectionLabel(var15, (java.lang.Comparable)255);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     var19.clearRangeMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var27 = var26.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     var30.setLabelGap((-1.0d));
//     java.lang.Object var33 = var30.clone();
//     java.awt.Paint var34 = var30.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var35 = null;
//     var30.setURLGenerator(var35);
//     java.awt.Stroke var38 = var30.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var40 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var30.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var40);
//     boolean var42 = var28.equals((java.lang.Object)var30);
//     org.jfree.chart.renderer.xy.XYItemRenderer var43 = null;
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot(var25, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.axis.ValueAxis)var28, var43);
//     var44.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     org.jfree.chart.plot.PolarPlot var48 = new org.jfree.chart.plot.PolarPlot();
//     var48.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     java.awt.geom.Rectangle2D var54 = null;
//     org.jfree.chart.util.RectangleAnchor var55 = null;
//     java.awt.geom.Point2D var56 = org.jfree.chart.util.RectangleAnchor.coordinates(var54, var55);
//     var48.zoomDomainAxes(0.0d, (-1.0d), var53, var56);
//     var44.zoomRangeAxes(100.0d, var47, var56);
//     var19.zoomDomainAxes(0.05d, 4.0d, var24, var56);
//     
//     // Checks the contract:  equals-hashcode on var5 and var30
//     assertTrue("Contract failed: equals-hashcode on var5 and var30", var5.equals(var30) ? var5.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var5
//     assertTrue("Contract failed: equals-hashcode on var30 and var5", var30.equals(var5) ? var30.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var33
//     assertTrue("Contract failed: equals-hashcode on var8 and var33", var8.equals(var33) ? var8.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var8
//     assertTrue("Contract failed: equals-hashcode on var33 and var8", var33.equals(var8) ? var33.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var40
//     assertTrue("Contract failed: equals-hashcode on var15 and var40", var15.equals(var40) ? var15.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var15
//     assertTrue("Contract failed: equals-hashcode on var40 and var15", var40.equals(var15) ? var40.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var21.draw(var22, var23);
// 
//   }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    var11.setName("hi!");
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var17 = var16.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    var20.setLabelGap((-1.0d));
    java.lang.Object var23 = var20.clone();
    java.awt.Paint var24 = var20.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var25 = null;
    var20.setURLGenerator(var25);
    java.awt.Stroke var28 = var20.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var30 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var20.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var30);
    boolean var32 = var18.equals((java.lang.Object)var20);
    org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var33);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    java.awt.geom.Point2D var38 = null;
    var34.zoomRangeAxes(0.05d, 10.0d, var37, var38);
    var34.setDomainCrosshairValue(0.05d, false);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var34.getRangeMarkers(0, var44);
    boolean var46 = var34.isDomainZoomable();
    java.awt.Paint var47 = var34.getNoDataMessagePaint();
    var34.configureDomainAxes();
    var34.setBackgroundAlpha(100.0f);
    var34.setDomainGridlinesVisible(false);
    boolean var53 = var11.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     boolean var31 = var19.isDomainZoomable();
//     java.awt.Paint var32 = var19.getNoDataMessagePaint();
//     var19.configureDomainAxes();
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     var19.drawOutline(var34, var35);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var5 = var4.getTextAlignment();
    var1.setHorizontalAlignment(var5);
    var1.setText("");
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
    var11.setLabelGap((-1.0d));
    java.lang.Object var14 = var11.clone();
    var11.setShadowXOffset((-1.0d));
    var11.setShadowXOffset(10.0d);
    boolean var19 = var11.getSimpleLabels();
    java.awt.Stroke var20 = var11.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var11);
    org.jfree.chart.plot.Plot var22 = var21.getPlot();
    java.awt.RenderingHints var23 = var21.getRenderingHints();
    org.jfree.chart.event.ChartChangeEventType var24 = null;
    org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100, var21, var24);
    var1.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var21);
    java.util.List var27 = var21.getSubtitles();
    org.jfree.chart.event.ChartChangeListener var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.removeChangeListener(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Shape var5 = var1.getLegendItemShape();
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.lang.String var7 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "ChartEntity: tooltip = null"+ "'", var7.equals("ChartEntity: tooltip = null"));

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(100.0d, var2, var3);
    var0.centerRange((-1.0d));
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var11 = var10.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
    var14.setLabelGap((-1.0d));
    java.lang.Object var17 = var14.clone();
    java.awt.Paint var18 = var14.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var19 = null;
    var14.setURLGenerator(var19);
    java.awt.Stroke var22 = var14.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var14.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
    boolean var26 = var12.equals((java.lang.Object)var14);
    org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var27);
    org.jfree.data.Range var29 = var10.getDefaultAutoRange();
    var8.setRange(var29);
    var0.setRangeWithMargins(var29, true, false);
    java.awt.Font var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelFont(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.RectangleAnchor.coordinates(var6, var7);
//     var0.zoomDomainAxes(0.0d, (-1.0d), var5, var8);
//     org.jfree.chart.axis.TickUnit var10 = var0.getAngleTickUnit();
//     double var11 = var0.getMaxRadius();
// 
//   }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
//     boolean var21 = var19.isRangeGridlinesVisible();
//     var19.setDomainCrosshairVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     var19.handleClick(254, 4, var26);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var5 = new org.jfree.chart.block.BlockBorder(0.0d, 0.12d, (-2.0d), Double.NaN, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var0, 1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var7 = org.jfree.data.Range.expand(var0, 4.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
//     java.lang.String var2 = var1.getURLText();
//     org.jfree.chart.util.HorizontalAlignment var3 = var1.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.ColumnArrangement var7 = new org.jfree.chart.block.ColumnArrangement(var3, var4, (-1.0d), 0.0d);
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     var9.setLabelGap((-1.0d));
//     java.lang.Object var12 = var9.clone();
//     var9.setShadowXOffset((-1.0d));
//     var9.setShadowXOffset(10.0d);
//     boolean var17 = var9.getSimpleLabels();
//     java.awt.Stroke var18 = var9.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var9);
//     org.jfree.chart.plot.Plot var20 = var19.getPlot();
//     java.awt.RenderingHints var21 = var19.getRenderingHints();
//     java.awt.Color var25 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var26 = var25.getGreen();
//     var19.setBorderPaint((java.awt.Paint)var25);
//     org.jfree.chart.title.LegendTitle var28 = var19.getLegend();
//     org.jfree.chart.block.BlockContainer var29 = var28.getItemContainer();
//     var29.clear();
//     java.awt.Graphics2D var31 = null;
//     org.jfree.data.Range var32 = null;
//     org.jfree.chart.block.RectangleConstraint var34 = new org.jfree.chart.block.RectangleConstraint(var32, 100.0d);
//     org.jfree.chart.util.Size2D var35 = var7.arrange(var29, var31, var34);
// 
//   }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var1.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     java.awt.Paint var7 = null;
//     var6.setLabelShadowPaint(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     var12.setLabelGap((-1.0d));
//     java.lang.Object var15 = var12.clone();
//     java.awt.Paint var16 = var12.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var17 = null;
//     var12.setURLGenerator(var17);
//     var12.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PiePlotState var23 = var6.initialise(var9, var10, var12, (java.lang.Integer)0, var22);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.awt.Font var28 = var25.getLabelFont();
//     var12.setNoDataMessageFont(var28);
//     boolean var30 = var1.equals((java.lang.Object)var12);
//     org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle("");
//     var32.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     var36.setLabelGap((-1.0d));
//     java.awt.Font var39 = var36.getLabelFont();
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     var41.setShadowXOffset((-1.0d));
//     var41.setShadowXOffset(10.0d);
//     boolean var49 = var41.getSimpleLabels();
//     java.awt.Stroke var50 = var41.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.event.ChartProgressEvent var54 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var36, var51, 0, 0);
//     var32.addChangeListener((org.jfree.chart.event.TitleChangeListener)var51);
//     var12.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var51);
//     
//     // Checks the contract:  equals-hashcode on var25 and var36
//     assertTrue("Contract failed: equals-hashcode on var25 and var36", var25.equals(var36) ? var25.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var25
//     assertTrue("Contract failed: equals-hashcode on var36 and var25", var36.equals(var25) ? var36.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var44
//     assertTrue("Contract failed: equals-hashcode on var15 and var44", var15.equals(var44) ? var15.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var15
//     assertTrue("Contract failed: equals-hashcode on var44 and var15", var44.equals(var15) ? var44.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.plot.MultiplePiePlot var1 = new org.jfree.chart.plot.MultiplePiePlot(var0);
    org.jfree.chart.util.TableOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDataExtractOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() {}
//   public void test313() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Size2D[width=0.0, height=0.0]", var1);
// 
//   }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     java.text.DateFormat var3 = var1.getDateFormatOverride();
//     var1.setLabel("hi!");
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.axis.AxisState var12 = var1.draw(var6, 100.0d, var8, var9, var10, var11);
// 
//   }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.jfree.chart.JFreeChart var1 = null;
//     org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)(-1.0d), var1, 10, (-1));
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     var7.setLabelGap((-1.0d));
//     java.lang.Object var10 = var7.clone();
//     var7.setShadowXOffset((-1.0d));
//     var7.setShadowXOffset(10.0d);
//     boolean var15 = var7.getSimpleLabels();
//     java.awt.Stroke var16 = var7.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var17 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var7);
//     org.jfree.chart.plot.Plot var18 = var17.getPlot();
//     java.awt.RenderingHints var19 = var17.getRenderingHints();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var24 = var23.getGreen();
//     var17.setBorderPaint((java.awt.Paint)var23);
//     org.jfree.chart.title.LegendTitle var26 = var17.getLegend();
//     var4.setChart(var17);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     var29.setLabelGap((-1.0d));
//     java.lang.Object var32 = var29.clone();
//     var29.setShadowXOffset((-1.0d));
//     var29.setShadowXOffset(10.0d);
//     boolean var37 = var29.getSimpleLabels();
//     java.awt.Stroke var38 = var29.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var39 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var29);
//     org.jfree.chart.plot.Plot var40 = var39.getPlot();
//     java.awt.RenderingHints var41 = var39.getRenderingHints();
//     java.awt.Color var45 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var46 = var45.getGreen();
//     var39.setBorderPaint((java.awt.Paint)var45);
//     org.jfree.chart.title.LegendTitle var48 = var39.getLegend();
//     var4.setChart(var39);
//     
//     // Checks the contract:  equals-hashcode on var7 and var29
//     assertTrue("Contract failed: equals-hashcode on var7 and var29", var7.equals(var29) ? var7.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var7
//     assertTrue("Contract failed: equals-hashcode on var29 and var7", var29.equals(var7) ? var29.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var32
//     assertTrue("Contract failed: equals-hashcode on var10 and var32", var10.equals(var32) ? var10.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var10
//     assertTrue("Contract failed: equals-hashcode on var32 and var10", var32.equals(var10) ? var32.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var39
//     assertTrue("Contract failed: equals-hashcode on var17 and var39", var17.equals(var39) ? var17.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var17
//     assertTrue("Contract failed: equals-hashcode on var39 and var17", var39.equals(var17) ? var39.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var40
//     assertTrue("Contract failed: equals-hashcode on var18 and var40", var18.equals(var40) ? var18.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var18
//     assertTrue("Contract failed: equals-hashcode on var40 and var18", var40.equals(var18) ? var40.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     var1.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     var20.setDataset(var21);
//     org.jfree.chart.plot.PlotOrientation var23 = var20.getOrientation();
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     java.awt.Paint var26 = null;
//     var25.setLabelShadowPaint(var26);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     var31.setLabelGap((-1.0d));
//     java.lang.Object var34 = var31.clone();
//     java.awt.Paint var35 = var31.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var36 = null;
//     var31.setURLGenerator(var36);
//     var31.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.chart.plot.PiePlotState var42 = var25.initialise(var28, var29, var31, (java.lang.Integer)0, var41);
//     org.jfree.chart.urls.PieURLGenerator var43 = var25.getLegendLabelURLGenerator();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var46 = var45.getPercentFormat();
//     var25.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var45);
//     java.awt.Stroke var48 = var25.getLabelOutlineStroke();
//     var20.setAngleGridlineStroke(var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var34
//     assertTrue("Contract failed: equals-hashcode on var6 and var34", var6.equals(var34) ? var6.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var6
//     assertTrue("Contract failed: equals-hashcode on var34 and var6", var34.equals(var6) ? var34.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var45
//     assertTrue("Contract failed: equals-hashcode on var13 and var45", var13.equals(var45) ? var13.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var13
//     assertTrue("Contract failed: equals-hashcode on var45 and var13", var45.equals(var13) ? var45.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setTickMarkOutsideLength(1.0f);
    float var3 = var0.getTickMarkOutsideLength();
    java.awt.Color var7 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    java.awt.geom.AffineTransform var11 = null;
    java.awt.RenderingHints var12 = null;
    java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
    java.lang.String var14 = var7.toString();
    float[] var15 = null;
    float[] var16 = var7.getRGBComponents(var15);
    var0.setAxisLinePaint((java.awt.Paint)var7);
    java.awt.Color var18 = var7.brighter();
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    java.awt.Paint var21 = null;
    var20.setLabelShadowPaint(var21);
    java.awt.Graphics2D var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.lang.Object var29 = var26.clone();
    java.awt.Paint var30 = var26.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var31 = null;
    var26.setURLGenerator(var31);
    var26.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.PiePlotState var37 = var20.initialise(var23, var24, var26, (java.lang.Integer)0, var36);
    org.jfree.data.general.PieDataset var38 = null;
    org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
    var39.setLabelGap((-1.0d));
    java.awt.Font var42 = var39.getLabelFont();
    var26.setNoDataMessageFont(var42);
    boolean var44 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var18, (java.lang.Object)var42);
    int var45 = var18.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var14.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 255);

  }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("poly", var1, (-1.0f), (-1.0f), var6, 10.0d, 0.5f, 1.0f);
// 
//   }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, (java.lang.Comparable)0.14d);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    var11.setName("hi!");
    org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis();
    var15.setUpperMargin(1.0d);
    boolean var18 = var15.isTickMarksVisible();
    boolean var19 = var11.equals((java.lang.Object)var15);
    java.text.NumberFormat var20 = var15.getNumberFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     double var17 = var1.getAutoRangeMinimumSize();
//     org.jfree.chart.renderer.PolarItemRenderer var18 = null;
//     org.jfree.chart.plot.PolarPlot var19 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var18);
//     org.jfree.data.xy.XYDataset var21 = null;
//     org.jfree.chart.axis.NumberAxis3D var22 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var23 = var22.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.lang.Object var29 = var26.clone();
//     java.awt.Paint var30 = var26.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var31 = null;
//     var26.setURLGenerator(var31);
//     java.awt.Stroke var34 = var26.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var36 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var26.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var36);
//     boolean var38 = var24.equals((java.lang.Object)var26);
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot(var21, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.axis.ValueAxis)var24, var39);
//     var40.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var43 = null;
//     var40.setRangeAxisLocation(4, var43, false);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var40);
//     var40.setBackgroundAlpha(1.0f);
//     java.awt.Stroke var49 = var40.getRangeZeroBaselineStroke();
//     var1.setPlot((org.jfree.chart.plot.Plot)var40);
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var3
//     assertTrue("Contract failed: equals-hashcode on var26 and var3", var26.equals(var3) ? var26.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var29
//     assertTrue("Contract failed: equals-hashcode on var6 and var29", var6.equals(var29) ? var6.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var6
//     assertTrue("Contract failed: equals-hashcode on var29 and var6", var29.equals(var6) ? var29.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var36
//     assertTrue("Contract failed: equals-hashcode on var13 and var36", var13.equals(var36) ? var13.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var13
//     assertTrue("Contract failed: equals-hashcode on var36 and var13", var36.equals(var13) ? var36.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    java.lang.String var1 = var0.toString();
    java.lang.Object var2 = null;
    boolean var3 = var0.equals(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Size2D[width=0.0, height=0.0]"+ "'", var1.equals("Size2D[width=0.0, height=0.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var3 = var2.toUnconstrainedWidth();
//     double var4 = var2.getWidth();
//     org.jfree.chart.util.Size2D var5 = new org.jfree.chart.util.Size2D();
//     org.jfree.chart.JFreeChart var6 = null;
//     org.jfree.chart.event.ChartChangeEvent var7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5, var6);
//     boolean var9 = var5.equals((java.lang.Object)(short)(-1));
//     double var10 = var5.getWidth();
//     org.jfree.chart.util.ObjectList var11 = new org.jfree.chart.util.ObjectList();
//     boolean var12 = var5.equals((java.lang.Object)var11);
//     org.jfree.chart.util.Size2D var13 = var2.calculateConstrainedSize(var5);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainMarkers();
    int var21 = var19.getDomainAxisCount();
    org.jfree.chart.annotations.XYAnnotation var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.addAnnotation(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     var0.configure();
//     double var16 = var0.getAutoRangeMinimumSize();
//     boolean var17 = var0.getAutoRangeIncludesZero();
//     org.jfree.chart.axis.NumberAxis3D var19 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
//     var21.setLabelGap((-1.0d));
//     java.lang.Object var24 = var21.clone();
//     java.awt.Paint var25 = var21.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var26 = null;
//     var21.setURLGenerator(var26);
//     java.awt.Stroke var29 = var21.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var21.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var31);
//     boolean var33 = var19.equals((java.lang.Object)var21);
//     java.awt.Color var37 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var38 = null;
//     java.awt.Rectangle var39 = null;
//     java.awt.geom.Rectangle2D var40 = null;
//     java.awt.geom.AffineTransform var41 = null;
//     java.awt.RenderingHints var42 = null;
//     java.awt.PaintContext var43 = var37.createContext(var38, var39, var40, var41, var42);
//     java.awt.color.ColorSpace var44 = var37.getColorSpace();
//     var21.setNoDataMessagePaint((java.awt.Paint)var37);
//     org.jfree.chart.block.LineBorder var46 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var47 = var46.getPaint();
//     java.awt.Stroke var48 = var46.getStroke();
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var37, var48);
//     var0.setTickMarkStroke(var48);
//     
//     // Checks the contract:  equals-hashcode on var5 and var24
//     assertTrue("Contract failed: equals-hashcode on var5 and var24", var5.equals(var24) ? var5.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var5
//     assertTrue("Contract failed: equals-hashcode on var24 and var5", var24.equals(var5) ? var24.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var31
//     assertTrue("Contract failed: equals-hashcode on var12 and var31", var12.equals(var31) ? var12.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var12
//     assertTrue("Contract failed: equals-hashcode on var31 and var12", var31.equals(var12) ? var31.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.chart.axis.DateTickMarkPosition var2 = var1.getTickMarkPosition();
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var7 = var6.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var10.setURLGenerator(var15);
//     java.awt.Stroke var18 = var10.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     boolean var22 = var8.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(100);
//     boolean var27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var26);
//     java.lang.String var28 = var26.toString();
//     double var29 = var1.java2DToValue((-2.0d), var4, var26);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("Range[1.0E-8,1.0E-8]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    java.awt.Paint var19 = var1.getLabelOutlinePaint();
    var1.setSimpleLabels(true);
    java.awt.Stroke var22 = var1.getLabelOutlineStroke();
    var1.setExplodePercent((java.lang.Comparable)(-2.0d), (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     var7.setLabelGap((-1.0d));
//     java.lang.Object var10 = var7.clone();
//     java.awt.Paint var11 = var7.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var12 = null;
//     var7.setURLGenerator(var12);
//     var7.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
//     java.awt.Paint var19 = var1.getLabelOutlinePaint();
//     var1.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Paint var24 = null;
//     var23.setLabelShadowPaint(var24);
//     java.awt.Paint var26 = var23.getLabelOutlinePaint();
//     var1.setOutlinePaint(var26);
//     boolean var28 = var1.isCircular();
//     org.jfree.data.xy.XYDataset var29 = null;
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var31 = var30.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     var34.setLabelGap((-1.0d));
//     java.lang.Object var37 = var34.clone();
//     java.awt.Paint var38 = var34.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var39 = null;
//     var34.setURLGenerator(var39);
//     java.awt.Stroke var42 = var34.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var44 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var34.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var44);
//     boolean var46 = var32.equals((java.lang.Object)var34);
//     org.jfree.chart.renderer.xy.XYItemRenderer var47 = null;
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot(var29, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.axis.ValueAxis)var32, var47);
//     var48.clearDomainAxes();
//     var48.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var51 = null;
//     int var52 = var48.indexOf(var51);
//     org.jfree.chart.axis.AxisLocation var53 = var48.getDomainAxisLocation();
//     java.awt.Color var57 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var58 = null;
//     java.awt.Rectangle var59 = null;
//     java.awt.geom.Rectangle2D var60 = null;
//     java.awt.geom.AffineTransform var61 = null;
//     java.awt.RenderingHints var62 = null;
//     java.awt.PaintContext var63 = var57.createContext(var58, var59, var60, var61, var62);
//     var48.setDomainZeroBaselinePaint((java.awt.Paint)var57);
//     var1.setLabelShadowPaint((java.awt.Paint)var57);
//     
//     // Checks the contract:  equals-hashcode on var10 and var37
//     assertTrue("Contract failed: equals-hashcode on var10 and var37", var10.equals(var37) ? var10.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var10
//     assertTrue("Contract failed: equals-hashcode on var37 and var10", var37.equals(var10) ? var37.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("");
//     var1.removeFragment(var3);
//     org.jfree.chart.text.TextFragment var5 = var1.getFirstTextFragment();
//     java.awt.Font var6 = var5.getFont();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var5.calculateDimensions(var7);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setLabelGap((-1.0d));
    java.lang.Object var5 = var2.clone();
    java.awt.Paint var6 = var2.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var7 = null;
    var2.setURLGenerator(var7);
    java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    boolean var14 = var0.equals((java.lang.Object)var2);
    var0.configure();
    double var16 = var0.getLowerMargin();
    boolean var17 = var0.getAutoRangeIncludesZero();
    java.lang.String var18 = var0.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     java.awt.Paint var3 = null;
//     var2.setLabelShadowPaint(var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setLabelGap((-1.0d));
//     java.lang.Object var11 = var8.clone();
//     java.awt.Paint var12 = var8.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var13 = null;
//     var8.setURLGenerator(var13);
//     var8.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     org.jfree.chart.plot.PiePlotState var19 = var2.initialise(var5, var6, var8, (java.lang.Integer)0, var18);
//     java.awt.Paint var20 = var2.getLabelOutlinePaint();
//     var2.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     java.awt.Paint var25 = null;
//     var24.setLabelShadowPaint(var25);
//     java.awt.Paint var27 = var24.getLabelOutlinePaint();
//     var2.setOutlinePaint(var27);
//     var0.setAngleGridlinePaint(var27);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
//     var31.setLabelGap((-1.0d));
//     java.lang.Object var34 = var31.clone();
//     java.awt.Paint var35 = var31.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var36 = null;
//     var31.setURLGenerator(var36);
//     java.awt.Paint var38 = var31.getLabelOutlinePaint();
//     var0.setRadiusGridlinePaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var11 and var34
//     assertTrue("Contract failed: equals-hashcode on var11 and var34", var11.equals(var34) ? var11.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var11
//     assertTrue("Contract failed: equals-hashcode on var34 and var11", var34.equals(var11) ? var34.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var4 = var3.getPercentFormat();
//     var1.setNumberFormatOverride(var4);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var8 = var7.getPercentFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var9 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("ChartEntity: tooltip = null", var4, var8);
//     
//     // Checks the contract:  equals-hashcode on var3 and var7
//     assertTrue("Contract failed: equals-hashcode on var3 and var7", var3.equals(var7) ? var3.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var3
//     assertTrue("Contract failed: equals-hashcode on var7 and var3", var7.equals(var3) ? var7.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     var20.clearDomainMarkers();
//     boolean var23 = var20.isDomainGridlinesVisible();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var26 = var25.getTextAlignment();
//     var25.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets();
//     var25.setPadding(var29);
//     double var32 = var29.trimHeight(0.05d);
//     var20.setInsets(var29, true);
//     java.awt.Font var35 = var20.getNoDataMessageFont();
//     org.jfree.chart.axis.NumberAxis3D var37 = new org.jfree.chart.axis.NumberAxis3D();
//     var37.setTickMarkOutsideLength(1.0f);
//     float var40 = var37.getTickMarkOutsideLength();
//     java.awt.Color var44 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     java.awt.geom.AffineTransform var48 = null;
//     java.awt.RenderingHints var49 = null;
//     java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
//     java.lang.String var51 = var44.toString();
//     float[] var52 = null;
//     float[] var53 = var44.getRGBComponents(var52);
//     var37.setAxisLinePaint((java.awt.Paint)var44);
//     java.awt.Color var55 = var44.brighter();
//     org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var57 = var56.getPaint();
//     java.awt.Stroke var58 = var56.getStroke();
//     org.jfree.chart.plot.ValueMarker var59 = new org.jfree.chart.plot.ValueMarker(10.0d, (java.awt.Paint)var55, var58);
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.text.G2TextMeasurer var62 = new org.jfree.chart.text.G2TextMeasurer(var61);
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("PlotOrientation.HORIZONTAL", var35, (java.awt.Paint)var55, 0.0f, (org.jfree.chart.text.TextMeasurer)var62);
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.clearDomainMarkers();
    boolean var22 = var19.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var24 = var19.getRangeAxisLocation(15);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    java.awt.Shape var28 = var27.getLeftArrow();
    java.lang.String var29 = var27.getLabel();
    var27.zoomRange(0.08d, 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setDomainAxis((-1), (org.jfree.chart.axis.ValueAxis)var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "org.jfree.chart.event.ChartProgressEvent[source=-1.0]"+ "'", var29.equals("org.jfree.chart.event.ChartProgressEvent[source=-1.0]"));

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var35 = var19.getRootPlot();
//     var19.setNoDataMessage("poly");
//     org.jfree.data.xy.XYDataset var38 = null;
//     org.jfree.chart.axis.NumberAxis3D var39 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var40 = var39.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var41 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     var43.setLabelGap((-1.0d));
//     java.lang.Object var46 = var43.clone();
//     java.awt.Paint var47 = var43.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var48 = null;
//     var43.setURLGenerator(var48);
//     java.awt.Stroke var51 = var43.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var53 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var43.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var53);
//     boolean var55 = var41.equals((java.lang.Object)var43);
//     org.jfree.chart.renderer.xy.XYItemRenderer var56 = null;
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot(var38, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.axis.ValueAxis)var41, var56);
//     org.jfree.chart.plot.PlotRenderingInfo var60 = null;
//     java.awt.geom.Point2D var61 = null;
//     var57.zoomRangeAxes(0.05d, 10.0d, var60, var61);
//     org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var65 = var64.getLabelPaint();
//     org.jfree.chart.util.RectangleInsets var66 = new org.jfree.chart.util.RectangleInsets();
//     double var68 = var66.calculateRightOutset(10.0d);
//     var64.setLabelOffset(var66);
//     java.awt.Stroke var70 = var64.getStroke();
//     org.jfree.chart.util.Layer var71 = null;
//     var57.addRangeMarker((org.jfree.chart.plot.Marker)var64, var71);
//     java.awt.Stroke var73 = var64.getStroke();
//     var19.addDomainMarker((org.jfree.chart.plot.Marker)var64);
//     
//     // Checks the contract:  equals-hashcode on var5 and var43
//     assertTrue("Contract failed: equals-hashcode on var5 and var43", var5.equals(var43) ? var5.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var5
//     assertTrue("Contract failed: equals-hashcode on var43 and var5", var43.equals(var5) ? var43.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var46
//     assertTrue("Contract failed: equals-hashcode on var8 and var46", var8.equals(var46) ? var8.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var8
//     assertTrue("Contract failed: equals-hashcode on var46 and var8", var46.equals(var8) ? var46.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var53
//     assertTrue("Contract failed: equals-hashcode on var15 and var53", var15.equals(var53) ? var15.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var15
//     assertTrue("Contract failed: equals-hashcode on var53 and var15", var53.equals(var15) ? var53.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     java.awt.Paint var2 = null;
//     var1.setLabelShadowPaint(var2);
//     java.awt.Paint var4 = var1.getLabelOutlinePaint();
//     var1.setBackgroundImageAlignment(10);
//     org.jfree.data.general.PieDataset var7 = null;
//     org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
//     var8.setLabelGap((-1.0d));
//     java.lang.Object var11 = var8.clone();
//     var8.setShadowXOffset((-1.0d));
//     var8.setShadowXOffset(10.0d);
//     boolean var16 = var8.getSimpleLabels();
//     java.awt.Stroke var17 = var8.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var18 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.plot.Plot var19 = var18.getPlot();
//     java.awt.RenderingHints var20 = var18.getRenderingHints();
//     var1.addChangeListener((org.jfree.chart.event.PlotChangeListener)var18);
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     java.awt.Paint var24 = null;
//     var23.setLabelShadowPaint(var24);
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
//     var29.setLabelGap((-1.0d));
//     java.lang.Object var32 = var29.clone();
//     java.awt.Paint var33 = var29.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var34 = null;
//     var29.setURLGenerator(var34);
//     var29.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.plot.PiePlotState var40 = var23.initialise(var26, var27, var29, (java.lang.Integer)0, var39);
//     org.jfree.chart.urls.PieURLGenerator var41 = var23.getLegendLabelURLGenerator();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var44 = var43.getPercentFormat();
//     var23.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var43);
//     java.awt.Stroke var46 = var23.getLabelOutlineStroke();
//     var18.setBorderStroke(var46);
//     
//     // Checks the contract:  equals-hashcode on var11 and var32
//     assertTrue("Contract failed: equals-hashcode on var11 and var32", var11.equals(var32) ? var11.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var11
//     assertTrue("Contract failed: equals-hashcode on var32 and var11", var32.equals(var11) ? var32.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var2 = var1.getLabelFont();
    java.awt.Color var7 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    java.awt.geom.AffineTransform var11 = null;
    java.awt.RenderingHints var12 = null;
    java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
    java.lang.String var14 = var7.toString();
    float[] var15 = null;
    float[] var16 = var7.getRGBComponents(var15);
    int var17 = var7.getBlue();
    java.awt.Color var18 = java.awt.Color.getColor("hi!", var7);
    org.jfree.chart.text.TextFragment var20 = new org.jfree.chart.text.TextFragment("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var2, (java.awt.Paint)var7, 10.0f);
    int var21 = var7.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var14.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 254);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-2));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
//     java.lang.String var22 = var21.toString();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     var24.setLabelGap((-1.0d));
//     java.lang.Object var27 = var24.clone();
//     var24.setShadowXOffset((-1.0d));
//     var24.setShadowXOffset(10.0d);
//     boolean var32 = var24.getSimpleLabels();
//     java.awt.Stroke var33 = var24.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     boolean var35 = var21.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.plot.AbstractPieLabelDistributor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelDistributor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.awt.Font var4 = var1.getLabelFont();
    boolean var5 = var1.isOutlineVisible();
    var1.zoom((-1.95d));
    java.awt.Color var12 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var13 = null;
    java.awt.Rectangle var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    java.awt.geom.AffineTransform var16 = null;
    java.awt.RenderingHints var17 = null;
    java.awt.PaintContext var18 = var12.createContext(var13, var14, var15, var16, var17);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
    var20.setLabelGap((-1.0d));
    java.awt.Stroke var23 = var20.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var26 = var25.getTextAlignment();
    var25.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var29 = new org.jfree.chart.util.RectangleInsets();
    var25.setPadding(var29);
    org.jfree.chart.block.LineBorder var31 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var12, var23, var29);
    java.awt.color.ColorSpace var32 = var12.getColorSpace();
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var12);
    var1.setSectionOutlinePaint((java.lang.Comparable)100, (java.awt.Paint)var12);
    java.awt.Stroke var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStroke(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var8 = var7.getTextAlignment();
//     var7.setHeight(1.0d);
//     double var11 = var7.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var12 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var13 = var12.getLabelFont();
//     boolean var14 = var7.equals((java.lang.Object)var13);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.PiePlot var16 = new org.jfree.chart.plot.PiePlot(var15);
//     java.awt.Paint var17 = null;
//     var16.setLabelShadowPaint(var17);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.data.general.PieDataset var21 = null;
//     org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
//     var22.setLabelGap((-1.0d));
//     java.lang.Object var25 = var22.clone();
//     java.awt.Paint var26 = var22.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var27 = null;
//     var22.setURLGenerator(var27);
//     var22.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     org.jfree.chart.plot.PiePlotState var33 = var16.initialise(var19, var20, var22, (java.lang.Integer)0, var32);
//     java.awt.Paint var34 = var16.getLabelOutlinePaint();
//     var16.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     java.awt.Paint var39 = null;
//     var38.setLabelShadowPaint(var39);
//     java.awt.Paint var41 = var38.getLabelOutlinePaint();
//     var16.setOutlinePaint(var41);
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var13, var41);
//     var1.setLabelShadowPaint(var41);
//     var1.setPieIndex(10);
//     org.jfree.chart.util.RectangleInsets var47 = var1.getSimpleLabelOffset();
//     java.awt.Graphics2D var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     var1.drawOutline(var48, var49);
// 
//   }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var2.createOutsetRectangle(var3, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var27 = var26.getLabelPaint();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     double var30 = var28.calculateRightOutset(10.0d);
//     var26.setLabelOffset(var28);
//     java.awt.Stroke var32 = var26.getStroke();
//     org.jfree.chart.util.Layer var33 = null;
//     var19.addRangeMarker((org.jfree.chart.plot.Marker)var26, var33);
//     java.awt.Stroke var35 = var26.getStroke();
//     java.lang.Object var36 = var26.clone();
//     org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var39 = var38.getLabelTextAnchor();
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     var42.setLabelGap((-1.0d));
//     java.lang.Object var45 = var42.clone();
//     java.awt.Paint var46 = var42.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var42.setURLGenerator(var47);
//     java.awt.Stroke var50 = var42.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var52 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var42.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var52);
//     boolean var54 = var40.equals((java.lang.Object)var42);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var59 = null;
//     java.awt.Rectangle var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     java.awt.geom.AffineTransform var62 = null;
//     java.awt.RenderingHints var63 = null;
//     java.awt.PaintContext var64 = var58.createContext(var59, var60, var61, var62, var63);
//     java.awt.color.ColorSpace var65 = var58.getColorSpace();
//     var42.setNoDataMessagePaint((java.awt.Paint)var58);
//     boolean var67 = var39.equals((java.lang.Object)var42);
//     var26.setLabelTextAnchor(var39);
//     
//     // Checks the contract:  equals-hashcode on var8 and var45
//     assertTrue("Contract failed: equals-hashcode on var8 and var45", var8.equals(var45) ? var8.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var8
//     assertTrue("Contract failed: equals-hashcode on var45 and var8", var45.equals(var8) ? var45.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var52
//     assertTrue("Contract failed: equals-hashcode on var15 and var52", var15.equals(var52) ? var15.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var15
//     assertTrue("Contract failed: equals-hashcode on var52 and var15", var52.equals(var15) ? var52.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     int var28 = var19.getDomainAxisCount();
//     var19.setRangeCrosshairLockedOnData(true);
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var33 = var32.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     var36.setLabelGap((-1.0d));
//     java.lang.Object var39 = var36.clone();
//     java.awt.Paint var40 = var36.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var41 = null;
//     var36.setURLGenerator(var41);
//     java.awt.Stroke var44 = var36.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var46 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var36.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var46);
//     boolean var48 = var34.equals((java.lang.Object)var36);
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.axis.ValueAxis)var34, var49);
//     var50.clearDomainAxes();
//     org.jfree.chart.plot.DatasetRenderingOrder var52 = var50.getDatasetRenderingOrder();
//     var19.setDatasetRenderingOrder(var52);
//     
//     // Checks the contract:  equals-hashcode on var5 and var36
//     assertTrue("Contract failed: equals-hashcode on var5 and var36", var5.equals(var36) ? var5.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var5
//     assertTrue("Contract failed: equals-hashcode on var36 and var5", var36.equals(var5) ? var36.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var39
//     assertTrue("Contract failed: equals-hashcode on var8 and var39", var8.equals(var39) ? var8.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var8
//     assertTrue("Contract failed: equals-hashcode on var39 and var8", var39.equals(var8) ? var39.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var46
//     assertTrue("Contract failed: equals-hashcode on var15 and var46", var15.equals(var46) ? var15.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var15
//     assertTrue("Contract failed: equals-hashcode on var46 and var15", var46.equals(var15) ? var46.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(254);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     org.jfree.data.xy.XYDataset var22 = null;
//     int var23 = var19.indexOf(var22);
//     org.jfree.chart.axis.AxisLocation var24 = var19.getDomainAxisLocation();
//     java.awt.Color var28 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var29 = null;
//     java.awt.Rectangle var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     java.awt.geom.AffineTransform var32 = null;
//     java.awt.RenderingHints var33 = null;
//     java.awt.PaintContext var34 = var28.createContext(var29, var30, var31, var32, var33);
//     var19.setDomainZeroBaselinePaint((java.awt.Paint)var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
//     var19.setRenderer(0, var37, false);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.data.xy.XYDataset var42 = null;
//     org.jfree.chart.axis.NumberAxis3D var43 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var44 = var43.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var45 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var46 = null;
//     org.jfree.chart.plot.PiePlot var47 = new org.jfree.chart.plot.PiePlot(var46);
//     var47.setLabelGap((-1.0d));
//     java.lang.Object var50 = var47.clone();
//     java.awt.Paint var51 = var47.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var52 = null;
//     var47.setURLGenerator(var52);
//     java.awt.Stroke var55 = var47.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var57 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var47.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var57);
//     boolean var59 = var45.equals((java.lang.Object)var47);
//     org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot(var42, (org.jfree.chart.axis.ValueAxis)var43, (org.jfree.chart.axis.ValueAxis)var45, var60);
//     org.jfree.chart.plot.PlotRenderingInfo var64 = null;
//     java.awt.geom.Point2D var65 = null;
//     var61.zoomRangeAxes(0.05d, 10.0d, var64, var65);
//     var61.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var71 = null;
//     java.util.Collection var72 = var61.getRangeMarkers(0, var71);
//     boolean var73 = var61.isDomainZoomable();
//     java.awt.Paint var74 = var61.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     org.jfree.chart.plot.PolarPlot var77 = new org.jfree.chart.plot.PolarPlot();
//     var77.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var82 = null;
//     java.awt.geom.Rectangle2D var83 = null;
//     org.jfree.chart.util.RectangleAnchor var84 = null;
//     java.awt.geom.Point2D var85 = org.jfree.chart.util.RectangleAnchor.coordinates(var83, var84);
//     var77.zoomDomainAxes(0.0d, (-1.0d), var82, var85);
//     var61.zoomRangeAxes((-1.0d), var76, var85);
//     org.jfree.chart.plot.PlotState var88 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var89 = null;
//     var19.draw(var40, var41, var85, var88, var89);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartChangeEvent var2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var1);
    boolean var4 = var0.equals((java.lang.Object)(short)(-1));
    double var5 = var0.getWidth();
    org.jfree.chart.util.ObjectList var6 = new org.jfree.chart.util.ObjectList();
    boolean var7 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.block.BlockParams var8 = new org.jfree.chart.block.BlockParams();
    var8.setTranslateY(100.0d);
    boolean var11 = var8.getGenerateEntities();
    boolean var12 = var0.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearAnnotations();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var24 = var23.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var32 = null;
//     var27.setURLGenerator(var32);
//     java.awt.Stroke var35 = var27.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var27.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     boolean var39 = var25.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var40);
//     var41.clearDomainAxes();
//     var41.clearDomainMarkers();
//     boolean var44 = var41.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var46 = var41.getRangeAxisLocation(15);
//     var19.setDomainAxisLocation(254, var46, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var27
//     assertTrue("Contract failed: equals-hashcode on var5 and var27", var5.equals(var27) ? var5.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var5
//     assertTrue("Contract failed: equals-hashcode on var27 and var5", var27.equals(var5) ? var27.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var15
//     assertTrue("Contract failed: equals-hashcode on var37 and var15", var37.equals(var15) ? var37.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var19
//     assertTrue("Contract failed: equals-hashcode on var41 and var19", var41.equals(var19) ? var41.hashCode() == var19.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var41 and var19.", var41.equals(var19) == var19.equals(var41));
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    var54.setWeight(0);
    org.jfree.chart.util.SortOrder var72 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.setColumnRenderingOrder(var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     var11.clearSubtitles();
//     float var22 = var11.getBackgroundImageAlpha();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var26 = var25.getTextAlignment();
//     var25.setHeight(1.0d);
//     double var29 = var25.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var31 = var30.getLabelFont();
//     boolean var32 = var25.equals((java.lang.Object)var31);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     var40.setLabelGap((-1.0d));
//     java.lang.Object var43 = var40.clone();
//     java.awt.Paint var44 = var40.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var45 = null;
//     var40.setURLGenerator(var45);
//     var40.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.chart.plot.PiePlotState var51 = var34.initialise(var37, var38, var40, (java.lang.Integer)0, var50);
//     java.awt.Paint var52 = var34.getLabelOutlinePaint();
//     var34.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var55 = null;
//     org.jfree.chart.plot.PiePlot var56 = new org.jfree.chart.plot.PiePlot(var55);
//     java.awt.Paint var57 = null;
//     var56.setLabelShadowPaint(var57);
//     java.awt.Paint var59 = var56.getLabelOutlinePaint();
//     var34.setOutlinePaint(var59);
//     org.jfree.chart.text.TextLine var61 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var31, var59);
//     var11.setBorderPaint(var59);
//     
//     // Checks the contract:  equals-hashcode on var4 and var43
//     assertTrue("Contract failed: equals-hashcode on var4 and var43", var4.equals(var43) ? var4.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var4
//     assertTrue("Contract failed: equals-hashcode on var43 and var4", var43.equals(var4) ? var43.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.axis.AxisState var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.data.xy.XYDataset var5 = null;
//     org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var7 = var6.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var8 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var15 = null;
//     var10.setURLGenerator(var15);
//     java.awt.Stroke var18 = var10.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var20 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var10.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var20);
//     boolean var22 = var8.equals((java.lang.Object)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot(var5, (org.jfree.chart.axis.ValueAxis)var6, (org.jfree.chart.axis.ValueAxis)var8, var23);
//     org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge(100);
//     boolean var27 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var26);
//     java.util.List var28 = var1.refreshTicks(var2, var3, var4, var26);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("", var1, var2, var3);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.CategoryMarker var55 = null;
    org.jfree.chart.util.Layer var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.addDomainMarker(var55, var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.data.Range var20 = var1.getDefaultAutoRange();
//     var1.setAutoTickUnitSelection(false);
//     org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.util.RectangleEdge var26 = null;
//     double var27 = var23.java2DToValue(100.0d, var25, var26);
//     var23.setUpperMargin(10.0d);
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var34 = var33.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     var37.setLabelGap((-1.0d));
//     java.lang.Object var40 = var37.clone();
//     java.awt.Paint var41 = var37.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var42 = null;
//     var37.setURLGenerator(var42);
//     java.awt.Stroke var45 = var37.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var47 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var37.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var47);
//     boolean var49 = var35.equals((java.lang.Object)var37);
//     org.jfree.chart.renderer.xy.XYItemRenderer var50 = null;
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot(var32, (org.jfree.chart.axis.ValueAxis)var33, (org.jfree.chart.axis.ValueAxis)var35, var50);
//     org.jfree.data.Range var52 = var33.getDefaultAutoRange();
//     var31.setRange(var52);
//     org.jfree.data.Range var56 = org.jfree.data.Range.shift(var52, (-1.95d), true);
//     var23.setRangeWithMargins(var52, false, false);
//     org.jfree.data.Range var62 = org.jfree.data.Range.expand(var52, 0.08d, 0.0d);
//     var1.setRangeWithMargins(var62, true, false);
//     
//     // Checks the contract:  equals-hashcode on var5 and var37
//     assertTrue("Contract failed: equals-hashcode on var5 and var37", var5.equals(var37) ? var5.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var5
//     assertTrue("Contract failed: equals-hashcode on var37 and var5", var37.equals(var5) ? var37.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var40
//     assertTrue("Contract failed: equals-hashcode on var8 and var40", var8.equals(var40) ? var8.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var8
//     assertTrue("Contract failed: equals-hashcode on var40 and var8", var40.equals(var8) ? var40.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var47
//     assertTrue("Contract failed: equals-hashcode on var15 and var47", var15.equals(var47) ? var15.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var15
//     assertTrue("Contract failed: equals-hashcode on var47 and var15", var47.equals(var15) ? var47.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     java.awt.Paint var7 = var1.getBaseSectionOutlinePaint();
//     java.lang.Comparable var8 = null;
//     double var9 = var1.getExplodePercent(var8);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.mapDatasetToRangeAxis(4, 100);
    var19.setRangeCrosshairVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     boolean var22 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getRangeAxisLocation(15);
//     org.jfree.chart.plot.PlotOrientation var25 = var19.getOrientation();
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     double var28 = var26.calculateRightOutset(10.0d);
//     double var30 = var26.calculateBottomOutset((-1.0d));
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     var31.setTickMarkOutsideLength(1.0f);
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     java.awt.Paint var36 = null;
//     var35.setLabelShadowPaint(var36);
//     java.awt.Graphics2D var38 = null;
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     java.awt.Paint var45 = var41.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var46 = null;
//     var41.setURLGenerator(var46);
//     var41.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     org.jfree.chart.plot.PiePlotState var52 = var35.initialise(var38, var39, var41, (java.lang.Integer)0, var51);
//     java.awt.Paint var53 = var35.getLabelOutlinePaint();
//     var31.setAxisLinePaint(var53);
//     org.jfree.chart.block.BlockBorder var55 = new org.jfree.chart.block.BlockBorder(var26, var53);
//     double var57 = var26.trimWidth(0.05d);
//     double var58 = var26.getRight();
//     var19.setAxisOffset(var26);
//     
//     // Checks the contract:  equals-hashcode on var8 and var44
//     assertTrue("Contract failed: equals-hashcode on var8 and var44", var8.equals(var44) ? var8.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var8
//     assertTrue("Contract failed: equals-hashcode on var44 and var8", var44.equals(var8) ? var44.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets();
    var1.setPadding(var5);
    java.lang.Object var7 = var1.clone();
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var10 = var9.getTextAlignment();
    var9.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var13 = new org.jfree.chart.util.RectangleInsets();
    var9.setPadding(var13);
    var1.setMargin(var13);
    double var17 = var13.trimHeight(0.0d);
    java.awt.geom.Rectangle2D var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var21 = var13.createInsetRectangle(var18, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-2.0d));

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var12 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    var6.addOptionalLibrary((org.jfree.chart.ui.Library)var12);
    var12.setName("hi!");
    java.lang.String var16 = var12.getInfo();
    boolean var17 = var0.equals((java.lang.Object)var12);
    var12.setName("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.ui.BasicProjectInfo var24 = new org.jfree.chart.ui.BasicProjectInfo("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "", "", "java.awt.Color[r=255,g=255,b=254]");
    var12.addLibrary((org.jfree.chart.ui.Library)var24);
    var24.setInfo("Range[1.0E-8,1.0E-8]");
    java.lang.String var28 = var24.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + ""+ "'", var16.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "Range[1.0E-8,1.0E-8]"+ "'", var28.equals("Range[1.0E-8,1.0E-8]"));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    float var1 = var0.getTickMarkOutsideLength();
    boolean var2 = var0.isInverted();
    org.jfree.chart.util.RectangleInsets var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelInsets(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.awt.Font var4 = var1.getLabelFont();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     var6.setShadowXOffset((-1.0d));
//     var6.setShadowXOffset(10.0d);
//     boolean var14 = var6.getSimpleLabels();
//     java.awt.Stroke var15 = var6.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.event.ChartProgressEvent var19 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var1, var16, 0, 0);
//     org.jfree.chart.title.TextTitle var21 = new org.jfree.chart.title.TextTitle("");
//     var21.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
//     var25.setLabelGap((-1.0d));
//     java.awt.Font var28 = var25.getLabelFont();
//     org.jfree.data.general.PieDataset var29 = null;
//     org.jfree.chart.plot.PiePlot var30 = new org.jfree.chart.plot.PiePlot(var29);
//     var30.setLabelGap((-1.0d));
//     java.lang.Object var33 = var30.clone();
//     var30.setShadowXOffset((-1.0d));
//     var30.setShadowXOffset(10.0d);
//     boolean var38 = var30.getSimpleLabels();
//     java.awt.Stroke var39 = var30.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var40 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var30);
//     org.jfree.chart.event.ChartProgressEvent var43 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var25, var40, 0, 0);
//     var21.addChangeListener((org.jfree.chart.event.TitleChangeListener)var40);
//     var40.fireChartChanged();
//     boolean var46 = var40.getAntiAlias();
//     var19.setChart(var40);
//     
//     // Checks the contract:  equals-hashcode on var1 and var25
//     assertTrue("Contract failed: equals-hashcode on var1 and var25", var1.equals(var25) ? var1.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var1
//     assertTrue("Contract failed: equals-hashcode on var25 and var1", var25.equals(var1) ? var25.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var33
//     assertTrue("Contract failed: equals-hashcode on var9 and var33", var9.equals(var33) ? var9.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var9
//     assertTrue("Contract failed: equals-hashcode on var33 and var9", var33.equals(var9) ? var33.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var40
//     assertTrue("Contract failed: equals-hashcode on var16 and var40", var16.equals(var40) ? var16.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var16
//     assertTrue("Contract failed: equals-hashcode on var40 and var16", var40.equals(var16) ? var40.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.event.MarkerChangeEvent var59 = null;
//     var57.notifyListeners(var59);
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
//     var57.setLabelPaint(var64);
//     var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.chart.util.Layer var68 = null;
//     var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
//     org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
//     java.util.List var71 = var54.getCategories();
//     org.jfree.data.xy.XYDataset var73 = null;
//     org.jfree.chart.axis.NumberAxis3D var74 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var75 = var74.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var76 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var77 = null;
//     org.jfree.chart.plot.PiePlot var78 = new org.jfree.chart.plot.PiePlot(var77);
//     var78.setLabelGap((-1.0d));
//     java.lang.Object var81 = var78.clone();
//     java.awt.Paint var82 = var78.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var83 = null;
//     var78.setURLGenerator(var83);
//     java.awt.Stroke var86 = var78.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var88 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var78.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var88);
//     boolean var90 = var76.equals((java.lang.Object)var78);
//     org.jfree.chart.renderer.xy.XYItemRenderer var91 = null;
//     org.jfree.chart.plot.XYPlot var92 = new org.jfree.chart.plot.XYPlot(var73, (org.jfree.chart.axis.ValueAxis)var74, (org.jfree.chart.axis.ValueAxis)var76, var91);
//     var92.clearDomainAxes();
//     var92.clearDomainMarkers();
//     boolean var95 = var92.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var97 = var92.getRangeAxisLocation(15);
//     var54.setDomainAxisLocation(1, var97, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var81
//     assertTrue("Contract failed: equals-hashcode on var16 and var81", var16.equals(var81) ? var16.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var16
//     assertTrue("Contract failed: equals-hashcode on var81 and var16", var81.equals(var16) ? var81.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.util.Size2D var0 = new org.jfree.chart.util.Size2D();
    double var1 = var0.getWidth();
    double var2 = var0.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     var5.setLabelTextAnchor(var8);
//     org.jfree.chart.text.TextAnchor var11 = null;
//     java.awt.Shape var12 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Multiple Pie Plot", var1, 1.0f, (-1.0f), var8, Double.POSITIVE_INFINITY, var11);
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setLabelGap((-1.0d));
    java.lang.Object var5 = var2.clone();
    java.awt.Paint var6 = var2.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var7 = null;
    var2.setURLGenerator(var7);
    java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    boolean var14 = var0.equals((java.lang.Object)var2);
    boolean var15 = var0.getAutoRangeStickyZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)true);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
    var22.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
    var22.setPadding(var26);
    double var29 = var26.trimHeight(0.05d);
    var20.setLegendItemGraphicPadding(var26);
    double var31 = var20.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 3.0d);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.util.RectangleEdge var3 = null;
    double var4 = var0.java2DToValue(100.0d, var2, var3);
    var0.setUpperMargin(10.0d);
    boolean var7 = var0.isInverted();
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 0.0d);
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var8, 1.0E-8d);
    double var13 = var12.getLength();
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var12, (-1.95d));
    var0.setRangeWithMargins(var15);
    org.jfree.data.Range var19 = org.jfree.data.Range.expand(var15, 0.0d, 0.12d);
    double var20 = var19.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == Double.POSITIVE_INFINITY);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == (-1.95d));

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    java.awt.Paint var21 = var20.getBackgroundPaint();
    org.jfree.chart.block.BlockFrame var22 = var20.getFrame();
    org.jfree.chart.util.RectangleInsets var23 = var20.getLegendItemGraphicPadding();
    double var24 = var23.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2.0d);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     var1.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     var20.setDataset(var21);
//     org.jfree.chart.plot.PlotOrientation var23 = var20.getOrientation();
//     org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var26 = var25.getTextAlignment();
//     var25.setHeight(1.0d);
//     double var29 = var25.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var31 = var30.getLabelFont();
//     boolean var32 = var25.equals((java.lang.Object)var31);
//     var20.setAngleLabelFont(var31);
//     java.awt.Graphics2D var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     var20.drawBackground(var34, var35);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var57 = var56.clone();
//     org.jfree.chart.event.MarkerChangeEvent var58 = null;
//     var56.notifyListeners(var58);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var63 = var61.getTickLabelPaint((java.lang.Comparable)255);
//     var56.setLabelPaint(var63);
//     var54.addRangeMarker((org.jfree.chart.plot.Marker)var56);
//     org.jfree.data.xy.XYDataset var66 = null;
//     org.jfree.chart.axis.NumberAxis3D var67 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var68 = var67.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var69 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var70 = null;
//     org.jfree.chart.plot.PiePlot var71 = new org.jfree.chart.plot.PiePlot(var70);
//     var71.setLabelGap((-1.0d));
//     java.lang.Object var74 = var71.clone();
//     java.awt.Paint var75 = var71.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var76 = null;
//     var71.setURLGenerator(var76);
//     java.awt.Stroke var79 = var71.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var81 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var71.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var81);
//     boolean var83 = var69.equals((java.lang.Object)var71);
//     org.jfree.chart.renderer.xy.XYItemRenderer var84 = null;
//     org.jfree.chart.plot.XYPlot var85 = new org.jfree.chart.plot.XYPlot(var66, (org.jfree.chart.axis.ValueAxis)var67, (org.jfree.chart.axis.ValueAxis)var69, var84);
//     java.awt.Stroke var86 = var85.getOutlineStroke();
//     var54.setRangeCrosshairStroke(var86);
//     
//     // Checks the contract:  equals-hashcode on var16 and var74
//     assertTrue("Contract failed: equals-hashcode on var16 and var74", var16.equals(var74) ? var16.hashCode() == var74.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var74 and var16
//     assertTrue("Contract failed: equals-hashcode on var74 and var16", var74.equals(var16) ? var74.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test374() {}
//   public void test374() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }
// 
// 
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     var2.setShadowXOffset((-1.0d));
//     var2.setShadowXOffset(10.0d);
//     boolean var10 = var2.getSimpleLabels();
//     java.awt.Stroke var11 = var2.getLabelOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var14 = var13.getPercentFormat();
//     var2.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     org.jfree.chart.JFreeChart var16 = new org.jfree.chart.JFreeChart("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", (org.jfree.chart.plot.Plot)var2);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var16.draw(var17, var18);
// 
//   }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var4 = var3.getTextAlignment();
//     var3.setHeight(1.0d);
//     double var7 = var3.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var9 = var8.getLabelFont();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Paint var13 = null;
//     var12.setLabelShadowPaint(var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     var18.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.PiePlotState var29 = var12.initialise(var15, var16, var18, (java.lang.Integer)0, var28);
//     java.awt.Paint var30 = var12.getLabelOutlinePaint();
//     var12.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Paint var37 = var34.getLabelOutlinePaint();
//     var12.setOutlinePaint(var37);
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var9, var37);
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("poly", var9);
//     org.jfree.chart.text.TextFragment var41 = var40.getLastTextFragment();
//     org.jfree.chart.text.TextLine var43 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var45 = new org.jfree.chart.text.TextFragment("");
//     var43.removeFragment(var45);
//     org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("");
//     var43.addFragment(var48);
//     org.jfree.chart.text.TextFragment var50 = var43.getFirstTextFragment();
//     org.jfree.chart.title.TextTitle var53 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var54 = var53.getTextAlignment();
//     var53.setHeight(1.0d);
//     double var57 = var53.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var59 = var58.getLabelFont();
//     boolean var60 = var53.equals((java.lang.Object)var59);
//     org.jfree.data.general.PieDataset var61 = null;
//     org.jfree.chart.plot.PiePlot var62 = new org.jfree.chart.plot.PiePlot(var61);
//     java.awt.Paint var63 = null;
//     var62.setLabelShadowPaint(var63);
//     java.awt.Graphics2D var65 = null;
//     java.awt.geom.Rectangle2D var66 = null;
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot(var67);
//     var68.setLabelGap((-1.0d));
//     java.lang.Object var71 = var68.clone();
//     java.awt.Paint var72 = var68.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var73 = null;
//     var68.setURLGenerator(var73);
//     var68.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var78 = null;
//     org.jfree.chart.plot.PiePlotState var79 = var62.initialise(var65, var66, var68, (java.lang.Integer)0, var78);
//     java.awt.Paint var80 = var62.getLabelOutlinePaint();
//     var62.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var83 = null;
//     org.jfree.chart.plot.PiePlot var84 = new org.jfree.chart.plot.PiePlot(var83);
//     java.awt.Paint var85 = null;
//     var84.setLabelShadowPaint(var85);
//     java.awt.Paint var87 = var84.getLabelOutlinePaint();
//     var62.setOutlinePaint(var87);
//     org.jfree.chart.text.TextBlock var89 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var59, var87);
//     org.jfree.chart.title.TextTitle var91 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var92 = var91.getTextAlignment();
//     var89.setLineAlignment(var92);
//     org.jfree.chart.util.VerticalAlignment var94 = null;
//     org.jfree.chart.block.FlowArrangement var97 = new org.jfree.chart.block.FlowArrangement(var92, var94, (-1.0d), (-1.0d));
//     boolean var98 = var50.equals((java.lang.Object)var97);
//     var40.removeFragment(var50);
//     
//     // Checks the contract:  equals-hashcode on var12 and var62
//     assertTrue("Contract failed: equals-hashcode on var12 and var62", var12.equals(var62) ? var12.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var68
//     assertTrue("Contract failed: equals-hashcode on var18 and var68", var18.equals(var68) ? var18.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var84
//     assertTrue("Contract failed: equals-hashcode on var34 and var84", var34.equals(var84) ? var34.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var12
//     assertTrue("Contract failed: equals-hashcode on var62 and var12", var62.equals(var12) ? var62.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var18
//     assertTrue("Contract failed: equals-hashcode on var68 and var18", var68.equals(var18) ? var68.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var34
//     assertTrue("Contract failed: equals-hashcode on var84 and var34", var84.equals(var34) ? var84.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var71
//     assertTrue("Contract failed: equals-hashcode on var21 and var71", var21.equals(var71) ? var21.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var21
//     assertTrue("Contract failed: equals-hashcode on var71 and var21", var71.equals(var21) ? var71.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var24 = null;
    java.awt.Rectangle var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    java.awt.geom.AffineTransform var27 = null;
    java.awt.RenderingHints var28 = null;
    java.awt.PaintContext var29 = var23.createContext(var24, var25, var26, var27, var28);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    var31.setLabelGap((-1.0d));
    java.awt.Stroke var34 = var31.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var37 = var36.getTextAlignment();
    var36.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets();
    var36.setPadding(var40);
    org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var23, var34, var40);
    java.lang.String var43 = var23.toString();
    var11.setBackgroundPaint((java.awt.Paint)var23);
    boolean var45 = var11.getAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var43.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    java.awt.Paint var21 = var19.getRangeCrosshairPaint();
    org.jfree.chart.event.RendererChangeEvent var22 = null;
    var19.rendererChanged(var22);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var19.setFixedRangeAxisSpace(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
//     java.lang.String var22 = var21.toString();
//     org.jfree.data.Range var23 = null;
//     org.jfree.chart.block.RectangleConstraint var25 = new org.jfree.chart.block.RectangleConstraint(var23, 100.0d);
//     double var26 = var25.getWidth();
//     org.jfree.chart.block.LengthConstraintType var27 = var25.getWidthConstraintType();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var30 = null;
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var32 = var31.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     var35.setLabelGap((-1.0d));
//     java.lang.Object var38 = var35.clone();
//     java.awt.Paint var39 = var35.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var40 = null;
//     var35.setURLGenerator(var40);
//     java.awt.Stroke var43 = var35.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var45 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var35.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var45);
//     boolean var47 = var33.equals((java.lang.Object)var35);
//     org.jfree.chart.renderer.xy.XYItemRenderer var48 = null;
//     org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot(var30, (org.jfree.chart.axis.ValueAxis)var31, (org.jfree.chart.axis.ValueAxis)var33, var48);
//     org.jfree.data.Range var50 = var31.getDefaultAutoRange();
//     var29.setRange(var50);
//     org.jfree.data.Range var54 = org.jfree.data.Range.shift(var50, (-1.95d), true);
//     org.jfree.chart.block.RectangleConstraint var55 = var25.toRangeWidth(var50);
//     boolean var56 = var21.equals((java.lang.Object)var25);
//     
//     // Checks the contract:  equals-hashcode on var4 and var38
//     assertTrue("Contract failed: equals-hashcode on var4 and var38", var4.equals(var38) ? var4.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var4
//     assertTrue("Contract failed: equals-hashcode on var38 and var4", var38.equals(var4) ? var38.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", var1);
// 
//   }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     org.jfree.chart.plot.PolarPlot var0 = new org.jfree.chart.plot.PolarPlot();
//     var0.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.util.RectangleAnchor var7 = null;
//     java.awt.geom.Point2D var8 = org.jfree.chart.util.RectangleAnchor.coordinates(var6, var7);
//     var0.zoomDomainAxes(0.0d, (-1.0d), var5, var8);
//     org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var11.configure();
//     org.jfree.data.Range var13 = var0.getDataRange((org.jfree.chart.axis.ValueAxis)var11);
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.plot.PolarPlot var17 = new org.jfree.chart.plot.PolarPlot();
//     var17.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleAnchor var24 = null;
//     java.awt.geom.Point2D var25 = org.jfree.chart.util.RectangleAnchor.coordinates(var23, var24);
//     var17.zoomDomainAxes(0.0d, (-1.0d), var22, var25);
//     var0.zoomRangeAxes(100.0d, Double.NaN, var16, var25);
// 
//   }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var1.setTickMarkOutsideLength(1.0f);
//     java.lang.String var5 = var1.getCategoryLabelToolTip((java.lang.Comparable)(byte)1);
//     java.awt.geom.Rectangle2D var8 = null;
//     org.jfree.data.xy.XYDataset var9 = null;
//     org.jfree.chart.axis.NumberAxis3D var10 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var11 = var10.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.PiePlot var14 = new org.jfree.chart.plot.PiePlot(var13);
//     var14.setLabelGap((-1.0d));
//     java.lang.Object var17 = var14.clone();
//     java.awt.Paint var18 = var14.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var19 = null;
//     var14.setURLGenerator(var19);
//     java.awt.Stroke var22 = var14.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var24 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var14.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var24);
//     boolean var26 = var12.equals((java.lang.Object)var14);
//     org.jfree.chart.renderer.xy.XYItemRenderer var27 = null;
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot(var9, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var12, var27);
//     org.jfree.chart.util.RectangleEdge var30 = var28.getRangeAxisEdge(100);
//     boolean var31 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var30);
//     java.lang.String var32 = var30.toString();
//     double var33 = var1.getCategoryMiddle(1, 10, var8, var30);
// 
//   }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var2 = var0.getStringArray("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    int var28 = var19.getRangeAxisCount();
    org.jfree.chart.axis.ValueAxis var30 = var19.getDomainAxis(4);
    java.awt.Stroke var31 = var19.getRangeGridlineStroke();
    org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
    var33.setTickMarkOutsideLength(1.0f);
    float var36 = var33.getTickMarkOutsideLength();
    java.awt.Color var40 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var41 = null;
    java.awt.Rectangle var42 = null;
    java.awt.geom.Rectangle2D var43 = null;
    java.awt.geom.AffineTransform var44 = null;
    java.awt.RenderingHints var45 = null;
    java.awt.PaintContext var46 = var40.createContext(var41, var42, var43, var44, var45);
    java.lang.String var47 = var40.toString();
    float[] var48 = null;
    float[] var49 = var40.getRGBComponents(var48);
    var33.setAxisLinePaint((java.awt.Paint)var40);
    java.awt.Color var51 = var40.brighter();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setQuadrantPaint(100, (java.awt.Paint)var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var47.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var1.setTickMarkOutsideLength(1.0f);
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Paint var7 = null;
    var6.setLabelShadowPaint(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    var12.setLabelGap((-1.0d));
    java.lang.Object var15 = var12.clone();
    java.awt.Paint var16 = var12.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var17 = null;
    var12.setURLGenerator(var17);
    var12.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PiePlotState var23 = var6.initialise(var9, var10, var12, (java.lang.Integer)0, var22);
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    var25.setLabelGap((-1.0d));
    java.awt.Font var28 = var25.getLabelFont();
    var12.setNoDataMessageFont(var28);
    boolean var30 = var1.equals((java.lang.Object)var12);
    var12.setShadowXOffset(0.05d);
    var12.setExplodePercent((java.lang.Comparable)3.0d, (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     org.jfree.chart.JFreeChart var23 = null;
//     org.jfree.chart.event.ChartChangeEventType var24 = null;
//     org.jfree.chart.event.ChartChangeEvent var25 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var22, var23, var24);
//     org.jfree.chart.JFreeChart var26 = var25.getChart();
//     org.jfree.data.xy.XYDataset var28 = null;
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var30 = var29.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var31 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setLabelGap((-1.0d));
//     java.lang.Object var36 = var33.clone();
//     java.awt.Paint var37 = var33.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var38 = null;
//     var33.setURLGenerator(var38);
//     java.awt.Stroke var41 = var33.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var43 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var33.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var43);
//     boolean var45 = var31.equals((java.lang.Object)var33);
//     org.jfree.chart.renderer.xy.XYItemRenderer var46 = null;
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot(var28, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.axis.ValueAxis)var31, var46);
//     var47.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var50 = null;
//     var47.setRangeAxisLocation(4, var50, false);
//     org.jfree.chart.JFreeChart var53 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var47);
//     var25.setChart(var53);
//     org.jfree.chart.ChartRenderingInfo var57 = null;
//     var53.handleClick(0, 0, var57);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.axis.NumberAxis3D var16 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var17 = var16.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var18 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.PiePlot var20 = new org.jfree.chart.plot.PiePlot(var19);
//     var20.setLabelGap((-1.0d));
//     java.lang.Object var23 = var20.clone();
//     java.awt.Paint var24 = var20.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var25 = null;
//     var20.setURLGenerator(var25);
//     java.awt.Stroke var28 = var20.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var30 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var20.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var30);
//     boolean var32 = var18.equals((java.lang.Object)var20);
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = null;
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot(var15, (org.jfree.chart.axis.ValueAxis)var16, (org.jfree.chart.axis.ValueAxis)var18, var33);
//     java.awt.Paint var35 = var34.getDomainZeroBaselinePaint();
//     java.awt.Paint var36 = var34.getRangeCrosshairPaint();
//     org.jfree.chart.event.RendererChangeEvent var37 = null;
//     var34.rendererChanged(var37);
//     java.awt.Font var39 = var34.getNoDataMessageFont();
//     java.awt.Stroke var40 = var34.getRangeGridlineStroke();
//     var0.setAxisLineStroke(var40);
//     
//     // Checks the contract:  equals-hashcode on var2 and var20
//     assertTrue("Contract failed: equals-hashcode on var2 and var20", var2.equals(var20) ? var2.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var2
//     assertTrue("Contract failed: equals-hashcode on var20 and var2", var20.equals(var2) ? var20.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var23
//     assertTrue("Contract failed: equals-hashcode on var5 and var23", var5.equals(var23) ? var5.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var5
//     assertTrue("Contract failed: equals-hashcode on var23 and var5", var23.equals(var5) ? var23.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var30
//     assertTrue("Contract failed: equals-hashcode on var12 and var30", var12.equals(var30) ? var12.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var12
//     assertTrue("Contract failed: equals-hashcode on var30 and var12", var30.equals(var12) ? var30.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "java.awt.Color[r=255,g=255,b=254]", var3, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "java.awt.Color[r=255,g=255,b=254]", "");
    java.awt.Image var8 = null;
    var7.setLogo(var8);
    java.util.List var10 = var7.getContributors();
    org.jfree.chart.ui.Library[] var11 = var7.getLibraries();
    java.awt.Image var15 = null;
    org.jfree.chart.ui.ProjectInfo var19 = new org.jfree.chart.ui.ProjectInfo("", "org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "java.awt.Color[r=255,g=255,b=254]", var15, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "java.awt.Color[r=255,g=255,b=254]", "");
    java.awt.Image var20 = null;
    var19.setLogo(var20);
    java.util.List var22 = var19.getContributors();
    org.jfree.chart.ui.Library[] var23 = var19.getLibraries();
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var26 = var25.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var27 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot var29 = new org.jfree.chart.plot.PiePlot(var28);
    var29.setLabelGap((-1.0d));
    java.lang.Object var32 = var29.clone();
    java.awt.Paint var33 = var29.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var34 = null;
    var29.setURLGenerator(var34);
    java.awt.Stroke var37 = var29.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var39 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var29.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var39);
    boolean var41 = var27.equals((java.lang.Object)var29);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = null;
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot(var24, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.axis.ValueAxis)var27, var42);
    org.jfree.chart.plot.PlotRenderingInfo var46 = null;
    java.awt.geom.Point2D var47 = null;
    var43.zoomRangeAxes(0.05d, 10.0d, var46, var47);
    var43.setDomainCrosshairValue(0.05d, false);
    org.jfree.chart.util.Layer var53 = null;
    java.util.Collection var54 = var43.getRangeMarkers(0, var53);
    boolean var55 = var43.isDomainZoomable();
    var43.mapDatasetToRangeAxis(4, 0);
    org.jfree.chart.axis.NumberAxis3D var59 = new org.jfree.chart.axis.NumberAxis3D();
    java.awt.geom.Rectangle2D var61 = null;
    org.jfree.chart.util.RectangleEdge var62 = null;
    double var63 = var59.valueToJava2D(10.0d, var61, var62);
    org.jfree.chart.axis.ValueAxis[] var64 = new org.jfree.chart.axis.ValueAxis[] { var59};
    var43.setRangeAxes(var64);
    java.util.List var66 = var43.getAnnotations();
    var19.setContributors(var66);
    var7.setContributors(var66);
    java.util.List var69 = var7.getContributors();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.Comparable var1 = null;
    org.jfree.chart.text.TextLine var5 = new org.jfree.chart.text.TextLine("hi!");
    org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("");
    var5.removeFragment(var7);
    org.jfree.chart.text.TextFragment var9 = var5.getFirstTextFragment();
    java.awt.Font var10 = var9.getFont();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var14 = var13.getTextAlignment();
    var13.setHeight(1.0d);
    double var17 = var13.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var19 = var18.getLabelFont();
    boolean var20 = var13.equals((java.lang.Object)var19);
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.PiePlot var22 = new org.jfree.chart.plot.PiePlot(var21);
    java.awt.Paint var23 = null;
    var22.setLabelShadowPaint(var23);
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.data.general.PieDataset var27 = null;
    org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
    var28.setLabelGap((-1.0d));
    java.lang.Object var31 = var28.clone();
    java.awt.Paint var32 = var28.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var33 = null;
    var28.setURLGenerator(var33);
    var28.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    org.jfree.chart.plot.PiePlotState var39 = var22.initialise(var25, var26, var28, (java.lang.Integer)0, var38);
    java.awt.Paint var40 = var22.getLabelOutlinePaint();
    var22.setSimpleLabels(true);
    org.jfree.data.general.PieDataset var43 = null;
    org.jfree.chart.plot.PiePlot var44 = new org.jfree.chart.plot.PiePlot(var43);
    java.awt.Paint var45 = null;
    var44.setLabelShadowPaint(var45);
    java.awt.Paint var47 = var44.getLabelOutlinePaint();
    var22.setOutlinePaint(var47);
    org.jfree.chart.text.TextLine var49 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var19, var47);
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var10, var47);
    java.awt.Color var54 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var55 = null;
    java.awt.Rectangle var56 = null;
    java.awt.geom.Rectangle2D var57 = null;
    java.awt.geom.AffineTransform var58 = null;
    java.awt.RenderingHints var59 = null;
    java.awt.PaintContext var60 = var54.createContext(var55, var56, var57, var58, var59);
    java.lang.String var61 = var54.toString();
    org.jfree.chart.text.TextBlock var62 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var10, (java.awt.Paint)var54);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelFont(var1, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var61.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     int var28 = var19.getDomainAxisCount();
//     org.jfree.chart.axis.NumberAxis3D var29 = new org.jfree.chart.axis.NumberAxis3D();
//     float var30 = var29.getTickMarkOutsideLength();
//     var19.setDomainAxis((org.jfree.chart.axis.ValueAxis)var29);
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var35 = var34.clone();
//     java.awt.Stroke var36 = var34.getStroke();
//     org.jfree.chart.util.Layer var37 = null;
//     boolean var38 = var19.removeDomainMarker(15, (org.jfree.chart.plot.Marker)var34, var37);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
//     var3.setLabelGap((-1.0d));
//     java.lang.Object var6 = var3.clone();
//     java.awt.Paint var7 = var3.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var8 = null;
//     var3.setURLGenerator(var8);
//     java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
//     boolean var15 = var1.equals((java.lang.Object)var3);
//     var1.configure();
//     var1.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var19 = null;
//     org.jfree.chart.plot.PolarPlot var20 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var19);
//     org.jfree.data.xy.XYDataset var21 = null;
//     var20.setDataset(var21);
//     org.jfree.chart.plot.PlotOrientation var23 = var20.getOrientation();
//     java.lang.String var24 = var23.toString();
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var27 = null;
//     org.jfree.chart.axis.NumberAxis3D var28 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var29 = var28.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var30 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.PiePlot var32 = new org.jfree.chart.plot.PiePlot(var31);
//     var32.setLabelGap((-1.0d));
//     java.lang.Object var35 = var32.clone();
//     java.awt.Paint var36 = var32.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var37 = null;
//     var32.setURLGenerator(var37);
//     java.awt.Stroke var40 = var32.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var42 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var32.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var42);
//     boolean var44 = var30.equals((java.lang.Object)var32);
//     org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var27, (org.jfree.chart.axis.ValueAxis)var28, (org.jfree.chart.axis.ValueAxis)var30, var45);
//     org.jfree.data.Range var47 = var28.getDefaultAutoRange();
//     var26.setRange(var47);
//     org.jfree.data.Range var51 = org.jfree.data.Range.shift(var47, (-1.95d), true);
//     boolean var52 = var23.equals((java.lang.Object)var47);
//     
//     // Checks the contract:  equals-hashcode on var3 and var32
//     assertTrue("Contract failed: equals-hashcode on var3 and var32", var3.equals(var32) ? var3.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var3
//     assertTrue("Contract failed: equals-hashcode on var32 and var3", var32.equals(var3) ? var32.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var35
//     assertTrue("Contract failed: equals-hashcode on var6 and var35", var6.equals(var35) ? var6.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var6
//     assertTrue("Contract failed: equals-hashcode on var35 and var6", var35.equals(var6) ? var35.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var42
//     assertTrue("Contract failed: equals-hashcode on var13 and var42", var13.equals(var42) ? var13.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var13
//     assertTrue("Contract failed: equals-hashcode on var42 and var13", var42.equals(var13) ? var42.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     boolean var22 = var19.isRangeGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var23 = null;
//     var19.setFixedRangeAxisSpace(var23);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     var19.handleClick((-2), 0, var27);
// 
//   }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("RectangleAnchor.CENTER");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    java.util.Enumeration var1 = var0.getKeys();
    java.util.Enumeration var2 = var0.getKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var4 = var0.getString("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    var11.clearSubtitles();
    float var22 = var11.getBackgroundImageAlpha();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var23 = var11.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.5f);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var13 = var12.getPercentFormat();
//     var1.setLegendLabelToolTipGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     org.jfree.data.general.PieDataset var15 = null;
//     java.text.AttributedString var17 = var12.generateAttributedSectionLabel(var15, (java.lang.Comparable)3.0d);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    java.awt.Paint var19 = var1.getLabelOutlinePaint();
    var1.setInteriorGap(0.14d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var57 = var56.clone();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot var59 = new org.jfree.chart.plot.PiePlot(var58);
//     java.awt.Paint var60 = null;
//     var59.setLabelShadowPaint(var60);
//     java.awt.Graphics2D var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.data.general.PieDataset var64 = null;
//     org.jfree.chart.plot.PiePlot var65 = new org.jfree.chart.plot.PiePlot(var64);
//     var65.setLabelGap((-1.0d));
//     java.lang.Object var68 = var65.clone();
//     java.awt.Paint var69 = var65.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var70 = null;
//     var65.setURLGenerator(var70);
//     var65.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var75 = null;
//     org.jfree.chart.plot.PiePlotState var76 = var59.initialise(var62, var63, var65, (java.lang.Integer)0, var75);
//     java.awt.Paint var77 = var59.getLabelOutlinePaint();
//     var59.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var80 = null;
//     org.jfree.chart.plot.PiePlot var81 = new org.jfree.chart.plot.PiePlot(var80);
//     java.awt.Paint var82 = null;
//     var81.setLabelShadowPaint(var82);
//     java.awt.Paint var84 = var81.getLabelOutlinePaint();
//     var59.setOutlinePaint(var84);
//     boolean var86 = var59.isCircular();
//     var56.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var59);
//     org.jfree.chart.util.Layer var88 = null;
//     var54.addRangeMarker((org.jfree.chart.plot.Marker)var56, var88);
//     
//     // Checks the contract:  equals-hashcode on var7 and var81
//     assertTrue("Contract failed: equals-hashcode on var7 and var81", var7.equals(var81) ? var7.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var7
//     assertTrue("Contract failed: equals-hashcode on var81 and var7", var81.equals(var7) ? var81.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var68
//     assertTrue("Contract failed: equals-hashcode on var16 and var68", var16.equals(var68) ? var16.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var16
//     assertTrue("Contract failed: equals-hashcode on var68 and var16", var68.equals(var16) ? var68.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setLabelGap((-1.0d));
    java.lang.Object var5 = var2.clone();
    var2.setShadowXOffset((-1.0d));
    var2.setShadowXOffset(10.0d);
    boolean var10 = var2.getSimpleLabels();
    java.awt.Stroke var11 = var2.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.plot.Plot var13 = var12.getPlot();
    java.awt.RenderingHints var14 = var12.getRenderingHints();
    org.jfree.chart.event.ChartChangeEventType var15 = null;
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100, var12, var15);
    org.jfree.chart.event.ChartChangeEventType var17 = null;
    var16.setType(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    java.awt.Stroke var71 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.setDomainGridlineStroke(var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var3 = var2.getTextAlignment();
//     var2.setHeight(1.0d);
//     double var6 = var2.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var8 = var7.getLabelFont();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Paint var12 = null;
//     var11.setLabelShadowPaint(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     var17.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
//     java.awt.Paint var29 = var11.getLabelOutlinePaint();
//     var11.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Paint var34 = null;
//     var33.setLabelShadowPaint(var34);
//     java.awt.Paint var36 = var33.getLabelOutlinePaint();
//     var11.setOutlinePaint(var36);
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var8, var36);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var41 = var40.getTextAlignment();
//     var38.setLineAlignment(var41);
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var41, var43, (-1.0d), (-1.0d));
//     org.jfree.chart.title.TextTitle var48 = new org.jfree.chart.title.TextTitle("");
//     var48.setExpandToFitSpace(true);
//     java.lang.Object var51 = var48.clone();
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     java.awt.Paint var54 = null;
//     var53.setLabelShadowPaint(var54);
//     java.awt.Graphics2D var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot var59 = new org.jfree.chart.plot.PiePlot(var58);
//     var59.setLabelGap((-1.0d));
//     java.lang.Object var62 = var59.clone();
//     java.awt.Paint var63 = var59.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var64 = null;
//     var59.setURLGenerator(var64);
//     var59.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     org.jfree.chart.plot.PiePlotState var70 = var53.initialise(var56, var57, var59, (java.lang.Integer)0, var69);
//     java.awt.Paint var71 = var53.getLabelOutlinePaint();
//     var53.setSimpleLabels(true);
//     var53.setCircular(true);
//     org.jfree.chart.urls.PieURLGenerator var76 = var53.getURLGenerator();
//     var46.add((org.jfree.chart.block.Block)var48, (java.lang.Object)var53);
//     
//     // Checks the contract:  equals-hashcode on var17 and var59
//     assertTrue("Contract failed: equals-hashcode on var17 and var59", var17.equals(var59) ? var17.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var17
//     assertTrue("Contract failed: equals-hashcode on var59 and var17", var59.equals(var17) ? var59.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var62
//     assertTrue("Contract failed: equals-hashcode on var20 and var62", var20.equals(var62) ? var20.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var20
//     assertTrue("Contract failed: equals-hashcode on var62 and var20", var62.equals(var20) ? var62.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot var3 = new org.jfree.chart.plot.PiePlot(var2);
    var3.setLabelGap((-1.0d));
    java.lang.Object var6 = var3.clone();
    java.awt.Paint var7 = var3.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var8 = null;
    var3.setURLGenerator(var8);
    java.awt.Stroke var11 = var3.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var3.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
    boolean var15 = var1.equals((java.lang.Object)var3);
    boolean var16 = var1.isAutoTickUnitSelection();
    var1.resizeRange(10.0d, (-1.95d));
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    var2.setLabelGap((-1.0d));
    java.lang.Object var5 = var2.clone();
    java.awt.Paint var6 = var2.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var7 = null;
    var2.setURLGenerator(var7);
    java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
    boolean var14 = var0.equals((java.lang.Object)var2);
    var0.configure();
    var0.setTickMarkInsideLength(2.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(0.08d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setRangeAxisLocation(4, var23, false);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
//     var20.setBackgroundAlpha(1.0f);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.data.xy.XYDataset var31 = null;
//     org.jfree.chart.axis.NumberAxis3D var32 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var33 = var32.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var35 = null;
//     org.jfree.chart.plot.PiePlot var36 = new org.jfree.chart.plot.PiePlot(var35);
//     var36.setLabelGap((-1.0d));
//     java.lang.Object var39 = var36.clone();
//     java.awt.Paint var40 = var36.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var41 = null;
//     var36.setURLGenerator(var41);
//     java.awt.Stroke var44 = var36.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var46 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var36.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var46);
//     boolean var48 = var34.equals((java.lang.Object)var36);
//     org.jfree.chart.renderer.xy.XYItemRenderer var49 = null;
//     org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot(var31, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.axis.ValueAxis)var34, var49);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     java.awt.geom.Point2D var54 = null;
//     var50.zoomRangeAxes(0.05d, 10.0d, var53, var54);
//     var50.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var60 = null;
//     java.util.Collection var61 = var50.getRangeMarkers(0, var60);
//     boolean var62 = var50.isDomainZoomable();
//     var50.mapDatasetToRangeAxis(4, 0);
//     org.jfree.chart.axis.NumberAxis3D var66 = new org.jfree.chart.axis.NumberAxis3D();
//     java.awt.geom.Rectangle2D var68 = null;
//     org.jfree.chart.util.RectangleEdge var69 = null;
//     double var70 = var66.valueToJava2D(10.0d, var68, var69);
//     org.jfree.chart.axis.ValueAxis[] var71 = new org.jfree.chart.axis.ValueAxis[] { var66};
//     var50.setRangeAxes(var71);
//     java.util.List var73 = var50.getAnnotations();
//     var20.drawRangeTickBands(var29, var30, var73);
//     
//     // Checks the contract:  equals-hashcode on var6 and var36
//     assertTrue("Contract failed: equals-hashcode on var6 and var36", var6.equals(var36) ? var6.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var6
//     assertTrue("Contract failed: equals-hashcode on var36 and var6", var36.equals(var6) ? var36.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var39
//     assertTrue("Contract failed: equals-hashcode on var9 and var39", var9.equals(var39) ? var9.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var9
//     assertTrue("Contract failed: equals-hashcode on var39 and var9", var39.equals(var9) ? var39.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var46
//     assertTrue("Contract failed: equals-hashcode on var16 and var46", var16.equals(var46) ? var16.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var16
//     assertTrue("Contract failed: equals-hashcode on var46 and var16", var46.equals(var16) ? var46.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     boolean var22 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var24 = var19.getRangeAxisLocation(15);
//     org.jfree.chart.plot.PlotOrientation var25 = var19.getOrientation();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     var27.setLabelLinkMargin(0.05d);
//     boolean var34 = var25.equals((java.lang.Object)0.05d);
//     
//     // Checks the contract:  equals-hashcode on var8 and var30
//     assertTrue("Contract failed: equals-hashcode on var8 and var30", var8.equals(var30) ? var8.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var8
//     assertTrue("Contract failed: equals-hashcode on var30 and var8", var30.equals(var8) ? var30.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var22 = null;
//     var19.setRangeAxisLocation(4, var22, false);
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     var25.setTickMarkOutsideLength(1.0f);
//     float var28 = var25.getTickMarkOutsideLength();
//     java.awt.Color var32 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var33 = null;
//     java.awt.Rectangle var34 = null;
//     java.awt.geom.Rectangle2D var35 = null;
//     java.awt.geom.AffineTransform var36 = null;
//     java.awt.RenderingHints var37 = null;
//     java.awt.PaintContext var38 = var32.createContext(var33, var34, var35, var36, var37);
//     java.lang.String var39 = var32.toString();
//     float[] var40 = null;
//     float[] var41 = var32.getRGBComponents(var40);
//     var25.setAxisLinePaint((java.awt.Paint)var32);
//     java.awt.Color var43 = var32.brighter();
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     java.awt.Paint var46 = null;
//     var45.setLabelShadowPaint(var46);
//     java.awt.Graphics2D var48 = null;
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.data.general.PieDataset var50 = null;
//     org.jfree.chart.plot.PiePlot var51 = new org.jfree.chart.plot.PiePlot(var50);
//     var51.setLabelGap((-1.0d));
//     java.lang.Object var54 = var51.clone();
//     java.awt.Paint var55 = var51.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var56 = null;
//     var51.setURLGenerator(var56);
//     var51.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.plot.PiePlotState var62 = var45.initialise(var48, var49, var51, (java.lang.Integer)0, var61);
//     org.jfree.data.general.PieDataset var63 = null;
//     org.jfree.chart.plot.PiePlot var64 = new org.jfree.chart.plot.PiePlot(var63);
//     var64.setLabelGap((-1.0d));
//     java.awt.Font var67 = var64.getLabelFont();
//     var51.setNoDataMessageFont(var67);
//     boolean var69 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var43, (java.lang.Object)var67);
//     var19.setRangeCrosshairPaint((java.awt.Paint)var43);
//     
//     // Checks the contract:  equals-hashcode on var8 and var54
//     assertTrue("Contract failed: equals-hashcode on var8 and var54", var8.equals(var54) ? var8.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var8
//     assertTrue("Contract failed: equals-hashcode on var54 and var8", var54.equals(var8) ? var54.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     boolean var22 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var25 = var24.getTextAlignment();
//     var24.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     var24.setPadding(var28);
//     double var31 = var28.trimHeight(0.05d);
//     var19.setInsets(var28, true);
//     java.awt.Font var34 = var19.getNoDataMessageFont();
//     org.jfree.chart.renderer.xy.XYItemRenderer var36 = var19.getRenderer(255);
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     var38.setShadowXOffset((-1.0d));
//     var38.setShadowXOffset(10.0d);
//     boolean var46 = var38.getSimpleLabels();
//     java.awt.Stroke var47 = var38.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.plot.Plot var49 = var48.getPlot();
//     java.awt.RenderingHints var50 = var48.getRenderingHints();
//     java.awt.Color var54 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var55 = var54.getGreen();
//     var48.setBorderPaint((java.awt.Paint)var54);
//     org.jfree.chart.title.LegendTitle var57 = var48.getLegend();
//     java.awt.Paint var58 = var57.getBackgroundPaint();
//     org.jfree.chart.block.BlockFrame var59 = var57.getFrame();
//     org.jfree.chart.util.RectangleInsets var60 = var57.getLegendItemGraphicPadding();
//     var19.setAxisOffset(var60);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "hi!", "hi!");
    var5.addOptionalLibrary((org.jfree.chart.ui.Library)var11);
    org.jfree.chart.ui.Library[] var13 = var11.getOptionalLibraries();
    var11.setName("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    boolean var21 = var19.isRangeGridlinesVisible();
    var19.setDomainCrosshairVisible(true);
    org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
    org.jfree.chart.renderer.xy.XYItemRenderer[] var25 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var24};
    var19.setRenderers(var25);
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var19.setRenderer((-2), var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var6 = var5.getLabelTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Other", var1, 2.0f, 0.0f, var6, (-1.0d), 1.0f, 0.5f);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("Size2D[width=0.0, height=0.0]", 254, 0);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
//     boolean var22 = var21.isEmpty();
//     java.util.List var23 = var21.getBlocks();
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var21.draw(var24, var25);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(10.0d, 1.0E-8d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.event.MarkerChangeEvent var59 = null;
//     var57.notifyListeners(var59);
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
//     var57.setLabelPaint(var64);
//     var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.chart.util.Layer var68 = null;
//     var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
//     var54.setWeight(0);
//     var54.clearAnnotations();
//     org.jfree.chart.util.RectangleEdge var74 = var54.getDomainAxisEdge(100);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var75 = null;
//     var54.setRenderers(var75);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var3 = var2.getTextAlignment();
//     var2.setHeight(1.0d);
//     double var6 = var2.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var8 = var7.getLabelFont();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Paint var12 = null;
//     var11.setLabelShadowPaint(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     var17.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
//     java.awt.Paint var29 = var11.getLabelOutlinePaint();
//     var11.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Paint var34 = null;
//     var33.setLabelShadowPaint(var34);
//     java.awt.Paint var36 = var33.getLabelOutlinePaint();
//     var11.setOutlinePaint(var36);
//     org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var8, var36);
//     org.jfree.chart.title.TextTitle var40 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var41 = var40.getTextAlignment();
//     var38.setLineAlignment(var41);
//     org.jfree.chart.text.TextLine var44 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("");
//     var44.removeFragment(var46);
//     org.jfree.chart.text.TextFragment var49 = new org.jfree.chart.text.TextFragment("");
//     var44.addFragment(var49);
//     var38.addLine(var44);
//     org.jfree.chart.text.TextLine var53 = new org.jfree.chart.text.TextLine("hi!");
//     org.jfree.chart.text.TextFragment var54 = var53.getLastTextFragment();
//     var44.addFragment(var54);
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
//     float var57 = var56.getTickMarkOutsideLength();
//     org.jfree.data.general.PieDataset var58 = null;
//     org.jfree.chart.plot.PiePlot var59 = new org.jfree.chart.plot.PiePlot(var58);
//     var59.setLabelGap((-1.0d));
//     java.lang.Object var62 = var59.clone();
//     java.awt.Shape var63 = var59.getLegendItemShape();
//     var56.setUpArrow(var63);
//     org.jfree.chart.entity.ChartEntity var66 = new org.jfree.chart.entity.ChartEntity(var63, "org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     boolean var67 = var44.equals((java.lang.Object)var63);
//     
//     // Checks the contract:  equals-hashcode on var20 and var62
//     assertTrue("Contract failed: equals-hashcode on var20 and var62", var20.equals(var62) ? var20.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var20
//     assertTrue("Contract failed: equals-hashcode on var62 and var20", var62.equals(var20) ? var62.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextAnchor var75 = var74.getLabelTextAnchor();
    org.jfree.chart.event.MarkerChangeEvent var76 = null;
    var74.notifyListeners(var76);
    java.lang.String var78 = var74.getLabel();
    org.jfree.chart.util.Layer var79 = null;
    var71.addRangeMarker(0, (org.jfree.chart.plot.Marker)var74, var79);
    org.jfree.chart.util.Layer var81 = null;
    boolean var82 = var54.removeRangeMarker((org.jfree.chart.plot.Marker)var74, var81);
    org.jfree.chart.annotations.CategoryAnnotation var83 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.addAnnotation(var83);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.block.BlockContainer var21 = var20.getItemContainer();
//     var21.clear();
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.PiePlot var24 = new org.jfree.chart.plot.PiePlot(var23);
//     var24.setLabelGap((-1.0d));
//     java.lang.Object var27 = var24.clone();
//     var24.setShadowXOffset((-1.0d));
//     var24.setShadowXOffset(10.0d);
//     boolean var32 = var24.getSimpleLabels();
//     java.awt.Stroke var33 = var24.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var34 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.plot.Plot var35 = var34.getPlot();
//     java.awt.RenderingHints var36 = var34.getRenderingHints();
//     java.awt.Color var40 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var41 = var40.getGreen();
//     var34.setBorderPaint((java.awt.Paint)var40);
//     org.jfree.chart.title.LegendTitle var43 = var34.getLegend();
//     org.jfree.chart.block.BlockContainer var44 = var43.getItemContainer();
//     org.jfree.chart.util.RectangleInsets var45 = var43.getItemLabelPadding();
//     var21.add((org.jfree.chart.block.Block)var43);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var27
//     assertTrue("Contract failed: equals-hashcode on var4 and var27", var4.equals(var27) ? var4.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var4
//     assertTrue("Contract failed: equals-hashcode on var27 and var4", var27.equals(var4) ? var27.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var34
//     assertTrue("Contract failed: equals-hashcode on var11 and var34", var11.equals(var34) ? var11.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var11
//     assertTrue("Contract failed: equals-hashcode on var34 and var11", var34.equals(var11) ? var34.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var35
//     assertTrue("Contract failed: equals-hashcode on var12 and var35", var12.equals(var35) ? var12.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var12
//     assertTrue("Contract failed: equals-hashcode on var35 and var12", var35.equals(var12) ? var35.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var1 = null;
//     org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
//     var2.setLabelGap((-1.0d));
//     java.lang.Object var5 = var2.clone();
//     java.awt.Paint var6 = var2.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var7 = null;
//     var2.setURLGenerator(var7);
//     java.awt.Stroke var10 = var2.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var2.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var12);
//     boolean var14 = var0.equals((java.lang.Object)var2);
//     var0.configure();
//     var0.setTickMarkInsideLength(2.0f);
//     org.jfree.data.general.PieDataset var18 = null;
//     org.jfree.chart.plot.PiePlot var19 = new org.jfree.chart.plot.PiePlot(var18);
//     var19.setLabelGap((-1.0d));
//     java.lang.Object var22 = var19.clone();
//     var19.setShadowXOffset((-1.0d));
//     var19.setShadowXOffset(10.0d);
//     boolean var27 = var19.getSimpleLabels();
//     java.awt.Stroke var28 = var19.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var19);
//     org.jfree.chart.plot.Plot var30 = var29.getPlot();
//     java.awt.RenderingHints var31 = var29.getRenderingHints();
//     java.awt.Color var35 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var36 = var35.getGreen();
//     var29.setBorderPaint((java.awt.Paint)var35);
//     var0.setTickLabelPaint((java.awt.Paint)var35);
//     
//     // Checks the contract:  equals-hashcode on var5 and var22
//     assertTrue("Contract failed: equals-hashcode on var5 and var22", var5.equals(var22) ? var5.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var5
//     assertTrue("Contract failed: equals-hashcode on var22 and var5", var22.equals(var5) ? var22.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
//     var1.setExpandToFitSpace(true);
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.awt.Font var8 = var5.getLabelFont();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.PiePlot var10 = new org.jfree.chart.plot.PiePlot(var9);
//     var10.setLabelGap((-1.0d));
//     java.lang.Object var13 = var10.clone();
//     var10.setShadowXOffset((-1.0d));
//     var10.setShadowXOffset(10.0d);
//     boolean var18 = var10.getSimpleLabels();
//     java.awt.Stroke var19 = var10.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var20 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var10);
//     org.jfree.chart.event.ChartProgressEvent var23 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var5, var20, 0, 0);
//     var1.addChangeListener((org.jfree.chart.event.TitleChangeListener)var20);
//     var20.fireChartChanged();
//     boolean var26 = var20.getAntiAlias();
//     org.jfree.chart.title.TextTitle var28 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var29 = var28.getTextAlignment();
//     var28.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     var28.setID("poly");
//     org.jfree.data.general.PieDataset var34 = null;
//     org.jfree.chart.plot.PiePlot var35 = new org.jfree.chart.plot.PiePlot(var34);
//     var35.setLabelGap((-1.0d));
//     java.lang.Object var38 = var35.clone();
//     var35.setShadowXOffset((-1.0d));
//     var35.setShadowXOffset(10.0d);
//     boolean var43 = var35.getSimpleLabels();
//     java.awt.Stroke var44 = var35.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
//     org.jfree.chart.plot.Plot var46 = var45.getPlot();
//     java.awt.RenderingHints var47 = var45.getRenderingHints();
//     java.awt.Color var51 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var52 = var51.getGreen();
//     var45.setBorderPaint((java.awt.Paint)var51);
//     org.jfree.chart.title.LegendTitle var54 = var45.getLegend();
//     org.jfree.chart.title.TextTitle var56 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var57 = var56.getTextAlignment();
//     var56.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var60 = new org.jfree.chart.util.RectangleInsets();
//     var56.setPadding(var60);
//     double var63 = var60.trimHeight(0.05d);
//     var54.setLegendItemGraphicPadding(var60);
//     org.jfree.chart.util.RectangleInsets var65 = var54.getLegendItemGraphicPadding();
//     var28.setPadding(var65);
//     var20.setTitle(var28);
//     
//     // Checks the contract:  equals-hashcode on var10 and var35
//     assertTrue("Contract failed: equals-hashcode on var10 and var35", var10.equals(var35) ? var10.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var10
//     assertTrue("Contract failed: equals-hashcode on var35 and var10", var35.equals(var10) ? var35.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var38
//     assertTrue("Contract failed: equals-hashcode on var13 and var38", var13.equals(var38) ? var13.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var13
//     assertTrue("Contract failed: equals-hashcode on var38 and var13", var38.equals(var13) ? var38.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, Double.NaN, (-0.974999995d), (-1.95d), 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
    org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var25 = var24.getTextAlignment();
    java.lang.String var26 = var25.toString();
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var25, var27, 0.05d, 10.0d);
    var20.setHorizontalAlignment(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var26.equals("HorizontalAlignment.CENTER"));

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.plot.PolarPlot var4 = new org.jfree.chart.plot.PolarPlot();
//     var4.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleAnchor var11 = null;
//     java.awt.geom.Point2D var12 = org.jfree.chart.util.RectangleAnchor.coordinates(var10, var11);
//     var4.zoomDomainAxes(0.0d, (-1.0d), var9, var12);
//     org.jfree.chart.plot.PlotState var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var1.draw(var2, var3, var12, var14, var15);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setUpperMargin(1.0d);
    var0.configure();
    var0.setUpperMargin(0.0d);
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var2 = var1.getURLText();
    var1.setToolTipText("RectangleEdge.RIGHT");
    java.lang.Object var5 = var1.clone();
    double var6 = var1.getContentXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    java.util.List var71 = var54.getCategories();
    org.jfree.chart.util.SortOrder var72 = var54.getRowRenderingOrder();
    org.jfree.chart.annotations.CategoryAnnotation var73 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var74 = var54.removeAnnotation(var73);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.clearDomainMarkers();
    boolean var22 = var19.isDomainGridlinesVisible();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var25 = var24.getTextAlignment();
    var24.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
    var24.setPadding(var28);
    double var31 = var28.trimHeight(0.05d);
    var19.setInsets(var28, true);
    var19.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1.95d));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var0.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainAxes();
    var19.clearDomainMarkers();
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = var19.getRenderer((-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    float var1 = var0.getTickMarkOutsideLength();
    org.jfree.chart.axis.NumberTickUnit var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    java.awt.Paint var3 = var1.getTickLabelPaint();
    var1.setLabel("Multiple Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainMarkers();
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
//     var23.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleAnchor var30 = null;
//     java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
//     var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
//     var19.zoomRangeAxes(100.0d, var22, var31);
//     float var34 = var19.getBackgroundImageAlpha();
//     org.jfree.chart.plot.Plot var35 = var19.getRootPlot();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     java.awt.Paint var42 = var38.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var43 = null;
//     var38.setURLGenerator(var43);
//     java.awt.Stroke var46 = var38.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var48 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var38.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var48);
//     boolean var50 = var36.equals((java.lang.Object)var38);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var55 = null;
//     java.awt.Rectangle var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     java.awt.geom.AffineTransform var58 = null;
//     java.awt.RenderingHints var59 = null;
//     java.awt.PaintContext var60 = var54.createContext(var55, var56, var57, var58, var59);
//     java.awt.color.ColorSpace var61 = var54.getColorSpace();
//     var38.setNoDataMessagePaint((java.awt.Paint)var54);
//     var35.setParent((org.jfree.chart.plot.Plot)var38);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var48
//     assertTrue("Contract failed: equals-hashcode on var15 and var48", var15.equals(var48) ? var15.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var15
//     assertTrue("Contract failed: equals-hashcode on var48 and var15", var48.equals(var15) ? var48.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test433() {}
//   public void test433() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.axis.NumberAxis3D var21 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var22 = null;
//     org.jfree.chart.plot.PiePlot var23 = new org.jfree.chart.plot.PiePlot(var22);
//     var23.setLabelGap((-1.0d));
//     java.lang.Object var26 = var23.clone();
//     java.awt.Paint var27 = var23.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var28 = null;
//     var23.setURLGenerator(var28);
//     java.awt.Stroke var31 = var23.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var33 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var23.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var33);
//     boolean var35 = var21.equals((java.lang.Object)var23);
//     java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var40 = null;
//     java.awt.Rectangle var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     java.awt.geom.AffineTransform var43 = null;
//     java.awt.RenderingHints var44 = null;
//     java.awt.PaintContext var45 = var39.createContext(var40, var41, var42, var43, var44);
//     java.awt.color.ColorSpace var46 = var39.getColorSpace();
//     var23.setNoDataMessagePaint((java.awt.Paint)var39);
//     org.jfree.chart.block.LineBorder var48 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var49 = var48.getPaint();
//     java.awt.Stroke var50 = var48.getStroke();
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var39, var50);
//     java.awt.Color var55 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var56 = null;
//     java.awt.Rectangle var57 = null;
//     java.awt.geom.Rectangle2D var58 = null;
//     java.awt.geom.AffineTransform var59 = null;
//     java.awt.RenderingHints var60 = null;
//     java.awt.PaintContext var61 = var55.createContext(var56, var57, var58, var59, var60);
//     java.awt.color.ColorSpace var62 = var55.getColorSpace();
//     var51.setPaint((java.awt.Paint)var55);
//     var19.setRangeZeroBaselinePaint((java.awt.Paint)var55);
//     
//     // Checks the contract:  equals-hashcode on var8 and var26
//     assertTrue("Contract failed: equals-hashcode on var8 and var26", var8.equals(var26) ? var8.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var8
//     assertTrue("Contract failed: equals-hashcode on var26 and var8", var26.equals(var8) ? var26.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var33
//     assertTrue("Contract failed: equals-hashcode on var15 and var33", var15.equals(var33) ? var15.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var15
//     assertTrue("Contract failed: equals-hashcode on var33 and var15", var33.equals(var15) ? var33.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
//     var22.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     var22.setPadding(var26);
//     double var29 = var26.trimHeight(0.05d);
//     var20.setLegendItemGraphicPadding(var26);
//     java.awt.Font var31 = var20.getItemFont();
//     java.awt.Graphics2D var32 = null;
//     java.awt.geom.Rectangle2D var33 = null;
//     var20.draw(var32, var33);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 3.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 0.5f};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var4 = var3.getTextAlignment();
//     var3.setHeight(1.0d);
//     double var7 = var3.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var9 = var8.getLabelFont();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Paint var13 = null;
//     var12.setLabelShadowPaint(var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     var18.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.PiePlotState var29 = var12.initialise(var15, var16, var18, (java.lang.Integer)0, var28);
//     java.awt.Paint var30 = var12.getLabelOutlinePaint();
//     var12.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Paint var37 = var34.getLabelOutlinePaint();
//     var12.setOutlinePaint(var37);
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var9, var37);
//     org.jfree.chart.text.TextLine var40 = new org.jfree.chart.text.TextLine("poly", var9);
//     org.jfree.chart.text.TextFragment var41 = var40.getLastTextFragment();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.text.TextAnchor var43 = null;
//     float var44 = var41.calculateBaselineOffset(var42, var43);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.event.ChartChangeEvent var11 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1);
    org.jfree.chart.event.ChartChangeEventType var12 = null;
    var11.setType(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var15 = var14.getTextAlignment();
//     var14.setHeight(1.0d);
//     double var18 = var14.getContentXOffset();
//     java.lang.Object var19 = var14.clone();
//     double var20 = var14.getContentYOffset();
//     var11.setTitle(var14);
//     org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var24 = var23.getTextAlignment();
//     org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var27 = var26.getTextAlignment();
//     var23.setHorizontalAlignment(var27);
//     var23.setText("");
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     var33.setLabelGap((-1.0d));
//     java.lang.Object var36 = var33.clone();
//     var33.setShadowXOffset((-1.0d));
//     var33.setShadowXOffset(10.0d);
//     boolean var41 = var33.getSimpleLabels();
//     java.awt.Stroke var42 = var33.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var33);
//     org.jfree.chart.plot.Plot var44 = var43.getPlot();
//     java.awt.RenderingHints var45 = var43.getRenderingHints();
//     org.jfree.chart.event.ChartChangeEventType var46 = null;
//     org.jfree.chart.event.ChartChangeEvent var47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)100, var43, var46);
//     var23.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var43);
//     java.awt.RenderingHints var49 = var43.getRenderingHints();
//     var11.setRenderingHints(var49);
//     
//     // Checks the contract:  equals-hashcode on var1 and var33
//     assertTrue("Contract failed: equals-hashcode on var1 and var33", var1.equals(var33) ? var1.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var1
//     assertTrue("Contract failed: equals-hashcode on var33 and var1", var33.equals(var1) ? var33.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var36
//     assertTrue("Contract failed: equals-hashcode on var4 and var36", var4.equals(var36) ? var4.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var4
//     assertTrue("Contract failed: equals-hashcode on var36 and var4", var36.equals(var4) ? var36.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var44
//     assertTrue("Contract failed: equals-hashcode on var12 and var44", var12.equals(var44) ? var12.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var12
//     assertTrue("Contract failed: equals-hashcode on var44 and var12", var44.equals(var12) ? var44.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.axis.NumberAxis3D var23 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var24 = var23.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var25 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var26 = null;
//     org.jfree.chart.plot.PiePlot var27 = new org.jfree.chart.plot.PiePlot(var26);
//     var27.setLabelGap((-1.0d));
//     java.lang.Object var30 = var27.clone();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var32 = null;
//     var27.setURLGenerator(var32);
//     java.awt.Stroke var35 = var27.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var37 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var27.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var37);
//     boolean var39 = var25.equals((java.lang.Object)var27);
//     org.jfree.chart.renderer.xy.XYItemRenderer var40 = null;
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot(var22, (org.jfree.chart.axis.ValueAxis)var23, (org.jfree.chart.axis.ValueAxis)var25, var40);
//     org.jfree.chart.util.RectangleEdge var43 = var41.getRangeAxisEdge(100);
//     boolean var44 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var43);
//     java.lang.String var45 = var43.toString();
//     java.awt.Image var49 = null;
//     org.jfree.chart.ui.ProjectInfo var53 = new org.jfree.chart.ui.ProjectInfo("", "org.jfree.chart.event.ChartProgressEvent[source=-1.0]", "java.awt.Color[r=255,g=255,b=254]", var49, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "java.awt.Color[r=255,g=255,b=254]", "");
//     java.awt.Image var54 = null;
//     var53.setLogo(var54);
//     java.util.List var56 = var53.getContributors();
//     org.jfree.chart.ui.Library[] var57 = var53.getLibraries();
//     boolean var58 = var43.equals((java.lang.Object)var57);
//     org.jfree.chart.util.RectangleEdge var59 = org.jfree.chart.util.RectangleEdge.opposite(var43);
//     var20.setLegendItemGraphicEdge(var43);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    var0.setTickMarkOutsideLength(1.0f);
    float var3 = var0.getTickMarkOutsideLength();
    java.awt.Color var7 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    java.awt.geom.AffineTransform var11 = null;
    java.awt.RenderingHints var12 = null;
    java.awt.PaintContext var13 = var7.createContext(var8, var9, var10, var11, var12);
    java.lang.String var14 = var7.toString();
    float[] var15 = null;
    float[] var16 = var7.getRGBComponents(var15);
    var0.setAxisLinePaint((java.awt.Paint)var7);
    var0.setTickMarkInsideLength((-1.0f));
    org.jfree.chart.axis.NumberTickUnit var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var20, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var14.equals("java.awt.Color[r=255,g=255,b=254]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainMarkers();
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
    var23.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleAnchor var30 = null;
    java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
    var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
    var19.zoomRangeAxes(100.0d, var22, var31);
    java.awt.Paint var35 = var19.getQuadrantPaint(1);
    var19.clearRangeMarkers();
    org.jfree.chart.axis.ValueAxis var37 = null;
    var19.setRangeAxis(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     var0.setDarkerSides(false);
//     var0.setDarkerSides(true);
//     java.awt.Paint var5 = var0.getOutlinePaint();
//     java.awt.Paint[] var6 = new java.awt.Paint[] { var5};
//     java.awt.Paint[] var7 = null;
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     java.awt.Paint var10 = null;
//     var9.setLabelShadowPaint(var10);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.data.general.PieDataset var14 = null;
//     org.jfree.chart.plot.PiePlot var15 = new org.jfree.chart.plot.PiePlot(var14);
//     var15.setLabelGap((-1.0d));
//     java.lang.Object var18 = var15.clone();
//     java.awt.Paint var19 = var15.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var20 = null;
//     var15.setURLGenerator(var20);
//     var15.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     org.jfree.chart.plot.PiePlotState var26 = var9.initialise(var12, var13, var15, (java.lang.Integer)0, var25);
//     java.awt.Paint var27 = var9.getLabelOutlinePaint();
//     var9.setSimpleLabels(true);
//     java.awt.Stroke var30 = var9.getLabelOutlineStroke();
//     java.awt.Stroke var31 = var9.getBaseSectionOutlineStroke();
//     java.awt.Stroke[] var32 = new java.awt.Stroke[] { var31};
//     org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var35 = var34.clone();
//     java.awt.Stroke var36 = var34.getStroke();
//     java.awt.Stroke[] var37 = new java.awt.Stroke[] { var36};
//     org.jfree.chart.axis.NumberAxis3D var38 = new org.jfree.chart.axis.NumberAxis3D();
//     float var39 = var38.getTickMarkOutsideLength();
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     java.awt.Shape var45 = var41.getLegendItemShape();
//     var38.setUpArrow(var45);
//     java.awt.Shape[] var47 = new java.awt.Shape[] { var45};
//     org.jfree.chart.plot.DefaultDrawingSupplier var48 = new org.jfree.chart.plot.DefaultDrawingSupplier(var6, var7, var32, var37, var47);
//     
//     // Checks the contract:  equals-hashcode on var18 and var44
//     assertTrue("Contract failed: equals-hashcode on var18 and var44", var18.equals(var44) ? var18.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var18
//     assertTrue("Contract failed: equals-hashcode on var44 and var18", var44.equals(var18) ? var44.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setRangeAxisLocation(4, var23, false);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
//     org.jfree.chart.plot.ValueMarker var28 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var29 = var28.getPaint();
//     boolean var30 = var26.equals((java.lang.Object)var29);
//     org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(var29);
//     java.awt.Paint var32 = var31.getPaint();
//     java.awt.Graphics2D var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var31.draw(var33, var34);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     var19.clearDomainAxes();
//     var19.clearDomainMarkers();
//     boolean var22 = var19.isDomainGridlinesVisible();
//     org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var25 = var24.getTextAlignment();
//     var24.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     var24.setPadding(var28);
//     double var31 = var28.trimHeight(0.05d);
//     var19.setInsets(var28, true);
//     org.jfree.data.xy.XYDataset var34 = null;
//     org.jfree.chart.axis.NumberAxis3D var35 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     var37.setLabelGap((-1.0d));
//     java.lang.Object var40 = var37.clone();
//     java.awt.Paint var41 = var37.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var42 = null;
//     var37.setURLGenerator(var42);
//     java.awt.Stroke var45 = var37.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var47 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var37.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var47);
//     boolean var49 = var35.equals((java.lang.Object)var37);
//     var35.configure();
//     var35.setTickMarkInsideLength(2.0f);
//     org.jfree.chart.renderer.PolarItemRenderer var53 = null;
//     org.jfree.chart.plot.PolarPlot var54 = new org.jfree.chart.plot.PolarPlot(var34, (org.jfree.chart.axis.ValueAxis)var35, var53);
//     org.jfree.data.xy.XYDataset var55 = null;
//     var54.setDataset(var55);
//     org.jfree.chart.plot.PlotOrientation var57 = var54.getOrientation();
//     java.lang.String var58 = var57.toString();
//     var19.setOrientation(var57);
//     
//     // Checks the contract:  equals-hashcode on var5 and var37
//     assertTrue("Contract failed: equals-hashcode on var5 and var37", var5.equals(var37) ? var5.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var5
//     assertTrue("Contract failed: equals-hashcode on var37 and var5", var37.equals(var5) ? var37.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var40
//     assertTrue("Contract failed: equals-hashcode on var8 and var40", var8.equals(var40) ? var8.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var8
//     assertTrue("Contract failed: equals-hashcode on var40 and var8", var40.equals(var8) ? var40.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var47
//     assertTrue("Contract failed: equals-hashcode on var15 and var47", var15.equals(var47) ? var15.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var15
//     assertTrue("Contract failed: equals-hashcode on var47 and var15", var47.equals(var15) ? var47.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var4 = null;
//     java.awt.Rectangle var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.AffineTransform var7 = null;
//     java.awt.RenderingHints var8 = null;
//     java.awt.PaintContext var9 = var3.createContext(var4, var5, var6, var7, var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.awt.Stroke var14 = var11.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var17 = var16.getTextAlignment();
//     var16.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets();
//     var16.setPadding(var20);
//     org.jfree.chart.block.LineBorder var22 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var14, var20);
//     java.awt.color.ColorSpace var23 = var3.getColorSpace();
//     org.jfree.chart.block.BlockBorder var24 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var3);
//     org.jfree.chart.axis.NumberAxis3D var26 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.PiePlot var28 = new org.jfree.chart.plot.PiePlot(var27);
//     var28.setLabelGap((-1.0d));
//     java.lang.Object var31 = var28.clone();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var33 = null;
//     var28.setURLGenerator(var33);
//     java.awt.Stroke var36 = var28.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var28.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var38);
//     boolean var40 = var26.equals((java.lang.Object)var28);
//     java.awt.Color var44 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var45 = null;
//     java.awt.Rectangle var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     java.awt.geom.AffineTransform var48 = null;
//     java.awt.RenderingHints var49 = null;
//     java.awt.PaintContext var50 = var44.createContext(var45, var46, var47, var48, var49);
//     java.awt.color.ColorSpace var51 = var44.getColorSpace();
//     var28.setNoDataMessagePaint((java.awt.Paint)var44);
//     org.jfree.chart.block.LineBorder var53 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var54 = var53.getPaint();
//     java.awt.Stroke var55 = var53.getStroke();
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var44, var55);
//     java.awt.Color var60 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var61 = null;
//     java.awt.Rectangle var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     java.awt.geom.AffineTransform var64 = null;
//     java.awt.RenderingHints var65 = null;
//     java.awt.PaintContext var66 = var60.createContext(var61, var62, var63, var64, var65);
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot(var67);
//     var68.setLabelGap((-1.0d));
//     java.awt.Stroke var71 = var68.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var74 = var73.getTextAlignment();
//     var73.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var77 = new org.jfree.chart.util.RectangleInsets();
//     var73.setPadding(var77);
//     org.jfree.chart.block.LineBorder var79 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var60, var71, var77);
//     java.awt.Color var83 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var84 = null;
//     java.awt.Rectangle var85 = null;
//     java.awt.geom.Rectangle2D var86 = null;
//     java.awt.geom.AffineTransform var87 = null;
//     java.awt.RenderingHints var88 = null;
//     java.awt.PaintContext var89 = var83.createContext(var84, var85, var86, var87, var88);
//     java.lang.String var90 = var83.toString();
//     float[] var91 = null;
//     float[] var92 = var83.getRGBComponents(var91);
//     float[] var93 = var60.getRGBColorComponents(var92);
//     float[] var94 = var44.getComponents(var93);
//     float[] var95 = var3.getRGBComponents(var93);
//     
//     // Checks the contract:  equals-hashcode on var11 and var68
//     assertTrue("Contract failed: equals-hashcode on var11 and var68", var11.equals(var68) ? var11.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var11
//     assertTrue("Contract failed: equals-hashcode on var68 and var11", var68.equals(var11) ? var68.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var79
//     assertTrue("Contract failed: equals-hashcode on var22 and var79", var22.equals(var79) ? var22.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var22
//     assertTrue("Contract failed: equals-hashcode on var79 and var22", var79.equals(var22) ? var79.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.data.xy.XYDataset var55 = null;
//     org.jfree.chart.axis.NumberAxis3D var56 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var57 = var56.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var58 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.PiePlot var60 = new org.jfree.chart.plot.PiePlot(var59);
//     var60.setLabelGap((-1.0d));
//     java.lang.Object var63 = var60.clone();
//     java.awt.Paint var64 = var60.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var65 = null;
//     var60.setURLGenerator(var65);
//     java.awt.Stroke var68 = var60.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var70 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var60.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var70);
//     boolean var72 = var58.equals((java.lang.Object)var60);
//     org.jfree.chart.renderer.xy.XYItemRenderer var73 = null;
//     org.jfree.chart.plot.XYPlot var74 = new org.jfree.chart.plot.XYPlot(var55, (org.jfree.chart.axis.ValueAxis)var56, (org.jfree.chart.axis.ValueAxis)var58, var73);
//     java.awt.Paint var75 = var74.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.AxisLocation var77 = var74.getDomainAxisLocation((-1));
//     var54.setDomainAxisLocation(var77, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var63
//     assertTrue("Contract failed: equals-hashcode on var16 and var63", var16.equals(var63) ? var16.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var16
//     assertTrue("Contract failed: equals-hashcode on var63 and var16", var63.equals(var16) ? var63.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     java.awt.Shape var2 = var1.getLeftArrow();
//     var1.setRange(100.0d, Double.POSITIVE_INFINITY);
//     var1.resizeRange(0.08d);
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     var8.setUpperMargin(1.0d);
//     boolean var11 = var8.isTickMarksVisible();
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     var13.setLabelLinkMargin((-1.0d));
//     java.awt.Paint var19 = var13.getBaseSectionPaint();
//     boolean var20 = var8.hasListener((java.util.EventListener)var13);
//     boolean var21 = var1.equals((java.lang.Object)var20);
//     java.util.Date var22 = null;
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var24.configure();
//     java.text.DateFormat var26 = var24.getDateFormatOverride();
//     org.jfree.chart.axis.DateTickMarkPosition var27 = var24.getTickMarkPosition();
//     var24.setLabelURL("java.awt.Color[r=255,g=255,b=254]");
//     org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     java.awt.Shape var32 = var31.getLeftArrow();
//     var31.setRange(100.0d, Double.POSITIVE_INFINITY);
//     org.jfree.chart.axis.DateTickUnit var36 = var31.getTickUnit();
//     java.util.Date var37 = var24.calculateLowestVisibleTickValue(var36);
//     var1.setRange(var22, var37);
// 
//   }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("hi!");
    java.lang.String var2 = var1.getURLText();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.draw(var3, var4);
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setPaint(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.plot.ValueMarker var5 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//     org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var8 = var7.getLabelTextAnchor();
//     var5.setLabelTextAnchor(var8);
//     org.jfree.chart.plot.ValueMarker var12 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextAnchor var13 = var12.getLabelTextAnchor();
//     java.awt.Shape var14 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Multiple Pie Plot", var1, 0.0f, 0.5f, var8, 0.14d, var13);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
//     var22.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     var22.setPadding(var26);
//     double var29 = var26.trimHeight(0.05d);
//     var20.setLegendItemGraphicPadding(var26);
//     double var32 = var26.calculateTopInset(0.14d);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Paint var37 = var34.getLabelOutlinePaint();
//     var34.setBackgroundImageAlignment(10);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     var41.setShadowXOffset((-1.0d));
//     var41.setShadowXOffset(10.0d);
//     boolean var49 = var41.getSimpleLabels();
//     java.awt.Stroke var50 = var41.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var51 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     org.jfree.chart.plot.Plot var52 = var51.getPlot();
//     java.awt.RenderingHints var53 = var51.getRenderingHints();
//     var34.addChangeListener((org.jfree.chart.event.PlotChangeListener)var51);
//     org.jfree.chart.event.ChartProgressEvent var57 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var26, var51, 15, 1);
//     
//     // Checks the contract:  equals-hashcode on var1 and var41
//     assertTrue("Contract failed: equals-hashcode on var1 and var41", var1.equals(var41) ? var1.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var1
//     assertTrue("Contract failed: equals-hashcode on var41 and var1", var41.equals(var1) ? var41.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var44
//     assertTrue("Contract failed: equals-hashcode on var4 and var44", var4.equals(var44) ? var4.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var4
//     assertTrue("Contract failed: equals-hashcode on var44 and var4", var44.equals(var4) ? var44.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var52
//     assertTrue("Contract failed: equals-hashcode on var12 and var52", var12.equals(var52) ? var12.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var12
//     assertTrue("Contract failed: equals-hashcode on var52 and var12", var52.equals(var12) ? var52.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var57 = var56.clone();
//     org.jfree.chart.event.MarkerChangeEvent var58 = null;
//     var56.notifyListeners(var58);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var63 = var61.getTickLabelPaint((java.lang.Comparable)255);
//     var56.setLabelPaint(var63);
//     var54.addRangeMarker((org.jfree.chart.plot.Marker)var56);
//     org.jfree.chart.plot.ValueMarker var67 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var68 = var67.clone();
//     boolean var69 = var54.removeDomainMarker((org.jfree.chart.plot.Marker)var67);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var24 = null;
    java.awt.Rectangle var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    java.awt.geom.AffineTransform var27 = null;
    java.awt.RenderingHints var28 = null;
    java.awt.PaintContext var29 = var23.createContext(var24, var25, var26, var27, var28);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.PiePlot var31 = new org.jfree.chart.plot.PiePlot(var30);
    var31.setLabelGap((-1.0d));
    java.awt.Stroke var34 = var31.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var37 = var36.getTextAlignment();
    var36.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var40 = new org.jfree.chart.util.RectangleInsets();
    var36.setPadding(var40);
    org.jfree.chart.block.LineBorder var42 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var23, var34, var40);
    java.lang.String var43 = var23.toString();
    var11.setBackgroundPaint((java.awt.Paint)var23);
    var11.removeLegend();
    var11.setTitle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var11.setTitle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "java.awt.Color[r=255,g=255,b=254]"+ "'", var43.equals("java.awt.Color[r=255,g=255,b=254]"));

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.plot.PlotRenderingInfo var0 = null;
    org.jfree.chart.renderer.RendererState var1 = new org.jfree.chart.renderer.RendererState(var0);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
    org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
    java.lang.String var23 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "VerticalAlignment.CENTER"+ "'", var23.equals("VerticalAlignment.CENTER"));

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    var19.clearDomainMarkers();
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot();
    var23.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleAnchor var30 = null;
    java.awt.geom.Point2D var31 = org.jfree.chart.util.RectangleAnchor.coordinates(var29, var30);
    var23.zoomDomainAxes(0.0d, (-1.0d), var28, var31);
    var19.zoomRangeAxes(100.0d, var22, var31);
    java.awt.Paint var35 = var19.getQuadrantPaint(1);
    var19.clearRangeMarkers();
    org.jfree.chart.renderer.xy.XYItemRenderer var37 = null;
    int var38 = var19.getIndexOf(var37);
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
    int var40 = var19.getIndexOf(var39);
    org.jfree.chart.annotations.XYAnnotation var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var42 = var19.removeAnnotation(var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.general.WaferMapDataset var0 = null;
    org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
    org.jfree.chart.event.RendererChangeEvent var2 = null;
    var1.rendererChanged(var2);
    var1.setBackgroundImageAlpha(0.0f);
    java.lang.String var6 = var1.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "WMAP_Plot"+ "'", var6.equals("WMAP_Plot"));

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var1.configure();
//     var1.setRange((-1.0d), 0.05d);
//     org.jfree.data.xy.XYDataset var6 = null;
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var8 = var7.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     var11.setLabelGap((-1.0d));
//     java.lang.Object var14 = var11.clone();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var16 = null;
//     var11.setURLGenerator(var16);
//     java.awt.Stroke var19 = var11.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var11.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
//     boolean var23 = var9.equals((java.lang.Object)var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var24 = null;
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot(var6, (org.jfree.chart.axis.ValueAxis)var7, (org.jfree.chart.axis.ValueAxis)var9, var24);
//     var25.clearDomainAxes();
//     var25.clearDomainMarkers();
//     boolean var28 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisLocation var30 = var25.getRangeAxisLocation(15);
//     boolean var31 = var1.equals((java.lang.Object)var25);
//     java.awt.Stroke var32 = var25.getDomainGridlineStroke();
//     org.jfree.chart.axis.NumberAxis3D var33 = new org.jfree.chart.axis.NumberAxis3D();
//     var33.setTickMarkOutsideLength(1.0f);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.PiePlot var37 = new org.jfree.chart.plot.PiePlot(var36);
//     java.awt.Paint var38 = null;
//     var37.setLabelShadowPaint(var38);
//     java.awt.Graphics2D var40 = null;
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.data.general.PieDataset var42 = null;
//     org.jfree.chart.plot.PiePlot var43 = new org.jfree.chart.plot.PiePlot(var42);
//     var43.setLabelGap((-1.0d));
//     java.lang.Object var46 = var43.clone();
//     java.awt.Paint var47 = var43.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var48 = null;
//     var43.setURLGenerator(var48);
//     var43.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     org.jfree.chart.plot.PiePlotState var54 = var37.initialise(var40, var41, var43, (java.lang.Integer)0, var53);
//     java.awt.Paint var55 = var37.getLabelOutlinePaint();
//     var33.setAxisLinePaint(var55);
//     java.awt.Color var60 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var61 = null;
//     java.awt.Rectangle var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     java.awt.geom.AffineTransform var64 = null;
//     java.awt.RenderingHints var65 = null;
//     java.awt.PaintContext var66 = var60.createContext(var61, var62, var63, var64, var65);
//     org.jfree.data.general.PieDataset var67 = null;
//     org.jfree.chart.plot.PiePlot var68 = new org.jfree.chart.plot.PiePlot(var67);
//     var68.setLabelGap((-1.0d));
//     java.awt.Stroke var71 = var68.getLabelLinkStroke();
//     org.jfree.chart.title.TextTitle var73 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var74 = var73.getTextAlignment();
//     var73.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var77 = new org.jfree.chart.util.RectangleInsets();
//     var73.setPadding(var77);
//     org.jfree.chart.block.LineBorder var79 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var60, var71, var77);
//     org.jfree.chart.JFreeChart var80 = null;
//     org.jfree.chart.event.ChartChangeEventType var81 = null;
//     org.jfree.chart.event.ChartChangeEvent var82 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var79, var80, var81);
//     java.awt.Stroke var83 = var79.getStroke();
//     org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var86 = var85.getTextAlignment();
//     var85.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var89 = new org.jfree.chart.util.RectangleInsets();
//     var85.setPadding(var89);
//     org.jfree.chart.block.LineBorder var91 = new org.jfree.chart.block.LineBorder(var55, var83, var89);
//     var25.setDomainCrosshairStroke(var83);
//     
//     // Checks the contract:  equals-hashcode on var14 and var46
//     assertTrue("Contract failed: equals-hashcode on var14 and var46", var14.equals(var46) ? var14.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var14
//     assertTrue("Contract failed: equals-hashcode on var46 and var14", var46.equals(var14) ? var46.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var58 = var57.clone();
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var57.notifyListeners(var59);
    org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
    var57.setLabelPaint(var64);
    var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.chart.util.Layer var68 = null;
    var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
    org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
    java.util.List var71 = var54.getCategories();
    org.jfree.chart.axis.AxisLocation var72 = var54.getDomainAxisLocation();
    org.jfree.chart.plot.CategoryMarker var73 = null;
    org.jfree.chart.util.Layer var74 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.addDomainMarker(var73, var74);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var1.setTickMarkOutsideLength(1.0f);
    java.awt.Font var4 = var1.getLabelFont();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
    java.awt.Paint var7 = null;
    var6.setLabelShadowPaint(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
    var12.setLabelGap((-1.0d));
    java.lang.Object var15 = var12.clone();
    java.awt.Paint var16 = var12.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var17 = null;
    var12.setURLGenerator(var17);
    var12.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    org.jfree.chart.plot.PiePlotState var23 = var6.initialise(var9, var10, var12, (java.lang.Integer)0, var22);
    org.jfree.data.general.PieDataset var24 = null;
    org.jfree.chart.plot.PiePlot var25 = new org.jfree.chart.plot.PiePlot(var24);
    var25.setLabelGap((-1.0d));
    java.awt.Font var28 = var25.getLabelFont();
    var12.setNoDataMessageFont(var28);
    boolean var30 = var1.equals((java.lang.Object)var12);
    var12.setSimpleLabels(false);
    org.jfree.chart.urls.PieURLGenerator var33 = null;
    var12.setURLGenerator(var33);
    var12.setLabelLinkMargin(1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.getObject("RectangleAnchor.CENTER");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    java.awt.Paint var6 = var1.getNoDataMessagePaint();
    java.awt.Color var10 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    java.awt.image.ColorModel var11 = null;
    java.awt.Rectangle var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    java.awt.geom.AffineTransform var14 = null;
    java.awt.RenderingHints var15 = null;
    java.awt.PaintContext var16 = var10.createContext(var11, var12, var13, var14, var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
    var18.setLabelGap((-1.0d));
    java.awt.Stroke var21 = var18.getLabelLinkStroke();
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var24 = var23.getTextAlignment();
    var23.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var27 = new org.jfree.chart.util.RectangleInsets();
    var23.setPadding(var27);
    org.jfree.chart.block.LineBorder var29 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var21, var27);
    java.awt.color.ColorSpace var30 = var10.getColorSpace();
    var1.setBackgroundPaint((java.awt.Paint)var10);
    boolean var32 = var1.isOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setRangeAxisLocation(4, var23, false);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var26.draw(var27, var28);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     int var28 = var19.getRangeAxisCount();
//     org.jfree.chart.axis.ValueAxis var30 = var19.getDomainAxis(4);
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.axis.NumberAxis3D var34 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var35 = var34.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     java.awt.Paint var42 = var38.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var43 = null;
//     var38.setURLGenerator(var43);
//     java.awt.Stroke var46 = var38.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var48 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var38.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var48);
//     boolean var50 = var36.equals((java.lang.Object)var38);
//     org.jfree.chart.renderer.xy.XYItemRenderer var51 = null;
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot(var33, (org.jfree.chart.axis.ValueAxis)var34, (org.jfree.chart.axis.ValueAxis)var36, var51);
//     org.jfree.data.Range var53 = var34.getDefaultAutoRange();
//     var32.setRange(var53);
//     var32.setRangeAboutValue(0.05d, 100.0d);
//     org.jfree.chart.axis.Timeline var58 = var32.getTimeline();
//     int var59 = var19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var38
//     assertTrue("Contract failed: equals-hashcode on var5 and var38", var5.equals(var38) ? var5.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var5
//     assertTrue("Contract failed: equals-hashcode on var38 and var5", var38.equals(var5) ? var38.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var48
//     assertTrue("Contract failed: equals-hashcode on var15 and var48", var15.equals(var48) ? var15.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var15
//     assertTrue("Contract failed: equals-hashcode on var48 and var15", var48.equals(var15) ? var48.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    org.jfree.data.xy.XYDataset var3 = null;
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var5 = var4.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var6 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setLabelGap((-1.0d));
    java.lang.Object var11 = var8.clone();
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var8.setURLGenerator(var13);
    java.awt.Stroke var16 = var8.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var18 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var8.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var18);
    boolean var20 = var6.equals((java.lang.Object)var8);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot(var3, (org.jfree.chart.axis.ValueAxis)var4, (org.jfree.chart.axis.ValueAxis)var6, var21);
    org.jfree.data.Range var23 = var4.getDefaultAutoRange();
    var2.setRange(var23);
    org.jfree.data.Range var25 = null;
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var25, 100.0d);
    org.jfree.chart.block.RectangleConstraint var28 = var27.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var29 = var28.getHeightConstraintType();
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 0.0d);
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var31, 1.0E-8d);
    double var36 = var35.getLength();
    org.jfree.data.Range var38 = org.jfree.data.Range.expandToInclude(var35, (-1.95d));
    double var39 = var38.getUpperBound();
    org.jfree.data.Range var40 = null;
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(var40, 100.0d);
    double var43 = var42.getWidth();
    org.jfree.chart.block.LengthConstraintType var44 = var42.getWidthConstraintType();
    org.jfree.chart.block.RectangleConstraint var45 = new org.jfree.chart.block.RectangleConstraint(0.0d, var23, var29, 10.0d, var38, var44);
    java.lang.String var46 = var29.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var46 + "' != '" + "LengthConstraintType.FIXED"+ "'", var46.equals("LengthConstraintType.FIXED"));

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
    var19.setDomainCrosshairValue(0.05d, false);
    int var28 = var19.getRangeAxisCount();
    org.jfree.chart.axis.ValueAxis var30 = var19.getDomainAxis(4);
    java.awt.Stroke var31 = var19.getRangeGridlineStroke();
    org.jfree.chart.util.RectangleInsets var32 = var19.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
    int var22 = var19.getDomainAxisCount();
    org.jfree.chart.axis.ValueAxis var23 = var19.getDomainAxis();
    org.jfree.chart.axis.AxisSpace var24 = var19.getFixedRangeAxisSpace();
    var19.zoom(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot var2 = new org.jfree.chart.plot.PiePlot(var1);
    java.awt.Paint var3 = null;
    var2.setLabelShadowPaint(var3);
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.data.general.PieDataset var7 = null;
    org.jfree.chart.plot.PiePlot var8 = new org.jfree.chart.plot.PiePlot(var7);
    var8.setLabelGap((-1.0d));
    java.lang.Object var11 = var8.clone();
    java.awt.Paint var12 = var8.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var13 = null;
    var8.setURLGenerator(var13);
    var8.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    org.jfree.chart.plot.PiePlotState var19 = var2.initialise(var5, var6, var8, (java.lang.Integer)0, var18);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.PiePlot var21 = new org.jfree.chart.plot.PiePlot(var20);
    var21.setLabelGap((-1.0d));
    java.awt.Font var24 = var21.getLabelFont();
    var8.setNoDataMessageFont(var24);
    org.jfree.chart.title.TextTitle var26 = new org.jfree.chart.title.TextTitle("", var24);
    java.awt.Font var27 = var26.getFont();
    var26.setID("");
    java.awt.Graphics2D var30 = null;
    org.jfree.data.Range var31 = null;
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(var31, 100.0d);
    org.jfree.chart.block.RectangleConstraint var34 = var33.toUnconstrainedWidth();
    org.jfree.chart.block.LengthConstraintType var35 = var34.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var37 = var34.toFixedWidth(1.0E-8d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var38 = var26.arrange(var30, var37);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var2 = var0.calculateTopInset(1.0d);
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var0.createInsetRectangle(var3, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.data.xy.XYDataset var4 = null;
//     org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var6 = var5.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var7 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var8 = null;
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot(var8);
//     var9.setLabelGap((-1.0d));
//     java.lang.Object var12 = var9.clone();
//     java.awt.Paint var13 = var9.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var14 = null;
//     var9.setURLGenerator(var14);
//     java.awt.Stroke var17 = var9.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var19 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var9.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var19);
//     boolean var21 = var7.equals((java.lang.Object)var9);
//     org.jfree.chart.renderer.xy.XYItemRenderer var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot(var4, (org.jfree.chart.axis.ValueAxis)var5, (org.jfree.chart.axis.ValueAxis)var7, var22);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var23.zoomRangeAxes(0.05d, 10.0d, var26, var27);
//     var23.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var33 = null;
//     java.util.Collection var34 = var23.getRangeMarkers(0, var33);
//     boolean var35 = var23.isDomainZoomable();
//     java.awt.Paint var36 = var23.getNoDataMessagePaint();
//     org.jfree.chart.plot.ValueMarker var39 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var40 = var39.getLabelPaint();
//     org.jfree.chart.util.Layer var41 = null;
//     var23.addRangeMarker(15, (org.jfree.chart.plot.Marker)var39, var41);
//     org.jfree.chart.text.TextAnchor var43 = var39.getLabelTextAnchor();
//     java.awt.geom.Rectangle2D var44 = org.jfree.chart.text.TextUtilities.drawAlignedString("Category Plot", var1, 0.0f, 1.0f, var43);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var2 = var1.getPercentFormat();
    java.text.NumberFormat var3 = var1.getNumberFormat();
    java.lang.String var4 = var1.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    org.jfree.chart.plot.Plot var2 = var1.getRootPlot();
    org.jfree.chart.urls.PieURLGenerator var3 = var1.getURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.awt.Paint var27 = var26.getLabelPaint();
//     org.jfree.chart.util.RectangleInsets var28 = new org.jfree.chart.util.RectangleInsets();
//     double var30 = var28.calculateRightOutset(10.0d);
//     var26.setLabelOffset(var28);
//     java.awt.Stroke var32 = var26.getStroke();
//     org.jfree.chart.util.Layer var33 = null;
//     var19.addRangeMarker((org.jfree.chart.plot.Marker)var26, var33);
//     java.awt.Stroke var35 = var26.getStroke();
//     java.lang.Object var36 = var26.clone();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     var38.setShadowXOffset((-1.0d));
//     var38.setShadowXOffset(10.0d);
//     boolean var46 = var38.getSimpleLabels();
//     java.awt.Stroke var47 = var38.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var38);
//     org.jfree.chart.plot.Plot var49 = var48.getPlot();
//     java.awt.RenderingHints var50 = var48.getRenderingHints();
//     java.awt.Color var54 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var55 = var54.getGreen();
//     var48.setBorderPaint((java.awt.Paint)var54);
//     org.jfree.chart.title.LegendTitle var57 = var48.getLegend();
//     java.awt.Paint var58 = var57.getBackgroundPaint();
//     var26.setOutlinePaint(var58);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.chart.LegendItemCollection var19 = var1.getLegendItems();
    int var20 = var19.getItemCount();
    java.util.Iterator var21 = var19.iterator();
    java.util.Iterator var22 = var19.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var2 = var1.getTextAlignment();
    var1.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setID("poly");
    var1.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    var2.setTickMarkOutsideLength(1.0f);
    java.awt.Font var5 = var2.getLabelFont();
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    java.awt.Paint var8 = null;
    var7.setLabelShadowPaint(var8);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
    var13.setLabelGap((-1.0d));
    java.lang.Object var16 = var13.clone();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var18 = null;
    var13.setURLGenerator(var18);
    var13.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var23 = null;
    org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
    org.jfree.data.general.PieDataset var25 = null;
    org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
    var26.setLabelGap((-1.0d));
    java.awt.Font var29 = var26.getLabelFont();
    var13.setNoDataMessageFont(var29);
    boolean var31 = var2.equals((java.lang.Object)var13);
    var2.setMaximumCategoryLabelLines(254);
    var2.setCategoryMargin(0.12d);
    java.lang.Object var36 = null;
    boolean var37 = var2.equals(var36);
    org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
    var38.setAngleLabelsVisible(true);
    org.jfree.chart.plot.PlotRenderingInfo var43 = null;
    java.awt.geom.Rectangle2D var44 = null;
    org.jfree.chart.util.RectangleAnchor var45 = null;
    java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
    var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
    org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
    var49.configure();
    org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
    double var52 = var49.getUpperMargin();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
    org.jfree.chart.plot.ValueMarker var56 = new org.jfree.chart.plot.ValueMarker(0.0d);
    java.lang.Object var57 = var56.clone();
    org.jfree.chart.event.MarkerChangeEvent var58 = null;
    var56.notifyListeners(var58);
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    java.awt.Paint var63 = var61.getTickLabelPaint((java.lang.Comparable)255);
    var56.setLabelPaint(var63);
    var54.addRangeMarker((org.jfree.chart.plot.Marker)var56);
    org.jfree.chart.util.Layer var67 = null;
    java.util.Collection var68 = var54.getRangeMarkers(10, var67);
    org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    float var72 = var71.getMaximumCategoryLabelWidthRatio();
    double var73 = var71.getUpperMargin();
    java.awt.Paint var74 = var71.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var54.setDomainAxis((-2), var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var3 = var2.getTextAlignment();
//     var2.setHeight(1.0d);
//     double var6 = var2.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var8 = var7.getLabelFont();
//     boolean var9 = var2.equals((java.lang.Object)var8);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.PiePlot var11 = new org.jfree.chart.plot.PiePlot(var10);
//     java.awt.Paint var12 = null;
//     var11.setLabelShadowPaint(var12);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.plot.PiePlot var17 = new org.jfree.chart.plot.PiePlot(var16);
//     var17.setLabelGap((-1.0d));
//     java.lang.Object var20 = var17.clone();
//     java.awt.Paint var21 = var17.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var22 = null;
//     var17.setURLGenerator(var22);
//     var17.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.plot.PiePlotState var28 = var11.initialise(var14, var15, var17, (java.lang.Integer)0, var27);
//     java.awt.Paint var29 = var11.getLabelOutlinePaint();
//     var11.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var32 = null;
//     org.jfree.chart.plot.PiePlot var33 = new org.jfree.chart.plot.PiePlot(var32);
//     java.awt.Paint var34 = null;
//     var33.setLabelShadowPaint(var34);
//     java.awt.Paint var36 = var33.getLabelOutlinePaint();
//     var11.setOutlinePaint(var36);
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var8, var36);
//     org.jfree.chart.axis.NumberAxis3D var40 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot(var41);
//     var42.setLabelGap((-1.0d));
//     java.lang.Object var45 = var42.clone();
//     java.awt.Paint var46 = var42.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var47 = null;
//     var42.setURLGenerator(var47);
//     java.awt.Stroke var50 = var42.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var52 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var42.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var52);
//     boolean var54 = var40.equals((java.lang.Object)var42);
//     java.awt.Color var58 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var59 = null;
//     java.awt.Rectangle var60 = null;
//     java.awt.geom.Rectangle2D var61 = null;
//     java.awt.geom.AffineTransform var62 = null;
//     java.awt.RenderingHints var63 = null;
//     java.awt.PaintContext var64 = var58.createContext(var59, var60, var61, var62, var63);
//     java.awt.color.ColorSpace var65 = var58.getColorSpace();
//     var42.setNoDataMessagePaint((java.awt.Paint)var58);
//     org.jfree.chart.block.LineBorder var67 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var68 = var67.getPaint();
//     java.awt.Stroke var69 = var67.getStroke();
//     org.jfree.chart.plot.ValueMarker var70 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var58, var69);
//     int var71 = var58.getRGB();
//     boolean var72 = var38.equals((java.lang.Object)var71);
//     
//     // Checks the contract:  equals-hashcode on var20 and var45
//     assertTrue("Contract failed: equals-hashcode on var20 and var45", var20.equals(var45) ? var20.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var20
//     assertTrue("Contract failed: equals-hashcode on var45 and var20", var45.equals(var20) ? var45.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    java.awt.Paint var19 = var1.getLabelOutlinePaint();
    var1.setSimpleLabels(true);
    var1.setCircular(true);
    org.jfree.chart.urls.PieURLGenerator var24 = var1.getURLGenerator();
    java.awt.Stroke var26 = var1.getSectionOutlineStroke((java.lang.Comparable)"ChartEntity: tooltip = null");
    org.jfree.chart.util.RectangleInsets var27 = var1.getSimpleLabelOffset();
    java.awt.geom.Rectangle2D var28 = null;
    org.jfree.chart.util.LengthAdjustmentType var29 = null;
    org.jfree.chart.util.LengthAdjustmentType var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var31 = var27.createAdjustedRectangle(var28, var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var2 = var1.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var4 = null;
//     org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
//     var5.setLabelGap((-1.0d));
//     java.lang.Object var8 = var5.clone();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var10 = null;
//     var5.setURLGenerator(var10);
//     java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
//     boolean var17 = var3.equals((java.lang.Object)var5);
//     org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var22 = null;
//     java.awt.geom.Point2D var23 = null;
//     var19.zoomRangeAxes(0.05d, 10.0d, var22, var23);
//     var19.setDomainCrosshairValue(0.05d, false);
//     org.jfree.chart.util.Layer var29 = null;
//     java.util.Collection var30 = var19.getRangeMarkers(0, var29);
//     boolean var31 = var19.isDomainZoomable();
//     java.awt.Paint var32 = var19.getNoDataMessagePaint();
//     var19.configureDomainAxes();
//     var19.setBackgroundAlpha(100.0f);
//     var19.setOutlineVisible(true);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.PiePlot var39 = new org.jfree.chart.plot.PiePlot(var38);
//     java.awt.Paint var40 = null;
//     var39.setLabelShadowPaint(var40);
//     java.awt.Graphics2D var42 = null;
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.plot.PiePlot var45 = new org.jfree.chart.plot.PiePlot(var44);
//     var45.setLabelGap((-1.0d));
//     java.lang.Object var48 = var45.clone();
//     java.awt.Paint var49 = var45.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var50 = null;
//     var45.setURLGenerator(var50);
//     var45.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var55 = null;
//     org.jfree.chart.plot.PiePlotState var56 = var39.initialise(var42, var43, var45, (java.lang.Integer)0, var55);
//     org.jfree.chart.LegendItemCollection var57 = var39.getLegendItems();
//     java.lang.Object var58 = var57.clone();
//     var19.setFixedLegendItems(var57);
//     
//     // Checks the contract:  equals-hashcode on var8 and var48
//     assertTrue("Contract failed: equals-hashcode on var8 and var48", var8.equals(var48) ? var8.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var8
//     assertTrue("Contract failed: equals-hashcode on var48 and var8", var48.equals(var8) ? var48.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    var0.setUpperMargin(1.0d);
    boolean var3 = var0.isTickMarksVisible();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    var5.setLabelLinkMargin((-1.0d));
    java.awt.Paint var11 = var5.getBaseSectionPaint();
    boolean var12 = var0.hasListener((java.util.EventListener)var5);
    org.jfree.chart.urls.PieURLGenerator var13 = var5.getURLGenerator();
    org.jfree.chart.util.RectangleInsets var14 = var5.getSimpleLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("poly", var1, var2);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var4 = var3.getTextAlignment();
//     var3.setHeight(1.0d);
//     double var7 = var3.getContentXOffset();
//     org.jfree.chart.axis.NumberAxis var8 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var9 = var8.getLabelFont();
//     boolean var10 = var3.equals((java.lang.Object)var9);
//     org.jfree.data.general.PieDataset var11 = null;
//     org.jfree.chart.plot.PiePlot var12 = new org.jfree.chart.plot.PiePlot(var11);
//     java.awt.Paint var13 = null;
//     var12.setLabelShadowPaint(var13);
//     java.awt.Graphics2D var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.PiePlot var18 = new org.jfree.chart.plot.PiePlot(var17);
//     var18.setLabelGap((-1.0d));
//     java.lang.Object var21 = var18.clone();
//     java.awt.Paint var22 = var18.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var23 = null;
//     var18.setURLGenerator(var23);
//     var18.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.plot.PiePlotState var29 = var12.initialise(var15, var16, var18, (java.lang.Integer)0, var28);
//     java.awt.Paint var30 = var12.getLabelOutlinePaint();
//     var12.setSimpleLabels(true);
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Paint var37 = var34.getLabelOutlinePaint();
//     var12.setOutlinePaint(var37);
//     org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("org.jfree.chart.event.ChartProgressEvent[source=-1.0]", var9, var37);
//     org.jfree.data.general.PieDataset var40 = null;
//     org.jfree.chart.plot.PiePlot var41 = new org.jfree.chart.plot.PiePlot(var40);
//     var41.setLabelGap((-1.0d));
//     java.lang.Object var44 = var41.clone();
//     java.awt.Paint var45 = var41.getNoDataMessagePaint();
//     java.awt.Paint var46 = var41.getNoDataMessagePaint();
//     org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("Range[1.0E-8,1.0E-8]", var9, var46);
//     
//     // Checks the contract:  equals-hashcode on var21 and var44
//     assertTrue("Contract failed: equals-hashcode on var21 and var44", var21.equals(var44) ? var21.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var21
//     assertTrue("Contract failed: equals-hashcode on var44 and var21", var44.equals(var21) ? var44.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
    var22.setHeight(1.0d);
    org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
    var22.setPadding(var26);
    double var29 = var26.trimHeight(0.05d);
    var20.setLegendItemGraphicPadding(var26);
    java.awt.Paint var31 = var20.getBackgroundPaint();
    java.awt.Paint var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var20.setItemPaint(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1.95d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("Multiple Pie Plot", "XY Plot", var3);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D();
    boolean var2 = var1.isAutoRange();
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.PiePlot var5 = new org.jfree.chart.plot.PiePlot(var4);
    var5.setLabelGap((-1.0d));
    java.lang.Object var8 = var5.clone();
    java.awt.Paint var9 = var5.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var5.setURLGenerator(var10);
    java.awt.Stroke var13 = var5.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var15 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    var5.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var15);
    boolean var17 = var3.equals((java.lang.Object)var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = null;
    org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var1, (org.jfree.chart.axis.ValueAxis)var3, var18);
    java.awt.Paint var20 = var19.getDomainZeroBaselinePaint();
    java.awt.Stroke var21 = var19.getRangeZeroBaselineStroke();
    int var22 = var19.getDomainAxisCount();
    org.jfree.chart.axis.ValueAxis var23 = var19.getDomainAxis();
    org.jfree.chart.plot.PolarPlot var24 = new org.jfree.chart.plot.PolarPlot();
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle("");
    org.jfree.chart.util.HorizontalAlignment var28 = var27.getTextAlignment();
    var27.setHeight(1.0d);
    double var31 = var27.getContentXOffset();
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Font var33 = var32.getLabelFont();
    boolean var34 = var27.equals((java.lang.Object)var33);
    org.jfree.chart.text.TextLine var35 = new org.jfree.chart.text.TextLine("java.awt.Color[r=255,g=255,b=254]", var33);
    boolean var36 = var24.equals((java.lang.Object)"java.awt.Color[r=255,g=255,b=254]");
    java.awt.Stroke var37 = var24.getRadiusGridlineStroke();
    var19.setDomainGridlineStroke(var37);
    org.jfree.data.xy.XYDataset var39 = null;
    var19.setDataset(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleConstraint[LengthConstraintType.NONE: width=0.0, height=100.0]", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    var1.setShadowXOffset((-1.0d));
    var1.setShadowXOffset(10.0d);
    boolean var9 = var1.getSimpleLabels();
    java.awt.Stroke var10 = var1.getLabelOutlineStroke();
    org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    java.awt.RenderingHints var13 = var11.getRenderingHints();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
    int var18 = var17.getGreen();
    var11.setBorderPaint((java.awt.Paint)var17);
    org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
    org.jfree.chart.util.RectangleAnchor var21 = var20.getLegendItemGraphicAnchor();
    org.jfree.chart.util.VerticalAlignment var22 = var20.getVerticalAlignment();
    double var23 = var20.getHeight();
    org.jfree.chart.util.RectangleInsets var24 = var20.getLegendItemGraphicPadding();
    java.lang.Object var25 = var20.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
    org.jfree.chart.util.RectangleInsets var2 = var1.getLabelInsets();
    var1.setTickMarkInsideLength(0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    var1.handleClick(0, 10, var8);
    org.jfree.chart.urls.PieURLGenerator var10 = null;
    var1.setLegendLabelURLGenerator(var10);
    var1.setShadowXOffset(0.0d);
    java.awt.Image var14 = var1.getBackgroundImage();
    boolean var15 = var1.isCircular();
    boolean var17 = var1.equals((java.lang.Object)3.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
//     var22.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     var22.setPadding(var26);
//     double var29 = var26.trimHeight(0.05d);
//     var20.setLegendItemGraphicPadding(var26);
//     org.jfree.chart.util.RectangleInsets var31 = var20.getLegendItemGraphicPadding();
//     java.awt.Graphics2D var32 = null;
//     org.jfree.data.Range var33 = null;
//     org.jfree.chart.block.RectangleConstraint var35 = new org.jfree.chart.block.RectangleConstraint(var33, 100.0d);
//     double var36 = var35.getWidth();
//     org.jfree.data.Range var37 = var35.getHeightRange();
//     org.jfree.chart.block.RectangleConstraint var39 = var35.toFixedHeight(Double.POSITIVE_INFINITY);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.geom.Rectangle2D var42 = null;
//     org.jfree.chart.util.RectangleEdge var43 = null;
//     double var44 = var40.java2DToValue(100.0d, var42, var43);
//     var40.setUpperMargin(10.0d);
//     boolean var47 = var40.isInverted();
//     org.jfree.data.Range var48 = null;
//     org.jfree.data.Range var50 = org.jfree.data.Range.expandToInclude(var48, 0.0d);
//     org.jfree.data.Range var52 = org.jfree.data.Range.expandToInclude(var48, 1.0E-8d);
//     double var53 = var52.getLength();
//     org.jfree.data.Range var55 = org.jfree.data.Range.expandToInclude(var52, (-1.95d));
//     var40.setRangeWithMargins(var55);
//     org.jfree.data.Range var59 = org.jfree.data.Range.expand(var55, 0.0d, 0.12d);
//     org.jfree.chart.axis.DateAxis var61 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.data.xy.XYDataset var62 = null;
//     org.jfree.chart.axis.NumberAxis3D var63 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var64 = var63.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var65 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.PiePlot var67 = new org.jfree.chart.plot.PiePlot(var66);
//     var67.setLabelGap((-1.0d));
//     java.lang.Object var70 = var67.clone();
//     java.awt.Paint var71 = var67.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var72 = null;
//     var67.setURLGenerator(var72);
//     java.awt.Stroke var75 = var67.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var77 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var67.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var77);
//     boolean var79 = var65.equals((java.lang.Object)var67);
//     org.jfree.chart.renderer.xy.XYItemRenderer var80 = null;
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot(var62, (org.jfree.chart.axis.ValueAxis)var63, (org.jfree.chart.axis.ValueAxis)var65, var80);
//     org.jfree.data.Range var82 = var63.getDefaultAutoRange();
//     var61.setRange(var82);
//     org.jfree.data.Range var86 = org.jfree.data.Range.shift(var82, (-1.95d), true);
//     org.jfree.data.Range var87 = org.jfree.data.Range.combine(var59, var86);
//     org.jfree.chart.block.RectangleConstraint var88 = var35.toRangeWidth(var87);
//     org.jfree.chart.util.Size2D var89 = var20.arrange(var32, var88);
//     
//     // Checks the contract:  equals-hashcode on var4 and var70
//     assertTrue("Contract failed: equals-hashcode on var4 and var70", var4.equals(var70) ? var4.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var4
//     assertTrue("Contract failed: equals-hashcode on var70 and var4", var70.equals(var4) ? var70.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    var1.setLabelGap((-1.0d));
    java.lang.Object var4 = var1.clone();
    java.awt.Paint var5 = var1.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var6 = null;
    var1.setURLGenerator(var6);
    org.jfree.chart.plot.DrawingSupplier var8 = var1.getDrawingSupplier();
    var1.setLabelLinksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     java.awt.RenderingHints var13 = var11.getRenderingHints();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     int var18 = var17.getGreen();
//     var11.setBorderPaint((java.awt.Paint)var17);
//     org.jfree.chart.title.LegendTitle var20 = var11.getLegend();
//     org.jfree.chart.title.TextTitle var22 = new org.jfree.chart.title.TextTitle("");
//     org.jfree.chart.util.HorizontalAlignment var23 = var22.getTextAlignment();
//     var22.setHeight(1.0d);
//     org.jfree.chart.util.RectangleInsets var26 = new org.jfree.chart.util.RectangleInsets();
//     var22.setPadding(var26);
//     double var29 = var26.trimHeight(0.05d);
//     var20.setLegendItemGraphicPadding(var26);
//     java.awt.Paint var31 = var20.getBackgroundPaint();
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis();
//     java.awt.Font var34 = var33.getLabelFont();
//     org.jfree.chart.axis.NumberAxis3D var36 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var37 = null;
//     org.jfree.chart.plot.PiePlot var38 = new org.jfree.chart.plot.PiePlot(var37);
//     var38.setLabelGap((-1.0d));
//     java.lang.Object var41 = var38.clone();
//     java.awt.Paint var42 = var38.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var43 = null;
//     var38.setURLGenerator(var43);
//     java.awt.Stroke var46 = var38.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var48 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var38.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var48);
//     boolean var50 = var36.equals((java.lang.Object)var38);
//     java.awt.Color var54 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var55 = null;
//     java.awt.Rectangle var56 = null;
//     java.awt.geom.Rectangle2D var57 = null;
//     java.awt.geom.AffineTransform var58 = null;
//     java.awt.RenderingHints var59 = null;
//     java.awt.PaintContext var60 = var54.createContext(var55, var56, var57, var58, var59);
//     java.awt.color.ColorSpace var61 = var54.getColorSpace();
//     var38.setNoDataMessagePaint((java.awt.Paint)var54);
//     org.jfree.chart.block.LineBorder var63 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var64 = var63.getPaint();
//     java.awt.Stroke var65 = var63.getStroke();
//     org.jfree.chart.plot.ValueMarker var66 = new org.jfree.chart.plot.ValueMarker(Double.POSITIVE_INFINITY, (java.awt.Paint)var54, var65);
//     java.awt.Color var70 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 1.0f);
//     java.awt.image.ColorModel var71 = null;
//     java.awt.Rectangle var72 = null;
//     java.awt.geom.Rectangle2D var73 = null;
//     java.awt.geom.AffineTransform var74 = null;
//     java.awt.RenderingHints var75 = null;
//     java.awt.PaintContext var76 = var70.createContext(var71, var72, var73, var74, var75);
//     java.awt.color.ColorSpace var77 = var70.getColorSpace();
//     var66.setPaint((java.awt.Paint)var70);
//     java.awt.Paint var79 = var66.getOutlinePaint();
//     org.jfree.chart.text.TextFragment var81 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = null", var34, var79, 0.0f);
//     var20.setBackgroundPaint(var79);
//     
//     // Checks the contract:  equals-hashcode on var4 and var41
//     assertTrue("Contract failed: equals-hashcode on var4 and var41", var4.equals(var41) ? var4.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var4
//     assertTrue("Contract failed: equals-hashcode on var41 and var4", var41.equals(var4) ? var41.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test495() {}
//   public void test495() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }
// 
// 
//     org.jfree.data.xy.XYDataset var1 = null;
//     org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D();
//     boolean var3 = var2.isAutoRange();
//     org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D();
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot(var5);
//     var6.setLabelGap((-1.0d));
//     java.lang.Object var9 = var6.clone();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var11 = null;
//     var6.setURLGenerator(var11);
//     java.awt.Stroke var14 = var6.getSectionOutlineStroke((java.lang.Comparable)(byte)10);
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     var6.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var16);
//     boolean var18 = var4.equals((java.lang.Object)var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot(var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var4, var19);
//     var20.clearDomainAxes();
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var20.setRangeAxisLocation(4, var23, false);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot)var20);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var29.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var32 = var29.getLabelFont();
//     org.jfree.data.general.PieDataset var33 = null;
//     org.jfree.chart.plot.PiePlot var34 = new org.jfree.chart.plot.PiePlot(var33);
//     java.awt.Paint var35 = null;
//     var34.setLabelShadowPaint(var35);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.PiePlot var40 = new org.jfree.chart.plot.PiePlot(var39);
//     var40.setLabelGap((-1.0d));
//     java.lang.Object var43 = var40.clone();
//     java.awt.Paint var44 = var40.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var45 = null;
//     var40.setURLGenerator(var45);
//     var40.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var50 = null;
//     org.jfree.chart.plot.PiePlotState var51 = var34.initialise(var37, var38, var40, (java.lang.Integer)0, var50);
//     org.jfree.data.general.PieDataset var52 = null;
//     org.jfree.chart.plot.PiePlot var53 = new org.jfree.chart.plot.PiePlot(var52);
//     var53.setLabelGap((-1.0d));
//     java.awt.Font var56 = var53.getLabelFont();
//     var40.setNoDataMessageFont(var56);
//     boolean var58 = var29.equals((java.lang.Object)var40);
//     var29.setMaximumCategoryLabelLines(254);
//     var29.setCategoryMargin(0.12d);
//     java.lang.Object var63 = null;
//     boolean var64 = var29.equals(var63);
//     org.jfree.chart.plot.PolarPlot var65 = new org.jfree.chart.plot.PolarPlot();
//     var65.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var70 = null;
//     java.awt.geom.Rectangle2D var71 = null;
//     org.jfree.chart.util.RectangleAnchor var72 = null;
//     java.awt.geom.Point2D var73 = org.jfree.chart.util.RectangleAnchor.coordinates(var71, var72);
//     var65.zoomDomainAxes(0.0d, (-1.0d), var70, var73);
//     org.jfree.chart.axis.DateAxis var76 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var76.configure();
//     org.jfree.data.Range var78 = var65.getDataRange((org.jfree.chart.axis.ValueAxis)var76);
//     double var79 = var76.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var80 = null;
//     org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var27, var29, (org.jfree.chart.axis.ValueAxis)var76, var80);
//     org.jfree.chart.axis.CategoryAxis var82 = null;
//     java.util.List var83 = var81.getCategoriesForAxis(var82);
//     var26.setSubtitles(var83);
//     
//     // Checks the contract:  equals-hashcode on var9 and var43
//     assertTrue("Contract failed: equals-hashcode on var9 and var43", var9.equals(var43) ? var9.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var9
//     assertTrue("Contract failed: equals-hashcode on var43 and var9", var43.equals(var9) ? var43.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.axis.NumberAxis3D var0 = new org.jfree.chart.axis.NumberAxis3D();
    float var1 = var0.getTickMarkOutsideLength();
    boolean var2 = var0.isInverted();
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot();
    var0.setPlot((org.jfree.chart.plot.Plot)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRange(90.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     var2.setTickMarkOutsideLength(1.0f);
//     java.awt.Font var5 = var2.getLabelFont();
//     org.jfree.data.general.PieDataset var6 = null;
//     org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
//     java.awt.Paint var8 = null;
//     var7.setLabelShadowPaint(var8);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.PiePlot var13 = new org.jfree.chart.plot.PiePlot(var12);
//     var13.setLabelGap((-1.0d));
//     java.lang.Object var16 = var13.clone();
//     java.awt.Paint var17 = var13.getNoDataMessagePaint();
//     org.jfree.chart.urls.PieURLGenerator var18 = null;
//     var13.setURLGenerator(var18);
//     var13.setIgnoreZeroValues(true);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.plot.PiePlotState var24 = var7.initialise(var10, var11, var13, (java.lang.Integer)0, var23);
//     org.jfree.data.general.PieDataset var25 = null;
//     org.jfree.chart.plot.PiePlot var26 = new org.jfree.chart.plot.PiePlot(var25);
//     var26.setLabelGap((-1.0d));
//     java.awt.Font var29 = var26.getLabelFont();
//     var13.setNoDataMessageFont(var29);
//     boolean var31 = var2.equals((java.lang.Object)var13);
//     var2.setMaximumCategoryLabelLines(254);
//     var2.setCategoryMargin(0.12d);
//     java.lang.Object var36 = null;
//     boolean var37 = var2.equals(var36);
//     org.jfree.chart.plot.PolarPlot var38 = new org.jfree.chart.plot.PolarPlot();
//     var38.setAngleLabelsVisible(true);
//     org.jfree.chart.plot.PlotRenderingInfo var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleAnchor var45 = null;
//     java.awt.geom.Point2D var46 = org.jfree.chart.util.RectangleAnchor.coordinates(var44, var45);
//     var38.zoomDomainAxes(0.0d, (-1.0d), var43, var46);
//     org.jfree.chart.axis.DateAxis var49 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     var49.configure();
//     org.jfree.data.Range var51 = var38.getDataRange((org.jfree.chart.axis.ValueAxis)var49);
//     double var52 = var49.getUpperMargin();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var0, var2, (org.jfree.chart.axis.ValueAxis)var49, var53);
//     org.jfree.chart.plot.ValueMarker var57 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     java.lang.Object var58 = var57.clone();
//     org.jfree.chart.event.MarkerChangeEvent var59 = null;
//     var57.notifyListeners(var59);
//     org.jfree.chart.axis.CategoryAxis var62 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=255,g=255,b=254]");
//     java.awt.Paint var64 = var62.getTickLabelPaint((java.lang.Comparable)255);
//     var57.setLabelPaint(var64);
//     var57.setLabel("org.jfree.chart.event.ChartProgressEvent[source=-1.0]");
//     org.jfree.chart.util.Layer var68 = null;
//     var54.addRangeMarker(0, (org.jfree.chart.plot.Marker)var57, var68);
//     org.jfree.chart.axis.CategoryAnchor var70 = var54.getDomainGridlinePosition();
//     java.util.List var71 = var54.getCategories();
//     java.awt.Graphics2D var72 = null;
//     java.awt.geom.Rectangle2D var73 = null;
//     var54.drawBackground(var72, var73);
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
    java.awt.Paint var2 = null;
    var1.setLabelShadowPaint(var2);
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.chart.plot.PiePlot var7 = new org.jfree.chart.plot.PiePlot(var6);
    var7.setLabelGap((-1.0d));
    java.lang.Object var10 = var7.clone();
    java.awt.Paint var11 = var7.getNoDataMessagePaint();
    org.jfree.chart.urls.PieURLGenerator var12 = null;
    var7.setURLGenerator(var12);
    var7.setIgnoreZeroValues(true);
    org.jfree.chart.plot.PlotRenderingInfo var17 = null;
    org.jfree.chart.plot.PiePlotState var18 = var1.initialise(var4, var5, var7, (java.lang.Integer)0, var17);
    org.jfree.chart.urls.PieURLGenerator var19 = var1.getLegendLabelURLGenerator();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var22 = var21.getPercentFormat();
    var1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var21);
    java.awt.Shape var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLegendItemShape(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint((-1.0d), 100.0d);
    org.jfree.data.Range var3 = var2.getHeightRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot var1 = new org.jfree.chart.plot.PiePlot(var0);
//     var1.setLabelGap((-1.0d));
//     java.lang.Object var4 = var1.clone();
//     var1.setShadowXOffset((-1.0d));
//     var1.setShadowXOffset(10.0d);
//     boolean var9 = var1.getSimpleLabels();
//     java.awt.Stroke var10 = var1.getLabelOutlineStroke();
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var1);
//     java.awt.Stroke var12 = var11.getBorderStroke();
//     java.lang.Object var13 = var11.getTextAntiAlias();
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     var11.handleClick(1, 255, var16);
// 
//   }

}
