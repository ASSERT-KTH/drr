
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    org.jfree.data.category.CategoryDataset var26 = var4.getDataset((-16777215));
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var36 = var32.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var37 = null;
    org.jfree.chart.title.LegendItemBlockContainer var39 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, var37, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var27, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.util.RectangleEdge var46 = var45.getPosition();
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.axis.CategoryAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
    org.jfree.chart.util.SortOrder var52 = var51.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var53 = var51.getColumnRenderingOrder();
    var51.setForegroundAlpha(0.0f);
    boolean var56 = var46.equals((java.lang.Object)var51);
    org.jfree.chart.axis.CategoryAnchor var57 = var51.getDomainGridlinePosition();
    java.awt.Font var58 = var51.getNoDataMessageFont();
    var4.setParent((org.jfree.chart.plot.Plot)var51);
    boolean var60 = var51.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    double var2 = var1.getAutoRangeMinimumSize();
    boolean var3 = var1.getAutoRangeIncludesZero();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var8.getCategoriesForAxis(var9);
    float var11 = var8.getBackgroundAlpha();
    var1.setPlot((org.jfree.chart.plot.Plot)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    java.lang.String var5 = var4.getURLText();
    java.lang.String var6 = var4.toString();
    var4.setToolTipText("hi!");
    java.lang.Object var9 = null;
    boolean var10 = var4.equals(var9);
    java.awt.Shape var11 = var4.getArea();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var20 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var21 = var17.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var22 = null;
    org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var17, var22, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var12, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var29);
    java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var35 = var34.getAlpha();
    java.awt.color.ColorSpace var36 = var34.getColorSpace();
    java.lang.String var37 = var34.toString();
    var30.setItemPaint((java.awt.Paint)var34);
    org.jfree.chart.util.RectangleEdge var39 = var30.getPosition();
    java.awt.Color var43 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var44 = null;
    org.jfree.chart.axis.CategoryAxis var45 = null;
    org.jfree.chart.axis.ValueAxis var46 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
    org.jfree.chart.LegendItemCollection var49 = null;
    var48.setFixedLegendItems(var49);
    java.awt.Stroke var51 = null;
    var48.setOutlineStroke(var51);
    org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var55 = null;
    org.jfree.data.Range var57 = org.jfree.data.Range.expandToInclude(var55, 1.0d);
    double var58 = var57.getLowerBound();
    var54.setRange(var57);
    org.jfree.data.Range var60 = var48.getDataRange((org.jfree.chart.axis.ValueAxis)var54);
    var54.setAutoTickUnitSelection(true, true);
    boolean var64 = var54.isVisible();
    java.awt.Stroke var65 = var54.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var66, var67, var68, var69);
    org.jfree.chart.axis.CategoryAxis var71 = null;
    java.util.List var72 = var70.getCategoriesForAxis(var71);
    org.jfree.chart.util.RectangleInsets var73 = var70.getInsets();
    double var75 = var73.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var76 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var43, var65, var73);
    org.jfree.chart.util.RectangleInsets var77 = var76.getInsets();
    org.jfree.chart.util.RectangleInsets var78 = var76.getInsets();
    var30.setLegendItemGraphicPadding(var78);
    org.jfree.chart.util.RectangleInsets var80 = var30.getLegendItemGraphicPadding();
    boolean var81 = var4.equals((java.lang.Object)var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var6.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var37.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, (-15.0d), (-254), (java.lang.Comparable)"org.jfree.chart.event.ChartProgressEvent[source=ChartEntity: tooltip = ]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
//     org.jfree.chart.util.SortOrder var12 = var11.getColumnRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var13 = var11.getRangeAxisLocation();
//     org.jfree.chart.plot.DatasetRenderingOrder var14 = var11.getDatasetRenderingOrder();
//     var4.setDatasetRenderingOrder(var14);
//     
//     // Checks the contract:  equals-hashcode on var4 and var11
//     assertTrue("Contract failed: equals-hashcode on var4 and var11", var4.equals(var11) ? var4.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var4
//     assertTrue("Contract failed: equals-hashcode on var11 and var4", var11.equals(var4) ? var11.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Size2D[width=1.0, height=-1.0]", var1, (-1.0f), (-1.0f), var4, (-19.0d), 100.0f, 100.0f);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    int var3 = java.awt.Color.HSBtoRGB(1.0f, 10.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    int var2 = var1.size();
    int var3 = var1.size();
    java.lang.Object var4 = null;
    boolean var5 = var1.equals(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.CategoryAxis var5 = null;
    java.util.List var6 = var4.getCategoriesForAxis(var5);
    org.jfree.chart.plot.DrawingSupplier var7 = var4.getDrawingSupplier();
    int var8 = var4.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    java.awt.Paint[] var9 = null;
    java.awt.Color var13 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var14 = var13.getAlpha();
    java.awt.color.ColorSpace var15 = var13.getColorSpace();
    java.lang.String var16 = var13.toString();
    java.awt.Paint[] var17 = new java.awt.Paint[] { var13};
    java.awt.Font var19 = null;
    java.awt.Color var22 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var23 = var22.darker();
    org.jfree.chart.text.TextMeasurer var25 = null;
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var19, (java.awt.Paint)var23, 0.0f, var25);
    java.awt.Paint[] var27 = new java.awt.Paint[] { var23};
    java.awt.Stroke var28 = null;
    java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var34 = new org.jfree.chart.entity.ChartEntity(var33);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var38 = org.jfree.chart.util.ShapeUtilities.equal(var33, var37);
    java.awt.Shape[] var39 = new java.awt.Shape[] { var33};
    org.jfree.chart.plot.DefaultDrawingSupplier var40 = new org.jfree.chart.plot.DefaultDrawingSupplier(var9, var17, var27, var29, var31, var39);
    var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var40);
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var42, var43, var44, var45);
    org.jfree.chart.LegendItemCollection var47 = null;
    var46.setFixedLegendItems(var47);
    org.jfree.chart.axis.CategoryAxis var50 = var46.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var51 = var46.getRangeAxisLocation();
    org.jfree.chart.axis.CategoryAxis var52 = null;
    org.jfree.chart.axis.CategoryAxis[] var53 = new org.jfree.chart.axis.CategoryAxis[] { var52};
    var46.setDomainAxes(var53);
    org.jfree.chart.plot.DrawingSupplier var55 = var46.getDrawingSupplier();
    java.awt.Stroke var56 = var46.getDomainGridlineStroke();
    var4.setDomainGridlineStroke(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var16.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.fireChartChanged();
    java.awt.Paint var16 = var10.getBackgroundPaint();
    boolean var17 = var10.isNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var5, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var28 = var27.getAlpha();
    java.awt.color.ColorSpace var29 = var27.getColorSpace();
    java.lang.String var30 = var27.toString();
    var23.setItemPaint((java.awt.Paint)var27);
    java.awt.Font var32 = var23.getItemFont();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var32);
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Rectangle2D var35 = var33.getBounds();
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
    org.jfree.chart.LegendItemCollection var41 = null;
    var40.setFixedLegendItems(var41);
    org.jfree.chart.axis.CategoryAxis var44 = var40.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var46 = var40.getRangeAxisLocation((-16777215));
    java.awt.Paint var47 = var40.getNoDataMessagePaint();
    var40.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
    org.jfree.chart.LegendItemCollection var54 = null;
    var53.setFixedLegendItems(var54);
    org.jfree.chart.axis.CategoryAxis var57 = var53.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var59 = var53.getRangeAxisLocation((-16777215));
    var40.setDomainAxisLocation(var59);
    java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var64 = var63.darker();
    int var65 = var64.getRed();
    var40.setOutlinePaint((java.awt.Paint)var64);
    org.jfree.chart.util.RectangleEdge var68 = var40.getDomainAxisEdge(10);
    double var69 = var1.getCategoryMiddle(1, 246, var35, var68);
    org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    java.awt.Paint var72 = var71.getPaint();
    var1.setAxisLinePaint(var72);
    var1.setCategoryLabelPositionOffset(10);
    var1.setLabelToolTip("ChartEntity: tooltip = ");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    java.awt.Stroke var11 = null;
    var8.setOutlineStroke(var11);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    double var18 = var17.getLowerBound();
    var14.setRange(var17);
    org.jfree.data.Range var20 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    var14.setAutoTickUnitSelection(true, true);
    boolean var24 = var14.isVisible();
    java.awt.Stroke var25 = var14.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var30.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleInsets var33 = var30.getInsets();
    double var35 = var33.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var25, var33);
    org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var40, var41, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var47 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var48 = var44.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var49 = null;
    org.jfree.chart.title.LegendItemBlockContainer var51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var44, var49, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var52 = null;
    org.jfree.chart.util.VerticalAlignment var53 = null;
    org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var52, var53, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var39, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var56);
    java.awt.Color var61 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var62 = var61.getAlpha();
    java.awt.color.ColorSpace var63 = var61.getColorSpace();
    java.lang.String var64 = var61.toString();
    var57.setItemPaint((java.awt.Paint)var61);
    java.awt.Font var66 = var57.getItemFont();
    org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var66);
    java.lang.Object var68 = var67.clone();
    java.awt.geom.Rectangle2D var69 = var67.getBounds();
    java.awt.geom.Rectangle2D var70 = var37.createInsetRectangle(var69);
    double var72 = var37.trimWidth((-19.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var64.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == (-35.0d));

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var18 = var10.getSubtitle(246);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-6.0d));
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var11 = var7.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var12 = null;
    org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var12, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var2, (org.jfree.chart.block.Arrangement)var7, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var22 = var1.getLabelPosition(var21);
    double var23 = var22.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-6.0d));

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    double var2 = var1.getAutoRangeMinimumSize();
    boolean var3 = var1.getAutoRangeIncludesZero();
    java.awt.Paint var4 = var1.getAxisLinePaint();
    boolean var5 = var1.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.CategoryAxis var5 = null;
    java.util.List var6 = var4.getCategoriesForAxis(var5);
    org.jfree.chart.util.RectangleInsets var7 = var4.getInsets();
    double var9 = var7.calculateLeftInset(100.0d);
    double var11 = var7.trimWidth(10.0d);
    double var13 = var7.extendWidth((-6.0d));
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    org.jfree.chart.LegendItemCollection var19 = null;
    var18.setFixedLegendItems(var19);
    java.awt.Stroke var21 = null;
    var18.setOutlineStroke(var21);
    org.jfree.chart.axis.NumberAxis var24 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var25 = null;
    org.jfree.data.Range var27 = org.jfree.data.Range.expandToInclude(var25, 1.0d);
    double var28 = var27.getLowerBound();
    var24.setRange(var27);
    org.jfree.data.Range var30 = var18.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    var24.setAutoTickUnitSelection(true, true);
    boolean var34 = var24.isVisible();
    java.awt.Stroke var35 = var24.getAxisLineStroke();
    var24.setVisible(false);
    org.jfree.chart.axis.MarkerAxisBand var38 = null;
    var24.setMarkerBand(var38);
    boolean var40 = var7.equals((java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("org.jfree.chart.event.ChartProgressEvent[source=ChartEntity: tooltip = ]", "ChartEntity: tooltip = ", "0,-10,10,0,0,10,-10,0,-10,0", "ChartEntity: tooltip = hi!", "hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    boolean var2 = var1.isTickLabelsVisible();
    boolean var3 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.0f, var7);
    org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var8.calculateDimensions(var10);
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    var8.draw(var12, 100.0f, 1.0f, var15, 0.0f, 1.0f, (-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.chart.text.TextFragment var3 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    java.awt.Paint var4 = var3.getPaint();
    java.awt.Font var5 = var3.getFont();
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    org.jfree.chart.util.SortOrder var11 = var10.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var12 = var10.getColumnRenderingOrder();
    var10.setForegroundAlpha(0.0f);
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    java.awt.geom.Point2D var17 = null;
    var10.zoomRangeAxes((-15.0d), var16, var17);
    java.awt.Paint var19 = var10.getBackgroundPaint();
    java.awt.Paint var20 = var10.getBackgroundPaint();
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=1.0]", var5, var20);
    org.jfree.chart.text.TextLine var22 = new org.jfree.chart.text.TextLine("java.awt.Color[r=0,g=0,b=0]", var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    var10.setVerticalTickLabels(false);
    org.jfree.data.Range var33 = var10.getRange();
    double var34 = var10.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.0d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.removeLegend();
    org.jfree.chart.title.LegendTitle var17 = var10.getLegend(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 1.0d);
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var6);
    org.jfree.chart.block.LengthConstraintType var9 = var8.getHeightConstraintType();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    org.jfree.chart.util.SortOrder var15 = var14.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
    var14.setForegroundAlpha(0.0f);
    boolean var19 = var9.equals((java.lang.Object)var14);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    java.awt.Stroke var27 = null;
    var24.setOutlineStroke(var27);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 1.0d);
    double var34 = var33.getLowerBound();
    var30.setRange(var33);
    org.jfree.data.Range var36 = var24.getDataRange((org.jfree.chart.axis.ValueAxis)var30);
    var30.setAutoTickUnitSelection(true, true);
    boolean var40 = var30.isVisible();
    java.awt.Stroke var41 = var30.getAxisLineStroke();
    java.awt.Color var44 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var45 = var44.darker();
    int var46 = var45.getRed();
    var30.setTickMarkPaint((java.awt.Paint)var45);
    var30.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var50 = var30.getStandardTickUnits();
    var30.setVerticalTickLabels(false);
    org.jfree.data.Range var53 = var30.getRange();
    boolean var54 = var30.getAutoRangeIncludesZero();
    double var55 = var30.getLowerBound();
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
    org.jfree.chart.LegendItemCollection var62 = null;
    var61.setFixedLegendItems(var62);
    org.jfree.data.category.CategoryDataset var65 = var61.getDataset((-254));
    org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var61);
    var66.setTextAntiAlias(false);
    var66.setTextAntiAlias(true);
    java.util.List var71 = var66.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var72 = null;
    org.jfree.chart.event.ChartChangeEvent var73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var66, var72);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var66);
    var66.setTextAntiAlias(false);
    java.awt.Image var77 = null;
    var66.setBackgroundImage(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var18 = var17.getBounds();
    boolean var19 = var5.equals((java.lang.Object)var18);
    java.lang.String var20 = var5.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "SortOrder.ASCENDING"+ "'", var20.equals("SortOrder.ASCENDING"));

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    int var2 = var1.size();
    int var3 = var1.size();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    java.util.List var10 = var8.getCategoriesForAxis(var9);
    org.jfree.chart.util.RectangleInsets var11 = var8.getInsets();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    java.awt.Stroke var19 = null;
    var16.setOutlineStroke(var19);
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 1.0d);
    double var26 = var25.getLowerBound();
    var22.setRange(var25);
    org.jfree.data.Range var28 = var16.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
    var22.setAutoTickUnitSelection(true, true);
    boolean var32 = var22.isVisible();
    java.awt.Stroke var33 = var22.getAxisLineStroke();
    java.awt.Color var36 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var37 = var36.darker();
    int var38 = var37.getRed();
    var22.setTickMarkPaint((java.awt.Paint)var37);
    var22.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var42 = var22.getStandardTickUnits();
    var22.setFixedDimension(10.0d);
    var22.setRange(0.0d, 10.0d);
    org.jfree.data.Range var48 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var22);
    boolean var49 = var1.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.setBorderVisible(false);
    org.jfree.chart.title.LegendTitle var18 = var10.getLegend(0);
    var10.setTextAntiAlias(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var4 = var3.getAlpha();
    java.awt.color.ColorSpace var5 = var3.getColorSpace();
    int var6 = var3.getBlue();
    java.awt.color.ColorSpace var7 = var3.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var5 = var4.getAlpha();
    java.awt.color.ColorSpace var6 = var4.getColorSpace();
    java.lang.String var7 = var4.toString();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=0]", (java.lang.Object)var7);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var12 = null;
    org.jfree.chart.util.Size2D var13 = var11.calculateConstrainedSize(var12);
    double var14 = var13.getWidth();
    var8.setObject((java.lang.Object)var13);
    var13.setWidth(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var7.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.CategoryAxis var5 = null;
    java.util.List var6 = var4.getCategoriesForAxis(var5);
    org.jfree.chart.util.RectangleInsets var7 = var4.getInsets();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    java.awt.Stroke var15 = null;
    var12.setOutlineStroke(var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 1.0d);
    double var22 = var21.getLowerBound();
    var18.setRange(var21);
    org.jfree.data.Range var24 = var12.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    var18.setAutoTickUnitSelection(true, true);
    boolean var28 = var18.isVisible();
    java.awt.Stroke var29 = var18.getAxisLineStroke();
    java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var33 = var32.darker();
    int var34 = var33.getRed();
    var18.setTickMarkPaint((java.awt.Paint)var33);
    var18.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var38 = var18.getStandardTickUnits();
    var18.setFixedDimension(10.0d);
    var18.setRange(0.0d, 10.0d);
    org.jfree.data.Range var44 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    java.awt.Font var45 = var4.getNoDataMessageFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    var10.setVerticalTickLabels(false);
    org.jfree.data.Range var33 = var10.getRange();
    boolean var34 = var10.getAutoRangeIncludesZero();
    double var35 = var10.getLowerBound();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    org.jfree.data.category.CategoryDataset var45 = var41.getDataset((-254));
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var41);
    var46.setTextAntiAlias(false);
    var46.setTextAntiAlias(true);
    java.util.List var51 = var46.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var52 = null;
    org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var46, var52);
    org.jfree.chart.util.RectangleInsets var54 = var46.getPadding();
    double var55 = var54.getLeft();
    org.jfree.chart.util.UnitType var56 = var54.getUnitType();
    java.lang.String var57 = var56.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + "UnitType.ABSOLUTE"+ "'", var57.equals("UnitType.ABSOLUTE"));

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var5 = var4.getAlpha();
    java.awt.color.ColorSpace var6 = var4.getColorSpace();
    java.lang.String var7 = var4.toString();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=0]", (java.lang.Object)var7);
    java.lang.Object var9 = var8.getObject();
    java.lang.Object var10 = var8.getObject();
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    java.awt.Color var33 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var34 = var33.getAlpha();
    java.awt.color.ColorSpace var35 = var33.getColorSpace();
    java.lang.String var36 = var33.toString();
    var29.setItemPaint((java.awt.Paint)var33);
    org.jfree.chart.LegendItemSource var38 = null;
    org.jfree.chart.LegendItemSource[] var39 = new org.jfree.chart.LegendItemSource[] { var38};
    var29.setSources(var39);
    java.awt.Font var42 = null;
    java.awt.Color var45 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var46 = var45.darker();
    org.jfree.chart.text.TextMeasurer var48 = null;
    org.jfree.chart.text.TextBlock var49 = org.jfree.chart.text.TextUtilities.createTextBlock("", var42, (java.awt.Paint)var46, 0.0f, var48);
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.util.Size2D var51 = var49.calculateDimensions(var50);
    org.jfree.chart.util.HorizontalAlignment var52 = var49.getLineAlignment();
    var29.setHorizontalAlignment(var52);
    double var54 = var29.getHeight();
    var8.setObject((java.lang.Object)var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var7.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var9.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var10.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var36.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var5, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var28 = var27.getAlpha();
    java.awt.color.ColorSpace var29 = var27.getColorSpace();
    java.lang.String var30 = var27.toString();
    var23.setItemPaint((java.awt.Paint)var27);
    java.awt.Font var32 = var23.getItemFont();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var32);
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Rectangle2D var35 = var33.getBounds();
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
    org.jfree.chart.LegendItemCollection var41 = null;
    var40.setFixedLegendItems(var41);
    org.jfree.chart.axis.CategoryAxis var44 = var40.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var46 = var40.getRangeAxisLocation((-16777215));
    java.awt.Paint var47 = var40.getNoDataMessagePaint();
    var40.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
    org.jfree.chart.LegendItemCollection var54 = null;
    var53.setFixedLegendItems(var54);
    org.jfree.chart.axis.CategoryAxis var57 = var53.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var59 = var53.getRangeAxisLocation((-16777215));
    var40.setDomainAxisLocation(var59);
    java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var64 = var63.darker();
    int var65 = var64.getRed();
    var40.setOutlinePaint((java.awt.Paint)var64);
    org.jfree.chart.util.RectangleEdge var68 = var40.getDomainAxisEdge(10);
    double var69 = var1.getCategoryMiddle(1, 246, var35, var68);
    org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    java.awt.Paint var72 = var71.getPaint();
    var1.setAxisLinePaint(var72);
    var1.setCategoryLabelPositionOffset(10);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)true);
    java.awt.Font var79 = var1.getTickLabelFont((java.lang.Comparable)(-15.0d));
    var1.setCategoryMargin(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "", "hi!", "hi!");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var10 = new org.jfree.chart.entity.ChartEntity(var9);
    boolean var11 = var7.equals((java.lang.Object)var10);
    java.lang.String var12 = var7.getInfo();
    java.awt.Image var16 = null;
    org.jfree.chart.ui.ProjectInfo var20 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var16, "", "hi!", "hi!");
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var23 = new org.jfree.chart.entity.ChartEntity(var22);
    boolean var24 = var20.equals((java.lang.Object)var23);
    java.lang.String var25 = var20.getInfo();
    java.lang.String var26 = var20.toString();
    var20.setInfo("ChartEntity: tooltip = hi!");
    var7.addLibrary((org.jfree.chart.ui.Library)var20);
    org.jfree.chart.ui.Library[] var30 = var7.getLibraries();
    java.lang.String var31 = var7.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"+ "'", var26.equals("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + "hi!"+ "'", var31.equals("hi!"));

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
//     org.jfree.chart.JFreeChart var7 = null;
//     org.jfree.chart.event.ChartProgressEvent var10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var7, (-254), (-16777215));
//     var4.configureRangeAxes();
//     org.jfree.data.general.DatasetGroup var12 = var4.getDatasetGroup();
//     java.lang.String var13 = var4.getPlotType();
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     org.jfree.chart.util.SortOrder var19 = var18.getColumnRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var20 = var18.getRangeAxisLocation();
//     org.jfree.chart.plot.DatasetRenderingOrder var21 = var18.getDatasetRenderingOrder();
//     org.jfree.chart.axis.AxisLocation var22 = var18.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAnchor var23 = var18.getDomainGridlinePosition();
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     java.awt.Stroke var31 = null;
//     var28.setOutlineStroke(var31);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var35 = null;
//     org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 1.0d);
//     double var38 = var37.getLowerBound();
//     var34.setRange(var37);
//     org.jfree.data.Range var40 = var28.getDataRange((org.jfree.chart.axis.ValueAxis)var34);
//     var34.setAutoTickUnitSelection(true, true);
//     boolean var44 = var34.isVisible();
//     java.awt.Stroke var45 = var34.getAxisLineStroke();
//     java.awt.Color var48 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var49 = var48.darker();
//     int var50 = var49.getRed();
//     var34.setTickMarkPaint((java.awt.Paint)var49);
//     var34.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.chart.axis.TickUnitSource var54 = var34.getStandardTickUnits();
//     var34.setFixedDimension(10.0d);
//     var34.setRange(0.0d, 10.0d);
//     boolean var60 = var23.equals((java.lang.Object)0.0d);
//     var4.setDomainGridlinePosition(var23);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.util.RectangleEdge var10 = var4.getDomainAxisEdge((-10));
    java.lang.String var11 = var4.getNoDataMessage();
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = var4.getRenderer((-254));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    java.awt.Font var3 = null;
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var7 = var6.darker();
    org.jfree.chart.text.TextMeasurer var9 = null;
    org.jfree.chart.text.TextBlock var10 = org.jfree.chart.text.TextUtilities.createTextBlock("", var3, (java.awt.Paint)var7, 0.0f, var9);
    org.jfree.chart.util.HorizontalAlignment var11 = var10.getLineAlignment();
    org.jfree.chart.util.VerticalAlignment var12 = null;
    org.jfree.chart.block.FlowArrangement var15 = new org.jfree.chart.block.FlowArrangement(var11, var12, 100.0d, 1.0d);
    var1.setTextAlignment(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    var10.setFixedDimension(10.0d);
    var10.setRange(0.0d, 10.0d);
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
    org.jfree.chart.LegendItemCollection var41 = null;
    var40.setFixedLegendItems(var41);
    org.jfree.chart.axis.CategoryAxis var44 = var40.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var46 = var40.getRangeAxisLocation((-16777215));
    java.awt.Paint var47 = var40.getNoDataMessagePaint();
    var40.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
    org.jfree.chart.LegendItemCollection var54 = null;
    var53.setFixedLegendItems(var54);
    org.jfree.chart.axis.CategoryAxis var57 = var53.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var59 = var53.getRangeAxisLocation((-16777215));
    var40.setDomainAxisLocation(var59);
    java.lang.Object var61 = var40.clone();
    org.jfree.chart.util.HorizontalAlignment var62 = null;
    org.jfree.chart.util.VerticalAlignment var63 = null;
    org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, 1.0d, 100.0d);
    org.jfree.chart.block.Block var67 = null;
    var66.add(var67, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var71 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var72 = var66.equals((java.lang.Object)var71);
    org.jfree.data.general.Dataset var73 = null;
    org.jfree.chart.title.LegendItemBlockContainer var75 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var66, var73, (java.lang.Comparable)(byte)100);
    var75.setID("ChartEntity: tooltip = hi!");
    org.jfree.chart.util.RectangleInsets var78 = var75.getPadding();
    var40.setInsets(var78, false);
    var10.setLabelInsets(var78);
    var10.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var8 = var4.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var9, (java.lang.Comparable)(-254));
    java.lang.String var12 = var11.getToolTipText();
    double var13 = var11.getContentXOffset();
    boolean var14 = var11.isEmpty();
    java.lang.String var15 = var11.getID();
    double var16 = var11.getWidth();
    double var17 = var11.getContentXOffset();
    org.jfree.chart.block.Arrangement var18 = var11.getArrangement();
    var11.setHeight(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 1.0d);
    org.jfree.data.Range var5 = org.jfree.data.Range.combine(var1, var4);
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(100.0d, var5);
    org.jfree.data.Range var7 = var6.getWidthRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation(100.0d, (-7.0d));

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var4 = var3.getBlue();
    java.awt.color.ColorSpace var5 = var3.getColorSpace();
    java.awt.Color var6 = var3.brighter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    float var20 = var10.getTickMarkOutsideLength();
    var10.setInverted(true);
    org.jfree.chart.axis.TickUnitSource var23 = var10.getStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var9 = var5.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.util.RectangleAnchor var19 = var18.getLegendItemGraphicLocation();
    java.lang.Object var20 = var18.clone();
    org.jfree.chart.util.RectangleAnchor var21 = var18.getLegendItemGraphicLocation();
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
    org.jfree.chart.LegendItemCollection var27 = null;
    var26.setFixedLegendItems(var27);
    java.awt.Stroke var29 = null;
    var26.setOutlineStroke(var29);
    org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var33 = null;
    org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 1.0d);
    double var36 = var35.getLowerBound();
    var32.setRange(var35);
    org.jfree.data.Range var38 = var26.getDataRange((org.jfree.chart.axis.ValueAxis)var32);
    var32.setAutoTickUnitSelection(true, true);
    boolean var42 = var32.isVisible();
    java.awt.Stroke var43 = var32.getAxisLineStroke();
    java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var47 = var46.darker();
    int var48 = var47.getRed();
    var32.setTickMarkPaint((java.awt.Paint)var47);
    var32.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var52 = var32.getStandardTickUnits();
    var32.setVerticalTickLabels(false);
    org.jfree.data.Range var55 = var32.getRange();
    boolean var56 = var32.getAutoRangeIncludesZero();
    double var57 = var32.getLowerBound();
    org.jfree.data.category.CategoryDataset var59 = null;
    org.jfree.chart.axis.CategoryAxis var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var59, var60, var61, var62);
    org.jfree.chart.LegendItemCollection var64 = null;
    var63.setFixedLegendItems(var64);
    org.jfree.data.category.CategoryDataset var67 = var63.getDataset((-254));
    org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var63);
    var68.setTextAntiAlias(false);
    var68.setTextAntiAlias(true);
    java.util.List var73 = var68.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var74 = null;
    org.jfree.chart.event.ChartChangeEvent var75 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var57, var68, var74);
    org.jfree.chart.util.RectangleInsets var76 = var68.getPadding();
    var18.setLegendItemGraphicPadding(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var8 = var4.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var9, (java.lang.Comparable)(-254));
    java.lang.String var12 = var11.getToolTipText();
    org.jfree.chart.block.BlockFrame var13 = var11.getFrame();
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var18 = null;
    org.jfree.chart.util.Size2D var19 = var17.calculateConstrainedSize(var18);
    org.jfree.chart.block.RectangleConstraint var21 = var17.toFixedWidth((-1.0d));
    org.jfree.chart.util.Size2D var22 = var11.arrange(var14, var21);
    var22.setWidth(10.0d);
    java.lang.String var25 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "Size2D[width=10.0, height=0.0]"+ "'", var25.equals("Size2D[width=10.0, height=0.0]"));

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder((-1.0d), 10.0d, 10.0d, (-1.0d));
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var6, "hi!", "hi!");
    var9.setToolTipText("");
    java.lang.String var12 = var9.toString();
    boolean var13 = var4.equals((java.lang.Object)var9);
    java.lang.Object var14 = null;
    boolean var15 = var4.equals(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "ChartEntity: tooltip = "+ "'", var12.equals("ChartEntity: tooltip = "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var9 = var5.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var23 = var22.getAlpha();
//     java.awt.color.ColorSpace var24 = var22.getColorSpace();
//     java.lang.String var25 = var22.toString();
//     var18.setItemPaint((java.awt.Paint)var22);
//     java.awt.Font var27 = var18.getItemFont();
//     org.jfree.chart.util.VerticalAlignment var28 = var18.getVerticalAlignment();
//     org.jfree.chart.util.HorizontalAlignment var29 = null;
//     org.jfree.chart.util.VerticalAlignment var30 = null;
//     org.jfree.chart.block.ColumnArrangement var33 = new org.jfree.chart.block.ColumnArrangement(var29, var30, 1.0d, 0.0d);
//     boolean var35 = var33.equals((java.lang.Object)0.0f);
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 1.0d, 100.0d);
//     org.jfree.chart.block.Block var41 = null;
//     var40.add(var41, (java.lang.Object)1L);
//     org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
//     boolean var46 = var40.equals((java.lang.Object)var45);
//     org.jfree.data.general.Dataset var47 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var49 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var40, var47, (java.lang.Comparable)(byte)100);
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.util.Size2D var54 = null;
//     org.jfree.chart.util.Size2D var55 = var53.calculateConstrainedSize(var54);
//     org.jfree.chart.block.RectangleConstraint var57 = var53.toFixedWidth((-1.0d));
//     double var58 = var57.getWidth();
//     org.jfree.chart.block.LengthConstraintType var59 = var57.getWidthConstraintType();
//     org.jfree.chart.util.Size2D var60 = var33.arrange((org.jfree.chart.block.BlockContainer)var49, var50, var57);
//     java.lang.String var61 = var49.getURLText();
//     var18.setWrapper((org.jfree.chart.block.BlockContainer)var49);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var49
//     assertTrue("Contract failed: equals-hashcode on var12 and var49", var12.equals(var49) ? var12.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var12
//     assertTrue("Contract failed: equals-hashcode on var49 and var12", var49.equals(var12) ? var49.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var8 = var4.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var9, (java.lang.Comparable)(-254));
    java.lang.String var12 = var11.getToolTipText();
    double var13 = var11.getContentXOffset();
    boolean var14 = var11.isEmpty();
    java.lang.String var15 = var11.getID();
    java.lang.String var16 = var11.getURLText();
    java.util.List var17 = var11.getBlocks();
    var11.setURLText("0,-10,10,0,0,10,-10,0,-10,0");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    boolean var2 = var1.isTickLabelsVisible();
    var1.setRangeAboutValue((-15.0d), 10.0d);
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot(var6, var7, var8, var9);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    java.util.List var12 = var10.getCategoriesForAxis(var11);
    org.jfree.chart.util.RectangleInsets var13 = var10.getInsets();
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.FlowArrangement var18 = new org.jfree.chart.block.FlowArrangement(var14, var15, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var21 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var22 = var18.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var23 = null;
    org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var18, var23, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var26 = var25.getBounds();
    org.jfree.chart.util.RectangleAnchor var27 = null;
    java.awt.geom.Point2D var28 = org.jfree.chart.util.RectangleAnchor.coordinates(var26, var27);
    java.awt.geom.Rectangle2D var29 = var13.createOutsetRectangle(var26);
    double var31 = var13.calculateBottomInset(10.0d);
    java.awt.Font var33 = null;
    java.awt.Color var36 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var37 = var36.darker();
    org.jfree.chart.text.TextMeasurer var39 = null;
    org.jfree.chart.text.TextBlock var40 = org.jfree.chart.text.TextUtilities.createTextBlock("", var33, (java.awt.Paint)var37, 0.0f, var39);
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder(var13, (java.awt.Paint)var37);
    var1.setAxisLinePaint((java.awt.Paint)var37);
    var1.setAutoRangeIncludesZero(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }
// 
// 
//     java.awt.Font var1 = null;
//     java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var5 = var4.darker();
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.0f, var7);
//     org.jfree.chart.util.HorizontalAlignment var9 = var8.getLineAlignment();
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement(var9, var10, 100.0d, 1.0d);
//     org.jfree.chart.util.ObjectList var15 = new org.jfree.chart.util.ObjectList(100);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.block.RectangleConstraint var21 = var20.toUnconstrainedWidth();
//     var15.set(100, (java.lang.Object)var20);
//     boolean var23 = var13.equals((java.lang.Object)var15);
//     java.lang.Object var24 = var15.clone();
//     
//     // Checks the contract:  equals-hashcode on var16 and var24
//     assertTrue("Contract failed: equals-hashcode on var16 and var24", var16.equals(var24) ? var16.hashCode() == var24.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var16 and var24.", var16.equals(var24) == var24.equals(var16));
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var10 = var6.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var11 = null;
    org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var11, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var1, (org.jfree.chart.block.Arrangement)var6, (org.jfree.chart.block.Arrangement)var18);
    org.jfree.chart.util.RectangleEdge var20 = var19.getPosition();
    java.lang.String var21 = var19.getID();
    org.jfree.chart.util.VerticalAlignment var22 = var19.getVerticalAlignment();
    java.lang.String var23 = var22.toString();
    org.jfree.chart.block.ColumnArrangement var26 = new org.jfree.chart.block.ColumnArrangement(var0, var22, 10.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "VerticalAlignment.CENTER"+ "'", var23.equals("VerticalAlignment.CENTER"));

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     java.awt.Stroke var7 = null;
//     var4.setOutlineStroke(var7);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
//     double var14 = var13.getLowerBound();
//     var10.setRange(var13);
//     org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
//     var10.setAutoTickUnitSelection(true, true);
//     java.lang.Object var20 = var10.clone();
//     float var21 = var10.getTickMarkInsideLength();
//     java.lang.String var22 = var10.getLabelToolTip();
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.ObjectList var25 = new org.jfree.chart.util.ObjectList(100);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
//     org.jfree.chart.LegendItemCollection var31 = null;
//     var30.setFixedLegendItems(var31);
//     org.jfree.chart.axis.CategoryAxis var34 = var30.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var35 = var30.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     org.jfree.chart.axis.CategoryAxis[] var37 = new org.jfree.chart.axis.CategoryAxis[] { var36};
//     var30.setDomainAxes(var37);
//     org.jfree.chart.plot.DrawingSupplier var39 = var30.getDrawingSupplier();
//     java.awt.Stroke var40 = var30.getDomainGridlineStroke();
//     int var41 = var25.indexOf((java.lang.Object)var30);
//     org.jfree.chart.util.HorizontalAlignment var42 = null;
//     org.jfree.chart.util.VerticalAlignment var43 = null;
//     org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var49 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var50 = var46.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var51 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var46, var51, (java.lang.Comparable)(-254));
//     java.awt.geom.Rectangle2D var54 = var53.getBounds();
//     org.jfree.chart.util.RectangleEdge var55 = null;
//     org.jfree.chart.axis.AxisSpace var56 = null;
//     org.jfree.chart.axis.AxisSpace var57 = var10.reserveSpace(var23, (org.jfree.chart.plot.Plot)var30, var54, var55, var56);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    var4.clearRangeAxes();
    org.jfree.chart.axis.CategoryAnchor var10 = var4.getDomainGridlinePosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(1.0d);
    var1.setMax((-1.0d));
    var1.cursorRight(0.0d);
    var1.cursorUp((-15.0d));
    double var8 = var1.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1.0d));

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }
// 
// 
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var10 = var6.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var11 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var11, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var1, (org.jfree.chart.block.Arrangement)var6, (org.jfree.chart.block.Arrangement)var18);
//     org.jfree.chart.util.RectangleEdge var20 = var19.getPosition();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     org.jfree.chart.axis.ValueAxis var23 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var21, var22, var23, var24);
//     org.jfree.chart.util.SortOrder var26 = var25.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var27 = var25.getColumnRenderingOrder();
//     var25.setForegroundAlpha(0.0f);
//     boolean var30 = var20.equals((java.lang.Object)var25);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     var25.setRenderer(246, var32);
//     org.jfree.chart.LegendItemCollection var34 = var25.getLegendItems();
//     java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var34);
//     org.jfree.data.KeyedObject var36 = new org.jfree.data.KeyedObject((java.lang.Comparable)0.0d, (java.lang.Object)var34);
//     java.lang.Object var37 = var34.clone();
//     
//     // Checks the contract:  equals-hashcode on var35 and var37
//     assertTrue("Contract failed: equals-hashcode on var35 and var37", var35.equals(var37) ? var35.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var35
//     assertTrue("Contract failed: equals-hashcode on var37 and var35", var37.equals(var35) ? var37.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getDescription();
    boolean var84 = var82.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot(var2, var3, var4, var5);
//     org.jfree.chart.LegendItemCollection var7 = null;
//     var6.setFixedLegendItems(var7);
//     org.jfree.data.category.CategoryDataset var10 = var6.getDataset((-254));
//     org.jfree.chart.JFreeChart var11 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var6);
//     org.jfree.chart.title.TextTitle var12 = var11.getTitle();
//     var12.setText("ChartEntity: tooltip = hi!");
//     org.jfree.chart.LegendItemSource var15 = null;
//     org.jfree.chart.util.HorizontalAlignment var16 = null;
//     org.jfree.chart.util.VerticalAlignment var17 = null;
//     org.jfree.chart.block.FlowArrangement var20 = new org.jfree.chart.block.FlowArrangement(var16, var17, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var23 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var24 = var20.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var25 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var27 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var20, var25, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.ColumnArrangement var32 = new org.jfree.chart.block.ColumnArrangement(var28, var29, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle(var15, (org.jfree.chart.block.Arrangement)var20, (org.jfree.chart.block.Arrangement)var32);
//     java.awt.Color var37 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var38 = var37.getAlpha();
//     java.awt.color.ColorSpace var39 = var37.getColorSpace();
//     java.lang.String var40 = var37.toString();
//     var33.setItemPaint((java.awt.Paint)var37);
//     java.awt.Font var42 = var33.getItemFont();
//     var12.setFont(var42);
//     org.jfree.chart.LegendItemSource var44 = null;
//     org.jfree.chart.util.HorizontalAlignment var45 = null;
//     org.jfree.chart.util.VerticalAlignment var46 = null;
//     org.jfree.chart.block.FlowArrangement var49 = new org.jfree.chart.block.FlowArrangement(var45, var46, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var52 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var53 = var49.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var54 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var49, var54, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var57 = null;
//     org.jfree.chart.util.VerticalAlignment var58 = null;
//     org.jfree.chart.block.ColumnArrangement var61 = new org.jfree.chart.block.ColumnArrangement(var57, var58, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var62 = new org.jfree.chart.title.LegendTitle(var44, (org.jfree.chart.block.Arrangement)var49, (org.jfree.chart.block.Arrangement)var61);
//     org.jfree.chart.util.RectangleEdge var63 = var62.getPosition();
//     org.jfree.data.category.CategoryDataset var64 = null;
//     org.jfree.chart.axis.CategoryAxis var65 = null;
//     org.jfree.chart.axis.ValueAxis var66 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var67 = null;
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot(var64, var65, var66, var67);
//     org.jfree.chart.util.SortOrder var69 = var68.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var70 = var68.getColumnRenderingOrder();
//     var68.setForegroundAlpha(0.0f);
//     boolean var73 = var63.equals((java.lang.Object)var68);
//     java.awt.Color var76 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var77 = var76.darker();
//     var68.setBackgroundPaint((java.awt.Paint)var76);
//     org.jfree.chart.block.LabelBlock var79 = new org.jfree.chart.block.LabelBlock("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", var42, (java.awt.Paint)var76);
//     
//     // Checks the contract:  equals-hashcode on var20 and var49
//     assertTrue("Contract failed: equals-hashcode on var20 and var49", var20.equals(var49) ? var20.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var20
//     assertTrue("Contract failed: equals-hashcode on var49 and var20", var49.equals(var20) ? var49.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var52
//     assertTrue("Contract failed: equals-hashcode on var23 and var52", var23.equals(var52) ? var23.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var23
//     assertTrue("Contract failed: equals-hashcode on var52 and var23", var52.equals(var23) ? var52.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var56
//     assertTrue("Contract failed: equals-hashcode on var27 and var56", var27.equals(var56) ? var27.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var27
//     assertTrue("Contract failed: equals-hashcode on var56 and var27", var56.equals(var27) ? var56.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var61
//     assertTrue("Contract failed: equals-hashcode on var32 and var61", var32.equals(var61) ? var32.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var32
//     assertTrue("Contract failed: equals-hashcode on var61 and var32", var61.equals(var32) ? var61.hashCode() == var32.hashCode() : true);
// 
//   }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }


    java.awt.Color var7 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var8 = var7.getBlue();
    org.jfree.chart.block.BlockBorder var9 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var7);
    int var10 = var7.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 255);

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-6.0d));
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var11 = var7.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var12 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var12, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var2, (org.jfree.chart.block.Arrangement)var7, (org.jfree.chart.block.Arrangement)var19);
//     org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
//     org.jfree.chart.axis.CategoryLabelPosition var22 = var1.getLabelPosition(var21);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.LegendItemCollection var28 = null;
//     var27.setFixedLegendItems(var28);
//     org.jfree.data.category.CategoryDataset var31 = var27.getDataset((-254));
//     var27.setAnchorValue(0.0d, false);
//     org.jfree.chart.axis.CategoryAxis var36 = null;
//     var27.setDomainAxis(246, var36, true);
//     java.awt.Color var42 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
//     int var43 = var42.getBlue();
//     java.awt.color.ColorSpace var44 = var42.getColorSpace();
//     var27.setBackgroundPaint((java.awt.Paint)var42);
//     org.jfree.chart.util.RectangleEdge var46 = var27.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var47 = var1.getLabelPosition(var46);
//     org.jfree.chart.axis.CategoryLabelPositions var49 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-6.0d));
//     org.jfree.chart.LegendItemSource var50 = null;
//     org.jfree.chart.util.HorizontalAlignment var51 = null;
//     org.jfree.chart.util.VerticalAlignment var52 = null;
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var51, var52, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var58 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var59 = var55.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var60 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var62 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var55, var60, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var63 = null;
//     org.jfree.chart.util.VerticalAlignment var64 = null;
//     org.jfree.chart.block.ColumnArrangement var67 = new org.jfree.chart.block.ColumnArrangement(var63, var64, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var68 = new org.jfree.chart.title.LegendTitle(var50, (org.jfree.chart.block.Arrangement)var55, (org.jfree.chart.block.Arrangement)var67);
//     org.jfree.chart.util.RectangleEdge var69 = var68.getPosition();
//     org.jfree.chart.axis.CategoryLabelPosition var70 = var49.getLabelPosition(var69);
//     org.jfree.data.category.CategoryDataset var71 = null;
//     org.jfree.chart.axis.CategoryAxis var72 = null;
//     org.jfree.chart.axis.ValueAxis var73 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var74 = null;
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot(var71, var72, var73, var74);
//     org.jfree.chart.LegendItemCollection var76 = null;
//     var75.setFixedLegendItems(var76);
//     org.jfree.data.category.CategoryDataset var79 = var75.getDataset((-254));
//     var75.setAnchorValue(0.0d, false);
//     org.jfree.chart.axis.CategoryAxis var84 = null;
//     var75.setDomainAxis(246, var84, true);
//     java.awt.Color var90 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
//     int var91 = var90.getBlue();
//     java.awt.color.ColorSpace var92 = var90.getColorSpace();
//     var75.setBackgroundPaint((java.awt.Paint)var90);
//     org.jfree.chart.util.RectangleEdge var94 = var75.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var95 = var49.getLabelPosition(var94);
//     double var96 = var95.getAngle();
//     org.jfree.chart.axis.CategoryLabelPositions var97 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var1, var95);
//     
//     // Checks the contract:  equals-hashcode on var7 and var55
//     assertTrue("Contract failed: equals-hashcode on var7 and var55", var7.equals(var55) ? var7.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var7
//     assertTrue("Contract failed: equals-hashcode on var55 and var7", var55.equals(var7) ? var55.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var58
//     assertTrue("Contract failed: equals-hashcode on var10 and var58", var10.equals(var58) ? var10.hashCode() == var58.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var58 and var10
//     assertTrue("Contract failed: equals-hashcode on var58 and var10", var58.equals(var10) ? var58.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var62
//     assertTrue("Contract failed: equals-hashcode on var14 and var62", var14.equals(var62) ? var14.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var14
//     assertTrue("Contract failed: equals-hashcode on var62 and var14", var62.equals(var14) ? var62.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var67
//     assertTrue("Contract failed: equals-hashcode on var19 and var67", var19.equals(var67) ? var19.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var19
//     assertTrue("Contract failed: equals-hashcode on var67 and var19", var67.equals(var19) ? var67.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var75
//     assertTrue("Contract failed: equals-hashcode on var27 and var75", var27.equals(var75) ? var27.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var27
//     assertTrue("Contract failed: equals-hashcode on var75 and var27", var75.equals(var27) ? var75.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    var4.setForegroundAlpha(0.0f);
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    java.awt.geom.Point2D var11 = null;
    var4.zoomRangeAxes((-15.0d), var10, var11);
    java.util.List var13 = var4.getCategories();
    org.jfree.chart.axis.AxisLocation var14 = var4.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
//     java.awt.Paint var11 = var4.getNoDataMessagePaint();
//     var4.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
//     var4.setDomainAxisLocation(var23);
//     org.jfree.data.category.CategoryDataset var26 = var4.getDataset((-16777215));
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.util.HorizontalAlignment var28 = null;
//     org.jfree.chart.util.VerticalAlignment var29 = null;
//     org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var36 = var32.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var37 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var39 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, var37, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var40 = null;
//     org.jfree.chart.util.VerticalAlignment var41 = null;
//     org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var27, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var44);
//     org.jfree.chart.util.RectangleEdge var46 = var45.getPosition();
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
//     org.jfree.chart.util.SortOrder var52 = var51.getColumnRenderingOrder();
//     org.jfree.chart.util.SortOrder var53 = var51.getColumnRenderingOrder();
//     var51.setForegroundAlpha(0.0f);
//     boolean var56 = var46.equals((java.lang.Object)var51);
//     org.jfree.chart.axis.CategoryAnchor var57 = var51.getDomainGridlinePosition();
//     java.awt.Font var58 = var51.getNoDataMessageFont();
//     var4.setParent((org.jfree.chart.plot.Plot)var51);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.data.category.CategoryDataset var63 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var63, var64, var65, var66);
//     var67.setRangeCrosshairValue(0.0d, true);
//     java.awt.Color var73 = java.awt.Color.getColor("hi!", 1);
//     var67.setNoDataMessagePaint((java.awt.Paint)var73);
//     org.jfree.chart.plot.PlotRenderingInfo var76 = null;
//     org.jfree.chart.util.HorizontalAlignment var77 = null;
//     org.jfree.chart.util.VerticalAlignment var78 = null;
//     org.jfree.chart.block.FlowArrangement var81 = new org.jfree.chart.block.FlowArrangement(var77, var78, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var84 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var85 = var81.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var86 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var88 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var81, var86, (java.lang.Comparable)(-254));
//     java.awt.geom.Rectangle2D var89 = var88.getBounds();
//     org.jfree.chart.util.RectangleAnchor var90 = null;
//     java.awt.geom.Point2D var91 = org.jfree.chart.util.RectangleAnchor.coordinates(var89, var90);
//     var67.zoomDomainAxes((-15.0d), var76, var91);
//     var4.zoomDomainAxes(0.0d, (-1.0d), var62, var91);
//     
//     // Checks the contract:  equals-hashcode on var32 and var81
//     assertTrue("Contract failed: equals-hashcode on var32 and var81", var32.equals(var81) ? var32.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var32
//     assertTrue("Contract failed: equals-hashcode on var81 and var32", var81.equals(var32) ? var81.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var84
//     assertTrue("Contract failed: equals-hashcode on var35 and var84", var35.equals(var84) ? var35.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var35
//     assertTrue("Contract failed: equals-hashcode on var84 and var35", var84.equals(var35) ? var84.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var88
//     assertTrue("Contract failed: equals-hashcode on var39 and var88", var39.equals(var88) ? var39.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var39
//     assertTrue("Contract failed: equals-hashcode on var88 and var39", var88.equals(var39) ? var88.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    java.lang.Object var25 = var4.clone();
    org.jfree.chart.util.HorizontalAlignment var26 = null;
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 1.0d, 100.0d);
    org.jfree.chart.block.Block var31 = null;
    var30.add(var31, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var36 = var30.equals((java.lang.Object)var35);
    org.jfree.data.general.Dataset var37 = null;
    org.jfree.chart.title.LegendItemBlockContainer var39 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var37, (java.lang.Comparable)(byte)100);
    var39.setID("ChartEntity: tooltip = hi!");
    org.jfree.chart.util.RectangleInsets var42 = var39.getPadding();
    var4.setInsets(var42, false);
    int var45 = var4.getDatasetCount();
    var4.setRangeGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("java.awt.Color[r=0,g=0,b=1]", "ChartEntity: tooltip = ", "", var3, "ChartEntity: tooltip = hi!", "", "hi!");
    var7.addOptionalLibrary("ChartEntity: tooltip = hi!");
    var7.setLicenceName("");
    java.lang.String var12 = var7.getLicenceText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    java.awt.Stroke var11 = null;
    var8.setOutlineStroke(var11);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    double var18 = var17.getLowerBound();
    var14.setRange(var17);
    org.jfree.data.Range var20 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    var14.setAutoTickUnitSelection(true, true);
    boolean var24 = var14.isVisible();
    java.awt.Stroke var25 = var14.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var30.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleInsets var33 = var30.getInsets();
    double var35 = var33.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var25, var33);
    org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.FlowArrangement var44 = new org.jfree.chart.block.FlowArrangement(var40, var41, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var47 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var48 = var44.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var49 = null;
    org.jfree.chart.title.LegendItemBlockContainer var51 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var44, var49, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var52 = null;
    org.jfree.chart.util.VerticalAlignment var53 = null;
    org.jfree.chart.block.ColumnArrangement var56 = new org.jfree.chart.block.ColumnArrangement(var52, var53, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var57 = new org.jfree.chart.title.LegendTitle(var39, (org.jfree.chart.block.Arrangement)var44, (org.jfree.chart.block.Arrangement)var56);
    java.awt.Color var61 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var62 = var61.getAlpha();
    java.awt.color.ColorSpace var63 = var61.getColorSpace();
    java.lang.String var64 = var61.toString();
    var57.setItemPaint((java.awt.Paint)var61);
    java.awt.Font var66 = var57.getItemFont();
    org.jfree.chart.block.LabelBlock var67 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var66);
    java.lang.Object var68 = var67.clone();
    java.awt.geom.Rectangle2D var69 = var67.getBounds();
    java.awt.geom.Rectangle2D var70 = var37.createInsetRectangle(var69);
    double var71 = var37.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var64 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var64.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 4.0d);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }
// 
// 
//     org.jfree.chart.LegendItemSource var1 = null;
//     org.jfree.chart.util.HorizontalAlignment var2 = null;
//     org.jfree.chart.util.VerticalAlignment var3 = null;
//     org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var10 = var6.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var11 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var11, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var14 = null;
//     org.jfree.chart.util.VerticalAlignment var15 = null;
//     org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var1, (org.jfree.chart.block.Arrangement)var6, (org.jfree.chart.block.Arrangement)var18);
//     java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var24 = var23.getAlpha();
//     java.awt.color.ColorSpace var25 = var23.getColorSpace();
//     java.lang.String var26 = var23.toString();
//     var19.setItemPaint((java.awt.Paint)var23);
//     java.awt.Font var28 = var19.getItemFont();
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var28);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     java.util.List var36 = var34.getCategoriesForAxis(var35);
//     org.jfree.chart.util.RectangleInsets var37 = var34.getInsets();
//     double var39 = var37.trimHeight(10.0d);
//     var29.setPadding(var37);
//     java.lang.String var41 = var29.getURLText();
//     var29.setURLText("ChartEntity: tooltip = hi!");
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.LegendItemCollection var49 = null;
//     var48.setFixedLegendItems(var49);
//     org.jfree.chart.axis.CategoryAxis var52 = var48.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var54 = var48.getRangeAxisLocation((-16777215));
//     java.awt.Paint var55 = var48.getNoDataMessagePaint();
//     var48.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var57 = null;
//     org.jfree.chart.axis.CategoryAxis var58 = null;
//     org.jfree.chart.axis.ValueAxis var59 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
//     org.jfree.chart.LegendItemCollection var62 = null;
//     var61.setFixedLegendItems(var62);
//     org.jfree.chart.axis.CategoryAxis var65 = var61.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var67 = var61.getRangeAxisLocation((-16777215));
//     var48.setDomainAxisLocation(var67);
//     boolean var69 = var48.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var72 = null;
//     org.jfree.chart.util.HorizontalAlignment var73 = null;
//     org.jfree.chart.util.VerticalAlignment var74 = null;
//     org.jfree.chart.block.FlowArrangement var77 = new org.jfree.chart.block.FlowArrangement(var73, var74, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var80 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var81 = var77.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var82 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var84 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var77, var82, (java.lang.Comparable)(-254));
//     java.awt.geom.Rectangle2D var85 = var84.getBounds();
//     org.jfree.chart.util.RectangleAnchor var86 = null;
//     java.awt.geom.Point2D var87 = org.jfree.chart.util.RectangleAnchor.coordinates(var85, var86);
//     var48.zoomRangeAxes((-15.0d), (-15.0d), var72, var87);
//     org.jfree.chart.plot.DatasetRenderingOrder var89 = var48.getDatasetRenderingOrder();
//     boolean var90 = var29.equals((java.lang.Object)var48);
//     
//     // Checks the contract:  equals-hashcode on var6 and var77
//     assertTrue("Contract failed: equals-hashcode on var6 and var77", var6.equals(var77) ? var6.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var6
//     assertTrue("Contract failed: equals-hashcode on var77 and var6", var77.equals(var6) ? var77.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var80
//     assertTrue("Contract failed: equals-hashcode on var9 and var80", var9.equals(var80) ? var9.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var9
//     assertTrue("Contract failed: equals-hashcode on var80 and var9", var80.equals(var9) ? var80.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var84
//     assertTrue("Contract failed: equals-hashcode on var13 and var84", var13.equals(var84) ? var13.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var13
//     assertTrue("Contract failed: equals-hashcode on var84 and var13", var84.equals(var13) ? var84.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var61
//     assertTrue("Contract failed: equals-hashcode on var34 and var61", var34.equals(var61) ? var34.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var34
//     assertTrue("Contract failed: equals-hashcode on var61 and var34", var61.equals(var34) ? var61.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomRangeAxes(10.0d, var13, var14);
    var4.setWeight(0);
    java.awt.Paint var18 = var4.getOutlinePaint();
    org.jfree.chart.util.RectangleEdge var20 = var4.getRangeAxisEdge((-254));
    boolean var21 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("LegendItemEntity: seriesKey=0, dataset=null", "java.awt.Color[r=0,g=0,b=1]", "hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:hi! hi! ().hi! hi! ().\nhi! LICENCE TERMS:\nhi!", "Size2D[width=10.0, height=0.0]", "hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:hi! hi! ().hi! hi! ().\nhi! LICENCE TERMS:\nhi!");

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var11 = var10.getTitle();
    var11.setText("ChartEntity: tooltip = hi!");
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var15, var16, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var23 = var19.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var24 = null;
    org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var24, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var27 = null;
    org.jfree.chart.util.VerticalAlignment var28 = null;
    org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var14, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var31);
    java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var37 = var36.getAlpha();
    java.awt.color.ColorSpace var38 = var36.getColorSpace();
    java.lang.String var39 = var36.toString();
    var32.setItemPaint((java.awt.Paint)var36);
    java.awt.Font var41 = var32.getItemFont();
    var11.setFont(var41);
    java.awt.Paint var43 = null;
    var11.setBackgroundPaint(var43);
    var11.setText("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    var11.setText("LegendItemEntity: seriesKey=0, dataset=null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var39.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 1.0d);
    double var3 = var2.getLowerBound();
    boolean var6 = var2.intersects((-1.0d), (-1.0d));
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var10 = null;
    org.jfree.chart.util.Size2D var11 = var9.calculateConstrainedSize(var10);
    org.jfree.chart.block.RectangleConstraint var13 = var9.toFixedWidth((-1.0d));
    org.jfree.data.Range var14 = null;
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    org.jfree.data.Range var18 = org.jfree.data.Range.combine(var14, var17);
    org.jfree.chart.block.RectangleConstraint var19 = var9.toRangeHeight(var17);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint(var2, var17);
    double var21 = var20.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 1.0d);
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var6);
    org.jfree.chart.block.LengthConstraintType var9 = var8.getHeightConstraintType();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    org.jfree.chart.util.SortOrder var15 = var14.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
    var14.setForegroundAlpha(0.0f);
    boolean var19 = var9.equals((java.lang.Object)var14);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    java.awt.Stroke var27 = null;
    var24.setOutlineStroke(var27);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 1.0d);
    double var34 = var33.getLowerBound();
    var30.setRange(var33);
    org.jfree.data.Range var36 = var24.getDataRange((org.jfree.chart.axis.ValueAxis)var30);
    var30.setAutoTickUnitSelection(true, true);
    boolean var40 = var30.isVisible();
    java.awt.Stroke var41 = var30.getAxisLineStroke();
    java.awt.Color var44 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var45 = var44.darker();
    int var46 = var45.getRed();
    var30.setTickMarkPaint((java.awt.Paint)var45);
    var30.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var50 = var30.getStandardTickUnits();
    var30.setVerticalTickLabels(false);
    org.jfree.data.Range var53 = var30.getRange();
    boolean var54 = var30.getAutoRangeIncludesZero();
    double var55 = var30.getLowerBound();
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
    org.jfree.chart.LegendItemCollection var62 = null;
    var61.setFixedLegendItems(var62);
    org.jfree.data.category.CategoryDataset var65 = var61.getDataset((-254));
    org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var61);
    var66.setTextAntiAlias(false);
    var66.setTextAntiAlias(true);
    java.util.List var71 = var66.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var72 = null;
    org.jfree.chart.event.ChartChangeEvent var73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var66, var72);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var66);
    org.jfree.chart.util.Layer var76 = null;
    java.util.Collection var77 = var14.getRangeMarkers(0, var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var10 = var6.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var11 = null;
    org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var11, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var1, (org.jfree.chart.block.Arrangement)var6, (org.jfree.chart.block.Arrangement)var18);
    java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var24 = var23.getAlpha();
    java.awt.color.ColorSpace var25 = var23.getColorSpace();
    java.lang.String var26 = var23.toString();
    var19.setItemPaint((java.awt.Paint)var23);
    java.awt.Font var28 = var19.getItemFont();
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var28);
    org.jfree.data.category.CategoryDataset var30 = null;
    org.jfree.chart.axis.CategoryAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
    org.jfree.chart.axis.CategoryAxis var35 = null;
    java.util.List var36 = var34.getCategoriesForAxis(var35);
    org.jfree.chart.util.RectangleInsets var37 = var34.getInsets();
    double var39 = var37.trimHeight(10.0d);
    var29.setPadding(var37);
    double var42 = var37.calculateRightInset(10.0d);
    double var44 = var37.trimWidth((-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var26.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-22.0d));

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getDescription();
    org.jfree.chart.util.GradientPaintTransformer var84 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var82.setFillPaintTransformer(var84);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    var10.setDownArrow(var18);
    java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
    int var28 = var27.getRGB();
    java.lang.String var29 = var27.toString();
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
    var10.setTickMarkPaint((java.awt.Paint)var27);
    java.awt.Stroke var32 = var10.getAxisLineStroke();
    org.jfree.data.Range var33 = var10.getRange();
    var10.setFixedAutoRange((-19.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var29.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
//     java.awt.Paint var11 = var4.getNoDataMessagePaint();
//     var4.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
//     org.jfree.chart.LegendItemCollection var18 = null;
//     var17.setFixedLegendItems(var18);
//     org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
//     var4.setDomainAxisLocation(var23);
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var28 = var27.darker();
//     int var29 = var28.getRed();
//     var4.setOutlinePaint((java.awt.Paint)var28);
//     org.jfree.chart.util.RectangleEdge var32 = var4.getDomainAxisEdge(10);
//     int var33 = var4.getDatasetCount();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
//     var40.setRangeCrosshairValue(0.0d, true);
//     var40.configureDomainAxes();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.FlowArrangement var52 = new org.jfree.chart.block.FlowArrangement(var48, var49, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var55 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var56 = var52.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var57 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var59 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var52, var57, (java.lang.Comparable)(-254));
//     java.awt.geom.Rectangle2D var60 = var59.getBounds();
//     org.jfree.chart.util.RectangleAnchor var61 = null;
//     java.awt.geom.Point2D var62 = org.jfree.chart.util.RectangleAnchor.coordinates(var60, var61);
//     var40.zoomRangeAxes((-1.0d), 0.0d, var47, var62);
//     var4.zoomRangeAxes((-7.0d), var35, var62);
//     
//     // Checks the contract:  equals-hashcode on var17 and var40
//     assertTrue("Contract failed: equals-hashcode on var17 and var40", var17.equals(var40) ? var17.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var17
//     assertTrue("Contract failed: equals-hashcode on var40 and var17", var40.equals(var17) ? var40.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    org.jfree.chart.entity.LegendItemEntity var5 = new org.jfree.chart.entity.LegendItemEntity(var1);
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.chart.block.Block var11 = null;
    var10.add(var11, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var16 = var10.equals((java.lang.Object)var15);
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var17, (java.lang.Comparable)(byte)100);
    var19.setID("ChartEntity: tooltip = hi!");
    org.jfree.chart.util.RectangleInsets var22 = var19.getPadding();
    boolean var23 = var5.equals((java.lang.Object)var22);
    java.lang.Object var24 = var5.clone();
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    java.util.List var31 = var29.getCategoriesForAxis(var30);
    java.awt.Paint var32 = var29.getBackgroundPaint();
    var29.setRangeGridlinesVisible(false);
    boolean var35 = var5.equals((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var9 = var4.getRangeAxisLocation();
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
//     org.jfree.chart.LegendItemCollection var15 = null;
//     var14.setFixedLegendItems(var15);
//     org.jfree.chart.axis.CategoryAxis var18 = var14.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var19 = var14.getRangeAxisLocation();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
//     org.jfree.chart.LegendItemCollection var25 = null;
//     var24.setFixedLegendItems(var25);
//     org.jfree.data.category.CategoryDataset var28 = var24.getDataset((-254));
//     org.jfree.data.category.CategoryDataset var30 = var24.getDataset((-1));
//     java.awt.Color var38 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
//     int var39 = var38.getBlue();
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var38);
//     var24.setDomainGridlinePaint((java.awt.Paint)var38);
//     boolean var42 = var24.isSubplot();
//     var24.setNoDataMessage("100");
//     org.jfree.chart.plot.PlotOrientation var45 = var24.getOrientation();
//     org.jfree.chart.util.RectangleEdge var46 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var19, var45);
//     org.jfree.chart.util.RectangleEdge var47 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var9, var45);
//     
//     // Checks the contract:  equals-hashcode on var4 and var14
//     assertTrue("Contract failed: equals-hashcode on var4 and var14", var4.equals(var14) ? var4.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var4
//     assertTrue("Contract failed: equals-hashcode on var14 and var4", var14.equals(var4) ? var14.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var3 = null;
    org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
    double var5 = var2.getHeight();
    org.jfree.data.Range var6 = var2.getWidthRange();
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot(var8, var9, var10, var11);
    org.jfree.chart.LegendItemCollection var13 = null;
    var12.setFixedLegendItems(var13);
    java.awt.Stroke var15 = null;
    var12.setOutlineStroke(var15);
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var19 = null;
    org.jfree.data.Range var21 = org.jfree.data.Range.expandToInclude(var19, 1.0d);
    double var22 = var21.getLowerBound();
    var18.setRange(var21);
    org.jfree.data.Range var24 = var12.getDataRange((org.jfree.chart.axis.ValueAxis)var18);
    var18.setAutoTickUnitSelection(true, true);
    boolean var28 = var18.isVisible();
    java.awt.Stroke var29 = var18.getAxisLineStroke();
    java.awt.Color var32 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var33 = var32.darker();
    int var34 = var33.getRed();
    var18.setTickMarkPaint((java.awt.Paint)var33);
    var18.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var38 = var18.getStandardTickUnits();
    var18.setVerticalTickLabels(false);
    org.jfree.data.Range var41 = var18.getRange();
    org.jfree.chart.block.RectangleConstraint var42 = new org.jfree.chart.block.RectangleConstraint(10.0d, var41);
    org.jfree.data.Range var45 = org.jfree.data.Range.shift(var41, 0.0d, false);
    org.jfree.chart.block.RectangleConstraint var46 = var2.toRangeWidth(var41);
    double var47 = var41.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1.0d);

  }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var9 = var4.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.CategoryAxis[] var11 = new org.jfree.chart.axis.CategoryAxis[] { var10};
//     var4.setDomainAxes(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var4.getDrawingSupplier();
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     org.jfree.chart.util.SortOrder var15 = var4.getColumnRenderingOrder();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     java.awt.Color var22 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = null;
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
//     org.jfree.chart.LegendItemCollection var28 = null;
//     var27.setFixedLegendItems(var28);
//     java.awt.Stroke var30 = null;
//     var27.setOutlineStroke(var30);
//     org.jfree.chart.axis.NumberAxis var33 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var34 = null;
//     org.jfree.data.Range var36 = org.jfree.data.Range.expandToInclude(var34, 1.0d);
//     double var37 = var36.getLowerBound();
//     var33.setRange(var36);
//     org.jfree.data.Range var39 = var27.getDataRange((org.jfree.chart.axis.ValueAxis)var33);
//     var33.setAutoTickUnitSelection(true, true);
//     boolean var43 = var33.isVisible();
//     java.awt.Stroke var44 = var33.getAxisLineStroke();
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.ValueAxis var47 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var45, var46, var47, var48);
//     org.jfree.chart.axis.CategoryAxis var50 = null;
//     java.util.List var51 = var49.getCategoriesForAxis(var50);
//     org.jfree.chart.util.RectangleInsets var52 = var49.getInsets();
//     double var54 = var52.trimHeight(10.0d);
//     org.jfree.chart.block.LineBorder var55 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var22, var44, var52);
//     var18.setAxisLineStroke(var44);
//     double var57 = var18.getLowerBound();
//     var18.setAutoTickUnitSelection(true, true);
//     var4.setRangeAxis(100, (org.jfree.chart.axis.ValueAxis)var18, true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var4
//     assertTrue("Contract failed: equals-hashcode on var49 and var4", var49.equals(var4) ? var49.hashCode() == var4.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var49 and var4.", var49.equals(var4) == var4.equals(var49));
// 
//   }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    org.jfree.data.general.DatasetChangeEvent var11 = null;
    var4.datasetChanged(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var5, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var28 = var27.getAlpha();
    java.awt.color.ColorSpace var29 = var27.getColorSpace();
    java.lang.String var30 = var27.toString();
    var23.setItemPaint((java.awt.Paint)var27);
    java.awt.Font var32 = var23.getItemFont();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var32);
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Rectangle2D var35 = var33.getBounds();
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
    org.jfree.chart.LegendItemCollection var41 = null;
    var40.setFixedLegendItems(var41);
    org.jfree.chart.axis.CategoryAxis var44 = var40.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var46 = var40.getRangeAxisLocation((-16777215));
    java.awt.Paint var47 = var40.getNoDataMessagePaint();
    var40.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
    org.jfree.chart.LegendItemCollection var54 = null;
    var53.setFixedLegendItems(var54);
    org.jfree.chart.axis.CategoryAxis var57 = var53.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var59 = var53.getRangeAxisLocation((-16777215));
    var40.setDomainAxisLocation(var59);
    java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var64 = var63.darker();
    int var65 = var64.getRed();
    var40.setOutlinePaint((java.awt.Paint)var64);
    org.jfree.chart.util.RectangleEdge var68 = var40.getDomainAxisEdge(10);
    double var69 = var1.getCategoryMiddle(1, 246, var35, var68);
    org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    java.awt.Paint var72 = var71.getPaint();
    var1.setAxisLinePaint(var72);
    java.lang.Object var74 = var1.clone();
    org.jfree.chart.axis.CategoryLabelPositions var75 = var1.getCategoryLabelPositions();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    java.awt.geom.Point2D var14 = null;
    var4.zoomDomainAxes(10.0d, (-1.0d), var13, var14);
    int var16 = var4.getRangeAxisCount();
    org.jfree.chart.LegendItemSource var17 = null;
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var25 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var26 = var22.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var27 = null;
    org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var22, var27, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.ColumnArrangement var34 = new org.jfree.chart.block.ColumnArrangement(var30, var31, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle(var17, (org.jfree.chart.block.Arrangement)var22, (org.jfree.chart.block.Arrangement)var34);
    org.jfree.chart.util.RectangleEdge var36 = var35.getPosition();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.util.SortOrder var42 = var41.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var43 = var41.getColumnRenderingOrder();
    var41.setForegroundAlpha(0.0f);
    boolean var46 = var36.equals((java.lang.Object)var41);
    org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
    var41.setRenderer(246, var48);
    var41.clearDomainMarkers(100);
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("Size2D[width=1.0, height=-1.0]");
    double var55 = var54.getCategoryMargin();
    var54.clearCategoryLabelToolTips();
    var41.setDomainAxis(246, var54);
    java.util.List var58 = var4.getCategoriesForAxis(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.CategoryAxis var5 = null;
    java.util.List var6 = var4.getCategoriesForAxis(var5);
    org.jfree.chart.util.RectangleInsets var7 = var4.getInsets();
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement(var8, var9, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var15 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var16 = var12.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, var17, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var20 = var19.getBounds();
    org.jfree.chart.util.RectangleAnchor var21 = null;
    java.awt.geom.Point2D var22 = org.jfree.chart.util.RectangleAnchor.coordinates(var20, var21);
    java.awt.geom.Rectangle2D var23 = var7.createOutsetRectangle(var20);
    double var25 = var7.calculateBottomInset(10.0d);
    java.awt.Color var29 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var7, (java.awt.Paint)var29);
    java.awt.Paint var31 = var30.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var15 = var10.createBufferedImage((-10), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
    var4.setNoDataMessagePaint((java.awt.Paint)var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.chart.axis.CategoryAxis var20 = var16.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var22 = var16.getRangeAxisLocation((-16777215));
    var4.setRangeAxisLocation(var22);
    var4.setOutlineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 1.0f);
    org.jfree.chart.entity.LegendItemEntity var3 = new org.jfree.chart.entity.LegendItemEntity(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.setBorderVisible(false);
    org.jfree.chart.title.LegendTitle var18 = var10.getLegend(0);
    var10.removeLegend();
    org.jfree.chart.title.LegendTitle var21 = var10.getLegend(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range((-15.0d), (-7.0d));

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    org.jfree.data.category.CategoryDataset var26 = var4.getDataset((-16777215));
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var35 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var36 = var32.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var37 = null;
    org.jfree.chart.title.LegendItemBlockContainer var39 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, var37, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var40 = null;
    org.jfree.chart.util.VerticalAlignment var41 = null;
    org.jfree.chart.block.ColumnArrangement var44 = new org.jfree.chart.block.ColumnArrangement(var40, var41, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var45 = new org.jfree.chart.title.LegendTitle(var27, (org.jfree.chart.block.Arrangement)var32, (org.jfree.chart.block.Arrangement)var44);
    org.jfree.chart.util.RectangleEdge var46 = var45.getPosition();
    org.jfree.data.category.CategoryDataset var47 = null;
    org.jfree.chart.axis.CategoryAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var47, var48, var49, var50);
    org.jfree.chart.util.SortOrder var52 = var51.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var53 = var51.getColumnRenderingOrder();
    var51.setForegroundAlpha(0.0f);
    boolean var56 = var46.equals((java.lang.Object)var51);
    org.jfree.chart.axis.CategoryAnchor var57 = var51.getDomainGridlinePosition();
    java.awt.Font var58 = var51.getNoDataMessageFont();
    var4.setParent((org.jfree.chart.plot.Plot)var51);
    var4.setBackgroundImageAlignment((-254));
    org.jfree.chart.axis.ValueAxis var63 = var4.getRangeAxis(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var9 = var4.getRangeAxisLocation();
//     org.jfree.chart.plot.Marker var11 = null;
//     org.jfree.chart.util.Layer var12 = null;
//     var4.addRangeMarker((-10), var11, var12);
// 
//   }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset((-254));
    org.jfree.data.category.CategoryDataset var10 = var4.getDataset((-1));
    java.awt.Color var18 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var19 = var18.getBlue();
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var18);
    var4.setDomainGridlinePaint((java.awt.Paint)var18);
    boolean var22 = var4.isSubplot();
    var4.setNoDataMessage("100");
    org.jfree.chart.plot.PlotOrientation var25 = var4.getOrientation();
    java.lang.String var26 = var25.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "PlotOrientation.VERTICAL"+ "'", var26.equals("PlotOrientation.VERTICAL"));

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var11 = var10.getTitle();
    org.jfree.chart.LegendItemSource var12 = null;
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var20 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var21 = var17.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var22 = null;
    org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var17, var22, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var12, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var29);
    java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var35 = var34.getAlpha();
    java.awt.color.ColorSpace var36 = var34.getColorSpace();
    java.lang.String var37 = var34.toString();
    var30.setItemPaint((java.awt.Paint)var34);
    org.jfree.chart.LegendItemSource var39 = null;
    org.jfree.chart.LegendItemSource[] var40 = new org.jfree.chart.LegendItemSource[] { var39};
    var30.setSources(var40);
    java.awt.Font var43 = null;
    java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var47 = var46.darker();
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, 0.0f, var49);
    java.awt.Graphics2D var51 = null;
    org.jfree.chart.util.Size2D var52 = var50.calculateDimensions(var51);
    org.jfree.chart.util.HorizontalAlignment var53 = var50.getLineAlignment();
    var30.setHorizontalAlignment(var53);
    var11.setTextAlignment(var53);
    java.lang.Object var56 = var11.clone();
    boolean var57 = var11.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var37.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    double var2 = var1.getAutoRangeMinimumSize();
    var1.setAutoRangeIncludesZero(false);
    var1.setPositiveArrowVisible(true);
    double var7 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.clearSubtitles();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(0.0d, true);
    var4.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var9 = null;
    var4.setDataset(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    java.awt.Stroke var19 = null;
    var16.setOutlineStroke(var19);
    java.awt.Paint[] var21 = null;
    java.awt.Color var25 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var26 = var25.getAlpha();
    java.awt.color.ColorSpace var27 = var25.getColorSpace();
    java.lang.String var28 = var25.toString();
    java.awt.Paint[] var29 = new java.awt.Paint[] { var25};
    java.awt.Font var31 = null;
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var35 = var34.darker();
    org.jfree.chart.text.TextMeasurer var37 = null;
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, (java.awt.Paint)var35, 0.0f, var37);
    java.awt.Paint[] var39 = new java.awt.Paint[] { var35};
    java.awt.Stroke var40 = null;
    java.awt.Stroke[] var41 = new java.awt.Stroke[] { var40};
    java.awt.Stroke var42 = null;
    java.awt.Stroke[] var43 = new java.awt.Stroke[] { var42};
    java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var46 = new org.jfree.chart.entity.ChartEntity(var45);
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var50 = org.jfree.chart.util.ShapeUtilities.equal(var45, var49);
    java.awt.Shape[] var51 = new java.awt.Shape[] { var45};
    org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var21, var29, var39, var41, var43, var51);
    var16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var52);
    java.awt.Paint var54 = var52.getNextOutlinePaint();
    var4.setNoDataMessagePaint(var54);
    org.jfree.chart.util.SortOrder var56 = var4.getColumnRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var28.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
    var4.setRenderer(var25, true);
    org.jfree.chart.plot.CategoryMarker var28 = null;
    org.jfree.chart.util.Layer var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var28, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("java.awt.Color[r=0,g=0,b=0]");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset((-254));
    org.jfree.data.category.CategoryDataset var10 = var4.getDataset((-1));
    java.awt.Color var18 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var19 = var18.getBlue();
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var18);
    var4.setDomainGridlinePaint((java.awt.Paint)var18);
    boolean var22 = var4.isSubplot();
    org.jfree.chart.axis.ValueAxis var23 = var4.getRangeAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var11 = var10.getTitle();
//     var11.setText("ChartEntity: tooltip = hi!");
//     var11.setText("hi!");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     org.jfree.chart.util.SortOrder var22 = var21.getColumnRenderingOrder();
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement(var23, var24, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var30 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var31 = var27.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var32 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var34 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var27, var32, (java.lang.Comparable)(-254));
//     java.awt.geom.Rectangle2D var35 = var34.getBounds();
//     boolean var36 = var22.equals((java.lang.Object)var35);
//     org.jfree.chart.util.HorizontalAlignment var37 = null;
//     org.jfree.chart.util.VerticalAlignment var38 = null;
//     org.jfree.chart.block.FlowArrangement var41 = new org.jfree.chart.block.FlowArrangement(var37, var38, 1.0d, 100.0d);
//     org.jfree.chart.block.Block var42 = null;
//     var41.add(var42, (java.lang.Object)1L);
//     org.jfree.chart.event.ChartChangeEvent var46 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
//     boolean var47 = var41.equals((java.lang.Object)var46);
//     org.jfree.data.general.Dataset var48 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var50 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var41, var48, (java.lang.Comparable)(byte)100);
//     var50.setID("ChartEntity: tooltip = hi!");
//     java.lang.Comparable var53 = var50.getSeriesKey();
//     java.lang.Object var54 = var11.draw(var16, var35, (java.lang.Object)var53);
//     
//     // Checks the contract:  equals-hashcode on var5 and var21
//     assertTrue("Contract failed: equals-hashcode on var5 and var21", var5.equals(var21) ? var5.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var5
//     assertTrue("Contract failed: equals-hashcode on var21 and var5", var21.equals(var5) ? var21.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var41
//     assertTrue("Contract failed: equals-hashcode on var27 and var41", var27.equals(var41) ? var27.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var27
//     assertTrue("Contract failed: equals-hashcode on var41 and var27", var41.equals(var27) ? var41.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.setNotify(false);
    java.util.List var17 = var10.getSubtitles();
    org.jfree.chart.plot.Plot var18 = var10.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     double var2 = var1.getAutoRangeMinimumSize();
//     boolean var3 = var1.getAutoRangeIncludesZero();
//     java.awt.Paint var4 = var1.getAxisLinePaint();
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot(var5, var6, var7, var8);
//     org.jfree.chart.LegendItemCollection var10 = null;
//     var9.setFixedLegendItems(var10);
//     org.jfree.chart.axis.CategoryAxis var13 = var9.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var14 = var9.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.CategoryAxis[] var16 = new org.jfree.chart.axis.CategoryAxis[] { var15};
//     var9.setDomainAxes(var16);
//     org.jfree.chart.plot.DrawingSupplier var18 = var9.getDrawingSupplier();
//     java.awt.Stroke var19 = var9.getDomainGridlineStroke();
//     java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
//     org.jfree.data.category.CategoryDataset var24 = null;
//     org.jfree.chart.axis.CategoryAxis var25 = null;
//     org.jfree.chart.axis.ValueAxis var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
//     org.jfree.chart.LegendItemCollection var29 = null;
//     var28.setFixedLegendItems(var29);
//     java.awt.Stroke var31 = null;
//     var28.setOutlineStroke(var31);
//     org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var35 = null;
//     org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 1.0d);
//     double var38 = var37.getLowerBound();
//     var34.setRange(var37);
//     org.jfree.data.Range var40 = var28.getDataRange((org.jfree.chart.axis.ValueAxis)var34);
//     var34.setAutoTickUnitSelection(true, true);
//     boolean var44 = var34.isVisible();
//     java.awt.Stroke var45 = var34.getAxisLineStroke();
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     java.util.List var52 = var50.getCategoriesForAxis(var51);
//     org.jfree.chart.util.RectangleInsets var53 = var50.getInsets();
//     double var55 = var53.trimHeight(10.0d);
//     org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var23, var45, var53);
//     double var58 = var53.calculateTopInset((-6.0d));
//     double var60 = var53.trimHeight(1.0d);
//     org.jfree.chart.block.LineBorder var61 = new org.jfree.chart.block.LineBorder(var4, var19, var53);
//     
//     // Checks the contract:  equals-hashcode on var9 and var50
//     assertTrue("Contract failed: equals-hashcode on var9 and var50", var9.equals(var50) ? var9.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var9
//     assertTrue("Contract failed: equals-hashcode on var50 and var9", var50.equals(var9) ? var50.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var9 = var5.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
    java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var23 = var22.getAlpha();
    java.awt.color.ColorSpace var24 = var22.getColorSpace();
    java.lang.String var25 = var22.toString();
    var18.setItemPaint((java.awt.Paint)var22);
    org.jfree.chart.LegendItemSource var27 = null;
    org.jfree.chart.LegendItemSource[] var28 = new org.jfree.chart.LegendItemSource[] { var27};
    var18.setSources(var28);
    java.awt.Font var31 = null;
    java.awt.Color var34 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var35 = var34.darker();
    org.jfree.chart.text.TextMeasurer var37 = null;
    org.jfree.chart.text.TextBlock var38 = org.jfree.chart.text.TextUtilities.createTextBlock("", var31, (java.awt.Paint)var35, 0.0f, var37);
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.util.Size2D var40 = var38.calculateDimensions(var39);
    org.jfree.chart.util.HorizontalAlignment var41 = var38.getLineAlignment();
    var18.setHorizontalAlignment(var41);
    org.jfree.chart.util.RectangleAnchor var43 = var18.getLegendItemGraphicAnchor();
    org.jfree.chart.event.ChartChangeEvent var44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var43);
    org.jfree.chart.text.TextBlockAnchor var45 = null;
    org.jfree.chart.text.TextAnchor var46 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var48 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var50 = new org.jfree.chart.axis.CategoryLabelPosition(var43, var45, var46, (-22.0d), var48, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var25.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var2);
    java.lang.String var4 = var1.getText();
    java.awt.Font var5 = var1.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var4.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }
// 
// 
//     org.jfree.chart.LegendItemSource var2 = null;
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var11 = var7.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var12 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var12, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var2, (org.jfree.chart.block.Arrangement)var7, (org.jfree.chart.block.Arrangement)var19);
//     java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var25 = var24.getAlpha();
//     java.awt.color.ColorSpace var26 = var24.getColorSpace();
//     java.lang.String var27 = var24.toString();
//     var20.setItemPaint((java.awt.Paint)var24);
//     java.awt.Font var29 = var20.getItemFont();
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var29);
//     java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var35 = var34.getAlpha();
//     java.awt.color.ColorSpace var36 = var34.getColorSpace();
//     org.jfree.chart.text.TextLine var37 = new org.jfree.chart.text.TextLine("0,-10,10,0,0,10,-10,0,-10,0", var29, (java.awt.Paint)var34);
//     org.jfree.chart.text.TextFragment var38 = var37.getLastTextFragment();
//     org.jfree.chart.text.TextFragment var39 = var37.getFirstTextFragment();
//     org.jfree.chart.text.TextFragment var40 = var37.getFirstTextFragment();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.util.Size2D var42 = var37.calculateDimensions(var41);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.0f, var7);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.util.Size2D var10 = var8.calculateDimensions(var9);
    org.jfree.chart.util.HorizontalAlignment var11 = var8.getLineAlignment();
    org.jfree.chart.text.TextLine var12 = var8.getLastLine();
    org.jfree.chart.util.HorizontalAlignment var13 = var8.getLineAlignment();
    org.jfree.chart.util.HorizontalAlignment var14 = var8.getLineAlignment();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    var8.draw(var15, 1.0f, (-1.0f), var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.axis.AxisLocation var6 = var4.getRangeAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var7 = var4.getDatasetRenderingOrder();
    boolean var8 = var4.isRangeGridlinesVisible();
    boolean var9 = var4.isRangeCrosshairVisible();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    org.jfree.chart.LegendItemCollection var15 = null;
    var14.setFixedLegendItems(var15);
    org.jfree.chart.axis.CategoryAxis var18 = var14.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var20 = var14.getRangeAxisLocation((-16777215));
    java.awt.Paint var21 = var14.getNoDataMessagePaint();
    var14.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    org.jfree.chart.LegendItemCollection var28 = null;
    var27.setFixedLegendItems(var28);
    org.jfree.chart.axis.CategoryAxis var31 = var27.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var33 = var27.getRangeAxisLocation((-16777215));
    var14.setDomainAxisLocation(var33);
    java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var38 = var37.darker();
    int var39 = var38.getRed();
    var14.setOutlinePaint((java.awt.Paint)var38);
    var4.setOutlinePaint((java.awt.Paint)var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset((-254));
    org.jfree.data.category.CategoryDataset var10 = var4.getDataset((-1));
    java.awt.Color var18 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var19 = var18.getBlue();
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var18);
    var4.setDomainGridlinePaint((java.awt.Paint)var18);
    boolean var22 = var4.isSubplot();
    var4.setNoDataMessage("100");
    org.jfree.chart.plot.PlotOrientation var25 = var4.getOrientation();
    java.awt.Color var28 = java.awt.Color.getColor("hi!", 1);
    int var29 = var28.getRGB();
    java.lang.String var30 = var28.toString();
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var28);
    boolean var32 = var25.equals((java.lang.Object)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=1]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=1]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var9 = var4.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.CategoryAxis[] var11 = new org.jfree.chart.axis.CategoryAxis[] { var10};
//     var4.setDomainAxes(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var4.getDrawingSupplier();
//     var4.zoom(1.0d);
// 
//   }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var11 = var10.getTitle();
//     var11.setText("ChartEntity: tooltip = hi!");
//     var11.setText("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:hi! hi! ().hi! hi! ().\nhi! LICENCE TERMS:\nhi!");
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
//     org.jfree.chart.LegendItemCollection var22 = null;
//     var21.setFixedLegendItems(var22);
//     org.jfree.chart.axis.CategoryAxis var25 = var21.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var27 = var21.getRangeAxisLocation((-16777215));
//     java.awt.Paint var28 = var21.getNoDataMessagePaint();
//     var21.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var30 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var30, var31, var32, var33);
//     org.jfree.chart.LegendItemCollection var35 = null;
//     var34.setFixedLegendItems(var35);
//     org.jfree.chart.axis.CategoryAxis var38 = var34.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var40 = var34.getRangeAxisLocation((-16777215));
//     var21.setDomainAxisLocation(var40);
//     org.jfree.data.category.CategoryDataset var43 = var21.getDataset((-16777215));
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 10.0d, (-1.0d));
//     org.jfree.chart.util.RectangleInsets var49 = var48.getInsets();
//     var21.setInsets(var49);
//     org.jfree.chart.block.RectangleConstraint var53 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.util.Size2D var54 = null;
//     org.jfree.chart.util.Size2D var55 = var53.calculateConstrainedSize(var54);
//     double var56 = var55.getWidth();
//     org.jfree.chart.util.RectangleAnchor var59 = null;
//     java.awt.geom.Rectangle2D var60 = org.jfree.chart.util.RectangleAnchor.createRectangle(var55, 10.0d, 100.0d, var59);
//     var55.setHeight(10.0d);
//     org.jfree.chart.LegendItemSource var65 = null;
//     org.jfree.chart.util.HorizontalAlignment var66 = null;
//     org.jfree.chart.util.VerticalAlignment var67 = null;
//     org.jfree.chart.block.FlowArrangement var70 = new org.jfree.chart.block.FlowArrangement(var66, var67, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var73 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var74 = var70.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var75 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var77 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var70, var75, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var78 = null;
//     org.jfree.chart.util.VerticalAlignment var79 = null;
//     org.jfree.chart.block.ColumnArrangement var82 = new org.jfree.chart.block.ColumnArrangement(var78, var79, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var83 = new org.jfree.chart.title.LegendTitle(var65, (org.jfree.chart.block.Arrangement)var70, (org.jfree.chart.block.Arrangement)var82);
//     org.jfree.chart.util.RectangleAnchor var84 = var83.getLegendItemGraphicLocation();
//     java.lang.Object var85 = var83.clone();
//     org.jfree.chart.util.RectangleAnchor var86 = var83.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var87 = org.jfree.chart.util.RectangleAnchor.createRectangle(var55, 1.0d, 1.0d, var86);
//     java.awt.geom.Rectangle2D var88 = var49.createOutsetRectangle(var87);
//     var11.draw(var16, var88);
//     
//     // Checks the contract:  equals-hashcode on var5 and var34
//     assertTrue("Contract failed: equals-hashcode on var5 and var34", var5.equals(var34) ? var5.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var5
//     assertTrue("Contract failed: equals-hashcode on var34 and var5", var34.equals(var5) ? var34.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var8 = var4.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var9, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var12 = var11.getBounds();
    var11.setURLText("org.jfree.chart.event.ChartProgressEvent[source=ChartEntity: tooltip = ]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var5, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var22);
    java.awt.Color var27 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var28 = var27.getAlpha();
    java.awt.color.ColorSpace var29 = var27.getColorSpace();
    java.lang.String var30 = var27.toString();
    var23.setItemPaint((java.awt.Paint)var27);
    java.awt.Font var32 = var23.getItemFont();
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var32);
    java.lang.Object var34 = var33.clone();
    java.awt.geom.Rectangle2D var35 = var33.getBounds();
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var36, var37, var38, var39);
    org.jfree.chart.LegendItemCollection var41 = null;
    var40.setFixedLegendItems(var41);
    org.jfree.chart.axis.CategoryAxis var44 = var40.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var46 = var40.getRangeAxisLocation((-16777215));
    java.awt.Paint var47 = var40.getNoDataMessagePaint();
    var40.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis var50 = null;
    org.jfree.chart.axis.ValueAxis var51 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var49, var50, var51, var52);
    org.jfree.chart.LegendItemCollection var54 = null;
    var53.setFixedLegendItems(var54);
    org.jfree.chart.axis.CategoryAxis var57 = var53.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var59 = var53.getRangeAxisLocation((-16777215));
    var40.setDomainAxisLocation(var59);
    java.awt.Color var63 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var64 = var63.darker();
    int var65 = var64.getRed();
    var40.setOutlinePaint((java.awt.Paint)var64);
    org.jfree.chart.util.RectangleEdge var68 = var40.getDomainAxisEdge(10);
    double var69 = var1.getCategoryMiddle(1, 246, var35, var68);
    org.jfree.chart.text.TextFragment var71 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    java.awt.Paint var72 = var71.getPaint();
    var1.setAxisLinePaint(var72);
    var1.removeCategoryLabelToolTip((java.lang.Comparable)(-10));
    var1.removeCategoryLabelToolTip((java.lang.Comparable)246);
    var1.setUpperMargin(0.0d);
    org.jfree.chart.event.AxisChangeEvent var80 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var30.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var2 = null;
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 1.0d);
    double var5 = var4.getLowerBound();
    var1.setRange(var4);
    var1.setTickMarkOutsideLength(100.0f);
    java.awt.Shape var9 = var1.getDownArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    java.lang.Object var2 = var1.clone();
    java.lang.Object var4 = null;
    var1.set(246, var4);
    java.lang.Object var7 = var1.get(0);
    var1.set(0, (java.lang.Object)0.0f);
    java.lang.Object var12 = var1.get((-254));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    java.awt.Paint var2 = var1.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "", "hi!", "hi!");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var13, "", "hi!", "hi!");
    java.util.List var18 = null;
    var17.setContributors(var18);
    var7.addLibrary((org.jfree.chart.ui.Library)var17);
    var7.setCopyright("");
    java.awt.Image var26 = null;
    org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var26, "", "hi!", "hi!");
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var32);
    boolean var34 = var30.equals((java.lang.Object)var33);
    java.util.List var35 = var30.getContributors();
    var7.addLibrary((org.jfree.chart.ui.Library)var30);
    var7.setCopyright("ChartEntity: tooltip = ");
    java.awt.Image var42 = null;
    org.jfree.chart.ui.ProjectInfo var46 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var42, "", "hi!", "hi!");
    java.awt.Image var47 = null;
    var46.setLogo(var47);
    java.awt.Image var52 = null;
    org.jfree.chart.ui.ProjectInfo var56 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var52, "", "hi!", "hi!");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity(var58);
    boolean var60 = var56.equals((java.lang.Object)var59);
    java.util.List var61 = var56.getContributors();
    java.lang.String var62 = var56.getLicenceText();
    var46.addOptionalLibrary((org.jfree.chart.ui.Library)var56);
    var7.addLibrary((org.jfree.chart.ui.Library)var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var62 + "' != '" + "hi!"+ "'", var62.equals("hi!"));

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("ChartEntity: tooltip = hi!");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset((-254));
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var4.getDomainMarkers((-16777215), var10);
    java.awt.Color var15 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var16 = var15.getAlpha();
    java.awt.color.ColorSpace var17 = var15.getColorSpace();
    int var18 = var15.getBlue();
    var4.setOutlinePaint((java.awt.Paint)var15);
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = var4.getRenderer(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var9 = var5.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.util.RectangleAnchor var19 = var18.getLegendItemGraphicLocation();
    java.awt.Color var23 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    java.awt.Stroke var31 = null;
    var28.setOutlineStroke(var31);
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var35 = null;
    org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 1.0d);
    double var38 = var37.getLowerBound();
    var34.setRange(var37);
    org.jfree.data.Range var40 = var28.getDataRange((org.jfree.chart.axis.ValueAxis)var34);
    var34.setAutoTickUnitSelection(true, true);
    boolean var44 = var34.isVisible();
    java.awt.Stroke var45 = var34.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var46 = null;
    org.jfree.chart.axis.CategoryAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
    org.jfree.chart.axis.CategoryAxis var51 = null;
    java.util.List var52 = var50.getCategoriesForAxis(var51);
    org.jfree.chart.util.RectangleInsets var53 = var50.getInsets();
    double var55 = var53.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var56 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var23, var45, var53);
    var18.setItemLabelPadding(var53);
    double var59 = var53.extendWidth((-19.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-3.0d));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, (-19.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getDescription();
    java.lang.String var84 = var82.getToolTipText();
    org.jfree.data.general.Dataset var85 = var82.getDataset();
    org.jfree.data.general.Dataset var86 = null;
    var82.setDataset(var86);
    java.lang.String var88 = var82.getLabel();
    java.awt.Shape var89 = var82.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "hi!"+ "'", var84.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + "Range[1.0,1.0]"+ "'", var88.equals("Range[1.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    java.lang.Comparable var0 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createRegularCross(100.0f, 100.0f);
    org.jfree.chart.entity.CategoryLabelEntity var6 = new org.jfree.chart.entity.CategoryLabelEntity(var0, var3, "java.awt.Color[r=0,g=0,b=0]", "Range[1.0,1.0]");
    java.lang.String var7 = var6.toString();
    java.lang.Comparable var8 = var6.getKey();
    java.lang.String var9 = var6.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]"+ "'", var7.equals("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]"+ "'", var9.equals("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]"));

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    boolean var2 = var1.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    java.awt.Stroke var11 = null;
    var8.setOutlineStroke(var11);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    double var18 = var17.getLowerBound();
    var14.setRange(var17);
    org.jfree.data.Range var20 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    var14.setAutoTickUnitSelection(true, true);
    boolean var24 = var14.isVisible();
    java.awt.Stroke var25 = var14.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var30.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleInsets var33 = var30.getInsets();
    double var35 = var33.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var25, var33);
    java.awt.Paint var37 = var36.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    java.lang.String var5 = var4.getURLText();
    java.lang.String var6 = var4.toString();
    org.jfree.data.category.CategoryDataset var7 = null;
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var10 = null;
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot(var7, var8, var9, var10);
    org.jfree.chart.axis.CategoryAxis var12 = null;
    java.util.List var13 = var11.getCategoriesForAxis(var12);
    org.jfree.chart.util.RectangleInsets var14 = var11.getInsets();
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var15, var16, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var23 = var19.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var24 = null;
    org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var24, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var27 = var26.getBounds();
    org.jfree.chart.util.RectangleAnchor var28 = null;
    java.awt.geom.Point2D var29 = org.jfree.chart.util.RectangleAnchor.coordinates(var27, var28);
    java.awt.geom.Rectangle2D var30 = var14.createOutsetRectangle(var27);
    var4.setArea((java.awt.Shape)var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var6.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    java.awt.Stroke var11 = null;
    var8.setOutlineStroke(var11);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    double var18 = var17.getLowerBound();
    var14.setRange(var17);
    org.jfree.data.Range var20 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    var14.setAutoTickUnitSelection(true, true);
    boolean var24 = var14.isVisible();
    java.awt.Stroke var25 = var14.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var30.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleInsets var33 = var30.getInsets();
    double var35 = var33.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var25, var33);
    org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
    org.jfree.chart.util.RectangleInsets var38 = var36.getInsets();
    java.awt.Paint var39 = var36.getPaint();
    java.awt.Paint var40 = var36.getPaint();
    org.jfree.chart.LegendItemSource var41 = null;
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.FlowArrangement var46 = new org.jfree.chart.block.FlowArrangement(var42, var43, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var49 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var50 = var46.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var51 = null;
    org.jfree.chart.title.LegendItemBlockContainer var53 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var46, var51, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var54 = null;
    org.jfree.chart.util.VerticalAlignment var55 = null;
    org.jfree.chart.block.ColumnArrangement var58 = new org.jfree.chart.block.ColumnArrangement(var54, var55, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var59 = new org.jfree.chart.title.LegendTitle(var41, (org.jfree.chart.block.Arrangement)var46, (org.jfree.chart.block.Arrangement)var58);
    org.jfree.chart.ui.Library var64 = new org.jfree.chart.ui.Library("hi!", "Range[1.0,1.0]", "ChartEntity: tooltip = hi!", "Range[1.0,1.0]");
    boolean var65 = var58.equals((java.lang.Object)"Range[1.0,1.0]");
    org.jfree.chart.block.BlockContainer var66 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var58);
    boolean var67 = var36.equals((java.lang.Object)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
//     org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
//     org.jfree.chart.entity.LegendItemEntity var5 = new org.jfree.chart.entity.LegendItemEntity(var1);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
//     org.jfree.chart.block.Block var11 = null;
//     var10.add(var11, (java.lang.Object)1L);
//     org.jfree.chart.event.ChartChangeEvent var15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
//     boolean var16 = var10.equals((java.lang.Object)var15);
//     org.jfree.data.general.Dataset var17 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var17, (java.lang.Comparable)(byte)100);
//     var19.setID("ChartEntity: tooltip = hi!");
//     org.jfree.chart.util.RectangleInsets var22 = var19.getPadding();
//     boolean var23 = var5.equals((java.lang.Object)var22);
//     java.lang.Object var24 = var5.clone();
//     org.jfree.chart.LegendItemSource var25 = null;
//     org.jfree.chart.util.HorizontalAlignment var26 = null;
//     org.jfree.chart.util.VerticalAlignment var27 = null;
//     org.jfree.chart.block.FlowArrangement var30 = new org.jfree.chart.block.FlowArrangement(var26, var27, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var33 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var34 = var30.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var35 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var37 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var30, var35, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var38 = null;
//     org.jfree.chart.util.VerticalAlignment var39 = null;
//     org.jfree.chart.block.ColumnArrangement var42 = new org.jfree.chart.block.ColumnArrangement(var38, var39, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var43 = new org.jfree.chart.title.LegendTitle(var25, (org.jfree.chart.block.Arrangement)var30, (org.jfree.chart.block.Arrangement)var42);
//     java.awt.Color var47 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var48 = var47.getAlpha();
//     java.awt.color.ColorSpace var49 = var47.getColorSpace();
//     java.lang.String var50 = var47.toString();
//     var43.setItemPaint((java.awt.Paint)var47);
//     org.jfree.chart.LegendItemSource var52 = null;
//     org.jfree.chart.LegendItemSource[] var53 = new org.jfree.chart.LegendItemSource[] { var52};
//     var43.setSources(var53);
//     java.awt.Font var56 = null;
//     java.awt.Color var59 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var60 = var59.darker();
//     org.jfree.chart.text.TextMeasurer var62 = null;
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("", var56, (java.awt.Paint)var60, 0.0f, var62);
//     java.awt.Graphics2D var64 = null;
//     org.jfree.chart.util.Size2D var65 = var63.calculateDimensions(var64);
//     org.jfree.chart.util.HorizontalAlignment var66 = var63.getLineAlignment();
//     var43.setHorizontalAlignment(var66);
//     double var68 = var43.getHeight();
//     org.jfree.chart.util.HorizontalAlignment var69 = var43.getHorizontalAlignment();
//     boolean var70 = var5.equals((java.lang.Object)var43);
//     
//     // Checks the contract:  equals-hashcode on var10 and var30
//     assertTrue("Contract failed: equals-hashcode on var10 and var30", var10.equals(var30) ? var10.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var10
//     assertTrue("Contract failed: equals-hashcode on var30 and var10", var30.equals(var10) ? var30.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var2 = new org.jfree.chart.entity.ChartEntity(var1);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var6 = org.jfree.chart.util.ShapeUtilities.equal(var1, var5);
    org.jfree.chart.LegendItemSource var7 = null;
    org.jfree.chart.util.HorizontalAlignment var8 = null;
    org.jfree.chart.util.VerticalAlignment var9 = null;
    org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement(var8, var9, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var15 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var16 = var12.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var17 = null;
    org.jfree.chart.title.LegendItemBlockContainer var19 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, var17, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.ColumnArrangement var24 = new org.jfree.chart.block.ColumnArrangement(var20, var21, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle(var7, (org.jfree.chart.block.Arrangement)var12, (org.jfree.chart.block.Arrangement)var24);
    org.jfree.chart.util.RectangleAnchor var26 = var25.getLegendItemGraphicLocation();
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, var26, 0.0d, (-1.0d));
    org.jfree.chart.entity.ChartEntity var30 = new org.jfree.chart.entity.ChartEntity(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    boolean var9 = var4.isDomainZoomable();
    var4.clearRangeAxes();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 1.0d);
    double var25 = var24.getLowerBound();
    var21.setRange(var24);
    org.jfree.data.Range var27 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.LegendItemSource var29 = null;
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var37 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var38 = var34.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var39 = null;
    org.jfree.chart.title.LegendItemBlockContainer var41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var34, var39, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var29, (org.jfree.chart.block.Arrangement)var34, (org.jfree.chart.block.Arrangement)var46);
    java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var52 = var51.getAlpha();
    java.awt.color.ColorSpace var53 = var51.getColorSpace();
    java.lang.String var54 = var51.toString();
    var47.setItemPaint((java.awt.Paint)var51);
    java.awt.Font var56 = var47.getItemFont();
    java.awt.Color var60 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var61 = var60.getBlue();
    java.awt.color.ColorSpace var62 = var60.getColorSpace();
    org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("", var56, (java.awt.Paint)var60);
    var21.setTickLabelFont(var56);
    java.awt.Paint var65 = var21.getAxisLinePaint();
    org.jfree.data.Range var66 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    boolean var67 = var21.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var54.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     var10.setTextAntiAlias(false);
//     var10.setTextAntiAlias(true);
//     var10.setNotify(false);
//     java.util.List var17 = var10.getSubtitles();
//     var10.removeLegend();
//     org.jfree.chart.ChartRenderingInfo var21 = null;
//     var10.handleClick((-254), (-16777215), var21);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var5 = var4.getAlpha();
    java.awt.color.ColorSpace var6 = var4.getColorSpace();
    java.lang.String var7 = var4.toString();
    org.jfree.data.KeyedObject var8 = new org.jfree.data.KeyedObject((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=0]", (java.lang.Object)var7);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var12 = null;
    org.jfree.chart.util.Size2D var13 = var11.calculateConstrainedSize(var12);
    double var14 = var13.getWidth();
    var8.setObject((java.lang.Object)var13);
    java.lang.Object var16 = null;
    boolean var17 = var8.equals(var16);
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.FlowArrangement var22 = new org.jfree.chart.block.FlowArrangement(var18, var19, 1.0d, 100.0d);
    org.jfree.chart.block.Block var23 = null;
    var22.add(var23, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var27 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var28 = var22.equals((java.lang.Object)var27);
    var22.clear();
    boolean var30 = var8.equals((java.lang.Object)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var7.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var11 = var7.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var12 = null;
    org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var12, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var2, (org.jfree.chart.block.Arrangement)var7, (org.jfree.chart.block.Arrangement)var19);
    java.awt.Color var24 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var25 = var24.getAlpha();
    java.awt.color.ColorSpace var26 = var24.getColorSpace();
    java.lang.String var27 = var24.toString();
    var20.setItemPaint((java.awt.Paint)var24);
    java.awt.Font var29 = var20.getItemFont();
    java.awt.Color var33 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var34 = var33.getBlue();
    java.awt.color.ColorSpace var35 = var33.getColorSpace();
    org.jfree.chart.block.LabelBlock var36 = new org.jfree.chart.block.LabelBlock("", var29, (java.awt.Paint)var33);
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    org.jfree.chart.axis.CategoryAxis var45 = var41.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var47 = var41.getRangeAxisLocation((-16777215));
    java.awt.Paint var48 = var41.getNoDataMessagePaint();
    var41.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var50 = null;
    org.jfree.chart.axis.CategoryAxis var51 = null;
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var50, var51, var52, var53);
    org.jfree.chart.LegendItemCollection var55 = null;
    var54.setFixedLegendItems(var55);
    org.jfree.chart.axis.CategoryAxis var58 = var54.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var60 = var54.getRangeAxisLocation((-16777215));
    var41.setDomainAxisLocation(var60);
    java.awt.Color var64 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var65 = var64.darker();
    int var66 = var65.getRed();
    var41.setOutlinePaint((java.awt.Paint)var65);
    org.jfree.chart.text.TextBlock var68 = org.jfree.chart.text.TextUtilities.createTextBlock("", var29, (java.awt.Paint)var65);
    java.awt.Graphics2D var69 = null;
    org.jfree.chart.text.TextBlockAnchor var72 = null;
    java.awt.Shape var76 = var68.calculateBounds(var69, 10.0f, 0.0f, var72, 1.0f, 1.0f, 0.0d);
    java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.clone(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var27.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var11 = var10.getTitle();
    var11.setText("ChartEntity: tooltip = hi!");
    org.jfree.chart.LegendItemSource var14 = null;
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var15, var16, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var23 = var19.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var24 = null;
    org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var24, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var27 = null;
    org.jfree.chart.util.VerticalAlignment var28 = null;
    org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var14, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var31);
    java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var37 = var36.getAlpha();
    java.awt.color.ColorSpace var38 = var36.getColorSpace();
    java.lang.String var39 = var36.toString();
    var32.setItemPaint((java.awt.Paint)var36);
    java.awt.Font var41 = var32.getItemFont();
    var11.setFont(var41);
    java.awt.Paint var43 = null;
    var11.setBackgroundPaint(var43);
    java.awt.Paint var45 = var11.getPaint();
    var11.setToolTipText("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
    java.lang.String var48 = var11.getText();
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.LegendItemSource var51 = null;
    org.jfree.chart.util.HorizontalAlignment var52 = null;
    org.jfree.chart.util.VerticalAlignment var53 = null;
    org.jfree.chart.block.FlowArrangement var56 = new org.jfree.chart.block.FlowArrangement(var52, var53, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var59 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var60 = var56.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var61 = null;
    org.jfree.chart.title.LegendItemBlockContainer var63 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var56, var61, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var64 = null;
    org.jfree.chart.util.VerticalAlignment var65 = null;
    org.jfree.chart.block.ColumnArrangement var68 = new org.jfree.chart.block.ColumnArrangement(var64, var65, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var69 = new org.jfree.chart.title.LegendTitle(var51, (org.jfree.chart.block.Arrangement)var56, (org.jfree.chart.block.Arrangement)var68);
    java.awt.Color var73 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var74 = var73.getAlpha();
    java.awt.color.ColorSpace var75 = var73.getColorSpace();
    java.lang.String var76 = var73.toString();
    var69.setItemPaint((java.awt.Paint)var73);
    java.awt.Font var78 = var69.getItemFont();
    org.jfree.chart.block.LabelBlock var79 = new org.jfree.chart.block.LabelBlock("0,-10,10,0,0,10,-10,0,-10,0", var78);
    double var80 = var79.getContentYOffset();
    org.jfree.chart.block.RectangleConstraint var83 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var84 = null;
    org.jfree.chart.util.Size2D var85 = var83.calculateConstrainedSize(var84);
    org.jfree.chart.block.RectangleConstraint var87 = var83.toFixedWidth((-1.0d));
    org.jfree.data.Range var88 = null;
    org.jfree.data.Range var89 = null;
    org.jfree.data.Range var91 = org.jfree.data.Range.expandToInclude(var89, 1.0d);
    org.jfree.data.Range var92 = org.jfree.data.Range.combine(var88, var91);
    org.jfree.chart.block.RectangleConstraint var93 = var83.toRangeHeight(var91);
    org.jfree.chart.event.ChartChangeEvent var94 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var83);
    boolean var95 = var79.equals((java.lang.Object)var83);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var96 = var11.arrange(var49, var83);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var39.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var48.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var76 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var76.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    float var20 = var10.getTickMarkOutsideLength();
    var10.setInverted(true);
    double var23 = var10.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var7 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var8 = var4.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var9 = null;
    org.jfree.chart.title.LegendItemBlockContainer var11 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var9, (java.lang.Comparable)(-254));
    java.lang.String var12 = var11.getToolTipText();
    double var13 = var11.getContentXOffset();
    java.awt.Color var17 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var18, var19, var20, var21);
    org.jfree.chart.LegendItemCollection var23 = null;
    var22.setFixedLegendItems(var23);
    java.awt.Stroke var25 = null;
    var22.setOutlineStroke(var25);
    org.jfree.chart.axis.NumberAxis var28 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var29 = null;
    org.jfree.data.Range var31 = org.jfree.data.Range.expandToInclude(var29, 1.0d);
    double var32 = var31.getLowerBound();
    var28.setRange(var31);
    org.jfree.data.Range var34 = var22.getDataRange((org.jfree.chart.axis.ValueAxis)var28);
    var28.setAutoTickUnitSelection(true, true);
    boolean var38 = var28.isVisible();
    java.awt.Stroke var39 = var28.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.axis.CategoryAxis var45 = null;
    java.util.List var46 = var44.getCategoriesForAxis(var45);
    org.jfree.chart.util.RectangleInsets var47 = var44.getInsets();
    double var49 = var47.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var50 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var17, var39, var47);
    org.jfree.chart.util.RectangleInsets var51 = var50.getInsets();
    var11.setFrame((org.jfree.chart.block.BlockFrame)var50);
    java.lang.String var53 = var11.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    var10.setAutoRangeIncludesZero(false);
    var10.setVisible(false);
    var10.setAutoTickUnitSelection(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    var10.setVerticalTickLabels(false);
    org.jfree.data.Range var33 = var10.getRange();
    boolean var34 = var10.getAutoRangeIncludesZero();
    double var35 = var10.getLowerBound();
    org.jfree.data.category.CategoryDataset var37 = null;
    org.jfree.chart.axis.CategoryAxis var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var37, var38, var39, var40);
    org.jfree.chart.LegendItemCollection var42 = null;
    var41.setFixedLegendItems(var42);
    org.jfree.data.category.CategoryDataset var45 = var41.getDataset((-254));
    org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var41);
    var46.setTextAntiAlias(false);
    var46.setTextAntiAlias(true);
    java.util.List var51 = var46.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var52 = null;
    org.jfree.chart.event.ChartChangeEvent var53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var35, var46, var52);
    org.jfree.chart.util.RectangleInsets var54 = var46.getPadding();
    double var55 = var54.getLeft();
    org.jfree.chart.util.UnitType var56 = var54.getUnitType();
    org.jfree.chart.util.RectangleInsets var61 = new org.jfree.chart.util.RectangleInsets(var56, (-1.0d), (-15.0d), 0.0d, (-35.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "", "hi!", "hi!");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.awt.Image var13 = null;
    org.jfree.chart.ui.ProjectInfo var17 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var13, "", "hi!", "hi!");
    java.util.List var18 = null;
    var17.setContributors(var18);
    var7.addLibrary((org.jfree.chart.ui.Library)var17);
    var7.setCopyright("");
    java.awt.Image var26 = null;
    org.jfree.chart.ui.ProjectInfo var30 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var26, "", "hi!", "hi!");
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var32);
    boolean var34 = var30.equals((java.lang.Object)var33);
    java.util.List var35 = var30.getContributors();
    var7.addLibrary((org.jfree.chart.ui.Library)var30);
    java.lang.String var37 = var30.getVersion();
    java.lang.String var38 = var30.getLicenceName();
    java.awt.Image var39 = null;
    var30.setLogo(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + "hi!"+ "'", var37.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "hi!"+ "'", var38.equals("hi!"));

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    java.awt.Shape var28 = var10.getUpArrow();
    boolean var29 = var10.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    var10.setDownArrow(var18);
    org.jfree.chart.axis.NumberTickUnit var25 = var10.getTickUnit();
    java.lang.String var27 = var25.valueToString(100.0d);
    org.jfree.chart.LegendItemSource var28 = null;
    org.jfree.chart.util.HorizontalAlignment var29 = null;
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.block.FlowArrangement var33 = new org.jfree.chart.block.FlowArrangement(var29, var30, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var36 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var37 = var33.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var38 = null;
    org.jfree.chart.title.LegendItemBlockContainer var40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var33, var38, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var41 = null;
    org.jfree.chart.util.VerticalAlignment var42 = null;
    org.jfree.chart.block.ColumnArrangement var45 = new org.jfree.chart.block.ColumnArrangement(var41, var42, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var46 = new org.jfree.chart.title.LegendTitle(var28, (org.jfree.chart.block.Arrangement)var33, (org.jfree.chart.block.Arrangement)var45);
    java.awt.Color var50 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var51 = var50.getAlpha();
    java.awt.color.ColorSpace var52 = var50.getColorSpace();
    java.lang.String var53 = var50.toString();
    var46.setItemPaint((java.awt.Paint)var50);
    org.jfree.chart.LegendItemSource var55 = null;
    org.jfree.chart.LegendItemSource[] var56 = new org.jfree.chart.LegendItemSource[] { var55};
    var46.setSources(var56);
    int var58 = var25.compareTo((java.lang.Object)var56);
    int var59 = var25.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "100"+ "'", var27.equals("100"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var53.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    var5.setNoDataMessagePaint((java.awt.Paint)var11);
    java.awt.Font var13 = var5.getNoDataMessageFont();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle("", var13);
    java.lang.String var15 = var14.getText();
    java.lang.Object var16 = var14.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + ""+ "'", var15.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    var4.setRangeCrosshairVisible(false);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var9, var10, var11, var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var13.setFixedLegendItems(var14);
    org.jfree.data.category.CategoryDataset var17 = var13.getDataset((-254));
    org.jfree.data.category.CategoryDataset var19 = var13.getDataset((-1));
    java.awt.Color var27 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var28 = var27.getBlue();
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var27);
    var13.setDomainGridlinePaint((java.awt.Paint)var27);
    var4.setRangeGridlinePaint((java.awt.Paint)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 246);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var3, "", "hi!", "hi!");
    java.util.List var8 = null;
    var7.setContributors(var8);
    java.util.List var10 = null;
    var7.setContributors(var10);
    java.lang.String var12 = var7.getName();
    var7.setCopyright("0,-10,10,0,0,10,-10,0,-10,0");
    org.jfree.chart.ui.Library[] var15 = var7.getOptionalLibraries();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
//     java.awt.Paint var11 = var4.getNoDataMessagePaint();
//     org.jfree.data.category.CategoryDataset var12 = null;
//     var4.setDataset(var12);
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     org.jfree.chart.axis.ValueAxis var16 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
//     org.jfree.chart.util.SortOrder var19 = var18.getColumnRenderingOrder();
//     var4.setRowRenderingOrder(var19);
//     
//     // Checks the contract:  equals-hashcode on var4 and var18
//     assertTrue("Contract failed: equals-hashcode on var4 and var18", var4.equals(var18) ? var4.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var4
//     assertTrue("Contract failed: equals-hashcode on var18 and var4", var18.equals(var4) ? var18.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }
// 
// 
//     java.lang.Number[][] var2 = null;
//     org.jfree.data.category.CategoryDataset var3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "100", var2);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-10));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var9 = var5.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
//     org.jfree.chart.util.RectangleAnchor var19 = var18.getLegendItemGraphicLocation();
//     org.jfree.chart.util.RectangleAnchor var20 = var18.getLegendItemGraphicLocation();
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     org.jfree.data.category.CategoryDataset var30 = var26.getDataset((-254));
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var26);
//     org.jfree.chart.title.TextTitle var32 = var31.getTitle();
//     var32.setText("ChartEntity: tooltip = hi!");
//     org.jfree.chart.LegendItemSource var35 = null;
//     org.jfree.chart.util.HorizontalAlignment var36 = null;
//     org.jfree.chart.util.VerticalAlignment var37 = null;
//     org.jfree.chart.block.FlowArrangement var40 = new org.jfree.chart.block.FlowArrangement(var36, var37, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var43 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var44 = var40.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var45 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var47 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var40, var45, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var48 = null;
//     org.jfree.chart.util.VerticalAlignment var49 = null;
//     org.jfree.chart.block.ColumnArrangement var52 = new org.jfree.chart.block.ColumnArrangement(var48, var49, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var53 = new org.jfree.chart.title.LegendTitle(var35, (org.jfree.chart.block.Arrangement)var40, (org.jfree.chart.block.Arrangement)var52);
//     java.awt.Color var57 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var58 = var57.getAlpha();
//     java.awt.color.ColorSpace var59 = var57.getColorSpace();
//     java.lang.String var60 = var57.toString();
//     var53.setItemPaint((java.awt.Paint)var57);
//     java.awt.Font var62 = var53.getItemFont();
//     var32.setFont(var62);
//     java.awt.Paint var64 = null;
//     var32.setBackgroundPaint(var64);
//     java.awt.Paint var66 = var32.getPaint();
//     var32.setToolTipText("CategoryLabelEntity: category=null, tooltip=java.awt.Color[r=0,g=0,b=0], url=Range[1.0,1.0]");
//     java.lang.String var69 = var32.getText();
//     org.jfree.chart.util.RectangleEdge var70 = var32.getPosition();
//     var18.setLegendItemGraphicEdge(var70);
//     
//     // Checks the contract:  equals-hashcode on var5 and var40
//     assertTrue("Contract failed: equals-hashcode on var5 and var40", var5.equals(var40) ? var5.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var5
//     assertTrue("Contract failed: equals-hashcode on var40 and var5", var40.equals(var5) ? var40.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var43
//     assertTrue("Contract failed: equals-hashcode on var8 and var43", var8.equals(var43) ? var8.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var8
//     assertTrue("Contract failed: equals-hashcode on var43 and var8", var43.equals(var8) ? var43.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var47
//     assertTrue("Contract failed: equals-hashcode on var12 and var47", var12.equals(var47) ? var12.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var12
//     assertTrue("Contract failed: equals-hashcode on var47 and var12", var47.equals(var12) ? var47.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var52
//     assertTrue("Contract failed: equals-hashcode on var17 and var52", var17.equals(var52) ? var17.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var17
//     assertTrue("Contract failed: equals-hashcode on var52 and var17", var52.equals(var17) ? var52.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
    var4.setNoDataMessagePaint((java.awt.Paint)var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.chart.axis.CategoryAxis var20 = var16.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var22 = var16.getRangeAxisLocation((-16777215));
    var4.setRangeAxisLocation(var22);
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    java.awt.Stroke var31 = null;
    var28.setOutlineStroke(var31);
    java.awt.Paint[] var33 = null;
    java.awt.Color var37 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var38 = var37.getAlpha();
    java.awt.color.ColorSpace var39 = var37.getColorSpace();
    java.lang.String var40 = var37.toString();
    java.awt.Paint[] var41 = new java.awt.Paint[] { var37};
    java.awt.Font var43 = null;
    java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var47 = var46.darker();
    org.jfree.chart.text.TextMeasurer var49 = null;
    org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, 0.0f, var49);
    java.awt.Paint[] var51 = new java.awt.Paint[] { var47};
    java.awt.Stroke var52 = null;
    java.awt.Stroke[] var53 = new java.awt.Stroke[] { var52};
    java.awt.Stroke var54 = null;
    java.awt.Stroke[] var55 = new java.awt.Stroke[] { var54};
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var58 = new org.jfree.chart.entity.ChartEntity(var57);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var57, var61);
    java.awt.Shape[] var63 = new java.awt.Shape[] { var57};
    org.jfree.chart.plot.DefaultDrawingSupplier var64 = new org.jfree.chart.plot.DefaultDrawingSupplier(var33, var41, var51, var53, var55, var63);
    var28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var64);
    java.awt.Paint var66 = var64.getNextFillPaint();
    var4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var40.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var18);
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var23 = org.jfree.chart.util.ShapeUtilities.equal(var18, var22);
    var10.setDownArrow(var18);
    boolean var25 = var10.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    var4.setToolTipText("");
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartProgressEvent var10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var7, 1, 10);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    org.jfree.chart.axis.CategoryAxis var19 = var15.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var21 = var15.getRangeAxisLocation((-16777215));
    java.awt.Paint var22 = var15.getNoDataMessagePaint();
    var15.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var24 = null;
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var24, var25, var26, var27);
    org.jfree.chart.LegendItemCollection var29 = null;
    var28.setFixedLegendItems(var29);
    org.jfree.chart.axis.CategoryAxis var32 = var28.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var34 = var28.getRangeAxisLocation((-16777215));
    var15.setDomainAxisLocation(var34);
    org.jfree.data.category.CategoryDataset var37 = var15.getDataset((-16777215));
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleInsets var43 = var42.getInsets();
    var15.setInsets(var43);
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var48 = null;
    org.jfree.chart.util.Size2D var49 = var47.calculateConstrainedSize(var48);
    double var50 = var49.getWidth();
    org.jfree.chart.util.RectangleAnchor var53 = null;
    java.awt.geom.Rectangle2D var54 = org.jfree.chart.util.RectangleAnchor.createRectangle(var49, 10.0d, 100.0d, var53);
    var49.setHeight(10.0d);
    org.jfree.chart.LegendItemSource var59 = null;
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.block.FlowArrangement var64 = new org.jfree.chart.block.FlowArrangement(var60, var61, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var67 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var68 = var64.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var69 = null;
    org.jfree.chart.title.LegendItemBlockContainer var71 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var64, var69, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var72 = null;
    org.jfree.chart.util.VerticalAlignment var73 = null;
    org.jfree.chart.block.ColumnArrangement var76 = new org.jfree.chart.block.ColumnArrangement(var72, var73, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle(var59, (org.jfree.chart.block.Arrangement)var64, (org.jfree.chart.block.Arrangement)var76);
    org.jfree.chart.util.RectangleAnchor var78 = var77.getLegendItemGraphicLocation();
    java.lang.Object var79 = var77.clone();
    org.jfree.chart.util.RectangleAnchor var80 = var77.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var49, 1.0d, 1.0d, var80);
    java.awt.geom.Rectangle2D var82 = var43.createOutsetRectangle(var81);
    var4.setArea((java.awt.Shape)var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.setRangeCrosshairValue(0.0d, true);
    var5.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var10 = null;
    var5.setDataset(var10);
    org.jfree.chart.renderer.category.CategoryItemRenderer var12 = null;
    var5.setRenderer(var12, true);
    java.awt.Color var18 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var19 = var18.getAlpha();
    int var20 = var18.getTransparency();
    var5.setNoDataMessagePaint((java.awt.Paint)var18);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    org.jfree.chart.LegendItemCollection var28 = null;
    var27.setFixedLegendItems(var28);
    org.jfree.data.category.CategoryDataset var31 = var27.getDataset((-254));
    org.jfree.chart.JFreeChart var32 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var27);
    var32.setTextAntiAlias(false);
    var32.setTextAntiAlias(true);
    java.util.List var37 = var32.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var38 = null;
    var32.addProgressListener(var38);
    org.jfree.chart.util.RectangleInsets var40 = var32.getPadding();
    java.awt.Stroke var41 = var32.getBorderStroke();
    org.jfree.data.category.CategoryDataset var42 = null;
    org.jfree.chart.axis.CategoryAxis var43 = null;
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot(var42, var43, var44, var45);
    var46.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var52 = java.awt.Color.getColor("hi!", 1);
    var46.setNoDataMessagePaint((java.awt.Paint)var52);
    java.awt.Color var54 = var52.brighter();
    org.jfree.data.category.CategoryDataset var55 = null;
    org.jfree.chart.axis.CategoryAxis var56 = null;
    org.jfree.chart.axis.ValueAxis var57 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var58 = null;
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot(var55, var56, var57, var58);
    org.jfree.chart.LegendItemCollection var60 = null;
    var59.setFixedLegendItems(var60);
    org.jfree.chart.axis.CategoryAxis var63 = var59.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var65 = var59.getRangeAxisLocation((-16777215));
    java.awt.Paint var66 = var59.getNoDataMessagePaint();
    var59.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var68 = null;
    org.jfree.chart.axis.CategoryAxis var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var71 = null;
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var68, var69, var70, var71);
    org.jfree.chart.LegendItemCollection var73 = null;
    var72.setFixedLegendItems(var73);
    org.jfree.chart.axis.CategoryAxis var76 = var72.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var78 = var72.getRangeAxisLocation((-16777215));
    var59.setDomainAxisLocation(var78);
    org.jfree.chart.axis.AxisLocation var80 = var59.getDomainAxisLocation();
    java.awt.Stroke var81 = var59.getRangeCrosshairStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var83 = new org.jfree.chart.plot.ValueMarker((-3.0d), (java.awt.Paint)var18, var41, (java.awt.Paint)var52, var81, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    var10.setAutoRangeIncludesZero(false);
    var10.setVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setRangeWithMargins(1.0d, (-15.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    org.jfree.chart.block.Block var5 = null;
    var4.add(var5, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var10 = var4.equals((java.lang.Object)var9);
    org.jfree.data.general.Dataset var11 = null;
    org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var11, (java.lang.Comparable)(byte)100);
    var13.setID("ChartEntity: tooltip = hi!");
    org.jfree.chart.util.RectangleInsets var16 = var13.getPadding();
    java.lang.Object var17 = var13.clone();
    org.jfree.chart.block.Arrangement var18 = var13.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(0.0d, 1.0d, 1.0d, 1.0d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    java.awt.Graphics2D var25 = null;
    java.awt.Color var37 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var38 = var37.getAlpha();
    java.awt.color.ColorSpace var39 = var37.getColorSpace();
    int var40 = var37.getBlue();
    org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((-15.0d), 1.0d, (-15.0d), 0.0d, (java.awt.Paint)var37);
    org.jfree.chart.block.BlockBorder var42 = new org.jfree.chart.block.BlockBorder(10.0d, (-1.0d), 100.0d, 10.0d, (java.awt.Paint)var37);
    java.awt.image.ColorModel var43 = null;
    java.awt.Rectangle var44 = null;
    org.jfree.chart.block.RectangleConstraint var47 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var48 = null;
    org.jfree.chart.util.Size2D var49 = var47.calculateConstrainedSize(var48);
    double var50 = var49.getWidth();
    org.jfree.chart.util.RectangleAnchor var53 = null;
    java.awt.geom.Rectangle2D var54 = org.jfree.chart.util.RectangleAnchor.createRectangle(var49, 10.0d, 100.0d, var53);
    var49.setHeight(10.0d);
    org.jfree.chart.LegendItemSource var59 = null;
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.block.FlowArrangement var64 = new org.jfree.chart.block.FlowArrangement(var60, var61, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var67 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var68 = var64.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var69 = null;
    org.jfree.chart.title.LegendItemBlockContainer var71 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var64, var69, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var72 = null;
    org.jfree.chart.util.VerticalAlignment var73 = null;
    org.jfree.chart.block.ColumnArrangement var76 = new org.jfree.chart.block.ColumnArrangement(var72, var73, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var77 = new org.jfree.chart.title.LegendTitle(var59, (org.jfree.chart.block.Arrangement)var64, (org.jfree.chart.block.Arrangement)var76);
    org.jfree.chart.util.RectangleAnchor var78 = var77.getLegendItemGraphicLocation();
    java.lang.Object var79 = var77.clone();
    org.jfree.chart.util.RectangleAnchor var80 = var77.getLegendItemGraphicLocation();
    java.awt.geom.Rectangle2D var81 = org.jfree.chart.util.RectangleAnchor.createRectangle(var49, 1.0d, 1.0d, var80);
    java.awt.geom.AffineTransform var82 = null;
    java.awt.RenderingHints var83 = null;
    java.awt.PaintContext var84 = var37.createContext(var43, var44, var81, var82, var83);
    org.jfree.chart.plot.PlotRenderingInfo var86 = null;
    boolean var87 = var4.render(var25, var81, 10, var86);
    boolean var88 = var4.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(10.0d);
    double var2 = var1.getCursor();
    var1.cursorUp((-15.0d));
    double var5 = var1.getCursor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 25.0d);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement(var0, var1, 1.0d, 0.0d);
    boolean var6 = var4.equals((java.lang.Object)0.0f);
    org.jfree.chart.util.HorizontalAlignment var7 = null;
    org.jfree.chart.util.VerticalAlignment var8 = null;
    org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement(var7, var8, 1.0d, 100.0d);
    org.jfree.chart.block.Block var12 = null;
    var11.add(var12, (java.lang.Object)1L);
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    boolean var17 = var11.equals((java.lang.Object)var16);
    org.jfree.data.general.Dataset var18 = null;
    org.jfree.chart.title.LegendItemBlockContainer var20 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, var18, (java.lang.Comparable)(byte)100);
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var25 = null;
    org.jfree.chart.util.Size2D var26 = var24.calculateConstrainedSize(var25);
    org.jfree.chart.block.RectangleConstraint var28 = var24.toFixedWidth((-1.0d));
    double var29 = var28.getWidth();
    org.jfree.chart.block.LengthConstraintType var30 = var28.getWidthConstraintType();
    org.jfree.chart.util.Size2D var31 = var4.arrange((org.jfree.chart.block.BlockContainer)var20, var21, var28);
    org.jfree.chart.axis.CategoryLabelPositions var33 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-6.0d));
    boolean var34 = var20.equals((java.lang.Object)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    org.jfree.chart.util.HorizontalAlignment var31 = null;
    org.jfree.chart.util.VerticalAlignment var32 = null;
    org.jfree.chart.block.FlowArrangement var35 = new org.jfree.chart.block.FlowArrangement(var31, var32, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var38 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var39 = var35.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var40 = null;
    org.jfree.chart.title.LegendItemBlockContainer var42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, var40, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var43 = var42.getBounds();
    boolean var44 = var10.equals((java.lang.Object)var42);
    var10.setAutoRange(false);
    boolean var47 = var10.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    java.awt.Font var1 = null;
    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var5 = var4.darker();
    org.jfree.chart.text.TextMeasurer var7 = null;
    org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("", var1, (java.awt.Paint)var5, 0.0f, var7);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var13 = new org.jfree.chart.entity.ChartEntity(var10, "hi!", "hi!");
    java.lang.String var14 = var13.getURLText();
    java.lang.String var15 = var13.toString();
    var13.setToolTipText("hi!");
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var19, "hi!", "hi!");
    var22.setToolTipText("");
    org.jfree.chart.JFreeChart var25 = null;
    org.jfree.chart.event.ChartProgressEvent var28 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var22, var25, 1, 10);
    boolean var29 = var13.equals((java.lang.Object)10);
    boolean var30 = var8.equals((java.lang.Object)var29);
    org.jfree.chart.JFreeChart var31 = null;
    org.jfree.chart.event.ChartProgressEvent var34 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var8, var31, 0, (-254));
    org.jfree.chart.util.HorizontalAlignment var35 = var8.getLineAlignment();
    org.jfree.chart.text.TextLine var36 = var8.getLastLine();
    org.jfree.chart.text.TextLine var37 = null;
    var8.addLine(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "hi!"+ "'", var14.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var15.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    org.jfree.chart.plot.CategoryPlot var15 = var10.getCategoryPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var18 = var10.createBufferedImage(100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    org.jfree.chart.title.TextTitle var11 = var10.getTitle();
    var11.setText("ChartEntity: tooltip = hi!");
    var11.setText("hi!");
    boolean var16 = var11.getExpandToFitSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getDescription();
    java.lang.String var84 = var82.getToolTipText();
    java.awt.Stroke var85 = var82.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "hi!"+ "'", var84.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var9 = var5.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.util.RectangleEdge var19 = var18.getPosition();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.util.SortOrder var25 = var24.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var26 = var24.getColumnRenderingOrder();
    var24.setForegroundAlpha(0.0f);
    boolean var29 = var19.equals((java.lang.Object)var24);
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    var24.setRenderer(246, var31);
    org.jfree.chart.annotations.CategoryAnnotation var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var34 = var24.removeAnnotation(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    java.lang.Object var20 = var10.clone();
    float var21 = var10.getTickMarkInsideLength();
    var10.setAxisLineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0f);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.data.category.CategoryDataset var8 = var4.getDataset((-254));
    org.jfree.data.category.CategoryDataset var10 = var4.getDataset((-1));
    java.awt.Color var18 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var19 = var18.getBlue();
    org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder(0.0d, 1.0d, 0.0d, (-1.0d), (java.awt.Paint)var18);
    var4.setDomainGridlinePaint((java.awt.Paint)var18);
    var4.setNoDataMessage("org.jfree.chart.event.ChartProgressEvent[source=ChartEntity: tooltip = ]");
    var4.setNoDataMessage("Size2D[width=1.0, height=-1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 246);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("0,-10,10,0,0,10,-10,0,-10,0", var1);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.jfree.chart.LegendItemSource var0 = null;
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    org.jfree.chart.util.VerticalAlignment var2 = null;
    org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var9 = var5.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var13 = null;
    org.jfree.chart.util.VerticalAlignment var14 = null;
    org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
    org.jfree.chart.util.RectangleEdge var19 = var18.getPosition();
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.util.SortOrder var25 = var24.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var26 = var24.getColumnRenderingOrder();
    var24.setForegroundAlpha(0.0f);
    boolean var29 = var19.equals((java.lang.Object)var24);
    org.jfree.chart.util.RectangleEdge var31 = var24.getDomainAxisEdge((-10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     java.awt.Color var4 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var5 = var4.getAlpha();
//     java.awt.color.ColorSpace var6 = var4.getColorSpace();
//     java.lang.String var7 = var4.toString();
//     java.awt.Paint[] var8 = new java.awt.Paint[] { var4};
//     java.awt.Font var10 = null;
//     java.awt.Color var13 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var14 = var13.darker();
//     org.jfree.chart.text.TextMeasurer var16 = null;
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("", var10, (java.awt.Paint)var14, 0.0f, var16);
//     java.awt.Paint[] var18 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var19 = null;
//     java.awt.Stroke[] var20 = new java.awt.Stroke[] { var19};
//     java.awt.Stroke var21 = null;
//     java.awt.Stroke[] var22 = new java.awt.Stroke[] { var21};
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
//     org.jfree.chart.entity.ChartEntity var25 = new org.jfree.chart.entity.ChartEntity(var24);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.equal(var24, var28);
//     java.awt.Shape[] var30 = new java.awt.Shape[] { var24};
//     org.jfree.chart.plot.DefaultDrawingSupplier var31 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var8, var18, var20, var22, var30);
//     org.jfree.data.Range var32 = null;
//     org.jfree.data.Range var34 = org.jfree.data.Range.expandToInclude(var32, 1.0d);
//     double var35 = var34.getLowerBound();
//     double var36 = var34.getLowerBound();
//     boolean var37 = var31.equals((java.lang.Object)var36);
//     java.awt.Paint var38 = var31.getNextPaint();
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var11 = var10.getTitle();
//     org.jfree.chart.LegendItemSource var12 = null;
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var20 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var21 = var17.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var22 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var24 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var17, var22, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var25 = null;
//     org.jfree.chart.util.VerticalAlignment var26 = null;
//     org.jfree.chart.block.ColumnArrangement var29 = new org.jfree.chart.block.ColumnArrangement(var25, var26, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle(var12, (org.jfree.chart.block.Arrangement)var17, (org.jfree.chart.block.Arrangement)var29);
//     java.awt.Color var34 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var35 = var34.getAlpha();
//     java.awt.color.ColorSpace var36 = var34.getColorSpace();
//     java.lang.String var37 = var34.toString();
//     var30.setItemPaint((java.awt.Paint)var34);
//     org.jfree.chart.LegendItemSource var39 = null;
//     org.jfree.chart.LegendItemSource[] var40 = new org.jfree.chart.LegendItemSource[] { var39};
//     var30.setSources(var40);
//     java.awt.Font var43 = null;
//     java.awt.Color var46 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var47 = var46.darker();
//     org.jfree.chart.text.TextMeasurer var49 = null;
//     org.jfree.chart.text.TextBlock var50 = org.jfree.chart.text.TextUtilities.createTextBlock("", var43, (java.awt.Paint)var47, 0.0f, var49);
//     java.awt.Graphics2D var51 = null;
//     org.jfree.chart.util.Size2D var52 = var50.calculateDimensions(var51);
//     org.jfree.chart.util.HorizontalAlignment var53 = var50.getLineAlignment();
//     var30.setHorizontalAlignment(var53);
//     var11.setTextAlignment(var53);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis var57 = null;
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var56, var57, var58, var59);
//     org.jfree.chart.LegendItemCollection var61 = null;
//     var60.setFixedLegendItems(var61);
//     org.jfree.data.category.CategoryDataset var64 = var60.getDataset((-254));
//     var60.setAnchorValue(0.0d, false);
//     org.jfree.chart.axis.CategoryAxis var69 = null;
//     var60.setDomainAxis(246, var69, true);
//     org.jfree.chart.axis.AxisSpace var72 = var60.getFixedDomainAxisSpace();
//     java.awt.Paint var73 = var60.getRangeCrosshairPaint();
//     var11.setPaint(var73);
//     
//     // Checks the contract:  equals-hashcode on var5 and var60
//     assertTrue("Contract failed: equals-hashcode on var5 and var60", var5.equals(var60) ? var5.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var5
//     assertTrue("Contract failed: equals-hashcode on var60 and var5", var60.equals(var5) ? var60.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    boolean var9 = var4.isDomainZoomable();
    var4.clearRangeAxes();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 1.0d);
    double var25 = var24.getLowerBound();
    var21.setRange(var24);
    org.jfree.data.Range var27 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.LegendItemSource var29 = null;
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var37 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var38 = var34.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var39 = null;
    org.jfree.chart.title.LegendItemBlockContainer var41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var34, var39, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var29, (org.jfree.chart.block.Arrangement)var34, (org.jfree.chart.block.Arrangement)var46);
    java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var52 = var51.getAlpha();
    java.awt.color.ColorSpace var53 = var51.getColorSpace();
    java.lang.String var54 = var51.toString();
    var47.setItemPaint((java.awt.Paint)var51);
    java.awt.Font var56 = var47.getItemFont();
    java.awt.Color var60 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var61 = var60.getBlue();
    java.awt.color.ColorSpace var62 = var60.getColorSpace();
    org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("", var56, (java.awt.Paint)var60);
    var21.setTickLabelFont(var56);
    java.awt.Paint var65 = var21.getAxisLinePaint();
    org.jfree.data.Range var66 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.axis.AxisLocation var68 = var4.getDomainAxisLocation(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var54.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var8 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var9 = var5.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var5, var10, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.ColumnArrangement var17 = new org.jfree.chart.block.ColumnArrangement(var13, var14, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var17);
//     java.awt.Color var22 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var23 = var22.getAlpha();
//     java.awt.color.ColorSpace var24 = var22.getColorSpace();
//     java.lang.String var25 = var22.toString();
//     var18.setItemPaint((java.awt.Paint)var22);
//     org.jfree.chart.LegendItemSource var27 = null;
//     org.jfree.chart.LegendItemSource[] var28 = new org.jfree.chart.LegendItemSource[] { var27};
//     var18.setSources(var28);
//     java.awt.Color var33 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
//     var18.setBackgroundPaint((java.awt.Paint)var33);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.data.Range var39 = null;
//     org.jfree.data.Range var40 = null;
//     org.jfree.data.Range var42 = org.jfree.data.Range.expandToInclude(var40, 1.0d);
//     org.jfree.data.Range var43 = org.jfree.data.Range.combine(var39, var42);
//     org.jfree.chart.block.RectangleConstraint var44 = var38.toRangeWidth(var42);
//     org.jfree.chart.block.LengthConstraintType var45 = var44.getHeightConstraintType();
//     org.jfree.data.Range var46 = var44.getWidthRange();
//     org.jfree.chart.block.RectangleConstraint var48 = new org.jfree.chart.block.RectangleConstraint(var46, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var50 = var48.toFixedHeight(0.0d);
//     org.jfree.chart.util.Size2D var51 = var18.arrange(var35, var50);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 1.0d);
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var6);
    org.jfree.chart.block.LengthConstraintType var9 = var8.getHeightConstraintType();
    org.jfree.data.Range var10 = var8.getWidthRange();
    org.jfree.chart.block.RectangleConstraint var12 = new org.jfree.chart.block.RectangleConstraint(var10, 0.0d);
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    java.awt.Stroke var20 = null;
    var17.setOutlineStroke(var20);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var24 = null;
    org.jfree.data.Range var26 = org.jfree.data.Range.expandToInclude(var24, 1.0d);
    double var27 = var26.getLowerBound();
    var23.setRange(var26);
    org.jfree.data.Range var29 = var17.getDataRange((org.jfree.chart.axis.ValueAxis)var23);
    var23.setAutoTickUnitSelection(true, true);
    boolean var33 = var23.isVisible();
    java.awt.Stroke var34 = var23.getAxisLineStroke();
    java.awt.Color var37 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var38 = var37.darker();
    int var39 = var38.getRed();
    var23.setTickMarkPaint((java.awt.Paint)var38);
    var23.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var43 = var23.getStandardTickUnits();
    var23.setVerticalTickLabels(false);
    org.jfree.data.Range var46 = var23.getRange();
    org.jfree.data.Range var47 = null;
    org.jfree.data.Range var49 = org.jfree.data.Range.expandToInclude(var47, 1.0d);
    double var50 = var49.getLowerBound();
    var23.setDefaultAutoRange(var49);
    org.jfree.chart.block.RectangleConstraint var52 = var12.toRangeWidth(var49);
    org.jfree.data.Range var55 = org.jfree.data.Range.expand(var49, 100.0d, 0.0d);
    org.jfree.data.Range var56 = null;
    org.jfree.data.Range var58 = org.jfree.data.Range.expandToInclude(var56, 1.0d);
    double var59 = var58.getLowerBound();
    double var60 = var58.getLowerBound();
    org.jfree.data.Range var61 = org.jfree.data.Range.combine(var55, var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    int var3 = var2.getRGB();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    org.jfree.chart.axis.CategoryAxis var12 = var8.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var14 = var8.getRangeAxisLocation((-16777215));
    java.awt.Paint var15 = var8.getNoDataMessagePaint();
    var8.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    org.jfree.chart.axis.CategoryAxis var25 = var21.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var27 = var21.getRangeAxisLocation((-16777215));
    var8.setDomainAxisLocation(var27);
    org.jfree.chart.axis.AxisLocation var29 = var8.getDomainAxisLocation();
    boolean var30 = var2.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777215));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    double var2 = var1.getAutoRangeMinimumSize();
    var1.setAutoRangeIncludesZero(false);
    var1.setAutoRangeIncludesZero(false);
    var1.setAutoRangeIncludesZero(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0E-8d);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    var5.setNoDataMessagePaint((java.awt.Paint)var11);
    java.awt.Font var13 = var5.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    org.jfree.chart.LegendItemCollection var19 = null;
    var18.setFixedLegendItems(var19);
    org.jfree.data.category.CategoryDataset var22 = var18.getDataset((-254));
    var18.setAnchorValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis var27 = null;
    var18.setDomainAxis(246, var27, true);
    java.awt.Color var33 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var34 = var33.getBlue();
    java.awt.color.ColorSpace var35 = var33.getColorSpace();
    var18.setBackgroundPaint((java.awt.Paint)var33);
    java.awt.image.ColorModel var37 = null;
    java.awt.Rectangle var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    java.awt.geom.AffineTransform var40 = null;
    java.awt.RenderingHints var41 = null;
    java.awt.PaintContext var42 = var33.createContext(var37, var38, var39, var40, var41);
    java.awt.Color var46 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var47 = var46.getAlpha();
    java.awt.color.ColorSpace var48 = var46.getColorSpace();
    float[] var49 = null;
    float[] var50 = var33.getComponents(var48, var49);
    org.jfree.chart.block.LabelBlock var51 = new org.jfree.chart.block.LabelBlock("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", var13, (java.awt.Paint)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var6 = var4.getColumnRenderingOrder();
    org.jfree.chart.JFreeChart var7 = null;
    org.jfree.chart.event.ChartProgressEvent var10 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)var4, var7, (-254), (-16777215));
    var4.configureRangeAxes();
    float var12 = var4.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var13, var14, var15, var16);
    org.jfree.chart.LegendItemCollection var18 = null;
    var17.setFixedLegendItems(var18);
    org.jfree.chart.axis.CategoryAxis var21 = var17.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var23 = var17.getRangeAxisLocation((-16777215));
    var4.setDomainAxisLocation(var23);
    org.jfree.data.category.CategoryDataset var26 = var4.getDataset((-16777215));
    org.jfree.chart.block.BlockBorder var31 = new org.jfree.chart.block.BlockBorder(10.0d, 1.0d, 10.0d, (-1.0d));
    org.jfree.chart.util.RectangleInsets var32 = var31.getInsets();
    var4.setInsets(var32);
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = var4.getRendererForDataset(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    java.util.List var15 = var10.getSubtitles();
    var10.setTextAntiAlias(true);
    var10.setAntiAlias(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("org.jfree.chart.event.ChartProgressEvent[source=ChartEntity: tooltip = ]", var1, var2);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    var10.setRangeAboutValue((-6.0d), 0.0d);
    var10.setRangeWithMargins((-6.0d), 25.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((-6.0d));
    org.jfree.chart.LegendItemSource var2 = null;
    org.jfree.chart.util.HorizontalAlignment var3 = null;
    org.jfree.chart.util.VerticalAlignment var4 = null;
    org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var10 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var11 = var7.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var12 = null;
    org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var12, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var15 = null;
    org.jfree.chart.util.VerticalAlignment var16 = null;
    org.jfree.chart.block.ColumnArrangement var19 = new org.jfree.chart.block.ColumnArrangement(var15, var16, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var20 = new org.jfree.chart.title.LegendTitle(var2, (org.jfree.chart.block.Arrangement)var7, (org.jfree.chart.block.Arrangement)var19);
    org.jfree.chart.util.RectangleEdge var21 = var20.getPosition();
    org.jfree.chart.axis.CategoryLabelPosition var22 = var1.getLabelPosition(var21);
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis var24 = null;
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot(var23, var24, var25, var26);
    org.jfree.chart.LegendItemCollection var28 = null;
    var27.setFixedLegendItems(var28);
    org.jfree.data.category.CategoryDataset var31 = var27.getDataset((-254));
    var27.setAnchorValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis var36 = null;
    var27.setDomainAxis(246, var36, true);
    java.awt.Color var42 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var43 = var42.getBlue();
    java.awt.color.ColorSpace var44 = var42.getColorSpace();
    var27.setBackgroundPaint((java.awt.Paint)var42);
    org.jfree.chart.util.RectangleEdge var46 = var27.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var47 = var1.getLabelPosition(var46);
    double var48 = var47.getAngle();
    double var49 = var47.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == (-6.0d));

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }


    java.awt.Color var4 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var5 = var4.getBlue();
    int var6 = var4.getBlue();
    int var7 = var4.getGreen();
    java.awt.Stroke var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var9 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint)var4, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 255);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    boolean var9 = var4.isDomainZoomable();
    var4.clearRangeAxes();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 1.0d);
    double var25 = var24.getLowerBound();
    var21.setRange(var24);
    org.jfree.data.Range var27 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    org.jfree.chart.LegendItemSource var29 = null;
    org.jfree.chart.util.HorizontalAlignment var30 = null;
    org.jfree.chart.util.VerticalAlignment var31 = null;
    org.jfree.chart.block.FlowArrangement var34 = new org.jfree.chart.block.FlowArrangement(var30, var31, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var37 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var38 = var34.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var39 = null;
    org.jfree.chart.title.LegendItemBlockContainer var41 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var34, var39, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var42 = null;
    org.jfree.chart.util.VerticalAlignment var43 = null;
    org.jfree.chart.block.ColumnArrangement var46 = new org.jfree.chart.block.ColumnArrangement(var42, var43, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var47 = new org.jfree.chart.title.LegendTitle(var29, (org.jfree.chart.block.Arrangement)var34, (org.jfree.chart.block.Arrangement)var46);
    java.awt.Color var51 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var52 = var51.getAlpha();
    java.awt.color.ColorSpace var53 = var51.getColorSpace();
    java.lang.String var54 = var51.toString();
    var47.setItemPaint((java.awt.Paint)var51);
    java.awt.Font var56 = var47.getItemFont();
    java.awt.Color var60 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var61 = var60.getBlue();
    java.awt.color.ColorSpace var62 = var60.getColorSpace();
    org.jfree.chart.block.LabelBlock var63 = new org.jfree.chart.block.LabelBlock("", var56, (java.awt.Paint)var60);
    var21.setTickLabelFont(var56);
    java.awt.Paint var65 = var21.getAxisLinePaint();
    org.jfree.data.Range var66 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    java.lang.String var67 = var21.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var54.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    boolean var83 = var82.isShapeVisible();
    java.lang.String var84 = var82.getLabel();
    var82.setSeriesIndex(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "Range[1.0,1.0]"+ "'", var84.equals("Range[1.0,1.0]"));

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.awt.Color var85 = java.awt.Color.getColor("0,-10,10,0,0,10,-10,0,-10,0", 10);
    boolean var86 = var82.equals((java.lang.Object)var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    java.lang.String var83 = var82.getDescription();
    java.lang.String var84 = var82.getToolTipText();
    org.jfree.data.general.Dataset var85 = var82.getDataset();
    org.jfree.data.general.Dataset var86 = null;
    var82.setDataset(var86);
    boolean var88 = var82.isShapeVisible();
    var82.setDatasetIndex(10);
    java.awt.Stroke var91 = var82.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var83 + "' != '" + "hi!"+ "'", var83.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var84 + "' != '" + "hi!"+ "'", var84.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 1.0d);
    org.jfree.data.Range var7 = org.jfree.data.Range.combine(var3, var6);
    org.jfree.chart.block.RectangleConstraint var8 = var2.toRangeWidth(var6);
    org.jfree.chart.block.LengthConstraintType var9 = var8.getHeightConstraintType();
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var13 = null;
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot(var10, var11, var12, var13);
    org.jfree.chart.util.SortOrder var15 = var14.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var16 = var14.getColumnRenderingOrder();
    var14.setForegroundAlpha(0.0f);
    boolean var19 = var9.equals((java.lang.Object)var14);
    org.jfree.data.category.CategoryDataset var20 = null;
    org.jfree.chart.axis.CategoryAxis var21 = null;
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var20, var21, var22, var23);
    org.jfree.chart.LegendItemCollection var25 = null;
    var24.setFixedLegendItems(var25);
    java.awt.Stroke var27 = null;
    var24.setOutlineStroke(var27);
    org.jfree.chart.axis.NumberAxis var30 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var31 = null;
    org.jfree.data.Range var33 = org.jfree.data.Range.expandToInclude(var31, 1.0d);
    double var34 = var33.getLowerBound();
    var30.setRange(var33);
    org.jfree.data.Range var36 = var24.getDataRange((org.jfree.chart.axis.ValueAxis)var30);
    var30.setAutoTickUnitSelection(true, true);
    boolean var40 = var30.isVisible();
    java.awt.Stroke var41 = var30.getAxisLineStroke();
    java.awt.Color var44 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var45 = var44.darker();
    int var46 = var45.getRed();
    var30.setTickMarkPaint((java.awt.Paint)var45);
    var30.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var50 = var30.getStandardTickUnits();
    var30.setVerticalTickLabels(false);
    org.jfree.data.Range var53 = var30.getRange();
    boolean var54 = var30.getAutoRangeIncludesZero();
    double var55 = var30.getLowerBound();
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = null;
    org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot(var57, var58, var59, var60);
    org.jfree.chart.LegendItemCollection var62 = null;
    var61.setFixedLegendItems(var62);
    org.jfree.data.category.CategoryDataset var65 = var61.getDataset((-254));
    org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var61);
    var66.setTextAntiAlias(false);
    var66.setTextAntiAlias(true);
    java.util.List var71 = var66.getSubtitles();
    org.jfree.chart.event.ChartChangeEventType var72 = null;
    org.jfree.chart.event.ChartChangeEvent var73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var55, var66, var72);
    var14.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var66);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var75 = var66.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    var10.removeLegend();
    java.lang.Object var16 = var10.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     java.awt.Stroke var7 = null;
//     var4.setOutlineStroke(var7);
//     org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var11 = null;
//     org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
//     double var14 = var13.getLowerBound();
//     var10.setRange(var13);
//     org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
//     var10.setAutoTickUnitSelection(true, true);
//     boolean var20 = var10.isVisible();
//     java.awt.Stroke var21 = var10.getAxisLineStroke();
//     java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var25 = var24.darker();
//     int var26 = var25.getRed();
//     var10.setTickMarkPaint((java.awt.Paint)var25);
//     var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
//     var10.setVerticalTickLabels(false);
//     org.jfree.data.Range var33 = var10.getRange();
//     var10.setAutoTickUnitSelection(false, false);
//     java.awt.Color var49 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var50 = var49.getAlpha();
//     java.awt.color.ColorSpace var51 = var49.getColorSpace();
//     int var52 = var49.getBlue();
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder((-15.0d), 1.0d, (-15.0d), 0.0d, (java.awt.Paint)var49);
//     org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(10.0d, (-1.0d), 100.0d, 10.0d, (java.awt.Paint)var49);
//     java.awt.image.ColorModel var55 = null;
//     java.awt.Rectangle var56 = null;
//     org.jfree.chart.block.RectangleConstraint var59 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
//     org.jfree.chart.util.Size2D var60 = null;
//     org.jfree.chart.util.Size2D var61 = var59.calculateConstrainedSize(var60);
//     double var62 = var61.getWidth();
//     org.jfree.chart.util.RectangleAnchor var65 = null;
//     java.awt.geom.Rectangle2D var66 = org.jfree.chart.util.RectangleAnchor.createRectangle(var61, 10.0d, 100.0d, var65);
//     var61.setHeight(10.0d);
//     org.jfree.chart.LegendItemSource var71 = null;
//     org.jfree.chart.util.HorizontalAlignment var72 = null;
//     org.jfree.chart.util.VerticalAlignment var73 = null;
//     org.jfree.chart.block.FlowArrangement var76 = new org.jfree.chart.block.FlowArrangement(var72, var73, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var79 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var80 = var76.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var81 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var83 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var76, var81, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var84 = null;
//     org.jfree.chart.util.VerticalAlignment var85 = null;
//     org.jfree.chart.block.ColumnArrangement var88 = new org.jfree.chart.block.ColumnArrangement(var84, var85, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var89 = new org.jfree.chart.title.LegendTitle(var71, (org.jfree.chart.block.Arrangement)var76, (org.jfree.chart.block.Arrangement)var88);
//     org.jfree.chart.util.RectangleAnchor var90 = var89.getLegendItemGraphicLocation();
//     java.lang.Object var91 = var89.clone();
//     org.jfree.chart.util.RectangleAnchor var92 = var89.getLegendItemGraphicLocation();
//     java.awt.geom.Rectangle2D var93 = org.jfree.chart.util.RectangleAnchor.createRectangle(var61, 1.0d, 1.0d, var92);
//     java.awt.geom.AffineTransform var94 = null;
//     java.awt.RenderingHints var95 = null;
//     java.awt.PaintContext var96 = var49.createContext(var55, var56, var93, var94, var95);
//     org.jfree.chart.util.RectangleEdge var97 = null;
//     double var98 = var10.valueToJava2D(1.0d, var93, var97);
//     org.jfree.chart.util.RectangleInsets var99 = var10.getTickLabelInsets();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 255);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var96);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var98 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var99);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var9 = var4.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.CategoryAxis[] var11 = new org.jfree.chart.axis.CategoryAxis[] { var10};
//     var4.setDomainAxes(var11);
//     org.jfree.chart.plot.DrawingSupplier var13 = var4.getDrawingSupplier();
//     java.awt.Stroke var14 = var4.getDomainGridlineStroke();
//     org.jfree.chart.util.SortOrder var15 = var4.getColumnRenderingOrder();
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var16, var17, var18, var19);
//     org.jfree.chart.LegendItemCollection var21 = null;
//     var20.setFixedLegendItems(var21);
//     org.jfree.chart.axis.CategoryAxis var24 = var20.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var26 = var20.getRangeAxisLocation((-16777215));
//     java.awt.Paint var27 = var20.getNoDataMessagePaint();
//     var20.configureRangeAxes();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var29, var30, var31, var32);
//     org.jfree.chart.LegendItemCollection var34 = null;
//     var33.setFixedLegendItems(var34);
//     org.jfree.chart.axis.CategoryAxis var37 = var33.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var39 = var33.getRangeAxisLocation((-16777215));
//     var20.setDomainAxisLocation(var39);
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
//     java.awt.Color var44 = var43.darker();
//     int var45 = var44.getRed();
//     var20.setOutlinePaint((java.awt.Paint)var44);
//     org.jfree.chart.util.RectangleEdge var48 = var20.getDomainAxisEdge(10);
//     org.jfree.chart.event.PlotChangeEvent var49 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var20);
//     var4.notifyListeners(var49);
//     
//     // Checks the contract:  equals-hashcode on var4 and var33
//     assertTrue("Contract failed: equals-hashcode on var4 and var33", var4.equals(var33) ? var4.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var4
//     assertTrue("Contract failed: equals-hashcode on var33 and var4", var33.equals(var4) ? var33.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 1.0d, 100.0d);
    var4.clear();
    org.jfree.chart.ui.BasicProjectInfo var11 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "hi!", "hi!", "hi!");
    org.jfree.chart.event.ChartChangeEvent var12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)"hi!");
    org.jfree.chart.event.ChartChangeEventType var13 = var12.getType();
    boolean var14 = var4.equals((java.lang.Object)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.axis.CategoryAxis var5 = null;
    java.util.List var6 = var4.getCategoriesForAxis(var5);
    float var7 = var4.getBackgroundAlpha();
    java.awt.Color var11 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var12 = var11.getBlue();
    java.awt.color.ColorSpace var13 = var11.getColorSpace();
    var4.setDomainGridlinePaint((java.awt.Paint)var11);
    var4.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.util.SortOrder var5 = var4.getColumnRenderingOrder();
    org.jfree.chart.axis.AxisLocation var6 = var4.getRangeAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var7 = var4.getDatasetRenderingOrder();
    boolean var8 = var4.isRangeGridlinesVisible();
    boolean var9 = var4.isRangeCrosshairVisible();
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("Size2D[width=1.0, height=-1.0]");
    double var12 = var11.getCategoryMargin();
    var11.clearCategoryLabelToolTips();
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var17, var18, var19, var20);
    org.jfree.chart.LegendItemCollection var22 = null;
    var21.setFixedLegendItems(var22);
    org.jfree.data.category.CategoryDataset var25 = var21.getDataset((-254));
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var21);
    org.jfree.chart.title.TextTitle var27 = var26.getTitle();
    var27.setText("ChartEntity: tooltip = hi!");
    org.jfree.chart.LegendItemSource var30 = null;
    org.jfree.chart.util.HorizontalAlignment var31 = null;
    org.jfree.chart.util.VerticalAlignment var32 = null;
    org.jfree.chart.block.FlowArrangement var35 = new org.jfree.chart.block.FlowArrangement(var31, var32, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var38 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var39 = var35.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var40 = null;
    org.jfree.chart.title.LegendItemBlockContainer var42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, var40, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var43 = null;
    org.jfree.chart.util.VerticalAlignment var44 = null;
    org.jfree.chart.block.ColumnArrangement var47 = new org.jfree.chart.block.ColumnArrangement(var43, var44, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var48 = new org.jfree.chart.title.LegendTitle(var30, (org.jfree.chart.block.Arrangement)var35, (org.jfree.chart.block.Arrangement)var47);
    java.awt.Color var52 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var53 = var52.getAlpha();
    java.awt.color.ColorSpace var54 = var52.getColorSpace();
    java.lang.String var55 = var52.toString();
    var48.setItemPaint((java.awt.Paint)var52);
    java.awt.Font var57 = var48.getItemFont();
    var27.setFont(var57);
    org.jfree.chart.title.TextTitle var59 = new org.jfree.chart.title.TextTitle("ChartEntity: tooltip = ", var57);
    var11.setTickLabelFont((java.lang.Comparable)"hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!", var57);
    var4.setDomainAxis(var11);
    var11.setCategoryLabelPositionOffset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var55.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(0.0d, true);
    var4.configureDomainAxes();
    org.jfree.data.category.CategoryDataset var9 = null;
    var4.setDataset(var9);
    org.jfree.chart.renderer.category.CategoryItemRenderer var11 = null;
    var4.setRenderer(var11, true);
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var15, var16, var17, var18);
    org.jfree.chart.util.SortOrder var20 = var19.getColumnRenderingOrder();
    org.jfree.chart.axis.AxisLocation var21 = var19.getRangeAxisLocation();
    org.jfree.chart.plot.DatasetRenderingOrder var22 = var19.getDatasetRenderingOrder();
    org.jfree.chart.axis.AxisLocation var23 = var19.getRangeAxisLocation();
    org.jfree.chart.axis.AxisLocation var24 = org.jfree.chart.axis.AxisLocation.getOpposite(var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation((-1), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
    java.awt.Paint var11 = var4.getNoDataMessagePaint();
    var4.configureRangeAxes();
    org.jfree.chart.axis.AxisSpace var13 = null;
    var4.setFixedDomainAxisSpace(var13);
    org.jfree.chart.util.SortOrder var15 = var4.getRowRenderingOrder();
    org.jfree.chart.LegendItemCollection var16 = var4.getLegendItems();
    java.lang.Object var17 = var16.clone();
    java.util.Iterator var18 = var16.iterator();
    java.util.Iterator var19 = var16.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    var4.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var10 = java.awt.Color.getColor("hi!", 1);
    var4.setNoDataMessagePaint((java.awt.Paint)var10);
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var12, var13, var14, var15);
    org.jfree.chart.LegendItemCollection var17 = null;
    var16.setFixedLegendItems(var17);
    org.jfree.chart.axis.CategoryAxis var20 = var16.getDomainAxis((-16777215));
    org.jfree.chart.axis.AxisLocation var22 = var16.getRangeAxisLocation((-16777215));
    var4.setRangeAxisLocation(var22);
    org.jfree.chart.plot.DatasetRenderingOrder var24 = var4.getDatasetRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    org.jfree.chart.LegendItemCollection var6 = null;
    var5.setFixedLegendItems(var6);
    org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
    var10.setTextAntiAlias(false);
    var10.setTextAntiAlias(true);
    org.jfree.chart.plot.CategoryPlot var15 = var10.getCategoryPlot();
    java.awt.Color var19 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var20 = var19.getBlue();
    int var21 = var19.getBlue();
    int var22 = var19.getGreen();
    var10.setBorderPaint((java.awt.Paint)var19);
    java.awt.Color var27 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var28 = var27.getAlpha();
    java.awt.color.ColorSpace var29 = var27.getColorSpace();
    int var30 = var27.getBlue();
    java.awt.Color var31 = var27.brighter();
    float[] var41 = new float[] { 1.0f, 100.0f, 100.0f};
    float[] var42 = java.awt.Color.RGBtoHSB((-16777215), (-1), 246, var41);
    float[] var43 = java.awt.Color.RGBtoHSB(0, 246, 0, var41);
    float[] var44 = var31.getRGBColorComponents(var41);
    var10.setBackgroundPaint((java.awt.Paint)var31);
    float var46 = var10.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.5f);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis var2 = null;
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
    var5.setRangeCrosshairValue(0.0d, true);
    java.awt.Color var11 = java.awt.Color.getColor("hi!", 1);
    var5.setNoDataMessagePaint((java.awt.Paint)var11);
    java.awt.Font var13 = var5.getNoDataMessageFont();
    org.jfree.data.category.CategoryDataset var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var14, var15, var16, var17);
    org.jfree.chart.LegendItemCollection var19 = null;
    var18.setFixedLegendItems(var19);
    org.jfree.data.category.CategoryDataset var22 = var18.getDataset((-254));
    var18.setAnchorValue(0.0d, false);
    org.jfree.chart.axis.CategoryAxis var27 = null;
    var18.setDomainAxis(246, var27, true);
    org.jfree.chart.axis.AxisSpace var30 = var18.getFixedDomainAxisSpace();
    java.awt.Paint var31 = var18.getRangeCrosshairPaint();
    org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var13, var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.LegendItemEntity var6 = new org.jfree.chart.entity.LegendItemEntity(var5);
    java.awt.Color var10 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var11, var12, var13, var14);
    org.jfree.chart.LegendItemCollection var16 = null;
    var15.setFixedLegendItems(var16);
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.axis.NumberAxis var21 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var22 = null;
    org.jfree.data.Range var24 = org.jfree.data.Range.expandToInclude(var22, 1.0d);
    double var25 = var24.getLowerBound();
    var21.setRange(var24);
    org.jfree.data.Range var27 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var21);
    var21.setAutoTickUnitSelection(true, true);
    boolean var31 = var21.isVisible();
    java.awt.Stroke var32 = var21.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var33, var34, var35, var36);
    org.jfree.chart.axis.CategoryAxis var38 = null;
    java.util.List var39 = var37.getCategoriesForAxis(var38);
    org.jfree.chart.util.RectangleInsets var40 = var37.getInsets();
    double var42 = var40.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var43 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var10, var32, var40);
    org.jfree.chart.util.RectangleInsets var44 = var43.getInsets();
    org.jfree.chart.util.RectangleInsets var45 = var43.getInsets();
    java.awt.Paint var46 = var43.getPaint();
    java.awt.Paint var47 = var43.getPaint();
    org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("java.awt.Color[r=0,g=0,b=0]", "ChartEntity: tooltip = ", "0,-10,10,0,0,10,-10,0,-10,0", "ChartEntity: tooltip = hi!", var5, var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 1.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.combine(var0, var3);
    double var5 = var3.getLowerBound();
    org.jfree.data.Range var8 = org.jfree.data.Range.expand(var3, 100.0d, (-6.0d));
    boolean var11 = var3.intersects(0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    org.jfree.chart.util.HorizontalAlignment var31 = null;
    org.jfree.chart.util.VerticalAlignment var32 = null;
    org.jfree.chart.block.FlowArrangement var35 = new org.jfree.chart.block.FlowArrangement(var31, var32, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var38 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var39 = var35.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var40 = null;
    org.jfree.chart.title.LegendItemBlockContainer var42 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var35, var40, (java.lang.Comparable)(-254));
    java.awt.geom.Rectangle2D var43 = var42.getBounds();
    boolean var44 = var10.equals((java.lang.Object)var42);
    var10.setLabelURL("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }


    java.awt.Color var3 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot(var4, var5, var6, var7);
    org.jfree.chart.LegendItemCollection var9 = null;
    var8.setFixedLegendItems(var9);
    java.awt.Stroke var11 = null;
    var8.setOutlineStroke(var11);
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var15 = null;
    org.jfree.data.Range var17 = org.jfree.data.Range.expandToInclude(var15, 1.0d);
    double var18 = var17.getLowerBound();
    var14.setRange(var17);
    org.jfree.data.Range var20 = var8.getDataRange((org.jfree.chart.axis.ValueAxis)var14);
    var14.setAutoTickUnitSelection(true, true);
    boolean var24 = var14.isVisible();
    java.awt.Stroke var25 = var14.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var26 = null;
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot(var26, var27, var28, var29);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    java.util.List var32 = var30.getCategoriesForAxis(var31);
    org.jfree.chart.util.RectangleInsets var33 = var30.getInsets();
    double var35 = var33.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var36 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var3, var25, var33);
    org.jfree.chart.util.RectangleInsets var37 = var36.getInsets();
    org.jfree.chart.util.RectangleInsets var38 = var36.getInsets();
    java.awt.Paint var39 = var36.getPaint();
    java.awt.Stroke var40 = var36.getStroke();
    org.jfree.chart.util.RectangleInsets var41 = var36.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var4 = null;
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot(var1, var2, var3, var4);
//     org.jfree.chart.LegendItemCollection var6 = null;
//     var5.setFixedLegendItems(var6);
//     org.jfree.data.category.CategoryDataset var9 = var5.getDataset((-254));
//     org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("", (org.jfree.chart.plot.Plot)var5);
//     org.jfree.chart.title.TextTitle var11 = var10.getTitle();
//     var11.setText("ChartEntity: tooltip = hi!");
//     org.jfree.chart.LegendItemSource var14 = null;
//     org.jfree.chart.util.HorizontalAlignment var15 = null;
//     org.jfree.chart.util.VerticalAlignment var16 = null;
//     org.jfree.chart.block.FlowArrangement var19 = new org.jfree.chart.block.FlowArrangement(var15, var16, 1.0d, 100.0d);
//     org.jfree.data.statistics.MeanAndStandardDeviation var22 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
//     boolean var23 = var19.equals((java.lang.Object)0.0d);
//     org.jfree.data.general.Dataset var24 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var26 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var19, var24, (java.lang.Comparable)(-254));
//     org.jfree.chart.util.HorizontalAlignment var27 = null;
//     org.jfree.chart.util.VerticalAlignment var28 = null;
//     org.jfree.chart.block.ColumnArrangement var31 = new org.jfree.chart.block.ColumnArrangement(var27, var28, 100.0d, 100.0d);
//     org.jfree.chart.title.LegendTitle var32 = new org.jfree.chart.title.LegendTitle(var14, (org.jfree.chart.block.Arrangement)var19, (org.jfree.chart.block.Arrangement)var31);
//     java.awt.Color var36 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
//     int var37 = var36.getAlpha();
//     java.awt.color.ColorSpace var38 = var36.getColorSpace();
//     java.lang.String var39 = var36.toString();
//     var32.setItemPaint((java.awt.Paint)var36);
//     java.awt.Font var41 = var32.getItemFont();
//     var11.setFont(var41);
//     java.awt.Font var43 = var11.getFont();
//     java.awt.Graphics2D var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.data.category.CategoryDataset var46 = null;
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var46, var47, var48, var49);
//     org.jfree.chart.LegendItemCollection var51 = null;
//     var50.setFixedLegendItems(var51);
//     org.jfree.chart.axis.CategoryAxis var54 = var50.getDomainAxis((-16777215));
//     org.jfree.chart.util.RectangleEdge var56 = var50.getDomainAxisEdge((-10));
//     java.lang.Object var57 = var11.draw(var44, var45, (java.lang.Object)var50);
//     
//     // Checks the contract:  equals-hashcode on var5 and var50
//     assertTrue("Contract failed: equals-hashcode on var5 and var50", var5.equals(var50) ? var5.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var5
//     assertTrue("Contract failed: equals-hashcode on var50 and var5", var50.equals(var5) ? var50.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle("");
    java.awt.Paint var2 = var1.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var4 = new org.jfree.chart.entity.ChartEntity(var1, "hi!", "hi!");
    java.lang.String var5 = var4.getURLText();
    java.lang.String var6 = var4.toString();
    var4.setToolTipText("hi!");
    java.lang.Object var9 = null;
    boolean var10 = var4.equals(var9);
    java.awt.Image var14 = null;
    org.jfree.chart.ui.ProjectInfo var18 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var14, "", "hi!", "hi!");
    java.util.List var19 = null;
    var18.setContributors(var19);
    java.awt.Image var24 = null;
    org.jfree.chart.ui.ProjectInfo var28 = new org.jfree.chart.ui.ProjectInfo("hi!", "hi!", "", var24, "", "hi!", "hi!");
    java.util.List var29 = null;
    var28.setContributors(var29);
    var18.addLibrary((org.jfree.chart.ui.Library)var28);
    var18.setCopyright("");
    boolean var34 = var4.equals((java.lang.Object)"");
    var4.setToolTipText("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var6.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
//     org.jfree.chart.LegendItemCollection var5 = null;
//     var4.setFixedLegendItems(var5);
//     org.jfree.chart.axis.CategoryAxis var8 = var4.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var10 = var4.getRangeAxisLocation((-16777215));
//     java.awt.Paint var11 = var4.getNoDataMessagePaint();
//     org.jfree.chart.plot.PlotRenderingInfo var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     var4.zoomRangeAxes(10.0d, var13, var14);
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     java.util.List var17 = var4.getCategoriesForAxis(var16);
//     java.awt.Color var21 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var22, var23, var24, var25);
//     org.jfree.chart.LegendItemCollection var27 = null;
//     var26.setFixedLegendItems(var27);
//     java.awt.Stroke var29 = null;
//     var26.setOutlineStroke(var29);
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
//     org.jfree.data.Range var33 = null;
//     org.jfree.data.Range var35 = org.jfree.data.Range.expandToInclude(var33, 1.0d);
//     double var36 = var35.getLowerBound();
//     var32.setRange(var35);
//     org.jfree.data.Range var38 = var26.getDataRange((org.jfree.chart.axis.ValueAxis)var32);
//     var32.setAutoTickUnitSelection(true, true);
//     boolean var42 = var32.isVisible();
//     java.awt.Stroke var43 = var32.getAxisLineStroke();
//     org.jfree.data.category.CategoryDataset var44 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = null;
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var44, var45, var46, var47);
//     org.jfree.chart.axis.CategoryAxis var49 = null;
//     java.util.List var50 = var48.getCategoriesForAxis(var49);
//     org.jfree.chart.util.RectangleInsets var51 = var48.getInsets();
//     double var53 = var51.trimHeight(10.0d);
//     org.jfree.chart.block.LineBorder var54 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var21, var43, var51);
//     var4.setRangeCrosshairStroke(var43);
//     var4.setOutlineVisible(false);
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var58, var59, var60, var61);
//     org.jfree.chart.LegendItemCollection var63 = null;
//     var62.setFixedLegendItems(var63);
//     org.jfree.chart.axis.CategoryAxis var66 = var62.getDomainAxis((-16777215));
//     org.jfree.chart.axis.AxisLocation var67 = var62.getRangeAxisLocation();
//     org.jfree.chart.axis.CategoryAxis var68 = null;
//     org.jfree.chart.axis.CategoryAxis[] var69 = new org.jfree.chart.axis.CategoryAxis[] { var68};
//     var62.setDomainAxes(var69);
//     var4.setDomainAxes(var69);
//     
//     // Checks the contract:  equals-hashcode on var48 and var62
//     assertTrue("Contract failed: equals-hashcode on var48 and var62", var48.equals(var62) ? var48.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var48
//     assertTrue("Contract failed: equals-hashcode on var62 and var48", var62.equals(var48) ? var62.hashCode() == var48.hashCode() : true);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList(100);
    java.lang.Object var2 = var1.clone();
    java.lang.Object var4 = null;
    var1.set(246, var4);
    java.lang.Object var7 = var1.get(0);
    var1.set(0, (java.lang.Object)0.0f);
    java.lang.Object var12 = var1.get((-16777215));
    var1.set(10, (java.lang.Object)(byte)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }
// 
// 
//     org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
//     org.jfree.chart.JFreeChart var2 = null;
//     org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var2);
//     java.lang.String var4 = var1.getText();
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.text.TextAnchor var8 = null;
//     var1.draw(var5, 0.0f, 10.0f, var8, 0.0f, 100.0f, 25.0d);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }


    java.awt.Image var3 = null;
    org.jfree.chart.ui.ProjectInfo var7 = new org.jfree.chart.ui.ProjectInfo("", "", "hi!", var3, "100", "", "hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test212"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("ChartEntity: tooltip = hi!");
    org.jfree.chart.JFreeChart var2 = null;
    org.jfree.chart.event.ChartChangeEvent var3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var1, var2);
    java.lang.String var4 = var1.getText();
    org.jfree.chart.LegendItemSource var5 = null;
    org.jfree.chart.util.HorizontalAlignment var6 = null;
    org.jfree.chart.util.VerticalAlignment var7 = null;
    org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var13 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var14 = var10.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var15 = null;
    org.jfree.chart.title.LegendItemBlockContainer var17 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var10, var15, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var18 = null;
    org.jfree.chart.util.VerticalAlignment var19 = null;
    org.jfree.chart.block.ColumnArrangement var22 = new org.jfree.chart.block.ColumnArrangement(var18, var19, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var23 = new org.jfree.chart.title.LegendTitle(var5, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var22);
    org.jfree.chart.util.RectangleEdge var24 = var23.getPosition();
    org.jfree.data.category.CategoryDataset var25 = null;
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var25, var26, var27, var28);
    org.jfree.chart.util.SortOrder var30 = var29.getColumnRenderingOrder();
    org.jfree.chart.util.SortOrder var31 = var29.getColumnRenderingOrder();
    var29.setForegroundAlpha(0.0f);
    boolean var34 = var24.equals((java.lang.Object)var29);
    org.jfree.chart.axis.CategoryAnchor var35 = var29.getDomainGridlinePosition();
    java.lang.String var36 = var35.toString();
    boolean var37 = var1.equals((java.lang.Object)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "ChartEntity: tooltip = hi!"+ "'", var4.equals("ChartEntity: tooltip = hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "CategoryAnchor.MIDDLE"+ "'", var36.equals("CategoryAnchor.MIDDLE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test213"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, var3);
    org.jfree.chart.LegendItemCollection var5 = null;
    var4.setFixedLegendItems(var5);
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var11 = null;
    org.jfree.data.Range var13 = org.jfree.data.Range.expandToInclude(var11, 1.0d);
    double var14 = var13.getLowerBound();
    var10.setRange(var13);
    org.jfree.data.Range var16 = var4.getDataRange((org.jfree.chart.axis.ValueAxis)var10);
    var10.setAutoTickUnitSelection(true, true);
    boolean var20 = var10.isVisible();
    java.awt.Stroke var21 = var10.getAxisLineStroke();
    java.awt.Color var24 = java.awt.Color.getColor("hi!", 1);
    java.awt.Color var25 = var24.darker();
    int var26 = var25.getRed();
    var10.setTickMarkPaint((java.awt.Paint)var25);
    var10.setLabelURL("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.chart.axis.TickUnitSource var30 = var10.getStandardTickUnits();
    var10.setVerticalTickLabels(false);
    org.jfree.data.Range var33 = var10.getRange();
    boolean var34 = var10.getAutoRangeIncludesZero();
    double var35 = var10.getLowerBound();
    boolean var36 = var10.isAxisLineVisible();
    boolean var37 = var10.isPositiveArrowVisible();
    var10.resizeRange((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test214"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, (-1.0d));
    org.jfree.chart.util.Size2D var3 = null;
    org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
    org.jfree.chart.block.RectangleConstraint var6 = var2.toFixedWidth((-1.0d));
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var8 = null;
    org.jfree.data.Range var10 = org.jfree.data.Range.expandToInclude(var8, 1.0d);
    org.jfree.data.Range var11 = org.jfree.data.Range.combine(var7, var10);
    org.jfree.chart.block.RectangleConstraint var12 = var2.toRangeHeight(var10);
    org.jfree.chart.block.LengthConstraintType var13 = var2.getHeightConstraintType();
    java.lang.String var14 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "LengthConstraintType.FIXED"+ "'", var14.equals("LengthConstraintType.FIXED"));

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test215"); }


    java.awt.Color var5 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var6 = var5.getAlpha();
    java.awt.Color var7 = java.awt.Color.getColor("Size2D[width=1.0, height=-1.0]", var5);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var14 = new org.jfree.chart.entity.ChartEntity(var13);
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var18 = org.jfree.chart.util.ShapeUtilities.equal(var13, var17);
    org.jfree.chart.LegendItemSource var19 = null;
    org.jfree.chart.util.HorizontalAlignment var20 = null;
    org.jfree.chart.util.VerticalAlignment var21 = null;
    org.jfree.chart.block.FlowArrangement var24 = new org.jfree.chart.block.FlowArrangement(var20, var21, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var27 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var28 = var24.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var29 = null;
    org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var24, var29, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var32 = null;
    org.jfree.chart.util.VerticalAlignment var33 = null;
    org.jfree.chart.block.ColumnArrangement var36 = new org.jfree.chart.block.ColumnArrangement(var32, var33, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var37 = new org.jfree.chart.title.LegendTitle(var19, (org.jfree.chart.block.Arrangement)var24, (org.jfree.chart.block.Arrangement)var36);
    org.jfree.chart.util.RectangleAnchor var38 = var37.getLegendItemGraphicLocation();
    java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, var38, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var47 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis var49 = null;
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var48, var49, var50, var51);
    org.jfree.chart.LegendItemCollection var53 = null;
    var52.setFixedLegendItems(var53);
    java.awt.Stroke var55 = null;
    var52.setOutlineStroke(var55);
    org.jfree.chart.axis.NumberAxis var58 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var59 = null;
    org.jfree.data.Range var61 = org.jfree.data.Range.expandToInclude(var59, 1.0d);
    double var62 = var61.getLowerBound();
    var58.setRange(var61);
    org.jfree.data.Range var64 = var52.getDataRange((org.jfree.chart.axis.ValueAxis)var58);
    var58.setAutoTickUnitSelection(true, true);
    boolean var68 = var58.isVisible();
    java.awt.Stroke var69 = var58.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var70 = null;
    org.jfree.chart.axis.CategoryAxis var71 = null;
    org.jfree.chart.axis.ValueAxis var72 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var73 = null;
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot(var70, var71, var72, var73);
    org.jfree.chart.axis.CategoryAxis var75 = null;
    java.util.List var76 = var74.getCategoriesForAxis(var75);
    org.jfree.chart.util.RectangleInsets var77 = var74.getInsets();
    double var79 = var77.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var80 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var47, var69, var77);
    var43.setAxisLineStroke(var69);
    java.awt.Color var85 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var86 = var85.getAlpha();
    java.awt.color.ColorSpace var87 = var85.getColorSpace();
    int var88 = var85.getBlue();
    java.awt.Color var89 = var85.brighter();
    org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var41, var69, (java.awt.Paint)var89);
    boolean var91 = var90.isShapeVisible();
    java.lang.String var92 = var90.getLabel();
    var90.setSeriesIndex(0);
    java.awt.Stroke var95 = var90.getOutlineStroke();
    org.jfree.chart.plot.ValueMarker var96 = new org.jfree.chart.plot.ValueMarker((-22.0d), (java.awt.Paint)var5, var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var92 + "' != '" + "Range[1.0,1.0]"+ "'", var92.equals("Range[1.0,1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test216"); }


    org.jfree.chart.LegendItemSource var1 = null;
    org.jfree.chart.util.HorizontalAlignment var2 = null;
    org.jfree.chart.util.VerticalAlignment var3 = null;
    org.jfree.chart.block.FlowArrangement var6 = new org.jfree.chart.block.FlowArrangement(var2, var3, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var9 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var10 = var6.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var11 = null;
    org.jfree.chart.title.LegendItemBlockContainer var13 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var6, var11, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var14 = null;
    org.jfree.chart.util.VerticalAlignment var15 = null;
    org.jfree.chart.block.ColumnArrangement var18 = new org.jfree.chart.block.ColumnArrangement(var14, var15, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var19 = new org.jfree.chart.title.LegendTitle(var1, (org.jfree.chart.block.Arrangement)var6, (org.jfree.chart.block.Arrangement)var18);
    java.awt.Color var23 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var24 = var23.getAlpha();
    java.awt.color.ColorSpace var25 = var23.getColorSpace();
    java.lang.String var26 = var23.toString();
    var19.setItemPaint((java.awt.Paint)var23);
    java.awt.Font var28 = var19.getItemFont();
    java.awt.Color var32 = java.awt.Color.getHSBColor(10.0f, 0.0f, 10.0f);
    int var33 = var32.getBlue();
    java.awt.color.ColorSpace var34 = var32.getColorSpace();
    org.jfree.chart.block.LabelBlock var35 = new org.jfree.chart.block.LabelBlock("", var28, (java.awt.Paint)var32);
    double var36 = var35.getWidth();
    java.lang.Object var37 = var35.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + "java.awt.Color[r=0,g=0,b=0]"+ "'", var26.equals("java.awt.Color[r=0,g=0,b=0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 246);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test217"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(10.0f);
    org.jfree.chart.entity.ChartEntity var6 = new org.jfree.chart.entity.ChartEntity(var5);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createRegularCross(0.0f, 0.0f);
    boolean var10 = org.jfree.chart.util.ShapeUtilities.equal(var5, var9);
    org.jfree.chart.LegendItemSource var11 = null;
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    org.jfree.chart.util.VerticalAlignment var13 = null;
    org.jfree.chart.block.FlowArrangement var16 = new org.jfree.chart.block.FlowArrangement(var12, var13, 1.0d, 100.0d);
    org.jfree.data.statistics.MeanAndStandardDeviation var19 = new org.jfree.data.statistics.MeanAndStandardDeviation((-1.0d), 0.0d);
    boolean var20 = var16.equals((java.lang.Object)0.0d);
    org.jfree.data.general.Dataset var21 = null;
    org.jfree.chart.title.LegendItemBlockContainer var23 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var16, var21, (java.lang.Comparable)(-254));
    org.jfree.chart.util.HorizontalAlignment var24 = null;
    org.jfree.chart.util.VerticalAlignment var25 = null;
    org.jfree.chart.block.ColumnArrangement var28 = new org.jfree.chart.block.ColumnArrangement(var24, var25, 100.0d, 100.0d);
    org.jfree.chart.title.LegendTitle var29 = new org.jfree.chart.title.LegendTitle(var11, (org.jfree.chart.block.Arrangement)var16, (org.jfree.chart.block.Arrangement)var28);
    org.jfree.chart.util.RectangleAnchor var30 = var29.getLegendItemGraphicLocation();
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var30, 0.0d, (-1.0d));
    org.jfree.chart.axis.NumberAxis var35 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    java.awt.Color var39 = java.awt.Color.getHSBColor(100.0f, (-1.0f), 0.0f);
    org.jfree.data.category.CategoryDataset var40 = null;
    org.jfree.chart.axis.CategoryAxis var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var40, var41, var42, var43);
    org.jfree.chart.LegendItemCollection var45 = null;
    var44.setFixedLegendItems(var45);
    java.awt.Stroke var47 = null;
    var44.setOutlineStroke(var47);
    org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi! version hi!.\n.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:\nCONTRIBUTORS:None\nOTHER LIBRARIES USED BY hi!:None\nhi! LICENCE TERMS:\nhi!");
    org.jfree.data.Range var51 = null;
    org.jfree.data.Range var53 = org.jfree.data.Range.expandToInclude(var51, 1.0d);
    double var54 = var53.getLowerBound();
    var50.setRange(var53);
    org.jfree.data.Range var56 = var44.getDataRange((org.jfree.chart.axis.ValueAxis)var50);
    var50.setAutoTickUnitSelection(true, true);
    boolean var60 = var50.isVisible();
    java.awt.Stroke var61 = var50.getAxisLineStroke();
    org.jfree.data.category.CategoryDataset var62 = null;
    org.jfree.chart.axis.CategoryAxis var63 = null;
    org.jfree.chart.axis.ValueAxis var64 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var65 = null;
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var62, var63, var64, var65);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    java.util.List var68 = var66.getCategoriesForAxis(var67);
    org.jfree.chart.util.RectangleInsets var69 = var66.getInsets();
    double var71 = var69.trimHeight(10.0d);
    org.jfree.chart.block.LineBorder var72 = new org.jfree.chart.block.LineBorder((java.awt.Paint)var39, var61, var69);
    var35.setAxisLineStroke(var61);
    java.awt.Color var77 = java.awt.Color.getHSBColor((-1.0f), 1.0f, 0.0f);
    int var78 = var77.getAlpha();
    java.awt.color.ColorSpace var79 = var77.getColorSpace();
    int var80 = var77.getBlue();
    java.awt.Color var81 = var77.brighter();
    org.jfree.chart.LegendItem var82 = new org.jfree.chart.LegendItem("Range[1.0,1.0]", "hi!", "hi!", "ChartEntity: tooltip = hi!", var33, var61, (java.awt.Paint)var81);
    boolean var83 = var82.isShapeVisible();
    boolean var84 = var82.isShapeFilled();
    java.lang.Comparable var85 = var82.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var85);

  }

}
