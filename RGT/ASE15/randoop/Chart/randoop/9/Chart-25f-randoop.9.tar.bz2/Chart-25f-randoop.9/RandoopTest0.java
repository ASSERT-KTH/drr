
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Paint var0 = null;
    java.awt.Stroke var1 = null;
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var3 = new org.jfree.chart.block.LineBorder(var0, var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("", var1);
//     
//     // Checks the contract:  var2.equals(var2)
//     assertTrue("Contract failed: var2.equals(var2)", var2.equals(var2));
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("hi!", var1, var2);
// 
//   }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "hi!", var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("", "", "", "", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem(var0, "hi!", "hi!", "", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)' ');
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelPaint(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    java.awt.Shape var4 = null;
    java.awt.Stroke var5 = null;
    java.awt.Paint var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var7 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", var4, var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    org.jfree.chart.util.RectangleInsets var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickLabelInsets(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    int var3 = java.awt.Color.HSBtoRGB(100.0f, (-1.0f), 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    java.awt.Paint var1 = null;
    java.awt.Stroke var2 = null;
    java.awt.Paint var3 = null;
    java.awt.Stroke var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var6 = new org.jfree.chart.plot.ValueMarker(1.0d, var1, var2, var3, var4, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.05d, 10.0d);
//     org.jfree.chart.block.Block var5 = null;
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 0.05d, 10.0d);
//     var4.add(var5, (java.lang.Object)0.05d);
//     
//     // Checks the contract:  equals-hashcode on var4 and var10
//     assertTrue("Contract failed: equals-hashcode on var4 and var10", var4.equals(var10) ? var4.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var4
//     assertTrue("Contract failed: equals-hashcode on var10 and var4", var10.equals(var4) ? var10.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var5 = null;
    java.awt.Paint var7 = null;
    java.awt.Paint var9 = null;
    java.awt.Stroke var10 = null;
    java.awt.Shape var12 = null;
    java.awt.Stroke var13 = null;
    java.awt.Paint var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var15 = new org.jfree.chart.LegendItem(var0, "hi!", "", "hi!", true, var5, false, var7, false, var9, var10, true, var12, var13, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.05d, 100.0f, (-1.0f));

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    double var2 = var1.getUpperMargin();
    java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)10.0d);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, (-1.0f), (-1.0f), 0.05d, 1.0f, 0.0f);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    java.awt.Stroke var6 = null;
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem(var0, "", "", "", var4, var5, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getUpperMargin();
//     java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)10.0d);
//     java.awt.Paint var5 = null;
//     org.jfree.chart.text.TextMeasurer var7 = null;
//     org.jfree.chart.text.TextBlock var8 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var4, var5, 10.0f, var7);
// 
//   }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 0.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "", "hi!", var3, (java.lang.Comparable)100L, (java.lang.Comparable)(-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("", var1, var2);
// 
//   }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.axis.CategoryLabelPosition var0 = null;
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    org.jfree.chart.axis.CategoryLabelPosition var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var4 = new org.jfree.chart.axis.CategoryLabelPositions(var0, var1, var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test36() {}
//   public void test36() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.Paint var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var1 = new org.jfree.chart.block.BlockBorder(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 100.0d, 100.0d, 10.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    double var2 = var1.getUpperMargin();
    java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, (-1.0d), var2);
// 
//   }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.plot.Plot var2 = null;
//     org.jfree.chart.JFreeChart var4 = new org.jfree.chart.JFreeChart("", var1, var2, false);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.KeyToGroupMap var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 0.05d, 10.0d);
//     org.jfree.chart.util.HorizontalAlignment var6 = null;
//     org.jfree.chart.util.VerticalAlignment var7 = null;
//     org.jfree.chart.block.FlowArrangement var10 = new org.jfree.chart.block.FlowArrangement(var6, var7, 0.05d, 10.0d);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     double var13 = var12.getUpperMargin();
//     java.awt.Font var15 = var12.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var16 = null;
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("", var15, var16);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     java.awt.Font var21 = var18.getTickLabelFont((java.lang.Comparable)10.0d);
//     var17.setFont(var21);
//     var17.setWidth(0.0d);
//     java.lang.Object var25 = null;
//     var10.add((org.jfree.chart.block.Block)var17, var25);
//     org.jfree.chart.title.LegendTitle var27 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var10);
//     
//     // Checks the contract:  equals-hashcode on var5 and var10
//     assertTrue("Contract failed: equals-hashcode on var5 and var10", var5.equals(var10) ? var5.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var5
//     assertTrue("Contract failed: equals-hashcode on var10 and var5", var10.equals(var5) ? var10.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);

  }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
//     org.jfree.chart.text.TextFragment var8 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextAnchor var12 = null;
//     var8.draw(var9, 0.0f, (-1.0f), var12, 0.0f, (-1.0f), 18.0d);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    org.jfree.data.Range var2 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var2, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var0.arrange(var1, var4);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var3 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
//     org.jfree.chart.text.TextFragment var8 = new org.jfree.chart.text.TextFragment("", var5);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.util.Size2D var10 = var8.calculateDimensions(var9);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getDomainGridlinePaint();
    java.awt.Stroke var2 = null;
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var5 = var3.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var3.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var8 = var3.getTickLabelInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LineBorder var9 = new org.jfree.chart.block.LineBorder(var1, var2, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("18");

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.axis.TickUnit var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getLargerTickUnit(var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.axis.CategoryAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainGridlinePosition(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    var0.removeColumn((java.lang.Comparable)(short)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    java.awt.Paint var8 = var5.getOutlinePaint();
    java.awt.Stroke var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var11 = var10.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("hi!", "", "hi!", "", var4, var8, var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var3 = new org.jfree.chart.entity.ChartEntity(var0, "18", "18");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    java.util.List var2 = var1.getBlocks();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var7 = var6.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var1, var3, var6);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.util.List var1 = var0.getBlocks();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.block.RectangleConstraint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var4 = var0.arrange(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearDomainMarkers(0);
    java.awt.Paint var5 = var2.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var6 = new org.jfree.chart.text.TextLine("", var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     java.lang.Object var4 = var0.draw(var1, var2, (java.lang.Object)(byte)100);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getSeriesItemLabelGenerator((-1));
    java.awt.Shape var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseShape(var5, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 18.0d, "", var3, var4, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    java.util.List var1 = var0.getBlocks();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var2, (java.lang.Object)0L);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = null;
//     var0.setDrawingSupplier(var5);
//     org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
//     java.util.List var8 = var0.getAnnotations();
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     var0.addRangeMarker((-1), var10, var11);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, (-1.0d), 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("18", var1, var2);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    org.jfree.data.Range var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var4 = var2.toRangeHeight(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "java.awt.Color[r=0,g=0,b=18]", var3);
// 
//   }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var0.setLowerMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)10.0d);
//     var0.setTickLabelFont(var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearDomainMarkers(0);
//     java.awt.Paint var14 = var11.getOutlinePaint();
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     org.jfree.chart.axis.AxisSpace var17 = null;
//     org.jfree.chart.axis.AxisSpace var18 = var0.reserveSpace(var10, (org.jfree.chart.plot.Plot)var11, var15, var16, var17);
// 
//   }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var0.setDrawingSupplier(var5);
    org.jfree.chart.axis.CategoryAxis var7 = var0.getDomainAxis();
    org.jfree.chart.annotations.CategoryAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var0 + "' != '" + "18"+ "'", var0.equals("18"));

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.chart.util.GradientPaintTransformType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.StandardGradientPaintTransformer var1 = new org.jfree.chart.util.StandardGradientPaintTransformer(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.chart.util.PaintList var1 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var4 = var2.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var2.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var7 = var2.getTickLabelInsets();
    boolean var8 = var1.equals((java.lang.Object)var2);
    java.awt.Font var10 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearDomainMarkers(0);
    java.awt.Paint var14 = var11.getOutlinePaint();
    boolean var15 = var11.isSubplot();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var19 = var16.getFixedRangeAxisSpace();
    java.awt.Paint var20 = var16.getDomainGridlinePaint();
    var11.setNoDataMessagePaint(var20);
    org.jfree.chart.util.RectangleEdge var22 = null;
    org.jfree.chart.title.TextTitle var23 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var24 = var23.getFont();
    java.lang.Object var25 = var23.clone();
    org.jfree.chart.util.HorizontalAlignment var26 = var23.getHorizontalAlignment();
    org.jfree.chart.util.VerticalAlignment var27 = null;
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var30 = var28.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var28.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var33 = var28.getTickLabelInsets();
    double var35 = var33.calculateLeftOutset(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle("18", var10, var20, var22, var26, var27, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 4.0d);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.draw(var1, var2);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, (-1.0f));
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     var0.setWeight((-1));
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Point2D var9 = null;
//     org.jfree.chart.plot.PlotState var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     var0.draw(var7, var8, var9, var10, var11);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=0,b=18]", var1, 100.0f, 0.0f, 100.0d, (-1.0f), (-1.0f));
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("18", var1, var2);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(0);
//     java.awt.Paint var12 = var9.getOutlinePaint();
//     boolean var13 = var9.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     int var15 = var9.getDomainAxisIndex(var14);
//     var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var9);
//     java.lang.Object var17 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var5);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var20 = var18.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var26 = var22.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var27 = null;
//     var22.setDrawingSupplier(var27);
//     org.jfree.chart.axis.CategoryAxis var29 = var22.getDomainAxis();
//     java.util.List var30 = var22.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var32 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     var18.drawRangeMarker(var21, var22, (org.jfree.chart.axis.ValueAxis)var32, var33, var34);
//     org.jfree.chart.util.Layer var36 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var37 = null;
//     var0.drawAnnotations(var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var32, var36, var37);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var3.draw(var5, var6);
// 
//   }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     java.awt.Paint var4 = var0.getNoDataMessagePaint();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     java.awt.Paint var8 = var5.getOutlinePaint();
//     java.awt.Paint var9 = var5.getNoDataMessagePaint();
//     var0.setNoDataMessagePaint(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    org.jfree.chart.labels.ItemLabelPosition var2 = new org.jfree.chart.labels.ItemLabelPosition();
    java.lang.Object var3 = null;
    boolean var4 = var2.equals(var3);
    org.jfree.chart.text.TextAnchor var5 = var2.getTextAnchor();
    org.jfree.chart.axis.CategoryLabelWidthType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var9 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1, var5, 4.0d, var7, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    boolean var4 = var0.equals((java.lang.Object)var3);
    org.jfree.chart.block.Arrangement var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setArrangement(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.labels.ItemLabelPosition var1 = new org.jfree.chart.labels.ItemLabelPosition();
    java.lang.Object var2 = null;
    boolean var3 = var1.equals(var2);
    org.jfree.chart.text.TextAnchor var4 = var1.getTextAnchor();
    org.jfree.chart.labels.ItemLabelPosition var5 = new org.jfree.chart.labels.ItemLabelPosition();
    java.lang.Object var6 = null;
    boolean var7 = var5.equals(var6);
    org.jfree.chart.text.TextAnchor var8 = var5.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var10 = new org.jfree.chart.labels.ItemLabelPosition(var0, var4, var8, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.setLicenceName("");
    var0.setCopyright("hi!");
    java.lang.String var5 = var0.getCopyright();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "hi!"+ "'", var5.equals("hi!"));

  }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible((-1));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
//     var0.setLegendItemToolTipGenerator(var3);
//     boolean var5 = var0.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getToolTipGenerator(100, (-1));
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var14 = var10.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var15 = null;
//     var10.setDrawingSupplier(var15);
//     java.awt.Image var17 = null;
//     var10.setBackgroundImage(var17);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Point2D var22 = null;
//     var10.zoomRangeAxes(1.0d, 0.0d, var21, var22);
//     org.jfree.data.category.CategoryDataset var24 = var10.getDataset();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     double var26 = var25.getUpperMargin();
//     java.awt.Font var28 = var25.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.clearDomainMarkers(0);
//     java.awt.Paint var32 = var29.getOutlinePaint();
//     boolean var33 = var29.isSubplot();
//     var25.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var29);
//     org.jfree.chart.plot.CategoryMarker var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     var0.drawDomainMarker(var9, var10, var25, var35, var36);
// 
//   }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.util.RectangleAnchor var0 = null;
    org.jfree.chart.text.TextBlockAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    org.jfree.chart.plot.Plot var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.PlotChangeEvent var1 = new org.jfree.chart.event.PlotChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var0.setLowerMargin(1.0d);
//     java.lang.String var5 = var0.getLabelToolTip();
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = null;
//     org.jfree.chart.axis.AxisState var12 = var0.draw(var6, 2.0d, var8, var9, var10, var11);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("HorizontalAlignment.CENTER", var1, var2);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    var0.setBase(18.0d);
    org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    java.awt.Shape var23 = var15.calculateBounds(var16, 0.0f, 100.0f, var19, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var27 = var24.getTickMarkStroke();
    java.awt.Color var29 = java.awt.Color.decode("18");
    float[] var30 = null;
    float[] var31 = var29.getRGBColorComponents(var30);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var23, var27, (java.awt.Paint)var29);
    java.awt.Color var35 = java.awt.Color.decode("18");
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var40 = var37.getFixedRangeAxisSpace();
    java.awt.Paint var41 = var37.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var45 = var42.getFixedRangeAxisSpace();
    java.awt.Paint var46 = var42.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var47 = null;
    var42.setRangeAxis(var47);
    var42.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var53 = var51.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var54 = var51.getTickMarkStroke();
    var42.setDomainGridlineStroke(var54);
    org.jfree.chart.text.TextBlock var57 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var58 = null;
    org.jfree.chart.text.TextBlockAnchor var61 = null;
    java.awt.Shape var65 = var57.calculateBounds(var58, 0.0f, 100.0f, var61, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var68 = var66.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
    var70.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var74 = var70.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var75 = null;
    var70.setDrawingSupplier(var75);
    org.jfree.chart.axis.CategoryAxis var77 = var70.getDomainAxis();
    java.util.List var78 = var70.getAnnotations();
    org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var81 = null;
    java.awt.geom.Rectangle2D var82 = null;
    var66.drawRangeMarker(var69, var70, (org.jfree.chart.axis.ValueAxis)var80, var81, var82);
    var66.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var86 = var66.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis();
    double var88 = var87.getUpperMargin();
    java.awt.Font var90 = var87.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var91 = var87.isTickMarksVisible();
    java.awt.Paint var92 = var87.getAxisLinePaint();
    org.jfree.chart.LegendItem var93 = new org.jfree.chart.LegendItem("18", "18", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", false, var23, false, (java.awt.Paint)var35, false, var41, var54, false, var65, var86, var92);
    var0.setSeriesFillPaint(0, (java.awt.Paint)var35, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var97 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777216), var97, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.annotations.CategoryAnnotation var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.removeAnnotation(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=0,g=0,b=18]", var1, 18.0d, (-1.0f), 0.0f);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-16777216), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getSeriesItemLabelGenerator((-1));
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-1), var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    java.awt.Color var1 = java.awt.Color.getColor("HorizontalAlignment.CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.notifyListeners(var3);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var10 = var6.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var11 = null;
//     var6.setDrawingSupplier(var11);
//     java.awt.Image var13 = null;
//     var6.setBackgroundImage(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var17 = null;
//     java.awt.geom.Point2D var18 = null;
//     var6.zoomRangeAxes(1.0d, 0.0d, var17, var18);
//     org.jfree.data.category.CategoryDataset var20 = var6.getDataset();
//     java.awt.geom.Rectangle2D var21 = null;
//     var0.drawBackground(var5, var6, var21);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("java.awt.Color[r=0,g=0,b=18]", var1);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     int var6 = var0.getDomainAxisIndex(var5);
//     org.jfree.chart.axis.AxisLocation var8 = var0.getDomainAxisLocation(100);
//     org.jfree.chart.plot.Marker var10 = null;
//     org.jfree.chart.util.Layer var11 = null;
//     var0.addRangeMarker(0, var10, var11);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(4.0d, 6.0d, var2);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("HorizontalAlignment.CENTER", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
//     org.jfree.chart.axis.TickUnits var1 = new org.jfree.chart.axis.TickUnits();
//     boolean var3 = var1.equals((java.lang.Object)(byte)10);
//     org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     var1.add((org.jfree.chart.axis.TickUnit)var5);
//     var0.add((org.jfree.chart.axis.TickUnit)var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var1
//     assertTrue("Contract failed: equals-hashcode on var0 and var1", var0.equals(var1) ? var0.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var0
//     assertTrue("Contract failed: equals-hashcode on var1 and var0", var1.equals(var0) ? var1.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.HorizontalAlignment var3 = var0.getHorizontalAlignment();
    java.awt.Graphics2D var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var0.arrange(var4);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var3 = null;
    var0.setGradientPaintTransformer(var3);
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getUpperMargin();
    java.awt.Font var12 = var9.getTickLabelFont((java.lang.Comparable)10.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var15 = var13.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
    var17.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var21 = var17.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var22 = null;
    var17.setDrawingSupplier(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var17.getDomainAxis();
    java.util.List var25 = var17.getAnnotations();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var28 = null;
    java.awt.geom.Rectangle2D var29 = null;
    var13.drawRangeMarker(var16, var17, (org.jfree.chart.axis.ValueAxis)var27, var28, var29);
    float var31 = var27.getTickMarkInsideLength();
    org.jfree.data.category.CategoryDataset var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var5, var6, var7, var8, var9, (org.jfree.chart.axis.ValueAxis)var27, var32, 0, 0, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0f);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition();
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.chart.text.TextAnchor var7 = var4.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("java.awt.Color[r=0,g=0,b=18]", var1, (-1.0f), 100.0f, var7, 4.0d, (-1.0f), 10.0f);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers(0);
//     java.awt.Paint var4 = var1.getOutlinePaint();
//     boolean var5 = var1.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var6 = null;
//     int var7 = var1.getDomainAxisIndex(var6);
//     org.jfree.chart.axis.AxisLocation var9 = var1.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var10 = var1.getDomainAxisEdge();
//     double var11 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var10);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    var0.setBase(18.0d);
    org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    java.awt.Shape var23 = var15.calculateBounds(var16, 0.0f, 100.0f, var19, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var27 = var24.getTickMarkStroke();
    java.awt.Color var29 = java.awt.Color.decode("18");
    float[] var30 = null;
    float[] var31 = var29.getRGBColorComponents(var30);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var23, var27, (java.awt.Paint)var29);
    java.awt.Color var35 = java.awt.Color.decode("18");
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var40 = var37.getFixedRangeAxisSpace();
    java.awt.Paint var41 = var37.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var45 = var42.getFixedRangeAxisSpace();
    java.awt.Paint var46 = var42.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var47 = null;
    var42.setRangeAxis(var47);
    var42.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var53 = var51.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var54 = var51.getTickMarkStroke();
    var42.setDomainGridlineStroke(var54);
    org.jfree.chart.text.TextBlock var57 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var58 = null;
    org.jfree.chart.text.TextBlockAnchor var61 = null;
    java.awt.Shape var65 = var57.calculateBounds(var58, 0.0f, 100.0f, var61, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var66 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var68 = var66.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var69 = null;
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot();
    var70.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var74 = var70.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var75 = null;
    var70.setDrawingSupplier(var75);
    org.jfree.chart.axis.CategoryAxis var77 = var70.getDomainAxis();
    java.util.List var78 = var70.getAnnotations();
    org.jfree.chart.axis.NumberAxis var80 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var81 = null;
    java.awt.geom.Rectangle2D var82 = null;
    var66.drawRangeMarker(var69, var70, (org.jfree.chart.axis.ValueAxis)var80, var81, var82);
    var66.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var86 = var66.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var87 = new org.jfree.chart.axis.CategoryAxis();
    double var88 = var87.getUpperMargin();
    java.awt.Font var90 = var87.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var91 = var87.isTickMarksVisible();
    java.awt.Paint var92 = var87.getAxisLinePaint();
    org.jfree.chart.LegendItem var93 = new org.jfree.chart.LegendItem("18", "18", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", false, var23, false, (java.awt.Paint)var35, false, var41, var54, false, var65, var86, var92);
    var0.setSeriesFillPaint(0, (java.awt.Paint)var35, true);
    org.jfree.chart.annotations.CategoryAnnotation var96 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var96);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible((-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemToolTipGenerator(var3);
    boolean var5 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getToolTipGenerator(100, (-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesVisible((-1), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("18", "18", var3);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var0.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var5 = var0.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var6.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var11 = var6.getTickLabelInsets();
    var0.setLabelInsets(var11);
    double var13 = var11.getRight();
    double var14 = var11.getBottom();
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var18 = var11.createOutsetRectangle(var15, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.chart.util.PaintList var1 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var4 = var2.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var2.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var7 = var2.getTickLabelInsets();
//     boolean var8 = var1.equals((java.lang.Object)var2);
//     java.awt.Font var10 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var14 = var11.getFixedRangeAxisSpace();
//     java.awt.Paint var15 = var11.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var10, var15);
//     org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.PaintList var19 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var22 = var20.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var20.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var25 = var20.getTickLabelInsets();
//     boolean var26 = var19.equals((java.lang.Object)var20);
//     java.awt.Font var28 = var20.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var32 = var29.getFixedRangeAxisSpace();
//     java.awt.Paint var33 = var29.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var34 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var28, var33);
//     org.jfree.chart.util.HorizontalAlignment var35 = var34.getLineAlignment();
//     var17.setHorizontalAlignment(var35);
//     var16.setLineAlignment(var35);
//     
//     // Checks the contract:  equals-hashcode on var1 and var19
//     assertTrue("Contract failed: equals-hashcode on var1 and var19", var1.equals(var19) ? var1.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var1
//     assertTrue("Contract failed: equals-hashcode on var19 and var1", var19.equals(var1) ? var19.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var29
//     assertTrue("Contract failed: equals-hashcode on var11 and var29", var11.equals(var29) ? var11.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var11
//     assertTrue("Contract failed: equals-hashcode on var29 and var11", var29.equals(var11) ? var29.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     boolean var0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == false);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    java.awt.Paint var7 = var4.getOutlinePaint();
    boolean var8 = var4.isSubplot();
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    org.jfree.chart.util.SortOrder var10 = var4.getColumnRenderingOrder();
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addAnnotation(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.PaintList var2 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var5 = var3.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var3.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var8 = var3.getTickLabelInsets();
    boolean var9 = var2.equals((java.lang.Object)var3);
    java.awt.Font var11 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedRangeAxisSpace();
    java.awt.Paint var16 = var12.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var11, var16);
    org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
    var0.setHorizontalAlignment(var18);
    org.jfree.chart.util.RectangleEdge var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("[size=0.05]", var1, var2);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    java.lang.Boolean var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-16777216), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 18);
// 
//   }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     java.awt.Paint[] var4 = new java.awt.Paint[] { var3};
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var9 = var5.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var10 = null;
//     var5.setDrawingSupplier(var10);
//     java.awt.Image var12 = null;
//     var5.setBackgroundImage(var12);
//     var5.setBackgroundImageAlpha(1.0f);
//     org.jfree.data.general.DatasetGroup var16 = var5.getDatasetGroup();
//     org.jfree.chart.axis.AxisSpace var17 = var5.getFixedDomainAxisSpace();
//     org.jfree.chart.util.RectangleInsets var18 = var5.getAxisOffset();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearDomainMarkers(0);
//     java.awt.Paint var22 = var19.getOutlinePaint();
//     var5.setRangeGridlinePaint(var22);
//     java.awt.Paint[] var24 = new java.awt.Paint[] { var22};
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var33 = var31.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var39 = var35.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var40 = null;
//     var35.setDrawingSupplier(var40);
//     org.jfree.chart.axis.CategoryAxis var42 = var35.getDomainAxis();
//     java.util.List var43 = var35.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     var31.drawRangeMarker(var34, var35, (org.jfree.chart.axis.ValueAxis)var45, var46, var47);
//     var31.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var51 = var31.getBaseStroke();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var55 = var52.getFixedRangeAxisSpace();
//     java.awt.Paint var56 = var52.getDomainGridlinePaint();
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "hi!", "", "", var30, var51, var56);
//     java.awt.Paint[] var58 = new java.awt.Paint[] { var56};
//     org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var61 = var59.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var62 = var59.getTickMarkStroke();
//     java.awt.Stroke[] var63 = new java.awt.Stroke[] { var62};
//     java.awt.Stroke[] var64 = null;
//     java.awt.Shape[] var65 = null;
//     org.jfree.chart.plot.DefaultDrawingSupplier var66 = new org.jfree.chart.plot.DefaultDrawingSupplier(var4, var24, var58, var63, var64, var65);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var0 and var52
//     assertTrue("Contract failed: equals-hashcode on var0 and var52", var0.equals(var52) ? var0.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var52
//     assertTrue("Contract failed: equals-hashcode on var19 and var52", var19.equals(var52) ? var19.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var0
//     assertTrue("Contract failed: equals-hashcode on var52 and var0", var52.equals(var0) ? var52.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var19
//     assertTrue("Contract failed: equals-hashcode on var52 and var19", var52.equals(var19) ? var52.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var3 = null;
    var0.setGradientPaintTransformer(var3);
    java.awt.Paint var6 = null;
    var0.setSeriesItemLabelPaint(100, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.HorizontalAlignment var3 = var0.getHorizontalAlignment();
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, 0.0d, 0.05d);
//     org.jfree.chart.block.BlockContainer var8 = new org.jfree.chart.block.BlockContainer();
//     java.util.List var9 = var8.getBlocks();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.block.RectangleConstraint var11 = null;
//     org.jfree.chart.util.Size2D var12 = var7.arrange(var8, var10, var11);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 10);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.05d, 10.0d);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     double var7 = var6.getUpperMargin();
//     java.awt.Font var9 = var6.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("", var9, var10);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     double var13 = var12.getUpperMargin();
//     java.awt.Font var15 = var12.getTickLabelFont((java.lang.Comparable)10.0d);
//     var11.setFont(var15);
//     var11.setWidth(0.0d);
//     java.lang.Object var19 = null;
//     var4.add((org.jfree.chart.block.Block)var11, var19);
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
//     var22.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var25 = new org.jfree.chart.block.BlockContainer();
//     boolean var26 = var22.equals((java.lang.Object)var25);
//     java.util.List var27 = var25.getBlocks();
//     java.awt.geom.Rectangle2D var28 = var25.getBounds();
//     var11.draw(var21, var28);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.CategoryMarker var5 = null;
    org.jfree.chart.util.Layer var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     java.awt.Paint var9 = var6.getOutlinePaint();
//     boolean var10 = var6.isSubplot();
//     var2.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var6);
//     java.awt.Font var12 = var2.getLabelFont();
//     org.jfree.chart.text.TextLine var13 = new org.jfree.chart.text.TextLine("hi!", var12);
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var29 = var27.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var30 = var27.getTickMarkStroke();
//     java.awt.Color var32 = java.awt.Color.decode("18");
//     float[] var33 = null;
//     float[] var34 = var32.getRGBColorComponents(var33);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var26, var30, (java.awt.Paint)var32);
//     java.lang.String var36 = var35.getToolTipText();
//     org.jfree.chart.text.TextBlock var41 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var42 = null;
//     org.jfree.chart.text.TextBlockAnchor var45 = null;
//     java.awt.Shape var49 = var41.calculateBounds(var42, 0.0f, 100.0f, var45, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var52 = var50.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var53 = var50.getTickMarkStroke();
//     java.awt.Color var55 = java.awt.Color.decode("18");
//     float[] var56 = null;
//     float[] var57 = var55.getRGBColorComponents(var56);
//     org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var49, var53, (java.awt.Paint)var55);
//     boolean var59 = var35.equals((java.lang.Object)var55);
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.text.G2TextMeasurer var62 = new org.jfree.chart.text.G2TextMeasurer(var61);
//     org.jfree.chart.text.TextBlock var63 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var12, (java.awt.Paint)var55, 0.0f, (org.jfree.chart.text.TextMeasurer)var62);
// 
//   }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.Range var1 = null;
    org.jfree.chart.block.LengthConstraintType var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var8 = var7.getWidthConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(0.05d, var1, var2, 0.05d, var4, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var0.getCategoryLabelPositions();
//     org.jfree.chart.axis.NumberTickUnit var6 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     java.lang.String var8 = var6.valueToString(18.0d);
//     double var9 = var6.getSize();
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearDomainMarkers(0);
//     java.awt.Paint var13 = var10.getOutlinePaint();
//     java.awt.Paint var14 = var10.getNoDataMessagePaint();
//     var0.setTickLabelPaint((java.lang.Comparable)var9, var14);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.chart.axis.AxisState var17 = new org.jfree.chart.axis.AxisState();
//     double var18 = var17.getMax();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot();
//     var19.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var22 = new org.jfree.chart.block.BlockContainer();
//     boolean var23 = var19.equals((java.lang.Object)var22);
//     java.util.List var24 = var22.getBlocks();
//     java.awt.geom.Rectangle2D var25 = var22.getBounds();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     java.awt.Paint var29 = var26.getOutlinePaint();
//     boolean var30 = var26.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     int var32 = var26.getDomainAxisIndex(var31);
//     org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var35 = var26.getDomainAxisEdge();
//     java.util.List var36 = var0.refreshTicks(var16, var17, var25, var35);
//     
//     // Checks the contract:  equals-hashcode on var10 and var19
//     assertTrue("Contract failed: equals-hashcode on var10 and var19", var10.equals(var19) ? var10.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var26
//     assertTrue("Contract failed: equals-hashcode on var10 and var26", var10.equals(var26) ? var10.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var10
//     assertTrue("Contract failed: equals-hashcode on var19 and var10", var19.equals(var10) ? var19.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var26
//     assertTrue("Contract failed: equals-hashcode on var19 and var26", var19.equals(var26) ? var19.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var10
//     assertTrue("Contract failed: equals-hashcode on var26 and var10", var26.equals(var10) ? var26.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var19
//     assertTrue("Contract failed: equals-hashcode on var26 and var19", var26.equals(var19) ? var26.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.PaintList var2 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var5 = var3.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var3.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var8 = var3.getTickLabelInsets();
//     boolean var9 = var2.equals((java.lang.Object)var3);
//     java.awt.Font var11 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var15 = var12.getFixedRangeAxisSpace();
//     java.awt.Paint var16 = var12.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var11, var16);
//     org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
//     var0.setHorizontalAlignment(var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
//     var21.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var24 = new org.jfree.chart.block.BlockContainer();
//     boolean var25 = var21.equals((java.lang.Object)var24);
//     java.util.List var26 = var24.getBlocks();
//     java.awt.geom.Rectangle2D var27 = var24.getBounds();
//     java.lang.Object var29 = var0.draw(var20, var27, (java.lang.Object)'a');
//     
//     // Checks the contract:  equals-hashcode on var12 and var21
//     assertTrue("Contract failed: equals-hashcode on var12 and var21", var12.equals(var21) ? var12.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var12
//     assertTrue("Contract failed: equals-hashcode on var21 and var12", var21.equals(var12) ? var21.hashCode() == var12.hashCode() : true);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var2 = org.jfree.data.Range.combine(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var9 = var6.getFixedRangeAxisSpace();
    java.awt.Paint var10 = var6.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var11 = null;
    var6.setRangeAxis(var11);
    var6.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var18 = var15.getTickMarkStroke();
    var6.setDomainGridlineStroke(var18);
    var0.setRangeCrosshairStroke(var18);
    org.jfree.chart.event.PlotChangeListener var21 = null;
    var0.removeChangeListener(var21);
    var0.mapDatasetToRangeAxis(10, 100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    var0.clearCategoryLabelToolTips();
    java.lang.Comparable var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var6 = var0.getTickLabelPaint(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.awt.Paint[] var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getUpperMargin();
//     java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var5 = var1.isTickMarksVisible();
//     java.awt.Paint var6 = var1.getAxisLinePaint();
//     java.awt.Paint[] var7 = new java.awt.Paint[] { var6};
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var9 = var8.getFont();
//     java.lang.Object var10 = var8.clone();
//     org.jfree.chart.util.HorizontalAlignment var11 = var8.getHorizontalAlignment();
//     java.awt.Paint var12 = var8.getPaint();
//     java.awt.Paint[] var13 = new java.awt.Paint[] { var12};
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var17 = var14.getFixedRangeAxisSpace();
//     java.awt.Paint var18 = var14.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     var14.setRangeAxis(var19);
//     var14.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var25 = var23.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var26 = var23.getTickMarkStroke();
//     var14.setDomainGridlineStroke(var26);
//     java.awt.Stroke[] var28 = new java.awt.Stroke[] { var26};
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot();
//     var29.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var32 = var29.getFixedRangeAxisSpace();
//     java.awt.Paint var33 = var29.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     var29.setRangeAxis(var34);
//     var29.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var40 = var38.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var41 = var38.getTickMarkStroke();
//     var29.setDomainGridlineStroke(var41);
//     java.awt.Stroke[] var43 = new java.awt.Stroke[] { var41};
//     java.awt.Shape[] var44 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
//     org.jfree.chart.plot.DefaultDrawingSupplier var45 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var7, var13, var28, var43, var44);
//     
//     // Checks the contract:  equals-hashcode on var14 and var29
//     assertTrue("Contract failed: equals-hashcode on var14 and var29", var14.equals(var29) ? var14.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var14
//     assertTrue("Contract failed: equals-hashcode on var29 and var14", var29.equals(var14) ? var29.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(0.05d, var1, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 0.05d, true);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("java.awt.Color[r=0,g=0,b=18]", 1, 1);
// 
//   }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = null;
//     var0.setDrawingSupplier(var5);
//     java.awt.Image var7 = null;
//     var0.setBackgroundImage(var7);
//     var0.setBackgroundImageAlpha(1.0f);
//     float var11 = var0.getForegroundAlpha();
//     org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.text.TextBlockAnchor var18 = null;
//     java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 100.0f, var18, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, var22, "HorizontalAlignment.CENTER", "hi!");
//     var13.setRange(0.05d, 0.05d);
//     var13.setRangeAboutValue(0.0d, 18.0d);
//     var13.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var39 = var35.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var40 = null;
//     var35.setDrawingSupplier(var40);
//     var13.addChangeListener((org.jfree.chart.event.AxisChangeListener)var35);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
//     float var44 = var43.getBackgroundImageAlpha();
//     org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var43);
//     org.jfree.chart.event.TitleChangeEvent var46 = null;
//     var43.titleChanged(var46);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=18]", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var1.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
//     boolean var7 = var0.equals((java.lang.Object)var1);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var13 = var9.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var9.setDrawingSupplier(var14);
//     org.jfree.chart.axis.CategoryAxis var16 = var9.getDomainAxis();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var18.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     java.awt.Paint var29 = var26.getOutlinePaint();
//     boolean var30 = var26.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     int var32 = var26.getDomainAxisIndex(var31);
//     org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var35 = var26.getDomainAxisEdge();
//     double var36 = var18.valueToJava2D(10.0d, var25, var35);
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     org.jfree.chart.axis.AxisSpace var39 = var1.reserveSpace(var8, (org.jfree.chart.plot.Plot)var9, var25, var37, var38);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var4.setDrawingSupplier(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     double var21 = var20.getUpperMargin();
//     java.awt.Font var23 = var20.getTickLabelFont((java.lang.Comparable)10.0d);
//     var20.clearCategoryLabelToolTips();
//     java.lang.Object var25 = var20.clone();
//     var20.setLabelURL("AxisLabelEntity: label = hi!");
//     org.jfree.chart.plot.CategoryMarker var28 = null;
//     org.jfree.chart.ChartRenderingInfo var29 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var30 = new org.jfree.chart.plot.PlotRenderingInfo(var29);
//     java.awt.geom.Rectangle2D var31 = var30.getDataArea();
//     var0.drawDomainMarker(var18, var19, var20, var28, var31);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("java.awt.Color[r=0,g=0,b=18]");

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var20 = var0.getBaseStroke();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var0.getSeriesToolTipGenerator((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
//     double var4 = var3.getUpperMargin();
//     java.awt.Font var6 = var3.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var7 = null;
//     org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("", var6, var7);
//     var1.setBaseItemLabelFont(var6, true);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     double var12 = var11.getUpperMargin();
//     java.awt.Font var14 = var11.getTickLabelFont((java.lang.Comparable)(short)10);
//     var1.setBaseItemLabelFont(var14);
//     org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.TextBlockAnchor var24 = null;
//     java.awt.Shape var28 = var20.calculateBounds(var21, 0.0f, 100.0f, var24, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var31 = var29.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var32 = var29.getTickMarkStroke();
//     java.awt.Color var34 = java.awt.Color.decode("18");
//     float[] var35 = null;
//     float[] var36 = var34.getRGBColorComponents(var35);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var28, var32, (java.awt.Paint)var34);
//     int var38 = var34.getTransparency();
//     org.jfree.chart.text.TextLine var39 = new org.jfree.chart.text.TextLine("", var14, (java.awt.Paint)var34);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis();
//     double var43 = var42.getUpperMargin();
//     java.awt.Font var45 = var42.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var46 = null;
//     org.jfree.chart.block.LabelBlock var47 = new org.jfree.chart.block.LabelBlock("", var45, var46);
//     org.jfree.chart.text.TextFragment var48 = new org.jfree.chart.text.TextFragment("", var45);
//     var39.removeFragment(var48);
//     
//     // Checks the contract:  equals-hashcode on var8 and var47
//     assertTrue("Contract failed: equals-hashcode on var8 and var47", var8.equals(var47) ? var8.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var8
//     assertTrue("Contract failed: equals-hashcode on var47 and var8", var47.equals(var8) ? var47.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit(6.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var6 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
//     var0.setBaseItemLabelFont(var5, true);
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     double var11 = var10.getUpperMargin();
//     java.awt.Font var13 = var10.getTickLabelFont((java.lang.Comparable)(short)10);
//     var0.setBaseItemLabelFont(var13);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var18 = var15.getFixedRangeAxisSpace();
//     java.awt.Paint var19 = var15.getDomainGridlinePaint();
//     var0.setBasePaint(var19);
//     org.jfree.chart.labels.CategoryToolTipGenerator var22 = var0.getSeriesToolTipGenerator(0);
//     org.jfree.chart.util.PaintList var24 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var27 = var25.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var25.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var30 = var25.getTickLabelInsets();
//     boolean var31 = var24.equals((java.lang.Object)var25);
//     java.awt.Font var33 = var25.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var37 = var34.getFixedRangeAxisSpace();
//     java.awt.Paint var38 = var34.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var33, var38);
//     var0.setBaseFillPaint(var38);
//     
//     // Checks the contract:  equals-hashcode on var15 and var34
//     assertTrue("Contract failed: equals-hashcode on var15 and var34", var15.equals(var34) ? var15.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var15
//     assertTrue("Contract failed: equals-hashcode on var34 and var15", var34.equals(var15) ? var34.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var2 = null;
    org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextBlockAnchor var11 = null;
    java.awt.Shape var15 = var7.calculateBounds(var8, 0.0f, 100.0f, var11, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var18 = var16.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var19 = var16.getTickMarkStroke();
    java.awt.Color var21 = java.awt.Color.decode("18");
    float[] var22 = null;
    float[] var23 = var21.getRGBColorComponents(var22);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var15, var19, (java.awt.Paint)var21);
    java.awt.image.ColorModel var25 = null;
    java.awt.Rectangle var26 = null;
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
    boolean var31 = var27.equals((java.lang.Object)var30);
    java.util.List var32 = var30.getBlocks();
    java.awt.geom.Rectangle2D var33 = var30.getBounds();
    java.awt.geom.AffineTransform var34 = null;
    java.awt.RenderingHints var35 = null;
    java.awt.PaintContext var36 = var21.createContext(var25, var26, var33, var34, var35);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.clearDomainMarkers(0);
    java.awt.Paint var40 = var37.getOutlinePaint();
    boolean var41 = var37.isSubplot();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot();
    var42.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var45 = var42.getFixedRangeAxisSpace();
    java.awt.Paint var46 = var42.getDomainGridlinePaint();
    var37.setNoDataMessagePaint(var46);
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
    double var49 = var48.getUpperMargin();
    java.awt.Font var51 = var48.getTickLabelFont((java.lang.Comparable)(short)10);
    var48.setUpperMargin(100.0d);
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var57 = var55.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var55.setLowerMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis();
    double var61 = var60.getUpperMargin();
    java.awt.Font var63 = var60.getTickLabelFont((java.lang.Comparable)10.0d);
    var55.setTickLabelFont(var63);
    var48.setTickLabelFont((java.lang.Comparable)4.0d, var63);
    org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
    var67.setAutoRangeIncludesZero(false);
    var67.setAutoTickUnitSelection(true, false);
    org.jfree.data.category.CategoryDataset var73 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var2, (java.awt.geom.Rectangle2D)var26, var37, var48, (org.jfree.chart.axis.ValueAxis)var67, var73, 18, (-16777216), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.text.TextBlockAnchor var10 = null;
//     java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var18 = var15.getTickMarkStroke();
//     java.awt.Color var20 = java.awt.Color.decode("18");
//     float[] var21 = null;
//     float[] var22 = var20.getRGBColorComponents(var21);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
//     java.awt.image.ColorModel var24 = null;
//     java.awt.Rectangle var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
//     boolean var30 = var26.equals((java.lang.Object)var29);
//     java.util.List var31 = var29.getBlocks();
//     java.awt.geom.Rectangle2D var32 = var29.getBounds();
//     java.awt.geom.AffineTransform var33 = null;
//     java.awt.RenderingHints var34 = null;
//     java.awt.PaintContext var35 = var20.createContext(var24, var25, var32, var33, var34);
//     var0.draw(var1, (java.awt.geom.Rectangle2D)var25);
// 
//   }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 100.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 18.0d};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
    java.util.List var2 = var1.getColumnKeys();
    org.jfree.data.KeyedObject var3 = new org.jfree.data.KeyedObject(var0, (java.lang.Object)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    double var6 = var5.getUpperMargin();
    java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var9 = null;
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
    java.awt.Font var12 = var11.getFont();
    var0.setFont(var12);
    org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
    java.lang.String var15 = var14.toString();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.text.TextBlockAnchor var22 = null;
    java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
    var17.setRange(0.05d, 0.05d);
    var17.setRangeAboutValue(0.0d, 18.0d);
    var17.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    var39.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var44 = null;
    var39.setDrawingSupplier(var44);
    var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
    boolean var47 = var14.equals((java.lang.Object)var17);
    java.awt.Shape var48 = var17.getRightArrow();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setRange(6.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "VerticalAlignment.CENTER"+ "'", var15.equals("VerticalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo();
    var5.setLicenceName("");
    var5.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var10 = var5.getLibraries();
    var4.addLibrary((org.jfree.chart.ui.Library)var5);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getTextAlignment();
    boolean var14 = var4.equals((java.lang.Object)var12);
    var4.setLicenceName("AxisLocation.TOP_OR_LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     var1.setRange(0.05d, 0.05d);
//     var1.setRangeAboutValue(0.0d, 18.0d);
//     var1.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var28 = null;
//     var23.setDrawingSupplier(var28);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     float var32 = var31.getBackgroundImageAlpha();
//     java.util.List var33 = var31.getSubtitles();
//     org.jfree.chart.event.ChartProgressListener var34 = null;
//     var31.removeProgressListener(var34);
//     org.jfree.chart.ChartRenderingInfo var38 = null;
//     var31.handleClick(0, 1, var38);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var2 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    var0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var2);
    boolean var4 = var0.getBaseCreateEntities();
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var0.setSeriesURLGenerator(18, var6);
    org.jfree.chart.labels.ItemLabelPosition var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBasePositiveItemLabelPosition(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    double var4 = var3.getUpperMargin();
    java.awt.Font var6 = var3.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearDomainMarkers(0);
    java.awt.Paint var10 = var7.getOutlinePaint();
    boolean var11 = var7.isSubplot();
    var3.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    java.awt.Font var13 = var3.getLabelFont();
    org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("hi!", var13);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var19 = var17.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var17.setLowerMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    double var23 = var22.getUpperMargin();
    java.awt.Font var25 = var22.getTickLabelFont((java.lang.Comparable)10.0d);
    var17.setTickLabelFont(var25);
    org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("", var25);
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_RIGHT", var25);
    var14.removeFragment(var28);
    var0.set(18, (java.lang.Object)var14);
    java.lang.Object var32 = var0.get((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("AxisLocation.BOTTOM_OR_RIGHT", 1, 100);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 0.0f);
// 
//   }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    var31.fireChartChanged();
    org.jfree.chart.event.ChartChangeListener var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.removeChangeListener(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    var0.add((org.jfree.chart.axis.TickUnit)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var7 = var0.get(18);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    org.jfree.data.Range var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("hi!", 0, 10);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "java.awt.Color[r=0,g=0,b=18]", var3);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var4.setDrawingSupplier(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var21 = var19.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var22 = null;
//     var19.notifyListeners(var22);
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var19.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var19.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var28 = var27.getRotationAnchor();
//     var0.setSeriesNegativeItemLabelPosition(1, var27, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var19 and var0.", var19.equals(var0) == var0.equals(var19));
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    java.awt.Paint var8 = var5.getOutlinePaint();
    boolean var9 = var5.isSubplot();
    org.jfree.chart.axis.CategoryAxis var10 = null;
    int var11 = var5.getDomainAxisIndex(var10);
    var0.setPlot(var5);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var18 = new org.jfree.chart.block.BlockContainer();
    boolean var19 = var15.equals((java.lang.Object)var18);
    java.util.List var20 = var18.getBlocks();
    java.awt.geom.Rectangle2D var21 = var18.getBounds();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    var22.clearDomainMarkers(0);
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var27 = var25.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var25.setLowerMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
    double var31 = var30.getUpperMargin();
    java.awt.Font var33 = var30.getTickLabelFont((java.lang.Comparable)10.0d);
    var25.setTickLabelFont(var33);
    org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
    var36.setAutoRangeIncludesZero(false);
    var36.setAutoTickUnitSelection(true, false);
    java.text.NumberFormat var42 = null;
    var36.setNumberFormatOverride(var42);
    var36.setAutoTickUnitSelection(false, true);
    org.jfree.data.category.CategoryDataset var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var13, var14, var21, var22, var25, (org.jfree.chart.axis.ValueAxis)var36, var47, (-16777216), 10, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    org.jfree.data.xy.XYDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var3.notifyListeners(var6);
//     org.jfree.chart.urls.CategoryURLGenerator var8 = var3.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var11 = var3.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var15 = var13.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var16 = null;
//     var13.notifyListeners(var16);
//     org.jfree.chart.urls.CategoryURLGenerator var18 = var13.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var21 = var13.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var22 = var21.getRotationAnchor();
//     org.jfree.chart.axis.NumberTick var24 = new org.jfree.chart.axis.NumberTick(var0, 6.0d, "", var12, var22, 1.0d);
//     
//     // Checks the contract:  equals-hashcode on var11 and var21
//     assertTrue("Contract failed: equals-hashcode on var11 and var21", var11.equals(var21) ? var11.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var11
//     assertTrue("Contract failed: equals-hashcode on var21 and var11", var21.equals(var11) ? var21.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var4 = var0.getCategoryLabelPositions();
//     org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.text.TextBlockAnchor var15 = null;
//     java.awt.Shape var19 = var11.calculateBounds(var12, 0.0f, 100.0f, var15, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var22 = var20.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var23 = var20.getTickMarkStroke();
//     java.awt.Color var25 = java.awt.Color.decode("18");
//     float[] var26 = null;
//     float[] var27 = var25.getRGBColorComponents(var26);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var19, var23, (java.awt.Paint)var25);
//     java.awt.image.ColorModel var29 = null;
//     java.awt.Rectangle var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var34 = new org.jfree.chart.block.BlockContainer();
//     boolean var35 = var31.equals((java.lang.Object)var34);
//     java.util.List var36 = var34.getBlocks();
//     java.awt.geom.Rectangle2D var37 = var34.getBounds();
//     java.awt.geom.AffineTransform var38 = null;
//     java.awt.RenderingHints var39 = null;
//     java.awt.PaintContext var40 = var25.createContext(var29, var30, var37, var38, var39);
//     org.jfree.chart.axis.CategoryLabelPositions var42 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot();
//     var43.clearDomainMarkers(0);
//     java.awt.Paint var46 = var43.getOutlinePaint();
//     boolean var47 = var43.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     int var49 = var43.getDomainAxisIndex(var48);
//     org.jfree.chart.axis.AxisLocation var51 = var43.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var52 = var43.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var53 = var42.getLabelPosition(var52);
//     double var54 = var0.getCategoryMiddle(4, 4, (java.awt.geom.Rectangle2D)var30, var52);
// 
//   }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var4.setDrawingSupplier(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     var0.setMaximumBarWidth(0.0d);
//     java.awt.Graphics2D var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var26 = var23.getFixedRangeAxisSpace();
//     java.awt.Paint var27 = var23.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var32 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.text.TextBlockAnchor var36 = null;
//     java.awt.Shape var40 = var32.calculateBounds(var33, 0.0f, 100.0f, var36, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var43 = var41.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var44 = var41.getTickMarkStroke();
//     java.awt.Color var46 = java.awt.Color.decode("18");
//     float[] var47 = null;
//     float[] var48 = var46.getRGBColorComponents(var47);
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var40, var44, (java.awt.Paint)var46);
//     java.awt.image.ColorModel var50 = null;
//     java.awt.Rectangle var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var55 = new org.jfree.chart.block.BlockContainer();
//     boolean var56 = var52.equals((java.lang.Object)var55);
//     java.util.List var57 = var55.getBlocks();
//     java.awt.geom.Rectangle2D var58 = var55.getBounds();
//     java.awt.geom.AffineTransform var59 = null;
//     java.awt.RenderingHints var60 = null;
//     java.awt.PaintContext var61 = var46.createContext(var50, var51, var58, var59, var60);
//     var0.drawOutline(var22, var23, (java.awt.geom.Rectangle2D)var51);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }


    org.jfree.data.function.Function2D var0 = null;
    org.jfree.chart.axis.NumberTickUnit var5 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var6 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 1.0d, 100.0d, 4, (java.lang.Comparable)0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.labels.ItemLabelPosition var4 = var0.getSeriesNegativeItemLabelPosition((-1));
//     var0.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
//     var0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var8);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var10.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var13 = null;
//     var10.setGradientPaintTransformer(var13);
//     java.awt.Paint var16 = null;
//     var10.setSeriesFillPaint(10, var16, false);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var10.getSeriesNegativeItemLabelPosition(100);
//     var0.setNegativeItemLabelPositionFallback(var20);
//     
//     // Checks the contract:  equals-hashcode on var4 and var20
//     assertTrue("Contract failed: equals-hashcode on var4 and var20", var4.equals(var20) ? var4.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var4
//     assertTrue("Contract failed: equals-hashcode on var20 and var4", var20.equals(var4) ? var20.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(1);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var10 = var7.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var12 = var7.getRangeAxisLocation((-16777216));
    var0.setDomainAxisLocation(var12);
    org.jfree.chart.plot.PlotOrientation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var15 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var12, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var4.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var4.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var4.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var13 = var12.getRotationAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("18", var1, 1.0f, 100.0f, var13, 4.0d, 10.0f, (-1.0f));
// 
//   }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, (-1.0d), 4.0d);
//     java.awt.Paint var5 = var4.getPaint();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
//     var7.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer();
//     boolean var11 = var7.equals((java.lang.Object)var10);
//     java.util.List var12 = var10.getBlocks();
//     java.awt.geom.Rectangle2D var13 = var10.getBounds();
//     var4.draw(var6, var13);
// 
//   }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(4.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 0.05d, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.text.TextLine var0 = new org.jfree.chart.text.TextLine();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    var2.setHeight(18.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
    org.jfree.data.Range var4 = null;
    org.jfree.data.Range var6 = org.jfree.data.Range.expandToInclude(var4, 2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.RectangleConstraint var7 = var2.toRangeWidth(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    float var18 = var14.getTickMarkInsideLength();
    var14.setAutoRangeIncludesZero(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setRangeWithMargins(100.0d, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getDomainGridlinePaint();
    org.jfree.chart.annotations.CategoryAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.text.TextBlock var4 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.text.TextBlockAnchor var8 = null;
    java.awt.Shape var12 = var4.calculateBounds(var5, 0.0f, 100.0f, var8, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var15 = var13.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var16 = var13.getTickMarkStroke();
    java.awt.Color var18 = java.awt.Color.decode("18");
    float[] var19 = null;
    float[] var20 = var18.getRGBColorComponents(var19);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var12, var16, (java.awt.Paint)var18);
    java.lang.Comparable var22 = var21.getSeriesKey();
    var21.setSeriesIndex(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
//     java.awt.Paint var9 = var5.getDomainGridlinePaint();
//     var0.setNoDataMessagePaint(var9);
//     org.jfree.chart.event.PlotChangeEvent var11 = null;
//     var0.notifyListeners(var11);
//     org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
//     var14.clearDomainMarkers(0);
//     java.awt.Paint var17 = var14.getOutlinePaint();
//     boolean var18 = var14.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var19 = null;
//     int var20 = var14.getDomainAxisIndex(var19);
//     org.jfree.chart.axis.AxisLocation var21 = var14.getRangeAxisLocation();
//     var0.setDomainAxisLocation(0, var21);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var5
//     assertTrue("Contract failed: equals-hashcode on var14 and var5", var14.equals(var5) ? var14.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    boolean var4 = var0.equals((java.lang.Object)var3);
    java.util.List var5 = var3.getBlocks();
    java.awt.geom.Rectangle2D var6 = var3.getBounds();
    java.lang.Object var7 = var3.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getBaseToolTipGenerator();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var10);
    org.jfree.chart.labels.ItemLabelPosition var12 = var0.getNegativeItemLabelPositionFallback();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var16 = var14.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var17 = null;
    var14.notifyListeners(var17);
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
    var14.setBaseToolTipGenerator(var19, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var25 = null;
    var22.setGradientPaintTransformer(var25);
    java.awt.Shape var28 = var22.lookupSeriesShape((-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var31 = var29.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
    var33.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var37 = var33.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var38 = null;
    var33.setDrawingSupplier(var38);
    org.jfree.chart.axis.CategoryAxis var40 = var33.getDomainAxis();
    java.util.List var41 = var33.getAnnotations();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var44 = null;
    java.awt.geom.Rectangle2D var45 = null;
    var29.drawRangeMarker(var32, var33, (org.jfree.chart.axis.ValueAxis)var43, var44, var45);
    var29.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var49 = var29.getBaseStroke();
    var22.setErrorIndicatorStroke(var49);
    var14.setErrorIndicatorStroke(var49);
    var0.setSeriesOutlineStroke(100, var49, true);
    var0.setSeriesItemLabelsVisible(18, (java.lang.Boolean)true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.ValueMarker var2 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var7 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.text.TextBlockAnchor var11 = null;
    java.awt.Shape var15 = var7.calculateBounds(var8, 0.0f, 100.0f, var11, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var18 = var16.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var19 = var16.getTickMarkStroke();
    java.awt.Color var21 = java.awt.Color.decode("18");
    float[] var22 = null;
    float[] var23 = var21.getRGBColorComponents(var22);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var15, var19, (java.awt.Paint)var21);
    java.lang.String var25 = var21.toString();
    var2.setPaint((java.awt.Paint)var21);
    java.awt.Color var27 = java.awt.Color.getColor("java.awt.Color[r=0,g=0,b=18]", var21);
    float[] var30 = new float[] { 0.0f, 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var31 = var21.getRGBComponents(var30);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var25 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var25.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getSeriesItemLabelGenerator((-1));
//     var0.setBaseSeriesVisible(true, false);
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var29 = var27.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var30 = var27.getTickMarkStroke();
//     java.awt.Color var32 = java.awt.Color.decode("18");
//     float[] var33 = null;
//     float[] var34 = var32.getRGBColorComponents(var33);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var26, var30, (java.awt.Paint)var32);
//     java.awt.Color var38 = java.awt.Color.decode("18");
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     var40.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var43 = var40.getFixedRangeAxisSpace();
//     java.awt.Paint var44 = var40.getDomainGridlinePaint();
//     org.jfree.chart.plot.CategoryPlot var45 = new org.jfree.chart.plot.CategoryPlot();
//     var45.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var48 = var45.getFixedRangeAxisSpace();
//     java.awt.Paint var49 = var45.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     var45.setRangeAxis(var50);
//     var45.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var56 = var54.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var57 = var54.getTickMarkStroke();
//     var45.setDomainGridlineStroke(var57);
//     org.jfree.chart.text.TextBlock var60 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.text.TextBlockAnchor var64 = null;
//     java.awt.Shape var68 = var60.calculateBounds(var61, 0.0f, 100.0f, var64, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var69 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var71 = var69.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var72 = null;
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     var73.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var77 = var73.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var78 = null;
//     var73.setDrawingSupplier(var78);
//     org.jfree.chart.axis.CategoryAxis var80 = var73.getDomainAxis();
//     java.util.List var81 = var73.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var83 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var84 = null;
//     java.awt.geom.Rectangle2D var85 = null;
//     var69.drawRangeMarker(var72, var73, (org.jfree.chart.axis.ValueAxis)var83, var84, var85);
//     var69.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var89 = var69.getBaseStroke();
//     org.jfree.chart.axis.CategoryAxis var90 = new org.jfree.chart.axis.CategoryAxis();
//     double var91 = var90.getUpperMargin();
//     java.awt.Font var93 = var90.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var94 = var90.isTickMarksVisible();
//     java.awt.Paint var95 = var90.getAxisLinePaint();
//     org.jfree.chart.LegendItem var96 = new org.jfree.chart.LegendItem("18", "18", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", false, var26, false, (java.awt.Paint)var38, false, var44, var57, false, var68, var89, var95);
//     var0.setSeriesStroke(10, var89, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var69 and var0.", var69.equals(var0) == var0.equals(var69));
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("HorizontalAlignment.CENTER", "AxisLocation.TOP_OR_LEFT", "AxisLabelEntity: label = hi!", "", "AxisLocation.BOTTOM_OR_RIGHT");

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    java.awt.Paint var7 = var4.getOutlinePaint();
    boolean var8 = var4.isSubplot();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    int var10 = var4.getDomainAxisIndex(var9);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var0);
    boolean var13 = var0.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var1.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var6 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
//     java.awt.geom.Rectangle2D var8 = var7.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(0);
//     java.awt.Paint var12 = var9.getOutlinePaint();
//     boolean var13 = var9.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     int var15 = var9.getDomainAxisIndex(var14);
//     org.jfree.chart.axis.AxisLocation var17 = var9.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var18 = var9.getDomainAxisEdge();
//     double var19 = var1.valueToJava2D(10.0d, var8, var18);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var21 = var20.getFont();
//     java.lang.Object var22 = var20.clone();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     double var26 = var25.getUpperMargin();
//     java.awt.Font var28 = var25.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var29 = null;
//     org.jfree.chart.block.LabelBlock var30 = new org.jfree.chart.block.LabelBlock("", var28, var29);
//     org.jfree.chart.text.TextFragment var31 = new org.jfree.chart.text.TextFragment("", var28);
//     java.awt.Font var32 = var31.getFont();
//     var20.setFont(var32);
//     org.jfree.chart.util.VerticalAlignment var34 = var20.getVerticalAlignment();
//     java.lang.String var35 = var34.toString();
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.text.TextBlockAnchor var42 = null;
//     java.awt.Shape var46 = var38.calculateBounds(var39, 0.0f, 100.0f, var42, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var37, var46, "HorizontalAlignment.CENTER", "hi!");
//     var37.setRange(0.05d, 0.05d);
//     var37.setRangeAboutValue(0.0d, 18.0d);
//     var37.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     var59.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var63 = var59.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var64 = null;
//     var59.setDrawingSupplier(var64);
//     var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var59);
//     boolean var67 = var34.equals((java.lang.Object)var37);
//     org.jfree.chart.axis.NumberAxis var69 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var69.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = new org.jfree.chart.plot.PlotRenderingInfo(var74);
//     java.awt.geom.Rectangle2D var76 = var75.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var77 = new org.jfree.chart.plot.CategoryPlot();
//     var77.clearDomainMarkers(0);
//     java.awt.Paint var80 = var77.getOutlinePaint();
//     boolean var81 = var77.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var82 = null;
//     int var83 = var77.getDomainAxisIndex(var82);
//     org.jfree.chart.axis.AxisLocation var85 = var77.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var86 = var77.getDomainAxisEdge();
//     double var87 = var69.valueToJava2D(10.0d, var76, var86);
//     org.jfree.data.Range var88 = var69.getRange();
//     var37.setRange(var88, true, true);
//     var1.setRange(var88, false, false);
//     
//     // Checks the contract:  equals-hashcode on var7 and var75
//     assertTrue("Contract failed: equals-hashcode on var7 and var75", var7.equals(var75) ? var7.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var7
//     assertTrue("Contract failed: equals-hashcode on var75 and var7", var75.equals(var7) ? var75.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var77
//     assertTrue("Contract failed: equals-hashcode on var9 and var77", var9.equals(var77) ? var9.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var9
//     assertTrue("Contract failed: equals-hashcode on var77 and var9", var77.equals(var9) ? var77.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var0.getColumnKey(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { 4.0d};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 10};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.axis.NumberAxis var5 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var17 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, var14, "HorizontalAlignment.CENTER", "hi!");
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    double var19 = var18.getUpperMargin();
    var18.setMaximumCategoryLabelLines(0);
    var18.removeCategoryLabelToolTip((java.lang.Comparable)(short)100);
    java.awt.Paint var24 = var18.getTickMarkPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem(var0, "[size=0.05]", "", "VerticalAlignment.CENTER", var14, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoRangeIncludesZero(false);
    var1.setAutoTickUnitSelection(true, false);
    java.text.NumberFormat var7 = null;
    var1.setNumberFormatOverride(var7);
    var1.setAutoTickUnitSelection(false, true);
    org.jfree.chart.axis.MarkerAxisBand var12 = null;
    var1.setMarkerBand(var12);

  }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var12 = var9.getFixedRangeAxisSpace();
    java.awt.Paint var13 = var9.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var14 = null;
    var9.setRangeAxis(var14);
    var9.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var20 = var18.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var21 = var18.getTickMarkStroke();
    var9.setDomainGridlineStroke(var21);
    var0.setSeriesOutlineStroke(100, var21);
    boolean var26 = var0.getItemCreateEntity(100, 0);
    java.awt.Paint var28 = var0.lookupSeriesFillPaint((-1));
    org.jfree.chart.labels.CategoryToolTipGenerator var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesToolTipGenerator((-16777216), var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoTickUnitSelection(true, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.awt.geom.Rectangle2D var8 = var7.getDataArea();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers(0);
    java.awt.Paint var12 = var9.getOutlinePaint();
    boolean var13 = var9.isSubplot();
    org.jfree.chart.axis.CategoryAxis var14 = null;
    int var15 = var9.getDomainAxisIndex(var14);
    org.jfree.chart.axis.AxisLocation var17 = var9.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var18 = var9.getDomainAxisEdge();
    double var19 = var1.valueToJava2D(10.0d, var8, var18);
    var1.setUpperMargin(0.05d);
    boolean var22 = var1.isVerticalTickLabels();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(var0, 100.0f);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    boolean var8 = var0.isDomainZoomable();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    java.awt.Shape var19 = var11.calculateBounds(var12, 0.0f, 100.0f, var15, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var10, var19, "HorizontalAlignment.CENTER", "hi!");
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var0.setRangeAxes(var23);
    org.jfree.chart.plot.ValueMarker var26 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var27 = null;
    var0.addRangeMarker((org.jfree.chart.plot.Marker)var26, var27);
    org.jfree.chart.util.LengthAdjustmentType var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var26.setLabelOffsetType(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getUpperMargin();
//     java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     java.awt.Paint var8 = var5.getOutlinePaint();
//     boolean var9 = var5.isSubplot();
//     var1.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var5);
//     java.awt.Font var11 = var1.getLabelFont();
//     org.jfree.chart.text.TextLine var12 = new org.jfree.chart.text.TextLine("hi!", var11);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var15.setLowerMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
//     double var21 = var20.getUpperMargin();
//     java.awt.Font var23 = var20.getTickLabelFont((java.lang.Comparable)10.0d);
//     var15.setTickLabelFont(var23);
//     org.jfree.chart.block.LabelBlock var25 = new org.jfree.chart.block.LabelBlock("", var23);
//     org.jfree.chart.text.TextFragment var26 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_RIGHT", var23);
//     var12.removeFragment(var26);
//     java.awt.Graphics2D var28 = null;
//     org.jfree.chart.labels.ItemLabelPosition var31 = new org.jfree.chart.labels.ItemLabelPosition();
//     java.lang.Object var32 = null;
//     boolean var33 = var31.equals(var32);
//     org.jfree.chart.text.TextAnchor var34 = var31.getTextAnchor();
//     var12.draw(var28, 0.5f, 100.0f, var34, 1.0f, 0.0f, 6.0d);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    java.awt.Paint var7 = var4.getOutlinePaint();
    boolean var8 = var4.isSubplot();
    org.jfree.chart.axis.CategoryAxis var9 = null;
    int var10 = var4.getDomainAxisIndex(var9);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var16 = var13.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var18 = var13.getRangeAxisLocation((-16777216));
    java.lang.String var19 = var18.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setDomainAxisLocation((-1), var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT"+ "'", var19.equals("AxisLocation.BOTTOM_OR_RIGHT"));

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var4 = var1.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var9 = var5.getCategoryLabelPositions();
//     org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     java.lang.String var13 = var11.valueToString(18.0d);
//     double var14 = var11.getSize();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearDomainMarkers(0);
//     java.awt.Paint var18 = var15.getOutlinePaint();
//     java.awt.Paint var19 = var15.getNoDataMessagePaint();
//     var5.setTickLabelPaint((java.lang.Comparable)var14, var19);
//     var1.setTickMarkPaint(var19);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var24 = var22.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var25 = null;
//     var22.setGradientPaintTransformer(var25);
//     java.awt.Shape var28 = var22.lookupSeriesShape((-16777216));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var29 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var31 = var29.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var37 = var33.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var38 = null;
//     var33.setDrawingSupplier(var38);
//     org.jfree.chart.axis.CategoryAxis var40 = var33.getDomainAxis();
//     java.util.List var41 = var33.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var44 = null;
//     java.awt.geom.Rectangle2D var45 = null;
//     var29.drawRangeMarker(var32, var33, (org.jfree.chart.axis.ValueAxis)var43, var44, var45);
//     var29.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var49 = var29.getBaseStroke();
//     var22.setErrorIndicatorStroke(var49);
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker(4.0d, var19, var49);
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var58 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var60 = var58.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     var62.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var66 = var62.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var67 = null;
//     var62.setDrawingSupplier(var67);
//     org.jfree.chart.axis.CategoryAxis var69 = var62.getDomainAxis();
//     java.util.List var70 = var62.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var72 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var73 = null;
//     java.awt.geom.Rectangle2D var74 = null;
//     var58.drawRangeMarker(var61, var62, (org.jfree.chart.axis.ValueAxis)var72, var73, var74);
//     var58.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var78 = var58.getBaseStroke();
//     org.jfree.chart.plot.CategoryPlot var79 = new org.jfree.chart.plot.CategoryPlot();
//     var79.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var82 = var79.getFixedRangeAxisSpace();
//     java.awt.Paint var83 = var79.getDomainGridlinePaint();
//     org.jfree.chart.LegendItem var84 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "hi!", "", "", var57, var78, var83);
//     var51.setPaint(var83);
//     
//     // Checks the contract:  equals-hashcode on var15 and var79
//     assertTrue("Contract failed: equals-hashcode on var15 and var79", var15.equals(var79) ? var15.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var15
//     assertTrue("Contract failed: equals-hashcode on var79 and var15", var79.equals(var15) ? var79.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     var1.setRange(0.05d, 0.05d);
//     var1.setRangeAboutValue(0.0d, 18.0d);
//     var1.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var28 = null;
//     var23.setDrawingSupplier(var28);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     var31.setBackgroundImageAlignment((-16777216));
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.util.HorizontalAlignment var35 = null;
//     org.jfree.chart.util.VerticalAlignment var36 = null;
//     org.jfree.chart.block.FlowArrangement var39 = new org.jfree.chart.block.FlowArrangement(var35, var36, 0.05d, 10.0d);
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     double var42 = var41.getUpperMargin();
//     java.awt.Font var44 = var41.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var45 = null;
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("", var44, var45);
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
//     double var48 = var47.getUpperMargin();
//     java.awt.Font var50 = var47.getTickLabelFont((java.lang.Comparable)10.0d);
//     var46.setFont(var50);
//     var46.setWidth(0.0d);
//     java.lang.Object var54 = null;
//     var39.add((org.jfree.chart.block.Block)var46, var54);
//     org.jfree.chart.util.RectangleInsets var56 = var46.getPadding();
//     var46.setToolTipText("");
//     org.jfree.chart.axis.NumberAxis var60 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var60.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = new org.jfree.chart.plot.PlotRenderingInfo(var65);
//     java.awt.geom.Rectangle2D var67 = var66.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     var68.clearDomainMarkers(0);
//     java.awt.Paint var71 = var68.getOutlinePaint();
//     boolean var72 = var68.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var73 = null;
//     int var74 = var68.getDomainAxisIndex(var73);
//     org.jfree.chart.axis.AxisLocation var76 = var68.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var77 = var68.getDomainAxisEdge();
//     double var78 = var60.valueToJava2D(10.0d, var67, var77);
//     var46.setBounds(var67);
//     java.awt.geom.Point2D var80 = null;
//     org.jfree.chart.ChartRenderingInfo var81 = null;
//     var31.draw(var34, var67, var80, var81);
// 
//   }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearDomainMarkers(0);
//     java.awt.Paint var6 = var3.getOutlinePaint();
//     boolean var7 = var3.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var8 = null;
//     int var9 = var3.getDomainAxisIndex(var8);
//     org.jfree.chart.axis.AxisLocation var11 = var3.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var12 = var3.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var13 = var2.getLabelPosition(var12);
//     java.lang.Object var14 = null;
//     boolean var15 = var12.equals(var14);
//     double var16 = org.jfree.chart.util.RectangleEdge.coordinate(var0, var12);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
    java.awt.Paint var9 = var5.getDomainGridlinePaint();
    var0.setNoDataMessagePaint(var9);
    org.jfree.chart.event.PlotChangeEvent var11 = null;
    var0.notifyListeners(var11);
    org.jfree.chart.plot.CategoryMarker var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    double var4 = var0.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    java.lang.String var3 = var0.getID();
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    var4.setWeight((-1));
    java.awt.Paint var11 = var4.getRangeGridlinePaint();
    var0.setBackgroundPaint(var11);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.block.RectangleConstraint var16 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var17 = var0.arrange(var13, var16);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("java.awt.Color[r=0,g=0,b=18]", var1, (-1.0f), 0.0f, var4);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var4.setDrawingSupplier(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     var0.setIncludeBaseInRange(true);
//     org.jfree.chart.LegendItem var24 = var0.getLegendItem(0, 10);
//     java.awt.Paint var26 = null;
//     var0.setSeriesPaint(10, var26);
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     java.awt.Paint var29 = var28.getDomainGridlinePaint();
//     org.jfree.chart.plot.DatasetRenderingOrder var30 = var28.getDatasetRenderingOrder();
//     boolean var31 = var0.equals((java.lang.Object)var30);
//     java.awt.Graphics2D var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot();
//     var33.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var37 = var33.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var38 = null;
//     var33.setDrawingSupplier(var38);
//     java.awt.Image var40 = null;
//     var33.setBackgroundImage(var40);
//     org.jfree.chart.plot.PlotRenderingInfo var44 = null;
//     java.awt.geom.Point2D var45 = null;
//     var33.zoomRangeAxes(1.0d, 0.0d, var44, var45);
//     org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
//     double var48 = var47.getUpperMargin();
//     java.awt.Font var50 = var47.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var51 = var47.isTickMarksVisible();
//     java.awt.Paint var52 = var47.getAxisLinePaint();
//     var47.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.CategoryMarker var54 = null;
//     java.awt.geom.Rectangle2D var55 = null;
//     var0.drawDomainMarker(var32, var33, var47, var54, var55);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var9 = null;
//     var4.setDrawingSupplier(var9);
//     org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
//     java.util.List var12 = var4.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
//     var0.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var20 = var0.getBaseStroke();
//     var0.setAutoPopulateSeriesOutlineStroke(false);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = var0.getLegendItemLabelGenerator();
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var33 = var31.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
//     var35.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var39 = var35.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var40 = null;
//     var35.setDrawingSupplier(var40);
//     org.jfree.chart.axis.CategoryAxis var42 = var35.getDomainAxis();
//     java.util.List var43 = var35.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var45 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var46 = null;
//     java.awt.geom.Rectangle2D var47 = null;
//     var31.drawRangeMarker(var34, var35, (org.jfree.chart.axis.ValueAxis)var45, var46, var47);
//     var31.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var51 = var31.getBaseStroke();
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
//     var52.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var55 = var52.getFixedRangeAxisSpace();
//     java.awt.Paint var56 = var52.getDomainGridlinePaint();
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "hi!", "", "", var30, var51, var56);
//     var0.setSeriesShape(0, var30, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var31 and var0.", var31.equals(var0) == var0.equals(var31));
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getCeilingTickUnit(100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    org.jfree.chart.event.ChartChangeListener var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.addChangeListener(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     var0.setMaximumCategoryLabelLines(0);
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)(short)100);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     java.awt.Paint var9 = var6.getOutlinePaint();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     var0.setTickMarkPaint(var10);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.AxisState var13 = new org.jfree.chart.axis.AxisState();
//     org.jfree.chart.ChartRenderingInfo var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearDomainMarkers(0);
//     java.awt.Paint var20 = var17.getOutlinePaint();
//     boolean var21 = var17.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var22 = null;
//     int var23 = var17.getDomainAxisIndex(var22);
//     org.jfree.chart.axis.AxisLocation var25 = var17.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var26 = var17.getDomainAxisEdge();
//     java.lang.String var27 = var26.toString();
//     java.util.List var28 = var0.refreshTicks(var12, var13, var16, var26);
//     
//     // Checks the contract:  equals-hashcode on var6 and var17
//     assertTrue("Contract failed: equals-hashcode on var6 and var17", var6.equals(var17) ? var6.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var6
//     assertTrue("Contract failed: equals-hashcode on var17 and var6", var17.equals(var6) ? var17.hashCode() == var6.hashCode() : true);
// 
//   }

//  public void test245() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//
//  }
//
  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.LegendItem var24 = var0.getLegendItem(0, 10);
    java.awt.Paint var26 = null;
    var0.setSeriesPaint(10, var26);
    org.jfree.chart.LegendItem var30 = var0.getLegendItem(100, 10);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var0.setBaseURLGenerator(var31);
    var0.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     boolean var15 = var13.equals((java.lang.Object)(short)10);
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var16 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var17 = null;
//     java.lang.String var18 = var13.getImageMapAreaTag(var16, var17);
// 
//   }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo();
    var5.setLicenceName("");
    var5.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var10 = var5.getLibraries();
    var4.addLibrary((org.jfree.chart.ui.Library)var5);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getTextAlignment();
    boolean var14 = var4.equals((java.lang.Object)var12);
    java.awt.Graphics2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var16 = var12.arrange(var15);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    double var6 = var5.getUpperMargin();
    java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var9 = null;
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
    java.awt.Font var12 = var11.getFont();
    var0.setFont(var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var18 = var17.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var19 = var0.arrange(var14, var17);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    double var8 = var7.getUpperMargin();
    java.awt.Font var10 = var7.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var11 = null;
    org.jfree.chart.block.LabelBlock var12 = new org.jfree.chart.block.LabelBlock("", var10, var11);
    var5.setBaseItemLabelFont(var10, true);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    double var16 = var15.getUpperMargin();
    java.awt.Font var18 = var15.getTickLabelFont((java.lang.Comparable)(short)10);
    var5.setBaseItemLabelFont(var18);
    org.jfree.chart.block.LabelBlock var20 = new org.jfree.chart.block.LabelBlock("", var18);
    java.awt.Paint var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addLine("AxisLabelEntity: label = hi!", var18, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var0.setDrawingSupplier(var5);
    java.awt.Image var7 = null;
    var0.setBackgroundImage(var7);
    var0.setBackgroundImageAlpha(1.0f);
    float var11 = var0.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var13 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 100.0f, var18, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var25 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var13, var22, "HorizontalAlignment.CENTER", "hi!");
    var13.setRange(0.05d, 0.05d);
    var13.setRangeAboutValue(0.0d, 18.0d);
    var13.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot();
    var35.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var39 = var35.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var40 = null;
    var35.setDrawingSupplier(var40);
    var13.addChangeListener((org.jfree.chart.event.AxisChangeListener)var35);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var35);
    float var44 = var43.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var43);
    org.jfree.chart.ChartRenderingInfo var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var50 = var43.createBufferedImage((-16777198), (-16777198), (-16777198), var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.5f);

  }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    java.awt.Paint var1 = var0.getDomainGridlinePaint();
    org.jfree.chart.plot.DatasetRenderingOrder var2 = var0.getDatasetRenderingOrder();
    java.lang.String var3 = var2.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var3.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
//     org.jfree.chart.ui.BasicProjectInfo var6 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
//     org.jfree.chart.ui.BasicProjectInfo var7 = new org.jfree.chart.ui.BasicProjectInfo();
//     var7.setLicenceName("");
//     var7.setCopyright("hi!");
//     org.jfree.chart.ui.Library[] var12 = var7.getLibraries();
//     var6.addLibrary((org.jfree.chart.ui.Library)var7);
//     int var14 = var1.compareTo((java.lang.Object)var7);
//     java.lang.Comparable[] var15 = new java.lang.Comparable[] { var14};
//     java.lang.Comparable[] var17 = new java.lang.Comparable[] { (byte)0};
//     double[] var18 = null;
//     double[][] var19 = new double[][] { var18};
//     org.jfree.data.category.CategoryDataset var20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var15, var17, var19);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(0.05d, var1, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var3 = null;
    var0.setGradientPaintTransformer(var3);
    java.awt.Paint var6 = null;
    var0.setSeriesFillPaint(10, var6, false);
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getSeriesNegativeItemLabelPosition(100);
    double var11 = var10.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    var31.setBorderVisible(false);
    var31.removeLegend();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var39 = var31.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.LegendItem var24 = var0.getLegendItem(0, 10);
    var0.setItemMargin(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    var31.fireChartChanged();
    org.jfree.chart.title.TextTitle var35 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var36 = var35.getFont();
    java.lang.Object var37 = var35.clone();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis();
    double var41 = var40.getUpperMargin();
    java.awt.Font var43 = var40.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var44 = null;
    org.jfree.chart.block.LabelBlock var45 = new org.jfree.chart.block.LabelBlock("", var43, var44);
    org.jfree.chart.text.TextFragment var46 = new org.jfree.chart.text.TextFragment("", var43);
    java.awt.Font var47 = var46.getFont();
    var35.setFont(var47);
    var31.removeSubtitle((org.jfree.chart.title.Title)var35);
    org.jfree.chart.ChartRenderingInfo var54 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var55 = var31.createBufferedImage((-16777198), 100, 18.0d, (-1.0d), var54);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var5 = var0.getRangeAxisLocation((-16777216));
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedRangeAxisSpace();
    java.awt.Image var7 = null;
    var0.setBackgroundImage(var7);
    org.jfree.chart.plot.Plot var9 = var0.getParent();
    var0.setNoDataMessage("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var12 = var9.getFixedRangeAxisSpace();
    java.awt.Paint var13 = var9.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var14 = null;
    var9.setRangeAxis(var14);
    var9.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var20 = var18.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var21 = var18.getTickMarkStroke();
    var9.setDomainGridlineStroke(var21);
    var0.setSeriesOutlineStroke(100, var21);
    boolean var26 = var0.getItemCreateEntity(100, 0);
    org.jfree.chart.labels.ItemLabelPosition var28 = var0.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.annotations.CategoryAnnotation var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     java.lang.Boolean var2 = var0.getSeriesVisible((-1));
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
//     var0.setLegendItemToolTipGenerator(var3);
//     org.jfree.chart.util.PaintList var7 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var10 = var8.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var8.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var13 = var8.getTickLabelInsets();
//     boolean var14 = var7.equals((java.lang.Object)var8);
//     java.awt.Font var16 = var8.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var20 = var17.getFixedRangeAxisSpace();
//     java.awt.Paint var21 = var17.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var22 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var16, var21);
//     var0.setSeriesItemLabelPaint(0, var21);
//     java.awt.Graphics2D var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var30 = var26.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var31 = null;
//     var26.setDrawingSupplier(var31);
//     java.awt.Image var33 = null;
//     var26.setBackgroundImage(var33);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     double var36 = var35.getUpperMargin();
//     java.awt.Font var38 = var35.getTickLabelFont((java.lang.Comparable)(short)10);
//     var26.setNoDataMessageFont(var38);
//     org.jfree.chart.LegendItemCollection var40 = null;
//     var26.setFixedLegendItems(var40);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var45 = var0.initialise(var24, var25, var26, 4, var44);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     org.jfree.chart.block.BorderArrangement var3 = new org.jfree.chart.block.BorderArrangement();
//     java.lang.Object var4 = null;
//     boolean var5 = var3.equals(var4);
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.renderer.category.StatisticalBarRenderer var3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var5 = var3.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var3.notifyListeners(var6);
    org.jfree.chart.urls.CategoryURLGenerator var8 = var3.getBaseURLGenerator();
    org.jfree.chart.labels.ItemLabelPosition var11 = var3.getPositiveItemLabelPosition((-16777216), (-16777216));
    org.jfree.chart.text.TextAnchor var12 = var11.getRotationAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var14 = new org.jfree.chart.axis.NumberTick((java.lang.Number)0.5f, "10", var2, var12, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, 0.0d, 6.0d, 0.2d);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var4 = var1.getFixedRangeAxisSpace();
    var1.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var7 = null;
    var1.markerChanged(var7);
    boolean var9 = var1.isDomainZoomable();
    org.jfree.chart.axis.NumberAxis var11 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var12 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    java.awt.Shape var20 = var12.calculateBounds(var13, 0.0f, 100.0f, var16, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var23 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var11, var20, "HorizontalAlignment.CENTER", "hi!");
    org.jfree.chart.axis.ValueAxis[] var24 = new org.jfree.chart.axis.ValueAxis[] { var11};
    var1.setRangeAxes(var24);
    org.jfree.chart.plot.ValueMarker var27 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.util.Layer var28 = null;
    var1.addRangeMarker((org.jfree.chart.plot.Marker)var27, var28);
    var27.setLabel("");
    java.awt.Paint var32 = var27.getLabelPaint();
    java.awt.Stroke var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var34 = new org.jfree.chart.plot.ValueMarker(0.2d, var32, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test268() {}
//   public void test268() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("UnitType.ABSOLUTE", var1);
// 
//   }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.text.G2TextMeasurer var1 = new org.jfree.chart.text.G2TextMeasurer(var0);
//     float var5 = var1.getStringWidth("10", 1, (-1));
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var4 = var0.isTickMarksVisible();
    java.awt.Paint var5 = var0.getAxisLinePaint();
    var0.clearCategoryLabelToolTips();
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
    org.jfree.chart.ui.BasicProjectInfo var13 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.ui.BasicProjectInfo var14 = new org.jfree.chart.ui.BasicProjectInfo();
    var14.setLicenceName("");
    var14.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var19 = var14.getLibraries();
    var13.addLibrary((org.jfree.chart.ui.Library)var14);
    int var21 = var8.compareTo((java.lang.Object)var14);
    var0.addCategoryLabelToolTip((java.lang.Comparable)var21, "");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-1));

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    float var18 = var14.getTickMarkInsideLength();
    double var19 = var14.getUpperBound();
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    double var21 = var20.getUpperMargin();
    java.awt.Font var23 = var20.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var24 = var20.isTickMarksVisible();
    java.awt.Paint var25 = var20.getAxisLinePaint();
    var20.clearCategoryLabelToolTips();
    var20.setMaximumCategoryLabelWidthRatio((-1.0f));
    boolean var29 = var14.equals((java.lang.Object)(-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

//  public void test273() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//
//  }
//
  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("AxisLabelEntity: label = hi!", var1);
// 
//   }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    double var4 = var3.getUpperMargin();
    java.awt.Font var6 = var3.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    var7.clearDomainMarkers(0);
    java.awt.Paint var10 = var7.getOutlinePaint();
    boolean var11 = var7.isSubplot();
    var3.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var7);
    java.awt.Font var13 = var3.getLabelFont();
    org.jfree.chart.text.TextLine var14 = new org.jfree.chart.text.TextLine("hi!", var13);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var19 = var17.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var17.setLowerMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    double var23 = var22.getUpperMargin();
    java.awt.Font var25 = var22.getTickLabelFont((java.lang.Comparable)10.0d);
    var17.setTickLabelFont(var25);
    org.jfree.chart.block.LabelBlock var27 = new org.jfree.chart.block.LabelBlock("", var25);
    org.jfree.chart.text.TextFragment var28 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_RIGHT", var25);
    var14.removeFragment(var28);
    var0.set(18, (java.lang.Object)var14);
    java.lang.Object var32 = var0.get(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     boolean var15 = var13.equals((java.lang.Object)(short)10);
//     java.lang.String var16 = var13.getURLText();
//     var13.setURLText("");
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var19 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var20 = null;
//     java.lang.String var21 = var13.getImageMapAreaTag(var19, var20);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
    var34.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var38 = var34.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var39 = null;
    var34.setDrawingSupplier(var39);
    java.awt.Image var41 = null;
    var34.setBackgroundImage(var41);
    var34.setBackgroundImageAlpha(1.0f);
    float var45 = var34.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var47 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var48 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var49 = null;
    org.jfree.chart.text.TextBlockAnchor var52 = null;
    java.awt.Shape var56 = var48.calculateBounds(var49, 0.0f, 100.0f, var52, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var59 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var47, var56, "HorizontalAlignment.CENTER", "hi!");
    var47.setRange(0.05d, 0.05d);
    var47.setRangeAboutValue(0.0d, 18.0d);
    var47.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
    var69.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var73 = var69.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var74 = null;
    var69.setDrawingSupplier(var74);
    var47.addChangeListener((org.jfree.chart.event.AxisChangeListener)var69);
    org.jfree.chart.JFreeChart var77 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var69);
    float var78 = var77.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var79 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var34, var77);
    java.awt.RenderingHints var80 = var77.getRenderingHints();
    var31.setRenderingHints(var80);
    org.jfree.chart.title.TextTitle var82 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var83 = var82.getFont();
    java.lang.Object var84 = var82.clone();
    org.jfree.chart.util.HorizontalAlignment var85 = var82.getHorizontalAlignment();
    var31.removeSubtitle((org.jfree.chart.title.Title)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.util.HorizontalAlignment var3 = var0.getHorizontalAlignment();
    java.awt.Paint var4 = var0.getPaint();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var9 = var5.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var10 = null;
    var5.setDrawingSupplier(var10);
    java.awt.Image var12 = null;
    var5.setBackgroundImage(var12);
    var5.setBackgroundImageAlpha(1.0f);
    float var16 = var5.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var19 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.text.TextBlockAnchor var23 = null;
    java.awt.Shape var27 = var19.calculateBounds(var20, 0.0f, 100.0f, var23, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var30 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var18, var27, "HorizontalAlignment.CENTER", "hi!");
    var18.setRange(0.05d, 0.05d);
    var18.setRangeAboutValue(0.0d, 18.0d);
    var18.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
    var40.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var44 = var40.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var45 = null;
    var40.setDrawingSupplier(var45);
    var18.addChangeListener((org.jfree.chart.event.AxisChangeListener)var40);
    org.jfree.chart.JFreeChart var48 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var40);
    float var49 = var48.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var5, var48);
    java.awt.RenderingHints var51 = var48.getRenderingHints();
    var0.addChangeListener((org.jfree.chart.event.TitleChangeListener)var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.Title var54 = var48.getSubtitle(4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var8.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var8.notifyListeners(var11);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    var8.setSeriesVisibleInLegend(1, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.PaintList var2 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var5 = var3.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var3.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var8 = var3.getTickLabelInsets();
    boolean var9 = var2.equals((java.lang.Object)var3);
    java.awt.Font var11 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedRangeAxisSpace();
    java.awt.Paint var16 = var12.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var11, var16);
    org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
    var0.setHorizontalAlignment(var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var24 = var20.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var25 = null;
    var20.setDrawingSupplier(var25);
    java.awt.Image var27 = null;
    var20.setBackgroundImage(var27);
    var20.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var33 = var31.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var31.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var36 = var31.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var39 = var37.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var37.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var42 = var37.getTickLabelInsets();
    var31.setLabelInsets(var42);
    double var44 = var42.getRight();
    double var45 = var42.getBottom();
    var20.setInsets(var42);
    org.jfree.chart.util.RectangleEdge var48 = var20.getDomainAxisEdge(100);
    var0.setPosition(var48);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var54 = var50.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var55 = null;
    var50.setDrawingSupplier(var55);
    java.awt.Image var57 = null;
    var50.setBackgroundImage(var57);
    var50.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var63 = var61.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var61.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var66 = var61.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var69 = var67.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var67.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var72 = var67.getTickLabelInsets();
    var61.setLabelInsets(var72);
    double var74 = var72.getRight();
    double var75 = var72.getBottom();
    var50.setInsets(var72);
    org.jfree.chart.util.RectangleEdge var78 = var50.getDomainAxisEdge(100);
    var0.setPosition(var78);
    org.jfree.chart.util.RectangleEdge var80 = org.jfree.chart.util.RectangleEdge.opposite(var78);
    boolean var81 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = null;
//     var0.setDrawingSupplier(var5);
//     java.awt.Image var7 = null;
//     var0.setBackgroundImage(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackgroundImage(var9, var10);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     java.awt.geom.Point2D var14 = null;
//     org.jfree.chart.plot.PlotState var15 = null;
//     org.jfree.chart.ChartRenderingInfo var16 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
//     java.awt.geom.Rectangle2D var18 = var17.getDataArea();
//     var0.draw(var12, var13, var14, var15, var17);
// 
//   }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Font var12 = var11.getFont();
//     var0.setFont(var12);
//     org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
//     java.lang.String var15 = var14.toString();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
//     var17.setRange(0.05d, 0.05d);
//     var17.setRangeAboutValue(0.0d, 18.0d);
//     var17.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     boolean var47 = var14.equals((java.lang.Object)var17);
//     java.awt.Shape var48 = var17.getRightArrow();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers(0);
//     java.awt.Paint var52 = var49.getOutlinePaint();
//     boolean var53 = var49.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
//     java.awt.Paint var58 = var54.getDomainGridlinePaint();
//     var49.setNoDataMessagePaint(var58);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.axis.NumberAxis var63 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var63.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var68 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var69 = new org.jfree.chart.plot.PlotRenderingInfo(var68);
//     java.awt.geom.Rectangle2D var70 = var69.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot();
//     var71.clearDomainMarkers(0);
//     java.awt.Paint var74 = var71.getOutlinePaint();
//     boolean var75 = var71.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var76 = null;
//     int var77 = var71.getDomainAxisIndex(var76);
//     org.jfree.chart.axis.AxisLocation var79 = var71.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var80 = var71.getDomainAxisEdge();
//     double var81 = var63.valueToJava2D(10.0d, var70, var80);
//     java.lang.Object var83 = var60.draw(var61, var70, (java.lang.Object)4);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    var0.add((org.jfree.chart.axis.TickUnit)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var7 = var0.get(4);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.PaintList var2 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var5 = var3.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var3.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var8 = var3.getTickLabelInsets();
    boolean var9 = var2.equals((java.lang.Object)var3);
    java.awt.Font var11 = var3.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var15 = var12.getFixedRangeAxisSpace();
    java.awt.Paint var16 = var12.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var17 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var11, var16);
    org.jfree.chart.util.HorizontalAlignment var18 = var17.getLineAlignment();
    var0.setHorizontalAlignment(var18);
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
    var20.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var24 = var20.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var25 = null;
    var20.setDrawingSupplier(var25);
    java.awt.Image var27 = null;
    var20.setBackgroundImage(var27);
    var20.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var33 = var31.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var31.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var36 = var31.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var39 = var37.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var37.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var42 = var37.getTickLabelInsets();
    var31.setLabelInsets(var42);
    double var44 = var42.getRight();
    double var45 = var42.getBottom();
    var20.setInsets(var42);
    org.jfree.chart.util.RectangleEdge var48 = var20.getDomainAxisEdge(100);
    var0.setPosition(var48);
    org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot();
    var50.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var54 = var50.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var55 = null;
    var50.setDrawingSupplier(var55);
    java.awt.Image var57 = null;
    var50.setBackgroundImage(var57);
    var50.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var63 = var61.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var61.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var66 = var61.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var69 = var67.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var67.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var72 = var67.getTickLabelInsets();
    var61.setLabelInsets(var72);
    double var74 = var72.getRight();
    double var75 = var72.getBottom();
    var50.setInsets(var72);
    org.jfree.chart.util.RectangleEdge var78 = var50.getDomainAxisEdge(100);
    var0.setPosition(var78);
    org.jfree.chart.util.RectangleEdge var80 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPosition(var80);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    var0.setIncludeBaseInRange(true);
    java.awt.Paint var24 = var0.getItemOutlinePaint((-1), 0);
    org.jfree.data.category.CategoryDataset var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var26 = var0.findRangeBounds(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.data.KeyedObjects2D var3 = new org.jfree.data.KeyedObjects2D();
    java.util.List var4 = var3.getColumnKeys();
    boolean var5 = var1.equals((java.lang.Object)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var7 = var1.getSubplotInfo(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var14.setNegativeArrowVisible(false);
    org.jfree.data.RangeType var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setRangeType(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     double var9 = var8.getUpperMargin();
//     java.awt.Font var11 = var8.getTickLabelFont((java.lang.Comparable)10.0d);
//     var7.setFont(var11);
//     java.awt.Font var13 = var7.getFont();
//     var0.add((org.jfree.chart.block.Block)var7, (java.lang.Object)1);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     java.awt.Font var21 = var18.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var22 = null;
//     org.jfree.chart.block.LabelBlock var23 = new org.jfree.chart.block.LabelBlock("", var21, var22);
//     var16.setBaseItemLabelFont(var21, true);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var29 = new org.jfree.chart.block.BlockContainer();
//     boolean var30 = var26.equals((java.lang.Object)var29);
//     org.jfree.chart.plot.Plot var31 = null;
//     var26.setParent(var31);
//     var16.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var26);
//     boolean var34 = var0.equals((java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var7 and var23
//     assertTrue("Contract failed: equals-hashcode on var7 and var23", var7.equals(var23) ? var7.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var7
//     assertTrue("Contract failed: equals-hashcode on var23 and var7", var23.equals(var7) ? var23.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
    java.awt.Paint var9 = var5.getDomainGridlinePaint();
    var0.setNoDataMessagePaint(var9);
    boolean var11 = var0.isDomainGridlinesVisible();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.clearDomainMarkers(0);
    java.awt.Paint var16 = var13.getOutlinePaint();
    java.awt.Paint var17 = var13.getNoDataMessagePaint();
    boolean var18 = var13.isRangeZoomable();
    org.jfree.chart.axis.AxisLocation var20 = var13.getDomainAxisLocation((-16777216));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-1), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    var31.setBorderVisible(false);
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
    var38.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var41 = var38.getFixedRangeAxisSpace();
    java.awt.Paint var42 = var38.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var43 = null;
    var38.setRangeAxis(var43);
    var38.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var47 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var49 = var47.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var50 = var47.getTickMarkStroke();
    var38.setDomainGridlineStroke(var50);
    var31.setBorderStroke(var50);
    org.jfree.chart.title.LegendTitle var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.addLegend(var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoTickUnitSelection(true, true);
    java.awt.Shape var5 = var1.getUpArrow();
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.util.PaintList var1 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var4 = var2.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var2.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var7 = var2.getTickLabelInsets();
    boolean var8 = var1.equals((java.lang.Object)var2);
    java.awt.Font var10 = var2.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
    var11.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var14 = var11.getFixedRangeAxisSpace();
    java.awt.Paint var15 = var11.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var16 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var10, var15);
    org.jfree.chart.util.HorizontalAlignment var17 = var16.getLineAlignment();
    java.lang.String var18 = var17.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var18.equals("HorizontalAlignment.CENTER"));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    var0.add((org.jfree.chart.axis.TickUnit)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var7 = var0.get(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var1 = var0.getFont();
    java.lang.Object var2 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    double var6 = var5.getUpperMargin();
    java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var9 = null;
    org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
    org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
    java.awt.Font var12 = var11.getFont();
    var0.setFont(var12);
    org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
    java.lang.String var15 = var14.toString();
    org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var19 = null;
    org.jfree.chart.text.TextBlockAnchor var22 = null;
    java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
    var17.setRange(0.05d, 0.05d);
    var17.setRangeAboutValue(0.0d, 18.0d);
    var17.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
    var39.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var44 = null;
    var39.setDrawingSupplier(var44);
    var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
    boolean var47 = var14.equals((java.lang.Object)var17);
    java.awt.Shape var48 = var17.getRightArrow();
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    var49.clearDomainMarkers(0);
    java.awt.Paint var52 = var49.getOutlinePaint();
    boolean var53 = var49.isSubplot();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
    var54.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
    java.awt.Paint var58 = var54.getDomainGridlinePaint();
    var49.setNoDataMessagePaint(var58);
    org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
    org.jfree.chart.util.RectangleAnchor var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var60.setShapeAnchor(var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "VerticalAlignment.CENTER"+ "'", var15.equals("VerticalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var3 = null;
    var0.setGradientPaintTransformer(var3);
    java.awt.Shape var6 = var0.lookupSeriesShape((-16777216));
    org.jfree.chart.entity.TickLabelEntity var9 = new org.jfree.chart.entity.TickLabelEntity(var6, "VerticalAlignment.CENTER", "AxisLabelEntity: label = hi!");
    var9.setToolTipText("ChartEntity: tooltip = null");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var4 = var0.isTickMarksVisible();
//     java.awt.Paint var5 = var0.getAxisLinePaint();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     java.awt.Paint var9 = var6.getOutlinePaint();
//     java.awt.Paint var10 = var6.getNoDataMessagePaint();
//     var0.setLabelPaint(var10);
//     org.jfree.chart.event.AxisChangeEvent var12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.AxisState var14 = null;
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var16 = var15.getFont();
//     java.awt.Paint var17 = var15.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var18 = var15.getBounds();
//     org.jfree.chart.title.TextTitle var19 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.PaintList var21 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var24 = var22.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var22.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var27 = var22.getTickLabelInsets();
//     boolean var28 = var21.equals((java.lang.Object)var22);
//     java.awt.Font var30 = var22.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
//     var31.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var34 = var31.getFixedRangeAxisSpace();
//     java.awt.Paint var35 = var31.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var36 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var30, var35);
//     org.jfree.chart.util.HorizontalAlignment var37 = var36.getLineAlignment();
//     var19.setHorizontalAlignment(var37);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     java.awt.Image var46 = null;
//     var39.setBackgroundImage(var46);
//     var39.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.axis.CategoryAxis var50 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var52 = var50.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var50.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var55 = var50.getTickLabelInsets();
//     org.jfree.chart.axis.CategoryAxis var56 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var58 = var56.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var56.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var61 = var56.getTickLabelInsets();
//     var50.setLabelInsets(var61);
//     double var63 = var61.getRight();
//     double var64 = var61.getBottom();
//     var39.setInsets(var61);
//     org.jfree.chart.util.RectangleEdge var67 = var39.getDomainAxisEdge(100);
//     var19.setPosition(var67);
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot();
//     var69.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var73 = var69.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var74 = null;
//     var69.setDrawingSupplier(var74);
//     java.awt.Image var76 = null;
//     var69.setBackgroundImage(var76);
//     var69.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.axis.CategoryAxis var80 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var82 = var80.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var80.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var85 = var80.getTickLabelInsets();
//     org.jfree.chart.axis.CategoryAxis var86 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var88 = var86.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var86.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var91 = var86.getTickLabelInsets();
//     var80.setLabelInsets(var91);
//     double var93 = var91.getRight();
//     double var94 = var91.getBottom();
//     var69.setInsets(var91);
//     org.jfree.chart.util.RectangleEdge var97 = var69.getDomainAxisEdge(100);
//     var19.setPosition(var97);
//     java.util.List var99 = var0.refreshTicks(var13, var14, var18, var97);
//     
//     // Checks the contract:  equals-hashcode on var6 and var31
//     assertTrue("Contract failed: equals-hashcode on var6 and var31", var6.equals(var31) ? var6.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var6
//     assertTrue("Contract failed: equals-hashcode on var31 and var6", var31.equals(var6) ? var31.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
//     var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var7 = new org.jfree.chart.block.BlockContainer();
//     boolean var8 = var4.equals((java.lang.Object)var7);
//     java.util.List var9 = var7.getBlocks();
//     java.awt.geom.Rectangle2D var10 = var7.getBounds();
//     java.lang.Object var11 = new java.lang.Object();
//     java.lang.Object var12 = var0.draw(var3, var10, var11);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.axis.AxisLocation var6 = var0.getDomainAxisLocation(1);
    org.jfree.chart.util.SortOrder var7 = var0.getRowRenderingOrder();
    java.lang.String var8 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "SortOrder.ASCENDING"+ "'", var8.equals("SortOrder.ASCENDING"));

  }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("HorizontalAlignment.CENTER", var1);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setUpperMargin(2.0d);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var5 = var4.getFont();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getUpperMargin();
    java.awt.Font var12 = var9.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var13 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var12, var13);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var12);
    java.awt.Font var16 = var15.getFont();
    var4.setFont(var16);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    org.jfree.data.RangeType var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeType(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getDataArea();
    org.jfree.data.KeyedObjects2D var3 = new org.jfree.data.KeyedObjects2D();
    java.util.List var4 = var3.getColumnKeys();
    boolean var5 = var1.equals((java.lang.Object)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var6 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    boolean var2 = var0.equals((java.lang.Object)(byte)10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var4 = var0.getCeilingTickUnit(2.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.text.TextBlockAnchor var10 = null;
//     java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var18 = var15.getTickMarkStroke();
//     java.awt.Color var20 = java.awt.Color.decode("18");
//     float[] var21 = null;
//     float[] var22 = var20.getRGBColorComponents(var21);
//     org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
//     java.lang.String var24 = var20.toString();
//     var1.setPaint((java.awt.Paint)var20);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
//     var26.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.event.MarkerChangeEvent var32 = null;
//     var26.markerChanged(var32);
//     boolean var34 = var26.isDomainZoomable();
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
//     java.awt.Paint var36 = var1.getLabelPaint();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var40 = null;
//     var37.notifyListeners(var40);
//     org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
//     var37.setBaseToolTipGenerator(var42, true);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var47 = var45.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var48 = null;
//     var45.setGradientPaintTransformer(var48);
//     java.awt.Shape var51 = var45.lookupSeriesShape((-16777216));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var54 = var52.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     var56.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var61 = null;
//     var56.setDrawingSupplier(var61);
//     org.jfree.chart.axis.CategoryAxis var63 = var56.getDomainAxis();
//     java.util.List var64 = var56.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var67 = null;
//     java.awt.geom.Rectangle2D var68 = null;
//     var52.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var66, var67, var68);
//     var52.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var72 = var52.getBaseStroke();
//     var45.setErrorIndicatorStroke(var72);
//     var37.setErrorIndicatorStroke(var72);
//     var1.setOutlineStroke(var72);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     var76.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var80 = var76.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var81 = null;
//     var76.setDrawingSupplier(var81);
//     java.awt.Image var83 = null;
//     var76.setBackgroundImage(var83);
//     org.jfree.chart.plot.PlotRenderingInfo var87 = null;
//     java.awt.geom.Point2D var88 = null;
//     var76.zoomRangeAxes(1.0d, 0.0d, var87, var88);
//     var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var76);
//     java.lang.Object var91 = var1.clone();
//     org.jfree.chart.text.TextAnchor var92 = var1.getLabelTextAnchor();
//     java.lang.Class var93 = null;
//     java.util.EventListener[] var94 = var1.getListeners(var93);
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var18 = var15.getTickMarkStroke();
    java.awt.Color var20 = java.awt.Color.decode("18");
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
    java.lang.String var24 = var20.toString();
    var1.setPaint((java.awt.Paint)var20);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
    var26.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var26.markerChanged(var32);
    boolean var34 = var26.isDomainZoomable();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
    java.awt.Paint var36 = var1.getLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var40 = null;
    var37.notifyListeners(var40);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var37.setBaseToolTipGenerator(var42, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var47 = var45.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var48 = null;
    var45.setGradientPaintTransformer(var48);
    java.awt.Shape var51 = var45.lookupSeriesShape((-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var54 = var52.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
    var56.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var61 = null;
    var56.setDrawingSupplier(var61);
    org.jfree.chart.axis.CategoryAxis var63 = var56.getDomainAxis();
    java.util.List var64 = var56.getAnnotations();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var67 = null;
    java.awt.geom.Rectangle2D var68 = null;
    var52.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var66, var67, var68);
    var52.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var72 = var52.getBaseStroke();
    var45.setErrorIndicatorStroke(var72);
    var37.setErrorIndicatorStroke(var72);
    var1.setOutlineStroke(var72);
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    var76.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var80 = var76.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var81 = null;
    var76.setDrawingSupplier(var81);
    java.awt.Image var83 = null;
    var76.setBackgroundImage(var83);
    org.jfree.chart.plot.PlotRenderingInfo var87 = null;
    java.awt.geom.Point2D var88 = null;
    var76.zoomRangeAxes(1.0d, 0.0d, var87, var88);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var76);
    java.lang.Object var91 = var1.clone();
    org.jfree.chart.text.TextAnchor var92 = var1.getLabelTextAnchor();
    java.lang.String var93 = var92.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var24.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + "TextAnchor.CENTER"+ "'", var93.equals("TextAnchor.CENTER"));

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var4 = var0.isTickMarksVisible();
    java.awt.Paint var5 = var0.getAxisLinePaint();
    boolean var6 = var0.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("SortOrder.ASCENDING", "Range[0.0,1.0]", var3);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    boolean var8 = var0.isDomainZoomable();
    org.jfree.chart.axis.NumberAxis var10 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    java.awt.Shape var19 = var11.calculateBounds(var12, 0.0f, 100.0f, var15, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var22 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var10, var19, "HorizontalAlignment.CENTER", "hi!");
    org.jfree.chart.axis.ValueAxis[] var23 = new org.jfree.chart.axis.ValueAxis[] { var10};
    var0.setRangeAxes(var23);
    java.util.List var25 = var0.getCategories();
    org.jfree.chart.axis.AxisSpace var26 = var0.getFixedRangeAxisSpace();
    java.awt.Stroke var27 = var0.getRangeGridlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setUpperMargin(2.0d);
    org.jfree.chart.title.TextTitle var4 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var5 = var4.getFont();
    java.lang.Object var6 = var4.clone();
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getUpperMargin();
    java.awt.Font var12 = var9.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var13 = null;
    org.jfree.chart.block.LabelBlock var14 = new org.jfree.chart.block.LabelBlock("", var12, var13);
    org.jfree.chart.text.TextFragment var15 = new org.jfree.chart.text.TextFragment("", var12);
    java.awt.Font var16 = var15.getFont();
    var4.setFont(var16);
    boolean var18 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var1, (java.lang.Object)var4);
    var1.configure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(2.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("AxisLocation.BOTTOM_OR_RIGHT", var1);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    java.util.List var31 = var23.getCategories();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
    org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearDomainMarkers(0);
    java.awt.Paint var9 = var6.getOutlinePaint();
    boolean var10 = var6.isSubplot();
    org.jfree.chart.axis.CategoryAxis var11 = null;
    int var12 = var6.getDomainAxisIndex(var11);
    org.jfree.chart.axis.AxisLocation var14 = var6.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var15 = var6.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var16 = var5.getLabelPosition(var15);
    float var17 = var16.getWidthRatio();
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var16);
    org.jfree.chart.block.RectangleConstraint var21 = new org.jfree.chart.block.RectangleConstraint(6.0d, 4.0d);
    boolean var22 = var1.equals((java.lang.Object)4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    int var3 = var0.getColumnIndex((java.lang.Comparable)"AxisLabelEntity: label = hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var0.getObject(15, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = null;
//     var0.setDrawingSupplier(var5);
//     java.awt.Image var7 = null;
//     var0.setBackgroundImage(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var0.drawBackgroundImage(var9, var10);
//     org.jfree.chart.util.RectangleInsets var12 = var0.getInsets();
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.axis.NumberAxis var15 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var15.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
//     java.awt.geom.Rectangle2D var22 = var21.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     java.awt.Paint var26 = var23.getOutlinePaint();
//     boolean var27 = var23.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     int var29 = var23.getDomainAxisIndex(var28);
//     org.jfree.chart.axis.AxisLocation var31 = var23.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var32 = var23.getDomainAxisEdge();
//     double var33 = var15.valueToJava2D(10.0d, var22, var32);
//     var0.drawOutline(var13, var22);
// 
//   }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     var1.setRange(0.05d, 0.05d);
//     var1.setRangeAboutValue(0.0d, 18.0d);
//     var1.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var28 = null;
//     var23.setDrawingSupplier(var28);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     float var32 = var31.getBackgroundImageAlpha();
//     java.util.List var33 = var31.getSubtitles();
//     org.jfree.chart.event.ChartProgressListener var34 = null;
//     var31.removeProgressListener(var34);
//     org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.text.TextBlockAnchor var42 = null;
//     java.awt.Shape var46 = var38.calculateBounds(var39, 0.0f, 100.0f, var42, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var37, var46, "HorizontalAlignment.CENTER", "hi!");
//     var37.setRange(0.05d, 0.05d);
//     var37.setRangeAboutValue(0.0d, 18.0d);
//     var37.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
//     var59.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var63 = var59.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var64 = null;
//     var59.setDrawingSupplier(var64);
//     var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var59);
//     org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var59);
//     float var68 = var67.getBackgroundImageAlpha();
//     java.awt.RenderingHints var69 = var67.getRenderingHints();
//     var31.setRenderingHints(var69);
//     java.awt.Graphics2D var71 = null;
//     org.jfree.chart.ChartRenderingInfo var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = new org.jfree.chart.plot.PlotRenderingInfo(var72);
//     java.awt.geom.Rectangle2D var74 = var73.getDataArea();
//     org.jfree.chart.ChartRenderingInfo var75 = null;
//     var31.draw(var71, var74, var75);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var14.setNegativeArrowVisible(false);
    var14.setRangeWithMargins((-1.0d), 1.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setRangeWithMargins(4.0d, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.Dataset var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.DatasetChangeEvent var2 = new org.jfree.data.general.DatasetChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
//     var0.setLicenceName("");
//     java.lang.Object var3 = null;
//     boolean var4 = var0.equals(var3);
//     org.jfree.chart.ui.Library var5 = null;
//     var0.addLibrary(var5);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.text.TextBlockAnchor var42 = null;
    java.awt.Shape var46 = var38.calculateBounds(var39, 0.0f, 100.0f, var42, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var37, var46, "HorizontalAlignment.CENTER", "hi!");
    var37.setRange(0.05d, 0.05d);
    var37.setRangeAboutValue(0.0d, 18.0d);
    var37.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    var59.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var63 = var59.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var64 = null;
    var59.setDrawingSupplier(var64);
    var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var59);
    org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var59);
    float var68 = var67.getBackgroundImageAlpha();
    java.awt.RenderingHints var69 = var67.getRenderingHints();
    var31.setRenderingHints(var69);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var71 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var31);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     int var6 = var0.getDomainAxisIndex(var5);
//     org.jfree.chart.axis.AxisLocation var7 = var0.getRangeAxisLocation();
//     org.jfree.chart.axis.NumberAxis var9 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var9.setAutoRangeIncludesZero(false);
//     var9.setAutoTickUnitSelection(true, false);
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var18 = new org.jfree.chart.block.BlockContainer();
//     boolean var19 = var15.equals((java.lang.Object)var18);
//     var9.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
//     int var21 = var0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var20 = var0.getBaseStroke();
    org.jfree.chart.LegendItemCollection var21 = var0.getLegendItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var23 = var21.get(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.axis.TickUnits var0 = new org.jfree.chart.axis.TickUnits();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
    var3.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var6 = var3.getFixedRangeAxisSpace();
    var3.setRangeCrosshairLockedOnData(false);
    boolean var9 = var2.equals((java.lang.Object)false);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var14 = var10.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var10.setDrawingSupplier(var15);
    java.awt.Image var17 = null;
    var10.setBackgroundImage(var17);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    java.awt.geom.Point2D var22 = null;
    var10.zoomRangeAxes(1.0d, 0.0d, var21, var22);
    int var24 = var2.compareTo((java.lang.Object)0.0d);
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
    var25.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var29 = var25.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var30 = null;
    var25.setDrawingSupplier(var30);
    java.awt.Image var32 = null;
    var25.setBackgroundImage(var32);
    var25.setBackgroundImageAlpha(1.0f);
    float var36 = var25.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var38 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var39 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.text.TextBlockAnchor var43 = null;
    java.awt.Shape var47 = var39.calculateBounds(var40, 0.0f, 100.0f, var43, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var50 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var38, var47, "HorizontalAlignment.CENTER", "hi!");
    var38.setRange(0.05d, 0.05d);
    var38.setRangeAboutValue(0.0d, 18.0d);
    var38.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
    var60.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var64 = var60.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var65 = null;
    var60.setDrawingSupplier(var65);
    var38.addChangeListener((org.jfree.chart.event.AxisChangeListener)var60);
    org.jfree.chart.JFreeChart var68 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var60);
    float var69 = var68.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var70 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var25, var68);
    java.awt.RenderingHints var71 = var68.getRenderingHints();
    org.jfree.chart.util.RectangleInsets var72 = var68.getPadding();
    org.jfree.chart.event.ChartChangeEvent var73 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var2, var68);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnit var74 = var0.getLargerTickUnit((org.jfree.chart.axis.TickUnit)var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Font var12 = var11.getFont();
//     var0.setFont(var12);
//     org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
//     java.lang.String var15 = var14.toString();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
//     var17.setRange(0.05d, 0.05d);
//     var17.setRangeAboutValue(0.0d, 18.0d);
//     var17.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     boolean var47 = var14.equals((java.lang.Object)var17);
//     java.awt.Shape var48 = var17.getRightArrow();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers(0);
//     java.awt.Paint var52 = var49.getOutlinePaint();
//     boolean var53 = var49.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
//     java.awt.Paint var58 = var54.getDomainGridlinePaint();
//     var49.setNoDataMessagePaint(var58);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
//     boolean var61 = var60.isShapeFilled();
//     org.jfree.chart.axis.CategoryLabelPositions var63 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.clearDomainMarkers(0);
//     java.awt.Paint var67 = var64.getOutlinePaint();
//     boolean var68 = var64.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var69 = null;
//     int var70 = var64.getDomainAxisIndex(var69);
//     org.jfree.chart.axis.AxisLocation var72 = var64.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var73 = var64.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var74 = var63.getLabelPosition(var73);
//     float var75 = var74.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var76 = var74.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var77 = var74.getCategoryAnchor();
//     var60.setShapeLocation(var77);
//     
//     // Checks the contract:  equals-hashcode on var54 and var64
//     assertTrue("Contract failed: equals-hashcode on var54 and var64", var54.equals(var64) ? var54.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var54
//     assertTrue("Contract failed: equals-hashcode on var64 and var54", var64.equals(var54) ? var64.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
//     boolean var4 = var0.equals((java.lang.Object)var3);
//     java.util.List var5 = var3.getBlocks();
//     java.awt.geom.Rectangle2D var6 = var3.getBounds();
//     var3.setWidth(18.0d);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.text.TextBlockAnchor var18 = null;
//     java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 100.0f, var18, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var25 = var23.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var26 = var23.getTickMarkStroke();
//     java.awt.Color var28 = java.awt.Color.decode("18");
//     float[] var29 = null;
//     float[] var30 = var28.getRGBColorComponents(var29);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var22, var26, (java.awt.Paint)var28);
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var37 = new org.jfree.chart.block.BlockContainer();
//     boolean var38 = var34.equals((java.lang.Object)var37);
//     java.util.List var39 = var37.getBlocks();
//     java.awt.geom.Rectangle2D var40 = var37.getBounds();
//     java.awt.geom.AffineTransform var41 = null;
//     java.awt.RenderingHints var42 = null;
//     java.awt.PaintContext var43 = var28.createContext(var32, var33, var40, var41, var42);
//     org.jfree.chart.text.TextBlock var48 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var49 = null;
//     org.jfree.chart.text.TextBlockAnchor var52 = null;
//     java.awt.Shape var56 = var48.calculateBounds(var49, 0.0f, 100.0f, var52, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var59 = var57.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var60 = var57.getTickMarkStroke();
//     java.awt.Color var62 = java.awt.Color.decode("18");
//     float[] var63 = null;
//     float[] var64 = var62.getRGBColorComponents(var63);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var56, var60, (java.awt.Paint)var62);
//     int var66 = var65.getSeriesIndex();
//     java.lang.Object var67 = var3.draw(var9, var40, (java.lang.Object)var66);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    boolean var15 = var13.equals((java.lang.Object)(short)10);
    java.lang.String var16 = var13.getURLText();
    java.lang.String var17 = var13.getShapeCoords();
    java.lang.String var18 = var13.getToolTipText();
    java.lang.String var19 = var13.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "-84,52,-84,52,-84,52,-84,52,-84,52,-84,52"+ "'", var17.equals("-84,52,-84,52,-84,52,-84,52,-84,52,-84,52"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var18.equals("HorizontalAlignment.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "-84,52,-84,52,-84,52,-84,52,-84,52,-84,52"+ "'", var19.equals("-84,52,-84,52,-84,52,-84,52,-84,52,-84,52"));

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var3 = new org.jfree.chart.block.BlockContainer();
    boolean var4 = var0.equals((java.lang.Object)var3);
    java.util.List var5 = var3.getBlocks();
    java.awt.geom.Rectangle2D var6 = var3.getBounds();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.block.RectangleConstraint var10 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
    org.jfree.chart.block.LengthConstraintType var11 = var10.getHeightConstraintType();
    org.jfree.chart.util.Size2D var12 = var3.arrange(var7, var10);
    var12.setHeight((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D((-1.0d), 0.0d);
    var2.setWidth(3.0d);
    var2.setHeight(1.0d);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo();
    var5.setLicenceName("");
    var5.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var10 = var5.getLibraries();
    var4.addLibrary((org.jfree.chart.ui.Library)var5);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getTextAlignment();
    boolean var14 = var4.equals((java.lang.Object)var12);
    java.lang.String var15 = var12.getToolTipText();
    org.jfree.chart.util.HorizontalAlignment var16 = var12.getHorizontalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    java.awt.Shape var8 = var0.calculateBounds(var1, 0.0f, 100.0f, var4, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    double var11 = var10.getUpperMargin();
    java.awt.Font var13 = var10.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers(0);
    java.awt.Paint var17 = var14.getOutlinePaint();
    boolean var18 = var14.isSubplot();
    var10.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var14);
    java.awt.Font var20 = var10.getLabelFont();
    org.jfree.chart.text.TextLine var21 = new org.jfree.chart.text.TextLine("hi!", var20);
    var0.addLine(var21);
    org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine();
    var0.addLine(var23);
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
    double var29 = var28.getUpperMargin();
    java.awt.Font var31 = var28.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var32 = null;
    org.jfree.chart.block.LabelBlock var33 = new org.jfree.chart.block.LabelBlock("", var31, var32);
    org.jfree.chart.text.TextFragment var34 = new org.jfree.chart.text.TextFragment("", var31);
    java.awt.Font var35 = var34.getFont();
    org.jfree.chart.plot.ValueMarker var38 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var43 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var44 = null;
    org.jfree.chart.text.TextBlockAnchor var47 = null;
    java.awt.Shape var51 = var43.calculateBounds(var44, 0.0f, 100.0f, var47, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var54 = var52.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var55 = var52.getTickMarkStroke();
    java.awt.Color var57 = java.awt.Color.decode("18");
    float[] var58 = null;
    float[] var59 = var57.getRGBColorComponents(var58);
    org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var51, var55, (java.awt.Paint)var57);
    java.lang.String var61 = var57.toString();
    var38.setPaint((java.awt.Paint)var57);
    java.awt.Color var67 = java.awt.Color.decode("18");
    float[] var68 = null;
    float[] var69 = var67.getRGBColorComponents(var68);
    float[] var70 = java.awt.Color.RGBtoHSB((-16777216), (-16777216), (-16777216), var69);
    float[] var71 = var57.getColorComponents(var69);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var72 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var74 = var72.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var75 = null;
    var72.notifyListeners(var75);
    org.jfree.chart.labels.CategoryToolTipGenerator var77 = null;
    var72.setBaseToolTipGenerator(var77, true);
    org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot();
    var81.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var84 = var81.getFixedRangeAxisSpace();
    java.awt.Paint var85 = var81.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var86 = null;
    var81.setRangeAxis(var86);
    var81.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var90 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var92 = var90.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var93 = var90.getTickMarkStroke();
    var81.setDomainGridlineStroke(var93);
    var72.setSeriesOutlineStroke(100, var93);
    org.jfree.chart.plot.ValueMarker var96 = new org.jfree.chart.plot.ValueMarker(2.0d, (java.awt.Paint)var57, var93);
    var0.addLine("[size=0.05]", var35, (java.awt.Paint)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var61 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var61.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
//     java.awt.Paint var9 = var5.getDomainGridlinePaint();
//     var0.setNoDataMessagePaint(var9);
//     boolean var11 = var0.isDomainGridlinesVisible();
//     org.jfree.chart.axis.AxisSpace var12 = null;
//     var0.setFixedRangeAxisSpace(var12);
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var29 = var27.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var30 = var27.getTickMarkStroke();
//     java.awt.Color var32 = java.awt.Color.decode("18");
//     float[] var33 = null;
//     float[] var34 = var32.getRGBColorComponents(var33);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var26, var30, (java.awt.Paint)var32);
//     java.awt.image.ColorModel var36 = null;
//     java.awt.Rectangle var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var41 = new org.jfree.chart.block.BlockContainer();
//     boolean var42 = var38.equals((java.lang.Object)var41);
//     java.util.List var43 = var41.getBlocks();
//     java.awt.geom.Rectangle2D var44 = var41.getBounds();
//     java.awt.geom.AffineTransform var45 = null;
//     java.awt.RenderingHints var46 = null;
//     java.awt.PaintContext var47 = var32.createContext(var36, var37, var44, var45, var46);
//     var0.setOutlinePaint((java.awt.Paint)var32);
//     
//     // Checks the contract:  equals-hashcode on var5 and var38
//     assertTrue("Contract failed: equals-hashcode on var5 and var38", var5.equals(var38) ? var5.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var5
//     assertTrue("Contract failed: equals-hashcode on var38 and var5", var38.equals(var5) ? var38.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    var0.setLicenceName("");
    var0.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var5 = var0.getLibraries();
    org.jfree.chart.ui.Library[] var6 = var0.getOptionalLibraries();
    java.lang.String var7 = var0.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)"ChartEntity: tooltip = null", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 0.05d, 0.5f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var18 = var15.getTickMarkStroke();
    java.awt.Color var20 = java.awt.Color.decode("18");
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
    java.lang.String var24 = var20.toString();
    var1.setPaint((java.awt.Paint)var20);
    int var26 = var20.getBlue();
    org.jfree.chart.plot.ValueMarker var31 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var36 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var37 = null;
    org.jfree.chart.text.TextBlockAnchor var40 = null;
    java.awt.Shape var44 = var36.calculateBounds(var37, 0.0f, 100.0f, var40, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var47 = var45.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var48 = var45.getTickMarkStroke();
    java.awt.Color var50 = java.awt.Color.decode("18");
    float[] var51 = null;
    float[] var52 = var50.getRGBColorComponents(var51);
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var44, var48, (java.awt.Paint)var50);
    java.lang.String var54 = var50.toString();
    var31.setPaint((java.awt.Paint)var50);
    java.awt.Color var60 = java.awt.Color.decode("18");
    float[] var61 = null;
    float[] var62 = var60.getRGBColorComponents(var61);
    float[] var63 = java.awt.Color.RGBtoHSB((-16777216), (-16777216), (-16777216), var62);
    float[] var64 = var50.getColorComponents(var62);
    float[] var65 = java.awt.Color.RGBtoHSB(100, (-16777216), 0, var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var66 = var20.getComponents(var62);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var24.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var54.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getUpperMargin();
//     java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var7 = var5.getTickLabelPaint((java.lang.Comparable)18.0d);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.text.G2TextMeasurer var10 = new org.jfree.chart.text.G2TextMeasurer(var9);
//     org.jfree.chart.text.TextBlock var11 = org.jfree.chart.text.TextUtilities.createTextBlock("[size=0.05]", var4, var7, 0.0f, (org.jfree.chart.text.TextMeasurer)var10);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.HorizontalAlignment var1 = var0.getTextAlignment();
//     double var2 = var0.getContentYOffset();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.data.Range var4 = null;
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var6 = var5.getFont();
//     java.lang.Object var7 = var5.clone();
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
//     double var11 = var10.getUpperMargin();
//     java.awt.Font var13 = var10.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var14 = null;
//     org.jfree.chart.block.LabelBlock var15 = new org.jfree.chart.block.LabelBlock("", var13, var14);
//     org.jfree.chart.text.TextFragment var16 = new org.jfree.chart.text.TextFragment("", var13);
//     java.awt.Font var17 = var16.getFont();
//     var5.setFont(var17);
//     org.jfree.chart.util.VerticalAlignment var19 = var5.getVerticalAlignment();
//     java.lang.String var20 = var19.toString();
//     org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var23 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.text.TextBlockAnchor var27 = null;
//     java.awt.Shape var31 = var23.calculateBounds(var24, 0.0f, 100.0f, var27, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var34 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var22, var31, "HorizontalAlignment.CENTER", "hi!");
//     var22.setRange(0.05d, 0.05d);
//     var22.setRangeAboutValue(0.0d, 18.0d);
//     var22.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var48 = var44.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var49 = null;
//     var44.setDrawingSupplier(var49);
//     var22.addChangeListener((org.jfree.chart.event.AxisChangeListener)var44);
//     boolean var52 = var19.equals((java.lang.Object)var22);
//     org.jfree.chart.axis.NumberAxis var54 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var54.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var59 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var60 = new org.jfree.chart.plot.PlotRenderingInfo(var59);
//     java.awt.geom.Rectangle2D var61 = var60.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot();
//     var62.clearDomainMarkers(0);
//     java.awt.Paint var65 = var62.getOutlinePaint();
//     boolean var66 = var62.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var67 = null;
//     int var68 = var62.getDomainAxisIndex(var67);
//     org.jfree.chart.axis.AxisLocation var70 = var62.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var71 = var62.getDomainAxisEdge();
//     double var72 = var54.valueToJava2D(10.0d, var61, var71);
//     org.jfree.data.Range var73 = var54.getRange();
//     var22.setRange(var73, true, true);
//     boolean var79 = var73.intersects(2.0d, 0.0d);
//     org.jfree.data.Range var82 = org.jfree.data.Range.expand(var73, 18.0d, 100.0d);
//     org.jfree.chart.block.RectangleConstraint var83 = new org.jfree.chart.block.RectangleConstraint(var4, var82);
//     org.jfree.chart.util.Size2D var84 = var0.arrange(var3, var83);
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("RectangleEdge.BOTTOM", var1, var2);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getSeriesItemLabelGenerator((-1));
//     var0.removeAnnotations();
//     boolean var6 = var0.getAutoPopulateSeriesFillPaint();
//     java.awt.Paint var8 = var0.lookupSeriesPaint(0);
//     var0.setSeriesCreateEntities(0, (java.lang.Boolean)true);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     double var14 = var13.getUpperMargin();
//     java.awt.Font var16 = var13.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearDomainMarkers(0);
//     java.awt.Paint var20 = var17.getOutlinePaint();
//     boolean var21 = var17.isSubplot();
//     var13.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var17);
//     var17.configureDomainAxes();
//     java.awt.geom.Rectangle2D var24 = null;
//     var0.drawDomainGridline(var12, var17, var24, (-1.0d));
// 
//   }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 18);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Font var12 = var11.getFont();
//     var0.setFont(var12);
//     org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
//     java.lang.String var15 = var14.toString();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
//     var17.setRange(0.05d, 0.05d);
//     var17.setRangeAboutValue(0.0d, 18.0d);
//     var17.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     boolean var47 = var14.equals((java.lang.Object)var17);
//     java.awt.Shape var48 = var17.getRightArrow();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers(0);
//     java.awt.Paint var52 = var49.getOutlinePaint();
//     boolean var53 = var49.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
//     java.awt.Paint var58 = var54.getDomainGridlinePaint();
//     var49.setNoDataMessagePaint(var58);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
//     java.awt.Graphics2D var61 = null;
//     org.jfree.chart.title.TextTitle var62 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var63 = var62.getFont();
//     java.awt.Paint var64 = var62.getBackgroundPaint();
//     java.awt.geom.Rectangle2D var65 = var62.getBounds();
//     var60.draw(var61, var65);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("[size=0.05]", "HorizontalAlignment.CENTER", "AxisLocation.TOP_OR_LEFT", "ChartEntity: tooltip = null");

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    var0.setIncludeBaseInRange(true);
    java.awt.Paint var24 = var0.getItemOutlinePaint((-1), 0);
    var0.setSeriesVisible(10, (java.lang.Boolean)false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = var0.getString("AxisLocation.BOTTOM_OR_RIGHT");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var0.add((-1.0d), 4.0d, (java.lang.Comparable)"[size=0.05]", (java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
    java.lang.String var9 = var7.valueToString(18.0d);
    double var10 = var7.getSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var11 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)var10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "18"+ "'", var9.equals("18"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(0.0d);
//     org.jfree.chart.axis.NumberAxis var7 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var7.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var12 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var13 = new org.jfree.chart.plot.PlotRenderingInfo(var12);
//     java.awt.geom.Rectangle2D var14 = var13.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
//     var15.clearDomainMarkers(0);
//     java.awt.Paint var18 = var15.getOutlinePaint();
//     boolean var19 = var15.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var20 = null;
//     int var21 = var15.getDomainAxisIndex(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var15.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var24 = var15.getDomainAxisEdge();
//     double var25 = var7.valueToJava2D(10.0d, var14, var24);
//     org.jfree.data.Range var26 = var7.getRange();
//     org.jfree.chart.block.RectangleConstraint var27 = var5.toRangeWidth(var26);
//     java.lang.String var28 = var26.toString();
//     org.jfree.data.Range var29 = null;
//     org.jfree.data.Range var30 = null;
//     org.jfree.chart.block.RectangleConstraint var31 = new org.jfree.chart.block.RectangleConstraint(var29, var30);
//     org.jfree.chart.block.LengthConstraintType var32 = var31.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var34 = var31.toFixedWidth(0.0d);
//     org.jfree.chart.axis.NumberAxis var36 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var36.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var41 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var42 = new org.jfree.chart.plot.PlotRenderingInfo(var41);
//     java.awt.geom.Rectangle2D var43 = var42.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot();
//     var44.clearDomainMarkers(0);
//     java.awt.Paint var47 = var44.getOutlinePaint();
//     boolean var48 = var44.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var49 = null;
//     int var50 = var44.getDomainAxisIndex(var49);
//     org.jfree.chart.axis.AxisLocation var52 = var44.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var53 = var44.getDomainAxisEdge();
//     double var54 = var36.valueToJava2D(10.0d, var43, var53);
//     org.jfree.data.Range var55 = var36.getRange();
//     org.jfree.chart.block.RectangleConstraint var56 = var34.toRangeWidth(var55);
//     org.jfree.chart.block.RectangleConstraint var57 = new org.jfree.chart.block.RectangleConstraint(var26, var55);
//     
//     // Checks the contract:  equals-hashcode on var13 and var42
//     assertTrue("Contract failed: equals-hashcode on var13 and var42", var13.equals(var42) ? var13.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var13
//     assertTrue("Contract failed: equals-hashcode on var42 and var13", var42.equals(var13) ? var42.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var44
//     assertTrue("Contract failed: equals-hashcode on var15 and var44", var15.equals(var44) ? var15.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var15
//     assertTrue("Contract failed: equals-hashcode on var44 and var15", var44.equals(var15) ? var44.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var8.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var11 = null;
    var8.notifyListeners(var11);
    var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var8, false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var8.getBasePositiveItemLabelPosition();
    var8.setSeriesItemLabelsVisible(1, true);
    var8.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var6 = var4.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     org.jfree.chart.urls.CategoryURLGenerator var9 = var4.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var12 = var4.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var13 = var12.getRotationAnchor();
//     java.lang.String var14 = var13.toString();
//     java.awt.geom.Rectangle2D var15 = org.jfree.chart.text.TextUtilities.drawAlignedString("[size=0.05]", var1, 0.8f, 1.0f, var13);
// 
//   }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var0.setLowerMargin(1.0d);
    double var5 = var0.getCategoryMargin();
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder(1.0d, 100.0d, (-1.0d), 4.0d);
    java.awt.Paint var11 = var10.getPaint();
    var0.setTickLabelPaint(var11);
    var0.configure();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
    double var3 = var2.getUpperMargin();
    java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var6 = null;
    org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
    org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
    double var9 = var8.getUpperMargin();
    java.awt.Font var11 = var8.getTickLabelFont((java.lang.Comparable)10.0d);
    var7.setFont(var11);
    java.awt.Font var13 = var7.getFont();
    var0.add((org.jfree.chart.block.Block)var7, (java.lang.Object)1);
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var19 = new org.jfree.chart.block.BlockContainer();
    boolean var20 = var16.equals((java.lang.Object)var19);
    java.util.List var21 = var19.getBlocks();
    java.awt.geom.Rectangle2D var22 = var19.getBounds();
    var19.setWidth(18.0d);
    java.awt.Graphics2D var25 = null;
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(1.0d, 2.0d);
    org.jfree.chart.block.RectangleConstraint var29 = var28.toUnconstrainedHeight();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var30 = var0.arrange(var19, var25, var28);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var1.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
    boolean var7 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.plot.ValueMarker var10 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var15 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.text.TextBlockAnchor var19 = null;
    java.awt.Shape var23 = var15.calculateBounds(var16, 0.0f, 100.0f, var19, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var27 = var24.getTickMarkStroke();
    java.awt.Color var29 = java.awt.Color.decode("18");
    float[] var30 = null;
    float[] var31 = var29.getRGBColorComponents(var30);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var23, var27, (java.awt.Paint)var29);
    java.lang.String var33 = var29.toString();
    var10.setPaint((java.awt.Paint)var29);
    java.awt.Color var39 = java.awt.Color.decode("18");
    float[] var40 = null;
    float[] var41 = var39.getRGBColorComponents(var40);
    float[] var42 = java.awt.Color.RGBtoHSB((-16777216), (-16777216), (-16777216), var41);
    float[] var43 = var29.getColorComponents(var41);
    java.awt.color.ColorSpace var44 = var29.getColorSpace();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-16777216), (java.awt.Paint)var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var33.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    var31.setBorderVisible(false);
    var31.removeLegend();
    org.jfree.chart.event.ChartChangeListener var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.removeChangeListener(var39);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var17 = var14.getFixedRangeAxisSpace();
    java.awt.Paint var18 = var14.getDomainGridlinePaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var19 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var21 = var19.getSeriesVisible((-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var22 = null;
    var19.setLegendItemToolTipGenerator(var22);
    org.jfree.chart.util.PaintList var26 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var29 = var27.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var27.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var32 = var27.getTickLabelInsets();
    boolean var33 = var26.equals((java.lang.Object)var27);
    java.awt.Font var35 = var27.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    var36.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var39 = var36.getFixedRangeAxisSpace();
    java.awt.Paint var40 = var36.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var41 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var35, var40);
    var19.setSeriesItemLabelPaint(0, var40);
    var14.setBackgroundPaint(var40);
    int var44 = var14.getWeight();
    boolean var45 = var13.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    var0.setItemMargin(18.0d);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
    double var6 = var0.getItemMargin();
    java.awt.Paint var8 = var0.getSeriesOutlinePaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 18.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var3 = null;
//     var0.setGradientPaintTransformer(var3);
//     java.awt.Shape var6 = var0.lookupSeriesShape((-16777216));
//     org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getSeriesToolTipGenerator((-16777198));
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.ChartRenderingInfo var10 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getDataArea();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     double var14 = var13.getUpperMargin();
//     java.awt.Font var16 = var13.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot();
//     var17.clearDomainMarkers(0);
//     var13.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var17);
//     java.awt.Stroke var21 = var17.getOutlineStroke();
//     org.jfree.chart.ChartRenderingInfo var23 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = new org.jfree.chart.plot.PlotRenderingInfo(var23);
//     java.awt.geom.Rectangle2D var25 = var24.getDataArea();
//     org.jfree.chart.renderer.category.CategoryItemRendererState var26 = var0.initialise(var9, var12, var17, 15, var24);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
    java.awt.Paint var9 = var5.getDomainGridlinePaint();
    var0.setNoDataMessagePaint(var9);
    var0.setWeight(0);
    java.lang.String var13 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Category Plot"+ "'", var13.equals("Category Plot"));

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     var4.setDomainGridlinesVisible(true);
//     org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var13 = var11.getTickLabelPaint((java.lang.Comparable)18.0d);
//     var4.setDomainAxis(18, var11, false);
//     org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
//     var16.clearDomainMarkers(0);
//     java.awt.Paint var19 = var16.getOutlinePaint();
//     boolean var20 = var16.isSubplot();
//     org.jfree.chart.axis.CategoryAnchor var21 = var16.getDomainGridlinePosition();
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
//     var24.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var27 = new org.jfree.chart.block.BlockContainer();
//     boolean var28 = var24.equals((java.lang.Object)var27);
//     java.util.List var29 = var27.getBlocks();
//     java.awt.geom.Rectangle2D var30 = var27.getBounds();
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var11.getCategoryJava2DCoordinate(var21, 18, 15, var30, var31);
//     
//     // Checks the contract:  equals-hashcode on var16 and var24
//     assertTrue("Contract failed: equals-hashcode on var16 and var24", var16.equals(var24) ? var16.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var16
//     assertTrue("Contract failed: equals-hashcode on var24 and var16", var24.equals(var16) ? var24.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("HorizontalAlignment.CENTER", "AxisLabelEntity: label = hi!", "Range[0.0,1.0]", "java.awt.Color[r=0,g=0,b=18]", "RectangleEdge.BOTTOM");

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    java.util.List var2 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=0,g=0,b=18]", var1);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
//     java.lang.Object var1 = var0.clone();
//     java.awt.Shape var3 = var0.getShape(18);
//     java.lang.Object var4 = var0.clone();
//     
//     // Checks the contract:  equals-hashcode on var1 and var4
//     assertTrue("Contract failed: equals-hashcode on var1 and var4", var1.equals(var4) ? var1.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var1
//     assertTrue("Contract failed: equals-hashcode on var4 and var1", var4.equals(var1) ? var4.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var14 = var10.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var15 = null;
    var10.setDrawingSupplier(var15);
    org.jfree.chart.axis.CategoryAxis var17 = var10.getDomainAxis();
    java.util.List var18 = var10.getAnnotations();
    org.jfree.chart.axis.NumberAxis var20 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    var6.drawRangeMarker(var9, var10, (org.jfree.chart.axis.ValueAxis)var20, var21, var22);
    var6.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var26 = var6.getBaseStroke();
    org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
    var27.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var30 = var27.getFixedRangeAxisSpace();
    java.awt.Paint var31 = var27.getDomainGridlinePaint();
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("HorizontalAlignment.CENTER", "hi!", "", "", var5, var26, var31);
    org.jfree.chart.util.RectangleAnchor var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, var33, 6.0d, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var3 = var1.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var1.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var6 = var1.getTickLabelInsets();
    boolean var7 = var0.equals((java.lang.Object)var1);
    org.jfree.data.KeyedObjects2D var8 = new org.jfree.data.KeyedObjects2D();
    java.util.List var9 = var8.getColumnKeys();
    int var11 = var8.getColumnIndex((java.lang.Comparable)"AxisLabelEntity: label = hi!");
    boolean var12 = var0.equals((java.lang.Object)"AxisLabelEntity: label = hi!");
    org.jfree.chart.util.StrokeList var13 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var15 = var14.getFont();
    java.lang.Object var16 = var14.clone();
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    double var20 = var19.getUpperMargin();
    java.awt.Font var22 = var19.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var23 = null;
    org.jfree.chart.block.LabelBlock var24 = new org.jfree.chart.block.LabelBlock("", var22, var23);
    org.jfree.chart.text.TextFragment var25 = new org.jfree.chart.text.TextFragment("", var22);
    java.awt.Font var26 = var25.getFont();
    var14.setFont(var26);
    org.jfree.chart.util.VerticalAlignment var28 = var14.getVerticalAlignment();
    boolean var29 = var13.equals((java.lang.Object)var14);
    boolean var30 = var0.equals((java.lang.Object)var29);
    java.awt.Color var33 = java.awt.Color.decode("18");
    var0.setPaint(100, (java.awt.Paint)var33);
    int var35 = var0.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 101);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    java.lang.Comparable var0 = null;
    org.jfree.data.KeyedObjects2D var1 = new org.jfree.data.KeyedObjects2D();
    java.util.List var2 = var1.getColumnKeys();
    org.jfree.data.KeyedObject var3 = new org.jfree.data.KeyedObject(var0, (java.lang.Object)var1);
    java.lang.Object var4 = var1.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var1.getRowKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    var0.clearCategoryLabelToolTips();
    double var5 = var0.getLabelAngle();
    var0.setLowerMargin(2.0d);
    double var8 = var0.getFixedDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var6.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var9 = null;
    var6.setGradientPaintTransformer(var9);
    java.awt.Shape var12 = var6.lookupSeriesShape((-16777216));
    double var13 = var6.getItemMargin();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-16777216), (org.jfree.chart.renderer.category.CategoryItemRenderer)var6, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.LegendItemCollection var0 = new org.jfree.chart.LegendItemCollection();
    java.lang.Object var1 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    var0.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    boolean var8 = var0.isDomainZoomable();
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.data.general.DatasetChangeEvent var11 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)(byte)10, var10);
    var0.datasetChanged(var11);
    java.lang.Object var13 = var11.getSource();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + (byte)10+ "'", var13.equals((byte)10));

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-1));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("AxisLocation.BOTTOM_OR_RIGHT", "", "java.awt.Color[r=0,g=0,b=18]", "");

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    java.awt.Paint var3 = var0.lookupSeriesOutlinePaint(0);
    java.awt.Font var6 = var0.getItemLabelFont(0, 101);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    var0.clearCategoryLabelToolTips();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var7 = var5.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var8 = null;
    var5.setGradientPaintTransformer(var8);
    var5.setAutoPopulateSeriesStroke(true);
    boolean var12 = var0.equals((java.lang.Object)true);
    java.awt.Paint var13 = var0.getTickMarkPaint();
    org.jfree.chart.plot.Plot var14 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var4.setDomainGridlinesVisible(false);
    org.jfree.chart.block.LineBorder var20 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var21 = var20.getInsets();
    java.awt.Stroke var22 = var20.getStroke();
    var4.setDomainGridlineStroke(var22);
    org.jfree.chart.plot.CategoryMarker var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.addDomainMarker(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     org.jfree.chart.axis.CategoryAxis var8 = new org.jfree.chart.axis.CategoryAxis();
//     double var9 = var8.getUpperMargin();
//     java.awt.Font var11 = var8.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearDomainMarkers(0);
//     java.awt.Paint var15 = var12.getOutlinePaint();
//     boolean var16 = var12.isSubplot();
//     var8.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var12);
//     org.jfree.chart.util.SortOrder var18 = var12.getColumnRenderingOrder();
//     var4.setColumnRenderingOrder(var18);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var5 = null;
//     var2.notifyListeners(var5);
//     org.jfree.chart.urls.CategoryURLGenerator var7 = var2.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var11 = var10.getRotationAnchor();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var14 = var12.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var15 = null;
//     var12.notifyListeners(var15);
//     org.jfree.chart.urls.CategoryURLGenerator var17 = var12.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var20 = var12.getPositiveItemLabelPosition((-16777216), (-16777216));
//     org.jfree.chart.text.TextAnchor var21 = var20.getRotationAnchor();
//     java.lang.String var22 = var21.toString();
//     org.jfree.chart.axis.NumberTick var24 = new org.jfree.chart.axis.NumberTick((java.lang.Number)1L, "", var11, var21, 100.0d);
//     
//     // Checks the contract:  equals-hashcode on var10 and var20
//     assertTrue("Contract failed: equals-hashcode on var10 and var20", var10.equals(var20) ? var10.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var10
//     assertTrue("Contract failed: equals-hashcode on var20 and var10", var20.equals(var10) ? var20.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
    org.jfree.chart.text.TextBlock var10 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.text.TextBlockAnchor var14 = null;
    java.awt.Shape var18 = var10.calculateBounds(var11, 0.0f, 100.0f, var14, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var19 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var21 = var19.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var22 = var19.getTickMarkStroke();
    java.awt.Color var24 = java.awt.Color.decode("18");
    float[] var25 = null;
    float[] var26 = var24.getRGBColorComponents(var25);
    org.jfree.chart.LegendItem var27 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var18, var22, (java.awt.Paint)var24);
    java.lang.String var28 = var27.getToolTipText();
    org.jfree.chart.util.GradientPaintTransformer var29 = var27.getFillPaintTransformer();
    var0.setGradientPaintTransformer(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + ""+ "'", var28.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
//     var1.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var4 = new org.jfree.chart.block.BlockContainer();
//     boolean var5 = var1.equals((java.lang.Object)var4);
//     java.util.List var6 = var4.getBlocks();
//     java.awt.geom.Rectangle2D var7 = var4.getBounds();
//     var4.setWidth(18.0d);
//     org.jfree.chart.block.CenterArrangement var10 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     double var13 = var12.getUpperMargin();
//     java.awt.Font var15 = var12.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var16 = null;
//     org.jfree.chart.block.LabelBlock var17 = new org.jfree.chart.block.LabelBlock("", var15, var16);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     java.awt.Font var21 = var18.getTickLabelFont((java.lang.Comparable)10.0d);
//     var17.setFont(var21);
//     java.awt.Font var23 = var17.getFont();
//     var10.add((org.jfree.chart.block.Block)var17, (java.lang.Object)1);
//     var4.setArrangement((org.jfree.chart.block.Arrangement)var10);
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var30 = new org.jfree.chart.block.BlockContainer();
//     boolean var31 = var27.equals((java.lang.Object)var30);
//     java.util.List var32 = var30.getBlocks();
//     java.awt.geom.Rectangle2D var33 = var30.getBounds();
//     var30.setWidth(18.0d);
//     org.jfree.chart.block.CenterArrangement var36 = new org.jfree.chart.block.CenterArrangement();
//     org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
//     double var39 = var38.getUpperMargin();
//     java.awt.Font var41 = var38.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var42 = null;
//     org.jfree.chart.block.LabelBlock var43 = new org.jfree.chart.block.LabelBlock("", var41, var42);
//     org.jfree.chart.axis.CategoryAxis var44 = new org.jfree.chart.axis.CategoryAxis();
//     double var45 = var44.getUpperMargin();
//     java.awt.Font var47 = var44.getTickLabelFont((java.lang.Comparable)10.0d);
//     var43.setFont(var47);
//     java.awt.Font var49 = var43.getFont();
//     var36.add((org.jfree.chart.block.Block)var43, (java.lang.Object)1);
//     var30.setArrangement((org.jfree.chart.block.Arrangement)var36);
//     var36.clear();
//     org.jfree.chart.title.LegendTitle var54 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var10, (org.jfree.chart.block.Arrangement)var36);
//     
//     // Checks the contract:  equals-hashcode on var1 and var27
//     assertTrue("Contract failed: equals-hashcode on var1 and var27", var1.equals(var27) ? var1.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var1
//     assertTrue("Contract failed: equals-hashcode on var27 and var1", var27.equals(var1) ? var27.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var36
//     assertTrue("Contract failed: equals-hashcode on var10 and var36", var10.equals(var36) ? var10.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var10
//     assertTrue("Contract failed: equals-hashcode on var36 and var10", var36.equals(var10) ? var36.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var43
//     assertTrue("Contract failed: equals-hashcode on var17 and var43", var17.equals(var43) ? var17.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var17
//     assertTrue("Contract failed: equals-hashcode on var43 and var17", var43.equals(var17) ? var43.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
    var0.setArrangement((org.jfree.chart.block.Arrangement)var1);
    java.lang.Object var3 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var2 = var0.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var0.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var5 = var0.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var6.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var11 = var6.getTickLabelInsets();
    var0.setLabelInsets(var11);
    java.lang.String var13 = var0.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("HorizontalAlignment.CENTER");
//     java.lang.Object var2 = var1.clone();
//     java.lang.Object var3 = var1.clone();
//     
//     // Checks the contract:  equals-hashcode on var2 and var3
//     assertTrue("Contract failed: equals-hashcode on var2 and var3", var2.equals(var3) ? var2.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var2
//     assertTrue("Contract failed: equals-hashcode on var3 and var2", var3.equals(var2) ? var3.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.labels.CategoryItemLabelGenerator var1 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator(1, (-1));
    boolean var5 = var0.getBaseCreateEntities();
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
    var0.setSeriesShape(0, var8);
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.clearDomainMarkers(0);
    java.awt.Paint var13 = var10.getOutlinePaint();
    boolean var14 = var10.isSubplot();
    org.jfree.chart.axis.CategoryAxis var15 = null;
    int var16 = var10.getDomainAxisIndex(var15);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var10.getDomainMarkers(10, var18);
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Shape var22 = var0.getItemShape((-1), 100);
    var0.setMaximumBarWidth(6.0d);
    double var25 = var0.getUpperClip();
    boolean var28 = var0.isItemLabelVisible(0, (-16777198));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var5 = var0.getRangeAxisLocation((-16777216));
//     org.jfree.chart.axis.AxisSpace var6 = var0.getFixedRangeAxisSpace();
//     java.awt.Image var7 = null;
//     var0.setBackgroundImage(var7);
//     boolean var9 = var0.isOutlineVisible();
//     org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var16 = var14.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var17 = var14.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     java.awt.Font var21 = var18.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var22 = var18.getCategoryLabelPositions();
//     org.jfree.chart.axis.NumberTickUnit var24 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     java.lang.String var26 = var24.valueToString(18.0d);
//     double var27 = var24.getSize();
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot();
//     var28.clearDomainMarkers(0);
//     java.awt.Paint var31 = var28.getOutlinePaint();
//     java.awt.Paint var32 = var28.getNoDataMessagePaint();
//     var18.setTickLabelPaint((java.lang.Comparable)var27, var32);
//     var14.setTickMarkPaint(var32);
//     org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, 0.0d, 1.0d, 100.0d, var32);
//     var0.setNoDataMessagePaint(var32);
//     
//     // Checks the contract:  equals-hashcode on var0 and var28
//     assertTrue("Contract failed: equals-hashcode on var0 and var28", var0.equals(var28) ? var0.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var0
//     assertTrue("Contract failed: equals-hashcode on var28 and var0", var28.equals(var0) ? var28.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    java.awt.Shape var17 = var9.calculateBounds(var10, 0.0f, 100.0f, var13, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var20 = var18.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var21 = var18.getTickMarkStroke();
    java.awt.Color var23 = java.awt.Color.decode("18");
    float[] var24 = null;
    float[] var25 = var23.getRGBColorComponents(var24);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var17, var21, (java.awt.Paint)var23);
    java.awt.Color var29 = java.awt.Color.decode("18");
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var34 = var31.getFixedRangeAxisSpace();
    java.awt.Paint var35 = var31.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    var36.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var39 = var36.getFixedRangeAxisSpace();
    java.awt.Paint var40 = var36.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var41 = null;
    var36.setRangeAxis(var41);
    var36.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var47 = var45.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var48 = var45.getTickMarkStroke();
    var36.setDomainGridlineStroke(var48);
    org.jfree.chart.text.TextBlock var51 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.text.TextBlockAnchor var55 = null;
    java.awt.Shape var59 = var51.calculateBounds(var52, 0.0f, 100.0f, var55, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var60 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var62 = var60.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var63 = null;
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
    var64.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var68 = var64.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var69 = null;
    var64.setDrawingSupplier(var69);
    org.jfree.chart.axis.CategoryAxis var71 = var64.getDomainAxis();
    java.util.List var72 = var64.getAnnotations();
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var75 = null;
    java.awt.geom.Rectangle2D var76 = null;
    var60.drawRangeMarker(var63, var64, (org.jfree.chart.axis.ValueAxis)var74, var75, var76);
    var60.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var80 = var60.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis();
    double var82 = var81.getUpperMargin();
    java.awt.Font var84 = var81.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var85 = var81.isTickMarksVisible();
    java.awt.Paint var86 = var81.getAxisLinePaint();
    org.jfree.chart.LegendItem var87 = new org.jfree.chart.LegendItem("18", "18", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", false, var17, false, (java.awt.Paint)var29, false, var35, var48, false, var59, var80, var86);
    org.jfree.chart.block.BlockBorder var88 = new org.jfree.chart.block.BlockBorder(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
//     var2.clearDomainMarkers(0);
//     java.awt.Paint var5 = var2.getOutlinePaint();
//     boolean var6 = var2.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var7 = null;
//     int var8 = var2.getDomainAxisIndex(var7);
//     org.jfree.chart.axis.AxisLocation var10 = var2.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var11 = var2.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var12 = var1.getLabelPosition(var11);
//     float var13 = var12.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var14 = var12.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var15 = var12.getCategoryAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var17 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     var18.clearDomainMarkers(0);
//     java.awt.Paint var21 = var18.getOutlinePaint();
//     boolean var22 = var18.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     int var24 = var18.getDomainAxisIndex(var23);
//     org.jfree.chart.axis.AxisLocation var26 = var18.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var27 = var18.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var28 = var17.getLabelPosition(var27);
//     float var29 = var28.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var30 = var28.getLabelAnchor();
//     org.jfree.chart.plot.ValueMarker var32 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextBlock var37 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var38 = null;
//     org.jfree.chart.text.TextBlockAnchor var41 = null;
//     java.awt.Shape var45 = var37.calculateBounds(var38, 0.0f, 100.0f, var41, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var46 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var48 = var46.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var49 = var46.getTickMarkStroke();
//     java.awt.Color var51 = java.awt.Color.decode("18");
//     float[] var52 = null;
//     float[] var53 = var51.getRGBColorComponents(var52);
//     org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var45, var49, (java.awt.Paint)var51);
//     java.lang.String var55 = var51.toString();
//     var32.setPaint((java.awt.Paint)var51);
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot();
//     var57.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var60 = var57.getFixedRangeAxisSpace();
//     var57.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.event.MarkerChangeEvent var63 = null;
//     var57.markerChanged(var63);
//     boolean var65 = var57.isDomainZoomable();
//     var32.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var57);
//     org.jfree.chart.text.TextAnchor var67 = var32.getLabelTextAnchor();
//     org.jfree.chart.axis.CategoryLabelPositions var70 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
//     org.jfree.chart.axis.CategoryLabelPosition var71 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var72 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var70, var71);
//     org.jfree.chart.axis.CategoryLabelWidthType var73 = var71.getWidthType();
//     org.jfree.chart.axis.CategoryLabelPosition var75 = new org.jfree.chart.axis.CategoryLabelPosition(var15, var30, var67, 1.0d, var73, 10.0f);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("", var1, var2);
// 
//   }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getTextAlignment();
    double var2 = var0.getContentYOffset();
    boolean var3 = var0.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    int var34 = var31.getBackgroundImageAlignment();
    org.jfree.chart.ChartRenderingInfo var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var39 = var31.createBufferedImage(0, 1, 100, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 15);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var5 = null;
    var0.setRangeAxis(var5);
    var0.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var11 = var9.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var12 = var9.getTickMarkStroke();
    var0.setDomainGridlineStroke(var12);
    org.jfree.chart.util.SortOrder var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRowRenderingOrder(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    var0.setMaximumCategoryLabelLines(0);
    var0.removeCategoryLabelToolTip((java.lang.Comparable)(short)100);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var8 = var6.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var6.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var11 = var6.getTickLabelInsets();
    double var13 = var11.calculateLeftOutset(0.0d);
    var0.setLabelInsets(var11);
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot();
    var15.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var19 = var15.getRangeAxisForDataset(0);
    var15.setAnchorValue(0.0d, true);
    boolean var23 = var11.equals((java.lang.Object)true);
    double var25 = var11.calculateRightInset(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 4.0d);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    boolean var5 = var0.isRangeGridlinesVisible();
    org.jfree.chart.event.MarkerChangeEvent var6 = null;
    var0.markerChanged(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.text.TextFragment var1 = new org.jfree.chart.text.TextFragment("");

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Font var12 = var11.getFont();
//     var0.setFont(var12);
//     org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
//     java.lang.String var15 = var14.toString();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
//     var17.setRange(0.05d, 0.05d);
//     var17.setRangeAboutValue(0.0d, 18.0d);
//     var17.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     boolean var47 = var14.equals((java.lang.Object)var17);
//     java.awt.Shape var48 = var17.getRightArrow();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers(0);
//     java.awt.Paint var52 = var49.getOutlinePaint();
//     boolean var53 = var49.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
//     java.awt.Paint var58 = var54.getDomainGridlinePaint();
//     var49.setNoDataMessagePaint(var58);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
//     boolean var61 = var60.isShapeFilled();
//     java.awt.Stroke var62 = var60.getLineStroke();
//     org.jfree.chart.axis.CategoryLabelPositions var64 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
//     var65.clearDomainMarkers(0);
//     java.awt.Paint var68 = var65.getOutlinePaint();
//     boolean var69 = var65.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var70 = null;
//     int var71 = var65.getDomainAxisIndex(var70);
//     org.jfree.chart.axis.AxisLocation var73 = var65.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var74 = var65.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var75 = var64.getLabelPosition(var74);
//     float var76 = var75.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var77 = var75.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var78 = var75.getCategoryAnchor();
//     var60.setShapeAnchor(var78);
//     
//     // Checks the contract:  equals-hashcode on var54 and var65
//     assertTrue("Contract failed: equals-hashcode on var54 and var65", var54.equals(var65) ? var54.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var54
//     assertTrue("Contract failed: equals-hashcode on var65 and var54", var65.equals(var54) ? var65.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    var0.setMaximumCategoryLabelLines(0);
    var0.addCategoryLabelToolTip((java.lang.Comparable)0L, "18");
    var0.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.setOutlineVisible(false);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("Range[0.0,1.0]");

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setUpperMargin(2.0d);
    var1.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.NumberTickUnit var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    java.awt.Paint var3 = var0.getOutlinePaint();
    boolean var4 = var0.isSubplot();
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var8 = var5.getFixedRangeAxisSpace();
    java.awt.Paint var9 = var5.getDomainGridlinePaint();
    var0.setNoDataMessagePaint(var9);
    org.jfree.chart.event.PlotChangeEvent var11 = null;
    var0.notifyListeners(var11);
    org.jfree.chart.event.PlotChangeEvent var13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var18 = var14.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var19 = null;
    var14.setDrawingSupplier(var19);
    java.awt.Image var21 = null;
    var14.setBackgroundImage(var21);
    var14.setBackgroundImageAlpha(1.0f);
    float var25 = var14.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var27 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var28 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.text.TextBlockAnchor var32 = null;
    java.awt.Shape var36 = var28.calculateBounds(var29, 0.0f, 100.0f, var32, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var39 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var27, var36, "HorizontalAlignment.CENTER", "hi!");
    var27.setRange(0.05d, 0.05d);
    var27.setRangeAboutValue(0.0d, 18.0d);
    var27.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
    var49.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var53 = var49.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var54 = null;
    var49.setDrawingSupplier(var54);
    var27.addChangeListener((org.jfree.chart.event.AxisChangeListener)var49);
    org.jfree.chart.JFreeChart var57 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var49);
    float var58 = var57.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var59 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var14, var57);
    org.jfree.chart.event.ChartChangeEventType var60 = var59.getType();
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis();
    double var62 = var61.getUpperMargin();
    java.awt.Font var64 = var61.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    var65.clearDomainMarkers(0);
    var61.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var65);
    var65.setDomainGridlinesVisible(true);
    org.jfree.chart.renderer.category.CategoryItemRenderer var72 = var65.getRenderer(1);
    boolean var73 = var60.equals((java.lang.Object)1);
    var13.setType(var60);
    java.lang.String var75 = var60.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var75.equals("ChartChangeEventType.GENERAL"));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.axis.AxisState var1 = new org.jfree.chart.axis.AxisState(Double.NaN);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var10 = var6.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var11 = null;
    var6.setDrawingSupplier(var11);
    org.jfree.chart.axis.CategoryAxis var13 = var6.getDomainAxis();
    java.util.List var14 = var6.getAnnotations();
    org.jfree.chart.axis.NumberAxis var16 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    var2.drawRangeMarker(var5, var6, (org.jfree.chart.axis.ValueAxis)var16, var17, var18);
    var0.setObject((java.lang.Object)var5, (java.lang.Comparable)100.0d, (java.lang.Comparable)"AxisLabelEntity: label = hi!");
    java.util.List var23 = var0.getColumnKeys();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo();
    var5.setLicenceName("");
    var5.setCopyright("hi!");
    org.jfree.chart.ui.Library[] var10 = var5.getLibraries();
    var4.addLibrary((org.jfree.chart.ui.Library)var5);
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var13 = var12.getTextAlignment();
    boolean var14 = var4.equals((java.lang.Object)var12);
    var12.setID("java.awt.Color[r=0,g=0,b=18]");
    java.awt.Paint var17 = var12.getBackgroundPaint();
    var12.setExpandToFitSpace(true);
    org.jfree.chart.util.RectangleInsets var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setMargin(var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test411() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Shape var22 = var0.getItemShape((-1), 100);
    var0.setMaximumBarWidth(6.0d);
    double var25 = var0.getUpperClip();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelsVisible((-16777198), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.resources.JFreeChartResources var0 = new org.jfree.chart.resources.JFreeChartResources();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = var0.getObject("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(1.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var0.setDrawingSupplier(var5);
    java.awt.Image var7 = null;
    var0.setBackgroundImage(var7);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getUpperMargin();
    java.awt.Font var12 = var9.getTickLabelFont((java.lang.Comparable)(short)10);
    var0.setNoDataMessageFont(var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var0.setFixedLegendItems(var14);
    org.jfree.chart.title.TextTitle var16 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var17 = var16.getFont();
    java.lang.Object var18 = var16.clone();
    org.jfree.chart.util.HorizontalAlignment var19 = var16.getHorizontalAlignment();
    java.awt.Paint var20 = var16.getPaint();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    var21.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var25 = var21.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var26 = null;
    var21.setDrawingSupplier(var26);
    java.awt.Image var28 = null;
    var21.setBackgroundImage(var28);
    var21.setBackgroundImageAlpha(1.0f);
    float var32 = var21.getForegroundAlpha();
    org.jfree.chart.axis.NumberAxis var34 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var35 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var36 = null;
    org.jfree.chart.text.TextBlockAnchor var39 = null;
    java.awt.Shape var43 = var35.calculateBounds(var36, 0.0f, 100.0f, var39, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var46 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var34, var43, "HorizontalAlignment.CENTER", "hi!");
    var34.setRange(0.05d, 0.05d);
    var34.setRangeAboutValue(0.0d, 18.0d);
    var34.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
    var56.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var61 = null;
    var56.setDrawingSupplier(var61);
    var34.addChangeListener((org.jfree.chart.event.AxisChangeListener)var56);
    org.jfree.chart.JFreeChart var64 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var56);
    float var65 = var64.getBackgroundImageAlpha();
    org.jfree.chart.event.ChartChangeEvent var66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var21, var64);
    java.awt.RenderingHints var67 = var64.getRenderingHints();
    var16.addChangeListener((org.jfree.chart.event.TitleChangeListener)var64);
    var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var64);
    java.lang.Object var70 = var64.getTextAntiAlias();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.chart.axis.NumberTickUnit var1 = new org.jfree.chart.axis.NumberTickUnit(6.0d);
    java.lang.String var3 = var1.valueToString(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "0"+ "'", var3.equals("0"));

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    var0.setIncludeBaseInRange(true);
    org.jfree.chart.LegendItem var24 = var0.getLegendItem(0, 10);
    java.awt.Paint var26 = null;
    var0.setSeriesPaint(10, var26);
    org.jfree.chart.LegendItem var30 = var0.getLegendItem(100, 10);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var0.setBaseURLGenerator(var31);
    org.jfree.chart.urls.CategoryURLGenerator var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesURLGenerator((-16777216), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.axis.AxisLocation var6 = var0.getRangeAxisLocation(100);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     var8.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var11 = new org.jfree.chart.block.BlockContainer();
//     boolean var12 = var8.equals((java.lang.Object)var11);
//     java.util.List var13 = var11.getBlocks();
//     java.awt.geom.Rectangle2D var14 = var11.getBounds();
//     var0.drawOutline(var7, var14);
// 
//   }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(0.05d, 0.05d, var2);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var5 = null;
    var0.setRangeAxis(var5);
    var0.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var11 = var9.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var12 = var9.getTickMarkStroke();
    var0.setDomainGridlineStroke(var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var0.setFixedLegendItems(var14);
    org.jfree.chart.plot.DrawingSupplier var16 = var0.getDrawingSupplier();
    org.jfree.chart.util.RectangleEdge var18 = var0.getDomainAxisEdge(0);
    boolean var19 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
    org.jfree.chart.labels.ItemLabelPosition var8 = var0.getPositiveItemLabelPosition((-16777216), (-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var11 = var9.getSeriesVisible((-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var12 = null;
    var9.setLegendItemToolTipGenerator(var12);
    org.jfree.chart.util.PaintList var16 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var19 = var17.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var17.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var22 = var17.getTickLabelInsets();
    boolean var23 = var16.equals((java.lang.Object)var17);
    java.awt.Font var25 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
    java.awt.Paint var30 = var26.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var25, var30);
    var9.setSeriesItemLabelPaint(0, var30);
    var9.setBaseSeriesVisibleInLegend(false, true);
    java.awt.Stroke var37 = var9.getSeriesStroke(4);
    var9.setSeriesItemLabelsVisible(0, true);
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
    double var42 = var41.getUpperMargin();
    java.awt.Font var44 = var41.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var45 = var41.isTickMarksVisible();
    java.awt.Paint var47 = var41.getTickLabelPaint((java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT");
    var9.setBasePaint(var47);
    var0.setBasePaint(var47, true);
    boolean var51 = var0.getIncludeBaseInRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
//     double var2 = var1.getUpperMargin();
//     java.awt.Font var4 = var1.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var5 = null;
//     org.jfree.chart.block.LabelBlock var6 = new org.jfree.chart.block.LabelBlock("", var4, var5);
//     org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
//     double var8 = var7.getUpperMargin();
//     java.awt.Font var10 = var7.getTickLabelFont((java.lang.Comparable)10.0d);
//     var6.setFont(var10);
//     var6.setToolTipText("");
//     java.awt.Graphics2D var14 = null;
//     org.jfree.data.Range var16 = null;
//     org.jfree.data.Range var17 = null;
//     org.jfree.data.Range var18 = null;
//     org.jfree.chart.block.RectangleConstraint var19 = new org.jfree.chart.block.RectangleConstraint(var17, var18);
//     org.jfree.chart.block.LengthConstraintType var20 = var19.getWidthConstraintType();
//     org.jfree.chart.block.LengthConstraintType var21 = var19.getWidthConstraintType();
//     org.jfree.data.Range var23 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(10.0d, 0.0d);
//     org.jfree.chart.block.LengthConstraintType var27 = var26.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint((-1.0d), var16, var21, 0.05d, var23, var27);
//     org.jfree.data.Range var29 = var28.getWidthRange();
//     org.jfree.chart.util.Size2D var30 = var6.arrange(var14, var28);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var2 = var0.getTickLabelPaint((java.lang.Comparable)18.0d);
//     var0.setLowerMargin(100.0d);
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     java.awt.Paint var8 = var5.getOutlinePaint();
//     boolean var9 = var5.isSubplot();
//     org.jfree.chart.axis.CategoryAnchor var10 = var5.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.PaintList var16 = new org.jfree.chart.util.PaintList();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var19 = var17.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var17.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var22 = var17.getTickLabelInsets();
//     boolean var23 = var16.equals((java.lang.Object)var17);
//     java.awt.Font var25 = var17.getTickLabelFont((java.lang.Comparable)1.0d);
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
//     var26.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
//     java.awt.Paint var30 = var26.getDomainGridlinePaint();
//     org.jfree.chart.text.TextBlock var31 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var25, var30);
//     org.jfree.chart.util.HorizontalAlignment var32 = var31.getLineAlignment();
//     var14.setHorizontalAlignment(var32);
//     org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot();
//     var34.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var38 = var34.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var39 = null;
//     var34.setDrawingSupplier(var39);
//     java.awt.Image var41 = null;
//     var34.setBackgroundImage(var41);
//     var34.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var47 = var45.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var45.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var50 = var45.getTickLabelInsets();
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var53 = var51.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var51.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var56 = var51.getTickLabelInsets();
//     var45.setLabelInsets(var56);
//     double var58 = var56.getRight();
//     double var59 = var56.getBottom();
//     var34.setInsets(var56);
//     org.jfree.chart.util.RectangleEdge var62 = var34.getDomainAxisEdge(100);
//     var14.setPosition(var62);
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
//     var64.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var68 = var64.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var69 = null;
//     var64.setDrawingSupplier(var69);
//     java.awt.Image var71 = null;
//     var64.setBackgroundImage(var71);
//     var64.setBackgroundImageAlpha(1.0f);
//     org.jfree.chart.axis.CategoryAxis var75 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var77 = var75.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var75.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var80 = var75.getTickLabelInsets();
//     org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var83 = var81.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var81.setLowerMargin(1.0d);
//     org.jfree.chart.util.RectangleInsets var86 = var81.getTickLabelInsets();
//     var75.setLabelInsets(var86);
//     double var88 = var86.getRight();
//     double var89 = var86.getBottom();
//     var64.setInsets(var86);
//     org.jfree.chart.util.RectangleEdge var92 = var64.getDomainAxisEdge(100);
//     var14.setPosition(var92);
//     double var94 = var0.getCategoryJava2DCoordinate(var10, 15, (-1), var13, var92);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    var2.clearDomainMarkers(0);
    java.awt.Paint var5 = var2.getOutlinePaint();
    boolean var6 = var2.isSubplot();
    org.jfree.chart.axis.CategoryAxis var7 = null;
    int var8 = var2.getDomainAxisIndex(var7);
    org.jfree.chart.axis.AxisLocation var10 = var2.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var11 = var2.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var12 = var1.getLabelPosition(var11);
    float var13 = var12.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var14 = var12.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var15 = var12.getCategoryAnchor();
    org.jfree.chart.text.TextBlockAnchor var16 = null;
    org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
    org.jfree.chart.axis.CategoryLabelPosition var19 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var18, var19);
    org.jfree.chart.axis.CategoryLabelWidthType var21 = var19.getWidthType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var23 = new org.jfree.chart.axis.CategoryLabelPosition(var15, var16, var21, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoTickUnitSelection(true, true);
    org.jfree.chart.ChartRenderingInfo var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = new org.jfree.chart.plot.PlotRenderingInfo(var6);
    java.awt.geom.Rectangle2D var8 = var7.getDataArea();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers(0);
    java.awt.Paint var12 = var9.getOutlinePaint();
    boolean var13 = var9.isSubplot();
    org.jfree.chart.axis.CategoryAxis var14 = null;
    int var15 = var9.getDomainAxisIndex(var14);
    org.jfree.chart.axis.AxisLocation var17 = var9.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var18 = var9.getDomainAxisEdge();
    double var19 = var1.valueToJava2D(10.0d, var8, var18);
    var1.setUpperMargin(0.05d);
    var1.setLowerBound(100.0d);
    var1.setFixedDimension((-2.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(6.0d, 4.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.AxisState var0 = new org.jfree.chart.axis.AxisState();
    double var1 = var0.getMax();
    var0.cursorRight((-1.0d));
    double var4 = var0.getCursor();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1.0d));

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
    var0.setLabelURL("java.awt.Color[r=0,g=0,b=18]");
    org.jfree.chart.text.TextBlock var14 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.text.TextBlockAnchor var18 = null;
    java.awt.Shape var22 = var14.calculateBounds(var15, 0.0f, 100.0f, var18, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var25 = var23.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var26 = var23.getTickMarkStroke();
    java.awt.Color var28 = java.awt.Color.decode("18");
    float[] var29 = null;
    float[] var30 = var28.getRGBColorComponents(var29);
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var22, var26, (java.awt.Paint)var28);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 0.0d);
    org.jfree.chart.entity.AxisLabelEntity var37 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var22, "", "Category Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.util.HorizontalAlignment var3 = var0.getHorizontalAlignment();
//     java.lang.String var4 = var3.toString();
//     org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
//     var5.clearDomainMarkers(0);
//     java.awt.Paint var8 = var5.getOutlinePaint();
//     boolean var9 = var5.isSubplot();
//     org.jfree.chart.axis.AxisLocation var11 = var5.getDomainAxisLocation(1);
//     boolean var12 = var3.equals((java.lang.Object)1);
//     org.jfree.chart.text.TextBlock var17 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.text.TextBlockAnchor var21 = null;
//     java.awt.Shape var25 = var17.calculateBounds(var18, 0.0f, 100.0f, var21, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var28 = var26.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var29 = var26.getTickMarkStroke();
//     java.awt.Color var31 = java.awt.Color.decode("18");
//     float[] var32 = null;
//     float[] var33 = var31.getRGBColorComponents(var32);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var25, var29, (java.awt.Paint)var31);
//     boolean var35 = var3.equals((java.lang.Object)"18");
//     org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var37 = var36.getFont();
//     java.lang.Object var38 = var36.clone();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     double var42 = var41.getUpperMargin();
//     java.awt.Font var44 = var41.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var45 = null;
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("", var44, var45);
//     org.jfree.chart.text.TextFragment var47 = new org.jfree.chart.text.TextFragment("", var44);
//     java.awt.Font var48 = var47.getFont();
//     var36.setFont(var48);
//     org.jfree.chart.util.VerticalAlignment var50 = var36.getVerticalAlignment();
//     java.lang.Object var51 = null;
//     boolean var52 = var50.equals(var51);
//     org.jfree.chart.block.FlowArrangement var55 = new org.jfree.chart.block.FlowArrangement(var3, var50, (-1.0d), 0.2d);
//     org.jfree.chart.text.TextBlock var56 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var57 = null;
//     org.jfree.chart.text.TextBlockAnchor var60 = null;
//     java.awt.Shape var64 = var56.calculateBounds(var57, 0.0f, 100.0f, var60, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var66 = var65.getFont();
//     java.lang.Object var67 = var65.clone();
//     org.jfree.chart.util.HorizontalAlignment var68 = var65.getHorizontalAlignment();
//     java.lang.String var69 = var68.toString();
//     var56.setLineAlignment(var68);
//     java.awt.Graphics2D var71 = null;
//     org.jfree.chart.axis.CategoryLabelPositions var75 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
//     var76.clearDomainMarkers(0);
//     java.awt.Paint var79 = var76.getOutlinePaint();
//     boolean var80 = var76.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var81 = null;
//     int var82 = var76.getDomainAxisIndex(var81);
//     org.jfree.chart.axis.AxisLocation var84 = var76.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var85 = var76.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var86 = var75.getLabelPosition(var85);
//     float var87 = var86.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var88 = var86.getLabelAnchor();
//     var56.draw(var71, 0.8f, 100.0f, var88);
//     boolean var90 = var55.equals((java.lang.Object)var71);
//     
//     // Checks the contract:  equals-hashcode on var5 and var76
//     assertTrue("Contract failed: equals-hashcode on var5 and var76", var5.equals(var76) ? var5.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var5
//     assertTrue("Contract failed: equals-hashcode on var76 and var5", var76.equals(var5) ? var76.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, 1.0f, 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-3407872));

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var3 = null;
//     var0.setGradientPaintTransformer(var3);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getPositiveItemLabelPositionFallback();
//     java.awt.Shape var7 = var0.getSeriesShape(100);
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(0);
//     java.awt.Paint var12 = var9.getOutlinePaint();
//     java.awt.Paint var13 = var9.getNoDataMessagePaint();
//     boolean var14 = var9.isRangeZoomable();
//     java.lang.Object var15 = var9.clone();
//     org.jfree.chart.LegendItemCollection var16 = var9.getFixedLegendItems();
//     org.jfree.chart.axis.NumberAxis var18 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var18.setAutoRangeIncludesZero(false);
//     java.awt.Shape var21 = var18.getLeftArrow();
//     var18.setAutoRangeMinimumSize(4.0d);
//     org.jfree.chart.text.TextBlock var24 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.util.Size2D var26 = var24.calculateDimensions(var25);
//     java.lang.Object var27 = var26.clone();
//     org.jfree.chart.axis.CategoryLabelPositions var31 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot();
//     var32.clearDomainMarkers(0);
//     java.awt.Paint var35 = var32.getOutlinePaint();
//     boolean var36 = var32.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var37 = null;
//     int var38 = var32.getDomainAxisIndex(var37);
//     org.jfree.chart.axis.AxisLocation var40 = var32.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var41 = var32.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var42 = var31.getLabelPosition(var41);
//     float var43 = var42.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var44 = var42.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var45 = var42.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var46 = org.jfree.chart.util.RectangleAnchor.createRectangle(var26, 0.0d, 100.0d, var45);
//     var0.drawRangeGridline(var8, var9, (org.jfree.chart.axis.ValueAxis)var18, var46, 0.0d);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
//     org.jfree.chart.axis.CategoryLabelPosition var2 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var2);
//     org.jfree.chart.axis.CategoryLabelPositions var5 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     java.awt.Paint var9 = var6.getOutlinePaint();
//     boolean var10 = var6.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     int var12 = var6.getDomainAxisIndex(var11);
//     org.jfree.chart.axis.AxisLocation var14 = var6.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var15 = var6.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var16 = var5.getLabelPosition(var15);
//     float var17 = var16.getWidthRatio();
//     org.jfree.chart.axis.CategoryLabelPositions var18 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var1, var16);
//     org.jfree.chart.axis.CategoryLabelPositions var20 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
//     org.jfree.chart.axis.CategoryLabelPosition var21 = new org.jfree.chart.axis.CategoryLabelPosition();
//     org.jfree.chart.axis.CategoryLabelPositions var22 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(var20, var21);
//     org.jfree.chart.axis.CategoryLabelWidthType var23 = var21.getWidthType();
//     org.jfree.chart.axis.CategoryLabelPositions var24 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(var1, var21);
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearDomainMarkers(0);
//     java.awt.Paint var28 = var25.getOutlinePaint();
//     boolean var29 = var25.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var33 = var30.getFixedRangeAxisSpace();
//     java.awt.Paint var34 = var30.getDomainGridlinePaint();
//     var25.setNoDataMessagePaint(var34);
//     boolean var36 = var25.isDomainGridlinesVisible();
//     org.jfree.chart.axis.CategoryAxis var37 = new org.jfree.chart.axis.CategoryAxis();
//     double var38 = var37.getUpperMargin();
//     java.awt.Font var40 = var37.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var41 = var37.isTickMarksVisible();
//     java.awt.Stroke var42 = var37.getTickMarkStroke();
//     var25.setOutlineStroke(var42);
//     boolean var44 = var24.equals((java.lang.Object)var42);
//     
//     // Checks the contract:  equals-hashcode on var6 and var30
//     assertTrue("Contract failed: equals-hashcode on var6 and var30", var6.equals(var30) ? var6.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var6
//     assertTrue("Contract failed: equals-hashcode on var30 and var6", var30.equals(var6) ? var30.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var1 = var0.getFont();
//     java.lang.Object var2 = var0.clone();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var9 = null;
//     org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("", var8, var9);
//     org.jfree.chart.text.TextFragment var11 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Font var12 = var11.getFont();
//     var0.setFont(var12);
//     org.jfree.chart.util.VerticalAlignment var14 = var0.getVerticalAlignment();
//     java.lang.String var15 = var14.toString();
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var18 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.text.TextBlockAnchor var22 = null;
//     java.awt.Shape var26 = var18.calculateBounds(var19, 0.0f, 100.0f, var22, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var17, var26, "HorizontalAlignment.CENTER", "hi!");
//     var17.setRange(0.05d, 0.05d);
//     var17.setRangeAboutValue(0.0d, 18.0d);
//     var17.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot();
//     var39.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var43 = var39.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var44 = null;
//     var39.setDrawingSupplier(var44);
//     var17.addChangeListener((org.jfree.chart.event.AxisChangeListener)var39);
//     boolean var47 = var14.equals((java.lang.Object)var17);
//     java.awt.Shape var48 = var17.getRightArrow();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot();
//     var49.clearDomainMarkers(0);
//     java.awt.Paint var52 = var49.getOutlinePaint();
//     boolean var53 = var49.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var57 = var54.getFixedRangeAxisSpace();
//     java.awt.Paint var58 = var54.getDomainGridlinePaint();
//     var49.setNoDataMessagePaint(var58);
//     org.jfree.chart.title.LegendGraphic var60 = new org.jfree.chart.title.LegendGraphic(var48, var58);
//     boolean var61 = var60.isShapeFilled();
//     java.awt.Stroke var62 = var60.getLineStroke();
//     java.awt.Paint var63 = var60.getLinePaint();
//     org.jfree.chart.text.TextBlock var64 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var65 = null;
//     org.jfree.chart.util.Size2D var66 = var64.calculateDimensions(var65);
//     java.lang.Object var67 = var66.clone();
//     org.jfree.chart.axis.CategoryLabelPositions var71 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     var72.clearDomainMarkers(0);
//     java.awt.Paint var75 = var72.getOutlinePaint();
//     boolean var76 = var72.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var77 = null;
//     int var78 = var72.getDomainAxisIndex(var77);
//     org.jfree.chart.axis.AxisLocation var80 = var72.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var81 = var72.getDomainAxisEdge();
//     org.jfree.chart.axis.CategoryLabelPosition var82 = var71.getLabelPosition(var81);
//     float var83 = var82.getWidthRatio();
//     org.jfree.chart.text.TextBlockAnchor var84 = var82.getLabelAnchor();
//     org.jfree.chart.util.RectangleAnchor var85 = var82.getCategoryAnchor();
//     java.awt.geom.Rectangle2D var86 = org.jfree.chart.util.RectangleAnchor.createRectangle(var66, 0.0d, 100.0d, var85);
//     var60.setShapeLocation(var85);
//     
//     // Checks the contract:  equals-hashcode on var54 and var72
//     assertTrue("Contract failed: equals-hashcode on var54 and var72", var54.equals(var72) ? var54.hashCode() == var72.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var72 and var54
//     assertTrue("Contract failed: equals-hashcode on var72 and var54", var72.equals(var54) ? var72.hashCode() == var54.hashCode() : true);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(4.0d, (-100.95d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var18 = var15.getTickMarkStroke();
    java.awt.Color var20 = java.awt.Color.decode("18");
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
    java.lang.String var24 = var20.toString();
    var1.setPaint((java.awt.Paint)var20);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
    var26.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var26.markerChanged(var32);
    boolean var34 = var26.isDomainZoomable();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
    java.awt.Paint var36 = var1.getLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var40 = null;
    var37.notifyListeners(var40);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var37.setBaseToolTipGenerator(var42, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var47 = var45.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var48 = null;
    var45.setGradientPaintTransformer(var48);
    java.awt.Shape var51 = var45.lookupSeriesShape((-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var54 = var52.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
    var56.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var61 = null;
    var56.setDrawingSupplier(var61);
    org.jfree.chart.axis.CategoryAxis var63 = var56.getDomainAxis();
    java.util.List var64 = var56.getAnnotations();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var67 = null;
    java.awt.geom.Rectangle2D var68 = null;
    var52.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var66, var67, var68);
    var52.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var72 = var52.getBaseStroke();
    var45.setErrorIndicatorStroke(var72);
    var37.setErrorIndicatorStroke(var72);
    var1.setOutlineStroke(var72);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var76 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var78 = var76.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var79 = null;
    var76.notifyListeners(var79);
    org.jfree.chart.urls.CategoryURLGenerator var81 = var76.getBaseURLGenerator();
    org.jfree.chart.labels.ItemLabelPosition var84 = var76.getPositiveItemLabelPosition((-16777216), (-16777216));
    org.jfree.chart.text.TextAnchor var85 = var84.getRotationAnchor();
    java.lang.String var86 = var85.toString();
    var1.setLabelTextAnchor(var85);
    java.awt.Paint var88 = var1.getLabelPaint();
    java.awt.Stroke var89 = var1.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var24.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var86 + "' != '" + "TextAnchor.CENTER"+ "'", var86.equals("TextAnchor.CENTER"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("SortOrder.ASCENDING");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    boolean var15 = var13.equals((java.lang.Object)(short)10);
    java.lang.String var16 = var13.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "poly"+ "'", var16.equals("poly"));

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis();
//     double var3 = var2.getUpperMargin();
//     java.awt.Font var5 = var2.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var6 = null;
//     org.jfree.chart.block.LabelBlock var7 = new org.jfree.chart.block.LabelBlock("", var5, var6);
//     var0.setBaseItemLabelFont(var5, true);
//     org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
//     var10.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
//     boolean var14 = var10.equals((java.lang.Object)var13);
//     org.jfree.chart.plot.Plot var15 = null;
//     var10.setParent(var15);
//     var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     double var19 = var18.getUpperMargin();
//     java.awt.Font var21 = var18.getTickLabelFont((java.lang.Comparable)(short)10);
//     var18.clearCategoryLabelToolTips();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var26 = var24.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var27 = var24.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis();
//     double var29 = var28.getUpperMargin();
//     java.awt.Font var31 = var28.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var32 = var28.getCategoryLabelPositions();
//     org.jfree.chart.axis.NumberTickUnit var34 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     java.lang.String var36 = var34.valueToString(18.0d);
//     double var37 = var34.getSize();
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.clearDomainMarkers(0);
//     java.awt.Paint var41 = var38.getOutlinePaint();
//     java.awt.Paint var42 = var38.getNoDataMessagePaint();
//     var28.setTickLabelPaint((java.lang.Comparable)var37, var42);
//     var24.setTickMarkPaint(var42);
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var47 = var45.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.util.GradientPaintTransformer var48 = null;
//     var45.setGradientPaintTransformer(var48);
//     java.awt.Shape var51 = var45.lookupSeriesShape((-16777216));
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var54 = var52.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var55 = null;
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
//     var56.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var61 = null;
//     var56.setDrawingSupplier(var61);
//     org.jfree.chart.axis.CategoryAxis var63 = var56.getDomainAxis();
//     java.util.List var64 = var56.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var67 = null;
//     java.awt.geom.Rectangle2D var68 = null;
//     var52.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var66, var67, var68);
//     var52.setAutoPopulateSeriesOutlinePaint(false);
//     java.awt.Stroke var72 = var52.getBaseStroke();
//     var45.setErrorIndicatorStroke(var72);
//     org.jfree.chart.plot.ValueMarker var74 = new org.jfree.chart.plot.ValueMarker(4.0d, var42, var72);
//     var18.setAxisLineStroke(var72);
//     var0.setBaseOutlineStroke(var72);
//     
//     // Checks the contract:  equals-hashcode on var10 and var38
//     assertTrue("Contract failed: equals-hashcode on var10 and var38", var10.equals(var38) ? var10.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var10
//     assertTrue("Contract failed: equals-hashcode on var38 and var10", var38.equals(var10) ? var38.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.2d, 100.0f, 1.0f);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    float var18 = var14.getTickMarkInsideLength();
    double var19 = var14.getUpperBound();
    double var20 = var14.getFixedDimension();
    org.jfree.chart.axis.TickUnitSource var21 = var14.getStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var2.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var5 = null;
    var2.setGradientPaintTransformer(var5);
    java.awt.Shape var8 = var2.lookupSeriesShape((-16777216));
    org.jfree.chart.entity.ChartEntity var9 = new org.jfree.chart.entity.ChartEntity(var8);
    boolean var10 = var0.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("AxisLocation.TOP_OR_LEFT", var1, 0.0f, 1.0f, Double.NaN, 0.0f, 0.8f);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("[size=0.05]");
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.PaintList var4 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var7 = var5.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var5.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var10 = var5.getTickLabelInsets();
    boolean var11 = var4.equals((java.lang.Object)var5);
    java.awt.Font var13 = var5.getTickLabelFont((java.lang.Comparable)1.0d);
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot();
    var14.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var17 = var14.getFixedRangeAxisSpace();
    java.awt.Paint var18 = var14.getDomainGridlinePaint();
    org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("HorizontalAlignment.CENTER", var13, var18);
    org.jfree.chart.util.HorizontalAlignment var20 = var19.getLineAlignment();
    var2.setHorizontalAlignment(var20);
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot();
    var22.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var26 = var22.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var27 = null;
    var22.setDrawingSupplier(var27);
    java.awt.Image var29 = null;
    var22.setBackgroundImage(var29);
    var22.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var35 = var33.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var33.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var38 = var33.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var41 = var39.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var39.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var44 = var39.getTickLabelInsets();
    var33.setLabelInsets(var44);
    double var46 = var44.getRight();
    double var47 = var44.getBottom();
    var22.setInsets(var44);
    org.jfree.chart.util.RectangleEdge var50 = var22.getDomainAxisEdge(100);
    var2.setPosition(var50);
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot();
    var52.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var56 = var52.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var57 = null;
    var52.setDrawingSupplier(var57);
    java.awt.Image var59 = null;
    var52.setBackgroundImage(var59);
    var52.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var63 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var65 = var63.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var63.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var68 = var63.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var69 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var71 = var69.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var69.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var74 = var69.getTickLabelInsets();
    var63.setLabelInsets(var74);
    double var76 = var74.getRight();
    double var77 = var74.getBottom();
    var52.setInsets(var74);
    org.jfree.chart.util.RectangleEdge var80 = var52.getDomainAxisEdge(100);
    var2.setPosition(var80);
    org.jfree.chart.util.RectangleEdge var82 = org.jfree.chart.util.RectangleEdge.opposite(var80);
    boolean var83 = var1.equals((java.lang.Object)var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)0.0f, var1, 1, (-1));
    int var5 = var4.getPercent();
    var4.setPercent((-16777216));
    var4.setPercent(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle.Control var3 = null;
//     java.util.ResourceBundle var4 = java.util.ResourceBundle.getBundle("RectangleEdge.BOTTOM", var1, var2, var3);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlockAnchor var4 = null;
//     java.awt.Shape var8 = var0.calculateBounds(var1, 0.0f, 100.0f, var4, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var10 = var9.getFont();
//     java.lang.Object var11 = var9.clone();
//     org.jfree.chart.util.HorizontalAlignment var12 = var9.getHorizontalAlignment();
//     java.lang.String var13 = var12.toString();
//     var0.setLineAlignment(var12);
//     org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
//     double var17 = var16.getUpperMargin();
//     java.awt.Font var19 = var16.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot();
//     var20.clearDomainMarkers(0);
//     java.awt.Paint var23 = var20.getOutlinePaint();
//     boolean var24 = var20.isSubplot();
//     var16.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
//     java.awt.Font var26 = var16.getLabelFont();
//     org.jfree.chart.text.TextLine var27 = new org.jfree.chart.text.TextLine("hi!", var26);
//     org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var32 = var30.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     var30.setLowerMargin(1.0d);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
//     double var36 = var35.getUpperMargin();
//     java.awt.Font var38 = var35.getTickLabelFont((java.lang.Comparable)10.0d);
//     var30.setTickLabelFont(var38);
//     org.jfree.chart.block.LabelBlock var40 = new org.jfree.chart.block.LabelBlock("", var38);
//     org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("AxisLocation.BOTTOM_OR_RIGHT", var38);
//     var27.removeFragment(var41);
//     var0.addLine(var27);
//     org.jfree.chart.text.TextFragment var44 = var27.getLastTextFragment();
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker(0.0d);
//     org.jfree.chart.text.TextBlock var52 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var53 = null;
//     org.jfree.chart.text.TextBlockAnchor var56 = null;
//     java.awt.Shape var60 = var52.calculateBounds(var53, 0.0f, 100.0f, var56, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var63 = var61.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var64 = var61.getTickMarkStroke();
//     java.awt.Color var66 = java.awt.Color.decode("18");
//     float[] var67 = null;
//     float[] var68 = var66.getRGBColorComponents(var67);
//     org.jfree.chart.LegendItem var69 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var60, var64, (java.awt.Paint)var66);
//     java.lang.String var70 = var66.toString();
//     var47.setPaint((java.awt.Paint)var66);
//     org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot();
//     var72.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var75 = var72.getFixedRangeAxisSpace();
//     var72.setRangeCrosshairLockedOnData(false);
//     org.jfree.chart.event.MarkerChangeEvent var78 = null;
//     var72.markerChanged(var78);
//     boolean var80 = var72.isDomainZoomable();
//     var47.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var72);
//     org.jfree.chart.text.TextAnchor var82 = var47.getLabelTextAnchor();
//     float var83 = var44.calculateBaselineOffset(var45, var82);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var5 = var0.getRangeAxisLocation((-16777216));
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getRangeMarkers((-1), var8);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var12 = var10.getTickLabelPaint((java.lang.Comparable)18.0d);
    var0.setRangeGridlinePaint(var12);
    org.jfree.chart.event.MarkerChangeEvent var14 = null;
    var0.markerChanged(var14);
    java.awt.Paint var16 = var0.getNoDataMessagePaint();
    int var17 = var0.getBackgroundImageAlignment();
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var19 = var0.removeAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 15);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var1 = var0.getInsets();
    double var2 = var1.getRight();
    double var4 = var1.trimHeight(6.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.ui.BasicProjectInfo var0 = new org.jfree.chart.ui.BasicProjectInfo();
    org.jfree.chart.ui.BasicProjectInfo var1 = new org.jfree.chart.ui.BasicProjectInfo();
    var1.setLicenceName("");
    org.jfree.chart.ui.Library[] var4 = var1.getLibraries();
    var0.addLibrary((org.jfree.chart.ui.Library)var1);
    java.lang.String var6 = var0.getInfo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    var0.setBase(18.0d);
    org.jfree.chart.plot.CategoryPlot var5 = new org.jfree.chart.plot.CategoryPlot();
    var5.clearDomainMarkers(0);
    java.awt.Paint var8 = var5.getOutlinePaint();
    boolean var9 = var5.isSubplot();
    org.jfree.chart.plot.CategoryPlot var10 = new org.jfree.chart.plot.CategoryPlot();
    var10.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var13 = var10.getFixedRangeAxisSpace();
    java.awt.Paint var14 = var10.getDomainGridlinePaint();
    var5.setNoDataMessagePaint(var14);
    boolean var16 = var5.isDomainGridlinesVisible();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var5);
    int var18 = var5.getDomainAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     double var1 = var0.getUpperMargin();
//     java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
//     var4.clearDomainMarkers(0);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var4);
//     var0.setMaximumCategoryLabelWidthRatio(10.0f);
//     boolean var10 = var0.isTickLabelsVisible();
//     boolean var11 = var0.isTickLabelsVisible();
//     org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
//     var12.clearDomainMarkers(0);
//     java.awt.Paint var15 = var12.getOutlinePaint();
//     boolean var16 = var12.isSubplot();
//     org.jfree.chart.axis.CategoryAnchor var17 = var12.getDomainGridlinePosition();
//     java.lang.String var18 = var17.toString();
//     org.jfree.chart.util.HorizontalAlignment var21 = null;
//     org.jfree.chart.util.VerticalAlignment var22 = null;
//     org.jfree.chart.block.FlowArrangement var25 = new org.jfree.chart.block.FlowArrangement(var21, var22, 0.05d, 10.0d);
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
//     double var28 = var27.getUpperMargin();
//     java.awt.Font var30 = var27.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var31 = null;
//     org.jfree.chart.block.LabelBlock var32 = new org.jfree.chart.block.LabelBlock("", var30, var31);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     double var34 = var33.getUpperMargin();
//     java.awt.Font var36 = var33.getTickLabelFont((java.lang.Comparable)10.0d);
//     var32.setFont(var36);
//     var32.setWidth(0.0d);
//     java.lang.Object var40 = null;
//     var25.add((org.jfree.chart.block.Block)var32, var40);
//     org.jfree.chart.util.RectangleInsets var42 = var32.getPadding();
//     var32.setToolTipText("");
//     org.jfree.chart.axis.NumberAxis var46 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var46.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var51 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var52 = new org.jfree.chart.plot.PlotRenderingInfo(var51);
//     java.awt.geom.Rectangle2D var53 = var52.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot();
//     var54.clearDomainMarkers(0);
//     java.awt.Paint var57 = var54.getOutlinePaint();
//     boolean var58 = var54.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var59 = null;
//     int var60 = var54.getDomainAxisIndex(var59);
//     org.jfree.chart.axis.AxisLocation var62 = var54.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var63 = var54.getDomainAxisEdge();
//     double var64 = var46.valueToJava2D(10.0d, var53, var63);
//     var32.setBounds(var53);
//     org.jfree.chart.axis.NumberAxis var67 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var67.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var72 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var73 = new org.jfree.chart.plot.PlotRenderingInfo(var72);
//     java.awt.geom.Rectangle2D var74 = var73.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot();
//     var75.clearDomainMarkers(0);
//     java.awt.Paint var78 = var75.getOutlinePaint();
//     boolean var79 = var75.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var80 = null;
//     int var81 = var75.getDomainAxisIndex(var80);
//     org.jfree.chart.axis.AxisLocation var83 = var75.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var84 = var75.getDomainAxisEdge();
//     double var85 = var67.valueToJava2D(10.0d, var74, var84);
//     double var86 = var0.getCategoryJava2DCoordinate(var17, 0, 0, var53, var84);
//     
//     // Checks the contract:  equals-hashcode on var4 and var12
//     assertTrue("Contract failed: equals-hashcode on var4 and var12", var4.equals(var12) ? var4.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var54
//     assertTrue("Contract failed: equals-hashcode on var4 and var54", var4.equals(var54) ? var4.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var75
//     assertTrue("Contract failed: equals-hashcode on var4 and var75", var4.equals(var75) ? var4.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var4
//     assertTrue("Contract failed: equals-hashcode on var12 and var4", var12.equals(var4) ? var12.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var54
//     assertTrue("Contract failed: equals-hashcode on var12 and var54", var12.equals(var54) ? var12.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var75
//     assertTrue("Contract failed: equals-hashcode on var12 and var75", var12.equals(var75) ? var12.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var4
//     assertTrue("Contract failed: equals-hashcode on var54 and var4", var54.equals(var4) ? var54.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var12
//     assertTrue("Contract failed: equals-hashcode on var54 and var12", var54.equals(var12) ? var54.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var75
//     assertTrue("Contract failed: equals-hashcode on var54 and var75", var54.equals(var75) ? var54.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var4
//     assertTrue("Contract failed: equals-hashcode on var75 and var4", var75.equals(var4) ? var75.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var12
//     assertTrue("Contract failed: equals-hashcode on var75 and var12", var75.equals(var12) ? var75.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var54
//     assertTrue("Contract failed: equals-hashcode on var75 and var54", var75.equals(var54) ? var75.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var73
//     assertTrue("Contract failed: equals-hashcode on var52 and var73", var52.equals(var73) ? var52.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var52
//     assertTrue("Contract failed: equals-hashcode on var73 and var52", var73.equals(var52) ? var73.hashCode() == var52.hashCode() : true);
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var0.setDrawingSupplier(var5);
    java.awt.Image var7 = null;
    var0.setBackgroundImage(var7);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    double var10 = var9.getUpperMargin();
    java.awt.Font var12 = var9.getTickLabelFont((java.lang.Comparable)(short)10);
    var0.setNoDataMessageFont(var12);
    org.jfree.chart.LegendItemCollection var14 = null;
    var0.setFixedLegendItems(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var16 = var0.clone();
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = null;
//     var0.setDrawingSupplier(var5);
//     java.awt.Image var7 = null;
//     var0.setBackgroundImage(var7);
//     var0.setBackgroundImageAlpha(1.0f);
//     org.jfree.data.general.DatasetGroup var11 = var0.getDatasetGroup();
//     org.jfree.chart.axis.AxisSpace var12 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var15 = var13.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var16 = var13.getTickMarkStroke();
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
//     double var18 = var17.getUpperMargin();
//     java.awt.Font var20 = var17.getTickLabelFont((java.lang.Comparable)(short)10);
//     org.jfree.chart.axis.CategoryLabelPositions var21 = var17.getCategoryLabelPositions();
//     org.jfree.chart.axis.NumberTickUnit var23 = new org.jfree.chart.axis.NumberTickUnit(0.05d);
//     java.lang.String var25 = var23.valueToString(18.0d);
//     double var26 = var23.getSize();
//     org.jfree.chart.plot.CategoryPlot var27 = new org.jfree.chart.plot.CategoryPlot();
//     var27.clearDomainMarkers(0);
//     java.awt.Paint var30 = var27.getOutlinePaint();
//     java.awt.Paint var31 = var27.getNoDataMessagePaint();
//     var17.setTickLabelPaint((java.lang.Comparable)var26, var31);
//     var13.setTickMarkPaint(var31);
//     var0.setOutlinePaint(var31);
//     org.jfree.chart.LegendItemCollection var35 = var0.getFixedLegendItems();
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var38 = var36.getSeriesURLGenerator((-16777216));
//     java.awt.Graphics2D var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot();
//     var40.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var44 = var40.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var45 = null;
//     var40.setDrawingSupplier(var45);
//     org.jfree.chart.axis.CategoryAxis var47 = var40.getDomainAxis();
//     java.util.List var48 = var40.getAnnotations();
//     org.jfree.chart.axis.NumberAxis var50 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.plot.Marker var51 = null;
//     java.awt.geom.Rectangle2D var52 = null;
//     var36.drawRangeMarker(var39, var40, (org.jfree.chart.axis.ValueAxis)var50, var51, var52);
//     var36.setAutoPopulateSeriesOutlinePaint(false);
//     org.jfree.chart.urls.CategoryURLGenerator var58 = var36.getURLGenerator((-16777216), 100);
//     var36.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     var0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var63 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var65 = var63.getRangeUpperBound(false);
//     java.lang.Object var66 = var63.clone();
//     var0.setDataset((org.jfree.data.category.CategoryDataset)var63);
//     org.jfree.chart.plot.CategoryPlot var68 = new org.jfree.chart.plot.CategoryPlot();
//     var68.clearDomainMarkers(0);
//     java.awt.Paint var71 = var68.getOutlinePaint();
//     boolean var72 = var68.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var73 = new org.jfree.chart.plot.CategoryPlot();
//     var73.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var76 = var73.getFixedRangeAxisSpace();
//     java.awt.Paint var77 = var73.getDomainGridlinePaint();
//     var68.setNoDataMessagePaint(var77);
//     boolean var79 = var68.isDomainGridlinesVisible();
//     org.jfree.chart.axis.CategoryAxis var80 = new org.jfree.chart.axis.CategoryAxis();
//     double var81 = var80.getUpperMargin();
//     java.awt.Font var83 = var80.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var84 = var80.isTickMarksVisible();
//     java.awt.Stroke var85 = var80.getTickMarkStroke();
//     var68.setOutlineStroke(var85);
//     var63.addChangeListener((org.jfree.data.general.DatasetChangeListener)var68);
//     
//     // Checks the contract:  equals-hashcode on var27 and var73
//     assertTrue("Contract failed: equals-hashcode on var27 and var73", var27.equals(var73) ? var27.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var27
//     assertTrue("Contract failed: equals-hashcode on var73 and var27", var73.equals(var27) ? var73.hashCode() == var27.hashCode() : true);
// 
//   }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend();
    org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(1.0d, 2.0d);
    org.jfree.chart.util.Size2D var39 = var33.arrange(var35, var38);
    org.jfree.chart.util.RectangleEdge var40 = var33.getLegendItemGraphicEdge();
    java.awt.Paint var41 = var33.getBackgroundPaint();
    org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var44 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var45 = null;
    org.jfree.chart.text.TextBlockAnchor var48 = null;
    java.awt.Shape var52 = var44.calculateBounds(var45, 0.0f, 100.0f, var48, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var55 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var43, var52, "HorizontalAlignment.CENTER", "hi!");
    var43.setRange(0.05d, 0.05d);
    var43.setRangeAboutValue(0.0d, 18.0d);
    var43.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var65 = new org.jfree.chart.plot.CategoryPlot();
    var65.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var69 = var65.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var70 = null;
    var65.setDrawingSupplier(var70);
    var43.addChangeListener((org.jfree.chart.event.AxisChangeListener)var65);
    org.jfree.chart.JFreeChart var73 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var65);
    float var74 = var73.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var75 = var73.getLegend();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var76 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var78 = var76.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var79 = null;
    var76.setGradientPaintTransformer(var79);
    org.jfree.chart.labels.ItemLabelPosition var81 = var76.getPositiveItemLabelPositionFallback();
    java.awt.Shape var83 = var76.getSeriesShape(100);
    boolean var85 = var76.isSeriesVisibleInLegend(0);
    var76.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.LegendItemSource[] var88 = new org.jfree.chart.LegendItemSource[] { var76};
    var75.setSources(var88);
    var33.setSources(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    var0.setCategoryLabelPositionOffset((-16777216));
    var0.setMaximumCategoryLabelWidthRatio(1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.notifyListeners(var3);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
//     org.jfree.chart.labels.ItemLabelPosition var8 = var0.getPositiveItemLabelPosition((-16777216), (-16777216));
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var10 = null;
//     org.jfree.chart.util.RectangleInsets var15 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 0.0d, 0.0d);
//     org.jfree.chart.axis.NumberAxis var17 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var17.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = new org.jfree.chart.plot.PlotRenderingInfo(var22);
//     java.awt.geom.Rectangle2D var24 = var23.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot();
//     var25.clearDomainMarkers(0);
//     java.awt.Paint var28 = var25.getOutlinePaint();
//     boolean var29 = var25.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var30 = null;
//     int var31 = var25.getDomainAxisIndex(var30);
//     org.jfree.chart.axis.AxisLocation var33 = var25.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var34 = var25.getDomainAxisEdge();
//     double var35 = var17.valueToJava2D(10.0d, var24, var34);
//     org.jfree.chart.entity.ChartEntity var36 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var24);
//     java.awt.geom.Rectangle2D var37 = var15.createInsetRectangle(var24);
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot();
//     var38.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var42 = var38.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var43 = null;
//     var38.setDrawingSupplier(var43);
//     java.awt.Stroke var45 = var38.getOutlineStroke();
//     org.jfree.chart.axis.CategoryAxis var46 = null;
//     org.jfree.chart.axis.NumberAxis var48 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var49 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var50 = null;
//     org.jfree.chart.text.TextBlockAnchor var53 = null;
//     java.awt.Shape var57 = var49.calculateBounds(var50, 0.0f, 100.0f, var53, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var60 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var48, var57, "HorizontalAlignment.CENTER", "hi!");
//     var48.setRange(0.05d, 0.05d);
//     var48.setRangeAboutValue(0.0d, 18.0d);
//     var48.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var70 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     double var72 = var70.getRangeUpperBound(false);
//     var0.drawItem(var9, var10, var37, var38, var46, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.data.category.CategoryDataset)var70, 101, 0, 100);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.05d, 10.0d);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    double var7 = var6.getUpperMargin();
    java.awt.Font var9 = var6.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var10 = null;
    org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("", var9, var10);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    double var13 = var12.getUpperMargin();
    java.awt.Font var15 = var12.getTickLabelFont((java.lang.Comparable)10.0d);
    var11.setFont(var15);
    var11.setWidth(0.0d);
    java.lang.Object var19 = null;
    var4.add((org.jfree.chart.block.Block)var11, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var21 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
    var0.add((-1.0d), 4.0d, (java.lang.Comparable)"[size=0.05]", (java.lang.Comparable)(byte)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)"TextAnchor.CENTER");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoRangeIncludesZero(false);
    var1.setAutoTickUnitSelection(true, false);
    java.text.NumberFormat var7 = null;
    var1.setNumberFormatOverride(var7);
    var1.setAutoTickUnitSelection(false, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var14 = var12.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot();
    var16.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var20 = var16.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var21 = null;
    var16.setDrawingSupplier(var21);
    org.jfree.chart.axis.CategoryAxis var23 = var16.getDomainAxis();
    java.util.List var24 = var16.getAnnotations();
    org.jfree.chart.axis.NumberAxis var26 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var27 = null;
    java.awt.geom.Rectangle2D var28 = null;
    var12.drawRangeMarker(var15, var16, (org.jfree.chart.axis.ValueAxis)var26, var27, var28);
    var12.setAutoPopulateSeriesOutlinePaint(false);
    var12.setIncludeBaseInRange(true);
    java.awt.Paint var36 = var12.getItemOutlinePaint((-1), 0);
    var1.setAxisLinePaint(var36);
    var1.setLabelToolTip("Range[0.0,1.0]");
    org.jfree.data.Range var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeWithMargins(var40, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    var1.setAutoRangeIncludesZero(false);
    java.awt.Shape var4 = var1.getLeftArrow();
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var4, "10", "AxisLocation.TOP_OR_LEFT");
    java.lang.String var8 = var7.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "ChartEntity: tooltip = 10"+ "'", var8.equals("ChartEntity: tooltip = 10"));

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var1 = var0.getRowCount();
//     org.jfree.data.general.DatasetGroup var2 = var0.getGroup();
//     org.jfree.chart.plot.CategoryPlot var3 = new org.jfree.chart.plot.CategoryPlot();
//     var3.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var6 = new org.jfree.chart.block.BlockContainer();
//     boolean var7 = var3.equals((java.lang.Object)var6);
//     var3.setBackgroundImageAlignment(1);
//     org.jfree.chart.axis.AxisLocation var11 = var3.getRangeAxisLocation(1);
//     org.jfree.chart.ChartRenderingInfo var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = new org.jfree.chart.plot.PlotRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getDataArea();
//     org.jfree.data.KeyedObjects2D var17 = new org.jfree.data.KeyedObjects2D();
//     java.util.List var18 = var17.getColumnKeys();
//     boolean var19 = var15.equals((java.lang.Object)var18);
//     java.awt.geom.Point2D var20 = null;
//     var3.zoomDomainAxes(18.0d, 2.0d, var15, var20);
//     org.jfree.chart.util.Layer var22 = null;
//     java.util.Collection var23 = var3.getDomainMarkers(var22);
//     var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
//     org.jfree.data.statistics.DefaultStatisticalCategoryDataset var25 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
//     int var26 = var25.getRowCount();
//     org.jfree.data.general.DatasetGroup var27 = var25.getGroup();
//     var3.setDataset((org.jfree.data.category.CategoryDataset)var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var27
//     assertTrue("Contract failed: equals-hashcode on var2 and var27", var2.equals(var27) ? var2.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var2
//     assertTrue("Contract failed: equals-hashcode on var27 and var2", var27.equals(var2) ? var27.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    org.jfree.chart.title.LegendTitle var33 = var31.getLegend();
    org.jfree.chart.util.RectangleInsets var34 = var33.getItemLabelPadding();
    java.awt.Graphics2D var35 = null;
    org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint(1.0d, 2.0d);
    org.jfree.chart.util.Size2D var39 = var33.arrange(var35, var38);
    org.jfree.chart.util.RectangleEdge var40 = var33.getLegendItemGraphicEdge();
    org.jfree.chart.util.RectangleInsets var41 = var33.getLegendItemGraphicPadding();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.axis.CategoryAnchor var5 = var0.getDomainGridlinePosition();
//     org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
//     var6.clearDomainMarkers(0);
//     java.awt.Paint var9 = var6.getOutlinePaint();
//     boolean var10 = var6.isSubplot();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var14 = var11.getFixedRangeAxisSpace();
//     java.awt.Paint var15 = var11.getDomainGridlinePaint();
//     var6.setNoDataMessagePaint(var15);
//     boolean var17 = var6.isSubplot();
//     boolean var18 = var5.equals((java.lang.Object)var6);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
//     org.jfree.chart.block.LengthConstraintType var3 = var2.getWidthConstraintType();
//     org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(0.0d);
//     org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.util.Size2D var8 = var6.calculateDimensions(var7);
//     double var9 = var8.getHeight();
//     java.lang.Object var10 = var8.clone();
//     org.jfree.chart.util.Size2D var11 = var2.calculateConstrainedSize(var8);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     var1.setRange(0.05d, 0.05d);
//     var1.setRangeAboutValue(0.0d, 18.0d);
//     var1.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var28 = null;
//     var23.setDrawingSupplier(var28);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     float var32 = var31.getBackgroundImageAlpha();
//     java.awt.Graphics2D var33 = null;
//     org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets(0.0d, (-1.0d), 0.0d, 0.0d);
//     org.jfree.chart.axis.NumberAxis var40 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var40.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var45 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var46 = new org.jfree.chart.plot.PlotRenderingInfo(var45);
//     java.awt.geom.Rectangle2D var47 = var46.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot();
//     var48.clearDomainMarkers(0);
//     java.awt.Paint var51 = var48.getOutlinePaint();
//     boolean var52 = var48.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var53 = null;
//     int var54 = var48.getDomainAxisIndex(var53);
//     org.jfree.chart.axis.AxisLocation var56 = var48.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var57 = var48.getDomainAxisEdge();
//     double var58 = var40.valueToJava2D(10.0d, var47, var57);
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape)var47);
//     java.awt.geom.Rectangle2D var60 = var38.createInsetRectangle(var47);
//     org.jfree.chart.ChartRenderingInfo var61 = null;
//     var31.draw(var33, var47, var61);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//     org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
//     org.jfree.chart.event.RendererChangeEvent var3 = null;
//     var0.notifyListeners(var3);
//     org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
//     var0.setBaseToolTipGenerator(var5, true);
//     org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
//     var9.clearDomainMarkers(0);
//     org.jfree.chart.axis.AxisSpace var12 = var9.getFixedRangeAxisSpace();
//     java.awt.Paint var13 = var9.getDomainGridlinePaint();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     var9.setRangeAxis(var14);
//     var9.setBackgroundImageAlpha(0.0f);
//     org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var20 = var18.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var21 = var18.getTickMarkStroke();
//     var9.setDomainGridlineStroke(var21);
//     var0.setSeriesOutlineStroke(100, var21);
//     boolean var26 = var0.getItemCreateEntity(100, 0);
//     java.awt.Paint var28 = var0.lookupSeriesFillPaint((-1));
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot();
//     var30.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var34 = var30.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var35 = null;
//     var30.setDrawingSupplier(var35);
//     java.awt.Image var37 = null;
//     var30.setBackgroundImage(var37);
//     var30.setBackgroundImageAlpha(1.0f);
//     boolean var41 = var30.isDomainGridlinesVisible();
//     org.jfree.chart.axis.NumberAxis var43 = new org.jfree.chart.axis.NumberAxis("hi!");
//     var43.setAutoTickUnitSelection(true, true);
//     org.jfree.chart.ChartRenderingInfo var48 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var49 = new org.jfree.chart.plot.PlotRenderingInfo(var48);
//     java.awt.geom.Rectangle2D var50 = var49.getDataArea();
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
//     var51.clearDomainMarkers(0);
//     java.awt.Paint var54 = var51.getOutlinePaint();
//     boolean var55 = var51.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var56 = null;
//     int var57 = var51.getDomainAxisIndex(var56);
//     org.jfree.chart.axis.AxisLocation var59 = var51.getDomainAxisLocation(100);
//     org.jfree.chart.util.RectangleEdge var60 = var51.getDomainAxisEdge();
//     double var61 = var43.valueToJava2D(10.0d, var50, var60);
//     var0.drawDomainGridline(var29, var30, var50, (-100.95d));
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.05d, 10.0d);
//     org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
//     double var7 = var6.getUpperMargin();
//     java.awt.Font var9 = var6.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var10 = null;
//     org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("", var9, var10);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     double var13 = var12.getUpperMargin();
//     java.awt.Font var15 = var12.getTickLabelFont((java.lang.Comparable)10.0d);
//     var11.setFont(var15);
//     var11.setWidth(0.0d);
//     java.lang.Object var19 = null;
//     var4.add((org.jfree.chart.block.Block)var11, var19);
//     var11.setID("DatasetRenderingOrder.REVERSE");
//     java.awt.Graphics2D var23 = null;
//     org.jfree.data.Range var24 = null;
//     org.jfree.data.Range var25 = null;
//     org.jfree.chart.block.RectangleConstraint var26 = new org.jfree.chart.block.RectangleConstraint(var24, var25);
//     org.jfree.chart.util.Size2D var27 = var11.arrange(var23, var26);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var11 = var9.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot();
    var13.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var17 = var13.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var18 = null;
    var13.setDrawingSupplier(var18);
    org.jfree.chart.axis.CategoryAxis var20 = var13.getDomainAxis();
    java.util.List var21 = var13.getAnnotations();
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var9.drawRangeMarker(var12, var13, (org.jfree.chart.axis.ValueAxis)var23, var24, var25);
    var9.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var29 = var9.getBaseStroke();
    var9.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.labels.ItemLabelPosition var33 = var9.getSeriesNegativeItemLabelPosition(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-3407872), var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    java.awt.Shape var18 = var14.getUpArrow();
    var14.setAutoTickUnitSelection(true, true);
    org.jfree.chart.axis.NumberAxis var23 = new org.jfree.chart.axis.NumberAxis("hi!");
    var23.setAutoRangeIncludesZero(false);
    java.awt.Shape var26 = var23.getUpArrow();
    org.jfree.chart.entity.AxisLabelEntity var29 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var14, var26, "CategoryAnchor.MIDDLE", "hi!");
    double var30 = var14.getLowerBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.0d);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    java.lang.Boolean var9 = var0.getSeriesItemLabelsVisible((-1));
    org.jfree.chart.labels.ItemLabelPosition var11 = new org.jfree.chart.labels.ItemLabelPosition();
    java.lang.Object var12 = null;
    boolean var13 = var11.equals(var12);
    var0.setSeriesPositiveItemLabelPosition(255, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var2 = var0.getSeriesVisible((-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemToolTipGenerator(var3);
    boolean var5 = var0.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.labels.CategoryToolTipGenerator var8 = var0.getToolTipGenerator(100, (-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = var0.getLegendItemURLGenerator();
    boolean var10 = var0.getAutoPopulateSeriesShape();
    org.jfree.chart.annotations.CategoryAnnotation var11 = null;
    org.jfree.chart.util.Layer var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var11, var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var5 = var0.getRangeAxisLocation((-16777216));
    org.jfree.chart.axis.AxisSpace var6 = var0.getFixedRangeAxisSpace();
    org.jfree.chart.util.Layer var8 = null;
    java.util.Collection var9 = var0.getRangeMarkers((-1), var8);
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var12 = var10.getTickLabelPaint((java.lang.Comparable)18.0d);
    var0.setRangeGridlinePaint(var12);
    var0.clearDomainMarkers();
    boolean var15 = var0.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeColumn((-16777198));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = var0.getBaseURLGenerator();
    org.jfree.chart.labels.ItemLabelPosition var8 = var0.getPositiveItemLabelPosition((-16777216), (-16777216));
    boolean var9 = var0.getAutoPopulateSeriesPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    org.jfree.chart.labels.ItemLabelPosition var0 = new org.jfree.chart.labels.ItemLabelPosition();
    org.jfree.chart.labels.ItemLabelAnchor var1 = var0.getItemLabelAnchor();
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "ItemLabelAnchor.OUTSIDE12"+ "'", var2.equals("ItemLabelAnchor.OUTSIDE12"));

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var20 = var0.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var24 = var22.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var22.setLowerMargin(1.0d);
    org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis();
    double var28 = var27.getUpperMargin();
    java.awt.Font var30 = var27.getTickLabelFont((java.lang.Comparable)10.0d);
    var22.setTickLabelFont(var30);
    var0.setSeriesItemLabelFont(10, var30);
    org.jfree.chart.urls.CategoryURLGenerator var35 = var0.getURLGenerator(1, 101);
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot();
    var37.clearDomainMarkers(0);
    java.awt.Paint var40 = var37.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesItemLabelPaint((-1), var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = var0.getSeriesItemLabelGenerator((-1));
    var0.removeAnnotations();
    boolean var6 = var0.getAutoPopulateSeriesFillPaint();
    java.awt.Paint var8 = var0.lookupSeriesPaint(0);
    org.jfree.chart.annotations.CategoryAnnotation var9 = null;
    boolean var10 = var0.removeAnnotation(var9);
    org.jfree.chart.event.RendererChangeListener var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addChangeListener(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    org.jfree.chart.ChartRenderingInfo var19 = null;
    org.jfree.chart.plot.PlotRenderingInfo var20 = new org.jfree.chart.plot.PlotRenderingInfo(var19);
    java.awt.geom.Rectangle2D var21 = var20.getDataArea();
    org.jfree.chart.text.TextBlock var26 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.text.TextBlockAnchor var30 = null;
    java.awt.Shape var34 = var26.calculateBounds(var27, 0.0f, 100.0f, var30, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var37 = var35.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var38 = var35.getTickMarkStroke();
    java.awt.Color var40 = java.awt.Color.decode("18");
    float[] var41 = null;
    float[] var42 = var40.getRGBColorComponents(var41);
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var34, var38, (java.awt.Paint)var40);
    java.awt.image.ColorModel var44 = null;
    java.awt.Rectangle var45 = null;
    org.jfree.chart.plot.CategoryPlot var46 = new org.jfree.chart.plot.CategoryPlot();
    var46.clearDomainMarkers(0);
    org.jfree.chart.block.BlockContainer var49 = new org.jfree.chart.block.BlockContainer();
    boolean var50 = var46.equals((java.lang.Object)var49);
    java.util.List var51 = var49.getBlocks();
    java.awt.geom.Rectangle2D var52 = var49.getBounds();
    java.awt.geom.AffineTransform var53 = null;
    java.awt.RenderingHints var54 = null;
    java.awt.PaintContext var55 = var40.createContext(var44, var45, var52, var53, var54);
    var20.setDataArea((java.awt.geom.Rectangle2D)var45);
    java.awt.geom.Point2D var57 = null;
    var4.zoomDomainAxes(6.0d, var20, var57);
    boolean var59 = var4.isSubplot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var1 = var0.getRowCount();
    int var2 = var0.getRowCount();
    var0.removeObject((java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT", (java.lang.Comparable)"java.awt.Color[r=0,g=0,b=18]");
    var0.removeRow(0);
    int var8 = var0.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.notifyListeners(var3);
    org.jfree.chart.labels.CategoryToolTipGenerator var5 = null;
    var0.setBaseToolTipGenerator(var5, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var10 = var8.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot();
    var12.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var16 = var12.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var17 = null;
    var12.setDrawingSupplier(var17);
    org.jfree.chart.axis.CategoryAxis var19 = var12.getDomainAxis();
    java.util.List var20 = var12.getAnnotations();
    org.jfree.chart.axis.NumberAxis var22 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var23 = null;
    java.awt.geom.Rectangle2D var24 = null;
    var8.drawRangeMarker(var11, var12, (org.jfree.chart.axis.ValueAxis)var22, var23, var24);
    var8.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var28 = var8.getBaseStroke();
    var8.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var31 = var8.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var31);
    org.jfree.chart.LegendItemCollection var34 = new org.jfree.chart.LegendItemCollection();
    org.jfree.chart.ui.BasicProjectInfo var39 = new org.jfree.chart.ui.BasicProjectInfo("", "", "", "18");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var40 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    java.lang.Boolean var42 = var40.getSeriesVisible((-1));
    org.jfree.chart.labels.CategorySeriesLabelGenerator var43 = null;
    var40.setLegendItemToolTipGenerator(var43);
    boolean var45 = var40.getAutoPopulateSeriesFillPaint();
    boolean var46 = var39.equals((java.lang.Object)var40);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var47 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var49 = var47.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot();
    var51.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var55 = var51.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var56 = null;
    var51.setDrawingSupplier(var56);
    org.jfree.chart.axis.CategoryAxis var58 = var51.getDomainAxis();
    java.util.List var59 = var51.getAnnotations();
    org.jfree.chart.axis.NumberAxis var61 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var62 = null;
    java.awt.geom.Rectangle2D var63 = null;
    var47.drawRangeMarker(var50, var51, (org.jfree.chart.axis.ValueAxis)var61, var62, var63);
    var47.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var67 = var47.getBaseStroke();
    var47.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.labels.ItemLabelPosition var71 = var47.getSeriesNegativeItemLabelPosition(100);
    org.jfree.chart.labels.ItemLabelAnchor var72 = var71.getItemLabelAnchor();
    var40.setBasePositiveItemLabelPosition(var71, false);
    boolean var75 = var34.equals((java.lang.Object)var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-1), var71, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    org.jfree.chart.axis.NumberAxis var37 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var38 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var39 = null;
    org.jfree.chart.text.TextBlockAnchor var42 = null;
    java.awt.Shape var46 = var38.calculateBounds(var39, 0.0f, 100.0f, var42, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var49 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var37, var46, "HorizontalAlignment.CENTER", "hi!");
    var37.setRange(0.05d, 0.05d);
    var37.setRangeAboutValue(0.0d, 18.0d);
    var37.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot();
    var59.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var63 = var59.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var64 = null;
    var59.setDrawingSupplier(var64);
    var37.addChangeListener((org.jfree.chart.event.AxisChangeListener)var59);
    org.jfree.chart.JFreeChart var67 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var59);
    float var68 = var67.getBackgroundImageAlpha();
    java.awt.RenderingHints var69 = var67.getRenderingHints();
    var31.setRenderingHints(var69);
    org.jfree.chart.block.LineBorder var71 = new org.jfree.chart.block.LineBorder();
    org.jfree.chart.util.RectangleInsets var72 = var71.getInsets();
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.renderer.category.StatisticalBarRenderer var75 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.axis.CategoryAxis var77 = new org.jfree.chart.axis.CategoryAxis();
    double var78 = var77.getUpperMargin();
    java.awt.Font var80 = var77.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var81 = null;
    org.jfree.chart.block.LabelBlock var82 = new org.jfree.chart.block.LabelBlock("", var80, var81);
    var75.setBaseItemLabelFont(var80, true);
    org.jfree.chart.axis.CategoryAxis var85 = new org.jfree.chart.axis.CategoryAxis();
    double var86 = var85.getUpperMargin();
    java.awt.Font var88 = var85.getTickLabelFont((java.lang.Comparable)(short)10);
    var75.setBaseItemLabelFont(var88);
    org.jfree.chart.plot.CategoryPlot var90 = new org.jfree.chart.plot.CategoryPlot();
    var90.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var93 = var90.getFixedRangeAxisSpace();
    java.awt.Paint var94 = var90.getDomainGridlinePaint();
    var75.setBasePaint(var94);
    var74.setLabelPaint(var94);
    boolean var97 = var71.equals((java.lang.Object)var94);
    var31.setBackgroundPaint(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    java.awt.Font var2 = var1.getFont();
    java.lang.Object var3 = var1.clone();
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis();
    double var7 = var6.getUpperMargin();
    java.awt.Font var9 = var6.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var10 = null;
    org.jfree.chart.block.LabelBlock var11 = new org.jfree.chart.block.LabelBlock("", var9, var10);
    org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("", var9);
    java.awt.Font var13 = var12.getFont();
    var1.setFont(var13);
    org.jfree.chart.util.VerticalAlignment var15 = var1.getVerticalAlignment();
    java.awt.Font var16 = var1.getFont();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle("TextAnchor.CENTER", var16);
    java.lang.String var18 = var17.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "TextAnchor.CENTER"+ "'", var18.equals("TextAnchor.CENTER"));

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.text.TextBlock var9 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.text.TextBlockAnchor var13 = null;
    java.awt.Shape var17 = var9.calculateBounds(var10, 0.0f, 100.0f, var13, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var20 = var18.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var21 = var18.getTickMarkStroke();
    java.awt.Color var23 = java.awt.Color.decode("18");
    float[] var24 = null;
    float[] var25 = var23.getRGBColorComponents(var24);
    org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var17, var21, (java.awt.Paint)var23);
    java.awt.Color var29 = java.awt.Color.decode("18");
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot();
    var31.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var34 = var31.getFixedRangeAxisSpace();
    java.awt.Paint var35 = var31.getDomainGridlinePaint();
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot();
    var36.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var39 = var36.getFixedRangeAxisSpace();
    java.awt.Paint var40 = var36.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var41 = null;
    var36.setRangeAxis(var41);
    var36.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var47 = var45.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var48 = var45.getTickMarkStroke();
    var36.setDomainGridlineStroke(var48);
    org.jfree.chart.text.TextBlock var51 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var52 = null;
    org.jfree.chart.text.TextBlockAnchor var55 = null;
    java.awt.Shape var59 = var51.calculateBounds(var52, 0.0f, 100.0f, var55, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var60 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var62 = var60.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var63 = null;
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot();
    var64.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var68 = var64.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var69 = null;
    var64.setDrawingSupplier(var69);
    org.jfree.chart.axis.CategoryAxis var71 = var64.getDomainAxis();
    java.util.List var72 = var64.getAnnotations();
    org.jfree.chart.axis.NumberAxis var74 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var75 = null;
    java.awt.geom.Rectangle2D var76 = null;
    var60.drawRangeMarker(var63, var64, (org.jfree.chart.axis.ValueAxis)var74, var75, var76);
    var60.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var80 = var60.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var81 = new org.jfree.chart.axis.CategoryAxis();
    double var82 = var81.getUpperMargin();
    java.awt.Font var84 = var81.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var85 = var81.isTickMarksVisible();
    java.awt.Paint var86 = var81.getAxisLinePaint();
    org.jfree.chart.LegendItem var87 = new org.jfree.chart.LegendItem("18", "18", "HorizontalAlignment.CENTER", "HorizontalAlignment.CENTER", false, var17, false, (java.awt.Paint)var29, false, var35, var48, false, var59, var80, var86);
    var87.setSeriesKey((java.lang.Comparable)(byte)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var3 = var0.getFixedRangeAxisSpace();
    java.awt.Paint var4 = var0.getDomainGridlinePaint();
    org.jfree.chart.axis.ValueAxis var5 = null;
    var0.setRangeAxis(var5);
    var0.setBackgroundImageAlpha(0.0f);
    org.jfree.chart.axis.CategoryAxis var9 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var11 = var9.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var12 = var9.getTickMarkStroke();
    var0.setDomainGridlineStroke(var12);
    org.jfree.chart.axis.AxisSpace var14 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.CategoryMarker var15 = null;
    org.jfree.chart.util.Layer var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var15, var16);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(100.0d, 100.0d);
    var1.setAutoRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)(short)10);
    org.jfree.chart.util.RectangleInsets var4 = var0.getLabelInsets();
    var0.setCategoryMargin((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    double var1 = var0.getUpperMargin();
    java.awt.Font var3 = var0.getTickLabelFont((java.lang.Comparable)10.0d);
    boolean var4 = var0.isTickMarksVisible();
    java.awt.Paint var5 = var0.getAxisLinePaint();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    var6.clearDomainMarkers(0);
    java.awt.Paint var9 = var6.getOutlinePaint();
    java.awt.Paint var10 = var6.getNoDataMessagePaint();
    var0.setLabelPaint(var10);
    org.jfree.chart.event.AxisChangeEvent var12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.axis.CategoryAxis var16 = new org.jfree.chart.axis.CategoryAxis();
    double var17 = var16.getUpperMargin();
    java.awt.Font var19 = var16.getTickLabelFont((java.lang.Comparable)(short)10);
    java.awt.Paint var20 = null;
    org.jfree.chart.block.LabelBlock var21 = new org.jfree.chart.block.LabelBlock("", var19, var20);
    var14.setBaseItemLabelFont(var19, true);
    org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
    double var25 = var24.getUpperMargin();
    java.awt.Font var27 = var24.getTickLabelFont((java.lang.Comparable)(short)10);
    var14.setBaseItemLabelFont(var27);
    org.jfree.chart.text.TextBlock var33 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var34 = null;
    org.jfree.chart.text.TextBlockAnchor var37 = null;
    java.awt.Shape var41 = var33.calculateBounds(var34, 0.0f, 100.0f, var37, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var44 = var42.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var45 = var42.getTickMarkStroke();
    java.awt.Color var47 = java.awt.Color.decode("18");
    float[] var48 = null;
    float[] var49 = var47.getRGBColorComponents(var48);
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var41, var45, (java.awt.Paint)var47);
    int var51 = var47.getTransparency();
    org.jfree.chart.text.TextLine var52 = new org.jfree.chart.text.TextLine("", var27, (java.awt.Paint)var47);
    var0.setTickLabelFont(var27);
    var0.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);

  }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
//     var1.setRange(0.05d, 0.05d);
//     var1.setRangeAboutValue(0.0d, 18.0d);
//     var1.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
//     var23.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var28 = null;
//     var23.setDrawingSupplier(var28);
//     var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
//     float var32 = var31.getBackgroundImageAlpha();
//     java.awt.RenderingHints var33 = var31.getRenderingHints();
//     org.jfree.chart.title.LegendTitle var34 = var31.getLegend();
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.text.TextBlock var40 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var41 = null;
//     org.jfree.chart.text.TextBlockAnchor var44 = null;
//     java.awt.Shape var48 = var40.calculateBounds(var41, 0.0f, 100.0f, var44, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.axis.CategoryAxis var49 = new org.jfree.chart.axis.CategoryAxis();
//     java.lang.String var51 = var49.getCategoryLabelToolTip((java.lang.Comparable)10L);
//     java.awt.Stroke var52 = var49.getTickMarkStroke();
//     java.awt.Color var54 = java.awt.Color.decode("18");
//     float[] var55 = null;
//     float[] var56 = var54.getRGBColorComponents(var55);
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var48, var52, (java.awt.Paint)var54);
//     java.awt.image.ColorModel var58 = null;
//     java.awt.Rectangle var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot();
//     var60.clearDomainMarkers(0);
//     org.jfree.chart.block.BlockContainer var63 = new org.jfree.chart.block.BlockContainer();
//     boolean var64 = var60.equals((java.lang.Object)var63);
//     java.util.List var65 = var63.getBlocks();
//     java.awt.geom.Rectangle2D var66 = var63.getBounds();
//     java.awt.geom.AffineTransform var67 = null;
//     java.awt.RenderingHints var68 = null;
//     java.awt.PaintContext var69 = var54.createContext(var58, var59, var66, var67, var68);
//     var34.draw(var35, var66);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    org.jfree.chart.renderer.category.StatisticalBarRenderer var0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var2 = var0.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    var4.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var8 = var4.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var9 = null;
    var4.setDrawingSupplier(var9);
    org.jfree.chart.axis.CategoryAxis var11 = var4.getDomainAxis();
    java.util.List var12 = var4.getAnnotations();
    org.jfree.chart.axis.NumberAxis var14 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    var0.drawRangeMarker(var3, var4, (org.jfree.chart.axis.ValueAxis)var14, var15, var16);
    float var18 = var14.getTickMarkInsideLength();
    double var19 = var14.getUpperBound();
    boolean var20 = var14.isAutoTickUnitSelection();
    double var21 = var14.getFixedAutoRange();
    org.jfree.chart.event.AxisChangeEvent var22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.chart.text.TextBlock var1 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.text.TextBlockAnchor var5 = null;
    java.awt.Shape var9 = var1.calculateBounds(var2, 0.0f, 100.0f, var5, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.util.HorizontalAlignment var10 = var1.getLineAlignment();
    org.jfree.chart.text.TextBlock var11 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.text.TextBlockAnchor var15 = null;
    java.awt.Shape var19 = var11.calculateBounds(var12, 0.0f, 100.0f, var15, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.util.HorizontalAlignment var20 = var11.getLineAlignment();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.axis.CategoryLabelPositions var25 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.clearDomainMarkers(0);
    java.awt.Paint var29 = var26.getOutlinePaint();
    boolean var30 = var26.isSubplot();
    org.jfree.chart.axis.CategoryAxis var31 = null;
    int var32 = var26.getDomainAxisIndex(var31);
    org.jfree.chart.axis.AxisLocation var34 = var26.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var35 = var26.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var36 = var25.getLabelPosition(var35);
    float var37 = var36.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var38 = var36.getLabelAnchor();
    var11.draw(var21, 1.0f, 0.5f, var38);
    org.jfree.chart.text.TextAnchor var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryTick var42 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)'a', var1, var38, var40, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test491() {}
//   public void test491() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }
// 
// 
//     org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
//     var0.clearDomainMarkers(0);
//     java.awt.Paint var3 = var0.getOutlinePaint();
//     boolean var4 = var0.isSubplot();
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     double var6 = var5.getUpperMargin();
//     java.awt.Font var8 = var5.getTickLabelFont((java.lang.Comparable)10.0d);
//     boolean var9 = var5.isTickMarksVisible();
//     java.awt.Paint var10 = var5.getAxisLinePaint();
//     org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot();
//     var11.clearDomainMarkers(0);
//     java.awt.Paint var14 = var11.getOutlinePaint();
//     java.awt.Paint var15 = var11.getNoDataMessagePaint();
//     var5.setLabelPaint(var15);
//     org.jfree.chart.event.AxisChangeEvent var17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var5);
//     org.jfree.chart.axis.NumberAxis var19 = new org.jfree.chart.axis.NumberAxis("hi!");
//     org.jfree.chart.text.TextBlock var20 = new org.jfree.chart.text.TextBlock();
//     java.awt.Graphics2D var21 = null;
//     org.jfree.chart.text.TextBlockAnchor var24 = null;
//     java.awt.Shape var28 = var20.calculateBounds(var21, 0.0f, 100.0f, var24, 1.0f, (-1.0f), 1.0d);
//     org.jfree.chart.entity.AxisLabelEntity var31 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var19, var28, "HorizontalAlignment.CENTER", "hi!");
//     var19.setRange(0.05d, 0.05d);
//     var19.setRangeAboutValue(0.0d, 18.0d);
//     var19.setRangeWithMargins((-1.0d), 0.0d);
//     org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot();
//     var41.clearDomainMarkers(0);
//     org.jfree.chart.axis.ValueAxis var45 = var41.getRangeAxisForDataset(0);
//     org.jfree.chart.plot.DrawingSupplier var46 = null;
//     var41.setDrawingSupplier(var46);
//     var19.addChangeListener((org.jfree.chart.event.AxisChangeListener)var41);
//     org.jfree.chart.JFreeChart var49 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var41);
//     float var50 = var49.getBackgroundImageAlpha();
//     java.util.List var51 = var49.getSubtitles();
//     org.jfree.chart.title.TextTitle var52 = new org.jfree.chart.title.TextTitle();
//     java.awt.Font var53 = var52.getFont();
//     java.lang.Object var54 = var52.clone();
//     org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
//     double var58 = var57.getUpperMargin();
//     java.awt.Font var60 = var57.getTickLabelFont((java.lang.Comparable)(short)10);
//     java.awt.Paint var61 = null;
//     org.jfree.chart.block.LabelBlock var62 = new org.jfree.chart.block.LabelBlock("", var60, var61);
//     org.jfree.chart.text.TextFragment var63 = new org.jfree.chart.text.TextFragment("", var60);
//     java.awt.Font var64 = var63.getFont();
//     var52.setFont(var64);
//     org.jfree.chart.util.VerticalAlignment var66 = var52.getVerticalAlignment();
//     var49.removeSubtitle((org.jfree.chart.title.Title)var52);
//     var17.setChart(var49);
//     org.jfree.chart.JFreeChart var69 = var17.getChart();
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var69);
//     
//     // Checks the contract:  equals-hashcode on var0 and var11
//     assertTrue("Contract failed: equals-hashcode on var0 and var11", var0.equals(var11) ? var0.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var0
//     assertTrue("Contract failed: equals-hashcode on var11 and var0", var11.equals(var0) ? var11.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.text.TextBlock var0 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.util.Size2D var2 = var0.calculateDimensions(var1);
    java.lang.Object var3 = var2.clone();
    org.jfree.chart.axis.CategoryLabelPositions var7 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(0.0d);
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
    var8.clearDomainMarkers(0);
    java.awt.Paint var11 = var8.getOutlinePaint();
    boolean var12 = var8.isSubplot();
    org.jfree.chart.axis.CategoryAxis var13 = null;
    int var14 = var8.getDomainAxisIndex(var13);
    org.jfree.chart.axis.AxisLocation var16 = var8.getDomainAxisLocation(100);
    org.jfree.chart.util.RectangleEdge var17 = var8.getDomainAxisEdge();
    org.jfree.chart.axis.CategoryLabelPosition var18 = var7.getLabelPosition(var17);
    float var19 = var18.getWidthRatio();
    org.jfree.chart.text.TextBlockAnchor var20 = var18.getLabelAnchor();
    org.jfree.chart.util.RectangleAnchor var21 = var18.getCategoryAnchor();
    java.awt.geom.Rectangle2D var22 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 0.0d, 100.0d, var21);
    org.jfree.chart.util.RectangleAnchor var25 = null;
    java.awt.geom.Rectangle2D var26 = org.jfree.chart.util.RectangleAnchor.createRectangle(var2, 10.0d, 0.0d, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    boolean var15 = var13.equals((java.lang.Object)(short)10);
    java.lang.String var16 = var13.getURLText();
    var13.setURLText("java.awt.Color[r=0,g=0,b=18]");
    java.lang.String var19 = var13.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "hi!"+ "'", var16.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "AxisLabelEntity: label = hi!"+ "'", var19.equals("AxisLabelEntity: label = hi!"));

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    var1.addChangeListener((org.jfree.chart.event.AxisChangeListener)var23);
    org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot)var23);
    float var32 = var31.getBackgroundImageAlpha();
    java.util.List var33 = var31.getSubtitles();
    org.jfree.chart.event.ChartProgressListener var34 = null;
    var31.removeProgressListener(var34);
    java.util.List var36 = var31.getSubtitles();
    java.util.Collection var37 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    var0.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var4 = var0.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var5 = null;
    var0.setDrawingSupplier(var5);
    java.awt.Stroke var7 = var0.getOutlineStroke();
    org.jfree.chart.LegendItemCollection var8 = var0.getLegendItems();
    org.jfree.chart.plot.CategoryPlot var9 = new org.jfree.chart.plot.CategoryPlot();
    var9.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var13 = var9.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var14 = null;
    var9.setDrawingSupplier(var14);
    java.awt.Image var16 = null;
    var9.setBackgroundImage(var16);
    var9.setBackgroundImageAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var22 = var20.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var20.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var25 = var20.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var28 = var26.getCategoryLabelToolTip((java.lang.Comparable)10L);
    var26.setLowerMargin(1.0d);
    org.jfree.chart.util.RectangleInsets var31 = var26.getTickLabelInsets();
    var20.setLabelInsets(var31);
    double var33 = var31.getRight();
    double var34 = var31.getBottom();
    var9.setInsets(var31);
    boolean var36 = var8.equals((java.lang.Object)var9);
    var9.setAnchorValue(0.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedHeight(0.0d);
    double var5 = var4.getWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.plot.ValueMarker var1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    org.jfree.chart.text.TextBlock var6 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var7 = null;
    org.jfree.chart.text.TextBlockAnchor var10 = null;
    java.awt.Shape var14 = var6.calculateBounds(var7, 0.0f, 100.0f, var10, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    java.lang.String var17 = var15.getCategoryLabelToolTip((java.lang.Comparable)10L);
    java.awt.Stroke var18 = var15.getTickMarkStroke();
    java.awt.Color var20 = java.awt.Color.decode("18");
    float[] var21 = null;
    float[] var22 = var20.getRGBColorComponents(var21);
    org.jfree.chart.LegendItem var23 = new org.jfree.chart.LegendItem("18", "", "", "java.awt.Color[r=0,g=0,b=18]", var14, var18, (java.awt.Paint)var20);
    java.lang.String var24 = var20.toString();
    var1.setPaint((java.awt.Paint)var20);
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot();
    var26.clearDomainMarkers(0);
    org.jfree.chart.axis.AxisSpace var29 = var26.getFixedRangeAxisSpace();
    var26.setRangeCrosshairLockedOnData(false);
    org.jfree.chart.event.MarkerChangeEvent var32 = null;
    var26.markerChanged(var32);
    boolean var34 = var26.isDomainZoomable();
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var26);
    java.awt.Paint var36 = var1.getLabelPaint();
    org.jfree.chart.renderer.category.StatisticalBarRenderer var37 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var39 = var37.getSeriesURLGenerator((-16777216));
    org.jfree.chart.event.RendererChangeEvent var40 = null;
    var37.notifyListeners(var40);
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var37.setBaseToolTipGenerator(var42, true);
    org.jfree.chart.renderer.category.StatisticalBarRenderer var45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var47 = var45.getSeriesURLGenerator((-16777216));
    org.jfree.chart.util.GradientPaintTransformer var48 = null;
    var45.setGradientPaintTransformer(var48);
    java.awt.Shape var51 = var45.lookupSeriesShape((-16777216));
    org.jfree.chart.renderer.category.StatisticalBarRenderer var52 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var54 = var52.getSeriesURLGenerator((-16777216));
    java.awt.Graphics2D var55 = null;
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot();
    var56.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var60 = var56.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var61 = null;
    var56.setDrawingSupplier(var61);
    org.jfree.chart.axis.CategoryAxis var63 = var56.getDomainAxis();
    java.util.List var64 = var56.getAnnotations();
    org.jfree.chart.axis.NumberAxis var66 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.plot.Marker var67 = null;
    java.awt.geom.Rectangle2D var68 = null;
    var52.drawRangeMarker(var55, var56, (org.jfree.chart.axis.ValueAxis)var66, var67, var68);
    var52.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Stroke var72 = var52.getBaseStroke();
    var45.setErrorIndicatorStroke(var72);
    var37.setErrorIndicatorStroke(var72);
    var1.setOutlineStroke(var72);
    org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot();
    var76.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var80 = var76.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var81 = null;
    var76.setDrawingSupplier(var81);
    java.awt.Image var83 = null;
    var76.setBackgroundImage(var83);
    org.jfree.chart.plot.PlotRenderingInfo var87 = null;
    java.awt.geom.Point2D var88 = null;
    var76.zoomRangeAxes(1.0d, 0.0d, var87, var88);
    var1.addChangeListener((org.jfree.chart.event.MarkerChangeListener)var76);
    var76.setRangeCrosshairVisible(true);
    org.jfree.data.category.CategoryDataset var93 = var76.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + "java.awt.Color[r=0,g=0,b=18]"+ "'", var24.equals("java.awt.Color[r=0,g=0,b=18]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("poly", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("hi!");
    org.jfree.chart.text.TextBlock var2 = new org.jfree.chart.text.TextBlock();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.text.TextBlockAnchor var6 = null;
    java.awt.Shape var10 = var2.calculateBounds(var3, 0.0f, 100.0f, var6, 1.0f, (-1.0f), 1.0d);
    org.jfree.chart.entity.AxisLabelEntity var13 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var10, "HorizontalAlignment.CENTER", "hi!");
    var1.setRange(0.05d, 0.05d);
    var1.setRangeAboutValue(0.0d, 18.0d);
    var1.setRangeWithMargins((-1.0d), 0.0d);
    var1.setAutoRangeMinimumSize(101.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.plot.CategoryPlot var1 = new org.jfree.chart.plot.CategoryPlot();
    var1.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var5 = var1.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var6 = null;
    var1.setDrawingSupplier(var6);
    java.awt.Image var8 = null;
    var1.setBackgroundImage(var8);
    var1.setBackgroundImageAlpha(1.0f);
    org.jfree.data.general.DatasetGroup var12 = var1.getDatasetGroup();
    org.jfree.chart.axis.AxisSpace var13 = var1.getFixedDomainAxisSpace();
    org.jfree.chart.util.RectangleInsets var14 = var1.getAxisOffset();
    org.jfree.chart.util.UnitType var15 = var14.getUnitType();
    org.jfree.chart.util.RectangleInsets var20 = new org.jfree.chart.util.RectangleInsets(var15, 0.0d, 1.0d, 2.0d, 100.0d);
    boolean var21 = var0.equals((java.lang.Object)2.0d);
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot();
    var23.clearDomainMarkers(0);
    org.jfree.chart.axis.ValueAxis var27 = var23.getRangeAxisForDataset(0);
    org.jfree.chart.plot.DrawingSupplier var28 = null;
    var23.setDrawingSupplier(var28);
    org.jfree.chart.axis.CategoryAxis var30 = var23.getDomainAxis();
    java.util.List var31 = var23.getAnnotations();
    org.jfree.data.category.CategoryDataset var32 = null;
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = var23.getRendererForDataset(var32);
    var23.mapDatasetToRangeAxis(0, (-1));
    java.awt.Stroke var37 = var23.getDomainGridlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setStroke((-16777198), var37);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

}
