
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() {}
//   public void test1() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "January"+ "'", var1.equals("January"));

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(1, 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(1, var1);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test11() {}
//   public void test11() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(100, var1);
// 
//   }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.util.Calendar var3 = null;
//     var2.peg(var3);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(100, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, (-1), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", var1);
// 
//   }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(0, var1);
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getFirstMillisecond(var3);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(1, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var5 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var5 = var4.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setMaximumItemAge((-1L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     java.util.Calendar var7 = null;
//     var5.peg(var7);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     java.util.TimeZone var3 = null;
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year(var2, var3);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var3.getValue(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("January", var1);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(21, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Sunday"+ "'", var1.equals("Sunday"));

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     int var5 = var2.compareTo((java.lang.Object)0);
//     java.util.Calendar var6 = null;
//     long var7 = var2.getFirstMillisecond(var6);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
    org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
    java.lang.Number var5 = var3.getValue((org.jfree.data.time.RegularTimePeriod)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test43() {}
//   public void test43() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2, var4);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(21, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     boolean var17 = var5.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var20 = var5.createCopy(10, 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("January");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     var2.setDescription("");
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     int var8 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.Object var10 = null;
//     int var11 = var9.compareTo(var10);
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     boolean var15 = var13.equals((java.lang.Object)var14);
//     java.lang.Object var16 = var13.clone();
//     org.jfree.data.time.RegularTimePeriod var17 = var13.getPeriod();
//     var2.add(var13, true);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)'#');
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var5.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getLastMillisecond(var9);
// 
//   }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    var2.setDescription("");
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
    java.lang.Object var6 = null;
    int var7 = var5.compareTo(var6);
    int var8 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.general.SeriesChangeEvent var9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
    org.jfree.data.time.RegularTimePeriod var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(var10, (java.lang.Number)10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-1), 2014, 2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     int var18 = var17.getDayOfMonth();
//     java.util.Date var19 = var17.getEnd();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(var19);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     java.lang.Object var23 = null;
//     int var24 = var22.compareTo(var23);
//     boolean var25 = var21.equals((java.lang.Object)var22);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)(byte)0);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var6 = var4.getNearestDayOfWeek(21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var4);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = var4.getNearestDayOfWeek(10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 100, 13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var14 = var6.getFollowingDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("January", var1);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(13, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
// 
//   }

  public void test71() {}
//   public void test71() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ThreadContext", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     long var4 = var2.getMiddleMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var2.getFirstMillisecond(var5);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     int var7 = var5.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var8 = var5.previous();
//     java.util.Calendar var9 = null;
//     var5.peg(var9);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var30 = var4.getValue(1900);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2014, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("January");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     java.util.Calendar var10 = null;
//     long var11 = var7.getLastMillisecond(var10);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(var3);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Sunday");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.setMaximumItemAge((-62167363200000L));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-41981));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    boolean var3 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var5 = var2.getDataItem(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     java.util.Calendar var7 = null;
//     long var8 = var5.getLastMillisecond(var7);
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sunday", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var14);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     java.lang.Object var18 = null;
//     int var19 = var17.compareTo(var18);
//     boolean var20 = var16.equals((java.lang.Object)var17);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var17, 10.0d, true);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Last"+ "'", var1.equals("Last"));

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     java.lang.Number var5 = var3.getValue((org.jfree.data.time.RegularTimePeriod)var4);
//     java.util.Calendar var6 = null;
//     long var7 = var4.getFirstMillisecond(var6);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getLastMillisecond(var6);
// 
//   }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     java.util.Calendar var29 = null;
//     long var30 = var13.getMiddleMillisecond(var29);
// 
//   }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var2 = null;
//     boolean var3 = var1.isOnOrBefore(var2);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("21-December-2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var2, var5);
// 
//   }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 100, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test104() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Sunday", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Sunday");

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     int var5 = var2.compareTo((java.lang.Object)0);
//     org.jfree.data.time.RegularTimePeriod var6 = var2.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var7 = var2.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 2147483647, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     var4.clear();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.RegularTimePeriod var13 = var12.previous();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("October 2014", var1);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(1, (-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     var4.clear();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     int var13 = var7.getDayOfMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var6);
//     java.util.Calendar var8 = null;
//     long var9 = var6.getLastMillisecond(var8);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    var5.removeAgedItems(false);
    java.lang.Object var9 = var5.clone();
    java.util.List var10 = var5.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var12 = var5.getTimePeriod(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test117() {}
//   public void test117() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     boolean var18 = var7.isInRange(var12, var16, (-1));
//     org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var21 = var19.getFollowingDayOfWeek(2014);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test118() {}
//   public void test118() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("21-December-2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     long var1 = var0.getFirstMillisecond();
//     int var2 = var0.getYear();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     java.util.Date var5 = var0.getEnd();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "SerialDate.weekInMonthToString(): invalid code.", "ThreadContext", var8);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     java.util.Date var12 = var10.getEnd();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(var12);
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var16);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     int var23 = var22.getDayOfMonth();
//     java.util.Date var24 = var22.getEnd();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var24);
//     org.jfree.data.time.TimeSeriesDataItem var27 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var29 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     long var30 = var25.getFirstMillisecond();
//     boolean var31 = var14.equals((java.lang.Object)var25);
//     org.jfree.data.time.RegularTimePeriod var32 = var14.next();
//     var9.add((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(byte)10);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     java.util.Calendar var4 = null;
//     var2.peg(var4);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.TimeSeriesDataItem var12 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 0.0d);
//     java.util.Calendar var15 = null;
//     long var16 = var10.getFirstMillisecond(var15);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("21-December-2014", var1);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var22);
//     var23.removeAgedItems(true);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     int var28 = var23.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     java.util.Collection var29 = var4.getTimePeriodsUniqueToOtherSeries(var23);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.delete(1, 21);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(0, 1900, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test128() {}
//   public void test128() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     java.util.Calendar var17 = null;
//     long var18 = var14.getFirstMillisecond(var17);
// 
//   }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    java.lang.Object var1 = null;
    int var2 = var0.compareTo(var1);
    org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
    java.util.Date var5 = var0.getEnd();
    java.lang.Class var8 = null;
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0, "SerialDate.weekInMonthToString(): invalid code.", "ThreadContext", var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"ThreadContext");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     int var16 = var1.getDayOfMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var18 = var1.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 12);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var5 = var4.isEmpty();
    var4.setMaximumItemAge(1419148800000L);
    var4.setDescription("");
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
    long var12 = var11.getFirstMillisecond();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.update((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)10);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-62167363200000L));

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var18 = var5.getDataItem((-1));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     int var4 = var3.getDayOfMonth();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var13 = var2.isInRange(var7, var11, (-1));
//     int var14 = var2.getYYYY();
//     int var15 = var2.getYYYY();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addYears((-41981), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1900);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-41981));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var17, var19);
//     org.jfree.data.time.Year var21 = var17.getYear();
//     java.util.Calendar var22 = null;
//     long var23 = var21.getFirstMillisecond(var22);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     int var7 = var5.getDayOfMonth();
//     org.jfree.data.time.RegularTimePeriod var8 = var5.previous();
//     long var9 = var5.getSerialIndex();
//     java.util.Calendar var10 = null;
//     var5.peg(var10);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var19 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 0.0d);
//     long var20 = var15.getFirstMillisecond();
//     boolean var21 = var4.equals((java.lang.Object)var15);
//     org.jfree.data.time.RegularTimePeriod var22 = var4.next();
//     org.jfree.data.time.RegularTimePeriod var23 = var4.next();
//     java.util.Calendar var24 = null;
//     long var25 = var4.getLastMillisecond(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1419235199999L);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("SerialDate.weekInMonthToString(): invalid code.", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December 2014", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     java.lang.Object var5 = var4.clone();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     boolean var18 = var7.isInRange(var12, var16, (-1));
//     int var19 = var4.compareTo((java.lang.Object)var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ERROR : Relative To String", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     var4.removeAgedItems(false);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     int var22 = var21.getDayOfMonth();
//     java.util.Date var23 = var21.getEnd();
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(var23);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(var23);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year(var23);
//     long var27 = var26.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var29 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, 100.0d);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     int var31 = var30.getDayOfMonth();
//     java.util.Date var32 = var30.getEnd();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(var32);
//     java.util.Calendar var34 = null;
//     long var35 = var33.getFirstMillisecond(var34);
//     java.lang.Class var37 = null;
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var37);
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var40);
//     java.util.Collection var42 = var38.getTimePeriodsUniqueToOtherSeries(var41);
//     boolean var43 = var33.equals((java.lang.Object)var41);
//     boolean var45 = var33.equals((java.lang.Object)(short)100);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var33, 1.0d);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var5);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var8);
//     java.util.Collection var10 = var6.getTimePeriodsUniqueToOtherSeries(var9);
//     int var11 = var3.compareTo((java.lang.Object)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.Object var13 = null;
//     int var14 = var12.compareTo(var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)0.0f);
//     java.lang.Object var17 = var16.clone();
//     java.lang.Object var18 = var16.clone();
//     int var19 = var3.compareTo((java.lang.Object)var16);
//     java.lang.Object var20 = var16.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var22);
//     var23.removeAgedItems(true);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     long var27 = var26.getFirstMillisecond();
//     int var28 = var23.getIndex((org.jfree.data.time.RegularTimePeriod)var26);
//     java.util.Collection var29 = var4.getTimePeriodsUniqueToOtherSeries(var23);
//     org.jfree.data.time.TimeSeries var30 = null;
//     java.util.Collection var31 = var23.getTimePeriodsUniqueToOtherSeries(var30);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var23 = var16.getSerialDate();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     int var33 = var32.getDayOfMonth();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     boolean var37 = var26.isInRange(var31, var35, (-1));
//     int var38 = var26.getYYYY();
//     int var39 = var26.getYYYY();
//     org.jfree.data.time.SerialDate var41 = var26.getFollowingDayOfWeek(1);
//     boolean var42 = var1.isInRange(var23, (org.jfree.data.time.SerialDate)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var44 = var26.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=24180]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ThreadContext");

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var5);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var8);
//     java.util.Collection var10 = var6.getTimePeriodsUniqueToOtherSeries(var9);
//     int var11 = var3.compareTo((java.lang.Object)var9);
//     java.lang.String var12 = var9.getDescription();
//     org.jfree.data.time.RegularTimePeriod var13 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var14 = var9.getDataItem(var13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-41981), 1900, 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-1), (-460), (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     int var5 = var2.compareTo((java.lang.Object)0);
//     long var6 = var2.getSerialIndex();
//     long var7 = var2.getSerialIndex();
//     int var8 = var2.getYearValue();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var9 = var2.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("January");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     var4.setNotify(false);
//     java.lang.Comparable var19 = var4.getKey();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     java.lang.Object var21 = null;
//     int var22 = var20.compareTo(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     boolean var26 = var24.equals((java.lang.Object)var25);
//     java.lang.Object var27 = var24.clone();
//     org.jfree.data.time.RegularTimePeriod var28 = var24.getPeriod();
//     org.jfree.data.time.RegularTimePeriod var29 = var24.getPeriod();
//     var4.add(var24, false);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.util.Calendar var9 = null;
//     long var10 = var5.getFirstMillisecond(var9);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var5 = var4.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var4.getValue(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     var2.setNotify(false);
//     var2.removeAgedItems(24180L, true);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Sunday");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.util.Calendar var9 = null;
//     var5.peg(var9);
// 
//   }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries(var0, "ERROR : Relative To String", "org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     long var4 = var2.getMiddleMillisecond();
//     java.util.Calendar var5 = null;
//     var2.peg(var5);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var19 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 0.0d);
//     long var20 = var15.getFirstMillisecond();
//     boolean var21 = var4.equals((java.lang.Object)var15);
//     java.util.Calendar var22 = null;
//     var4.peg(var22);
//     java.lang.Class var26 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var22, "SerialDate.weekInMonthToString(): invalid code.", "December 2014", var26);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var23 = var16.getSerialDate();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     int var33 = var32.getDayOfMonth();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     boolean var37 = var26.isInRange(var31, var35, (-1));
//     int var38 = var26.getYYYY();
//     int var39 = var26.getYYYY();
//     org.jfree.data.time.SerialDate var41 = var26.getFollowingDayOfWeek(1);
//     boolean var42 = var1.isInRange(var23, (org.jfree.data.time.SerialDate)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var44 = var23.getFollowingDayOfWeek(2147483647);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
// 
//   }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var9);
//     java.util.Collection var11 = var7.getTimePeriodsUniqueToOtherSeries(var10);
//     var10.removeAgedItems(false);
//     java.lang.Object var14 = var10.clone();
//     java.util.List var15 = var10.getItems();
//     boolean var16 = var4.equals((java.lang.Object)var10);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var20);
//     var21.removeAgedItems(true);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     int var26 = var25.getDayOfMonth();
//     java.util.Date var27 = var25.getEnd();
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(var27);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var27);
//     org.jfree.data.time.Year var30 = new org.jfree.data.time.Year(var27);
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(10, var30);
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var35);
//     boolean var38 = var36.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(1, 0);
//     long var42 = var41.getMiddleMillisecond();
//     var36.delete((org.jfree.data.time.RegularTimePeriod)var41);
//     long var44 = var41.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var45 = var21.createCopy((org.jfree.data.time.RegularTimePeriod)var30, (org.jfree.data.time.RegularTimePeriod)var41);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)1L, false);
// 
//   }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     long var10 = var4.getFirstMillisecond();
//     long var11 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     long var13 = var4.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
// 
//   }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(13, 2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(12, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Dec"+ "'", var2.equals("Dec"));

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     var4.clear();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var13 = var4.getNextTimePeriod();
//     var4.removeAgedItems(1417420800000L, true);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     org.jfree.data.time.SerialDate var16 = var1.getFollowingDayOfWeek(1);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var20);
//     var21.removeAgedItems(true);
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var21.addChangeListener(var24);
//     org.jfree.data.general.SeriesChangeListener var26 = null;
//     var21.removeChangeListener(var26);
//     org.jfree.data.general.SeriesChangeListener var28 = null;
//     var21.removeChangeListener(var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var30 = var1.compareTo((java.lang.Object)var21);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    java.lang.Object var1 = null;
    int var2 = var0.compareTo(var1);
    org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
    boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)'#');
    org.jfree.data.time.SerialDate var7 = var0.getSerialDate();
    org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = var7.getPreviousDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(13, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
    java.lang.Object var1 = null;
    int var2 = var0.compareTo(var1);
    org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
    org.jfree.data.time.RegularTimePeriod var5 = var4.getPeriod();
    java.lang.Number var6 = var4.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0.0f+ "'", var6.equals(0.0f));

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("October 2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    boolean var8 = var2.equals((java.lang.Object)"");
    org.jfree.data.time.RegularTimePeriod var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(var9, (java.lang.Number)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     var4.clear();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     int var13 = var7.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var4 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2, var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     java.lang.Object var4 = null;
//     int var5 = var3.compareTo(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var8 = var3.getSerialDate();
//     boolean var9 = var2.isOnOrAfter(var8);
//     java.util.Date var10 = var2.toDate();
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var13 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var12);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     int var17 = var16.getDayOfMonth();
//     java.util.Date var18 = var16.getEnd();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     int var22 = var21.getDayOfMonth();
//     java.util.Date var23 = var21.getEnd();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     boolean var26 = var15.isInRange(var20, var24, (-1));
//     int var27 = var12.compareTo((java.lang.Object)var15);
//     org.jfree.data.time.SpreadsheetDate var29 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     java.lang.Object var31 = null;
//     int var32 = var30.compareTo(var31);
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var35 = var30.getSerialDate();
//     boolean var36 = var29.isOnOrAfter(var35);
//     java.util.Date var37 = var29.toDate();
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day();
//     java.lang.Object var41 = null;
//     int var42 = var40.compareTo(var41);
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var40, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var45 = var40.getSerialDate();
//     boolean var46 = var39.isOnOrAfter(var45);
//     int var47 = var29.compare((org.jfree.data.time.SerialDate)var39);
//     int var48 = var29.getDayOfMonth();
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     java.lang.Object var50 = null;
//     int var51 = var49.compareTo(var50);
//     org.jfree.data.time.TimeSeriesDataItem var53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var54 = var49.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     int var58 = var57.getDayOfMonth();
//     java.util.Date var59 = var57.getEnd();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month(var59);
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     int var63 = var62.getDayOfMonth();
//     java.util.Date var64 = var62.getEnd();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.createInstance(var64);
//     boolean var67 = var56.isInRange(var61, var65, (-1));
//     org.jfree.data.time.SerialDate var68 = var54.getEndOfCurrentMonth(var65);
//     boolean var69 = var12.isInRange((org.jfree.data.time.SerialDate)var29, var54);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.addMonths(10, (org.jfree.data.time.SerialDate)var12);
//     java.lang.String var71 = var70.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var71 + "' != '" + "12-November-1900"+ "'", var71.equals("12-November-1900"));
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     var4.setNotify(false);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     java.lang.Object var20 = null;
//     int var21 = var19.compareTo(var20);
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day();
//     boolean var25 = var23.equals((java.lang.Object)var24);
//     java.lang.Object var26 = var23.clone();
//     org.jfree.data.time.RegularTimePeriod var27 = var23.getPeriod();
//     var4.add(var27, (java.lang.Number)12);
// 
//   }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(13);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     var5.setNotify(false);
//     int var11 = var5.getMaximumItemCount();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.Object var13 = null;
//     int var14 = var12.compareTo(var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     boolean var18 = var16.equals((java.lang.Object)var17);
//     java.lang.Object var19 = var16.clone();
//     var16.setValue((java.lang.Number)100.0d);
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     int var25 = var24.getYearValue();
//     int var26 = var16.compareTo((java.lang.Object)var24);
//     var5.add(var16);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.SerialDate var13 = var7.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     int var17 = var16.getDayOfMonth();
//     java.util.Date var18 = var16.getEnd();
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     int var22 = var21.getDayOfMonth();
//     java.util.Date var23 = var21.getEnd();
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var23);
//     boolean var26 = var15.isInRange(var20, var24, (-1));
//     int var27 = var15.getYYYY();
//     int var28 = var15.getYYYY();
//     int var29 = var15.getMonth();
//     org.jfree.data.time.SerialDate var30 = var12.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var15);
//     org.jfree.data.time.SerialDate var31 = null;
//     org.jfree.data.time.SpreadsheetDate var33 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var36);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     int var40 = var39.getDayOfMonth();
//     java.util.Date var41 = var39.getEnd();
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(var41);
//     boolean var44 = var33.isInRange(var38, var42, (-1));
//     int var45 = var33.getYYYY();
//     int var46 = var33.getYYYY();
//     org.jfree.data.time.SerialDate var48 = var33.getFollowingDayOfWeek(1);
//     boolean var49 = var15.isInRange(var31, (org.jfree.data.time.SerialDate)var33);
// 
//   }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)1.0d);
//     org.jfree.data.time.RegularTimePeriod var14 = null;
//     java.lang.Number var15 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var16 = var3.addOrUpdate(var14, var15);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     org.jfree.data.time.RegularTimePeriod var29 = var13.next();
//     java.util.Calendar var30 = null;
//     var13.peg(var30);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    var4.removeAgedItems(true);
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var4.addChangeListener(var7);
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var4.removeChangeListener(var9);
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var4.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     int var15 = var14.getDayOfMonth();
//     java.util.Date var16 = var14.getEnd();
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var16);
//     long var18 = var17.getSerialIndex();
//     java.util.Date var19 = var17.getStart();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var19);
//     int var21 = var20.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var1.compareTo((java.lang.Object)var20);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 12);
// 
//   }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Dec", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("December 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-41981));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var5);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var8);
//     java.util.Collection var10 = var6.getTimePeriodsUniqueToOtherSeries(var9);
//     int var11 = var3.compareTo((java.lang.Object)var9);
//     java.lang.String var12 = var9.getDescription();
//     var9.removeAgedItems(0L, false);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     int var9 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var7);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var11 = var4.getTimePeriod(1900);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)1.0d);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
//     org.jfree.data.time.RegularTimePeriod var16 = var15.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.add(var16, 0.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("12-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-41981), 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     int var6 = var5.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(byte)0);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.Object var10 = null;
//     int var11 = var9.compareTo(var10);
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     boolean var15 = var13.equals((java.lang.Object)var14);
//     java.lang.Object var16 = var13.clone();
//     org.jfree.data.time.RegularTimePeriod var17 = var13.getPeriod();
//     org.jfree.data.time.RegularTimePeriod var18 = var13.getPeriod();
//     int var19 = var8.compareTo((java.lang.Object)var18);
//     java.lang.String var20 = var18.toString();
//     var4.add(var18, (java.lang.Number)1419148800000L);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(12);
//     org.jfree.data.time.SerialDate var2 = null;
//     boolean var3 = var1.isOnOrBefore(var2);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     java.lang.Object var5 = null;
//     int var6 = var4.compareTo(var5);
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var9 = var4.getSerialDate();
//     boolean var10 = var3.isOnOrAfter(var9);
//     java.util.Date var11 = var3.toDate();
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var14 = var3.isOnOrAfter((org.jfree.data.time.SerialDate)var13);
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     int var18 = var17.getDayOfMonth();
//     java.util.Date var19 = var17.getEnd();
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var19);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     int var23 = var22.getDayOfMonth();
//     java.util.Date var24 = var22.getEnd();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     boolean var27 = var16.isInRange(var21, var25, (-1));
//     int var28 = var13.compareTo((java.lang.Object)var16);
//     org.jfree.data.time.SpreadsheetDate var30 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     java.lang.Object var32 = null;
//     int var33 = var31.compareTo(var32);
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var36 = var31.getSerialDate();
//     boolean var37 = var30.isOnOrAfter(var36);
//     java.util.Date var38 = var30.toDate();
//     org.jfree.data.time.SpreadsheetDate var40 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     java.lang.Object var42 = null;
//     int var43 = var41.compareTo(var42);
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var46 = var41.getSerialDate();
//     boolean var47 = var40.isOnOrAfter(var46);
//     int var48 = var30.compare((org.jfree.data.time.SerialDate)var40);
//     int var49 = var30.getDayOfMonth();
//     org.jfree.data.time.Day var50 = new org.jfree.data.time.Day();
//     java.lang.Object var51 = null;
//     int var52 = var50.compareTo(var51);
//     org.jfree.data.time.TimeSeriesDataItem var54 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var50, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var55 = var50.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     int var59 = var58.getDayOfMonth();
//     java.util.Date var60 = var58.getEnd();
//     org.jfree.data.time.Month var61 = new org.jfree.data.time.Month(var60);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var60);
//     org.jfree.data.time.Day var63 = new org.jfree.data.time.Day();
//     int var64 = var63.getDayOfMonth();
//     java.util.Date var65 = var63.getEnd();
//     org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(var65);
//     boolean var68 = var57.isInRange(var62, var66, (-1));
//     org.jfree.data.time.SerialDate var69 = var55.getEndOfCurrentMonth(var66);
//     boolean var70 = var13.isInRange((org.jfree.data.time.SerialDate)var30, var55);
//     org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.addMonths(10, (org.jfree.data.time.SerialDate)var13);
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     int var75 = var74.getDayOfMonth();
//     java.util.Date var76 = var74.getEnd();
//     org.jfree.data.time.Month var77 = new org.jfree.data.time.Month(var76);
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var76);
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     int var80 = var79.getDayOfMonth();
//     java.util.Date var81 = var79.getEnd();
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.createInstance(var81);
//     boolean var84 = var73.isInRange(var78, var82, (-1));
//     int var85 = var73.getYYYY();
//     int var86 = var73.getYYYY();
//     org.jfree.data.time.Day var88 = new org.jfree.data.time.Day();
//     int var89 = var88.getDayOfMonth();
//     java.util.Date var90 = var88.getEnd();
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.createInstance(var90);
//     org.jfree.data.time.SerialDate var92 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var91);
//     int var93 = var73.compare(var92);
//     boolean var94 = var13.isOnOrAfter(var92);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var95 = org.jfree.data.time.SerialDate.addDays((-460), (org.jfree.data.time.SerialDate)var13);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var94 == false);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ThreadContext", var1);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419148800000L);
//     var4.setDescription("");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.Object var11 = null;
//     int var12 = var10.compareTo(var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)0.0f);
//     java.lang.Object var15 = var14.clone();
//     var4.add(var14, true);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var2, var5);
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     java.lang.Object var2 = null;
//     int var3 = var1.compareTo(var2);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)0.0f);
//     java.util.Date var6 = var1.getEnd();
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.RegularTimePeriod var8 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var6, var7);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year(var6);
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var6, var10);
// 
//   }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.", var1);
// 
//   }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     long var10 = var4.getFirstMillisecond();
//     long var11 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var15);
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var15);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var15);
//     int var19 = var4.compareTo((java.lang.Object)var18);
//     java.util.Calendar var20 = null;
//     long var21 = var18.getFirstMillisecond(var20);
// 
//   }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(var11);
//     int var15 = var5.compareTo((java.lang.Object)var11);
//     java.util.Calendar var16 = null;
//     long var17 = var5.getLastMillisecond(var16);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2014, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    boolean var3 = var2.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var4 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test231() {}
//   public void test231() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var5 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var2, var5);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014, 100, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     org.jfree.data.time.RegularTimePeriod var9 = var4.previous();
//     long var10 = var4.getLastMillisecond();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     int var12 = var11.getDayOfMonth();
//     java.util.Date var13 = var11.getEnd();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(var13);
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var13);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year(var13);
//     org.jfree.data.time.RegularTimePeriod var17 = var16.previous();
//     boolean var18 = var4.equals((java.lang.Object)var17);
//     java.util.Calendar var19 = null;
//     long var20 = var4.getFirstMillisecond(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var5.removeChangeListener(var7);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     java.lang.Object var10 = null;
//     int var11 = var9.compareTo(var10);
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, (java.lang.Number)0.0f);
//     java.lang.Number var14 = var13.getValue();
//     var5.add(var13);
// 
//   }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     var2.setDescription("");
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     int var8 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.general.SeriesChangeEvent var9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     java.lang.Object var11 = null;
//     int var12 = var10.compareTo(var11);
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     boolean var16 = var14.equals((java.lang.Object)var15);
//     java.lang.Object var17 = var14.clone();
//     var14.setValue((java.lang.Number)100.0d);
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(1, 0);
//     int var23 = var22.getYearValue();
//     int var24 = var14.compareTo((java.lang.Object)var22);
//     java.lang.Number var25 = var14.getValue();
//     org.jfree.data.time.RegularTimePeriod var26 = var14.getPeriod();
//     var2.add(var26, (java.lang.Number)(byte)(-1), false);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     var2.setNotify(false);
//     var2.removeAgedItems(1419148800000L, true);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "January"+ "'", var2.equals("January"));

  }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     int var4 = var3.getDayOfMonth();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var13 = var2.isInRange(var7, var11, (-1));
//     int var14 = var2.getDayOfMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-460), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 12);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "December"+ "'", var1.equals("December"));

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("12-January-1900", var1);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Dec", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     boolean var18 = var7.isInRange(var12, var16, (-1));
//     org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     java.lang.Object var21 = null;
//     int var22 = var20.compareTo(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var25 = var20.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     int var29 = var28.getDayOfMonth();
//     java.util.Date var30 = var28.getEnd();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     int var34 = var33.getDayOfMonth();
//     java.util.Date var35 = var33.getEnd();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var35);
//     boolean var38 = var27.isInRange(var32, var36, (-1));
//     org.jfree.data.time.SerialDate var39 = var25.getEndOfCurrentMonth(var36);
//     org.jfree.data.time.SerialDate var40 = var16.getEndOfCurrentMonth(var25);
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     int var44 = var43.getDayOfMonth();
//     java.util.Date var45 = var43.getEnd();
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month(var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     int var49 = var48.getDayOfMonth();
//     java.util.Date var50 = var48.getEnd();
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var50);
//     boolean var53 = var42.isInRange(var47, var51, (-1));
//     int var54 = var42.getYYYY();
//     int var55 = var42.getYYYY();
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     int var58 = var57.getDayOfMonth();
//     java.util.Date var59 = var57.getEnd();
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var60);
//     int var62 = var42.compare(var61);
//     org.jfree.data.time.SerialDate var63 = var16.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var42);
//     java.lang.Object var64 = null;
//     int var65 = var42.compareTo(var64);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(1, 0);
//     long var8 = var7.getMiddleMillisecond();
//     long var9 = var7.getMiddleMillisecond();
//     boolean var10 = var4.equals((java.lang.Object)var9);
//     java.util.Calendar var11 = null;
//     long var12 = var4.getMiddleMillisecond(var11);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var13 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var4);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     var4.clear();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var11);
//     var12.removeAgedItems(true);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     int var17 = var16.getDayOfMonth();
//     java.util.Date var18 = var16.getEnd();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var18);
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(10, var21);
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var26);
//     boolean var29 = var27.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(1, 0);
//     long var33 = var32.getMiddleMillisecond();
//     var27.delete((org.jfree.data.time.RegularTimePeriod)var32);
//     long var35 = var32.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var36 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var21, (org.jfree.data.time.RegularTimePeriod)var32);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)1.0f);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.RegularTimePeriod var3 = var0.next();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var5);
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var8);
//     java.util.Collection var10 = var6.getTimePeriodsUniqueToOtherSeries(var9);
//     var9.removeAgedItems(false);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(1, 0);
//     long var16 = var15.getMiddleMillisecond();
//     int var18 = var15.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var20 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 10.0d);
//     int var21 = var0.compareTo((java.lang.Object)10.0d);
//     long var22 = var0.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 41994L);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     boolean var14 = var3.isInRange(var8, var12, (-1));
//     int var15 = var3.getYYYY();
//     int var16 = var3.getYYYY();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addYears(13, (org.jfree.data.time.SerialDate)var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(2147483647, (org.jfree.data.time.SerialDate)var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(100, 21, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     int var4 = var3.getDayOfMonth();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var13 = var2.isInRange(var7, var11, (-1));
//     int var14 = var2.getYYYY();
//     int var15 = var2.getYYYY();
//     int var16 = var2.getMonth();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(13, (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
// 
//   }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 6, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
//     var6.clear();
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     java.lang.Object var9 = null;
//     int var10 = var8.compareTo(var9);
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     boolean var14 = var12.equals((java.lang.Object)var13);
//     java.lang.Object var15 = null;
//     boolean var16 = var13.equals(var15);
//     var6.setKey((java.lang.Comparable)var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
// 
//   }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var23 = var16.getSerialDate();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     int var33 = var32.getDayOfMonth();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     boolean var37 = var26.isInRange(var31, var35, (-1));
//     int var38 = var26.getYYYY();
//     int var39 = var26.getYYYY();
//     org.jfree.data.time.SerialDate var41 = var26.getFollowingDayOfWeek(1);
//     boolean var42 = var1.isInRange(var23, (org.jfree.data.time.SerialDate)var26);
//     java.lang.String var43 = var23.getDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.general.SeriesChangeEvent[source=24180]", var1);
// 
//   }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-572));

  }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     java.util.Date var12 = var10.getEnd();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var13.getFirstMillisecond(var14);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var20);
//     java.util.Collection var22 = var18.getTimePeriodsUniqueToOtherSeries(var21);
//     boolean var23 = var13.equals((java.lang.Object)var21);
//     java.lang.Number var24 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     int var26 = var25.getDayOfMonth();
//     java.util.Date var27 = var25.getEnd();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(var27);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var27);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     java.lang.Object var31 = null;
//     int var32 = var30.compareTo(var31);
//     boolean var33 = var29.equals((java.lang.Object)var30);
//     java.util.Date var34 = var29.getTime();
//     long var35 = var29.getFirstMillisecond();
//     long var36 = var29.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var37 = var29.previous();
//     java.util.Calendar var38 = null;
//     long var39 = var29.getFirstMillisecond(var38);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)(byte)1);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    var4.removeAgedItems(true);
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var4.addChangeListener(var7);
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var4.removeChangeListener(var9);
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var4.removeChangeListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var14 = var4.getValue(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var21 = var16.getSerialDate();
//     boolean var22 = var15.isOnOrAfter(var21);
//     java.util.Date var23 = var15.toDate();
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.Object var27 = null;
//     int var28 = var26.compareTo(var27);
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var31 = var26.getSerialDate();
//     boolean var32 = var25.isOnOrAfter(var31);
//     int var33 = var15.compare((org.jfree.data.time.SerialDate)var25);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var1.isInRange((org.jfree.data.time.SerialDate)var15, var38);
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day(var38);
//     java.util.Calendar var41 = null;
//     var40.peg(var41);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.RegularTimePeriod var19 = var15.previous();
//     long var20 = var15.getSerialIndex();
//     java.util.Date var21 = var15.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     var2.setNotify(false);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     int var6 = var5.getDayOfMonth();
//     java.util.Date var7 = var5.getEnd();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var7);
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(var7);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var7);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7);
//     var2.setKey((java.lang.Comparable)var7);
//     
//     // Checks the contract:  equals-hashcode on var2 and var11
//     assertTrue("Contract failed: equals-hashcode on var2 and var11", var2.equals(var11) ? var2.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var2
//     assertTrue("Contract failed: equals-hashcode on var11 and var2", var11.equals(var2) ? var11.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ERROR : Relative To String");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     boolean var17 = var5.isEmpty();
//     java.beans.PropertyChangeListener var18 = null;
//     var5.addPropertyChangeListener(var18);
//     long var20 = var5.getMaximumItemAge();
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     int var22 = var21.getDayOfMonth();
//     java.util.Date var23 = var21.getEnd();
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(var23);
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(var23);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var27);
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     int var34 = var33.getDayOfMonth();
//     java.util.Date var35 = var33.getEnd();
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(var35);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var32.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var36, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var40 = var28.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var36, 0.0d);
//     long var41 = var36.getFirstMillisecond();
//     boolean var42 = var25.equals((java.lang.Object)var36);
//     org.jfree.data.time.RegularTimePeriod var43 = var25.next();
//     var5.add((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)1417420800000L);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.RegularTimePeriod var18 = var5.previous();
//     java.util.Calendar var19 = null;
//     long var20 = var5.getLastMillisecond(var19);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    java.lang.String var5 = var4.getRangeDescription();
    var4.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var4.getTimePeriod(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Preceding"+ "'", var1.equals("Preceding"));

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     java.lang.String var5 = var4.getRangeDescription();
//     var4.clear();
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.RegularTimePeriod var10 = var7.next();
//     org.jfree.data.time.TimeSeriesDataItem var12 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, 10.0d);
//     java.util.Calendar var13 = null;
//     var7.peg(var13);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("October 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    java.lang.String var5 = var4.getRangeDescription();
    var4.clear();
    java.lang.Comparable var7 = var4.getKey();
    var4.setNotify(false);
    java.beans.PropertyChangeListener var10 = null;
    var4.removePropertyChangeListener(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var4.getTimePeriod((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + ""+ "'", var5.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1)+ "'", var7.equals((-1)));

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=January]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 1900, 13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    java.lang.Object var7 = var5.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var5.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     long var9 = var4.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1419235199999L);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=January]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     boolean var22 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var16, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var23 = var16.getSerialDate();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.Month var30 = new org.jfree.data.time.Month(var29);
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var29);
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day();
//     int var33 = var32.getDayOfMonth();
//     java.util.Date var34 = var32.getEnd();
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(var34);
//     boolean var37 = var26.isInRange(var31, var35, (-1));
//     int var38 = var26.getYYYY();
//     int var39 = var26.getYYYY();
//     org.jfree.data.time.SerialDate var41 = var26.getFollowingDayOfWeek(1);
//     boolean var42 = var1.isInRange(var23, (org.jfree.data.time.SerialDate)var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var44 = var23.getPreviousDayOfWeek(21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == true);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    var2.setDescription("");
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
    java.lang.Object var6 = null;
    int var7 = var5.compareTo(var6);
    int var8 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.general.SeriesChangeEvent var9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
    int var10 = var2.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var2.getValue(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2147483647);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     java.util.Date var12 = var10.getEnd();
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var12);
//     java.util.Calendar var14 = null;
//     long var15 = var13.getFirstMillisecond(var14);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var20);
//     java.util.Collection var22 = var18.getTimePeriodsUniqueToOtherSeries(var21);
//     boolean var23 = var13.equals((java.lang.Object)var21);
//     java.lang.Number var24 = var4.getValue((org.jfree.data.time.RegularTimePeriod)var13);
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     int var26 = var25.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(byte)0);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var30);
//     java.lang.Class var33 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var33);
//     java.util.Collection var35 = var31.getTimePeriodsUniqueToOtherSeries(var34);
//     int var36 = var28.compareTo((java.lang.Object)var34);
//     var4.add(var28, false);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var15);
//     var16.removeAgedItems(true);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.FixedMillisecond var24 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year(var22);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(10, var25);
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var30);
//     boolean var33 = var31.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, 0);
//     long var37 = var36.getMiddleMillisecond();
//     var31.delete((org.jfree.data.time.RegularTimePeriod)var36);
//     long var39 = var36.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var40 = var16.createCopy((org.jfree.data.time.RegularTimePeriod)var25, (org.jfree.data.time.RegularTimePeriod)var36);
//     java.util.Date var41 = var25.getEnd();
//     org.jfree.data.time.TimeSeriesDataItem var42 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     java.util.Calendar var43 = null;
//     long var44 = var25.getFirstMillisecond(var43);
// 
//   }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     int var9 = var4.getIndex((org.jfree.data.time.RegularTimePeriod)var7);
//     java.lang.Object var10 = var4.clone();
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     int var12 = var11.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, (java.lang.Number)(byte)0);
//     var4.add(var14);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     java.util.Calendar var6 = null;
//     var5.peg(var6);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("12-January-1900", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     java.lang.Object var4 = null;
//     int var5 = var3.compareTo(var4);
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var8 = var3.getSerialDate();
//     boolean var9 = var2.isOnOrAfter(var8);
//     java.util.Date var10 = var2.toDate();
//     org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     java.lang.Object var14 = null;
//     int var15 = var13.compareTo(var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var18 = var13.getSerialDate();
//     boolean var19 = var12.isOnOrAfter(var18);
//     int var20 = var2.compare((org.jfree.data.time.SerialDate)var12);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.Object var22 = null;
//     int var23 = var21.compareTo(var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var26 = var21.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     int var30 = var29.getDayOfMonth();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var28.isInRange(var33, var37, (-1));
//     org.jfree.data.time.SerialDate var40 = var26.getEndOfCurrentMonth(var37);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     java.lang.Object var42 = null;
//     int var43 = var41.compareTo(var42);
//     org.jfree.data.time.TimeSeriesDataItem var45 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var46 = var41.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var48 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var49 = new org.jfree.data.time.Day();
//     int var50 = var49.getDayOfMonth();
//     java.util.Date var51 = var49.getEnd();
//     org.jfree.data.time.Month var52 = new org.jfree.data.time.Month(var51);
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var51);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     int var55 = var54.getDayOfMonth();
//     java.util.Date var56 = var54.getEnd();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     boolean var59 = var48.isInRange(var53, var57, (-1));
//     org.jfree.data.time.SerialDate var60 = var46.getEndOfCurrentMonth(var57);
//     org.jfree.data.time.SerialDate var61 = var37.getEndOfCurrentMonth(var46);
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     int var65 = var64.getDayOfMonth();
//     java.util.Date var66 = var64.getEnd();
//     org.jfree.data.time.Month var67 = new org.jfree.data.time.Month(var66);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var66);
//     org.jfree.data.time.Day var69 = new org.jfree.data.time.Day();
//     int var70 = var69.getDayOfMonth();
//     java.util.Date var71 = var69.getEnd();
//     org.jfree.data.time.SerialDate var72 = org.jfree.data.time.SerialDate.createInstance(var71);
//     boolean var74 = var63.isInRange(var68, var72, (-1));
//     int var75 = var63.getYYYY();
//     int var76 = var63.getYYYY();
//     org.jfree.data.time.Day var78 = new org.jfree.data.time.Day();
//     int var79 = var78.getDayOfMonth();
//     java.util.Date var80 = var78.getEnd();
//     org.jfree.data.time.SerialDate var81 = org.jfree.data.time.SerialDate.createInstance(var80);
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var81);
//     int var83 = var63.compare(var82);
//     org.jfree.data.time.SerialDate var84 = var37.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var63);
//     boolean var85 = var2.isOnOrBefore((org.jfree.data.time.SerialDate)var63);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var86 = org.jfree.data.time.SerialDate.addDays((-572), (org.jfree.data.time.SerialDate)var63);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var76 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == true);
// 
//   }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     java.util.Calendar var17 = null;
//     long var18 = var14.getLastMillisecond(var17);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("December 2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-572));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("ERROR : Relative To String", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var19 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 0.0d);
//     long var20 = var15.getFirstMillisecond();
//     boolean var21 = var4.equals((java.lang.Object)var15);
//     org.jfree.data.time.Year var22 = var15.getYear();
//     java.util.Calendar var23 = null;
//     long var24 = var22.getFirstMillisecond(var23);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(1, 0);
//     long var21 = var20.getMiddleMillisecond();
//     long var22 = var20.getMiddleMillisecond();
//     boolean var23 = var5.equals((java.lang.Object)var22);
//     long var24 = var5.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var25 = var5.next();
//     org.jfree.data.time.RegularTimePeriod var26 = var5.previous();
//     java.util.Calendar var27 = null;
//     var5.peg(var27);
// 
//   }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
//     java.util.TimeZone var7 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var2, var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test306() {}
//   public void test306() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     var4.setDescription("ThreadContext");
//     java.lang.String var12 = var4.getRangeDescription();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var13 = var4.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
// 
//   }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var5 = var4.isEmpty();
    java.lang.Class var6 = var4.getTimePeriodClass();
    org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 12);
    var4.setDescription("");
    var4.setKey((java.lang.Comparable)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var4.getTimePeriod((-572));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     int var2 = var0.getYear();
//     long var3 = var0.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-459), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("12-November-1900", var1);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(6, (-460), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test312() {}
//   public void test312() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(0, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-572), var7);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test314() {}
//   public void test314() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     java.util.Date var5 = var0.getEnd();
//     int var6 = var0.getDayOfMonth();
//     java.lang.String var7 = var0.toString();
//     java.util.Calendar var8 = null;
//     var0.peg(var8);
// 
//   }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, (-459), 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var17 = var11.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 1, (-41981));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var6);
//     java.lang.String var8 = var7.toString();
//     int var10 = var7.compareTo((java.lang.Object)(-62167363200000L));
//     int var11 = var7.getMonth();
//     java.util.Calendar var12 = null;
//     var7.peg(var12);
// 
//   }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)10.0d);
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var9);
//     boolean var12 = var10.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(1, 0);
//     long var16 = var15.getMiddleMillisecond();
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var15);
//     boolean var18 = var3.equals((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var20 = var10.getTimePeriod(6);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11, var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var20 = var18.getTimePeriod(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.TimeSeriesDataItem var12 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 0.0d);
//     long var15 = var10.getFirstMillisecond();
//     java.util.Calendar var16 = null;
//     long var17 = var10.getLastMillisecond(var16);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("January", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Last");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("12-January-1900");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     org.jfree.data.time.RegularTimePeriod var17 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var5.add(var17, (java.lang.Number)(-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     java.util.Date var29 = var13.getEnd();
//     java.util.TimeZone var30 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29, var30);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     boolean var17 = var5.isEmpty();
//     java.lang.Object var18 = var5.clone();
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var5.addChangeListener(var19);
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(1, 0);
//     long var24 = var23.getLastMillisecond();
//     var5.add((org.jfree.data.time.RegularTimePeriod)var23, 0.0d, false);
// 
//   }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     boolean var6 = var4.equals((java.lang.Object)var5);
//     java.util.Calendar var7 = null;
//     long var8 = var5.getFirstMillisecond(var7);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-572));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(6);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var4);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var4);
//     long var7 = var6.getSerialIndex();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var9);
//     boolean var11 = var10.isEmpty();
//     int var12 = var6.compareTo((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var1.compareTo((java.lang.Object)var10);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
// 
//   }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1900, (-572), (-572));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test337() {}
//   public void test337() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     java.util.TimeZone var3 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var4 = new org.jfree.data.time.Day(var2, var3);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
// 
//   }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.String var12 = var4.getDescription();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var14 = var13.next();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(12, 0);
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var17);
//     var18.setMaximumItemAge(100L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     boolean var9 = var6.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var13);
//     boolean var15 = var14.isEmpty();
//     var14.setMaximumItemAge(1419148800000L);
//     int var18 = var6.compareTo((java.lang.Object)var14);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "SerialDate.weekInMonthToString(): invalid code.", "21-December-2014", var21);
//     org.jfree.data.time.RegularTimePeriod var23 = var6.previous();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var24 = new org.jfree.data.time.Month((-460), var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: SerialDate.weekInMonthToString(): invalid code.");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(21, 21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var5.removeChangeListener(var7);
//     var5.setRangeDescription("");
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond((-1L));
//     long var13 = var12.getMiddleMillisecond();
//     var5.add((org.jfree.data.time.RegularTimePeriod)var12, 100.0d, false);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     long var8 = var7.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = var4.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
//     var4.removeAgedItems(100L, true);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    var5.removeAgedItems(false);
    java.lang.Object var9 = var5.clone();
    java.util.List var10 = var5.getItems();
    org.jfree.data.time.RegularTimePeriod var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var12 = var5.getDataItem(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: Last", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     int var4 = var3.getDayOfMonth();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var13 = var2.isInRange(var7, var11, (-1));
//     int var14 = var2.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     java.lang.Object var18 = null;
//     int var19 = var17.compareTo(var18);
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var22 = var17.getSerialDate();
//     boolean var23 = var16.isOnOrAfter(var22);
//     java.util.Date var24 = var16.toDate();
//     org.jfree.data.time.SpreadsheetDate var26 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     java.lang.Object var28 = null;
//     int var29 = var27.compareTo(var28);
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var32 = var27.getSerialDate();
//     boolean var33 = var26.isOnOrAfter(var32);
//     int var34 = var16.compare((org.jfree.data.time.SerialDate)var26);
//     org.jfree.data.time.Day var35 = new org.jfree.data.time.Day();
//     int var36 = var35.getDayOfMonth();
//     java.util.Date var37 = var35.getEnd();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(var37);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(var37);
//     boolean var40 = var2.isInRange((org.jfree.data.time.SerialDate)var16, var39);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate)var16);
//     java.lang.Object var42 = null;
//     int var43 = var16.compareTo(var42);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test350() {}
//   public void test350() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getMiddleMillisecond();
//     int var5 = var2.compareTo((java.lang.Object)0);
//     long var6 = var2.getSerialIndex();
//     long var7 = var2.getSerialIndex();
//     int var8 = var2.getYearValue();
//     java.lang.String var9 = var2.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Year var10 = var2.getYear();
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "January 0"+ "'", var9.equals("January 0"));
// 
//   }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var6);
//     java.lang.String var8 = var7.toString();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 100.0d);
//     long var11 = var7.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "October 2014"+ "'", var8.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1414825199999L);
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, (-1));
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1));
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var7);
//     var8.removeAgedItems(true);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var14);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year(var14);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(10, var17);
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var22);
//     boolean var25 = var23.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(1, 0);
//     long var29 = var28.getMiddleMillisecond();
//     var23.delete((org.jfree.data.time.RegularTimePeriod)var28);
//     long var31 = var28.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var32 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var28);
//     java.util.Date var33 = var17.getEnd();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var3.add((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)13, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, 0.0d);
//     var4.setNotify(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var21 = var4.createCopy((-459), 0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
// 
//   }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("December");

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     java.lang.Object var2 = null;
//     int var3 = var1.compareTo(var2);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var6 = var1.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.Month var12 = new org.jfree.data.time.Month(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var11);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day();
//     int var15 = var14.getDayOfMonth();
//     java.util.Date var16 = var14.getEnd();
//     org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(var16);
//     boolean var19 = var8.isInRange(var13, var17, (-1));
//     org.jfree.data.time.SerialDate var20 = var6.getEndOfCurrentMonth(var17);
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     java.lang.Object var22 = null;
//     int var23 = var21.compareTo(var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var26 = var21.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     int var30 = var29.getDayOfMonth();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var28.isInRange(var33, var37, (-1));
//     org.jfree.data.time.SerialDate var40 = var26.getEndOfCurrentMonth(var37);
//     org.jfree.data.time.SerialDate var41 = var17.getEndOfCurrentMonth(var26);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     java.lang.Class var19 = null;
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var17, var19);
//     org.jfree.data.time.Year var21 = var17.getYear();
//     long var22 = var17.getLastMillisecond();
//     int var23 = var17.getMonth();
//     java.lang.String var24 = var17.toString();
//     java.util.Calendar var25 = null;
//     var17.peg(var25);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    var5.removeAgedItems(false);
    var5.setNotify(false);
    int var11 = var5.getMaximumItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var12 = var5.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2147483647);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     var4.removeAgedItems(41994L, true);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(6, (-460), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.previous();
//     boolean var9 = var6.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var13);
//     boolean var15 = var14.isEmpty();
//     var14.setMaximumItemAge(1419148800000L);
//     int var18 = var6.compareTo((java.lang.Object)var14);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(1, var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
// 
//   }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    var2.setMaximumItemAge(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var10 = var2.getTimePeriod(21);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test363() {}
//   public void test363() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("12-January-1900", var1);
// 
//   }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("December");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var5 = var4.isEmpty();
//     java.lang.Class var6 = var4.getTimePeriodClass();
//     org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 12);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var14);
//     java.util.Collection var16 = var12.getTimePeriodsUniqueToOtherSeries(var15);
//     var12.setMaximumItemAge(1L);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     int var20 = var19.getDayOfMonth();
//     java.util.Date var21 = var19.getEnd();
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
//     java.util.Calendar var23 = null;
//     var22.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var12.getDataItem((org.jfree.data.time.RegularTimePeriod)var22);
//     var9.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)(byte)0, true);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(1, 0);
//     long var21 = var20.getMiddleMillisecond();
//     long var22 = var20.getMiddleMillisecond();
//     boolean var23 = var5.equals((java.lang.Object)var22);
//     long var24 = var5.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var25 = var5.next();
//     java.util.Calendar var26 = null;
//     var5.peg(var26);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     long var5 = var4.getSerialIndex();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var7);
//     boolean var9 = var8.isEmpty();
//     int var10 = var4.compareTo((java.lang.Object)var8);
//     boolean var11 = var8.isEmpty();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var12 = var8.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var7 = var0.getSerialDate();
//     java.util.Date var8 = var0.getStart();
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var8, var9);
// 
//   }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1900, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Value");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     long var3 = var0.getLastMillisecond();
//     org.jfree.data.time.TimePeriodFormatException var5 = new org.jfree.data.time.TimePeriodFormatException("January");
//     boolean var6 = var0.equals((java.lang.Object)"January");
//     java.util.Calendar var7 = null;
//     var0.peg(var7);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"hi!", "21-December-2014", "ThreadContext", var3);
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
    java.lang.Object var6 = null;
    int var7 = var5.compareTo(var6);
    org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)0.0f);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)'#');
    java.lang.Class var15 = null;
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var15);
    java.lang.String var17 = var16.getRangeDescription();
    int var18 = var5.compareTo((java.lang.Object)var17);
    org.jfree.data.time.TimeSeriesDataItem var20 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(-62167363200000L));
    java.util.List var21 = var4.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setMaximumItemCount((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("October 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.time.TimePeriodFormatException: Last", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     int var15 = var1.getMonth();
//     java.lang.String var16 = var1.getDescription();
//     org.jfree.data.time.Day var17 = new org.jfree.data.time.Day();
//     int var18 = var17.getDayOfMonth();
//     java.util.Date var19 = var17.getEnd();
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(var19);
//     java.util.Calendar var21 = null;
//     long var22 = var20.getFirstMillisecond(var21);
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var27);
//     java.util.Collection var29 = var25.getTimePeriodsUniqueToOtherSeries(var28);
//     boolean var30 = var20.equals((java.lang.Object)var28);
//     boolean var32 = var20.equals((java.lang.Object)(short)100);
//     java.util.Calendar var33 = null;
//     long var34 = var20.getMiddleMillisecond(var33);
//     java.lang.Object var35 = null;
//     int var36 = var20.compareTo(var35);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var37 = var1.compareTo((java.lang.Object)var36);
//       fail("Expected exception of type java.lang.ClassCastException");
//     } catch (java.lang.ClassCastException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 1);
// 
//   }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     boolean var17 = var5.isEmpty();
//     java.beans.PropertyChangeListener var18 = null;
//     var5.addPropertyChangeListener(var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)10.0d);
//     java.lang.Object var26 = var25.clone();
//     var5.add(var25);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-572), (-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     java.lang.String var7 = var5.getRangeDescription();
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var11);
//     boolean var14 = var12.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(1, 0);
//     long var18 = var17.getMiddleMillisecond();
//     var12.delete((org.jfree.data.time.RegularTimePeriod)var17);
//     java.lang.String var20 = var12.getDescription();
//     org.jfree.data.time.Day var21 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var22 = var21.next();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(12, 0);
//     org.jfree.data.time.TimeSeries var26 = var12.createCopy((org.jfree.data.time.RegularTimePeriod)var21, (org.jfree.data.time.RegularTimePeriod)var25);
//     java.util.Collection var27 = var5.getTimePeriodsUniqueToOtherSeries(var26);
//     java.util.Collection var28 = org.jfree.chart.util.ObjectUtilities.deepClone(var27);
//     java.util.Collection var29 = org.jfree.chart.util.ObjectUtilities.deepClone(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "Value"+ "'", var7.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(var6);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var11);
//     boolean var14 = var3.isInRange(var8, var12, (-1));
//     int var15 = var3.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day();
//     java.lang.Object var19 = null;
//     int var20 = var18.compareTo(var19);
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var23 = var18.getSerialDate();
//     boolean var24 = var17.isOnOrAfter(var23);
//     java.util.Date var25 = var17.toDate();
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     java.lang.Object var29 = null;
//     int var30 = var28.compareTo(var29);
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var33 = var28.getSerialDate();
//     boolean var34 = var27.isOnOrAfter(var33);
//     int var35 = var17.compare((org.jfree.data.time.SerialDate)var27);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     int var37 = var36.getDayOfMonth();
//     java.util.Date var38 = var36.getEnd();
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var38);
//     boolean var41 = var3.isInRange((org.jfree.data.time.SerialDate)var17, var40);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(1, var40);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths(2147483647, var42);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     long var5 = var4.getSerialIndex();
//     java.lang.String var6 = var4.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "Sun Dec 21 23:59:59 PST 2014"+ "'", var6.equals("Sun Dec 21 23:59:59 PST 2014"));
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test387() {}
//   public void test387() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(12);
//     org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     int var6 = var5.getDayOfMonth();
//     java.util.Date var7 = var5.getEnd();
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var7);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(var7);
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     int var11 = var10.getDayOfMonth();
//     java.util.Date var12 = var10.getEnd();
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(var12);
//     boolean var15 = var4.isInRange(var9, var13, (-1));
//     int var16 = var4.getYYYY();
//     int var17 = var4.getYYYY();
//     org.jfree.data.time.SerialDate var19 = var4.getFollowingDayOfWeek(1);
//     int var20 = var4.getYYYY();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     int var23 = var22.getDayOfMonth();
//     java.util.Date var24 = var22.getEnd();
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var24);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.addYears(0, var26);
//     int var28 = var4.compare(var26);
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day();
//     int var31 = var30.getDayOfMonth();
//     java.util.Date var32 = var30.getEnd();
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(var32);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addYears(0, var34);
//     boolean var36 = var2.isInRange((org.jfree.data.time.SerialDate)var4, var34);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addDays(21, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.TimeSeries var38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
// 
//   }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(var14);
//     org.jfree.data.time.TimeSeriesDataItem var17 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var19 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, 0.0d);
//     long var20 = var15.getFirstMillisecond();
//     boolean var21 = var4.equals((java.lang.Object)var15);
//     org.jfree.data.time.Year var22 = var15.getYear();
//     java.util.Calendar var23 = null;
//     long var24 = var22.getLastMillisecond(var23);
// 
//   }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var10);
//     java.util.Collection var12 = var8.getTimePeriodsUniqueToOtherSeries(var11);
//     boolean var13 = var3.equals((java.lang.Object)var11);
//     boolean var15 = var3.equals((java.lang.Object)(short)100);
//     java.util.Calendar var16 = null;
//     long var17 = var3.getMiddleMillisecond(var16);
//     java.lang.Object var18 = null;
//     int var19 = var3.compareTo(var18);
//     org.jfree.data.time.RegularTimePeriod var20 = var3.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.String var12 = var4.getRangeDescription();
//     int var13 = var4.getMaximumItemCount();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond((-62167363200000L));
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     var4.add(var16, 0.0d, true);
// 
//   }

  public void test391() {}
//   public void test391() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var5 = var4.isEmpty();
//     var4.setMaximumItemAge(1419148800000L);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     long var12 = var11.getSerialIndex();
//     java.util.Date var13 = var11.getStart();
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var13);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)(-460), false);
// 
//   }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     java.lang.Object var9 = var5.clone();
//     java.lang.Class var10 = var5.getTimePeriodClass();
//     var5.setDomainDescription("ThreadContext");
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var14);
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var22);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var19.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var27 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, 0.0d);
//     long var28 = var23.getSerialIndex();
//     java.lang.String var29 = var23.toString();
//     var5.add((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)13, true);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     java.lang.String var12 = var4.getDescription();
//     boolean var13 = var4.getNotify();
//     var4.removeAgedItems(0L, false);
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     boolean var3 = var2.isEmpty();
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(var6);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var6);
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year(var6);
//     long var10 = var9.getSerialIndex();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Value");

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var21 = var16.getSerialDate();
//     boolean var22 = var15.isOnOrAfter(var21);
//     java.util.Date var23 = var15.toDate();
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.Object var27 = null;
//     int var28 = var26.compareTo(var27);
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var31 = var26.getSerialDate();
//     boolean var32 = var25.isOnOrAfter(var31);
//     int var33 = var15.compare((org.jfree.data.time.SerialDate)var25);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var1.isInRange((org.jfree.data.time.SerialDate)var15, var38);
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"hi!", "21-December-2014", "ThreadContext", var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day();
//     java.lang.Object var46 = null;
//     int var47 = var45.compareTo(var46);
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)0.0f);
//     boolean var51 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var45, (java.lang.Object)'#');
//     java.lang.Class var55 = null;
//     org.jfree.data.time.TimeSeries var56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var55);
//     java.lang.String var57 = var56.getRangeDescription();
//     int var58 = var45.compareTo((java.lang.Object)var57);
//     org.jfree.data.time.TimeSeriesDataItem var60 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)(-62167363200000L));
//     org.jfree.data.time.SerialDate var61 = var45.getSerialDate();
//     boolean var62 = var15.isAfter(var61);
//     int var63 = var15.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var57 + "' != '" + ""+ "'", var57.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     long var4 = var3.getSerialIndex();
//     java.util.Date var5 = var3.getStart();
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     java.util.TimeZone var8 = null;
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(var5, var8);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var11, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.TimeSeries var20 = null;
//     org.jfree.data.time.TimeSeries var21 = var18.addAndOrUpdate(var20);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     int var7 = var2.getItemCount();
//     var2.setDomainDescription("");
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day();
//     long var11 = var10.getFirstMillisecond();
//     int var12 = var10.getYear();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var15 = var2.getDataItem(10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419148800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014);
// 
//   }

  public void test406() {}
//   public void test406() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var14);
//     java.util.Collection var16 = var12.getTimePeriodsUniqueToOtherSeries(var15);
//     boolean var18 = var12.equals((java.lang.Object)"");
//     org.jfree.data.time.TimeSeries var19 = var3.addAndOrUpdate(var12);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var23);
//     java.lang.String var25 = var24.getRangeDescription();
//     var24.clear();
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.RegularTimePeriod var30 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     int var33 = var19.getIndex((org.jfree.data.time.RegularTimePeriod)var27);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.FixedMillisecond var37 = new org.jfree.data.time.FixedMillisecond(var36);
//     org.jfree.data.time.FixedMillisecond var38 = new org.jfree.data.time.FixedMillisecond(var36);
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(1, 0);
//     long var42 = var41.getMiddleMillisecond();
//     long var43 = var41.getMiddleMillisecond();
//     boolean var44 = var38.equals((java.lang.Object)var43);
//     java.util.Calendar var45 = null;
//     long var46 = var38.getMiddleMillisecond(var45);
//     org.jfree.data.time.RegularTimePeriod var47 = var38.next();
//     java.util.Calendar var48 = null;
//     long var49 = var38.getFirstMillisecond(var48);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var19.update((org.jfree.data.time.RegularTimePeriod)var38, (java.lang.Number)(byte)100);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 1419235199999L);
// 
//   }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var12 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var14.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     java.lang.Object var30 = null;
//     int var31 = var29.compareTo(var30);
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var34 = var29.getSerialDate();
//     boolean var35 = var28.isOnOrAfter(var34);
//     java.util.Date var36 = var28.toDate();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     java.lang.Object var40 = null;
//     int var41 = var39.compareTo(var40);
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var44 = var39.getSerialDate();
//     boolean var45 = var38.isOnOrAfter(var44);
//     int var46 = var28.compare((org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     int var48 = var47.getDayOfMonth();
//     java.util.Date var49 = var47.getEnd();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var52 = var14.isInRange((org.jfree.data.time.SerialDate)var28, var51);
//     boolean var53 = var11.isOn((org.jfree.data.time.SerialDate)var28);
//     java.lang.String var54 = var11.toString();
//     var11.setDescription("org.jfree.data.time.TimePeriodFormatException: Last");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "12-January-1900"+ "'", var54.equals("12-January-1900"));
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     long var2 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1419235199999L);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     boolean var3 = var2.getNotify();
//     var2.setDescription("Sunday");
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var9);
//     boolean var12 = var10.equals((java.lang.Object)'a');
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     long var14 = var13.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = var10.getDataItem((org.jfree.data.time.RegularTimePeriod)var13);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var13, 100.0d, true);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("October -1", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     boolean var18 = var13.isEmpty();
//     org.jfree.data.time.RegularTimePeriod var19 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var21 = var13.addOrUpdate(var19, 1.0d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), (-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     java.util.Calendar var11 = null;
//     var10.peg(var11);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-41981));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var9);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");

  }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.TimeSeriesDataItem var12 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 0.0d);
//     var2.setDomainDescription("hi!");
//     org.jfree.data.time.RegularTimePeriod var17 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var18 = var2.getDataItem(var17);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(7, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     long var10 = var4.getFirstMillisecond();
//     long var11 = var4.getMiddleMillisecond();
//     java.util.Calendar var12 = null;
//     long var13 = var4.getLastMillisecond(var12);
//     long var14 = var4.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1419235199999L);
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var5 = var4.isEmpty();
//     java.lang.Class var6 = var4.getTimePeriodClass();
//     var4.setNotify(true);
//     var4.setDomainDescription("ERROR : Relative To String");
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var14);
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var20);
//     java.util.Collection var22 = var18.getTimePeriodsUniqueToOtherSeries(var21);
//     var21.removeAgedItems(false);
//     java.lang.Object var25 = var21.clone();
//     java.util.List var26 = var21.getItems();
//     boolean var27 = var15.equals((java.lang.Object)var21);
//     org.jfree.data.time.TimeSeries var28 = var4.addAndOrUpdate(var15);
//     var28.removeAgedItems(1388563200000L, true);
// 
//   }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(21, var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(21, 0, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-572));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var14.getYYYY();
//     int var27 = var14.getYYYY();
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     int var30 = var29.getDayOfMonth();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var32);
//     int var34 = var14.compare(var33);
//     int var35 = var14.getDayOfMonth();
//     int var36 = var14.toSerial();
//     boolean var37 = var1.isBefore((org.jfree.data.time.SerialDate)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var38 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var14);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == false);
// 
//   }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    java.lang.Class var6 = null;
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var6);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var9);
    java.util.Collection var11 = var7.getTimePeriodsUniqueToOtherSeries(var10);
    var10.removeAgedItems(false);
    java.lang.Object var14 = var10.clone();
    java.util.List var15 = var10.getItems();
    boolean var16 = var4.equals((java.lang.Object)var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var17 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)24180L);
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    java.lang.Object var4 = var1.getSource();
    java.lang.Object var5 = var1.getSource();
    java.lang.String var6 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=24180]"+ "'", var2.equals("org.jfree.data.general.SeriesChangeEvent[source=24180]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=24180]"+ "'", var3.equals("org.jfree.data.general.SeriesChangeEvent[source=24180]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 24180L+ "'", var4.equals(24180L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 24180L+ "'", var5.equals(24180L));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=24180]"+ "'", var6.equals("org.jfree.data.general.SeriesChangeEvent[source=24180]"));

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var12 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var14.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     java.lang.Object var30 = null;
//     int var31 = var29.compareTo(var30);
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var34 = var29.getSerialDate();
//     boolean var35 = var28.isOnOrAfter(var34);
//     java.util.Date var36 = var28.toDate();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     java.lang.Object var40 = null;
//     int var41 = var39.compareTo(var40);
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var44 = var39.getSerialDate();
//     boolean var45 = var38.isOnOrAfter(var44);
//     int var46 = var28.compare((org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     int var48 = var47.getDayOfMonth();
//     java.util.Date var49 = var47.getEnd();
//     org.jfree.data.time.Month var50 = new org.jfree.data.time.Month(var49);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var52 = var14.isInRange((org.jfree.data.time.SerialDate)var28, var51);
//     boolean var53 = var11.isOn((org.jfree.data.time.SerialDate)var28);
//     java.lang.String var54 = var11.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var56 = var11.getNearestDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + "12-January-1900"+ "'", var54.equals("12-January-1900"));
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("2014");

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     org.jfree.data.time.RegularTimePeriod var29 = var13.next();
//     java.util.Calendar var30 = null;
//     long var31 = var13.getFirstMillisecond(var30);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var2);
//     java.util.Calendar var6 = null;
//     long var7 = var5.getFirstMillisecond(var6);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-41981));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var4.addChangeListener(var7);
//     org.jfree.data.general.SeriesChangeListener var9 = null;
//     var4.removeChangeListener(var9);
//     long var11 = var4.getMaximumItemAge();
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.FixedMillisecond var16 = new org.jfree.data.time.FixedMillisecond(var15);
//     org.jfree.data.time.FixedMillisecond var17 = new org.jfree.data.time.FixedMillisecond(var15);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year(var15);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(10, var18);
//     java.lang.String var20 = var19.toString();
//     int var22 = var19.compareTo((java.lang.Object)(-62167363200000L));
//     int var23 = var19.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var25 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1420099199999L);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     int var27 = var26.getDayOfMonth();
//     java.util.Date var28 = var26.getEnd();
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(var28);
//     org.jfree.data.time.FixedMillisecond var30 = new org.jfree.data.time.FixedMillisecond(var28);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var32);
//     org.jfree.data.time.Month var36 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var38 = new org.jfree.data.time.Day();
//     int var39 = var38.getDayOfMonth();
//     java.util.Date var40 = var38.getEnd();
//     org.jfree.data.time.Month var41 = new org.jfree.data.time.Month(var40);
//     org.jfree.data.time.TimeSeriesDataItem var43 = var37.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var45 = var33.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var41, 0.0d);
//     long var46 = var41.getFirstMillisecond();
//     boolean var47 = var30.equals((java.lang.Object)var41);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var4.update((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)12L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "October 2014"+ "'", var20.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1417420800000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == false);
// 
//   }

  public void test435() {}
//   public void test435() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     java.lang.Object var13 = null;
//     int var14 = var12.compareTo(var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var17 = var12.getSerialDate();
//     boolean var18 = var11.isOnOrAfter(var17);
//     int var19 = var1.compare((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var22);
//     org.jfree.data.general.SeriesChangeEvent var26 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var25);
//     boolean var27 = var1.equals((java.lang.Object)var25);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     java.lang.Object var29 = null;
//     int var30 = var28.compareTo(var29);
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var33 = var28.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     int var37 = var36.getDayOfMonth();
//     java.util.Date var38 = var36.getEnd();
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     int var42 = var41.getDayOfMonth();
//     java.util.Date var43 = var41.getEnd();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     boolean var46 = var35.isInRange(var40, var44, (-1));
//     org.jfree.data.time.SerialDate var47 = var33.getEndOfCurrentMonth(var44);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     java.lang.Object var49 = null;
//     int var50 = var48.compareTo(var49);
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var48, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var53 = var48.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var55 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var56 = new org.jfree.data.time.Day();
//     int var57 = var56.getDayOfMonth();
//     java.util.Date var58 = var56.getEnd();
//     org.jfree.data.time.Month var59 = new org.jfree.data.time.Month(var58);
//     org.jfree.data.time.SerialDate var60 = org.jfree.data.time.SerialDate.createInstance(var58);
//     org.jfree.data.time.Day var61 = new org.jfree.data.time.Day();
//     int var62 = var61.getDayOfMonth();
//     java.util.Date var63 = var61.getEnd();
//     org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(var63);
//     boolean var66 = var55.isInRange(var60, var64, (-1));
//     org.jfree.data.time.SerialDate var67 = var53.getEndOfCurrentMonth(var64);
//     org.jfree.data.time.SerialDate var68 = var44.getEndOfCurrentMonth(var53);
//     org.jfree.data.time.SerialDate var69 = null;
//     boolean var70 = var1.isInRange(var68, var69);
// 
//   }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     long var10 = var4.getFirstMillisecond();
//     long var11 = var4.getMiddleMillisecond();
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     java.util.Date var13 = var4.getTime();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     org.jfree.data.general.SeriesChangeEvent var10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)24180L);
//     java.lang.String var11 = var10.toString();
//     java.lang.String var12 = var10.toString();
//     boolean var13 = var5.equals((java.lang.Object)var12);
//     java.util.Calendar var14 = null;
//     long var15 = var5.getFirstMillisecond(var14);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "SerialDate.weekInMonthToString(): invalid code.", "21-December-2014", var20);
//     org.jfree.data.time.RegularTimePeriod var22 = var5.previous();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, var23);
//     java.util.Calendar var25 = null;
//     long var26 = var5.getLastMillisecond(var25);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-452));

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     org.jfree.data.time.RegularTimePeriod var29 = var13.next();
//     long var30 = var13.getSerialIndex();
//     java.util.Calendar var31 = null;
//     var13.peg(var31);
// 
//   }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), var4);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-41981), 1, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesChangeEvent[source=January]", var1);
// 
//   }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var12 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var11.compareTo((java.lang.Object)var14);
//     java.lang.String var27 = var11.toString();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     java.lang.Object var29 = null;
//     int var30 = var28.compareTo(var29);
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var33 = var28.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var35 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var36 = new org.jfree.data.time.Day();
//     int var37 = var36.getDayOfMonth();
//     java.util.Date var38 = var36.getEnd();
//     org.jfree.data.time.Month var39 = new org.jfree.data.time.Month(var38);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(var38);
//     org.jfree.data.time.Day var41 = new org.jfree.data.time.Day();
//     int var42 = var41.getDayOfMonth();
//     java.util.Date var43 = var41.getEnd();
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(var43);
//     boolean var46 = var35.isInRange(var40, var44, (-1));
//     org.jfree.data.time.SerialDate var47 = var33.getEndOfCurrentMonth(var44);
//     boolean var48 = var11.isAfter(var44);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var50 = var11.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "12-January-1900"+ "'", var27.equals("12-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     long var10 = var4.getLastMillisecond();
//     java.util.Calendar var11 = null;
//     long var12 = var4.getFirstMillisecond(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
// 
//   }

  public void test447() {}
//   public void test447() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var6 = var4.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     long var10 = var9.getMiddleMillisecond();
//     var4.delete((org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day();
//     int var13 = var12.getDayOfMonth();
//     java.util.Date var14 = var12.getEnd();
//     org.jfree.data.time.FixedMillisecond var15 = new org.jfree.data.time.FixedMillisecond(var14);
//     long var16 = var15.getLastMillisecond();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var18 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var15, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day();
//     int var20 = var19.getDayOfMonth();
//     java.util.Date var21 = var19.getEnd();
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(var21);
//     long var23 = var22.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var24 = var22.next();
//     org.jfree.data.time.RegularTimePeriod var25 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var26 = var18.createCopy(var24, var25);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var3 = new org.jfree.data.time.Day();
//     int var4 = var3.getDayOfMonth();
//     java.util.Date var5 = var3.getEnd();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var5);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var5);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(var10);
//     boolean var13 = var2.isInRange(var7, var11, (-1));
//     int var14 = var2.getYYYY();
//     int var15 = var2.getYYYY();
//     org.jfree.data.time.SerialDate var17 = var2.getFollowingDayOfWeek(1);
//     int var18 = var2.getYYYY();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.FixedMillisecond var23 = new org.jfree.data.time.FixedMillisecond(var22);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(var22);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.addYears(0, var24);
//     int var26 = var2.compare(var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-452), (org.jfree.data.time.SerialDate)var2);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == (-41981));
// 
//   }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test450() {}
//   public void test450() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     org.jfree.data.time.Day var9 = new org.jfree.data.time.Day();
//     int var10 = var9.getDayOfMonth();
//     java.util.Date var11 = var9.getEnd();
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(var11);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year(var11);
//     int var15 = var5.compareTo((java.lang.Object)var11);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var11);
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var11, var17);
// 
//   }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("org.jfree.data.time.TimePeriodFormatException: Last", var1);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var7 = var6.next();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getLastMillisecond(var8);
// 
//   }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var5 = var4.isEmpty();
    java.lang.Class var6 = var4.getTimePeriodClass();
    org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 12);
    var4.setDescription("");
    var4.setKey((java.lang.Comparable)'#');
    java.util.List var14 = var4.getItems();
    java.util.Collection var15 = var4.getTimePeriods();
    var4.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     long var9 = var5.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 24180L);
// 
//   }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
    var3.removeAgedItems(1419148800000L, true);
    var3.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.delete(2147483647, 12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!"+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     boolean var6 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var0, (java.lang.Object)'#');
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var10);
//     java.lang.String var12 = var11.getRangeDescription();
//     int var13 = var0.compareTo((java.lang.Object)var12);
//     java.lang.String var14 = var0.toString();
//     java.lang.String var15 = var0.toString();
//     long var16 = var0.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "21-December-2014"+ "'", var14.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "21-December-2014"+ "'", var15.equals("21-December-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1419235199999L);
// 
//   }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.Calendar var4 = null;
//     long var5 = var3.getFirstMillisecond(var4);
//     java.util.Date var6 = var3.getEnd();
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Month var8 = new org.jfree.data.time.Month(var6, var7);
// 
//   }

  public void test459() {}
//   public void test459() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.Object var1 = null;
//     int var2 = var0.compareTo(var1);
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var5 = var0.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(var10);
//     org.jfree.data.time.Day var13 = new org.jfree.data.time.Day();
//     int var14 = var13.getDayOfMonth();
//     java.util.Date var15 = var13.getEnd();
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(var15);
//     boolean var18 = var7.isInRange(var12, var16, (-1));
//     org.jfree.data.time.SerialDate var19 = var5.getEndOfCurrentMonth(var16);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     java.lang.Object var21 = null;
//     int var22 = var20.compareTo(var21);
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var25 = var20.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day();
//     int var29 = var28.getDayOfMonth();
//     java.util.Date var30 = var28.getEnd();
//     org.jfree.data.time.Month var31 = new org.jfree.data.time.Month(var30);
//     org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.Day var33 = new org.jfree.data.time.Day();
//     int var34 = var33.getDayOfMonth();
//     java.util.Date var35 = var33.getEnd();
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(var35);
//     boolean var38 = var27.isInRange(var32, var36, (-1));
//     org.jfree.data.time.SerialDate var39 = var25.getEndOfCurrentMonth(var36);
//     org.jfree.data.time.SerialDate var40 = var16.getEndOfCurrentMonth(var25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var42 = var40.getNearestDayOfWeek(12);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
// 
//   }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var12 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var11.compareTo((java.lang.Object)var14);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     java.lang.Object var30 = null;
//     int var31 = var29.compareTo(var30);
//     org.jfree.data.time.TimeSeriesDataItem var33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var34 = var29.getSerialDate();
//     boolean var35 = var28.isOnOrAfter(var34);
//     java.util.Date var36 = var28.toDate();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var39 = var28.isOnOrAfter((org.jfree.data.time.SerialDate)var38);
//     org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day();
//     int var43 = var42.getDayOfMonth();
//     java.util.Date var44 = var42.getEnd();
//     org.jfree.data.time.Month var45 = new org.jfree.data.time.Month(var44);
//     org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(var44);
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day();
//     int var48 = var47.getDayOfMonth();
//     java.util.Date var49 = var47.getEnd();
//     org.jfree.data.time.SerialDate var50 = org.jfree.data.time.SerialDate.createInstance(var49);
//     boolean var52 = var41.isInRange(var46, var50, (-1));
//     int var53 = var38.compareTo((java.lang.Object)var41);
//     java.util.Date var54 = var41.toDate();
//     boolean var55 = var14.isBefore((org.jfree.data.time.SerialDate)var41);
//     org.jfree.data.time.SpreadsheetDate var57 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var58 = new org.jfree.data.time.Day();
//     java.lang.Object var59 = null;
//     int var60 = var58.compareTo(var59);
//     org.jfree.data.time.TimeSeriesDataItem var62 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var58, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var63 = var58.getSerialDate();
//     boolean var64 = var57.isOnOrAfter(var63);
//     org.jfree.data.time.Day var65 = new org.jfree.data.time.Day();
//     int var66 = var65.getDayOfMonth();
//     java.util.Date var67 = var65.getEnd();
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(var67);
//     org.jfree.data.time.SerialDate var69 = var63.getEndOfCurrentMonth(var68);
//     org.jfree.data.time.SpreadsheetDate var71 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var72 = new org.jfree.data.time.Day();
//     int var73 = var72.getDayOfMonth();
//     java.util.Date var74 = var72.getEnd();
//     org.jfree.data.time.Month var75 = new org.jfree.data.time.Month(var74);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(var74);
//     org.jfree.data.time.Day var77 = new org.jfree.data.time.Day();
//     int var78 = var77.getDayOfMonth();
//     java.util.Date var79 = var77.getEnd();
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(var79);
//     boolean var82 = var71.isInRange(var76, var80, (-1));
//     int var83 = var71.getYYYY();
//     int var84 = var71.getYYYY();
//     int var85 = var71.getMonth();
//     org.jfree.data.time.SerialDate var86 = var68.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var71);
//     boolean var87 = var14.isAfter(var86);
//     int var88 = var14.getDayOfWeek();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var79);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var86);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var88 == 6);
// 
//   }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
    java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
    var5.removeAgedItems(false);
    java.lang.Object var9 = var5.clone();
    long var10 = var5.getMaximumItemAge();
    java.util.List var11 = var5.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var2);
//     java.util.TimeZone var6 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var2, var6);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.previous();
//     boolean var8 = var5.equals((java.lang.Object)1419148800000L);
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var12);
//     boolean var14 = var13.isEmpty();
//     var13.setMaximumItemAge(1419148800000L);
//     int var17 = var5.compareTo((java.lang.Object)var13);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5, "SerialDate.weekInMonthToString(): invalid code.", "21-December-2014", var20);
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day();
//     int var23 = var22.getDayOfMonth();
//     java.util.Date var24 = var22.getEnd();
//     org.jfree.data.time.Month var25 = new org.jfree.data.time.Month(var24);
//     org.jfree.data.time.Month var26 = new org.jfree.data.time.Month(var24);
//     boolean var27 = var21.equals((java.lang.Object)var24);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var29 = var21.getDataItem(1900);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     java.lang.Class var4 = null;
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var4);
//     java.util.Collection var6 = var2.getTimePeriodsUniqueToOtherSeries(var5);
//     var5.removeAgedItems(false);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     long var12 = var11.getMiddleMillisecond();
//     int var14 = var11.compareTo((java.lang.Object)0);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var5.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 10.0d);
//     boolean var17 = var5.isEmpty();
//     java.beans.PropertyChangeListener var18 = null;
//     var5.addPropertyChangeListener(var18);
//     var5.setDescription("21-December-2014");
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day();
//     int var24 = var23.getDayOfMonth();
//     java.util.Date var25 = var23.getEnd();
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(var25);
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var26);
//     var27.setDescription("Sunday");
//     java.lang.String var30 = var27.toString();
//     var5.setKey((java.lang.Comparable)var30);
//     java.beans.PropertyChangeListener var32 = null;
//     var5.removePropertyChangeListener(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var30 + "' != '" + "21-December-2014"+ "'", var30.equals("21-December-2014"));
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     java.lang.Object var3 = null;
//     int var4 = var2.compareTo(var3);
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var2, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var7 = var2.getSerialDate();
//     boolean var8 = var1.isOnOrAfter(var7);
//     java.util.Date var9 = var1.toDate();
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     boolean var12 = var1.isOnOrAfter((org.jfree.data.time.SerialDate)var11);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day();
//     int var16 = var15.getDayOfMonth();
//     java.util.Date var17 = var15.getEnd();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     java.util.Date var22 = var20.getEnd();
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(var22);
//     boolean var25 = var14.isInRange(var19, var23, (-1));
//     int var26 = var11.compareTo((java.lang.Object)var14);
//     org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var29 = new org.jfree.data.time.Day();
//     int var30 = var29.getDayOfMonth();
//     java.util.Date var31 = var29.getEnd();
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var31);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var31);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var28.isInRange(var33, var37, (-1));
//     int var40 = var28.getYYYY();
//     int var41 = var28.getYYYY();
//     int var42 = var28.getMonth();
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     java.lang.Object var44 = null;
//     int var45 = var43.compareTo(var44);
//     org.jfree.data.time.TimeSeriesDataItem var47 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var43, (java.lang.Number)0.0f);
//     boolean var49 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var43, (java.lang.Object)'#');
//     org.jfree.data.time.SerialDate var50 = var43.getSerialDate();
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day(var50);
//     org.jfree.data.time.SpreadsheetDate var53 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var54 = new org.jfree.data.time.Day();
//     int var55 = var54.getDayOfMonth();
//     java.util.Date var56 = var54.getEnd();
//     org.jfree.data.time.Month var57 = new org.jfree.data.time.Month(var56);
//     org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day();
//     int var60 = var59.getDayOfMonth();
//     java.util.Date var61 = var59.getEnd();
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(var61);
//     boolean var64 = var53.isInRange(var58, var62, (-1));
//     int var65 = var53.getYYYY();
//     int var66 = var53.getYYYY();
//     org.jfree.data.time.SerialDate var68 = var53.getFollowingDayOfWeek(1);
//     boolean var69 = var28.isInRange(var50, (org.jfree.data.time.SerialDate)var53);
//     boolean var70 = var11.isOnOrBefore((org.jfree.data.time.SerialDate)var28);
//     int var71 = var28.getYYYY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var55 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 1900);
// 
//   }

  public void test468() {}
//   public void test468() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     java.lang.Object var17 = null;
//     int var18 = var16.compareTo(var17);
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var21 = var16.getSerialDate();
//     boolean var22 = var15.isOnOrAfter(var21);
//     java.util.Date var23 = var15.toDate();
//     org.jfree.data.time.SpreadsheetDate var25 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day();
//     java.lang.Object var27 = null;
//     int var28 = var26.compareTo(var27);
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var31 = var26.getSerialDate();
//     boolean var32 = var25.isOnOrAfter(var31);
//     int var33 = var15.compare((org.jfree.data.time.SerialDate)var25);
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day();
//     int var35 = var34.getDayOfMonth();
//     java.util.Date var36 = var34.getEnd();
//     org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(var36);
//     org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(var36);
//     boolean var39 = var1.isInRange((org.jfree.data.time.SerialDate)var15, var38);
//     java.lang.String var40 = var15.getDescription();
//     org.jfree.data.time.SpreadsheetDate var42 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var43 = new org.jfree.data.time.Day();
//     int var44 = var43.getDayOfMonth();
//     java.util.Date var45 = var43.getEnd();
//     org.jfree.data.time.Month var46 = new org.jfree.data.time.Month(var45);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var45);
//     org.jfree.data.time.Day var48 = new org.jfree.data.time.Day();
//     int var49 = var48.getDayOfMonth();
//     java.util.Date var50 = var48.getEnd();
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(var50);
//     boolean var53 = var42.isInRange(var47, var51, (-1));
//     boolean var54 = var15.equals((java.lang.Object)(-1));
//     org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var57 = new org.jfree.data.time.Day();
//     int var58 = var57.getDayOfMonth();
//     java.util.Date var59 = var57.getEnd();
//     org.jfree.data.time.Month var60 = new org.jfree.data.time.Month(var59);
//     org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.createInstance(var59);
//     org.jfree.data.time.Day var62 = new org.jfree.data.time.Day();
//     int var63 = var62.getDayOfMonth();
//     java.util.Date var64 = var62.getEnd();
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.createInstance(var64);
//     boolean var67 = var56.isInRange(var61, var65, (-1));
//     int var68 = var56.getYYYY();
//     int var69 = var56.getYYYY();
//     int var70 = var56.toSerial();
//     int var71 = var15.compare((org.jfree.data.time.SerialDate)var56);
//     int var72 = var56.getDayOfWeek();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var54 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var58 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var67 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var72 == 6);
// 
//   }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     int var2 = var1.getDayOfMonth();
//     java.util.Date var3 = var1.getEnd();
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(var3);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var3);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(10, var6);
//     java.lang.String var8 = var7.toString();
//     int var10 = var7.compareTo((java.lang.Object)(-62167363200000L));
//     int var11 = var7.getMonth();
//     org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var14 = var13.toSerial();
//     int var15 = var7.compareTo((java.lang.Object)var13);
//     org.jfree.data.time.RegularTimePeriod var16 = var7.next();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "October 2014"+ "'", var8.equals("October 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
// 
//   }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.TimeSeriesDataItem var12 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)10);
//     org.jfree.data.time.TimeSeriesDataItem var14 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 0.0d);
//     long var15 = var10.getFirstMillisecond();
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, "21-December-2014", "January", var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day();
//     int var21 = var20.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(byte)0);
//     var19.add(var23, true);
// 
//   }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("org.jfree.data.general.SeriesChangeEvent[source=24180]", var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    boolean var6 = var4.equals((java.lang.Object)'a');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var4.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
//     java.lang.Object var6 = null;
//     int var7 = var5.compareTo(var6);
//     boolean var8 = var4.equals((java.lang.Object)var5);
//     java.util.Date var9 = var4.getTime();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(var9);
//     java.lang.String var11 = var10.toString();
//     java.util.Calendar var12 = null;
//     long var13 = var10.getMiddleMillisecond(var12);
// 
//   }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test477() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("SerialDate.weekInMonthToString(): invalid code.");
    java.lang.Throwable[] var2 = var1.getSuppressed();
    org.jfree.data.time.TimePeriodFormatException var4 = new org.jfree.data.time.TimePeriodFormatException("ERROR : Relative To String");
    var1.addSuppressed((java.lang.Throwable)var4);
    java.lang.String var6 = var4.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"+ "'", var6.equals("org.jfree.data.time.TimePeriodFormatException: ERROR : Relative To String"));

  }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(2014, 1900, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.Month var3 = new org.jfree.data.time.Month(var2);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(var2);
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year(var2, var5);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.jfree.data.time.Day var1 = new org.jfree.data.time.Day();
//     java.lang.Object var2 = null;
//     int var3 = var1.compareTo(var2);
//     org.jfree.data.time.TimeSeriesDataItem var5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)0.0f);
//     org.jfree.data.time.Day var6 = new org.jfree.data.time.Day();
//     boolean var7 = var5.equals((java.lang.Object)var6);
//     org.jfree.data.time.RegularTimePeriod var8 = var6.next();
//     org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var11 = new org.jfree.data.time.Day();
//     int var12 = var11.getDayOfMonth();
//     java.util.Date var13 = var11.getEnd();
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(var13);
//     org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(var13);
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     int var17 = var16.getDayOfMonth();
//     java.util.Date var18 = var16.getEnd();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     boolean var21 = var10.isInRange(var15, var19, (-1));
//     int var22 = var10.getYYYY();
//     int var23 = var10.getYYYY();
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day();
//     int var26 = var25.getDayOfMonth();
//     java.util.Date var27 = var25.getEnd();
//     org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(var27);
//     org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var28);
//     int var30 = var10.compare(var29);
//     org.jfree.data.time.Day var31 = new org.jfree.data.time.Day();
//     java.lang.Object var32 = null;
//     int var33 = var31.compareTo(var32);
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var31, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var36 = var31.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var38 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var39 = new org.jfree.data.time.Day();
//     int var40 = var39.getDayOfMonth();
//     java.util.Date var41 = var39.getEnd();
//     org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(var41);
//     org.jfree.data.time.Day var44 = new org.jfree.data.time.Day();
//     int var45 = var44.getDayOfMonth();
//     java.util.Date var46 = var44.getEnd();
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(var46);
//     boolean var49 = var38.isInRange(var43, var47, (-1));
//     org.jfree.data.time.SerialDate var50 = var36.getEndOfCurrentMonth(var47);
//     org.jfree.data.time.Day var51 = new org.jfree.data.time.Day();
//     java.lang.Object var52 = null;
//     int var53 = var51.compareTo(var52);
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)0.0f);
//     org.jfree.data.time.SerialDate var56 = var51.getSerialDate();
//     org.jfree.data.time.SpreadsheetDate var58 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var59 = new org.jfree.data.time.Day();
//     int var60 = var59.getDayOfMonth();
//     java.util.Date var61 = var59.getEnd();
//     org.jfree.data.time.Month var62 = new org.jfree.data.time.Month(var61);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(var61);
//     org.jfree.data.time.Day var64 = new org.jfree.data.time.Day();
//     int var65 = var64.getDayOfMonth();
//     java.util.Date var66 = var64.getEnd();
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(var66);
//     boolean var69 = var58.isInRange(var63, var67, (-1));
//     org.jfree.data.time.SerialDate var70 = var56.getEndOfCurrentMonth(var67);
//     org.jfree.data.time.SerialDate var71 = var47.getEndOfCurrentMonth(var56);
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var74 = new org.jfree.data.time.Day();
//     int var75 = var74.getDayOfMonth();
//     java.util.Date var76 = var74.getEnd();
//     org.jfree.data.time.Month var77 = new org.jfree.data.time.Month(var76);
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(var76);
//     org.jfree.data.time.Day var79 = new org.jfree.data.time.Day();
//     int var80 = var79.getDayOfMonth();
//     java.util.Date var81 = var79.getEnd();
//     org.jfree.data.time.SerialDate var82 = org.jfree.data.time.SerialDate.createInstance(var81);
//     boolean var84 = var73.isInRange(var78, var82, (-1));
//     int var85 = var73.getYYYY();
//     int var86 = var73.getYYYY();
//     org.jfree.data.time.Day var88 = new org.jfree.data.time.Day();
//     int var89 = var88.getDayOfMonth();
//     java.util.Date var90 = var88.getEnd();
//     org.jfree.data.time.SerialDate var91 = org.jfree.data.time.SerialDate.createInstance(var90);
//     org.jfree.data.time.SerialDate var92 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1, var91);
//     int var93 = var73.compare(var92);
//     org.jfree.data.time.SerialDate var94 = var47.getEndOfCurrentMonth((org.jfree.data.time.SerialDate)var73);
//     boolean var95 = var10.equals((java.lang.Object)var47);
//     int var96 = var6.compareTo((java.lang.Object)var10);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var97 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate)var10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var69 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var85 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var86 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var89 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var90);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var92);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var93 == (-41981));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var95 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var96 == 1);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.data.time.Year var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(10, var1);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    var2.setNotify(true);
    var2.setDescription("ThreadContext");
    java.lang.Class var11 = null;
    org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var11);
    java.lang.Class var14 = null;
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var14);
    java.util.Collection var16 = var12.getTimePeriodsUniqueToOtherSeries(var15);
    var15.removeAgedItems(false);
    java.lang.Class var19 = var15.getTimePeriodClass();
    int var20 = var15.getMaximumItemCount();
    org.jfree.data.time.TimeSeries var21 = var2.addAndOrUpdate(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var22 = var21.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     boolean var5 = var4.isEmpty();
//     java.lang.Class var6 = var4.getTimePeriodClass();
//     org.jfree.data.time.TimeSeries var9 = var4.createCopy(0, 12);
//     var4.setDescription("");
//     var4.setKey((java.lang.Comparable)'#');
//     var4.setRangeDescription("");
//     org.jfree.data.time.Day var16 = new org.jfree.data.time.Day();
//     int var17 = var16.getDayOfMonth();
//     java.util.Date var18 = var16.getEnd();
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var18);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var18);
//     long var22 = var21.getFirstMillisecond();
//     java.lang.Class var24 = null;
//     org.jfree.data.time.TimeSeries var25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var24);
//     java.lang.Class var27 = null;
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var27);
//     java.util.Collection var29 = var25.getTimePeriodsUniqueToOtherSeries(var28);
//     boolean var31 = var25.equals((java.lang.Object)"");
//     int var32 = var21.compareTo((java.lang.Object)"");
//     var4.add((org.jfree.data.time.RegularTimePeriod)var21, 1.0d);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var1);
    boolean var3 = var2.getNotify();
    var2.removeAgedItems(false);
    var2.setNotify(true);
    var2.setDescription("ThreadContext");
    var2.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var13 = var2.getDataItem(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)"hi!", "21-December-2014", "ThreadContext", var3);
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day();
    java.lang.Object var6 = null;
    int var7 = var5.compareTo(var6);
    org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)0.0f);
    boolean var11 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)'#');
    java.lang.Class var15 = null;
    org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var15);
    java.lang.String var17 = var16.getRangeDescription();
    int var18 = var5.compareTo((java.lang.Object)var17);
    org.jfree.data.time.TimeSeriesDataItem var20 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(-62167363200000L));
    org.jfree.data.time.SerialDate var21 = var5.getSerialDate();
    var21.setDescription("Preceding");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(1, 0);
//     long var8 = var7.getMiddleMillisecond();
//     long var9 = var7.getMiddleMillisecond();
//     boolean var10 = var4.equals((java.lang.Object)var9);
//     java.util.Calendar var11 = null;
//     long var12 = var4.getMiddleMillisecond(var11);
//     org.jfree.data.time.RegularTimePeriod var13 = var4.next();
//     java.util.Calendar var14 = null;
//     long var15 = var4.getFirstMillisecond(var14);
//     java.util.Calendar var16 = null;
//     var4.peg(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1419235199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1419235199999L);
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)0);
//     org.jfree.data.time.Day var4 = new org.jfree.data.time.Day();
//     int var5 = var4.getDayOfMonth();
//     java.util.Date var6 = var4.getEnd();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month(var6);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var7, (java.lang.Number)10);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var11);
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-62167363200000L), var14);
//     java.util.Collection var16 = var12.getTimePeriodsUniqueToOtherSeries(var15);
//     boolean var18 = var12.equals((java.lang.Object)"");
//     org.jfree.data.time.TimeSeries var19 = var3.addAndOrUpdate(var12);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var23);
//     java.lang.String var25 = var24.getRangeDescription();
//     var24.clear();
//     org.jfree.data.time.Day var27 = new org.jfree.data.time.Day();
//     int var28 = var27.getDayOfMonth();
//     java.util.Date var29 = var27.getEnd();
//     org.jfree.data.time.RegularTimePeriod var30 = var27.next();
//     org.jfree.data.time.TimeSeriesDataItem var32 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var27, 10.0d);
//     int var33 = var19.getIndex((org.jfree.data.time.RegularTimePeriod)var27);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var34 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var27);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + ""+ "'", var25.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-1));
// 
//   }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.Day var2 = new org.jfree.data.time.Day();
//     int var3 = var2.getDayOfMonth();
//     java.util.Date var4 = var2.getEnd();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day();
//     int var8 = var7.getDayOfMonth();
//     java.util.Date var9 = var7.getEnd();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(var9);
//     boolean var12 = var1.isInRange(var6, var10, (-1));
//     int var13 = var1.getYYYY();
//     int var14 = var1.getYYYY();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var16 = var1.getFollowingDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     java.util.Date var2 = var0.getEnd();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.FixedMillisecond var4 = new org.jfree.data.time.FixedMillisecond(var2);
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var2);
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(var2);
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var2, var7);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    java.lang.String var5 = var4.getDescription();
    org.jfree.data.time.TimeSeriesDataItem var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.add(var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
    var4.removeAgedItems(true);
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var4.addChangeListener(var7);
    org.jfree.data.general.SeriesChangeListener var9 = null;
    var4.removeChangeListener(var9);
    long var11 = var4.getMaximumItemAge();
    org.jfree.data.general.SeriesChangeEvent var12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 9223372036854775807L);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getDayOfMonth();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, (java.lang.Number)(byte)0);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test497() {}
//   public void test497() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     var28.setDomainDescription("");
//     java.lang.String var31 = var28.getDomainDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var31 + "' != '" + ""+ "'", var31.equals(""));
// 
//   }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, 2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var3);
//     var4.removeAgedItems(true);
//     org.jfree.data.time.Day var8 = new org.jfree.data.time.Day();
//     int var9 = var8.getDayOfMonth();
//     java.util.Date var10 = var8.getEnd();
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(var10);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var10);
//     org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(10, var13);
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var18);
//     boolean var21 = var19.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var24 = new org.jfree.data.time.Month(1, 0);
//     long var25 = var24.getMiddleMillisecond();
//     var19.delete((org.jfree.data.time.RegularTimePeriod)var24);
//     long var27 = var24.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var28 = var4.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var24);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1), "SerialDate.weekInMonthToString(): invalid code.", "", var32);
//     boolean var35 = var33.equals((java.lang.Object)'a');
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month(1, 0);
//     long var39 = var38.getMiddleMillisecond();
//     var33.delete((org.jfree.data.time.RegularTimePeriod)var38);
//     java.lang.String var41 = var33.getRangeDescription();
//     long var42 = var33.getMaximumItemAge();
//     int var43 = var24.compareTo((java.lang.Object)var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == (-62167363200000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == (-62150212800001L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var41 + "' != '" + ""+ "'", var41.equals(""));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 9223372036854775807L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("ThreadContext");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

}
