
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    java.awt.Color var9 = java.awt.Color.getColor("", (-1));
    boolean var10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var6, (java.awt.Paint)var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var16 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var14, (org.jfree.chart.urls.XYURLGenerator)var16);
    var17.setItemLabelAnchorOffset(0.0d);
    boolean var20 = var11.equals((java.lang.Object)var17);
    java.util.Collection var21 = var17.getAnnotations();
    java.awt.Color var25 = java.awt.Color.getColor("", (-1));
    java.awt.Color var28 = java.awt.Color.getColor("", (-1));
    boolean var29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var25, (java.awt.Paint)var28);
    java.awt.Color var30 = var28.darker();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setSeriesFillPaint((-457), (java.awt.Paint)var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.lang.String var8 = var3.getLabel();
    org.jfree.data.RangeType var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setRangeType(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.lang.String var8 = var3.getLabel();
    boolean var9 = var3.isPositiveArrowVisible();
    var3.setAutoRangeIncludesZero(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    org.jfree.chart.renderer.xy.XYBarRenderer var12 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var12.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var16 = null;
    org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot(var16);
    java.awt.Image var18 = var17.getBackgroundImage();
    java.awt.Color var21 = java.awt.Color.getColor("", (-1));
    java.awt.Color var24 = java.awt.Color.getColor("", (-1));
    boolean var25 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var21, (java.awt.Paint)var24);
    org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var21);
    var17.setLabelPaint((java.awt.Paint)var21);
    var12.setBaseItemLabelPaint((java.awt.Paint)var21);
    org.jfree.chart.labels.ItemLabelPosition var29 = var12.getBasePositiveItemLabelPosition();
    var4.setSeriesNegativeItemLabelPosition(0, var29);
    java.lang.Boolean var32 = var4.getSeriesVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("Sunday");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    java.awt.Shape var0 = null;
    java.awt.Font var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Image var5 = var4.getBackgroundImage();
    double var6 = var4.getOuterSeparatorExtension();
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("hi!", var2, (org.jfree.chart.plot.Plot)var4, false);
    org.jfree.chart.title.LegendTitle var11 = var10.getLegend();
    java.awt.RenderingHints var12 = var10.getRenderingHints();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var14 = new org.jfree.chart.entity.JFreeChartEntity(var0, var10, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"", 0.0d, (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() {}
//   public void test8() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }
// 
// 
//     java.lang.String[] var6 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var7 = new org.jfree.chart.axis.SymbolAxis("hi!", var6);
//     var7.setLabelAngle(0.0d);
//     java.lang.Object var10 = null;
//     boolean var11 = var7.equals(var10);
//     java.awt.Shape var12 = var7.getRightArrow();
//     org.jfree.chart.labels.XYToolTipGenerator var14 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var16 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var14, (org.jfree.chart.urls.XYURLGenerator)var16);
//     org.jfree.data.time.TimeSeries var18 = null;
//     org.jfree.data.time.TimeSeriesCollection var19 = new org.jfree.data.time.TimeSeriesCollection(var18);
//     var19.removeAllSeries();
//     org.jfree.data.Range var21 = var17.findRangeBounds((org.jfree.data.xy.XYDataset)var19);
//     org.jfree.chart.title.LegendTitle var22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var17);
//     org.jfree.chart.entity.TitleEntity var24 = new org.jfree.chart.entity.TitleEntity(var12, (org.jfree.chart.title.Title)var22, "");
//     org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var26.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     java.awt.Image var32 = var31.getBackgroundImage();
//     java.awt.Color var35 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var38 = java.awt.Color.getColor("", (-1));
//     boolean var39 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var35, (java.awt.Paint)var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
//     var31.setLabelPaint((java.awt.Paint)var35);
//     var26.setBaseItemLabelPaint((java.awt.Paint)var35);
//     double var43 = var26.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var45 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var47 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var48 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var45, (org.jfree.chart.urls.XYURLGenerator)var47);
//     org.jfree.data.time.TimeSeries var49 = null;
//     org.jfree.data.time.TimeSeriesCollection var50 = new org.jfree.data.time.TimeSeriesCollection(var49);
//     var50.removeAllSeries();
//     org.jfree.data.Range var52 = var48.findRangeBounds((org.jfree.data.xy.XYDataset)var50);
//     java.awt.Stroke var54 = var48.lookupSeriesStroke(1);
//     var26.setBaseOutlineStroke(var54);
//     org.jfree.data.general.PieDataset var56 = null;
//     org.jfree.chart.plot.RingPlot var57 = new org.jfree.chart.plot.RingPlot(var56);
//     java.awt.Image var58 = var57.getBackgroundImage();
//     double var59 = var57.getOuterSeparatorExtension();
//     java.awt.Paint var60 = var57.getLabelBackgroundPaint();
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("", "hi!", "December 2014", "Pie Plot", var12, var54, var60);
//     
//     // Checks the contract:  equals-hashcode on var16 and var47
//     assertTrue("Contract failed: equals-hashcode on var16 and var47", var16.equals(var47) ? var16.hashCode() == var47.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var47 and var16
//     assertTrue("Contract failed: equals-hashcode on var47 and var16", var47.equals(var16) ? var47.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var50
//     assertTrue("Contract failed: equals-hashcode on var19 and var50", var19.equals(var50) ? var19.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var19
//     assertTrue("Contract failed: equals-hashcode on var50 and var19", var50.equals(var19) ? var50.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("December 2014");

  }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
//     java.awt.Color var6 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var9 = java.awt.Color.getColor("", (-1));
//     boolean var10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var6, (java.awt.Paint)var9);
//     org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
//     boolean var12 = var1.equals((java.lang.Object)var11);
//     org.jfree.chart.labels.XYToolTipGenerator var14 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var16 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var14, (org.jfree.chart.urls.XYURLGenerator)var16);
//     var17.setItemLabelAnchorOffset(0.0d);
//     boolean var20 = var11.equals((java.lang.Object)var17);
//     java.util.Collection var21 = var17.getAnnotations();
//     org.jfree.chart.urls.XYURLGenerator var23 = var17.getSeriesURLGenerator((-1));
//     org.jfree.chart.LegendItemCollection var24 = var17.getLegendItems();
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var29 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var27, (org.jfree.chart.urls.XYURLGenerator)var29);
//     org.jfree.data.time.TimeSeries var31 = null;
//     org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var31);
//     var32.removeAllSeries();
//     org.jfree.data.Range var34 = var30.findRangeBounds((org.jfree.data.xy.XYDataset)var32);
//     java.awt.Stroke var36 = var30.lookupSeriesStroke(1);
//     var17.setSeriesStroke(10, var36, false);
//     
//     // Checks the contract:  equals-hashcode on var1 and var32
//     assertTrue("Contract failed: equals-hashcode on var1 and var32", var1.equals(var32) ? var1.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var1
//     assertTrue("Contract failed: equals-hashcode on var32 and var1", var32.equals(var1) ? var32.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var29
//     assertTrue("Contract failed: equals-hashcode on var16 and var29", var16.equals(var29) ? var16.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var16
//     assertTrue("Contract failed: equals-hashcode on var29 and var16", var29.equals(var16) ? var29.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var30
//     assertTrue("Contract failed: equals-hashcode on var17 and var30", var17.equals(var30) ? var17.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var17
//     assertTrue("Contract failed: equals-hashcode on var30 and var17", var30.equals(var17) ? var30.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var6 = var1.getSeriesKey(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     double var18 = var1.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var22 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var20, (org.jfree.chart.urls.XYURLGenerator)var22);
//     org.jfree.data.time.TimeSeries var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
//     var25.removeAllSeries();
//     org.jfree.data.Range var27 = var23.findRangeBounds((org.jfree.data.xy.XYDataset)var25);
//     java.awt.Stroke var29 = var23.lookupSeriesStroke(1);
//     var1.setBaseOutlineStroke(var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
//     java.awt.Image var33 = var32.getBackgroundImage();
//     java.awt.Color var36 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var39 = java.awt.Color.getColor("", (-1));
//     boolean var40 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var36, (java.awt.Paint)var39);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var36);
//     var32.setLabelPaint((java.awt.Paint)var36);
//     org.jfree.chart.event.RendererChangeEvent var44 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var36, true);
//     var1.setBaseOutlinePaint((java.awt.Paint)var36);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var41
//     assertTrue("Contract failed: equals-hashcode on var15 and var41", var15.equals(var41) ? var15.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var15
//     assertTrue("Contract failed: equals-hashcode on var41 and var15", var41.equals(var15) ? var41.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Paint var4 = var1.getLabelBackgroundPaint();
    java.awt.Paint var6 = null;
    var1.setSectionPaint((java.lang.Comparable)"hi!", var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Font var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Image var14 = var13.getBackgroundImage();
//     double var15 = var13.getOuterSeparatorExtension();
//     java.awt.Stroke var16 = null;
//     var13.setOutlineStroke(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
//     java.awt.Graphics2D var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     java.lang.String[] var27 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var28 = new org.jfree.chart.axis.SymbolAxis("hi!", var27);
//     var28.setLabelAngle(0.0d);
//     org.jfree.chart.axis.NumberTickUnit var31 = var28.getTickUnit();
//     java.awt.Paint var32 = var28.getGridBandPaint();
//     java.lang.Object var33 = var9.draw(var23, var24, (java.lang.Object)var32);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setLabelAnchor(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Paint var4 = var1.getLabelBackgroundPaint();
    boolean var5 = var1.getSectionOutlinesVisible();
    var1.setIgnoreNullValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test17() {}
//   public void test17() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var6.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Image var12 = var11.getBackgroundImage();
//     java.awt.Color var15 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var18 = java.awt.Color.getColor("", (-1));
//     boolean var19 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var15, (java.awt.Paint)var18);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     var11.setLabelPaint((java.awt.Paint)var15);
//     var6.setBaseItemLabelPaint((java.awt.Paint)var15);
//     double var23 = var6.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var25, (org.jfree.chart.urls.XYURLGenerator)var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     var30.removeAllSeries();
//     org.jfree.data.Range var32 = var28.findRangeBounds((org.jfree.data.xy.XYDataset)var30);
//     java.awt.Stroke var34 = var28.lookupSeriesStroke(1);
//     var6.setBaseOutlineStroke(var34);
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     java.awt.Image var38 = var37.getBackgroundImage();
//     java.awt.Color var41 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var44 = java.awt.Color.getColor("", (-1));
//     boolean var45 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var41, (java.awt.Paint)var44);
//     org.jfree.chart.block.BlockBorder var46 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var41);
//     var37.setLabelPaint((java.awt.Paint)var41);
//     org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("", "?series=1&amp;item=10", "December 2014", "?series=1&amp;item=10", var4, var34, (java.awt.Paint)var41);
//     
//     // Checks the contract:  equals-hashcode on var11 and var37
//     assertTrue("Contract failed: equals-hashcode on var11 and var37", var11.equals(var37) ? var11.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var11
//     assertTrue("Contract failed: equals-hashcode on var37 and var11", var37.equals(var11) ? var37.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var46
//     assertTrue("Contract failed: equals-hashcode on var20 and var46", var20.equals(var46) ? var20.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var20
//     assertTrue("Contract failed: equals-hashcode on var46 and var20", var46.equals(var20) ? var46.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }


    java.awt.Shape var0 = null;
    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot(var1);
    java.awt.Image var3 = var2.getBackgroundImage();
    java.awt.Stroke var5 = var2.getSectionOutlineStroke((java.lang.Comparable)100.0d);
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    boolean var12 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var8, (java.awt.Paint)var11);
    int var13 = var11.getAlpha();
    var2.setBaseSectionPaint((java.awt.Paint)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.PlotEntity var17 = new org.jfree.chart.entity.PlotEntity(var0, (org.jfree.chart.plot.Plot)var2, "?series=1&amp;item=10", "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 255);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    boolean var8 = var4.isSeriesItemLabelsVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    boolean var6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var2, (java.awt.Paint)var5);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    java.awt.Paint var8 = var7.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.XYPlot var11 = null;
    org.jfree.data.time.TimeSeries var12 = null;
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
    var13.removeAllSeries();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var19 = var13.getEndXValue(100, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Image var4 = var3.getBackgroundImage();
//     double var5 = var3.getOuterSeparatorExtension();
//     java.awt.Stroke var6 = null;
//     var3.setOutlineStroke(var6);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
//     org.jfree.chart.title.LegendTitle var10 = var9.getLegend();
//     int var11 = var9.getSubtitleCount();
//     org.jfree.chart.labels.XYToolTipGenerator var13 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var15 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var13, (org.jfree.chart.urls.XYURLGenerator)var15);
//     org.jfree.data.time.TimeSeries var17 = null;
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var17);
//     var18.removeAllSeries();
//     org.jfree.data.Range var20 = var16.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.chart.title.LegendTitle var21 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var16);
//     java.awt.Font var23 = null;
//     org.jfree.data.general.PieDataset var24 = null;
//     org.jfree.chart.plot.RingPlot var25 = new org.jfree.chart.plot.RingPlot(var24);
//     java.awt.Image var26 = var25.getBackgroundImage();
//     double var27 = var25.getOuterSeparatorExtension();
//     java.awt.Stroke var28 = null;
//     var25.setOutlineStroke(var28);
//     org.jfree.chart.JFreeChart var31 = new org.jfree.chart.JFreeChart("hi!", var23, (org.jfree.chart.plot.Plot)var25, false);
//     java.awt.Paint var32 = var31.getBackgroundPaint();
//     var21.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var31);
//     org.jfree.chart.util.HorizontalAlignment var34 = var21.getHorizontalAlignment();
//     var9.addSubtitle((org.jfree.chart.title.Title)var21);
//     
//     // Checks the contract:  equals-hashcode on var3 and var25
//     assertTrue("Contract failed: equals-hashcode on var3 and var25", var3.equals(var25) ? var3.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var3
//     assertTrue("Contract failed: equals-hashcode on var25 and var3", var25.equals(var3) ? var25.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    int var22 = var19.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 15);

  }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    var9.setBackgroundImageAlpha(10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    java.awt.Paint var13 = var3.getGridBandAlternatePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     var3.setLabelAngle(0.0d);
//     java.lang.Object var6 = null;
//     boolean var7 = var3.equals(var6);
//     java.awt.Shape var8 = var3.getRightArrow();
//     org.jfree.data.general.PieDataset var9 = null;
//     org.jfree.chart.plot.RingPlot var10 = new org.jfree.chart.plot.RingPlot(var9);
//     java.awt.Image var11 = var10.getBackgroundImage();
//     double var12 = var10.getShadowXOffset();
//     boolean var13 = var3.equals((java.lang.Object)var12);
//     var3.setTickMarkOutsideLength(0.0f);
//     java.awt.Graphics2D var16 = null;
//     org.jfree.data.general.PieDataset var17 = null;
//     org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
//     java.awt.Image var19 = var18.getBackgroundImage();
//     double var20 = var18.getOuterSeparatorExtension();
//     java.awt.Stroke var21 = null;
//     var18.setOutlineStroke(var21);
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.util.RectangleEdge var24 = null;
//     org.jfree.chart.axis.AxisSpace var25 = null;
//     org.jfree.chart.axis.AxisSpace var26 = var3.reserveSpace(var16, (org.jfree.chart.plot.Plot)var18, var23, var24, var25);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.data.KeyedValues var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)100L, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() {}
//   public void test29() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setVisible(false);
    org.jfree.chart.util.RectangleInsets var25 = var9.getLegendItemGraphicPadding();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.plot.IntervalMarker var29 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var30 = var29.getLabelOffsetType();
    org.jfree.chart.plot.IntervalMarker var33 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var34 = var33.getLabelOffsetType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var35 = var25.createAdjustedRectangle(var26, var30, var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     var3.setLabelAngle(0.0d);
//     java.lang.Object var6 = null;
//     boolean var7 = var3.equals(var6);
//     java.awt.Shape var8 = var3.getRightArrow();
//     org.jfree.chart.labels.XYToolTipGenerator var10 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var12 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var10, (org.jfree.chart.urls.XYURLGenerator)var12);
//     org.jfree.data.time.TimeSeries var14 = null;
//     org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
//     var15.removeAllSeries();
//     org.jfree.data.Range var17 = var13.findRangeBounds((org.jfree.data.xy.XYDataset)var15);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.entity.TitleEntity var20 = new org.jfree.chart.entity.TitleEntity(var8, (org.jfree.chart.title.Title)var18, "");
//     org.jfree.chart.labels.XYToolTipGenerator var22 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var22, (org.jfree.chart.urls.XYURLGenerator)var24);
//     org.jfree.data.time.TimeSeries var26 = null;
//     org.jfree.data.time.TimeSeriesCollection var27 = new org.jfree.data.time.TimeSeriesCollection(var26);
//     var27.removeAllSeries();
//     org.jfree.data.Range var29 = var25.findRangeBounds((org.jfree.data.xy.XYDataset)var27);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     boolean var31 = var20.equals((java.lang.Object)var30);
//     
//     // Checks the contract:  equals-hashcode on var12 and var24
//     assertTrue("Contract failed: equals-hashcode on var12 and var24", var12.equals(var24) ? var12.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var12
//     assertTrue("Contract failed: equals-hashcode on var24 and var12", var24.equals(var12) ? var24.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var27
//     assertTrue("Contract failed: equals-hashcode on var15 and var27", var15.equals(var27) ? var15.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var15
//     assertTrue("Contract failed: equals-hashcode on var27 and var15", var27.equals(var15) ? var27.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    java.text.AttributedString var0 = null;
    java.lang.String[] var6 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var7 = new org.jfree.chart.axis.SymbolAxis("hi!", var6);
    var7.setLabelAngle(0.0d);
    java.lang.Object var10 = null;
    boolean var11 = var7.equals(var10);
    double var12 = var7.getFixedDimension();
    java.awt.Shape var13 = var7.getLeftArrow();
    org.jfree.chart.labels.XYToolTipGenerator var15 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var17 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var15, (org.jfree.chart.urls.XYURLGenerator)var17);
    var18.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var21 = null;
    var18.notifyListeners(var21);
    boolean var23 = var18.getPlotLines();
    java.awt.Shape var25 = var18.lookupLegendShape(100);
    java.awt.Stroke var29 = var18.getItemStroke((-457), (-1), true);
    org.jfree.data.general.PieDataset var30 = null;
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
    java.awt.Image var32 = var31.getBackgroundImage();
    java.awt.Color var35 = java.awt.Color.getColor("", (-1));
    java.awt.Color var38 = java.awt.Color.getColor("", (-1));
    boolean var39 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var35, (java.awt.Paint)var38);
    org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
    var31.setLabelPaint((java.awt.Paint)var35);
    org.jfree.chart.event.RendererChangeEvent var43 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var35, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem(var0, "?series=1&amp;item=10", "", "?series=1&amp;item=10", var13, var29, (java.awt.Paint)var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    org.jfree.chart.axis.NumberTickUnit var6 = var3.getTickUnit();
    java.awt.Paint var7 = var3.getGridBandPaint();
    java.awt.Graphics2D var8 = null;
    org.jfree.chart.axis.AxisState var10 = new org.jfree.chart.axis.AxisState(0.0d);
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    java.util.List var13 = var3.refreshTicks(var8, var10, var11, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getPlotLines();
    java.awt.Shape var11 = var4.lookupLegendShape(100);
    java.awt.Stroke var15 = var4.getItemStroke((-457), (-1), true);
    double var16 = var4.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }


    org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, 0.0d, 10.0d);
    org.jfree.data.time.TimeSeries var4 = null;
    org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var4);
    boolean var6 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var5);
    boolean var7 = var3.equals((java.lang.Object)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    org.jfree.chart.LegendItemCollection var12 = var1.getLegendItems();
    org.jfree.chart.plot.PieLabelLinkStyle var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStyle(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     java.lang.String[] var33 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("hi!", var33);
//     var34.setLabelAngle(0.0d);
//     java.lang.Object var37 = null;
//     boolean var38 = var34.equals(var37);
//     java.lang.String var39 = var34.getLabelURL();
//     org.jfree.chart.plot.Plot var40 = var34.getPlot();
//     var34.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Font var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     double var50 = var48.getOuterSeparatorExtension();
//     java.awt.Stroke var51 = null;
//     var48.setOutlineStroke(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, false);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     java.awt.RenderingHints var56 = var54.getRenderingHints();
//     java.awt.Color var59 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var62 = java.awt.Color.getColor("", (-1));
//     boolean var63 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var59, (java.awt.Paint)var62);
//     java.awt.Color var64 = var62.darker();
//     var54.setBackgroundPaint((java.awt.Paint)var62);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     int var68 = var67.getPieIndex();
//     org.jfree.data.general.DatasetGroup var69 = var67.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var71.setBaseCreateEntities(false, true);
//     boolean var75 = var67.equals((java.lang.Object)true);
//     java.awt.Stroke var76 = var67.getOutlineStroke();
//     var4.drawDomainLine(var11, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.chart.axis.ValueAxis)var34, var43, 10.0d, (java.awt.Paint)var62, var76);
//     org.jfree.chart.plot.PlotRenderingInfo var80 = null;
//     java.awt.geom.Point2D var81 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var30.zoomDomainAxes(1.0d, 0.0d, var80, var81);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
// 
//   }

  public void test38() {}
//   public void test38() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     var3.setLabelAngle(0.0d);
//     java.lang.Object var6 = null;
//     boolean var7 = var3.equals(var6);
//     java.awt.Shape var8 = var3.getRightArrow();
//     org.jfree.chart.labels.XYToolTipGenerator var10 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var12 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var10, (org.jfree.chart.urls.XYURLGenerator)var12);
//     org.jfree.data.time.TimeSeries var14 = null;
//     org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
//     var15.removeAllSeries();
//     org.jfree.data.Range var17 = var13.findRangeBounds((org.jfree.data.xy.XYDataset)var15);
//     org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
//     org.jfree.chart.entity.TitleEntity var20 = new org.jfree.chart.entity.TitleEntity(var8, (org.jfree.chart.title.Title)var18, "");
//     java.awt.Font var22 = null;
//     org.jfree.data.general.PieDataset var23 = null;
//     org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
//     java.awt.Image var25 = var24.getBackgroundImage();
//     double var26 = var24.getOuterSeparatorExtension();
//     java.awt.Stroke var27 = null;
//     var24.setOutlineStroke(var27);
//     org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", var22, (org.jfree.chart.plot.Plot)var24, false);
//     java.awt.Paint var31 = var30.getBackgroundPaint();
//     boolean var32 = var20.equals((java.lang.Object)var31);
//     org.jfree.data.time.Month var33 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var33);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var36 = var35.getYear();
//     java.lang.String var37 = var35.toString();
//     org.jfree.data.time.Month var38 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var39 = var38.getYear();
//     org.jfree.data.time.TimeSeries var40 = var34.createCopy((org.jfree.data.time.RegularTimePeriod)var35, (org.jfree.data.time.RegularTimePeriod)var39);
//     boolean var41 = var20.equals((java.lang.Object)var34);
//     var34.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "December 2014"+ "'", var37.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
// 
//   }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var1.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    java.awt.Image var7 = var6.getBackgroundImage();
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    java.awt.Color var13 = java.awt.Color.getColor("", (-1));
    boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    var6.setLabelPaint((java.awt.Paint)var10);
    var1.setBaseItemLabelPaint((java.awt.Paint)var10);
    java.lang.Object var18 = null;
    boolean var19 = var10.equals(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    int var5 = var4.getPieIndex();
    java.lang.String var6 = var4.getNoDataMessage();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var1.getSeriesKey(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    boolean var23 = var9.equals((java.lang.Object)(short)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(0, 0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.XYPlot var11 = null;
    org.jfree.data.time.TimeSeries var12 = null;
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
    var13.removeAllSeries();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
    org.jfree.data.time.TimeSeries var17 = null;
    org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var17);
    boolean var19 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.general.DatasetGroup var20 = var18.getGroup();
    org.jfree.data.Range var21 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var18);
    org.jfree.data.DomainOrder var22 = var18.getDomainOrder();
    var16.endSeriesPass((org.jfree.data.xy.XYDataset)var18, (-1), 10, 100, 1, 0);
    
    // Checks the contract:  equals-hashcode on var13 and var18
    assertTrue("Contract failed: equals-hashcode on var13 and var18", var13.equals(var18) ? var13.hashCode() == var18.hashCode() : true);
    
    // Checks the contract:  equals-hashcode on var18 and var13
    assertTrue("Contract failed: equals-hashcode on var18 and var13", var18.equals(var13) ? var18.hashCode() == var13.hashCode() : true);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.util.RectangleEdge var12 = null;
    double var13 = var3.lengthToJava2D(0.0d, var11, var12);
    java.awt.Graphics2D var14 = null;
    org.jfree.chart.axis.AxisState var16 = new org.jfree.chart.axis.AxisState(0.0d);
    java.awt.geom.Rectangle2D var17 = null;
    org.jfree.chart.util.RectangleEdge var18 = null;
    java.util.List var19 = var3.refreshTicks(var14, var16, var17, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Font var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Image var14 = var13.getBackgroundImage();
//     double var15 = var13.getOuterSeparatorExtension();
//     java.awt.Stroke var16 = null;
//     var13.setOutlineStroke(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.ChartRenderingInfo var24 = null;
//     var19.handleClick(10, 0, var24);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("Pie Plot");

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }


    java.awt.Font var2 = null;
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Image var5 = var4.getBackgroundImage();
    double var6 = var4.getOuterSeparatorExtension();
    java.awt.Stroke var7 = null;
    var4.setOutlineStroke(var7);
    org.jfree.chart.JFreeChart var10 = new org.jfree.chart.JFreeChart("hi!", var2, (org.jfree.chart.plot.Plot)var4, false);
    java.awt.Paint var11 = var10.getBackgroundPaint();
    org.jfree.chart.event.ChartChangeEventType var12 = null;
    org.jfree.chart.event.ChartChangeEvent var13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)'a', var10, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var23 = var22.getLabelOffsetType();
//     double var24 = var22.getEndValue();
//     org.jfree.chart.util.Layer var25 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var18.addDomainMarker(100, (org.jfree.chart.plot.Marker)var22, var25);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 100.0d);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    java.awt.Font var9 = var3.getLabelFont();
    boolean var10 = var3.getAutoRangeIncludesZero();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    var1.sort();
    java.lang.String var3 = var1.toString();
    org.jfree.chart.plot.PieLabelRecord var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addPieLabelRecord(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + ""+ "'", var3.equals(""));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.plot.PlotRenderingInfo var20 = null;
//     java.awt.geom.Point2D var21 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var18.zoomDomainAxes((-6.0d), var20, var21, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     var18.setRangeGridlinesVisible(false);
//     java.awt.Paint var24 = var18.getRangeCrosshairPaint();
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       boolean var29 = var18.removeRangeMarker(0, var26, var27, true);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    var3.centerRange(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
    org.jfree.data.time.TimeSeriesDataItem var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var2, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    java.awt.Font var5 = null;
    org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, (-1.0d), 100.0d, 0.0d, 0.0d, var5);
    java.awt.Graphics2D var7 = null;
    double var8 = var6.getHeight(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.lang.String var8 = var3.getLabelURL();
    org.jfree.chart.plot.Plot var9 = var3.getPlot();
    var3.setAutoRangeMinimumSize(100.0d, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     double var18 = var1.getMargin();
//     java.awt.Paint var20 = var1.getLegendTextPaint(1);
//     org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var23.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var27 = null;
//     org.jfree.chart.plot.RingPlot var28 = new org.jfree.chart.plot.RingPlot(var27);
//     java.awt.Image var29 = var28.getBackgroundImage();
//     java.awt.Color var32 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var35 = java.awt.Color.getColor("", (-1));
//     boolean var36 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var32, (java.awt.Paint)var35);
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var32);
//     var28.setLabelPaint((java.awt.Paint)var32);
//     var23.setBaseItemLabelPaint((java.awt.Paint)var32);
//     org.jfree.chart.labels.ItemLabelPosition var40 = var23.getBasePositiveItemLabelPosition();
//     var1.setSeriesNegativeItemLabelPosition(10, var40);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var1.", var23.equals(var1) == var1.equals(var23));
//     
//     // Checks the contract:  equals-hashcode on var6 and var28
//     assertTrue("Contract failed: equals-hashcode on var6 and var28", var6.equals(var28) ? var6.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var6
//     assertTrue("Contract failed: equals-hashcode on var28 and var6", var28.equals(var6) ? var28.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var37
//     assertTrue("Contract failed: equals-hashcode on var15 and var37", var15.equals(var37) ? var15.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var15
//     assertTrue("Contract failed: equals-hashcode on var37 and var15", var37.equals(var15) ? var37.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     boolean var13 = var4.isItemLabelVisible(1, (-1), true);
//     org.jfree.data.general.PieDataset var15 = null;
//     org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
//     int var17 = var16.getPieIndex();
//     org.jfree.data.general.DatasetGroup var18 = var16.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var20 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var20.setBaseCreateEntities(false, true);
//     boolean var24 = var16.equals((java.lang.Object)true);
//     java.awt.Stroke var25 = var16.getOutlineStroke();
//     var4.setSeriesStroke(0, var25, false);
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     int var30 = var29.getPieIndex();
//     org.jfree.data.general.DatasetGroup var31 = var29.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var33 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var33.setBaseCreateEntities(false, true);
//     boolean var37 = var29.equals((java.lang.Object)true);
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     java.awt.Image var40 = var39.getBackgroundImage();
//     java.awt.Color var43 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var46 = java.awt.Color.getColor("", (-1));
//     boolean var47 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var43, (java.awt.Paint)var46);
//     org.jfree.chart.block.BlockBorder var48 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var43);
//     var39.setLabelPaint((java.awt.Paint)var43);
//     boolean var50 = var29.equals((java.lang.Object)var43);
//     var4.setBaseFillPaint((java.awt.Paint)var43, false);
//     
//     // Checks the contract:  equals-hashcode on var16 and var29
//     assertTrue("Contract failed: equals-hashcode on var16 and var29", var16.equals(var29) ? var16.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var16
//     assertTrue("Contract failed: equals-hashcode on var29 and var16", var29.equals(var16) ? var29.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    java.lang.Object var22 = var9.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    int var3 = var1.indexOf((java.lang.Comparable)100L);
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    java.lang.String[] var7 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var8 = new org.jfree.chart.axis.SymbolAxis("hi!", var7);
    var8.setLabelAngle(0.0d);
    java.lang.Object var11 = null;
    boolean var12 = var8.equals(var11);
    double var13 = var8.getFixedDimension();
    java.awt.Shape var14 = var8.getLeftArrow();
    java.lang.Object var15 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var8);
    java.lang.Object var16 = var8.clone();
    org.jfree.chart.plot.CombinedRangeXYPlot var17 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var8);
    boolean var18 = var1.hasListener((java.util.EventListener)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
    org.jfree.chart.axis.TickUnitSource var2 = null;
    var1.setStandardTickUnits(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSmallestValue((-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("December 2014", "December 2014", "\uFFFD", "Sunday", "?series=1&amp;item=10");

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     java.lang.String var4 = var2.toString();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.TimeSeries var7 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var2, (org.jfree.data.time.RegularTimePeriod)var6);
//     var7.clear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "December 2014"+ "'", var4.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     java.lang.String var4 = var2.toString();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.TimeSeries var7 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var2, (org.jfree.data.time.RegularTimePeriod)var6);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var8 = var7.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "December 2014"+ "'", var4.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
// 
//   }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    java.lang.String var23 = var22.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "HorizontalAlignment.CENTER"+ "'", var23.equals("HorizontalAlignment.CENTER"));

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    var2.setPaint((java.awt.Paint)var6);
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var9.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    java.awt.Image var15 = var14.getBackgroundImage();
    java.awt.Color var18 = java.awt.Color.getColor("", (-1));
    java.awt.Color var21 = java.awt.Color.getColor("", (-1));
    boolean var22 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var18, (java.awt.Paint)var21);
    org.jfree.chart.block.BlockBorder var23 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var18);
    var14.setLabelPaint((java.awt.Paint)var18);
    var9.setBaseItemLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.util.GradientPaintTransformer var26 = var9.getGradientPaintTransformer();
    var2.setGradientPaintTransformer(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    float[] var4 = new float[] { 1.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var5 = var2.getColorComponents(var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    java.awt.Color var14 = java.awt.Color.getColor("", (-1));
    java.awt.Color var17 = java.awt.Color.getColor("", (-1));
    boolean var18 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var17);
    java.awt.Color var19 = var17.darker();
    var9.setBackgroundPaint((java.awt.Paint)var17);
    org.jfree.chart.plot.Plot var21 = var9.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    org.jfree.data.time.TimeSeries var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
    org.jfree.data.Range var26 = var23.findDomainBounds((org.jfree.data.xy.XYDataset)var25);
    boolean var27 = var21.equals((java.lang.Object)var23);
    var23.setBaseSeriesVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var31 = null;
    var23.setSeriesNegativeItemLabelPosition(1, var31);
    java.awt.Paint var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.setSeriesFillPaint((-457), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("\uFFFD", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.XYPlot var11 = var9.getXYPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     boolean var19 = var18.isOutlineVisible();
//     java.lang.String[] var22 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
//     var23.setLabelAngle(0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var23.equals(var26);
//     double var28 = var23.getFixedDimension();
//     java.awt.Shape var29 = var23.getLeftArrow();
//     java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
//     int var31 = var18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     boolean var32 = var18.isRangeCrosshairVisible();
//     double var33 = var18.getGap();
//     java.awt.Color var36 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var39 = java.awt.Color.getColor("", (-1));
//     boolean var40 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var36, (java.awt.Paint)var39);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var36);
//     var18.setDomainCrosshairPaint((java.awt.Paint)var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 5.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
// 
//   }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, 0.0d, 10.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var6.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Image var12 = var11.getBackgroundImage();
//     java.awt.Color var15 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var18 = java.awt.Color.getColor("", (-1));
//     boolean var19 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var15, (java.awt.Paint)var18);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     var11.setLabelPaint((java.awt.Paint)var15);
//     var6.setBaseItemLabelPaint((java.awt.Paint)var15);
//     double var23 = var6.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var25, (org.jfree.chart.urls.XYURLGenerator)var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     var30.removeAllSeries();
//     org.jfree.data.Range var32 = var28.findRangeBounds((org.jfree.data.xy.XYDataset)var30);
//     java.awt.Stroke var34 = var28.lookupSeriesStroke(1);
//     var6.setBaseOutlineStroke(var34);
//     java.awt.geom.RectangularShape var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     var3.paintBar(var4, var6, 0, 1, true, var39, var40);
//     org.jfree.data.general.PieDataset var43 = null;
//     org.jfree.chart.plot.RingPlot var44 = new org.jfree.chart.plot.RingPlot(var43);
//     java.awt.Image var45 = var44.getBackgroundImage();
//     java.awt.Color var48 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var51 = java.awt.Color.getColor("", (-1));
//     boolean var52 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var48, (java.awt.Paint)var51);
//     org.jfree.chart.block.BlockBorder var53 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var48);
//     var44.setLabelPaint((java.awt.Paint)var48);
//     org.jfree.chart.event.RendererChangeEvent var56 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var48, true);
//     var6.setSeriesFillPaint(100, (java.awt.Paint)var48);
//     
//     // Checks the contract:  equals-hashcode on var11 and var44
//     assertTrue("Contract failed: equals-hashcode on var11 and var44", var11.equals(var44) ? var11.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var11
//     assertTrue("Contract failed: equals-hashcode on var44 and var11", var44.equals(var11) ? var44.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var20 and var53
//     assertTrue("Contract failed: equals-hashcode on var20 and var53", var20.equals(var53) ? var20.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var20
//     assertTrue("Contract failed: equals-hashcode on var53 and var20", var53.equals(var20) ? var53.hashCode() == var20.hashCode() : true);
// 
//   }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = null;
//     org.jfree.data.time.TimeSeries var12 = null;
//     org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
//     var13.removeAllSeries();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
//     org.jfree.data.time.TimeSeries var17 = null;
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var17);
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.general.PieDataset var20 = null;
//     org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
//     int var22 = var21.getPieIndex();
//     java.lang.String var23 = var21.getNoDataMessage();
//     var18.addChangeListener((org.jfree.data.general.DatasetChangeListener)var21);
//     var16.startSeriesPass((org.jfree.data.xy.XYDataset)var18, 10, 10, (-1), 10, 1);
//     double var32 = var18.getDomainUpperBound(false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == Double.NaN);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.chart.axis.NumberAxis var1 = new org.jfree.chart.axis.NumberAxis("Sunday");

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var5 = java.awt.Color.getColor("", (-1));
//     boolean var6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var2, (java.awt.Paint)var5);
//     org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
//     java.awt.color.ColorSpace var8 = null;
//     float[] var12 = new float[] { (-1.0f), 1.0f, 0.0f};
//     float[] var13 = var2.getComponents(var8, var12);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     var18.setRangeGridlinesVisible(false);
//     java.awt.Paint var24 = var18.getRangeCrosshairPaint();
//     var18.setDomainGridlinesVisible(false);
//     org.jfree.chart.plot.PlotOrientation var27 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var18.setOrientation(var27);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, (-457));
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     boolean var19 = var18.isOutlineVisible();
//     org.jfree.data.time.TimeSeries var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var21);
//     boolean var23 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var22);
//     org.jfree.data.general.DatasetGroup var24 = var22.getGroup();
//     java.awt.Color var27 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var30 = java.awt.Color.getColor("", (-1));
//     boolean var31 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var27, (java.awt.Paint)var30);
//     org.jfree.chart.block.BlockBorder var32 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var27);
//     boolean var33 = var22.equals((java.lang.Object)var32);
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var37 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var35, (org.jfree.chart.urls.XYURLGenerator)var37);
//     var38.setItemLabelAnchorOffset(0.0d);
//     boolean var41 = var32.equals((java.lang.Object)var38);
//     java.util.Collection var42 = var38.getAnnotations();
//     org.jfree.chart.urls.XYURLGenerator var44 = var38.getSeriesURLGenerator((-1));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var18.setRenderer((-1), (org.jfree.chart.renderer.xy.XYItemRenderer)var38);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var44);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
    double var14 = var12.calculateRightOutset(1.0d);
    java.awt.geom.Rectangle2D var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var16 = var12.createOutsetRectangle(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 8.0d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setID("Pie Plot");
    var9.setMargin((-6.0d), 100.0d, 100.0d, (-6.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var21.setFixedRangeAxisSpace(var24, true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    java.lang.String var12 = var1.getPlotType();
    double var13 = var1.getStartAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Pie Plot"+ "'", var12.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 90.0d);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(1.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    var3.setMinimumFractionDigits(10);
    int var6 = var3.getMaximumFractionDigits();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 10);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    java.lang.String var4 = var3.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "CONTRACT"+ "'", var4.equals("CONTRACT"));

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    var1.setNoDataMessage("December 2014");
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    java.awt.Stroke var6 = var1.getSectionOutlineStroke((java.lang.Comparable)var5);
    org.jfree.chart.labels.PieToolTipGenerator var7 = null;
    var1.setToolTipGenerator(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var18.setRenderer(var19);
//     java.awt.Stroke var21 = var18.getDomainCrosshairStroke();
//     org.jfree.data.general.DatasetChangeEvent var22 = null;
//     var18.datasetChanged(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    var3.setParseIntegerOnly(false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setAutoPopulateSeriesPaint(false);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    int var13 = var12.getRangeAxisCount();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
    var12.zoomRangeAxes(100.0d, var15, var18);
    java.awt.Paint var20 = var12.getDomainMinorGridlinePaint();
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    int var23 = var22.getPieIndex();
    org.jfree.data.general.DatasetGroup var24 = var22.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYBarRenderer var26 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var26.setBaseCreateEntities(false, true);
    boolean var30 = var22.equals((java.lang.Object)true);
    java.awt.Stroke var31 = var22.getOutlineStroke();
    var12.setRangeZeroBaselineStroke(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    double var6 = var3.getFixedDimension();
    var3.setAutoRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Color var7 = java.awt.Color.getColor("", (-1));
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var7, (java.awt.Paint)var10);
    int var12 = var10.getAlpha();
    var1.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var10);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     java.lang.String[] var33 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("hi!", var33);
//     var34.setLabelAngle(0.0d);
//     java.lang.Object var37 = null;
//     boolean var38 = var34.equals(var37);
//     java.lang.String var39 = var34.getLabelURL();
//     org.jfree.chart.plot.Plot var40 = var34.getPlot();
//     var34.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Font var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     double var50 = var48.getOuterSeparatorExtension();
//     java.awt.Stroke var51 = null;
//     var48.setOutlineStroke(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, false);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     java.awt.RenderingHints var56 = var54.getRenderingHints();
//     java.awt.Color var59 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var62 = java.awt.Color.getColor("", (-1));
//     boolean var63 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var59, (java.awt.Paint)var62);
//     java.awt.Color var64 = var62.darker();
//     var54.setBackgroundPaint((java.awt.Paint)var62);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     int var68 = var67.getPieIndex();
//     org.jfree.data.general.DatasetGroup var69 = var67.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var71.setBaseCreateEntities(false, true);
//     boolean var75 = var67.equals((java.lang.Object)true);
//     java.awt.Stroke var76 = var67.getOutlineStroke();
//     var4.drawDomainLine(var11, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.chart.axis.ValueAxis)var34, var43, 10.0d, (java.awt.Paint)var62, var76);
//     org.jfree.chart.util.LogFormat var81 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     var81.setMinimumFractionDigits(10);
//     boolean var84 = var62.equals((java.lang.Object)10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var84 == false);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     var21.clearRangeMarkers();
//     boolean var23 = var21.getDrawSharedDomainAxis();
//     var21.setRangeZeroBaselineVisible(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    double var7 = var4.getItemLabelAnchorOffset();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    var4.setSeriesToolTipGenerator(1, var9);
    double var11 = var4.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
//     org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
//     org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
//     java.util.List var5 = null;
//     org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var1, var5, false);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    int var5 = var4.getPieIndex();
    java.lang.String var6 = var4.getNoDataMessage();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    java.lang.Number var8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     org.jfree.chart.labels.XYToolTipGenerator var13 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var15 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var13, (org.jfree.chart.urls.XYURLGenerator)var15);
//     org.jfree.data.time.TimeSeries var17 = null;
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var17);
//     var18.removeAllSeries();
//     org.jfree.data.Range var20 = var16.findRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     java.awt.Stroke var22 = var16.lookupSeriesStroke(1);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.axis.LogAxis var25 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var29 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var30 = var29.clone();
//     var25.setNumberFormatOverride((java.text.NumberFormat)var29);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var25.valueToJava2D(0.0d, var33, var34);
//     var25.pan(0.0d);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var25.java2DToValue(10.0d, var39, var40);
//     org.jfree.chart.plot.CombinedRangeXYPlot var42 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var25);
//     java.lang.String[] var45 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var46 = new org.jfree.chart.axis.SymbolAxis("hi!", var45);
//     var46.setLabelAngle(0.0d);
//     java.lang.Object var49 = null;
//     boolean var50 = var46.equals(var49);
//     java.lang.String var51 = var46.getLabelURL();
//     org.jfree.chart.plot.Plot var52 = var46.getPlot();
//     var46.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var55 = null;
//     java.awt.Font var58 = null;
//     org.jfree.data.general.PieDataset var59 = null;
//     org.jfree.chart.plot.RingPlot var60 = new org.jfree.chart.plot.RingPlot(var59);
//     java.awt.Image var61 = var60.getBackgroundImage();
//     double var62 = var60.getOuterSeparatorExtension();
//     java.awt.Stroke var63 = null;
//     var60.setOutlineStroke(var63);
//     org.jfree.chart.JFreeChart var66 = new org.jfree.chart.JFreeChart("hi!", var58, (org.jfree.chart.plot.Plot)var60, false);
//     java.awt.Paint var67 = var66.getBackgroundPaint();
//     java.awt.RenderingHints var68 = var66.getRenderingHints();
//     java.awt.Color var71 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var74 = java.awt.Color.getColor("", (-1));
//     boolean var75 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var71, (java.awt.Paint)var74);
//     java.awt.Color var76 = var74.darker();
//     var66.setBackgroundPaint((java.awt.Paint)var74);
//     org.jfree.data.general.PieDataset var78 = null;
//     org.jfree.chart.plot.RingPlot var79 = new org.jfree.chart.plot.RingPlot(var78);
//     int var80 = var79.getPieIndex();
//     org.jfree.data.general.DatasetGroup var81 = var79.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var83 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var83.setBaseCreateEntities(false, true);
//     boolean var87 = var79.equals((java.lang.Object)true);
//     java.awt.Stroke var88 = var79.getOutlineStroke();
//     var16.drawDomainLine(var23, (org.jfree.chart.plot.XYPlot)var42, (org.jfree.chart.axis.ValueAxis)var46, var55, 10.0d, (java.awt.Paint)var74, var88);
//     var1.setAxisLineStroke(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var62 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var80 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var87 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var1.setBaseCreateEntities(false, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var1.getNegativeItemLabelPositionFallback();
    org.jfree.chart.labels.XYSeriesLabelGenerator var6 = null;
    var1.setLegendItemToolTipGenerator(var6);
    org.jfree.chart.util.GradientPaintTransformer var8 = var1.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getShadowXOffset();
    org.jfree.chart.util.Rotation var4 = var1.getDirection();
    var1.setCircular(false, true);
    var1.setSectionDepth((-1.0d));
    double var10 = var1.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.14d);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var8 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var9 = var8.clone();
//     var4.setNumberFormatOverride((java.text.NumberFormat)var8);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var4.valueToJava2D(0.0d, var12, var13);
//     var4.pan(0.0d);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var4.java2DToValue(10.0d, var18, var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var4, var21);
//     org.jfree.data.Range var23 = var4.getDefaultAutoRange();
//     org.jfree.data.Range var25 = org.jfree.data.Range.shift(var23, 100.0d);
//     org.jfree.chart.block.LengthConstraintType var26 = null;
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var35 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var36 = var35.clone();
//     var31.setNumberFormatOverride((java.text.NumberFormat)var35);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var31.valueToJava2D(0.0d, var39, var40);
//     var31.pan(0.0d);
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var31.java2DToValue(10.0d, var45, var46);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var31, var48);
//     org.jfree.data.Range var50 = var31.getDefaultAutoRange();
//     org.jfree.data.Range var52 = org.jfree.data.Range.shift(var50, 100.0d);
//     org.jfree.chart.block.LengthConstraintType var53 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.block.RectangleConstraint var54 = new org.jfree.chart.block.RectangleConstraint((-6.0d), var25, var26, 0.0d, var50, var53);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     java.lang.String var4 = var2.toString();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var6 = var5.getYear();
//     org.jfree.data.time.TimeSeries var7 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var2, (org.jfree.data.time.RegularTimePeriod)var6);
//     int var8 = var2.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "December 2014"+ "'", var4.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 12);
// 
//   }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    java.lang.Class var1 = null;
    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("December 2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     boolean var9 = var4.getPlotLines();
//     java.awt.Shape var11 = var4.lookupLegendShape(100);
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     boolean var31 = var30.isOutlineVisible();
//     java.lang.String[] var34 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var35 = new org.jfree.chart.axis.SymbolAxis("hi!", var34);
//     var35.setLabelAngle(0.0d);
//     java.lang.Object var38 = null;
//     boolean var39 = var35.equals(var38);
//     double var40 = var35.getFixedDimension();
//     java.awt.Shape var41 = var35.getLeftArrow();
//     java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
//     int var43 = var30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     boolean var44 = var30.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     java.awt.geom.Point2D var48 = null;
//     var30.zoomRangeAxes((-6.0d), (-6.0d), var47, var48);
//     org.jfree.chart.entity.PlotEntity var51 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var30, "hi!");
//     java.lang.String var52 = var51.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "PlotEntity: tooltip = hi!"+ "'", var52.equals("PlotEntity: tooltip = hi!"));
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     var18.setRangeGridlinesVisible(false);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.RenderingSource var27 = null;
//     var18.select(0.0d, (-6.0d), var26, var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    java.awt.Color var9 = java.awt.Color.getColor("", (-1));
    boolean var10 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var6, (java.awt.Paint)var9);
    org.jfree.chart.block.BlockBorder var11 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var6);
    boolean var12 = var1.equals((java.lang.Object)var11);
    org.jfree.chart.labels.XYToolTipGenerator var14 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var16 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var14, (org.jfree.chart.urls.XYURLGenerator)var16);
    var17.setItemLabelAnchorOffset(0.0d);
    boolean var20 = var11.equals((java.lang.Object)var17);
    org.jfree.chart.urls.XYURLGenerator var21 = var17.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     boolean var25 = var21.getDrawSharedDomainAxis();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
// 
//   }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var0);
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var3 = var2.getYear();
//     long var4 = var3.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var3, (java.lang.Number)(-457));
//     org.jfree.data.time.TimeSeriesDataItem var7 = var1.addOrUpdate(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    java.lang.Object var8 = var7.clone();
    java.lang.String var10 = var7.format(0L);
    var3.setExponentFormat((java.text.NumberFormat)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "\uFFFD"+ "'", var10.equals("\uFFFD"));

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    int var5 = var4.getPieIndex();
    java.lang.String var6 = var4.getNoDataMessage();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    org.jfree.data.time.TimePeriodAnchor var8 = var1.getXPosition();
    java.lang.Number var9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1, (-1), (-457));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Pie Plot");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.DatasetGroup var3 = var1.getGroup();
    org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var18.setRenderer(var19);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.plot.CrosshairState var25 = null;
//     boolean var26 = var18.render(var21, var22, 1, var24, var25);
//     java.awt.Paint var27 = var18.getNoDataMessagePaint();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     double var22 = var3.getLowerMargin();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 0.05d);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    var1.removeAllSeries();
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    java.awt.Image var5 = var4.getBackgroundImage();
    double var6 = var4.getOuterSeparatorExtension();
    java.awt.Paint var7 = var4.getLabelBackgroundPaint();
    boolean var8 = var4.getSectionOutlinesVisible();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     java.awt.Paint var8 = var4.lookupLegendTextPaint(1);
//     org.jfree.chart.axis.LogAxis var10 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var14 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var15 = var14.clone();
//     var10.setNumberFormatOverride((java.text.NumberFormat)var14);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var10.valueToJava2D(0.0d, var18, var19);
//     var10.pan(0.0d);
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleEdge var25 = null;
//     double var26 = var10.java2DToValue(10.0d, var24, var25);
//     org.jfree.chart.plot.CombinedRangeXYPlot var27 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var10);
//     org.jfree.chart.renderer.xy.XYItemRenderer var28 = null;
//     var27.setRenderer(var28);
//     org.jfree.data.general.PieDataset var30 = null;
//     org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot(var30);
//     java.awt.Image var32 = var31.getBackgroundImage();
//     java.awt.Color var35 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var38 = java.awt.Color.getColor("", (-1));
//     boolean var39 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var35, (java.awt.Paint)var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
//     var31.setLabelPaint((java.awt.Paint)var35);
//     org.jfree.chart.util.RectangleInsets var42 = var31.getInsets();
//     var27.setAxisOffset(var42);
//     var4.setPlot((org.jfree.chart.plot.XYPlot)var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
// 
//   }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getRangeMarkers((-1), var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
// 
//   }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.LogAxis var5 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var9 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var10 = var9.clone();
//     var5.setNumberFormatOverride((java.text.NumberFormat)var9);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.util.RectangleEdge var14 = null;
//     double var15 = var5.valueToJava2D(0.0d, var13, var14);
//     var5.pan(0.0d);
//     java.awt.geom.Rectangle2D var19 = null;
//     org.jfree.chart.util.RectangleEdge var20 = null;
//     double var21 = var5.java2DToValue(10.0d, var19, var20);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var2, var3, (org.jfree.chart.axis.ValueAxis)var5, var22);
//     org.jfree.chart.util.RectangleEdge var25 = var23.getDomainAxisEdge(0);
//     java.lang.Comparable var26 = var23.getDomainCrosshairColumnKey();
//     org.jfree.chart.util.SortOrder var27 = var23.getRowRenderingOrder();
//     org.jfree.chart.event.RendererChangeEvent var28 = null;
//     var23.rendererChanged(var28);
//     org.jfree.chart.plot.IntervalMarker var33 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var34 = var33.getLabelOffsetType();
//     var33.setEndValue(0.0d);
//     java.awt.Paint var37 = var33.getLabelPaint();
//     org.jfree.chart.util.Layer var38 = null;
//     boolean var40 = var23.removeDomainMarker((-457), (org.jfree.chart.plot.Marker)var33, var38, true);
//     int var41 = var1.compareTo((java.lang.Object)var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    var3.setMinimumFractionDigits(10);
    int var6 = var3.getMinimumIntegerDigits();
    java.lang.String var8 = var3.format(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "\uFFFD"+ "'", var8.equals("\uFFFD"));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Paint var4 = var1.getLabelBackgroundPaint();
    var1.setNotify(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getPlotLines();
    java.awt.Shape var11 = var4.lookupLegendShape(100);
    java.awt.Font var13 = null;
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    java.awt.Image var16 = var15.getBackgroundImage();
    double var17 = var15.getOuterSeparatorExtension();
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", var13, (org.jfree.chart.plot.Plot)var15, false);
    java.awt.Paint var22 = var21.getBackgroundPaint();
    org.jfree.chart.entity.JFreeChartEntity var24 = new org.jfree.chart.entity.JFreeChartEntity(var11, var21, "December 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var12 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var10, (org.jfree.chart.urls.XYURLGenerator)var12);
    org.jfree.data.time.TimeSeries var14 = null;
    org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
    var15.removeAllSeries();
    org.jfree.data.Range var17 = var13.findRangeBounds((org.jfree.data.xy.XYDataset)var15);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.entity.TitleEntity var20 = new org.jfree.chart.entity.TitleEntity(var8, (org.jfree.chart.title.Title)var18, "");
    org.jfree.data.general.PieDataset var21 = null;
    org.jfree.chart.plot.RingPlot var22 = new org.jfree.chart.plot.RingPlot(var21);
    java.awt.Image var23 = var22.getBackgroundImage();
    double var24 = var22.getOuterSeparatorExtension();
    java.awt.Color var28 = java.awt.Color.getColor("", (-1));
    java.awt.Color var31 = java.awt.Color.getColor("", (-1));
    boolean var32 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var28, (java.awt.Paint)var31);
    int var33 = var31.getAlpha();
    var22.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var31);
    var18.setBackgroundPaint((java.awt.Paint)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 255);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
    java.lang.Object var4 = var3.clone();
    java.lang.String var6 = var3.format(0L);
    int var7 = var3.getMinimumFractionDigits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "\uFFFD"+ "'", var6.equals("\uFFFD"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, (-1.0d), 10.0d, var3);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    org.jfree.data.general.PieDataset var4 = var1.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.RectangleInsets var22 = var19.getPadding();
    int var23 = var19.getSubtitleCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    org.jfree.chart.urls.PieURLGenerator var4 = null;
    var1.setURLGenerator(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Pie Plot");
    var1.setVisible(true);

  }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter(0.0d, 0.0d, 10.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var6 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var6.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var10 = null;
//     org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
//     java.awt.Image var12 = var11.getBackgroundImage();
//     java.awt.Color var15 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var18 = java.awt.Color.getColor("", (-1));
//     boolean var19 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var15, (java.awt.Paint)var18);
//     org.jfree.chart.block.BlockBorder var20 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var15);
//     var11.setLabelPaint((java.awt.Paint)var15);
//     var6.setBaseItemLabelPaint((java.awt.Paint)var15);
//     double var23 = var6.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var25, (org.jfree.chart.urls.XYURLGenerator)var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     var30.removeAllSeries();
//     org.jfree.data.Range var32 = var28.findRangeBounds((org.jfree.data.xy.XYDataset)var30);
//     java.awt.Stroke var34 = var28.lookupSeriesStroke(1);
//     var6.setBaseOutlineStroke(var34);
//     java.awt.geom.RectangularShape var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     var3.paintBar(var4, var6, 0, 1, true, var39, var40);
//     org.jfree.chart.labels.XYToolTipGenerator var43 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var45 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var43, (org.jfree.chart.urls.XYURLGenerator)var45);
//     org.jfree.data.time.TimeSeries var47 = null;
//     org.jfree.data.time.TimeSeriesCollection var48 = new org.jfree.data.time.TimeSeriesCollection(var47);
//     var48.removeAllSeries();
//     org.jfree.data.Range var50 = var46.findRangeBounds((org.jfree.data.xy.XYDataset)var48);
//     org.jfree.chart.title.LegendTitle var51 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var46);
//     java.awt.Font var53 = null;
//     org.jfree.data.general.PieDataset var54 = null;
//     org.jfree.chart.plot.RingPlot var55 = new org.jfree.chart.plot.RingPlot(var54);
//     java.awt.Image var56 = var55.getBackgroundImage();
//     double var57 = var55.getOuterSeparatorExtension();
//     java.awt.Stroke var58 = null;
//     var55.setOutlineStroke(var58);
//     org.jfree.chart.JFreeChart var61 = new org.jfree.chart.JFreeChart("hi!", var53, (org.jfree.chart.plot.Plot)var55, false);
//     java.awt.Paint var62 = var61.getBackgroundPaint();
//     var51.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var61);
//     var61.setBackgroundImageAlignment(0);
//     org.jfree.chart.event.ChartProgressEvent var68 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)true, var61, (-1), 100);
//     
//     // Checks the contract:  equals-hashcode on var27 and var45
//     assertTrue("Contract failed: equals-hashcode on var27 and var45", var27.equals(var45) ? var27.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var27
//     assertTrue("Contract failed: equals-hashcode on var45 and var27", var45.equals(var27) ? var45.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var48
//     assertTrue("Contract failed: equals-hashcode on var30 and var48", var30.equals(var48) ? var30.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var30
//     assertTrue("Contract failed: equals-hashcode on var48 and var30", var48.equals(var30) ? var48.hashCode() == var30.hashCode() : true);
// 
//   }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     boolean var9 = var4.getPlotLines();
//     java.awt.Shape var11 = var4.lookupLegendShape(100);
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     boolean var31 = var30.isOutlineVisible();
//     java.lang.String[] var34 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var35 = new org.jfree.chart.axis.SymbolAxis("hi!", var34);
//     var35.setLabelAngle(0.0d);
//     java.lang.Object var38 = null;
//     boolean var39 = var35.equals(var38);
//     double var40 = var35.getFixedDimension();
//     java.awt.Shape var41 = var35.getLeftArrow();
//     java.lang.Object var42 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var35);
//     int var43 = var30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var35);
//     boolean var44 = var30.isRangeCrosshairVisible();
//     org.jfree.chart.plot.PlotRenderingInfo var47 = null;
//     java.awt.geom.Point2D var48 = null;
//     var30.zoomRangeAxes((-6.0d), (-6.0d), var47, var48);
//     org.jfree.chart.entity.PlotEntity var51 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var30, "hi!");
//     java.lang.String var52 = var51.getShapeType();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + "rect"+ "'", var52.equals("rect"));
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Color var7 = java.awt.Color.getColor("", (-1));
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var7, (java.awt.Paint)var10);
    int var12 = var10.getAlpha();
    var1.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var10);
    var1.clearSectionOutlinePaints(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var1 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = null;
//     org.jfree.chart.axis.LogAxis var4 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var8 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var9 = var8.clone();
//     var4.setNumberFormatOverride((java.text.NumberFormat)var8);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.chart.util.RectangleEdge var13 = null;
//     double var14 = var4.valueToJava2D(0.0d, var12, var13);
//     var4.pan(0.0d);
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.util.RectangleEdge var19 = null;
//     double var20 = var4.java2DToValue(10.0d, var18, var19);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var1, var2, (org.jfree.chart.axis.ValueAxis)var4, var21);
//     org.jfree.data.Range var23 = var4.getDefaultAutoRange();
//     org.jfree.data.Range var25 = org.jfree.data.Range.shift(var23, 100.0d);
//     org.jfree.chart.block.LengthConstraintType var26 = null;
//     org.jfree.data.category.CategoryDataset var28 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = null;
//     org.jfree.chart.axis.LogAxis var31 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var35 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var36 = var35.clone();
//     var31.setNumberFormatOverride((java.text.NumberFormat)var35);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var31.valueToJava2D(0.0d, var39, var40);
//     var31.pan(0.0d);
//     java.awt.geom.Rectangle2D var45 = null;
//     org.jfree.chart.util.RectangleEdge var46 = null;
//     double var47 = var31.java2DToValue(10.0d, var45, var46);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var28, var29, (org.jfree.chart.axis.ValueAxis)var31, var48);
//     org.jfree.data.Range var50 = var31.getDefaultAutoRange();
//     org.jfree.data.Range var53 = org.jfree.data.Range.shift(var50, 0.0d, false);
//     org.jfree.chart.block.LengthConstraintType var54 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.block.RectangleConstraint var55 = new org.jfree.chart.block.RectangleConstraint(0.0d, var25, var26, 1.0d, var50, var54);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    java.awt.Color var14 = java.awt.Color.getColor("", (-1));
    java.awt.Color var17 = java.awt.Color.getColor("", (-1));
    boolean var18 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var17);
    java.awt.Color var19 = var17.darker();
    var9.setBackgroundPaint((java.awt.Paint)var17);
    org.jfree.chart.plot.Plot var21 = var9.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    org.jfree.data.time.TimeSeries var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
    org.jfree.data.Range var26 = var23.findDomainBounds((org.jfree.data.xy.XYDataset)var25);
    boolean var27 = var21.equals((java.lang.Object)var23);
    var23.setBaseSeriesVisible(false);
    org.jfree.chart.urls.XYURLGenerator var31 = var23.getSeriesURLGenerator(0);
    org.jfree.chart.util.GradientPaintTransformer var32 = var23.getGradientPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.data.Range var22 = var3.getDefaultAutoRange();
//     org.jfree.data.Range var25 = org.jfree.data.Range.shift(var22, 0.0d, false);
//     double var27 = var25.constrain(10.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1.0d);
// 
//   }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, 1.0d, 0.0d, 1.0d);
    double var5 = var4.getTop();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1.0d);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     java.lang.String[] var33 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("hi!", var33);
//     var34.setLabelAngle(0.0d);
//     java.lang.Object var37 = null;
//     boolean var38 = var34.equals(var37);
//     java.lang.String var39 = var34.getLabelURL();
//     org.jfree.chart.plot.Plot var40 = var34.getPlot();
//     var34.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Font var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     double var50 = var48.getOuterSeparatorExtension();
//     java.awt.Stroke var51 = null;
//     var48.setOutlineStroke(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, false);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     java.awt.RenderingHints var56 = var54.getRenderingHints();
//     java.awt.Color var59 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var62 = java.awt.Color.getColor("", (-1));
//     boolean var63 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var59, (java.awt.Paint)var62);
//     java.awt.Color var64 = var62.darker();
//     var54.setBackgroundPaint((java.awt.Paint)var62);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     int var68 = var67.getPieIndex();
//     org.jfree.data.general.DatasetGroup var69 = var67.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var71.setBaseCreateEntities(false, true);
//     boolean var75 = var67.equals((java.lang.Object)true);
//     java.awt.Stroke var76 = var67.getOutlineStroke();
//     var4.drawDomainLine(var11, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.chart.axis.ValueAxis)var34, var43, 10.0d, (java.awt.Paint)var62, var76);
//     org.jfree.chart.urls.StandardXYURLGenerator var79 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.data.xy.XYDataset var80 = null;
//     java.lang.String var83 = var79.generateURL(var80, 1, 10);
//     var4.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var79);
//     
//     // Checks the contract:  equals-hashcode on var3 and var79
//     assertTrue("Contract failed: equals-hashcode on var3 and var79", var3.equals(var79) ? var3.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var3
//     assertTrue("Contract failed: equals-hashcode on var79 and var3", var79.equals(var3) ? var79.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    java.lang.String var12 = var1.getPlotType();
    var1.setIgnoreZeroValues(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Pie Plot"+ "'", var12.equals("Pie Plot"));

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Color var7 = java.awt.Color.getColor("", (-1));
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var7, (java.awt.Paint)var10);
    int var12 = var10.getAlpha();
    var1.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var10);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    java.awt.Image var16 = var15.getBackgroundImage();
    double var17 = var15.getOuterSeparatorExtension();
    java.awt.Paint var18 = var15.getLabelBackgroundPaint();
    boolean var19 = var15.getSectionOutlinesVisible();
    var1.setParent((org.jfree.chart.plot.Plot)var15);
    var1.setLabelLinkMargin(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     java.awt.color.ColorSpace var18 = null;
//     float[] var19 = new float[] { };
//     float[] var20 = var10.getComponents(var18, var19);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setID("Pie Plot");
    org.jfree.chart.event.RendererChangeEvent var25 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var9);
    java.awt.Paint var26 = var9.getItemPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    org.jfree.chart.util.GradientPaintTransformer var2 = var1.getGradientPaintTransformer();
    var1.setShadowVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     double var18 = var1.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var22 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var20, (org.jfree.chart.urls.XYURLGenerator)var22);
//     org.jfree.data.time.TimeSeries var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
//     var25.removeAllSeries();
//     org.jfree.data.Range var27 = var23.findRangeBounds((org.jfree.data.xy.XYDataset)var25);
//     java.awt.Stroke var29 = var23.lookupSeriesStroke(1);
//     var1.setBaseOutlineStroke(var29);
//     org.jfree.data.time.TimeSeries var31 = null;
//     org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var31);
//     int var34 = var32.indexOf((java.lang.Comparable)100L);
//     org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var32);
//     org.jfree.data.Range var36 = var1.findDomainBounds((org.jfree.data.xy.XYDataset)var32);
//     
//     // Checks the contract:  equals-hashcode on var25 and var32
//     assertTrue("Contract failed: equals-hashcode on var25 and var32", var25.equals(var32) ? var25.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var25
//     assertTrue("Contract failed: equals-hashcode on var32 and var25", var32.equals(var25) ? var32.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getPlotLines();
    org.jfree.chart.labels.XYToolTipGenerator var11 = null;
    var4.setSeriesToolTipGenerator(10, var11, true);
    java.lang.String[] var17 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var18 = new org.jfree.chart.axis.SymbolAxis("hi!", var17);
    var18.setLabelAngle(0.0d);
    java.lang.Object var21 = null;
    boolean var22 = var18.equals(var21);
    java.lang.String var23 = var18.getLabelURL();
    org.jfree.chart.plot.Plot var24 = var18.getPlot();
    var18.setMinorTickMarkOutsideLength(0.0f);
    java.awt.Font var31 = null;
    org.jfree.chart.axis.MarkerAxisBand var32 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var18, (-1.0d), 0.0d, 0.0d, 1.0d, var31);
    java.lang.String[] var39 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var40 = new org.jfree.chart.axis.SymbolAxis("hi!", var39);
    var40.setLabelAngle(0.0d);
    java.lang.Object var43 = null;
    boolean var44 = var40.equals(var43);
    java.awt.Shape var45 = var40.getRightArrow();
    java.awt.Font var46 = var40.getLabelFont();
    org.jfree.chart.axis.MarkerAxisBand var47 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var18, 1.0d, 0.0d, 100.0d, (-6.0d), var46);
    var4.setLegendTextFont(100, var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.jfree.data.time.TimeSeries var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset)var1);
    org.jfree.data.general.PieDataset var3 = null;
    org.jfree.chart.plot.RingPlot var4 = new org.jfree.chart.plot.RingPlot(var3);
    int var5 = var4.getPieIndex();
    java.lang.String var6 = var4.getNoDataMessage();
    var1.addChangeListener((org.jfree.data.general.DatasetChangeListener)var4);
    java.lang.Object var8 = null;
    boolean var9 = var4.equals(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    int var2 = var1.getPieIndex();
    java.lang.String var3 = var1.getNoDataMessage();
    org.jfree.chart.labels.XYToolTipGenerator var5 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var7 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var5, (org.jfree.chart.urls.XYURLGenerator)var7);
    var8.setItemLabelAnchorOffset(0.0d);
    double var11 = var8.getItemLabelAnchorOffset();
    org.jfree.chart.labels.XYToolTipGenerator var13 = null;
    var8.setSeriesToolTipGenerator(1, var13);
    java.awt.Paint var15 = var8.getBasePaint();
    var1.setBackgroundPaint(var15);
    org.jfree.data.general.PieDataset var17 = null;
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot(var17);
    java.awt.Image var19 = var18.getBackgroundImage();
    java.awt.Color var22 = java.awt.Color.getColor("", (-1));
    java.awt.Color var25 = java.awt.Color.getColor("", (-1));
    boolean var26 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var22, (java.awt.Paint)var25);
    org.jfree.chart.block.BlockBorder var27 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var22);
    var18.setLabelPaint((java.awt.Paint)var22);
    org.jfree.chart.event.RendererChangeEvent var30 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var22, true);
    var1.setLabelShadowPaint((java.awt.Paint)var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Font var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Image var14 = var13.getBackgroundImage();
//     double var15 = var13.getOuterSeparatorExtension();
//     java.awt.Stroke var16 = null;
//     var13.setOutlineStroke(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
//     var9.setID("Pie Plot");
//     org.jfree.chart.event.RendererChangeEvent var25 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var9);
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var29 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var27, (org.jfree.chart.urls.XYURLGenerator)var29);
//     var30.setItemLabelAnchorOffset(0.0d);
//     double var33 = var30.getItemLabelAnchorOffset();
//     org.jfree.chart.labels.XYToolTipGenerator var35 = null;
//     var30.setSeriesToolTipGenerator(1, var35);
//     org.jfree.chart.labels.XYItemLabelGenerator var40 = var30.getItemLabelGenerator(0, 100, true);
//     org.jfree.data.general.PieDataset var41 = null;
//     org.jfree.chart.plot.RingPlot var42 = new org.jfree.chart.plot.RingPlot(var41);
//     java.awt.Image var43 = var42.getBackgroundImage();
//     double var44 = var42.getOuterSeparatorExtension();
//     java.awt.Paint var45 = var42.getLabelBackgroundPaint();
//     var30.setBasePaint(var45);
//     var9.setItemPaint(var45);
//     
//     // Checks the contract:  equals-hashcode on var3 and var29
//     assertTrue("Contract failed: equals-hashcode on var3 and var29", var3.equals(var29) ? var3.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var3
//     assertTrue("Contract failed: equals-hashcode on var29 and var3", var29.equals(var3) ? var29.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var4 and var30
//     assertTrue("Contract failed: equals-hashcode on var4 and var30", var4.equals(var30) ? var4.hashCode() == var30.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var30 and var4
//     assertTrue("Contract failed: equals-hashcode on var30 and var4", var30.equals(var4) ? var30.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    java.lang.Boolean var8 = var4.getSeriesVisibleInLegend((-457));
    java.awt.Color var11 = java.awt.Color.getColor("", (-1));
    java.awt.Color var14 = java.awt.Color.getColor("", (-1));
    boolean var15 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var11, (java.awt.Paint)var14);
    org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var11);
    var4.setBaseFillPaint((java.awt.Paint)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    org.jfree.chart.title.LegendTitle var10 = var9.getLegend();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    java.awt.Stroke var12 = var9.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-6.0d), 100.0d);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    java.awt.Color var3 = java.awt.Color.getColor("", (-1));
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    boolean var7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var3, (java.awt.Paint)var6);
    java.awt.Color var8 = var6.darker();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var6);
    java.awt.Paint var10 = var9.getLinePaint();
    org.jfree.data.general.PieDataset var11 = null;
    org.jfree.chart.plot.RingPlot var12 = new org.jfree.chart.plot.RingPlot(var11);
    java.awt.Image var13 = var12.getBackgroundImage();
    java.awt.Color var16 = java.awt.Color.getColor("", (-1));
    java.awt.Color var19 = java.awt.Color.getColor("", (-1));
    boolean var20 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var16, (java.awt.Paint)var19);
    org.jfree.chart.block.BlockBorder var21 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var16);
    var12.setLabelPaint((java.awt.Paint)var16);
    var9.setLabelPaint((java.awt.Paint)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    java.awt.Paint var8 = var4.lookupLegendTextPaint(1);
    boolean var9 = var4.getPlotLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    java.awt.Image var6 = var5.getBackgroundImage();
    java.awt.Color var9 = java.awt.Color.getColor("", (-1));
    java.awt.Color var12 = java.awt.Color.getColor("", (-1));
    boolean var13 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var9, (java.awt.Paint)var12);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    var5.setLabelPaint((java.awt.Paint)var9);
    org.jfree.chart.util.RectangleInsets var16 = var5.getInsets();
    org.jfree.data.general.PieDataset var17 = var5.getDataset();
    double var18 = var5.getShadowXOffset();
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var5);
    var5.setMinimumArcAngleToDraw(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4.0d);

  }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Sunday", var1, (-1.0f), 100.0f, var4, 0.0d, 10.0f, 100.0f);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     boolean var9 = var4.getPlotLines();
//     java.awt.Shape var11 = var4.lookupLegendShape(100);
//     java.lang.String[] var14 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var15 = new org.jfree.chart.axis.SymbolAxis("hi!", var14);
//     var15.setLabelAngle(0.0d);
//     java.lang.Object var18 = null;
//     boolean var19 = var15.equals(var18);
//     java.awt.Shape var20 = var15.getRightArrow();
//     org.jfree.chart.labels.XYToolTipGenerator var22 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var22, (org.jfree.chart.urls.XYURLGenerator)var24);
//     org.jfree.data.time.TimeSeries var26 = null;
//     org.jfree.data.time.TimeSeriesCollection var27 = new org.jfree.data.time.TimeSeriesCollection(var26);
//     var27.removeAllSeries();
//     org.jfree.data.Range var29 = var25.findRangeBounds((org.jfree.data.xy.XYDataset)var27);
//     org.jfree.chart.title.LegendTitle var30 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var25);
//     org.jfree.chart.entity.TitleEntity var32 = new org.jfree.chart.entity.TitleEntity(var20, (org.jfree.chart.title.Title)var30, "");
//     org.jfree.chart.util.RectangleAnchor var33 = null;
//     var30.setLegendItemGraphicLocation(var33);
//     org.jfree.chart.entity.TitleEntity var37 = new org.jfree.chart.entity.TitleEntity(var11, (org.jfree.chart.title.Title)var30, "PlotEntity: tooltip = hi!", "");
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test160() {}
//   public void test160() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     java.awt.Paint var22 = var18.getRangeGridlinePaint();
//     org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var28 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var29 = var28.clone();
//     var24.setNumberFormatOverride((java.text.NumberFormat)var28);
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.util.RectangleEdge var33 = null;
//     double var34 = var24.valueToJava2D(0.0d, var32, var33);
//     var24.pan(0.0d);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var24.java2DToValue(10.0d, var38, var39);
//     int var41 = var18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-1));
// 
//   }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    boolean var6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var2, (java.awt.Paint)var5);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    boolean var9 = var7.equals((java.lang.Object)(byte)10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("December 2014");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.UnknownKeyException: December 2014"+ "'", var2.equals("org.jfree.data.UnknownKeyException: December 2014"));

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    double var7 = var4.getItemLabelAnchorOffset();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    var4.setSeriesToolTipGenerator(1, var9);
    org.jfree.chart.labels.XYItemLabelGenerator var14 = var4.getItemLabelGenerator(0, 100, true);
    org.jfree.data.general.PieDataset var15 = null;
    org.jfree.chart.plot.RingPlot var16 = new org.jfree.chart.plot.RingPlot(var15);
    java.awt.Image var17 = var16.getBackgroundImage();
    double var18 = var16.getOuterSeparatorExtension();
    java.awt.Paint var19 = var16.getLabelBackgroundPaint();
    var4.setBasePaint(var19);
    org.jfree.chart.labels.ItemLabelPosition var21 = var4.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    boolean var9 = var4.getAutoPopulateSeriesOutlinePaint();
    java.awt.Paint var11 = var4.getSeriesItemLabelPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setID("Pie Plot");
    boolean var25 = var9.isVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 1.0d);
    double var3 = var2.getHeight();
    org.jfree.chart.block.RectangleConstraint var5 = var2.toFixedWidth(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var18.setRenderer(var19);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     org.jfree.chart.plot.CrosshairState var25 = null;
//     boolean var26 = var18.render(var21, var22, 1, var24, var25);
//     org.jfree.chart.axis.AxisLocation var28 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var18.setDomainAxisLocation(0, var28);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     double var18 = var1.getMargin();
//     org.jfree.chart.labels.XYToolTipGenerator var20 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var22 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var20, (org.jfree.chart.urls.XYURLGenerator)var22);
//     org.jfree.data.time.TimeSeries var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
//     var25.removeAllSeries();
//     org.jfree.data.Range var27 = var23.findRangeBounds((org.jfree.data.xy.XYDataset)var25);
//     java.awt.Stroke var29 = var23.lookupSeriesStroke(1);
//     var1.setBaseOutlineStroke(var29);
//     org.jfree.data.general.PieDataset var31 = null;
//     org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
//     java.awt.Image var33 = var32.getBackgroundImage();
//     java.awt.Color var36 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var39 = java.awt.Color.getColor("", (-1));
//     boolean var40 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var36, (java.awt.Paint)var39);
//     org.jfree.chart.block.BlockBorder var41 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var36);
//     var32.setLabelPaint((java.awt.Paint)var36);
//     org.jfree.chart.event.RendererChangeEvent var44 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var36, true);
//     var1.setBaseLegendTextPaint((java.awt.Paint)var36);
//     
//     // Checks the contract:  equals-hashcode on var6 and var32
//     assertTrue("Contract failed: equals-hashcode on var6 and var32", var6.equals(var32) ? var6.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var6
//     assertTrue("Contract failed: equals-hashcode on var32 and var6", var32.equals(var6) ? var32.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var41
//     assertTrue("Contract failed: equals-hashcode on var15 and var41", var15.equals(var41) ? var15.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var15
//     assertTrue("Contract failed: equals-hashcode on var41 and var15", var41.equals(var15) ? var41.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    boolean var9 = var4.getAutoPopulateSeriesOutlinePaint();
    org.jfree.chart.labels.XYSeriesLabelGenerator var10 = var4.getLegendItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    int var2 = var1.getPieIndex();
    org.jfree.data.general.DatasetGroup var3 = var1.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYBarRenderer var5 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var5.setBaseCreateEntities(false, true);
    boolean var9 = var1.equals((java.lang.Object)true);
    java.awt.Stroke var10 = var1.getOutlineStroke();
    org.jfree.chart.plot.PieLabelLinkStyle var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelLinkStyle(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    java.awt.Color var3 = java.awt.Color.getColor("", (-1));
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    boolean var7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var3, (java.awt.Paint)var6);
    java.awt.Color var8 = var6.darker();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var6);
    org.jfree.data.time.TimeSeries var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var10);
    boolean var12 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var11);
    org.jfree.data.general.DatasetGroup var13 = var11.getGroup();
    java.lang.String[] var16 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var17 = new org.jfree.chart.axis.SymbolAxis("hi!", var16);
    var17.setLabelAngle(0.0d);
    java.lang.Object var20 = null;
    boolean var21 = var17.equals(var20);
    java.lang.String var22 = var17.getLabelURL();
    org.jfree.chart.plot.Plot var23 = var17.getPlot();
    var17.setMinorTickMarkOutsideLength(0.0f);
    java.awt.Font var30 = null;
    org.jfree.chart.axis.MarkerAxisBand var31 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var17, (-1.0d), 0.0d, 0.0d, 1.0d, var30);
    boolean var32 = var17.isGridBandsVisible();
    java.lang.String[] var35 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var36 = new org.jfree.chart.axis.SymbolAxis("hi!", var35);
    var36.setLabelAngle(0.0d);
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    java.lang.String var41 = var36.getLabelURL();
    org.jfree.chart.plot.Plot var42 = var36.getPlot();
    var36.setMinorTickMarkOutsideLength(0.0f);
    java.awt.Font var49 = null;
    org.jfree.chart.axis.MarkerAxisBand var50 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var36, (-1.0d), 0.0d, 0.0d, 1.0d, var49);
    boolean var51 = var36.isGridBandsVisible();
    var36.setTickMarkOutsideLength(1.0f);
    org.jfree.chart.renderer.xy.XYBarRenderer var55 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var55.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var59 = null;
    org.jfree.chart.plot.RingPlot var60 = new org.jfree.chart.plot.RingPlot(var59);
    java.awt.Image var61 = var60.getBackgroundImage();
    java.awt.Color var64 = java.awt.Color.getColor("", (-1));
    java.awt.Color var67 = java.awt.Color.getColor("", (-1));
    boolean var68 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var64, (java.awt.Paint)var67);
    org.jfree.chart.block.BlockBorder var69 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var64);
    var60.setLabelPaint((java.awt.Paint)var64);
    var55.setBaseItemLabelPaint((java.awt.Paint)var64);
    double var72 = var55.getMargin();
    org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var11, (org.jfree.chart.axis.ValueAxis)var17, (org.jfree.chart.axis.ValueAxis)var36, (org.jfree.chart.renderer.xy.XYItemRenderer)var55);
    var9.setDataset((org.jfree.data.general.Dataset)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.0d);

  }

  public void test172() {}
//   public void test172() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.data.general.PieDataset var2 = null;
//     org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
//     java.awt.Image var4 = var3.getBackgroundImage();
//     double var5 = var3.getOuterSeparatorExtension();
//     java.awt.Stroke var6 = null;
//     var3.setOutlineStroke(var6);
//     org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
//     org.jfree.chart.title.LegendTitle var10 = var9.getLegend();
//     int var11 = var9.getSubtitleCount();
//     org.jfree.chart.event.TitleChangeEvent var12 = null;
//     var9.titleChanged(var12);
// 
//   }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var2);
    org.jfree.data.time.TimeSeriesDataItem var4 = var1.getDataItem((org.jfree.data.time.RegularTimePeriod)var2);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
    var1.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)2014L, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.String[] var27 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var28 = new org.jfree.chart.axis.SymbolAxis("hi!", var27);
//     var28.setLabelAngle(0.0d);
//     java.lang.Object var31 = null;
//     boolean var32 = var28.equals(var31);
//     java.lang.String var33 = var28.getLabelURL();
//     org.jfree.chart.plot.Plot var34 = var28.getPlot();
//     var28.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.Font var41 = null;
//     org.jfree.chart.axis.MarkerAxisBand var42 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var28, (-1.0d), 0.0d, 0.0d, 1.0d, var41);
//     boolean var43 = var28.isGridBandsVisible();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var21.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis)var28, false);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == true);
// 
//   }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     org.jfree.chart.util.SortOrder var25 = var21.getRowRenderingOrder();
//     org.jfree.chart.event.RendererChangeEvent var26 = null;
//     var21.rendererChanged(var26);
//     org.jfree.chart.plot.IntervalMarker var31 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var32 = var31.getLabelOffsetType();
//     var31.setEndValue(0.0d);
//     java.awt.Paint var35 = var31.getLabelPaint();
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var38 = var21.removeDomainMarker((-457), (org.jfree.chart.plot.Marker)var31, var36, true);
//     org.jfree.chart.axis.CategoryAxis var40 = var21.getDomainAxisForDataset(10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
// 
//   }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    java.awt.Color var3 = java.awt.Color.getColor("", (-1));
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    boolean var7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var3, (java.awt.Paint)var6);
    java.awt.Color var8 = var6.darker();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var6);
    java.awt.Stroke var10 = var9.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
//     java.awt.Image var2 = var1.getBackgroundImage();
//     java.awt.Color var5 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var8 = java.awt.Color.getColor("", (-1));
//     boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
//     org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
//     var1.setLabelPaint((java.awt.Paint)var5);
//     org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
//     org.jfree.data.general.PieDataset var13 = var1.getDataset();
//     org.jfree.chart.plot.DrawingSupplier var14 = null;
//     var1.setDrawingSupplier(var14, true);
//     var1.setBackgroundImageAlignment(100);
//     org.jfree.data.general.PieDataset var19 = null;
//     org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
//     java.awt.Image var21 = var20.getBackgroundImage();
//     java.awt.Color var24 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var27 = java.awt.Color.getColor("", (-1));
//     boolean var28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var24, (java.awt.Paint)var27);
//     org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
//     var20.setLabelPaint((java.awt.Paint)var24);
//     org.jfree.chart.util.RectangleInsets var31 = var20.getInsets();
//     double var33 = var31.trimWidth(10.0d);
//     boolean var34 = var1.equals((java.lang.Object)10.0d);
//     
//     // Checks the contract:  equals-hashcode on var10 and var29
//     assertTrue("Contract failed: equals-hashcode on var10 and var29", var10.equals(var29) ? var10.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var10
//     assertTrue("Contract failed: equals-hashcode on var29 and var10", var29.equals(var10) ? var29.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.RingPlot var11 = new org.jfree.chart.plot.RingPlot(var10);
    java.awt.Image var12 = var11.getBackgroundImage();
    java.awt.Stroke var14 = var11.getSectionOutlineStroke((java.lang.Comparable)100.0d);
    org.jfree.chart.urls.PieURLGenerator var15 = null;
    var11.setLegendLabelURLGenerator(var15);
    org.jfree.chart.entity.PlotEntity var19 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var11, "", "\uFFFD");
    org.jfree.chart.util.RectangleInsets var20 = var11.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test179() {}
//   public void test179() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     java.awt.Shape var1 = null;
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var1, 1.0d, 0.0f, 1.0f);
// 
//   }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("December 2014", var1);
// 
//   }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    java.awt.Color var3 = java.awt.Color.getColor("", (-1));
    java.awt.Color var6 = java.awt.Color.getColor("", (-1));
    boolean var7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var3, (java.awt.Paint)var6);
    java.awt.Color var8 = var6.darker();
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var6);
    int var10 = var9.getSeriesIndex();
    java.lang.String[] var13 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var14 = new org.jfree.chart.axis.SymbolAxis("hi!", var13);
    var14.setLabelAngle(0.0d);
    java.lang.Object var17 = null;
    boolean var18 = var14.equals(var17);
    java.lang.String var19 = var14.getLabelURL();
    org.jfree.chart.plot.Plot var20 = var14.getPlot();
    var14.setMinorTickMarkOutsideLength(0.0f);
    java.awt.Font var27 = null;
    org.jfree.chart.axis.MarkerAxisBand var28 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var14, (-1.0d), 0.0d, 0.0d, 1.0d, var27);
    java.lang.String[] var35 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var36 = new org.jfree.chart.axis.SymbolAxis("hi!", var35);
    var36.setLabelAngle(0.0d);
    java.lang.Object var39 = null;
    boolean var40 = var36.equals(var39);
    java.awt.Shape var41 = var36.getRightArrow();
    java.awt.Font var42 = var36.getLabelFont();
    org.jfree.chart.axis.MarkerAxisBand var43 = new org.jfree.chart.axis.MarkerAxisBand((org.jfree.chart.axis.NumberAxis)var14, 1.0d, 0.0d, 100.0d, (-6.0d), var42);
    var9.setLabelFont(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor(10);

  }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }
// 
// 
//     java.lang.Class var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var1);
//     java.lang.String var3 = var1.toString();
//     java.util.Date var4 = var1.getStart();
//     java.util.TimeZone var5 = null;
//     org.jfree.data.time.RegularTimePeriod var6 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var4, var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + "December 2014"+ "'", var3.equals("December 2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
// 
//   }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getPlotLines();
    java.awt.Shape var11 = var4.lookupLegendShape(100);
    java.awt.Stroke var15 = var4.getItemStroke((-457), (-1), true);
    var4.setAutoPopulateSeriesPaint(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var4.setLegendItemLabelGenerator(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    boolean var2 = var1.isDrawBarOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.data.Range var22 = var3.getDefaultAutoRange();
//     org.jfree.chart.block.RectangleConstraint var24 = new org.jfree.chart.block.RectangleConstraint(var22, 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }
// 
// 
//     java.lang.ClassLoader var0 = null;
//     java.util.ResourceBundle.clearCache(var0);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("December 2014", var1, 1.0f, 100.0f, 10.0d, 100.0f, (-1.0f));
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    org.jfree.data.general.PieDataset var4 = null;
    org.jfree.chart.plot.RingPlot var5 = new org.jfree.chart.plot.RingPlot(var4);
    java.awt.Image var6 = var5.getBackgroundImage();
    java.awt.Color var9 = java.awt.Color.getColor("", (-1));
    java.awt.Color var12 = java.awt.Color.getColor("", (-1));
    boolean var13 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var9, (java.awt.Paint)var12);
    org.jfree.chart.block.BlockBorder var14 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var9);
    var5.setLabelPaint((java.awt.Paint)var9);
    org.jfree.chart.util.RectangleInsets var16 = var5.getInsets();
    org.jfree.data.general.PieDataset var17 = var5.getDataset();
    double var18 = var5.getShadowXOffset();
    var2.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var5);
    org.jfree.data.general.PieDataset var20 = null;
    var5.setDataset(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 4.0d);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     long var2 = var1.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(-457));
//     java.util.Calendar var5 = null;
//     long var6 = var1.getLastMillisecond(var5);
// 
//   }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Stroke var4 = null;
    var1.setOutlineStroke(var4);
    java.awt.Shape var6 = var1.getLegendItemShape();
    var1.setAutoPopulateSectionPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     var18.clearRangeMarkers();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    org.jfree.chart.title.LegendTitle var10 = var9.getLegend();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    var9.setBorderVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     int var22 = var18.getWeight();
//     org.jfree.chart.plot.IntervalMarker var25 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var26 = var25.getLabelOffsetType();
//     double var27 = var25.getEndValue();
//     var18.addDomainMarker((org.jfree.chart.plot.Marker)var25);
//     boolean var29 = var18.isRangeZeroBaselineVisible();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == false);
// 
//   }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     java.awt.Color var27 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var30 = java.awt.Color.getColor("", (-1));
//     boolean var31 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var27, (java.awt.Paint)var30);
//     java.awt.image.ColorModel var32 = null;
//     java.awt.Rectangle var33 = null;
//     java.awt.geom.Rectangle2D var34 = null;
//     java.awt.geom.AffineTransform var35 = null;
//     java.awt.Font var37 = null;
//     org.jfree.data.general.PieDataset var38 = null;
//     org.jfree.chart.plot.RingPlot var39 = new org.jfree.chart.plot.RingPlot(var38);
//     java.awt.Image var40 = var39.getBackgroundImage();
//     double var41 = var39.getOuterSeparatorExtension();
//     java.awt.Stroke var42 = null;
//     var39.setOutlineStroke(var42);
//     org.jfree.chart.JFreeChart var45 = new org.jfree.chart.JFreeChart("hi!", var37, (org.jfree.chart.plot.Plot)var39, false);
//     org.jfree.chart.title.LegendTitle var46 = var45.getLegend();
//     java.awt.RenderingHints var47 = var45.getRenderingHints();
//     java.awt.PaintContext var48 = var27.createContext(var32, var33, var34, var35, var47);
//     var21.setRangeMinorGridlinePaint((java.awt.Paint)var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setVisible(false);
    org.jfree.chart.util.RectangleInsets var25 = var9.getLegendItemGraphicPadding();
    double var26 = var25.getLeft();
    org.jfree.chart.util.UnitType var27 = var25.getUnitType();
    org.jfree.chart.util.RectangleInsets var32 = new org.jfree.chart.util.RectangleInsets(var27, (-1.0d), 100.0d, 10.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     java.lang.Comparable var25 = null;
//     var21.setDomainCrosshairRowKey(var25);
//     org.jfree.chart.plot.IntervalMarker var30 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var31 = var30.getLabelOffsetType();
//     org.jfree.chart.util.Layer var32 = null;
//     var21.addRangeMarker(100, (org.jfree.chart.plot.Marker)var30, var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    int var13 = var12.getRangeAxisCount();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
    var12.zoomRangeAxes(100.0d, var15, var18);
    java.awt.Paint var20 = var12.getDomainMinorGridlinePaint();
    org.jfree.chart.annotations.XYAnnotation var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.addAnnotation(var21, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var21.setFixedDomainAxisSpace(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = null;
//     org.jfree.data.time.TimeSeries var12 = null;
//     org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
//     var13.removeAllSeries();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
//     var13.validateObject();
//     org.jfree.chart.labels.XYToolTipGenerator var19 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var21 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var19, (org.jfree.chart.urls.XYURLGenerator)var21);
//     org.jfree.data.time.TimeSeries var23 = null;
//     org.jfree.data.time.TimeSeriesCollection var24 = new org.jfree.data.time.TimeSeriesCollection(var23);
//     var24.removeAllSeries();
//     org.jfree.data.Range var26 = var22.findRangeBounds((org.jfree.data.xy.XYDataset)var24);
//     int var27 = var24.getSeriesCount();
//     var13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var21
//     assertTrue("Contract failed: equals-hashcode on var3 and var21", var3.equals(var21) ? var3.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var3
//     assertTrue("Contract failed: equals-hashcode on var21 and var3", var21.equals(var3) ? var21.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var24
//     assertTrue("Contract failed: equals-hashcode on var13 and var24", var13.equals(var24) ? var13.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var13
//     assertTrue("Contract failed: equals-hashcode on var24 and var13", var24.equals(var13) ? var24.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    java.lang.String var12 = var1.getPlotType();
    double var13 = var1.getSectionDepth();
    org.jfree.chart.util.Rotation var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDirection(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "Pie Plot"+ "'", var12.equals("Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setVisible(false);
    org.jfree.chart.util.RectangleInsets var25 = var9.getLegendItemGraphicPadding();
    double var26 = var9.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.awt.Paint var10 = var3.getGridBandPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
    java.beans.PropertyChangeListener var2 = null;
    var1.removePropertyChangeListener(var2);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }
// 
// 
//     java.awt.Color var3 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var6 = java.awt.Color.getColor("", (-1));
//     boolean var7 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var3, (java.awt.Paint)var6);
//     java.awt.Color var8 = var6.darker();
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!", (java.awt.Paint)var6);
//     int var10 = var9.getSeriesIndex();
//     org.jfree.chart.axis.LogAxis var12 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var16 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var17 = var16.clone();
//     var12.setNumberFormatOverride((java.text.NumberFormat)var16);
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.util.RectangleEdge var21 = null;
//     double var22 = var12.valueToJava2D(0.0d, var20, var21);
//     java.lang.String[] var26 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var27 = new org.jfree.chart.axis.SymbolAxis("hi!", var26);
//     var27.setLabelAngle(0.0d);
//     java.lang.Object var30 = null;
//     boolean var31 = var27.equals(var30);
//     java.awt.Shape var32 = var27.getRightArrow();
//     java.awt.Font var33 = var27.getLabelFont();
//     org.jfree.chart.text.TextLine var34 = new org.jfree.chart.text.TextLine("", var33);
//     var12.setTickLabelFont(var33);
//     var9.setLabelFont(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     int var9 = var6.getSeriesCount();
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
//     int var12 = var6.indexOf(var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
//     boolean var15 = var11.equals((java.lang.Object)var13);
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var16);
//     java.lang.String var18 = var16.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var11.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)(short)0);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "December 2014"+ "'", var18.equals("December 2014"));
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
    java.awt.Stroke var11 = var4.getBaseOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 0.0d, 100.0d);
    org.jfree.chart.block.BlockContainer var5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
    boolean var6 = var5.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    var1.distributeLabels((-6.0d), 100.0d);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     java.lang.String[] var33 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("hi!", var33);
//     var34.setLabelAngle(0.0d);
//     java.lang.Object var37 = null;
//     boolean var38 = var34.equals(var37);
//     java.lang.String var39 = var34.getLabelURL();
//     org.jfree.chart.plot.Plot var40 = var34.getPlot();
//     var34.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Font var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     double var50 = var48.getOuterSeparatorExtension();
//     java.awt.Stroke var51 = null;
//     var48.setOutlineStroke(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, false);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     java.awt.RenderingHints var56 = var54.getRenderingHints();
//     java.awt.Color var59 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var62 = java.awt.Color.getColor("", (-1));
//     boolean var63 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var59, (java.awt.Paint)var62);
//     java.awt.Color var64 = var62.darker();
//     var54.setBackgroundPaint((java.awt.Paint)var62);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     int var68 = var67.getPieIndex();
//     org.jfree.data.general.DatasetGroup var69 = var67.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var71.setBaseCreateEntities(false, true);
//     boolean var75 = var67.equals((java.lang.Object)true);
//     java.awt.Stroke var76 = var67.getOutlineStroke();
//     var4.drawDomainLine(var11, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.chart.axis.ValueAxis)var34, var43, 10.0d, (java.awt.Paint)var62, var76);
//     java.awt.Paint var78 = var30.getDomainGridlinePaint();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    java.awt.Color var2 = java.awt.Color.getColor("", (-1));
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    boolean var6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var2, (java.awt.Paint)var5);
    org.jfree.chart.block.BlockBorder var7 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var2);
    java.awt.image.ColorModel var8 = null;
    java.awt.Rectangle var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    java.awt.geom.AffineTransform var11 = null;
    java.awt.Font var13 = null;
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    java.awt.Image var16 = var15.getBackgroundImage();
    double var17 = var15.getOuterSeparatorExtension();
    java.awt.Stroke var18 = null;
    var15.setOutlineStroke(var18);
    org.jfree.chart.JFreeChart var21 = new org.jfree.chart.JFreeChart("hi!", var13, (org.jfree.chart.plot.Plot)var15, false);
    java.awt.Paint var22 = var21.getBackgroundPaint();
    java.awt.RenderingHints var23 = var21.getRenderingHints();
    java.awt.PaintContext var24 = var2.createContext(var8, var9, var10, var11, var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.data.Range var22 = var3.getDefaultAutoRange();
//     org.jfree.data.Range var25 = org.jfree.data.Range.shift(var22, 0.0d, false);
//     org.jfree.data.category.CategoryDataset var26 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = null;
//     org.jfree.chart.axis.LogAxis var29 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var33 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var34 = var33.clone();
//     var29.setNumberFormatOverride((java.text.NumberFormat)var33);
//     java.awt.geom.Rectangle2D var37 = null;
//     org.jfree.chart.util.RectangleEdge var38 = null;
//     double var39 = var29.valueToJava2D(0.0d, var37, var38);
//     var29.pan(0.0d);
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var29.java2DToValue(10.0d, var43, var44);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var26, var27, (org.jfree.chart.axis.ValueAxis)var29, var46);
//     org.jfree.data.Range var48 = var29.getDefaultAutoRange();
//     org.jfree.data.Range var51 = org.jfree.data.Range.shift(var48, 0.0d, false);
//     boolean var52 = var25.intersects(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    int var9 = var6.getSeriesCount();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
    int var12 = var6.indexOf(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.delete(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     boolean var19 = var18.isOutlineVisible();
//     java.lang.String[] var22 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
//     var23.setLabelAngle(0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var23.equals(var26);
//     double var28 = var23.getFixedDimension();
//     java.awt.Shape var29 = var23.getLeftArrow();
//     java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
//     int var31 = var18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     org.jfree.chart.plot.PlotRenderingInfo var32 = null;
//     java.awt.geom.Point2D var33 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.plot.XYPlot var34 = var18.findSubplot(var32, var33);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1));
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    int var2 = var1.getPieIndex();
    org.jfree.data.general.DatasetGroup var3 = var1.getDatasetGroup();
    var1.setMinimumArcAngleToDraw(0.0d);
    var1.setIgnoreZeroValues(true);
    java.awt.Paint var8 = var1.getSeparatorPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.util.Layer var20 = null;
//     java.util.Collection var21 = var18.getDomainMarkers(0, var20);
//     java.awt.Paint var22 = var18.getRangeGridlinePaint();
//     java.lang.Object var23 = var18.clone();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var1.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    java.awt.Image var7 = var6.getBackgroundImage();
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    java.awt.Color var13 = java.awt.Color.getColor("", (-1));
    boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
    org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
    var6.setLabelPaint((java.awt.Paint)var10);
    var1.setBaseItemLabelPaint((java.awt.Paint)var10);
    double var18 = var1.getMargin();
    org.jfree.chart.labels.XYToolTipGenerator var20 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var22 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var20, (org.jfree.chart.urls.XYURLGenerator)var22);
    org.jfree.data.time.TimeSeries var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
    var25.removeAllSeries();
    org.jfree.data.Range var27 = var23.findRangeBounds((org.jfree.data.xy.XYDataset)var25);
    java.awt.Stroke var29 = var23.lookupSeriesStroke(1);
    var1.setBaseOutlineStroke(var29);
    java.awt.Paint var32 = null;
    var1.setSeriesOutlinePaint(0, var32, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var1.setBaseCreateEntities(false, true);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
//     java.awt.Image var7 = var6.getBackgroundImage();
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var13 = java.awt.Color.getColor("", (-1));
//     boolean var14 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var10, (java.awt.Paint)var13);
//     org.jfree.chart.block.BlockBorder var15 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var10);
//     var6.setLabelPaint((java.awt.Paint)var10);
//     var1.setBaseItemLabelPaint((java.awt.Paint)var10);
//     double var18 = var1.getMargin();
//     java.awt.Graphics2D var19 = null;
//     java.lang.String[] var22 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
//     var23.setLabelAngle(0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var23.equals(var26);
//     double var28 = var23.getFixedDimension();
//     java.awt.Shape var29 = var23.getLeftArrow();
//     java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
//     java.lang.Object var31 = var23.clone();
//     org.jfree.chart.plot.CombinedRangeXYPlot var32 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var23);
//     int var33 = var32.getRangeAxisCount();
//     org.jfree.chart.plot.PlotRenderingInfo var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleAnchor var37 = null;
//     java.awt.geom.Point2D var38 = org.jfree.chart.util.RectangleAnchor.coordinates(var36, var37);
//     var32.zoomRangeAxes(100.0d, var35, var38);
//     java.awt.Paint var40 = var32.getDomainMinorGridlinePaint();
//     java.lang.String[] var43 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var44 = new org.jfree.chart.axis.SymbolAxis("hi!", var43);
//     var44.setLabelAngle(0.0d);
//     org.jfree.chart.axis.NumberTickUnit var47 = var44.getTickUnit();
//     java.awt.Paint var48 = var44.getGridBandPaint();
//     org.jfree.data.general.PieDataset var49 = null;
//     org.jfree.chart.plot.RingPlot var50 = new org.jfree.chart.plot.RingPlot(var49);
//     java.awt.Image var51 = var50.getBackgroundImage();
//     java.awt.Color var54 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var57 = java.awt.Color.getColor("", (-1));
//     boolean var58 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var54, (java.awt.Paint)var57);
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var54);
//     var50.setLabelPaint((java.awt.Paint)var54);
//     org.jfree.chart.util.RectangleInsets var61 = var50.getInsets();
//     var44.setLabelInsets(var61, false);
//     java.awt.Paint var64 = var44.getTickMarkPaint();
//     org.jfree.chart.plot.IntervalMarker var67 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var68 = var67.getLabelOffsetType();
//     double var69 = var67.getEndValue();
//     org.jfree.data.general.PieDataset var70 = null;
//     org.jfree.chart.plot.RingPlot var71 = new org.jfree.chart.plot.RingPlot(var70);
//     java.awt.Image var72 = var71.getBackgroundImage();
//     double var73 = var71.getOuterSeparatorExtension();
//     java.awt.Color var77 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var80 = java.awt.Color.getColor("", (-1));
//     boolean var81 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var77, (java.awt.Paint)var80);
//     int var82 = var80.getAlpha();
//     var71.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var80);
//     org.jfree.data.general.PieDataset var84 = null;
//     org.jfree.chart.plot.RingPlot var85 = new org.jfree.chart.plot.RingPlot(var84);
//     java.awt.Image var86 = var85.getBackgroundImage();
//     double var87 = var85.getOuterSeparatorExtension();
//     java.awt.Paint var88 = var85.getLabelBackgroundPaint();
//     boolean var89 = var85.getSectionOutlinesVisible();
//     var71.setParent((org.jfree.chart.plot.Plot)var85);
//     var67.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var71);
//     java.awt.geom.Rectangle2D var92 = null;
//     var1.drawDomainMarker(var19, (org.jfree.chart.plot.XYPlot)var32, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.plot.Marker)var67, var92);
//     
//     // Checks the contract:  equals-hashcode on var6 and var50
//     assertTrue("Contract failed: equals-hashcode on var6 and var50", var6.equals(var50) ? var6.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var6
//     assertTrue("Contract failed: equals-hashcode on var50 and var6", var50.equals(var6) ? var50.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var59
//     assertTrue("Contract failed: equals-hashcode on var15 and var59", var15.equals(var59) ? var15.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var15
//     assertTrue("Contract failed: equals-hashcode on var59 and var15", var59.equals(var15) ? var59.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     boolean var19 = var18.isOutlineVisible();
//     org.jfree.chart.plot.IntervalMarker var22 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var23 = var22.getLabelOffsetType();
//     double var24 = var22.getEndValue();
//     java.awt.Paint var25 = var22.getLabelPaint();
//     boolean var26 = var18.removeRangeMarker((org.jfree.chart.plot.Marker)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 100.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    var9.setPadding((-1.0d), 0.0d, 0.0d, 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    int var9 = var6.getSeriesCount();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)100.0d);
    int var12 = var6.indexOf(var11);
    java.lang.String var13 = var11.getRangeDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Value"+ "'", var13.equals("Value"));

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var18.setRenderer(var19);
//     org.jfree.chart.labels.XYToolTipGenerator var22 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var24 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var25 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var22, (org.jfree.chart.urls.XYURLGenerator)var24);
//     org.jfree.data.time.TimeSeries var26 = null;
//     org.jfree.data.time.TimeSeriesCollection var27 = new org.jfree.data.time.TimeSeriesCollection(var26);
//     var27.removeAllSeries();
//     org.jfree.data.Range var29 = var25.findRangeBounds((org.jfree.data.xy.XYDataset)var27);
//     java.awt.Stroke var31 = var25.lookupSeriesStroke(1);
//     var18.setDomainGridlineStroke(var31);
//     java.lang.String[] var35 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var36 = new org.jfree.chart.axis.SymbolAxis("hi!", var35);
//     int var37 = var18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == (-1));
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 0.0d, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     java.lang.String[] var15 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var16 = new org.jfree.chart.axis.SymbolAxis("hi!", var15);
//     var16.setLabelAngle(0.0d);
//     java.lang.Object var19 = null;
//     boolean var20 = var16.equals(var19);
//     java.awt.Shape var21 = var16.getRightArrow();
//     java.awt.Font var22 = var16.getLabelFont();
//     org.jfree.chart.text.TextLine var23 = new org.jfree.chart.text.TextLine("", var22);
//     var1.setTickLabelFont(var22);
//     java.awt.geom.Rectangle2D var26 = null;
//     org.jfree.chart.labels.XYToolTipGenerator var28 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var30 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var28, (org.jfree.chart.urls.XYURLGenerator)var30);
//     org.jfree.data.time.TimeSeries var32 = null;
//     org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var32);
//     var33.removeAllSeries();
//     org.jfree.data.Range var35 = var31.findRangeBounds((org.jfree.data.xy.XYDataset)var33);
//     org.jfree.chart.title.LegendTitle var36 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var31);
//     java.awt.Font var38 = null;
//     org.jfree.data.general.PieDataset var39 = null;
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot(var39);
//     java.awt.Image var41 = var40.getBackgroundImage();
//     double var42 = var40.getOuterSeparatorExtension();
//     java.awt.Stroke var43 = null;
//     var40.setOutlineStroke(var43);
//     org.jfree.chart.JFreeChart var46 = new org.jfree.chart.JFreeChart("hi!", var38, (org.jfree.chart.plot.Plot)var40, false);
//     java.awt.Paint var47 = var46.getBackgroundPaint();
//     var36.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var46);
//     org.jfree.chart.util.HorizontalAlignment var49 = var36.getHorizontalAlignment();
//     var36.setID("Pie Plot");
//     org.jfree.chart.util.RectangleEdge var52 = var36.getPosition();
//     boolean var53 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var52);
//     double var54 = var1.valueToJava2D((-1.0d), var26, var52);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.awt.Shape var9 = var3.getLeftArrow();
    java.lang.Object var10 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var3);
    java.lang.Object var11 = var3.clone();
    org.jfree.chart.plot.CombinedRangeXYPlot var12 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var3);
    int var13 = var12.getRangeAxisCount();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.util.RectangleAnchor var17 = null;
    java.awt.geom.Point2D var18 = org.jfree.chart.util.RectangleAnchor.coordinates(var16, var17);
    var12.zoomRangeAxes(100.0d, var15, var18);
    java.awt.Paint var20 = var12.getDomainMinorGridlinePaint();
    org.jfree.data.xy.XYDataset var22 = var12.getDataset(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test226() {}
//   public void test226() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     var4.setItemLabelAnchorOffset(0.0d);
//     org.jfree.chart.event.RendererChangeEvent var7 = null;
//     var4.notifyListeners(var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.plot.XYPlot var11 = null;
//     org.jfree.data.time.TimeSeries var12 = null;
//     org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
//     var13.removeAllSeries();
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
//     java.lang.String[] var19 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var20 = new org.jfree.chart.axis.SymbolAxis("hi!", var19);
//     var20.setLabelAngle(0.0d);
//     java.lang.Object var23 = null;
//     boolean var24 = var20.equals(var23);
//     java.awt.Shape var25 = var20.getRightArrow();
//     org.jfree.chart.labels.XYToolTipGenerator var27 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var29 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var27, (org.jfree.chart.urls.XYURLGenerator)var29);
//     org.jfree.data.time.TimeSeries var31 = null;
//     org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var31);
//     var32.removeAllSeries();
//     org.jfree.data.Range var34 = var30.findRangeBounds((org.jfree.data.xy.XYDataset)var32);
//     org.jfree.chart.title.LegendTitle var35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var30);
//     org.jfree.chart.entity.TitleEntity var37 = new org.jfree.chart.entity.TitleEntity(var25, (org.jfree.chart.title.Title)var35, "");
//     var4.setBaseShape(var25);
//     
//     // Checks the contract:  equals-hashcode on var3 and var29
//     assertTrue("Contract failed: equals-hashcode on var3 and var29", var3.equals(var29) ? var3.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var3
//     assertTrue("Contract failed: equals-hashcode on var29 and var3", var29.equals(var3) ? var29.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var32
//     assertTrue("Contract failed: equals-hashcode on var13 and var32", var13.equals(var32) ? var13.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var13
//     assertTrue("Contract failed: equals-hashcode on var32 and var13", var32.equals(var13) ? var32.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.String var24 = var23.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + "RectangleEdge.BOTTOM"+ "'", var24.equals("RectangleEdge.BOTTOM"));
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    org.jfree.chart.axis.NumberTickUnit var6 = var3.getTickUnit();
    java.awt.Paint var7 = var3.getGridBandPaint();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var9, (org.jfree.chart.urls.XYURLGenerator)var11);
    org.jfree.data.time.TimeSeries var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
    var14.removeAllSeries();
    org.jfree.data.Range var16 = var12.findRangeBounds((org.jfree.data.xy.XYDataset)var14);
    java.awt.Stroke var18 = var12.lookupSeriesStroke(1);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    java.awt.Image var21 = var20.getBackgroundImage();
    java.awt.Color var24 = java.awt.Color.getColor("", (-1));
    java.awt.Color var27 = java.awt.Color.getColor("", (-1));
    boolean var28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var24, (java.awt.Paint)var27);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
    var20.setLabelPaint((java.awt.Paint)var24);
    org.jfree.chart.util.RectangleInsets var31 = var20.getInsets();
    double var33 = var31.calculateRightOutset(1.0d);
    org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder(var7, var18, var31);
    org.jfree.chart.util.RectangleInsets var35 = var34.getInsets();
    java.awt.Stroke var36 = var34.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    double var8 = var3.getFixedDimension();
    java.lang.String[] var11 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var12 = new org.jfree.chart.axis.SymbolAxis("hi!", var11);
    var12.setLabelAngle(0.0d);
    java.lang.Object var15 = null;
    boolean var16 = var12.equals(var15);
    double var17 = var12.getFixedDimension();
    java.awt.Shape var18 = var12.getLeftArrow();
    org.jfree.chart.entity.AxisLabelEntity var21 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var3, var18, "December 2014", "hi!");
    java.lang.String var22 = var21.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "AxisLabelEntity: label = hi!"+ "'", var22.equals("AxisLabelEntity: label = hi!"));

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, (-457));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.lang.String var8 = var3.getLabel();
    boolean var9 = var3.isPositiveArrowVisible();
    var3.setLabelAngle(1.0d);
    org.jfree.chart.util.RectangleInsets var12 = var3.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "hi!"+ "'", var8.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     var21.clearRangeMarkers();
//     java.awt.Paint var23 = var21.getRangeGridlinePaint();
//     var21.setCrosshairDatasetIndex((-457), false);
//     java.awt.Stroke var27 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var21.setRangeMinorGridlineStroke(var27);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
// 
//   }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("\uFFFD", var1);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
    org.jfree.chart.util.LengthAdjustmentType var3 = var2.getLabelOffsetType();
    double var4 = var2.getEndValue();
    org.jfree.data.general.PieDataset var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot(var5);
    int var7 = var6.getPieIndex();
    org.jfree.data.general.DatasetGroup var8 = var6.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYBarRenderer var10 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var10.setBaseCreateEntities(false, true);
    boolean var14 = var6.equals((java.lang.Object)true);
    java.awt.Stroke var15 = var6.getOutlineStroke();
    var2.setStroke(var15);
    double var17 = var2.getStartValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     java.lang.String[] var24 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var25 = new org.jfree.chart.axis.SymbolAxis("hi!", var24);
//     var21.setRangeAxis((org.jfree.chart.axis.ValueAxis)var25);
//     org.jfree.chart.axis.ValueAxis var27 = var21.getRangeAxis();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = null;
//     var18.setRenderer(var19);
//     org.jfree.chart.axis.LogAxis var22 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var26 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var27 = var26.clone();
//     var22.setNumberFormatOverride((java.text.NumberFormat)var26);
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var22.valueToJava2D(0.0d, var30, var31);
//     var22.pan(0.0d);
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var22.java2DToValue(10.0d, var36, var37);
//     org.jfree.chart.plot.CombinedRangeXYPlot var39 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var22);
//     boolean var40 = var39.isOutlineVisible();
//     java.lang.String[] var43 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var44 = new org.jfree.chart.axis.SymbolAxis("hi!", var43);
//     var44.setLabelAngle(0.0d);
//     java.lang.Object var47 = null;
//     boolean var48 = var44.equals(var47);
//     double var49 = var44.getFixedDimension();
//     java.awt.Shape var50 = var44.getLeftArrow();
//     java.lang.Object var51 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var44);
//     int var52 = var39.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var44);
//     var44.configure();
//     org.jfree.data.Range var54 = var18.getDataRange((org.jfree.chart.axis.ValueAxis)var44);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.chart.axis.ValueAxis var56 = var18.getDomainAxisForDataset((-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var54);
// 
//   }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    boolean var10 = var9.getNotify();
    org.jfree.chart.util.RectangleAnchor var11 = null;
    var9.setLegendItemGraphicLocation(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test239() {}
//   public void test239() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var23 = null;
//     org.jfree.chart.axis.LogAxis var25 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var29 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var30 = var29.clone();
//     var25.setNumberFormatOverride((java.text.NumberFormat)var29);
//     java.awt.geom.Rectangle2D var33 = null;
//     org.jfree.chart.util.RectangleEdge var34 = null;
//     double var35 = var25.valueToJava2D(0.0d, var33, var34);
//     var25.pan(0.0d);
//     java.awt.geom.Rectangle2D var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     double var41 = var25.java2DToValue(10.0d, var39, var40);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var42 = null;
//     org.jfree.chart.plot.CategoryPlot var43 = new org.jfree.chart.plot.CategoryPlot(var22, var23, (org.jfree.chart.axis.ValueAxis)var25, var42);
//     org.jfree.chart.util.RectangleEdge var45 = var43.getDomainAxisEdge(0);
//     java.lang.Comparable var46 = var43.getDomainCrosshairColumnKey();
//     org.jfree.chart.util.SortOrder var47 = var43.getRowRenderingOrder();
//     org.jfree.chart.event.RendererChangeEvent var48 = null;
//     var43.rendererChanged(var48);
//     org.jfree.chart.plot.IntervalMarker var53 = new org.jfree.chart.plot.IntervalMarker(1.0d, 100.0d);
//     org.jfree.chart.util.LengthAdjustmentType var54 = var53.getLabelOffsetType();
//     var53.setEndValue(0.0d);
//     java.awt.Paint var57 = var53.getLabelPaint();
//     org.jfree.chart.util.Layer var58 = null;
//     boolean var60 = var43.removeDomainMarker((-457), (org.jfree.chart.plot.Marker)var53, var58, true);
//     boolean var61 = var21.removeRangeMarker((org.jfree.chart.plot.Marker)var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
// 
//   }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Font var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Image var14 = var13.getBackgroundImage();
//     double var15 = var13.getOuterSeparatorExtension();
//     java.awt.Stroke var16 = null;
//     var13.setOutlineStroke(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
//     var9.setVisible(false);
//     org.jfree.chart.util.RectangleInsets var25 = var9.getLegendItemGraphicPadding();
//     var9.setHeight(100.0d);
//     java.lang.String[] var30 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var31 = new org.jfree.chart.axis.SymbolAxis("hi!", var30);
//     var31.setLabelAngle(0.0d);
//     org.jfree.chart.axis.NumberTickUnit var34 = var31.getTickUnit();
//     java.awt.Paint var35 = var31.getGridBandPaint();
//     org.jfree.chart.labels.XYToolTipGenerator var37 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var39 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var40 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var37, (org.jfree.chart.urls.XYURLGenerator)var39);
//     org.jfree.data.time.TimeSeries var41 = null;
//     org.jfree.data.time.TimeSeriesCollection var42 = new org.jfree.data.time.TimeSeriesCollection(var41);
//     var42.removeAllSeries();
//     org.jfree.data.Range var44 = var40.findRangeBounds((org.jfree.data.xy.XYDataset)var42);
//     java.awt.Stroke var46 = var40.lookupSeriesStroke(1);
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     java.awt.Color var52 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var55 = java.awt.Color.getColor("", (-1));
//     boolean var56 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var52, (java.awt.Paint)var55);
//     org.jfree.chart.block.BlockBorder var57 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var52);
//     var48.setLabelPaint((java.awt.Paint)var52);
//     org.jfree.chart.util.RectangleInsets var59 = var48.getInsets();
//     double var61 = var59.calculateRightOutset(1.0d);
//     org.jfree.chart.block.LineBorder var62 = new org.jfree.chart.block.LineBorder(var35, var46, var59);
//     org.jfree.chart.util.RectangleInsets var63 = var62.getInsets();
//     var9.setMargin(var63);
//     
//     // Checks the contract:  equals-hashcode on var3 and var39
//     assertTrue("Contract failed: equals-hashcode on var3 and var39", var3.equals(var39) ? var3.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var3
//     assertTrue("Contract failed: equals-hashcode on var39 and var3", var39.equals(var3) ? var39.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var42
//     assertTrue("Contract failed: equals-hashcode on var6 and var42", var6.equals(var42) ? var6.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var6
//     assertTrue("Contract failed: equals-hashcode on var42 and var6", var42.equals(var6) ? var42.hashCode() == var6.hashCode() : true);
// 
//   }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }


    org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);

  }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("rect", "December 2014", "hi!", "RectangleEdge.BOTTOM", "org.jfree.data.UnknownKeyException: December 2014");

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    var1.setNoDataMessage("December 2014");
    boolean var5 = var1.getSeparatorsVisible();
    var1.setAutoPopulateSectionOutlinePaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    org.jfree.data.time.TimeSeries var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
    org.jfree.data.Range var4 = var1.findDomainBounds((org.jfree.data.xy.XYDataset)var3);
    org.jfree.chart.LegendItem var7 = var1.getLegendItem(100, (-457));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    java.awt.Color var14 = java.awt.Color.getColor("", (-1));
    java.awt.Color var17 = java.awt.Color.getColor("", (-1));
    boolean var18 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var14, (java.awt.Paint)var17);
    java.awt.Color var19 = var17.darker();
    var9.setBackgroundPaint((java.awt.Paint)var17);
    org.jfree.chart.plot.Plot var21 = var9.getPlot();
    org.jfree.chart.renderer.xy.XYBarRenderer var23 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    org.jfree.data.time.TimeSeries var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var24);
    org.jfree.data.Range var26 = var23.findDomainBounds((org.jfree.data.xy.XYDataset)var25);
    boolean var27 = var21.equals((java.lang.Object)var23);
    var23.setBaseSeriesVisible(false);
    org.jfree.chart.urls.XYURLGenerator var31 = var23.getSeriesURLGenerator(0);
    java.awt.Stroke var33 = var23.getSeriesOutlineStroke(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var1.setBaseCreateEntities(false, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var1.getNegativeItemLabelPositionFallback();
    java.awt.Paint var6 = var1.getBaseLegendTextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    boolean var9 = var4.getPlotLines();
    org.jfree.chart.labels.XYToolTipGenerator var11 = null;
    var4.setSeriesToolTipGenerator(10, var11, true);
    java.awt.Paint var15 = var4.getSeriesPaint(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    org.jfree.chart.urls.StandardXYURLGenerator var12 = new org.jfree.chart.urls.StandardXYURLGenerator("", "hi!", "hi!");
    var4.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator)var12);
    java.awt.Paint var15 = var4.getSeriesFillPaint((-1));
    java.awt.Stroke var17 = var4.getSeriesStroke(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    org.jfree.chart.axis.NumberTickUnit var6 = var3.getTickUnit();
    java.awt.Paint var7 = var3.getGridBandPaint();
    org.jfree.chart.labels.XYToolTipGenerator var9 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var11 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var9, (org.jfree.chart.urls.XYURLGenerator)var11);
    org.jfree.data.time.TimeSeries var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var13);
    var14.removeAllSeries();
    org.jfree.data.Range var16 = var12.findRangeBounds((org.jfree.data.xy.XYDataset)var14);
    java.awt.Stroke var18 = var12.lookupSeriesStroke(1);
    org.jfree.data.general.PieDataset var19 = null;
    org.jfree.chart.plot.RingPlot var20 = new org.jfree.chart.plot.RingPlot(var19);
    java.awt.Image var21 = var20.getBackgroundImage();
    java.awt.Color var24 = java.awt.Color.getColor("", (-1));
    java.awt.Color var27 = java.awt.Color.getColor("", (-1));
    boolean var28 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var24, (java.awt.Paint)var27);
    org.jfree.chart.block.BlockBorder var29 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var24);
    var20.setLabelPaint((java.awt.Paint)var24);
    org.jfree.chart.util.RectangleInsets var31 = var20.getInsets();
    double var33 = var31.calculateRightOutset(1.0d);
    org.jfree.chart.block.LineBorder var34 = new org.jfree.chart.block.LineBorder(var7, var18, var31);
    java.awt.Stroke var35 = var34.getStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    org.jfree.chart.labels.ItemLabelPosition var12 = var4.getPositiveItemLabelPosition(1, 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var1);
//     boolean var3 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var2);
//     org.jfree.data.general.DatasetGroup var4 = var2.getGroup();
//     java.awt.Color var7 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var10 = java.awt.Color.getColor("", (-1));
//     boolean var11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var7, (java.awt.Paint)var10);
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var7);
//     boolean var13 = var2.equals((java.lang.Object)var12);
//     org.jfree.chart.labels.XYToolTipGenerator var15 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var17 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var18 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var15, (org.jfree.chart.urls.XYURLGenerator)var17);
//     var18.setItemLabelAnchorOffset(0.0d);
//     boolean var21 = var12.equals((java.lang.Object)var18);
//     java.util.Collection var22 = var18.getAnnotations();
//     org.jfree.chart.urls.XYURLGenerator var24 = var18.getSeriesURLGenerator((-1));
//     java.awt.Font var25 = var18.getBaseItemLabelFont();
//     org.jfree.chart.text.TextLine var26 = new org.jfree.chart.text.TextLine("December 2014", var25);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var28 = null;
//     org.jfree.chart.axis.LogAxis var30 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var34 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var35 = var34.clone();
//     var30.setNumberFormatOverride((java.text.NumberFormat)var34);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.util.RectangleEdge var39 = null;
//     double var40 = var30.valueToJava2D(0.0d, var38, var39);
//     var30.pan(0.0d);
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var30.java2DToValue(10.0d, var44, var45);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var27, var28, (org.jfree.chart.axis.ValueAxis)var30, var47);
//     org.jfree.chart.util.RectangleEdge var50 = var48.getDomainAxisEdge(0);
//     java.lang.Comparable var51 = var48.getDomainCrosshairColumnKey();
//     org.jfree.chart.util.SortOrder var52 = var48.getRowRenderingOrder();
//     org.jfree.chart.event.RendererChangeEvent var53 = null;
//     var48.rendererChanged(var53);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var48.getRenderer(1);
//     boolean var57 = var26.equals((java.lang.Object)1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == false);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setVisible(false);
    java.awt.Graphics2D var25 = null;
    org.jfree.data.Range var26 = null;
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint(var26, 1.0d);
    double var29 = var28.getHeight();
    double var30 = var28.getHeight();
    org.jfree.chart.util.Size2D var31 = var9.arrange(var25, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     long var2 = var1.getSerialIndex();
//     org.jfree.data.time.TimeSeriesDataItem var4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var1, (java.lang.Number)(-457));
//     java.lang.Number var5 = var4.getValue();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + (-457)+ "'", var5.equals((-457)));
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    org.jfree.chart.labels.XYToolTipGenerator var10 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var12 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var10, (org.jfree.chart.urls.XYURLGenerator)var12);
    org.jfree.data.time.TimeSeries var14 = null;
    org.jfree.data.time.TimeSeriesCollection var15 = new org.jfree.data.time.TimeSeriesCollection(var14);
    var15.removeAllSeries();
    org.jfree.data.Range var17 = var13.findRangeBounds((org.jfree.data.xy.XYDataset)var15);
    org.jfree.chart.title.LegendTitle var18 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var13);
    org.jfree.chart.entity.TitleEntity var20 = new org.jfree.chart.entity.TitleEntity(var8, (org.jfree.chart.title.Title)var18, "");
    java.awt.Font var22 = null;
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.plot.RingPlot var24 = new org.jfree.chart.plot.RingPlot(var23);
    java.awt.Image var25 = var24.getBackgroundImage();
    double var26 = var24.getOuterSeparatorExtension();
    java.awt.Stroke var27 = null;
    var24.setOutlineStroke(var27);
    org.jfree.chart.JFreeChart var30 = new org.jfree.chart.JFreeChart("hi!", var22, (org.jfree.chart.plot.Plot)var24, false);
    java.awt.Paint var31 = var30.getBackgroundPaint();
    boolean var32 = var20.equals((java.lang.Object)var31);
    org.jfree.chart.block.BlockBorder var33 = new org.jfree.chart.block.BlockBorder(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    java.awt.Font var9 = var3.getLabelFont();
    var3.pan(0.0d);
    float var12 = var3.getTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0f);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    java.awt.Paint var10 = var9.getBackgroundPaint();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    java.awt.Stroke var12 = var9.getBorderStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
//     java.awt.Font var11 = null;
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
//     java.awt.Image var14 = var13.getBackgroundImage();
//     double var15 = var13.getOuterSeparatorExtension();
//     java.awt.Stroke var16 = null;
//     var13.setOutlineStroke(var16);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
//     java.awt.Paint var20 = var19.getBackgroundPaint();
//     var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
//     org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
//     var9.setVisible(false);
//     org.jfree.chart.axis.LogAxis var26 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var30 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var31 = var30.clone();
//     var26.setNumberFormatOverride((java.text.NumberFormat)var30);
//     java.awt.geom.Rectangle2D var34 = null;
//     org.jfree.chart.util.RectangleEdge var35 = null;
//     double var36 = var26.valueToJava2D(0.0d, var34, var35);
//     var26.pan(0.0d);
//     java.awt.geom.Rectangle2D var40 = null;
//     org.jfree.chart.util.RectangleEdge var41 = null;
//     double var42 = var26.java2DToValue(10.0d, var40, var41);
//     org.jfree.chart.plot.CombinedRangeXYPlot var43 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var26);
//     java.awt.Paint var44 = var43.getRangeMinorGridlinePaint();
//     var9.setItemPaint(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
// 
//   }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     var21.clearRangeMarkers();
//     java.awt.Paint var23 = var21.getRangeGridlinePaint();
//     var21.setCrosshairDatasetIndex((-457), false);
//     java.awt.Stroke var27 = var21.getDomainGridlineStroke();
//     org.jfree.chart.util.Layer var28 = null;
//     java.util.Collection var29 = var21.getDomainMarkers(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(0.0d, (-1.0d));

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     org.jfree.chart.util.SortOrder var25 = var21.getRowRenderingOrder();
//     org.jfree.chart.plot.CategoryMarker var26 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var21.addDomainMarker(var26);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var25, (org.jfree.chart.urls.XYURLGenerator)var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     var30.removeAllSeries();
//     org.jfree.data.Range var32 = var28.findRangeBounds((org.jfree.data.xy.XYDataset)var30);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     java.awt.Font var35 = null;
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     java.awt.Image var38 = var37.getBackgroundImage();
//     double var39 = var37.getOuterSeparatorExtension();
//     java.awt.Stroke var40 = null;
//     var37.setOutlineStroke(var40);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("hi!", var35, (org.jfree.chart.plot.Plot)var37, false);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     var33.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var43);
//     org.jfree.chart.util.HorizontalAlignment var46 = var33.getHorizontalAlignment();
//     var33.setID("Pie Plot");
//     org.jfree.chart.event.RendererChangeEvent var49 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var33);
//     var21.rendererChanged(var49);
//     org.jfree.chart.axis.ValueAxis var51 = var21.getRangeAxis();
//     var21.mapDatasetToRangeAxis(100, 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     org.jfree.data.time.TimeSeries var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var2);
//     org.jfree.data.Range var4 = var1.findDomainBounds((org.jfree.data.xy.XYDataset)var3);
//     java.lang.String[] var7 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var8 = new org.jfree.chart.axis.SymbolAxis("hi!", var7);
//     var8.setLabelAngle(0.0d);
//     java.lang.Object var11 = null;
//     boolean var12 = var8.equals(var11);
//     double var13 = var8.getFixedDimension();
//     java.awt.Shape var14 = var8.getLeftArrow();
//     var1.setBaseShape(var14);
//     org.jfree.chart.labels.XYToolTipGenerator var17 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var19 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var17, (org.jfree.chart.urls.XYURLGenerator)var19);
//     org.jfree.data.time.TimeSeries var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var21);
//     var22.removeAllSeries();
//     org.jfree.data.Range var24 = var20.findRangeBounds((org.jfree.data.xy.XYDataset)var22);
//     org.jfree.chart.title.LegendTitle var25 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var20);
//     java.awt.Font var27 = null;
//     org.jfree.data.general.PieDataset var28 = null;
//     org.jfree.chart.plot.RingPlot var29 = new org.jfree.chart.plot.RingPlot(var28);
//     java.awt.Image var30 = var29.getBackgroundImage();
//     double var31 = var29.getOuterSeparatorExtension();
//     java.awt.Stroke var32 = null;
//     var29.setOutlineStroke(var32);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("hi!", var27, (org.jfree.chart.plot.Plot)var29, false);
//     java.awt.Paint var36 = var35.getBackgroundPaint();
//     var25.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var35);
//     org.jfree.chart.util.HorizontalAlignment var38 = var25.getHorizontalAlignment();
//     var25.setVisible(false);
//     org.jfree.chart.util.RectangleInsets var41 = var25.getLegendItemGraphicPadding();
//     var25.setHeight(100.0d);
//     org.jfree.chart.entity.TitleEntity var45 = new org.jfree.chart.entity.TitleEntity(var14, (org.jfree.chart.title.Title)var25, "org.jfree.data.UnknownKeyException: December 2014");
//     
//     // Checks the contract:  equals-hashcode on var3 and var22
//     assertTrue("Contract failed: equals-hashcode on var3 and var22", var3.equals(var22) ? var3.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var3
//     assertTrue("Contract failed: equals-hashcode on var22 and var3", var22.equals(var3) ? var22.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    var4.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.event.RendererChangeEvent var7 = null;
    var4.notifyListeners(var7);
    java.awt.Graphics2D var9 = null;
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.plot.XYPlot var11 = null;
    org.jfree.data.time.TimeSeries var12 = null;
    org.jfree.data.time.TimeSeriesCollection var13 = new org.jfree.data.time.TimeSeriesCollection(var12);
    var13.removeAllSeries();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var16 = var4.initialise(var9, var10, var11, (org.jfree.data.xy.XYDataset)var13, var15);
    var13.validateObject();
    org.jfree.data.xy.IntervalXYDelegate var19 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset)var13, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var22 = var13.getStartXValue(0, (-457));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     org.jfree.chart.labels.XYToolTipGenerator var25 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var27 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var25, (org.jfree.chart.urls.XYURLGenerator)var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     var30.removeAllSeries();
//     org.jfree.data.Range var32 = var28.findRangeBounds((org.jfree.data.xy.XYDataset)var30);
//     org.jfree.chart.title.LegendTitle var33 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var28);
//     java.awt.Font var35 = null;
//     org.jfree.data.general.PieDataset var36 = null;
//     org.jfree.chart.plot.RingPlot var37 = new org.jfree.chart.plot.RingPlot(var36);
//     java.awt.Image var38 = var37.getBackgroundImage();
//     double var39 = var37.getOuterSeparatorExtension();
//     java.awt.Stroke var40 = null;
//     var37.setOutlineStroke(var40);
//     org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("hi!", var35, (org.jfree.chart.plot.Plot)var37, false);
//     java.awt.Paint var44 = var43.getBackgroundPaint();
//     var33.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var43);
//     org.jfree.chart.util.HorizontalAlignment var46 = var33.getHorizontalAlignment();
//     var33.setID("Pie Plot");
//     org.jfree.chart.event.RendererChangeEvent var49 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var33);
//     var21.rendererChanged(var49);
//     java.awt.Paint var51 = var21.getDomainCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var53 = null;
//     var21.setRangeAxisLocation(1, var53, true);
//     var21.clearRangeAxes();
//     int var57 = var21.getCrosshairDatasetIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var57 == 0);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }


    java.awt.Font var1 = null;
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot(var2);
    java.awt.Image var4 = var3.getBackgroundImage();
    double var5 = var3.getOuterSeparatorExtension();
    java.awt.Stroke var6 = null;
    var3.setOutlineStroke(var6);
    org.jfree.chart.JFreeChart var9 = new org.jfree.chart.JFreeChart("hi!", var1, (org.jfree.chart.plot.Plot)var3, false);
    org.jfree.chart.title.LegendTitle var10 = var9.getLegend();
    java.awt.RenderingHints var11 = var9.getRenderingHints();
    var9.setTitle("AxisLabelEntity: label = hi!");
    org.jfree.chart.renderer.xy.XYBarRenderer var16 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var16.setBaseCreateEntities(false, true);
    org.jfree.data.general.PieDataset var20 = null;
    org.jfree.chart.plot.RingPlot var21 = new org.jfree.chart.plot.RingPlot(var20);
    java.awt.Image var22 = var21.getBackgroundImage();
    java.awt.Color var25 = java.awt.Color.getColor("", (-1));
    java.awt.Color var28 = java.awt.Color.getColor("", (-1));
    boolean var29 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var25, (java.awt.Paint)var28);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var25);
    var21.setLabelPaint((java.awt.Paint)var25);
    var16.setBaseItemLabelPaint((java.awt.Paint)var25);
    double var33 = var16.getMargin();
    java.awt.Paint var35 = var16.getLegendTextPaint(1);
    java.lang.String[] var39 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var40 = new org.jfree.chart.axis.SymbolAxis("hi!", var39);
    var40.setLabelAngle(0.0d);
    org.jfree.chart.axis.NumberTickUnit var43 = var40.getTickUnit();
    java.awt.Paint var44 = var40.getGridBandPaint();
    var16.setSeriesOutlinePaint(0, var44, false);
    org.jfree.chart.labels.XYToolTipGenerator var48 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var50 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var48, (org.jfree.chart.urls.XYURLGenerator)var50);
    org.jfree.data.time.TimeSeries var52 = null;
    org.jfree.data.time.TimeSeriesCollection var53 = new org.jfree.data.time.TimeSeriesCollection(var52);
    var53.removeAllSeries();
    org.jfree.data.Range var55 = var51.findRangeBounds((org.jfree.data.xy.XYDataset)var53);
    java.awt.Stroke var57 = var51.lookupSeriesStroke(1);
    java.awt.Font var61 = var51.getItemLabelFont(0, 100, true);
    var16.setBaseLegendTextFont(var61);
    org.jfree.chart.title.TextTitle var63 = new org.jfree.chart.title.TextTitle("\uFFFD", var61);
    var9.setTitle(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    double var12 = var1.getLabelLinkMargin();
    var1.setCircular(false, true);
    java.awt.Stroke var16 = var1.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.025d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    org.jfree.chart.util.RectangleInsets var4 = new org.jfree.chart.util.RectangleInsets(1.0d, 0.0d, (-6.0d), (-1.0d));

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    var1.setNoDataMessage("December 2014");
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    java.awt.Stroke var6 = var1.getSectionOutlineStroke((java.lang.Comparable)var5);
    java.awt.Paint var7 = var1.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    java.lang.Object var23 = null;
    boolean var24 = var9.equals(var23);
    var9.setHeight(1.0d);
    org.jfree.chart.util.VerticalAlignment var27 = var9.getVerticalAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.util.RectangleEdge var23 = var21.getDomainAxisEdge(0);
//     java.lang.Comparable var24 = var21.getDomainCrosshairColumnKey();
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.util.RectangleAnchor var29 = null;
//     java.awt.geom.Point2D var30 = org.jfree.chart.util.RectangleAnchor.coordinates(var28, var29);
//     var21.zoomRangeAxes(100.0d, 100.0d, var27, var30);
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis var33 = null;
//     org.jfree.chart.axis.LogAxis var35 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var39 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var40 = var39.clone();
//     var35.setNumberFormatOverride((java.text.NumberFormat)var39);
//     java.awt.geom.Rectangle2D var43 = null;
//     org.jfree.chart.util.RectangleEdge var44 = null;
//     double var45 = var35.valueToJava2D(0.0d, var43, var44);
//     var35.pan(0.0d);
//     java.awt.geom.Rectangle2D var49 = null;
//     org.jfree.chart.util.RectangleEdge var50 = null;
//     double var51 = var35.java2DToValue(10.0d, var49, var50);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var52 = null;
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot(var32, var33, (org.jfree.chart.axis.ValueAxis)var35, var52);
//     org.jfree.chart.util.RectangleEdge var55 = var53.getDomainAxisEdge(0);
//     org.jfree.chart.labels.XYToolTipGenerator var57 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var59 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var60 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var57, (org.jfree.chart.urls.XYURLGenerator)var59);
//     org.jfree.data.time.TimeSeries var61 = null;
//     org.jfree.data.time.TimeSeriesCollection var62 = new org.jfree.data.time.TimeSeriesCollection(var61);
//     var62.removeAllSeries();
//     org.jfree.data.Range var64 = var60.findRangeBounds((org.jfree.data.xy.XYDataset)var62);
//     org.jfree.chart.title.LegendTitle var65 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var60);
//     java.awt.Font var67 = null;
//     org.jfree.data.general.PieDataset var68 = null;
//     org.jfree.chart.plot.RingPlot var69 = new org.jfree.chart.plot.RingPlot(var68);
//     java.awt.Image var70 = var69.getBackgroundImage();
//     double var71 = var69.getOuterSeparatorExtension();
//     java.awt.Stroke var72 = null;
//     var69.setOutlineStroke(var72);
//     org.jfree.chart.JFreeChart var75 = new org.jfree.chart.JFreeChart("hi!", var67, (org.jfree.chart.plot.Plot)var69, false);
//     java.awt.Paint var76 = var75.getBackgroundPaint();
//     var65.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var75);
//     org.jfree.chart.util.HorizontalAlignment var78 = var65.getHorizontalAlignment();
//     var65.setID("Pie Plot");
//     org.jfree.chart.event.RendererChangeEvent var81 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var65);
//     var53.rendererChanged(var81);
//     java.awt.Paint var83 = var53.getDomainCrosshairPaint();
//     org.jfree.chart.axis.AxisLocation var85 = null;
//     var53.setRangeAxisLocation(1, var85, true);
//     org.jfree.chart.axis.AxisLocation var88 = var53.getRangeAxisLocation();
//     var21.setRangeAxisLocation(var88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var71 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var88);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    double var3 = var1.getOuterSeparatorExtension();
    java.awt.Color var7 = java.awt.Color.getColor("", (-1));
    java.awt.Color var10 = java.awt.Color.getColor("", (-1));
    boolean var11 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var7, (java.awt.Paint)var10);
    int var12 = var10.getAlpha();
    var1.setSectionPaint((java.lang.Comparable)(byte)100, (java.awt.Paint)var10);
    org.jfree.data.general.PieDataset var14 = null;
    org.jfree.chart.plot.RingPlot var15 = new org.jfree.chart.plot.RingPlot(var14);
    int var16 = var15.getPieIndex();
    org.jfree.data.general.DatasetGroup var17 = var15.getDatasetGroup();
    org.jfree.chart.renderer.xy.XYBarRenderer var19 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
    var19.setBaseCreateEntities(false, true);
    boolean var23 = var15.equals((java.lang.Object)true);
    java.awt.Stroke var24 = var15.getOutlineStroke();
    var1.setBaseSectionOutlineStroke(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.data.time.Year var1 = var0.getYear();
//     long var2 = var1.getSerialIndex();
//     long var3 = var1.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2014L);
// 
//   }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test274() {}
//   public void test274() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.LogAxis var3 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var7 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var8 = var7.clone();
//     var3.setNumberFormatOverride((java.text.NumberFormat)var7);
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.util.RectangleEdge var12 = null;
//     double var13 = var3.valueToJava2D(0.0d, var11, var12);
//     var3.pan(0.0d);
//     java.awt.geom.Rectangle2D var17 = null;
//     org.jfree.chart.util.RectangleEdge var18 = null;
//     double var19 = var3.java2DToValue(10.0d, var17, var18);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var3, var20);
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     java.awt.geom.Rectangle2D var24 = null;
//     org.jfree.chart.util.RectangleAnchor var25 = null;
//     java.awt.geom.Point2D var26 = org.jfree.chart.util.RectangleAnchor.coordinates(var24, var25);
//     var21.zoomRangeAxes(100.0d, var23, var26);
//     java.awt.Stroke var28 = var21.getRangeZeroBaselineStroke();
//     org.jfree.data.time.TimeSeries var29 = null;
//     org.jfree.data.time.TimeSeriesCollection var30 = new org.jfree.data.time.TimeSeriesCollection(var29);
//     boolean var31 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var30);
//     org.jfree.data.general.DatasetGroup var32 = var30.getGroup();
//     java.awt.Color var35 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var38 = java.awt.Color.getColor("", (-1));
//     boolean var39 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var35, (java.awt.Paint)var38);
//     org.jfree.chart.block.BlockBorder var40 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var35);
//     boolean var41 = var30.equals((java.lang.Object)var40);
//     org.jfree.chart.labels.XYToolTipGenerator var43 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var45 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var43, (org.jfree.chart.urls.XYURLGenerator)var45);
//     var46.setItemLabelAnchorOffset(0.0d);
//     boolean var49 = var40.equals((java.lang.Object)var46);
//     java.util.Collection var50 = var46.getAnnotations();
//     org.jfree.chart.urls.XYURLGenerator var52 = var46.getSeriesURLGenerator((-1));
//     org.jfree.chart.LegendItemCollection var53 = var46.getLegendItems();
//     var21.setFixedLegendItems(var53);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var49 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var53);
// 
//   }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }
// 
// 
//     org.jfree.chart.labels.XYToolTipGenerator var1 = null;
//     org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
//     org.jfree.data.time.TimeSeries var5 = null;
//     org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
//     var6.removeAllSeries();
//     org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
//     java.awt.Stroke var10 = var4.lookupSeriesStroke(1);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.LogAxis var13 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var17 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var18 = var17.clone();
//     var13.setNumberFormatOverride((java.text.NumberFormat)var17);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var13.valueToJava2D(0.0d, var21, var22);
//     var13.pan(0.0d);
//     java.awt.geom.Rectangle2D var27 = null;
//     org.jfree.chart.util.RectangleEdge var28 = null;
//     double var29 = var13.java2DToValue(10.0d, var27, var28);
//     org.jfree.chart.plot.CombinedRangeXYPlot var30 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var13);
//     java.lang.String[] var33 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var34 = new org.jfree.chart.axis.SymbolAxis("hi!", var33);
//     var34.setLabelAngle(0.0d);
//     java.lang.Object var37 = null;
//     boolean var38 = var34.equals(var37);
//     java.lang.String var39 = var34.getLabelURL();
//     org.jfree.chart.plot.Plot var40 = var34.getPlot();
//     var34.setMinorTickMarkOutsideLength(0.0f);
//     java.awt.geom.Rectangle2D var43 = null;
//     java.awt.Font var46 = null;
//     org.jfree.data.general.PieDataset var47 = null;
//     org.jfree.chart.plot.RingPlot var48 = new org.jfree.chart.plot.RingPlot(var47);
//     java.awt.Image var49 = var48.getBackgroundImage();
//     double var50 = var48.getOuterSeparatorExtension();
//     java.awt.Stroke var51 = null;
//     var48.setOutlineStroke(var51);
//     org.jfree.chart.JFreeChart var54 = new org.jfree.chart.JFreeChart("hi!", var46, (org.jfree.chart.plot.Plot)var48, false);
//     java.awt.Paint var55 = var54.getBackgroundPaint();
//     java.awt.RenderingHints var56 = var54.getRenderingHints();
//     java.awt.Color var59 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var62 = java.awt.Color.getColor("", (-1));
//     boolean var63 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var59, (java.awt.Paint)var62);
//     java.awt.Color var64 = var62.darker();
//     var54.setBackgroundPaint((java.awt.Paint)var62);
//     org.jfree.data.general.PieDataset var66 = null;
//     org.jfree.chart.plot.RingPlot var67 = new org.jfree.chart.plot.RingPlot(var66);
//     int var68 = var67.getPieIndex();
//     org.jfree.data.general.DatasetGroup var69 = var67.getDatasetGroup();
//     org.jfree.chart.renderer.xy.XYBarRenderer var71 = new org.jfree.chart.renderer.xy.XYBarRenderer(0.0d);
//     var71.setBaseCreateEntities(false, true);
//     boolean var75 = var67.equals((java.lang.Object)true);
//     java.awt.Stroke var76 = var67.getOutlineStroke();
//     var4.drawDomainLine(var11, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.chart.axis.ValueAxis)var34, var43, 10.0d, (java.awt.Paint)var62, var76);
//     org.jfree.chart.plot.PlotOrientation var78 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var30.setOrientation(var78);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 0.2d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var75 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    boolean var9 = var3.isPositiveArrowVisible();
    java.lang.String var11 = var3.valueToString(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + ""+ "'", var11.equals(""));

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.plot.RingPlot var14 = new org.jfree.chart.plot.RingPlot(var13);
    int var15 = var14.getPieIndex();
    java.lang.String var16 = var14.getNoDataMessage();
    org.jfree.chart.labels.XYToolTipGenerator var18 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var20 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var18, (org.jfree.chart.urls.XYURLGenerator)var20);
    var21.setItemLabelAnchorOffset(0.0d);
    double var24 = var21.getItemLabelAnchorOffset();
    org.jfree.chart.labels.XYToolTipGenerator var26 = null;
    var21.setSeriesToolTipGenerator(1, var26);
    java.awt.Paint var28 = var21.getBasePaint();
    var14.setBackgroundPaint(var28);
    org.jfree.chart.block.BlockBorder var30 = new org.jfree.chart.block.BlockBorder(var12, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    java.lang.String[] var2 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
    var3.setLabelAngle(0.0d);
    java.lang.Object var6 = null;
    boolean var7 = var3.equals(var6);
    java.awt.Shape var8 = var3.getRightArrow();
    var3.setLabel("?series=1&amp;item=10");
    java.awt.Shape var11 = var3.getRightArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection(var0);
//     boolean var2 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset)var1);
//     java.util.List var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = null;
//     org.jfree.chart.axis.LogAxis var7 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var11 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var12 = var11.clone();
//     var7.setNumberFormatOverride((java.text.NumberFormat)var11);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var7.valueToJava2D(0.0d, var15, var16);
//     var7.pan(0.0d);
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.util.RectangleEdge var22 = null;
//     double var23 = var7.java2DToValue(10.0d, var21, var22);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var4, var5, (org.jfree.chart.axis.ValueAxis)var7, var24);
//     org.jfree.data.Range var26 = var7.getDefaultAutoRange();
//     org.jfree.data.Range var28 = org.jfree.data.Range.shift(var26, 100.0d);
//     org.jfree.data.Range var30 = var1.getRangeBounds(var3, var26, false);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("");
//     org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat((-1.0d), "", false);
//     java.lang.Object var6 = var5.clone();
//     var1.setNumberFormatOverride((java.text.NumberFormat)var5);
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.util.RectangleEdge var10 = null;
//     double var11 = var1.valueToJava2D(0.0d, var9, var10);
//     var1.pan(0.0d);
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.util.RectangleEdge var16 = null;
//     double var17 = var1.java2DToValue(10.0d, var15, var16);
//     org.jfree.chart.plot.CombinedRangeXYPlot var18 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
//     boolean var19 = var18.isOutlineVisible();
//     java.lang.String[] var22 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var23 = new org.jfree.chart.axis.SymbolAxis("hi!", var22);
//     var23.setLabelAngle(0.0d);
//     java.lang.Object var26 = null;
//     boolean var27 = var23.equals(var26);
//     double var28 = var23.getFixedDimension();
//     java.awt.Shape var29 = var23.getLeftArrow();
//     java.lang.Object var30 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var23);
//     int var31 = var18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var23);
//     var18.clearRangeAxes();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == Double.NaN);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == (-1));
// 
//   }

  public void test281() {}
//   public void test281() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("", (-1));
//     java.awt.Color var5 = java.awt.Color.getColor("", (-1));
//     boolean var6 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var2, (java.awt.Paint)var5);
//     java.awt.color.ColorSpace var7 = null;
//     float[] var10 = new float[] { 1.0f, 0.0f};
//     float[] var11 = var5.getColorComponents(var7, var10);
// 
//   }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.chart.labels.XYToolTipGenerator var1 = null;
    org.jfree.chart.urls.StandardXYURLGenerator var3 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, var1, (org.jfree.chart.urls.XYURLGenerator)var3);
    org.jfree.data.time.TimeSeries var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var5);
    var6.removeAllSeries();
    org.jfree.data.Range var8 = var4.findRangeBounds((org.jfree.data.xy.XYDataset)var6);
    org.jfree.chart.title.LegendTitle var9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var4);
    java.awt.Font var11 = null;
    org.jfree.data.general.PieDataset var12 = null;
    org.jfree.chart.plot.RingPlot var13 = new org.jfree.chart.plot.RingPlot(var12);
    java.awt.Image var14 = var13.getBackgroundImage();
    double var15 = var13.getOuterSeparatorExtension();
    java.awt.Stroke var16 = null;
    var13.setOutlineStroke(var16);
    org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("hi!", var11, (org.jfree.chart.plot.Plot)var13, false);
    java.awt.Paint var20 = var19.getBackgroundPaint();
    var9.removeChangeListener((org.jfree.chart.event.TitleChangeListener)var19);
    org.jfree.chart.util.HorizontalAlignment var22 = var9.getHorizontalAlignment();
    var9.setVisible(false);
    boolean var25 = var9.getNotify();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { ""};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("hi!", var2);
//     var3.setLabelAngle(0.0d);
//     java.lang.Object var6 = null;
//     boolean var7 = var3.equals(var6);
//     java.awt.Shape var8 = var3.getRightArrow();
//     org.jfree.chart.entity.LegendItemEntity var9 = new org.jfree.chart.entity.LegendItemEntity(var8);
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month();
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var10);
//     long var12 = var10.getLastMillisecond();
//     var9.setSeriesKey((java.lang.Comparable)var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1420099199999L);
// 
//   }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     java.awt.geom.Rectangle2D var5 = org.jfree.chart.text.TextUtilities.drawAlignedString("Sunday", var1, 0.0f, 0.0f, var4);
// 
//   }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
    double var13 = var1.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.025d);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    java.awt.Image var2 = var1.getBackgroundImage();
    java.awt.Color var5 = java.awt.Color.getColor("", (-1));
    java.awt.Color var8 = java.awt.Color.getColor("", (-1));
    boolean var9 = org.jfree.chart.util.PaintUtilities.equal((java.awt.Paint)var5, (java.awt.Paint)var8);
    org.jfree.chart.block.BlockBorder var10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint)var5);
    var1.setLabelPaint((java.awt.Paint)var5);
    org.jfree.chart.util.RectangleInsets var12 = var1.getInsets();
    org.jfree.data.general.PieDataset var13 = var1.getDataset();
    org.jfree.chart.plot.DrawingSupplier var14 = null;
    var1.setDrawingSupplier(var14, true);
    var1.setBackgroundImageAlignment(100);
    java.awt.Graphics2D var19 = null;
    java.awt.geom.Rectangle2D var20 = null;
    java.lang.String[] var23 = new java.lang.String[] { ""};
    org.jfree.chart.axis.SymbolAxis var24 = new org.jfree.chart.axis.SymbolAxis("hi!", var23);
    var24.setLabelAngle(0.0d);
    java.lang.Object var27 = null;
    boolean var28 = var24.equals(var27);
    double var29 = var24.getFixedDimension();
    java.awt.Shape var30 = var24.getLeftArrow();
    org.jfree.data.general.PieDataset var31 = null;
    org.jfree.chart.plot.RingPlot var32 = new org.jfree.chart.plot.RingPlot(var31);
    java.awt.Image var33 = var32.getBackgroundImage();
    java.awt.Stroke var35 = var32.getSectionOutlineStroke((java.lang.Comparable)100.0d);
    org.jfree.chart.urls.PieURLGenerator var36 = null;
    var32.setLegendLabelURLGenerator(var36);
    org.jfree.chart.entity.PlotEntity var40 = new org.jfree.chart.entity.PlotEntity(var30, (org.jfree.chart.plot.Plot)var32, "", "\uFFFD");
    org.jfree.chart.plot.PlotRenderingInfo var42 = null;
    org.jfree.chart.plot.PiePlotState var43 = var1.initialise(var19, var20, (org.jfree.chart.plot.PiePlot)var32, (java.lang.Integer)1, var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

}
