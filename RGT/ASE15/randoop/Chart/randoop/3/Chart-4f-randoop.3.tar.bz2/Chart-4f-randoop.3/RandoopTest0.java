
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var6 = new org.jfree.chart.entity.CategoryItemEntity(var0, "hi!", "hi!", var3, (java.lang.Comparable)(short)10, (java.lang.Comparable)'4');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Font var1 = null;
    java.awt.Paint var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var3 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    java.util.Date var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Image var1 = org.jfree.chart.util.SerialUtilities.readImage(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    boolean var0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var1 = org.jfree.chart.util.SerialUtilities.readShape(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    org.jfree.chart.title.Title var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TitleEntity var4 = new org.jfree.chart.entity.TitleEntity(var1, var2, "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.Range.shift(var0, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.awt.geom.Line2D var0 = null;
    java.awt.geom.Line2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.util.RectangleInsets var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelInsets(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, (-1.0d), (-1.0f), 0.0f);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     org.jfree.chart.axis.DateTickUnit var2 = null;
//     java.util.Date var3 = var1.calculateHighestVisibleTickValue(var2);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    java.awt.Stroke var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { (byte)(-1)};
//     java.lang.Comparable[] var3 = new java.lang.Comparable[] { 'a'};
//     double[] var4 = null;
//     double[][] var5 = new double[][] { var4};
//     org.jfree.data.category.CategoryDataset var6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var3, var5);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 1, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     long var0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var0 == (-2208960000000L));
// 
//   }

  public void test21() {}
//   public void test21() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var2 = new org.jfree.chart.text.TextFragment("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", var3);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);
//     org.jfree.chart.util.Size2D var3 = null;
//     org.jfree.chart.util.Size2D var4 = var2.calculateConstrainedSize(var3);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBoolean((-1), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getCurrencyInstance(var0);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.util.RectangleAnchor var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, var5, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     double var2 = var1.getUpperMargin();
//     org.jfree.chart.axis.DateTickUnit var3 = null;
//     java.util.Date var4 = var1.calculateHighestVisibleTickValue(var3);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 0.0d);
//     org.jfree.chart.block.BlockContainer var5 = null;
//     java.awt.Graphics2D var6 = null;
//     org.jfree.data.Range var8 = null;
//     org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(100.0d, var8);
//     org.jfree.chart.util.Size2D var10 = var4.arrange(var5, var6, var9);
// 
//   }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Stroke var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseOutlineStroke(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, (-1), var2);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    float[] var3 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var4 = java.awt.Color.RGBtoHSB(100, 0, 100, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.text.NumberFormat var0 = java.text.NumberFormat.getInstance();
    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var2, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
    double var8 = var7.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var11 = new org.jfree.chart.entity.AxisEntity(var5, (org.jfree.chart.axis.Axis)var7, "hi!", "hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var12 = var0.formatToCharacterIterator((java.lang.Object)var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getStartYValue((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.plot.Marker var21 = null;
    org.jfree.chart.util.Layer var22 = null;
    boolean var23 = var15.removeDomainMarker(10, var21, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getFirstMillisecond(var3);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var1.setLine(var3);
    java.lang.String var5 = var1.getURLText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = var2.getSeries(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    org.jfree.data.general.DatasetGroup var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var11.setGroup(var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test46() {}
//   public void test46() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var15.drawOutline(var22, var23);
// 
//   }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1, 10.0f, 0.0f, 100.0d, 10.0f, 0.0f);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    org.jfree.data.Range var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(100.0d, var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var0.arrange(var1, var4);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     double var8 = var7.getUpperMargin();
//     var7.setAutoRangeMinimumSize(0.05d, true);
//     var7.setLabelURL("hi!");
//     org.jfree.chart.util.Layer var14 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var15 = null;
//     var2.drawAnnotations(var3, var4, var5, (org.jfree.chart.axis.ValueAxis)var7, var14, var15);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 0, var2);
// 
//   }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = null;
//     org.jfree.data.time.TimeSeries var9 = null;
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var18 = null;
//     var16.setSeriesOutlinePaint(0, var18);
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     org.jfree.chart.plot.XYPlot var22 = null;
//     org.jfree.data.time.TimeSeries var23 = null;
//     java.util.TimeZone var24 = null;
//     org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var27 = var16.initialise(var20, var21, var22, (org.jfree.data.xy.XYDataset)var25, var26);
//     var13.endSeriesPass((org.jfree.data.xy.XYDataset)var25, 0, 10, 10, 1, 100);
//     
//     // Checks the contract:  equals-hashcode on var11 and var25
//     assertTrue("Contract failed: equals-hashcode on var11 and var25", var11.equals(var25) ? var11.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var11
//     assertTrue("Contract failed: equals-hashcode on var25 and var11", var25.equals(var11) ? var25.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1, 10.0f, (-1.0f), (-1.0d), 0.0f, 100.0f);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.lang.Object var0 = null;
    org.jfree.data.general.SeriesChangeInfo var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.setMaximumItemCount((-1));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test56() {}
//   public void test56() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var7 = var6.getColorSpace();
    float[] var11 = new float[] { 100.0f, 0.0f, 0.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var2.getComponents(var7, var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.renderer.category.BarPainter var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var2.getSeriesKey(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test60() {}
//   public void test60() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setRangeAxisLocation(1, var38, true);
//     org.jfree.chart.event.PlotChangeListener var41 = null;
//     var36.addChangeListener(var41);
//     java.awt.Paint var43 = var36.getRangeCrosshairPaint();
//     var15.setNoDataMessagePaint(var43);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("");
//     double var55 = var54.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var58 = new org.jfree.chart.entity.AxisEntity(var52, (org.jfree.chart.axis.Axis)var54, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var45, (org.jfree.chart.axis.CategoryAxis)var47, (org.jfree.chart.axis.ValueAxis)var54, var59);
//     org.jfree.chart.axis.AxisLocation var62 = null;
//     var60.setRangeAxisLocation(1, var62, false);
//     int var65 = var60.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var66 = null;
//     org.jfree.chart.axis.CategoryAxis3D var68 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var70, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var75 = new org.jfree.chart.axis.DateAxis("");
//     double var76 = var75.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var79 = new org.jfree.chart.entity.AxisEntity(var73, (org.jfree.chart.axis.Axis)var75, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var80 = null;
//     org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var66, (org.jfree.chart.axis.CategoryAxis)var68, (org.jfree.chart.axis.ValueAxis)var75, var80);
//     org.jfree.chart.axis.AxisLocation var83 = null;
//     var81.setRangeAxisLocation(1, var83, true);
//     org.jfree.chart.event.PlotChangeListener var86 = null;
//     var81.addChangeListener(var86);
//     java.awt.Paint var88 = var81.getRangeCrosshairPaint();
//     var60.setNoDataMessagePaint(var88);
//     var15.setDomainGridlinePaint(var88);
//     
//     // Checks the contract:  equals-hashcode on var36 and var81
//     assertTrue("Contract failed: equals-hashcode on var36 and var81", var36.equals(var81) ? var36.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var36
//     assertTrue("Contract failed: equals-hashcode on var81 and var36", var81.equals(var36) ? var81.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     java.text.DateFormat var2 = null;
//     org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(var0, 1, var2);
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = var0.getHorizontalAlignment();
    java.awt.Graphics2D var2 = null;
    org.jfree.data.Range var4 = null;
    org.jfree.chart.block.RectangleConstraint var5 = new org.jfree.chart.block.RectangleConstraint(100.0d, var4);
    java.lang.String var6 = var5.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var7 = var0.arrange(var2, var5);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]"+ "'", var6.equals("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]"));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.util.RectangleInsets var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setAxisOffset(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBasePositiveItemLabelPosition(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    java.awt.Color var1 = org.jfree.chart.util.PaintUtilities.stringToColor("January 0");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var35 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset)var2, 13, 0.05d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var31.panDomainAxes(100.0d, var33, var34);
//     org.jfree.chart.event.RendererChangeEvent var36 = null;
//     var31.rendererChanged(var36);
// 
//   }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.plot.DatasetRenderingOrder var36 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setDatasetRenderingOrder(var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"hi!", 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.axis.AxisLocation var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setRangeAxisLocation(var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    var1.setLabelURL("hi!");
    java.awt.Font var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test75() {}
//   public void test75() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.clipLine(var0, var1);
// 
//   }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    var2.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    java.awt.Font var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelFont((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator(var0);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, 100.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    boolean var5 = var2.getDrawOutlines();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.plot.Marker var24 = null;
    org.jfree.chart.util.Layer var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var26 = var15.removeRangeMarker(var24, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.data.general.PieDataset var0 = null;
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, var1, 100.0d, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var15 = var11.getSeriesKey((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var6 = var2.getItemCreateEntity((-1), 13, true);
//     java.awt.Shape var8 = var2.getLegendShape(100);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var14, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
//     double var20 = var19.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var23 = new org.jfree.chart.entity.AxisEntity(var17, (org.jfree.chart.axis.Axis)var19, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var12, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.LegendItemCollection var26 = var25.getLegendItems();
//     java.awt.Stroke var27 = var25.getRangeGridlineStroke();
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     double var30 = var29.getUpperMargin();
//     var29.setAutoRangeMinimumSize(0.05d, true);
//     boolean var34 = var29.isPositiveArrowVisible();
//     java.awt.geom.Rectangle2D var35 = null;
//     java.awt.Color var39 = java.awt.Color.getColor("hi!", 1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var44 = null;
//     var42.setSeriesOutlinePaint(0, var44);
//     var42.setUseOutlinePaint(true);
//     var42.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var51 = var42.getBaseStroke();
//     var2.drawRangeLine(var9, var25, (org.jfree.chart.axis.ValueAxis)var29, var35, 0.0d, (java.awt.Paint)var39, var51);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesFilled((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test85() {}
//   public void test85() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var2.setLine(var4);
//     org.jfree.chart.entity.AxisLabelEntity var8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var4, "", "");
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
//     double var23 = var22.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var15, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setRangeAxisLocation(1, var30, true);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var28.addChangeListener(var33);
//     java.awt.Paint var35 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var36 = var28.getRangeAxisEdge();
//     java.util.List var37 = var0.refreshTicks(var9, var11, var12, var36);
// 
//   }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    java.awt.Font var1 = null;
    java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var3, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    double var9 = var8.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var12 = new org.jfree.chart.entity.AxisEntity(var6, (org.jfree.chart.axis.Axis)var8, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var17 = var15.lookupSeriesFillPaint(1);
    var8.setTickLabelPaint(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var19 = org.jfree.chart.text.TextUtilities.createTextBlock("January 0", var1, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     double var2 = var1.getUpperMargin();
//     var1.setAutoRangeMinimumSize(0.05d, true);
//     var1.setRangeAboutValue(100.0d, 100.0d);
//     org.jfree.chart.axis.DateTickUnit var9 = null;
//     java.util.Date var10 = var1.calculateLowestVisibleTickValue(var9);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     int var35 = var31.getDatasetCount();
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
//     double var47 = var46.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var50 = new org.jfree.chart.entity.AxisEntity(var44, (org.jfree.chart.axis.Axis)var46, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var55 = var53.lookupSeriesFillPaint(1);
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "", "January 0", "", var44, var55);
//     var31.setDomainGridlinePaint(var55);
//     
//     // Checks the contract:  equals-hashcode on var53 and var17
//     assertTrue("Contract failed: equals-hashcode on var53 and var17", var53.equals(var17) ? var53.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var53 and var17.", var53.equals(var17) == var17.equals(var53));
// 
//   }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getStartY(100, (-459));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var34 = var2.getEndY(1, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     java.awt.geom.Line2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.LineUtilities.clipLine(var0, var1);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     java.awt.Graphics2D var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     org.jfree.chart.plot.PlotState var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     var31.draw(var35, var36, var37, var38, var39);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var15 = var11.getItemCount((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.expand(var0, Double.NaN, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var16 = var11.getStartYValue(100, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getInstance(var0);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getY((-1), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("January 0", var1);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    var31.clearDomainMarkers();
    java.util.List var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.mapDatasetToRangeAxes((-459), var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getY(10, (-459));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test101() {}
//   public void test101() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     java.text.NumberFormat var1 = var0.getNumberFormatOverride();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var19.addChangeListener(var24);
//     java.awt.Paint var26 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var27 = var19.getRangeAxisEdge();
//     double var28 = var0.exponentLengthToJava2D(4.0d, var3, var27);
// 
//   }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var8.setLine(var10);
//     org.jfree.data.general.PieDataset var12 = null;
//     org.jfree.chart.entity.PieSectionEntity var18 = new org.jfree.chart.entity.PieSectionEntity(var10, var12, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var2.setLegendShape(0, var10);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var24 = null;
//     var22.setSeriesOutlinePaint(0, var24);
//     var22.setUseOutlinePaint(true);
//     org.jfree.chart.urls.XYURLGenerator var29 = null;
//     var22.setSeriesURLGenerator(0, var29, true);
//     org.jfree.data.time.TimeSeries var32 = null;
//     java.util.TimeZone var33 = null;
//     org.jfree.data.time.TimeSeriesCollection var34 = new org.jfree.data.time.TimeSeriesCollection(var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     double var43 = var42.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var40, (org.jfree.chart.axis.Axis)var42, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var51 = null;
//     var49.setSeriesOutlinePaint(0, var51);
//     java.awt.Paint var54 = var49.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var57.setLine(var59);
//     var49.setSeriesShape(0, var59, true);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var34, var35, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.renderer.xy.XYItemRenderer)var49);
//     org.jfree.chart.axis.AxisLocation var65 = null;
//     var63.setRangeAxisLocation(13, var65);
//     var22.setPlot(var63);
//     boolean var68 = var2.equals((java.lang.Object)var22);
//     
//     // Checks the contract:  equals-hashcode on var8 and var57
//     assertTrue("Contract failed: equals-hashcode on var8 and var57", var8.equals(var57) ? var8.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var8
//     assertTrue("Contract failed: equals-hashcode on var57 and var8", var57.equals(var8) ? var57.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
    org.jfree.chart.plot.CategoryMarker var18 = null;
    org.jfree.chart.util.Layer var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addDomainMarker(1, var18, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.RectangleInsets var36 = var31.getAxisOffset();
    double var38 = var36.calculateBottomOutset(Double.NaN);
    java.awt.geom.Rectangle2D var39 = null;
    org.jfree.chart.util.LengthAdjustmentType var40 = null;
    org.jfree.chart.util.LengthAdjustmentType var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var42 = var36.createAdjustedRectangle(var39, var40, var41);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4.0d);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    var1.setRange(var5, false, true);
    var1.resizeRange(0.0d, 0.0d);
    java.util.Date var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinimumDate(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     var2.setUseOutlinePaint(true);
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     var2.setSeriesURLGenerator(0, var9, true);
//     org.jfree.data.time.TimeSeries var12 = null;
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
//     double var23 = var22.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var31 = null;
//     var29.setSeriesOutlinePaint(0, var31);
//     java.awt.Paint var34 = var29.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var37.setLine(var39);
//     var29.setSeriesShape(0, var39, true);
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setRangeAxisLocation(13, var45);
//     var2.setPlot(var43);
//     org.jfree.chart.plot.PlotRenderingInfo var49 = null;
//     java.awt.geom.Point2D var50 = null;
//     var43.zoomRangeAxes(4.0d, var49, var50);
//     org.jfree.data.category.CategoryDataset var52 = null;
//     org.jfree.chart.axis.CategoryAxis3D var54 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var56, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var61 = new org.jfree.chart.axis.DateAxis("");
//     double var62 = var61.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var65 = new org.jfree.chart.entity.AxisEntity(var59, (org.jfree.chart.axis.Axis)var61, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var66 = null;
//     org.jfree.chart.plot.CategoryPlot var67 = new org.jfree.chart.plot.CategoryPlot(var52, (org.jfree.chart.axis.CategoryAxis)var54, (org.jfree.chart.axis.ValueAxis)var61, var66);
//     org.jfree.chart.axis.AxisLocation var69 = null;
//     var67.setRangeAxisLocation(1, var69, true);
//     org.jfree.chart.event.PlotChangeListener var72 = null;
//     var67.addChangeListener(var72);
//     java.awt.Paint var74 = var67.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var75 = var67.getDomainGridlinePosition();
//     org.jfree.chart.renderer.category.BarRenderer3D var78 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var78.setShadowVisible(false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var84 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var86 = null;
//     var84.setSeriesOutlinePaint(0, var86);
//     var84.setUseOutlinePaint(true);
//     var84.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var93 = var84.getBaseStroke();
//     var78.setSeriesOutlineStroke(100, var93, false);
//     var67.setOutlineStroke(var93);
//     var43.setOutlineStroke(var93);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var2 and var84.", var2.equals(var84) == var84.equals(var2));
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var19.addChangeListener(var24);
//     java.awt.Paint var26 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var27 = var19.getDomainGridlinePosition();
//     var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var19);
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
//     double var39 = var38.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var42 = new org.jfree.chart.entity.AxisEntity(var36, (org.jfree.chart.axis.Axis)var38, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var29, (org.jfree.chart.axis.CategoryAxis)var31, (org.jfree.chart.axis.ValueAxis)var38, var43);
//     org.jfree.chart.axis.AxisLocation var46 = null;
//     var44.setRangeAxisLocation(1, var46, false);
//     int var49 = var44.getRangeAxisCount();
//     var44.setForegroundAlpha(10.0f);
//     org.jfree.data.category.CategoryDataset var53 = var44.getDataset(100);
//     org.jfree.data.category.CategoryDataset var54 = null;
//     org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var58, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
//     double var64 = var63.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var67 = new org.jfree.chart.entity.AxisEntity(var61, (org.jfree.chart.axis.Axis)var63, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var54, (org.jfree.chart.axis.CategoryAxis)var56, (org.jfree.chart.axis.ValueAxis)var63, var68);
//     org.jfree.chart.LegendItemCollection var70 = var69.getLegendItems();
//     java.awt.Stroke var71 = var69.getRangeGridlineStroke();
//     var44.setRangeGridlineStroke(var71);
//     var19.setRangeMinorGridlineStroke(var71);
//     
//     // Checks the contract:  equals-hashcode on var19 and var69
//     assertTrue("Contract failed: equals-hashcode on var19 and var69", var19.equals(var69) ? var19.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var19
//     assertTrue("Contract failed: equals-hashcode on var69 and var19", var69.equals(var19) ? var69.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
//     var2.setBaseItemLabelGenerator(var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var2.getURLGenerator(100, 13, false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(1, var33, true);
//     org.jfree.chart.event.PlotChangeListener var36 = null;
//     var31.addChangeListener(var36);
//     org.jfree.chart.axis.AxisSpace var38 = null;
//     var31.setFixedDomainAxisSpace(var38);
//     org.jfree.chart.axis.CategoryAxis var40 = null;
//     org.jfree.data.time.TimeSeries var41 = null;
//     java.util.TimeZone var42 = null;
//     org.jfree.data.time.TimeSeriesCollection var43 = new org.jfree.data.time.TimeSeriesCollection(var41, var42);
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var46, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var51 = new org.jfree.chart.axis.DateAxis("");
//     double var52 = var51.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var55 = new org.jfree.chart.entity.AxisEntity(var49, (org.jfree.chart.axis.Axis)var51, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var60 = null;
//     var58.setSeriesOutlinePaint(0, var60);
//     java.awt.Paint var63 = var58.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var68 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var66.setLine(var68);
//     var58.setSeriesShape(0, var68, true);
//     org.jfree.chart.plot.XYPlot var72 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var43, var44, (org.jfree.chart.axis.ValueAxis)var51, (org.jfree.chart.renderer.xy.XYItemRenderer)var58);
//     org.jfree.data.category.CategoryDataset var73 = null;
//     var2.drawItem(var13, var14, var15, var31, var40, var44, var73, (-459), 0, true, 0);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var5);
    java.awt.Font var8 = var7.getLabelFont();
    java.awt.Paint var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.LabelBlock var10 = new org.jfree.chart.block.LabelBlock("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test110() {}
//   public void test110() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var31.panDomainAxes(100.0d, var33, var34);
//     org.jfree.chart.util.RectangleInsets var36 = var31.getAxisOffset();
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     java.awt.geom.Point2D var39 = null;
//     org.jfree.chart.plot.PlotState var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var31.draw(var37, var38, var39, var40, var41);
// 
//   }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { "hi!"};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("January 0", var2);
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var21.setRangeAxisLocation(1, var23, true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var21.addChangeListener(var26);
//     java.awt.Paint var28 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var29 = var21.getRangeAxisEdge();
//     double var30 = var3.valueToJava2D(0.2d, var5, var29);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.getEndYValue(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, 100.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
//     double var9 = var8.getUpperMargin();
//     var5.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var9);
//     java.awt.Paint var11 = null;
//     java.awt.Paint[] var12 = new java.awt.Paint[] { var11};
//     java.awt.Paint var13 = null;
//     java.awt.Paint[] var14 = new java.awt.Paint[] { var13};
//     java.awt.Stroke var15 = null;
//     java.awt.Stroke[] var16 = new java.awt.Stroke[] { var15};
//     java.awt.Stroke var17 = null;
//     java.awt.Stroke[] var18 = new java.awt.Stroke[] { var17};
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape[] var21 = new java.awt.Shape[] { var20};
//     org.jfree.chart.plot.DefaultDrawingSupplier var22 = new org.jfree.chart.plot.DefaultDrawingSupplier(var12, var14, var16, var18, var21);
//     boolean var23 = var5.equals((java.lang.Object)var14);
//     java.awt.Paint var24 = null;
//     java.awt.Paint[] var25 = new java.awt.Paint[] { var24};
//     java.awt.Paint var26 = null;
//     java.awt.Paint[] var27 = new java.awt.Paint[] { var26};
//     java.awt.Stroke var28 = null;
//     java.awt.Stroke[] var29 = new java.awt.Stroke[] { var28};
//     java.awt.Stroke var30 = null;
//     java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
//     org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var25, var27, var29, var31, var34);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
//     double var46 = var45.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var49 = new org.jfree.chart.entity.AxisEntity(var43, (org.jfree.chart.axis.Axis)var45, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var36, (org.jfree.chart.axis.CategoryAxis)var38, (org.jfree.chart.axis.ValueAxis)var45, var50);
//     org.jfree.chart.axis.AxisLocation var53 = null;
//     var51.setRangeAxisLocation(1, var53, true);
//     org.jfree.chart.event.PlotChangeListener var56 = null;
//     var51.addChangeListener(var56);
//     java.awt.Paint var58 = var51.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var59 = var51.getDomainGridlinePosition();
//     org.jfree.chart.renderer.category.BarRenderer3D var62 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var62.setShadowVisible(false);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var68 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var70 = null;
//     var68.setSeriesOutlinePaint(0, var70);
//     var68.setUseOutlinePaint(true);
//     var68.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var77 = var68.getBaseStroke();
//     var62.setSeriesOutlineStroke(100, var77, false);
//     var51.setOutlineStroke(var77);
//     java.awt.Stroke[] var81 = new java.awt.Stroke[] { var77};
//     org.jfree.chart.LegendItem var83 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var85 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var83.setLine(var85);
//     java.awt.Shape[] var87 = new java.awt.Shape[] { var85};
//     org.jfree.chart.plot.DefaultDrawingSupplier var88 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var14, var29, var81, var87);
//     
//     // Checks the contract:  equals-hashcode on var22 and var35
//     assertTrue("Contract failed: equals-hashcode on var22 and var35", var22.equals(var35) ? var22.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var22
//     assertTrue("Contract failed: equals-hashcode on var35 and var22", var35.equals(var22) ? var35.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1, var2);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var23 = var15.getDomainGridlinePosition();
    org.jfree.chart.plot.CategoryMarker var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addDomainMarker(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

//  public void test116() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var2.getStartX(0, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var4);
    java.awt.Paint var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setPaint(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { "hi!"};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("January 0", var2);
//     var3.setAutoRangeStickyZero(false);
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     double var18 = var17.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var21 = new org.jfree.chart.entity.AxisEntity(var15, (org.jfree.chart.axis.Axis)var17, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var8, (org.jfree.chart.axis.CategoryAxis)var10, (org.jfree.chart.axis.ValueAxis)var17, var22);
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setRangeAxisLocation(1, var25, true);
//     org.jfree.chart.event.PlotChangeListener var28 = null;
//     var23.addChangeListener(var28);
//     java.awt.Paint var30 = var23.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var31 = var23.getRangeAxisEdge();
//     boolean var32 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var31);
//     double var33 = var3.valueToJava2D(0.05d, var7, var31);
// 
//   }

//  public void test120() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (java.lang.Comparable)100.0f);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.RectangleInsets var36 = var31.getAxisOffset();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var38 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    boolean var39 = var36.equals((java.lang.Object)"RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setRangeZeroBaselineVisible(false);
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeGridlinePaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Oct"+ "'", var2.equals("Oct"));

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setRangeAxisLocation(1, var38, true);
//     org.jfree.chart.event.PlotChangeListener var41 = null;
//     var36.addChangeListener(var41);
//     java.awt.Paint var43 = var36.getRangeCrosshairPaint();
//     var15.setNoDataMessagePaint(var43);
//     var15.zoom((-1.0d));
//     var15.setRangePannable(true);
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var53, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("");
//     double var59 = var58.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var62 = new org.jfree.chart.entity.AxisEntity(var56, (org.jfree.chart.axis.Axis)var58, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
//     org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var49, (org.jfree.chart.axis.CategoryAxis)var51, (org.jfree.chart.axis.ValueAxis)var58, var63);
//     org.jfree.chart.axis.AxisLocation var66 = null;
//     var64.setRangeAxisLocation(1, var66, true);
//     org.jfree.chart.event.PlotChangeListener var69 = null;
//     var64.addChangeListener(var69);
//     java.awt.Paint var71 = var64.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var72 = var64.getDomainGridlinePosition();
//     var15.setDomainGridlinePosition(var72);
//     
//     // Checks the contract:  equals-hashcode on var36 and var64
//     assertTrue("Contract failed: equals-hashcode on var36 and var64", var36.equals(var64) ? var36.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var36
//     assertTrue("Contract failed: equals-hashcode on var64 and var36", var64.equals(var36) ? var64.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var2.setSeriesURLGenerator(0, var9, true);
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    double var23 = var22.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var31 = null;
    var29.setSeriesOutlinePaint(0, var31);
    java.awt.Paint var34 = var29.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var37.setLine(var39);
    var29.setSeriesShape(0, var39, true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setRangeAxisLocation(13, var45);
    var2.setPlot(var43);
    org.jfree.chart.plot.PlotRenderingInfo var49 = null;
    java.awt.geom.Point2D var50 = null;
    var43.zoomRangeAxes(4.0d, var49, var50);
    var43.clearRangeMarkers(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    java.util.Date var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumDate(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     org.jfree.chart.axis.ValueAxis var36 = var31.getRangeAxis(10);
//     org.jfree.data.time.TimeSeriesCollection var37 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.chart.axis.AxisState var39 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var40 = var39.getTicks();
//     java.util.Collection var41 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var40);
//     org.jfree.data.Range var42 = null;
//     org.jfree.data.Range var44 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var37, var40, var42, false);
//     var31.setDataset((org.jfree.data.xy.XYDataset)var37);
//     
//     // Checks the contract:  equals-hashcode on var2 and var37
//     assertTrue("Contract failed: equals-hashcode on var2 and var37", var2.equals(var37) ? var2.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var2
//     assertTrue("Contract failed: equals-hashcode on var37 and var2", var37.equals(var2) ? var37.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     var2.setUseOutlinePaint(true);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.data.time.TimeSeries var10 = null;
//     java.util.TimeZone var11 = null;
//     org.jfree.data.time.TimeSeriesCollection var12 = new org.jfree.data.time.TimeSeriesCollection(var10, var11);
//     org.jfree.chart.axis.ValueAxis var13 = null;
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("");
//     double var21 = var20.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var24 = new org.jfree.chart.entity.AxisEntity(var18, (org.jfree.chart.axis.Axis)var20, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var29 = null;
//     var27.setSeriesOutlinePaint(0, var29);
//     java.awt.Paint var32 = var27.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var35.setLine(var37);
//     var27.setSeriesShape(0, var37, true);
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var12, var13, (org.jfree.chart.axis.ValueAxis)var20, (org.jfree.chart.renderer.xy.XYItemRenderer)var27);
//     org.jfree.chart.axis.AxisLocation var43 = null;
//     var41.setRangeAxisLocation(13, var43);
//     var41.mapDatasetToRangeAxis(1, 13);
//     org.jfree.data.time.TimeSeries var48 = null;
//     java.util.TimeZone var49 = null;
//     org.jfree.data.time.TimeSeriesCollection var50 = new org.jfree.data.time.TimeSeriesCollection(var48, var49);
//     org.jfree.chart.axis.ValueAxis var51 = null;
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var53, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("");
//     double var59 = var58.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var62 = new org.jfree.chart.entity.AxisEntity(var56, (org.jfree.chart.axis.Axis)var58, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var67 = null;
//     var65.setSeriesOutlinePaint(0, var67);
//     java.awt.Paint var70 = var65.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var75 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var73.setLine(var75);
//     var65.setSeriesShape(0, var75, true);
//     org.jfree.chart.plot.XYPlot var79 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var50, var51, (org.jfree.chart.axis.ValueAxis)var58, (org.jfree.chart.renderer.xy.XYItemRenderer)var65);
//     org.jfree.chart.plot.PlotRenderingInfo var80 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var81 = var2.initialise(var8, var9, var41, (org.jfree.data.xy.XYDataset)var50, var80);
//     
//     // Checks the contract:  equals-hashcode on var12 and var50
//     assertTrue("Contract failed: equals-hashcode on var12 and var50", var12.equals(var50) ? var12.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var12
//     assertTrue("Contract failed: equals-hashcode on var50 and var12", var50.equals(var12) ? var50.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var73
//     assertTrue("Contract failed: equals-hashcode on var35 and var73", var35.equals(var73) ? var35.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var35
//     assertTrue("Contract failed: equals-hashcode on var73 and var35", var73.equals(var35) ? var73.hashCode() == var35.hashCode() : true);
// 
//   }

  public void test132() {}
//   public void test132() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
//     var2.setBaseItemLabelGenerator(var6, false);
//     org.jfree.chart.urls.CategoryURLGenerator var12 = var2.getURLGenerator(100, 13, false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("");
//     double var24 = var23.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var27 = new org.jfree.chart.entity.AxisEntity(var21, (org.jfree.chart.axis.Axis)var23, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var14, (org.jfree.chart.axis.CategoryAxis)var16, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setRangeAxisLocation(1, var31, true);
//     java.awt.geom.Rectangle2D var34 = null;
//     var2.drawOutline(var13, var29, var34);
// 
//   }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("RectangleConstraintType.RANGE");

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
    boolean var2 = var1.isParseIntegerOnly();
    java.text.NumberFormat var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     long var3 = var2.getLastMillisecond();
//     java.util.Calendar var4 = null;
//     long var5 = var2.getLastMillisecond(var4);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getStartY(13, 13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));

  }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ThreadContext", var1, var2);
// 
//   }

  public void test138() {}
//   public void test138() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var2.setShadowVisible(false);
//     java.awt.Graphics2D var5 = null;
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     org.jfree.chart.LegendItemCollection var22 = var21.getLegendItems();
//     java.awt.Stroke var23 = var21.getRangeGridlineStroke();
//     org.jfree.chart.util.Layer var25 = null;
//     java.util.Collection var26 = var21.getRangeMarkers(0, var25);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     var21.setRenderer(0, var28);
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var36 = var32.getItemCreateEntity((-1), 13, true);
//     var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
//     java.awt.geom.Rectangle2D var38 = null;
//     var2.drawDomainGridline(var5, var21, var38, 10.0d);
// 
//   }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
//     var2.setBaseItemLabelGenerator(var6, false);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(13, var10, false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.data.category.CategoryDataset var14 = null;
//     org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var18, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("");
//     double var24 = var23.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var27 = new org.jfree.chart.entity.AxisEntity(var21, (org.jfree.chart.axis.Axis)var23, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var28 = null;
//     org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var14, (org.jfree.chart.axis.CategoryAxis)var16, (org.jfree.chart.axis.ValueAxis)var23, var28);
//     org.jfree.chart.axis.AxisLocation var31 = null;
//     var29.setRangeAxisLocation(1, var31, true);
//     org.jfree.chart.event.PlotChangeListener var34 = null;
//     var29.addChangeListener(var34);
//     java.awt.Paint var36 = var29.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var37 = var29.getDomainGridlinePosition();
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.event.AxisChangeEvent var40 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var39);
//     var29.setDomainAxis(10, var39);
//     java.lang.Object var42 = var29.clone();
//     java.awt.geom.Rectangle2D var43 = null;
//     var2.drawDomainGridline(var13, var29, var43, 1.0d);
// 
//   }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
//     org.jfree.data.category.CategoryDataset var17 = null;
//     org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     double var27 = var26.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var30 = new org.jfree.chart.entity.AxisEntity(var24, (org.jfree.chart.axis.Axis)var26, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var17, (org.jfree.chart.axis.CategoryAxis)var19, (org.jfree.chart.axis.ValueAxis)var26, var31);
//     org.jfree.chart.LegendItemCollection var33 = var32.getLegendItems();
//     var16.addAll(var33);
//     
//     // Checks the contract:  equals-hashcode on var15 and var32
//     assertTrue("Contract failed: equals-hashcode on var15 and var32", var15.equals(var32) ? var15.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var15
//     assertTrue("Contract failed: equals-hashcode on var32 and var15", var32.equals(var15) ? var32.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var33
//     assertTrue("Contract failed: equals-hashcode on var16 and var33", var16.equals(var33) ? var16.hashCode() == var33.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var33 and var16
//     assertTrue("Contract failed: equals-hashcode on var33 and var16", var33.equals(var16) ? var33.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Paint var7 = var2.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var10.setLine(var12);
    var2.setSeriesShape(0, var12, true);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var12);
    java.awt.Shape var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var16.setArea(var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var5 = null;
//     var3.setSeriesOutlinePaint(0, var5);
//     var3.setUseOutlinePaint(true);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var24 = var22.lookupSeriesFillPaint(1);
//     var15.setTickLabelPaint(var24);
//     java.awt.Paint var26 = var15.getTickMarkPaint();
//     var3.setBaseFillPaint(var26, false);
//     var0.setBackgroundPaint(var26);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.chart.util.Size2D var31 = var0.arrange(var30);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var3 = var2.getNumberFormatOverride();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    java.text.NumberFormat var6 = var5.getPercentFormat();
    var2.setNumberFormatOverride(var6);
    var2.zoomRange(0.2d, (-1.0d));
    boolean var11 = var1.equals((java.lang.Object)(-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", "hi!");
    var4.setCopyright("RectangleConstraintType.RANGE");

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.CategoryMarker var25 = null;
    org.jfree.chart.util.Layer var26 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addDomainMarker(0, var25, var26, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("hi!", var1);
// 
//   }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { "hi!"};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("January 0", var2);
//     var3.setAutoRangeStickyZero(false);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.axis.AxisState var8 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var9 = var8.getTicks();
//     var8.cursorLeft(Double.NaN);
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
//     double var23 = var22.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var15, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setRangeAxisLocation(1, var30, true);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var28.addChangeListener(var33);
//     java.awt.Paint var35 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var36 = var28.getRangeAxisEdge();
//     var8.moveCursor(10.0d, var36);
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("");
//     double var49 = var48.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var52 = new org.jfree.chart.entity.AxisEntity(var46, (org.jfree.chart.axis.Axis)var48, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var39, (org.jfree.chart.axis.CategoryAxis)var41, (org.jfree.chart.axis.ValueAxis)var48, var53);
//     org.jfree.chart.axis.AxisLocation var56 = null;
//     var54.setRangeAxisLocation(1, var56, true);
//     org.jfree.chart.event.PlotChangeListener var59 = null;
//     var54.addChangeListener(var59);
//     java.awt.Paint var61 = var54.getRangeCrosshairPaint();
//     var54.zoom((-1.0d));
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     java.awt.geom.Point2D var66 = null;
//     var54.panRangeAxes(Double.NaN, var65, var66);
//     org.jfree.chart.util.RectangleEdge var68 = var54.getRangeAxisEdge();
//     java.util.List var69 = var3.refreshTicks(var6, var8, var38, var68);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    var15.setForegroundAlpha(10.0f);
    org.jfree.data.category.CategoryDataset var24 = var15.getDataset(100);
    org.jfree.chart.annotations.CategoryAnnotation var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.addAnnotation(var25, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)0.0d, Double.NaN);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }


    org.jfree.chart.util.UnitType var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleInsets var5 = new org.jfree.chart.util.RectangleInsets(var0, 1.0d, 100.0d, 4.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("AxisLabelEntity: label = null", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.JFreeChart var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var6 = new org.jfree.chart.entity.JFreeChartEntity(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test155() {}
//   public void test155() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.Date var1 = null;
//     org.jfree.data.time.DateRange var2 = new org.jfree.data.time.DateRange(var0, var1);
// 
//   }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var2.setSeriesURLGenerator(0, var9, true);
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    double var23 = var22.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var31 = null;
    var29.setSeriesOutlinePaint(0, var31);
    java.awt.Paint var34 = var29.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var37.setLine(var39);
    var29.setSeriesShape(0, var39, true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setRangeAxisLocation(13, var45);
    var2.setPlot(var43);
    int var48 = var43.getSeriesCount();
    org.jfree.chart.axis.AxisState var51 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var52 = var51.getTicks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var43.mapDatasetToDomainAxes((-1), var52);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.net.URL var0 = null;
//     java.net.URLClassLoader var1 = null;
//     org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(var0, var1);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    java.text.NumberFormat var34 = java.text.NumberFormat.getInstance();
    java.text.DateFormat var35 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var36 = new org.jfree.chart.labels.StandardXYToolTipGenerator("January 0", var34, var35);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setSeriesToolTipGenerator((-1), (org.jfree.chart.labels.XYToolTipGenerator)var36);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
    org.jfree.chart.plot.DrawingSupplier var29 = null;
    var15.setDrawingSupplier(var29);
    var15.setDomainCrosshairColumnKey((java.lang.Comparable)(short)0, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getEndY((-1), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((-1.0d), (-1.0d), var2);
// 
//   }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("TitleEntity: tooltip = AxisLabelEntity: label = null", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     double var2 = var1.getUpperMargin();
//     var1.setAutoRangeMinimumSize(0.05d, true);
//     var1.setRangeAboutValue(100.0d, 100.0d);
//     int var9 = var1.getMinorTickCount();
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.axis.AxisState var13 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var14 = var13.getTicks();
//     var13.cursorLeft(Double.NaN);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
//     double var28 = var27.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var20, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var33.setRangeAxisLocation(1, var35, true);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var33.addChangeListener(var38);
//     java.awt.Paint var40 = var33.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var41 = var33.getRangeAxisEdge();
//     var13.moveCursor(10.0d, var41);
//     double var43 = var1.valueToJava2D(100.0d, var11, var41);
// 
//   }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var15.setFixedDomainAxisSpace(var22);
//     org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
//     double var25 = var24.getUpperMargin();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.AxisState var28 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var29 = var28.getTicks();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     var31.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var39, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
//     double var45 = var44.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var48 = new org.jfree.chart.entity.AxisEntity(var42, (org.jfree.chart.axis.Axis)var44, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var35, (org.jfree.chart.axis.CategoryAxis)var37, (org.jfree.chart.axis.ValueAxis)var44, var49);
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var50.setRangeAxisLocation(1, var52, true);
//     org.jfree.chart.event.PlotChangeListener var55 = null;
//     var50.addChangeListener(var55);
//     java.awt.Paint var57 = var50.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var58 = var50.getRangeAxisEdge();
//     boolean var59 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var58);
//     var31.ensureAtLeast(0.0d, var58);
//     java.util.List var61 = var24.refreshTicks(var26, var28, var30, var58);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var1 = var0.getNumberFormatOverride();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    java.text.NumberFormat var4 = var3.getPercentFormat();
    var0.setNumberFormatOverride(var4);
    org.jfree.chart.axis.NumberTickUnit var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    var0.setRangeZeroBaselineVisible(false);
    org.jfree.chart.plot.PlotRenderingInfo var4 = null;
    java.awt.geom.Point2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomRangeAxes(0.0d, var4, var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("TitleEntity: tooltip = AxisLabelEntity: label = null");
    var1.setRangeWithMargins(0.0d, 4.0d);
    org.jfree.chart.axis.NumberTickUnit var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var5, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    double var1 = var0.getIntervalWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var4 = var0.isSelected((-459), 13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     var0.setRight(10.0d);
//     java.awt.geom.Rectangle2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = var0.shrink(var3, var4);
// 
//   }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.time.TimeSeriesCollection var1 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.chart.axis.AxisState var3 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var4 = var3.getTicks();
    java.util.Collection var5 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var4);
    org.jfree.data.Range var6 = null;
    org.jfree.data.Range var8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var1, var4, var6, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var10 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, var4, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var8 = null;
    var6.setSeriesOutlinePaint(0, var8);
    java.awt.Paint var11 = var6.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var14 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var14.setLine(var16);
    var6.setSeriesShape(0, var16, true);
    org.jfree.chart.entity.LegendItemEntity var20 = new org.jfree.chart.entity.LegendItemEntity(var16);
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.LegendItemCollection var37 = var36.getLegendItems();
    java.awt.Stroke var38 = var36.getRangeGridlineStroke();
    org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var40.setLine(var42);
    java.awt.Paint var44 = var40.getOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "0,100,0,100,0,100,0,100", "ThreadContext", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var16, var38, var44);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    double var6 = var5.getContentXOffset();
    org.jfree.chart.entity.TitleEntity var9 = new org.jfree.chart.entity.TitleEntity(var1, (org.jfree.chart.title.Title)var5, "AxisLabelEntity: label = null", "AxisLabelEntity: label = null");
    var5.setID("");
    var5.setVisible(false);
    java.awt.Graphics2D var14 = null;
    org.jfree.data.Range var16 = null;
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(100.0d, var16);
    double var18 = var17.getHeight();
    org.jfree.chart.block.LengthConstraintType var19 = var17.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var20 = var5.arrange(var14, var17);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test173() {}
//   public void test173() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     double var2 = var1.getUpperMargin();
//     var1.setAutoRangeMinimumSize(0.05d, true);
//     var1.setLabelURL("hi!");
//     java.awt.Shape var8 = var1.getUpArrow();
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.chart.axis.CategoryAxis3D var11 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var13, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var18 = new org.jfree.chart.axis.DateAxis("");
//     double var19 = var18.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var22 = new org.jfree.chart.entity.AxisEntity(var16, (org.jfree.chart.axis.Axis)var18, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var23 = null;
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var9, (org.jfree.chart.axis.CategoryAxis)var11, (org.jfree.chart.axis.ValueAxis)var18, var23);
//     org.jfree.chart.axis.AxisLocation var26 = null;
//     var24.setRangeAxisLocation(1, var26, true);
//     org.jfree.chart.event.PlotChangeListener var29 = null;
//     var24.addChangeListener(var29);
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     var24.setFixedDomainAxisSpace(var31);
//     org.jfree.chart.axis.CategoryAxis var33 = var24.getDomainAxis();
//     org.jfree.chart.entity.AxisEntity var35 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var33, "January 0");
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
//     double var46 = var45.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var49 = new org.jfree.chart.entity.AxisEntity(var43, (org.jfree.chart.axis.Axis)var45, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var36, (org.jfree.chart.axis.CategoryAxis)var38, (org.jfree.chart.axis.ValueAxis)var45, var50);
//     org.jfree.chart.entity.PlotEntity var53 = new org.jfree.chart.entity.PlotEntity(var8, (org.jfree.chart.plot.Plot)var51, "LegendItemEntity: seriesKey=null, dataset=null");
//     
//     // Checks the contract:  equals-hashcode on var24 and var51
//     assertTrue("Contract failed: equals-hashcode on var24 and var51", var24.equals(var51) ? var24.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var24
//     assertTrue("Contract failed: equals-hashcode on var51 and var24", var51.equals(var24) ? var51.hashCode() == var24.hashCode() : true);
// 
//   }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
//     java.text.NumberFormat var1 = var0.getNumberFormatOverride();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
//     java.text.NumberFormat var4 = var3.getPercentFormat();
//     var0.setNumberFormatOverride(var4);
//     var0.zoomRange(0.2d, (-1.0d));
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     java.awt.geom.Rectangle2D var12 = null;
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
//     double var23 = var22.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var13, (org.jfree.chart.axis.CategoryAxis)var15, (org.jfree.chart.axis.ValueAxis)var22, var27);
//     org.jfree.chart.axis.AxisLocation var30 = null;
//     var28.setRangeAxisLocation(1, var30, true);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var28.addChangeListener(var33);
//     java.awt.Paint var35 = var28.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var36 = var28.getRangeAxisEdge();
//     boolean var37 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var36);
//     java.lang.String var38 = var36.toString();
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     org.jfree.chart.axis.AxisState var40 = var0.draw(var9, 1.0d, var11, var12, var36, var39);
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    var15.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    double var28 = var27.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var20, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.AxisLocation var35 = null;
    var33.setRangeAxisLocation(1, var35, false);
    int var38 = var33.getRangeAxisCount();
    var33.setForegroundAlpha(10.0f);
    java.awt.Stroke var41 = var33.getRangeCrosshairStroke();
    java.awt.Paint var42 = var33.getDomainCrosshairPaint();
    var15.setLabelPaint(var42);
    var2.setSeriesFillPaint(1, var42, false);
    var2.setShadowVisible(true);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var51 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var53 = null;
    var51.setSeriesOutlinePaint(0, var53);
    var51.setUseOutlinePaint(true);
    var51.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var60 = var51.getBaseStroke();
    java.awt.Paint var64 = var51.getItemFillPaint((-1), 0, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesOutlinePaint((-459), var64, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    boolean var4 = var3.getNotify();
    var3.setDescription("");
    var3.add((java.lang.Number)18.0d, (java.lang.Number)10.0f, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var6 = var2.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var7 = var2.getBarPainter();
    double var8 = var2.getItemMargin();
    java.lang.Object var9 = var2.clone();
    org.jfree.chart.renderer.category.BarRenderer3D var13 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var16 = var13.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var17 = null;
    var13.setBaseItemLabelGenerator(var17, false);
    java.awt.Stroke var21 = null;
    var13.setSeriesStroke(13, var21, false);
    org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D("");
    var26.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
    double var39 = var38.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var42 = new org.jfree.chart.entity.AxisEntity(var36, (org.jfree.chart.axis.Axis)var38, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
    org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var29, (org.jfree.chart.axis.CategoryAxis)var31, (org.jfree.chart.axis.ValueAxis)var38, var43);
    org.jfree.chart.axis.AxisLocation var46 = null;
    var44.setRangeAxisLocation(1, var46, false);
    int var49 = var44.getRangeAxisCount();
    var44.setForegroundAlpha(10.0f);
    java.awt.Stroke var52 = var44.getRangeCrosshairStroke();
    java.awt.Paint var53 = var44.getDomainCrosshairPaint();
    var26.setLabelPaint(var53);
    var13.setSeriesFillPaint(1, var53, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesFillPaint((-459), var53, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var2 = var0.getSeries((java.lang.Comparable)0);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
//     org.jfree.data.time.RegularTimePeriod var3 = var2.next();
//     java.util.Calendar var4 = null;
//     var2.peg(var4);
// 
//   }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var1 = var0.getNumberFormatOverride();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    java.text.NumberFormat var4 = var3.getPercentFormat();
    var0.setNumberFormatOverride(var4);
    var0.resizeRange(1.0d);
    org.jfree.chart.axis.NumberTickUnit var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTickUnit(var8, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    double var14 = var13.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(1, var21, true);
    org.jfree.chart.event.PlotChangeListener var24 = null;
    var19.addChangeListener(var24);
    java.awt.Paint var26 = var19.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var27 = var19.getDomainGridlinePosition();
    var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var19);
    org.jfree.data.time.TimeSeries var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addSeries(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(18.0d, 10.0d, var2);
// 
//   }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("hi!");
    boolean var2 = var1.isShapeVisible();
    java.awt.Paint var3 = var1.getOutlinePaint();
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    double var14 = var13.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(1, var21, false);
    int var24 = var19.getRangeAxisCount();
    var19.setForegroundAlpha(10.0f);
    java.awt.Stroke var27 = var19.getRangeCrosshairStroke();
    java.awt.Paint var28 = var19.getDomainCrosshairPaint();
    boolean var29 = org.jfree.chart.util.PaintUtilities.equal(var3, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(13, var33);
    int var35 = var31.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
    org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!");
    boolean var40 = var39.isShapeVisible();
    java.awt.Paint var41 = var39.getOutlinePaint();
    var31.setDomainGridlinePaint(var41);
    org.jfree.chart.annotations.XYAnnotation var43 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var44 = var31.removeAnnotation(var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var2.setShadowVisible(false);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.data.category.CategoryDataset var7 = null;
//     org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var11, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var16 = new org.jfree.chart.axis.DateAxis("");
//     double var17 = var16.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var20 = new org.jfree.chart.entity.AxisEntity(var14, (org.jfree.chart.axis.Axis)var16, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var21 = null;
//     org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var7, (org.jfree.chart.axis.CategoryAxis)var9, (org.jfree.chart.axis.ValueAxis)var16, var21);
//     org.jfree.chart.axis.AxisLocation var24 = null;
//     var22.setRangeAxisLocation(1, var24, true);
//     org.jfree.chart.event.PlotChangeListener var27 = null;
//     var22.addChangeListener(var27);
//     org.jfree.chart.axis.AxisSpace var29 = null;
//     var22.setFixedDomainAxisSpace(var29);
//     org.jfree.chart.axis.CategoryAxis var31 = var22.getDomainAxis();
//     double var32 = var31.getUpperMargin();
//     double var33 = var31.getCategoryMargin();
//     var31.setCategoryMargin(10.0d);
//     org.jfree.chart.axis.LogAxis var37 = new org.jfree.chart.axis.LogAxis("TitleEntity: tooltip = AxisLabelEntity: label = null");
//     org.jfree.chart.util.Layer var38 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var39 = null;
//     var2.drawAnnotations(var5, var6, var31, (org.jfree.chart.axis.ValueAxis)var37, var38, var39);
// 
//   }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("LegendItemEntity: seriesKey=null, dataset=null", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     int var35 = var31.getDatasetCount();
//     org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!");
//     boolean var40 = var39.isShapeVisible();
//     java.awt.Paint var41 = var39.getOutlinePaint();
//     var31.setDomainGridlinePaint(var41);
//     java.awt.Graphics2D var43 = null;
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.data.time.TimeSeries var45 = null;
//     java.util.TimeZone var46 = null;
//     org.jfree.data.time.TimeSeriesCollection var47 = new org.jfree.data.time.TimeSeriesCollection(var45, var46);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var50, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var55 = new org.jfree.chart.axis.DateAxis("");
//     double var56 = var55.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var59 = new org.jfree.chart.entity.AxisEntity(var53, (org.jfree.chart.axis.Axis)var55, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var62 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var64 = null;
//     var62.setSeriesOutlinePaint(0, var64);
//     java.awt.Paint var67 = var62.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var70.setLine(var72);
//     var62.setSeriesShape(0, var72, true);
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var47, var48, (org.jfree.chart.axis.ValueAxis)var55, (org.jfree.chart.renderer.xy.XYItemRenderer)var62);
//     org.jfree.chart.axis.AxisLocation var78 = null;
//     var76.setRangeAxisLocation(13, var78);
//     int var80 = var76.getDatasetCount();
//     java.awt.geom.Point2D var81 = var76.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var82 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var83 = null;
//     var31.draw(var43, var44, var81, var82, var83);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(13, var1);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var6 = var2.getItemCreateEntity((-1), 13, true);
//     java.awt.Shape var8 = var2.getLegendShape(100);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var14, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
//     double var20 = var19.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var23 = new org.jfree.chart.entity.AxisEntity(var17, (org.jfree.chart.axis.Axis)var19, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var12, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setRangeAxisLocation(1, var27, true);
//     java.awt.geom.Rectangle2D var30 = null;
//     var2.drawBackground(var9, var25, var30);
// 
//   }

  public void test198() {}
//   public void test198() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     var0.setRight(10.0d);
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var19.addChangeListener(var24);
//     java.awt.Paint var26 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var27 = var19.getRangeAxisEdge();
//     boolean var28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var27);
//     java.lang.String var29 = var27.toString();
//     java.awt.geom.Rectangle2D var30 = var0.reserved(var3, var27);
// 
//   }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-459), var1);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries(var0, "0,100,0,100,0,100,0,100", "ThreadContext");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getEndY((-459), 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var1 = var0.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getEndX(13, 13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    var31.clearDomainMarkers();
    double var33 = var31.getDomainCrosshairValue();
    boolean var34 = var31.isDomainPannable();
    java.awt.Stroke var35 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setDomainCrosshairStroke(var35);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.axis.Axis var2 = var1.getAxis();
    org.jfree.chart.JFreeChart var3 = null;
    var1.setChart(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var10 = null;
    var8.setSeriesOutlinePaint(0, var10);
    var8.setUseOutlinePaint(true);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var18 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var15, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("");
    double var21 = var20.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var24 = new org.jfree.chart.entity.AxisEntity(var18, (org.jfree.chart.axis.Axis)var20, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var29 = var27.lookupSeriesFillPaint(1);
    var20.setTickLabelPaint(var29);
    java.awt.Paint var31 = var20.getTickMarkPaint();
    var8.setBaseFillPaint(var31, false);
    var5.setBackgroundPaint(var31);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    boolean var38 = var37.getUseOutlinePaint();
    java.awt.Paint var39 = var37.getBasePaint();
    var5.setBackgroundPaint(var39);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var45 = null;
    var43.setSeriesOutlinePaint(0, var45);
    var43.setUseOutlinePaint(true);
    var43.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var52 = var43.getBaseStroke();
    java.awt.Paint var53 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("hi!", "RectangleConstraintType.RANGE", "", "", var4, var39, var52, var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("AxisLabelEntity: label = null");

  }

  public void test207() {}
//   public void test207() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     org.jfree.chart.axis.ValueAxis var36 = var31.getRangeAxis(10);
//     org.jfree.chart.axis.AxisSpace var37 = new org.jfree.chart.axis.AxisSpace();
//     var31.setFixedDomainAxisSpace(var37);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.data.time.TimeSeries var42 = null;
//     java.util.TimeZone var43 = null;
//     org.jfree.data.time.TimeSeriesCollection var44 = new org.jfree.data.time.TimeSeriesCollection(var42, var43);
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var47, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var52 = new org.jfree.chart.axis.DateAxis("");
//     double var53 = var52.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var56 = new org.jfree.chart.entity.AxisEntity(var50, (org.jfree.chart.axis.Axis)var52, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var61 = null;
//     var59.setSeriesOutlinePaint(0, var61);
//     java.awt.Paint var64 = var59.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var67 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var67.setLine(var69);
//     var59.setSeriesShape(0, var69, true);
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var44, var45, (org.jfree.chart.axis.ValueAxis)var52, (org.jfree.chart.renderer.xy.XYItemRenderer)var59);
//     org.jfree.chart.axis.AxisLocation var75 = null;
//     var73.setRangeAxisLocation(13, var75);
//     int var77 = var73.getDatasetCount();
//     java.awt.geom.Point2D var78 = var73.getQuadrantOrigin();
//     var31.zoomDomainAxes(Double.NaN, 0.0d, var41, var78);
//     
//     // Checks the contract:  equals-hashcode on var2 and var44
//     assertTrue("Contract failed: equals-hashcode on var2 and var44", var2.equals(var44) ? var2.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var2
//     assertTrue("Contract failed: equals-hashcode on var44 and var2", var44.equals(var2) ? var44.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var67
//     assertTrue("Contract failed: equals-hashcode on var25 and var67", var25.equals(var67) ? var25.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var25
//     assertTrue("Contract failed: equals-hashcode on var67 and var25", var67.equals(var25) ? var67.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var73
//     assertTrue("Contract failed: equals-hashcode on var31 and var73", var31.equals(var73) ? var31.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var31
//     assertTrue("Contract failed: equals-hashcode on var73 and var31", var73.equals(var31) ? var73.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test208() {}
//   public void test208() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, Double.NaN, var2);
// 
//   }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    org.jfree.chart.ui.BasicProjectInfo var4 = new org.jfree.chart.ui.BasicProjectInfo("", "hi!", "RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", "hi!");
    var4.setLicenceName("");
    var4.setName("ThreadContext");

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 13);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.LegendItem var4 = new org.jfree.chart.LegendItem("hi!");
    boolean var5 = var4.isShapeVisible();
    java.awt.Paint var6 = var4.getOutlinePaint();
    var2.setDomainTickBandPaint(var6);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var10.setShadowVisible(false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var18 = null;
    var16.setSeriesOutlinePaint(0, var18);
    var16.setUseOutlinePaint(true);
    var16.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var25 = var16.getBaseStroke();
    var10.setSeriesOutlineStroke(100, var25, false);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var29, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
    double var35 = var34.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var38 = new org.jfree.chart.entity.AxisEntity(var32, (org.jfree.chart.axis.Axis)var34, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var43 = var41.lookupSeriesFillPaint(1);
    var34.setTickLabelPaint(var43);
    org.jfree.data.category.CategoryDataset var45 = null;
    org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("");
    double var55 = var54.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var58 = new org.jfree.chart.entity.AxisEntity(var52, (org.jfree.chart.axis.Axis)var54, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
    org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var45, (org.jfree.chart.axis.CategoryAxis)var47, (org.jfree.chart.axis.ValueAxis)var54, var59);
    org.jfree.chart.axis.AxisLocation var62 = null;
    var60.setRangeAxisLocation(1, var62, true);
    org.jfree.chart.event.PlotChangeListener var65 = null;
    var60.addChangeListener(var65);
    java.awt.Paint var67 = var60.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var68 = var60.getDomainGridlinePosition();
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var71.setShadowVisible(false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var77 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var79 = null;
    var77.setSeriesOutlinePaint(0, var79);
    var77.setUseOutlinePaint(true);
    var77.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var86 = var77.getBaseStroke();
    var71.setSeriesOutlineStroke(100, var86, false);
    var60.setOutlineStroke(var86);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.IntervalMarker var91 = new org.jfree.chart.plot.IntervalMarker(10.0d, Double.NaN, var6, var25, var43, var86, (-1.0f));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.update(10, (java.lang.Number)(byte)0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    double var2 = var1.getCrosshairY();
    java.awt.geom.Point2D var3 = var1.getAnchor();
    double var4 = var1.getAnchorX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    double var7 = var6.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var10 = new org.jfree.chart.entity.AxisEntity(var4, (org.jfree.chart.axis.Axis)var6, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    double var13 = var12.getUpperMargin();
    var12.setAutoRangeMinimumSize(0.05d, true);
    java.text.DateFormat var17 = null;
    var12.setDateFormatOverride(var17);
    boolean var19 = var10.equals((java.lang.Object)var12);
    var10.setURLText("RectangleConstraintType.RANGE");
    var10.setURLText("RectangleEdge.LEFT");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("LegendItemEntity: seriesKey=null, dataset=null", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var11 = var2.getBaseStroke();
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    double var23 = var22.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var31 = null;
    var29.setSeriesOutlinePaint(0, var31);
    java.awt.Paint var34 = var29.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var37.setLine(var39);
    var29.setSeriesShape(0, var39, true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setRangeAxisLocation(13, var45);
    int var47 = var43.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var49 = var43.getRangeAxisLocation((-1));
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("hi!");
    boolean var52 = var51.isShapeVisible();
    java.awt.Paint var53 = var51.getOutlinePaint();
    var43.setDomainGridlinePaint(var53);
    var2.setBaseOutlinePaint(var53, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.text.TextAnchor var2 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var5 = new org.jfree.chart.axis.NumberTick((java.lang.Number)(short)1, "0,100,0,100,0,100,0,100", var2, var3, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var2.setShadowVisible(false);
//     var2.setMinimumBarLength(1.0d);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     double var18 = var17.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var21 = new org.jfree.chart.entity.AxisEntity(var15, (org.jfree.chart.axis.Axis)var17, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var8, (org.jfree.chart.axis.CategoryAxis)var10, (org.jfree.chart.axis.ValueAxis)var17, var22);
//     org.jfree.chart.axis.AxisLocation var25 = null;
//     var23.setRangeAxisLocation(1, var25, false);
//     int var28 = var23.getRangeAxisCount();
//     var23.setForegroundAlpha(10.0f);
//     java.awt.Stroke var31 = var23.getRangeCrosshairStroke();
//     java.awt.Paint var32 = var23.getDomainCrosshairPaint();
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("");
//     double var40 = var39.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var43 = new org.jfree.chart.entity.AxisEntity(var37, (org.jfree.chart.axis.Axis)var39, "hi!", "hi!");
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
//     double var46 = var45.getUpperMargin();
//     var45.setAutoRangeMinimumSize(0.05d, true);
//     java.text.DateFormat var50 = null;
//     var45.setDateFormatOverride(var50);
//     boolean var52 = var43.equals((java.lang.Object)var45);
//     java.awt.geom.Rectangle2D var53 = null;
//     var2.drawRangeGridline(var7, var23, (org.jfree.chart.axis.ValueAxis)var45, var53, 0.0d);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    java.awt.Color var4 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var5 = var4.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var6 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var4);
    org.jfree.chart.util.LengthAdjustmentType var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setLabelOffsetType(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var6 = var3.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var9.setLine(var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity(var11, var13, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var3.setLegendShape(0, var11);
//     java.awt.Font var24 = var3.getItemLabelFont((-1), 1, true);
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.text.TextMeasurer var31 = null;
//     org.jfree.chart.text.TextBlock var32 = org.jfree.chart.text.TextUtilities.createTextBlock("AxisLabelEntity: label = null", var24, (java.awt.Paint)var27, 0.0f, (-459), var31);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    java.util.ResourceBundle.clearCache();

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYItemLabelGenerator var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelGenerator((-1), var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var2.setLine(var4);
    org.jfree.chart.entity.AxisLabelEntity var8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var4, "", "");
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    double var16 = var15.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var24 = var22.lookupSeriesFillPaint(1);
    var15.setTickLabelPaint(var24);
    java.awt.Paint var26 = var15.getTickMarkPaint();
    org.jfree.chart.title.LegendGraphic var27 = new org.jfree.chart.title.LegendGraphic(var4, var26);
    org.jfree.chart.util.RectangleInsets var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.setPadding(var28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    java.lang.Number var2 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getX(0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + Double.NaN+ "'", var1.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + Double.NaN+ "'", var2.equals(Double.NaN));

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.jfree.chart.axis.DateTickUnitType var0 = null;
//     org.jfree.chart.axis.DateTickUnitType var2 = null;
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.axis.DateTickUnit var5 = new org.jfree.chart.axis.DateTickUnit(var0, 13, var2, 13, var4);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.renderer.xy.GradientXYBarPainter var3 = new org.jfree.chart.renderer.xy.GradientXYBarPainter((-1.0d), 0.05d, 0.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var5 = null;
//     java.awt.geom.RectangularShape var9 = null;
//     org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var12 = var11.getTicks();
//     var11.cursorLeft(Double.NaN);
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(1, var33, true);
//     org.jfree.chart.event.PlotChangeListener var36 = null;
//     var31.addChangeListener(var36);
//     java.awt.Paint var38 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var39 = var31.getRangeAxisEdge();
//     var11.moveCursor(10.0d, var39);
//     var3.paintBar(var4, var5, (-459), (-1), true, var9, var39);
// 
//   }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
//     org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var2.setLine(var4);
//     org.jfree.chart.entity.AxisLabelEntity var8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var4, "", "");
//     java.awt.geom.Rectangle2D var10 = null;
//     org.jfree.chart.util.RectangleEdge var11 = null;
//     double var12 = var0.valueToJava2D(Double.NaN, var10, var11);
//     java.lang.Object var13 = var0.clone();
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.axis.AxisState var15 = null;
//     java.awt.geom.Rectangle2D var16 = null;
//     org.jfree.chart.axis.AxisState var18 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var19 = var18.getTicks();
//     var18.cursorLeft(Double.NaN);
//     org.jfree.data.category.CategoryDataset var23 = null;
//     org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var27, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
//     double var33 = var32.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var36 = new org.jfree.chart.entity.AxisEntity(var30, (org.jfree.chart.axis.Axis)var32, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
//     org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var23, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var32, var37);
//     org.jfree.chart.axis.AxisLocation var40 = null;
//     var38.setRangeAxisLocation(1, var40, true);
//     org.jfree.chart.event.PlotChangeListener var43 = null;
//     var38.addChangeListener(var43);
//     java.awt.Paint var45 = var38.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var46 = var38.getRangeAxisEdge();
//     var18.moveCursor(10.0d, var46);
//     java.util.List var48 = var0.refreshTicks(var14, var15, var16, var46);
// 
//   }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)1.0f, Double.NaN, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    double var2 = var1.getCategoryMargin();
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.data.category.CategoryDataset var6 = null;
    org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    double var16 = var15.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var15, var20);
    org.jfree.chart.axis.AxisLocation var23 = null;
    var21.setRangeAxisLocation(1, var23, true);
    org.jfree.chart.event.PlotChangeListener var26 = null;
    var21.addChangeListener(var26);
    java.awt.Paint var28 = var21.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var29 = var21.getRangeAxisEdge();
    boolean var30 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var31 = var1.getCategoryMiddle(2147483647, 2147483647, var5, var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test232() {}
//   public void test232() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setRangeAxisLocation(1, var38, true);
//     org.jfree.chart.event.PlotChangeListener var41 = null;
//     var36.addChangeListener(var41);
//     java.awt.Paint var43 = var36.getRangeCrosshairPaint();
//     var15.setNoDataMessagePaint(var43);
//     var15.zoom((-1.0d));
//     org.jfree.data.category.CategoryDataset var48 = null;
//     org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("");
//     double var58 = var57.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var61 = new org.jfree.chart.entity.AxisEntity(var55, (org.jfree.chart.axis.Axis)var57, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
//     org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var48, (org.jfree.chart.axis.CategoryAxis)var50, (org.jfree.chart.axis.ValueAxis)var57, var62);
//     org.jfree.chart.axis.AxisLocation var65 = null;
//     var63.setRangeAxisLocation(1, var65, true);
//     org.jfree.chart.event.PlotChangeListener var68 = null;
//     var63.addChangeListener(var68);
//     org.jfree.chart.axis.AxisSpace var70 = null;
//     var63.setFixedDomainAxisSpace(var70);
//     org.jfree.chart.axis.CategoryAxis var72 = var63.getDomainAxis();
//     var15.setDomainAxis(0, var72);
//     
//     // Checks the contract:  equals-hashcode on var36 and var63
//     assertTrue("Contract failed: equals-hashcode on var36 and var63", var36.equals(var63) ? var36.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var36
//     assertTrue("Contract failed: equals-hashcode on var63 and var36", var63.equals(var36) ? var63.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var2.setSeriesURLGenerator(0, var9, true);
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    double var23 = var22.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var31 = null;
    var29.setSeriesOutlinePaint(0, var31);
    java.awt.Paint var34 = var29.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var37.setLine(var39);
    var29.setSeriesShape(0, var39, true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setRangeAxisLocation(13, var45);
    var2.setPlot(var43);
    int var48 = var43.getSeriesCount();
    org.jfree.chart.util.RectangleInsets var49 = var43.getAxisOffset();
    org.jfree.chart.ui.BasicProjectInfo var55 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "");
    var55.setVersion("hi!");
    boolean var58 = var49.equals((java.lang.Object)"hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    double var7 = var6.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var10 = new org.jfree.chart.entity.AxisEntity(var4, (org.jfree.chart.axis.Axis)var6, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    double var13 = var12.getUpperMargin();
    var12.setAutoRangeMinimumSize(0.05d, true);
    java.text.DateFormat var17 = null;
    var12.setDateFormatOverride(var17);
    boolean var19 = var10.equals((java.lang.Object)var12);
    java.awt.geom.Rectangle2D var21 = null;
    org.jfree.chart.util.RectangleEdge var22 = null;
    double var23 = var12.lengthToJava2D(0.0d, var21, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.0d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.data.category.CategoryDataset var17 = var15.getDataset(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     var15.setForegroundAlpha(10.0f);
//     org.jfree.data.category.CategoryDataset var24 = var15.getDataset(100);
//     org.jfree.data.category.CategoryDataset var25 = null;
//     org.jfree.chart.axis.CategoryAxis3D var27 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var29, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var34 = new org.jfree.chart.axis.DateAxis("");
//     double var35 = var34.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var38 = new org.jfree.chart.entity.AxisEntity(var32, (org.jfree.chart.axis.Axis)var34, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var39 = null;
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var25, (org.jfree.chart.axis.CategoryAxis)var27, (org.jfree.chart.axis.ValueAxis)var34, var39);
//     org.jfree.chart.LegendItemCollection var41 = var40.getLegendItems();
//     java.awt.Stroke var42 = var40.getRangeGridlineStroke();
//     var15.setRangeGridlineStroke(var42);
//     org.jfree.data.category.CategoryDataset var45 = null;
//     org.jfree.chart.axis.CategoryAxis3D var47 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("");
//     double var55 = var54.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var58 = new org.jfree.chart.entity.AxisEntity(var52, (org.jfree.chart.axis.Axis)var54, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = null;
//     org.jfree.chart.plot.CategoryPlot var60 = new org.jfree.chart.plot.CategoryPlot(var45, (org.jfree.chart.axis.CategoryAxis)var47, (org.jfree.chart.axis.ValueAxis)var54, var59);
//     org.jfree.chart.axis.AxisLocation var62 = null;
//     var60.setRangeAxisLocation(1, var62, true);
//     org.jfree.chart.event.PlotChangeListener var65 = null;
//     var60.addChangeListener(var65);
//     java.awt.Paint var67 = var60.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var68 = var60.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     java.awt.geom.Point2D var72 = null;
//     var60.zoomDomainAxes(100.0d, 0.05d, var71, var72);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var75 = var60.getRenderer(1);
//     org.jfree.chart.axis.AxisLocation var77 = var60.getDomainAxisLocation(1);
//     var15.setRangeAxisLocation(100, var77);
//     
//     // Checks the contract:  equals-hashcode on var40 and var60
//     assertTrue("Contract failed: equals-hashcode on var40 and var60", var40.equals(var60) ? var40.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var40
//     assertTrue("Contract failed: equals-hashcode on var60 and var40", var60.equals(var40) ? var60.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     int var35 = var31.getDatasetCount();
//     org.jfree.data.time.TimeSeries var36 = null;
//     java.util.TimeZone var37 = null;
//     org.jfree.data.time.TimeSeriesCollection var38 = new org.jfree.data.time.TimeSeriesCollection(var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
//     double var47 = var46.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var50 = new org.jfree.chart.entity.AxisEntity(var44, (org.jfree.chart.axis.Axis)var46, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var55 = null;
//     var53.setSeriesOutlinePaint(0, var55);
//     java.awt.Paint var58 = var53.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var61.setLine(var63);
//     var53.setSeriesShape(0, var63, true);
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var38, var39, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.renderer.xy.XYItemRenderer)var53);
//     org.jfree.chart.axis.AxisLocation var69 = null;
//     var67.setRangeAxisLocation(13, var69);
//     org.jfree.chart.axis.ValueAxis var72 = var67.getRangeAxis(10);
//     org.jfree.chart.axis.AxisSpace var73 = new org.jfree.chart.axis.AxisSpace();
//     var67.setFixedDomainAxisSpace(var73);
//     var31.setFixedRangeAxisSpace(var73);
//     
//     // Checks the contract:  equals-hashcode on var2 and var38
//     assertTrue("Contract failed: equals-hashcode on var2 and var38", var2.equals(var38) ? var2.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var2
//     assertTrue("Contract failed: equals-hashcode on var38 and var2", var38.equals(var2) ? var38.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var61
//     assertTrue("Contract failed: equals-hashcode on var25 and var61", var25.equals(var61) ? var25.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var25
//     assertTrue("Contract failed: equals-hashcode on var61 and var25", var61.equals(var25) ? var61.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var67
//     assertTrue("Contract failed: equals-hashcode on var31 and var67", var31.equals(var67) ? var31.hashCode() == var67.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var67 and var31
//     assertTrue("Contract failed: equals-hashcode on var67 and var31", var67.equals(var31) ? var67.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYSeries var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2DToSeries(var0, 0.0d, 0.0d, 0, (java.lang.Comparable)"0.05");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("RectangleConstraintType.RANGE", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    var15.setForegroundAlpha(10.0f);
    java.awt.Stroke var23 = var15.getRangeCrosshairStroke();
    org.jfree.chart.axis.AxisState var26 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var27 = var26.getTicks();
    var26.cursorLeft(Double.NaN);
    java.util.List var30 = var26.getTicks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.mapDatasetToDomainAxes(100, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     java.lang.String[] var2 = new java.lang.String[] { "hi!"};
//     org.jfree.chart.axis.SymbolAxis var3 = new org.jfree.chart.axis.SymbolAxis("January 0", var2);
//     var3.setAutoRangeStickyZero(false);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var14, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var19 = new org.jfree.chart.axis.DateAxis("");
//     double var20 = var19.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var23 = new org.jfree.chart.entity.AxisEntity(var17, (org.jfree.chart.axis.Axis)var19, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var10, (org.jfree.chart.axis.CategoryAxis)var12, (org.jfree.chart.axis.ValueAxis)var19, var24);
//     org.jfree.chart.axis.AxisLocation var27 = null;
//     var25.setRangeAxisLocation(1, var27, true);
//     org.jfree.chart.event.PlotChangeListener var30 = null;
//     var25.addChangeListener(var30);
//     java.awt.Paint var32 = var25.getRangeCrosshairPaint();
//     var25.zoom((-1.0d));
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var25.panRangeAxes(Double.NaN, var36, var37);
//     org.jfree.chart.util.RectangleEdge var39 = var25.getRangeAxisEdge();
//     org.jfree.chart.util.RectangleEdge var40 = org.jfree.chart.util.RectangleEdge.opposite(var39);
//     boolean var41 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var39);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.axis.AxisState var43 = var3.draw(var6, Double.NaN, var8, var9, var39, var42);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = null;
//     org.jfree.data.time.TimeSeries var9 = null;
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
//     org.jfree.data.time.TimeSeries var14 = null;
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14, var15);
//     org.jfree.data.Range var17 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var16);
//     var13.endSeriesPass((org.jfree.data.xy.XYDataset)var16, 13, 10, 100, 4, 0);
//     
//     // Checks the contract:  equals-hashcode on var11 and var16
//     assertTrue("Contract failed: equals-hashcode on var11 and var16", var11.equals(var16) ? var11.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var11
//     assertTrue("Contract failed: equals-hashcode on var16 and var11", var16.equals(var11) ? var16.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var6 = var2.getItemCreateEntity((-1), 13, true);
//     org.jfree.chart.renderer.category.BarPainter var7 = var2.getBarPainter();
//     double var8 = var2.getItemMargin();
//     java.lang.Object var9 = var2.clone();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var11 = var2.getBaseLegendTextPaint();
//     var2.setAutoPopulateSeriesPaint(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(1, var33, true);
//     org.jfree.chart.event.PlotChangeListener var36 = null;
//     var31.addChangeListener(var36);
//     java.awt.Paint var38 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var39 = var31.getDomainGridlinePosition();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.event.AxisChangeEvent var42 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var41);
//     var31.setDomainAxis(10, var41);
//     var41.setTickLabelsVisible(false);
//     org.jfree.chart.axis.DateAxis var47 = new org.jfree.chart.axis.DateAxis("");
//     double var48 = var47.getUpperMargin();
//     var47.setAutoRangeMinimumSize(0.05d, true);
//     org.jfree.chart.util.Layer var52 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var53 = null;
//     var2.drawAnnotations(var14, var15, var41, (org.jfree.chart.axis.ValueAxis)var47, var52, var53);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);
//     double var3 = var2.getHeight();
//     org.jfree.chart.block.LengthConstraintType var4 = var2.getHeightConstraintType();
//     org.jfree.data.Range var5 = var2.getHeightRange();
//     org.jfree.chart.util.Size2D var6 = null;
//     org.jfree.chart.util.Size2D var7 = var2.calculateConstrainedSize(var6);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.RectangleInsets var36 = var31.getAxisOffset();
    double var38 = var36.calculateBottomOutset(Double.NaN);
    double var40 = var36.calculateRightOutset(Double.NaN);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 4.0d);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
    double var26 = var25.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(1, var33, true);
    org.jfree.chart.event.PlotChangeListener var36 = null;
    var31.addChangeListener(var36);
    java.awt.Paint var38 = var31.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var39 = var31.getDomainGridlinePosition();
    java.awt.geom.Rectangle2D var42 = null;
    org.jfree.chart.axis.AxisState var44 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var45 = var44.getTicks();
    var44.cursorLeft(Double.NaN);
    org.jfree.data.category.CategoryDataset var49 = null;
    org.jfree.chart.axis.CategoryAxis3D var51 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var53 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var53, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var58 = new org.jfree.chart.axis.DateAxis("");
    double var59 = var58.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var62 = new org.jfree.chart.entity.AxisEntity(var56, (org.jfree.chart.axis.Axis)var58, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var63 = null;
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var49, (org.jfree.chart.axis.CategoryAxis)var51, (org.jfree.chart.axis.ValueAxis)var58, var63);
    org.jfree.chart.axis.AxisLocation var66 = null;
    var64.setRangeAxisLocation(1, var66, true);
    org.jfree.chart.event.PlotChangeListener var69 = null;
    var64.addChangeListener(var69);
    java.awt.Paint var71 = var64.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var72 = var64.getRangeAxisEdge();
    var44.moveCursor(10.0d, var72);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var74 = var2.getCategoryJava2DCoordinate(var39, 2147483647, (-459), var42, var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);

  }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     java.awt.Paint var22 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = var15.getRenderer(1);
//     org.jfree.chart.axis.AxisLocation var32 = var15.getDomainAxisLocation(1);
//     org.jfree.data.category.CategoryDataset var33 = null;
//     org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     double var43 = var42.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var40, (org.jfree.chart.axis.Axis)var42, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var33, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var42, var47);
//     org.jfree.chart.axis.AxisLocation var50 = null;
//     var48.setRangeAxisLocation(1, var50, false);
//     org.jfree.chart.plot.PlotOrientation var53 = var48.getOrientation();
//     org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var60 = var56.getItemCreateEntity((-1), 13, true);
//     java.awt.Shape var62 = var56.getLegendShape(100);
//     boolean var63 = var53.equals((java.lang.Object)var56);
//     org.jfree.chart.util.RectangleEdge var64 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var32, var53);
//     
//     // Checks the contract:  equals-hashcode on var15 and var48
//     assertTrue("Contract failed: equals-hashcode on var15 and var48", var15.equals(var48) ? var15.hashCode() == var48.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var48 and var15
//     assertTrue("Contract failed: equals-hashcode on var48 and var15", var48.equals(var15) ? var48.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    var15.setForegroundAlpha(10.0f);
    java.awt.Stroke var23 = var15.getRangeCrosshairStroke();
    java.awt.Paint var24 = var15.getDomainCrosshairPaint();
    boolean var25 = var15.isRangeZoomable();
    org.jfree.chart.axis.CategoryAxis var26 = var15.getDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    var1.setRangeAboutValue(100.0d, 100.0d);
    org.jfree.chart.axis.DateTickUnit var9 = null;
    var1.setTickUnit(var9, false, true);
    java.util.TimeZone var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     java.text.NumberFormat var0 = java.text.NumberFormat.getPercentInstance();
//     java.math.RoundingMode var1 = null;
//     var0.setRoundingMode(var1);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(100, 10, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() {}
//   public void test254() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.DomainOrder var4 = var2.getDomainOrder();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.time.TimePeriodAnchor var6 = var2.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.getStartXValue(10, 100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
//     org.jfree.chart.block.BlockBorder var17 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var18 = var17.getPaint();
//     boolean var19 = var16.equals((java.lang.Object)var18);
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis3D var22 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
//     double var30 = var29.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var33 = new org.jfree.chart.entity.AxisEntity(var27, (org.jfree.chart.axis.Axis)var29, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var34 = null;
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var20, (org.jfree.chart.axis.CategoryAxis)var22, (org.jfree.chart.axis.ValueAxis)var29, var34);
//     org.jfree.chart.LegendItemCollection var36 = var35.getLegendItems();
//     org.jfree.chart.block.BlockBorder var37 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var38 = var37.getPaint();
//     boolean var39 = var36.equals((java.lang.Object)var38);
//     var16.addAll(var36);
//     
//     // Checks the contract:  equals-hashcode on var15 and var35
//     assertTrue("Contract failed: equals-hashcode on var15 and var35", var15.equals(var35) ? var15.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var15
//     assertTrue("Contract failed: equals-hashcode on var35 and var15", var35.equals(var15) ? var35.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var36
//     assertTrue("Contract failed: equals-hashcode on var16 and var36", var16.equals(var36) ? var16.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var16
//     assertTrue("Contract failed: equals-hashcode on var36 and var16", var36.equals(var16) ? var36.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var37
//     assertTrue("Contract failed: equals-hashcode on var17 and var37", var17.equals(var37) ? var17.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var17
//     assertTrue("Contract failed: equals-hashcode on var37 and var17", var37.equals(var17) ? var37.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-1));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    org.jfree.chart.axis.CategoryAxis3D var15 = new org.jfree.chart.axis.CategoryAxis3D("");
    var15.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    double var28 = var27.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var20, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.AxisLocation var35 = null;
    var33.setRangeAxisLocation(1, var35, false);
    int var38 = var33.getRangeAxisCount();
    var33.setForegroundAlpha(10.0f);
    java.awt.Stroke var41 = var33.getRangeCrosshairStroke();
    java.awt.Paint var42 = var33.getDomainCrosshairPaint();
    var15.setLabelPaint(var42);
    var2.setSeriesFillPaint(1, var42, false);
    var2.setShadowVisible(true);
    boolean var51 = var2.isItemLabelVisible((-1), 0, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    boolean var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(var0, false);
// 
//   }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test262() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    boolean var6 = var1.isPositiveArrowVisible();
    org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("");
    double var9 = var8.getUpperMargin();
    org.jfree.data.Range var10 = null;
    org.jfree.data.Range var12 = org.jfree.data.Range.expandToInclude(var10, 0.0d);
    var8.setRange(var12, false, true);
    var1.setRange(var12, false, false);
    org.jfree.chart.util.RectangleInsets var19 = var1.getTickLabelInsets();
    java.awt.geom.Rectangle2D var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var23 = var19.createOutsetRectangle(var20, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var2.setLine(var4);
    org.jfree.chart.entity.AxisLabelEntity var8 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var0, var4, "", "");
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    double var16 = var15.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var24 = var22.lookupSeriesFillPaint(1);
    var15.setTickLabelPaint(var24);
    java.awt.Paint var26 = var15.getTickMarkPaint();
    org.jfree.chart.title.LegendGraphic var27 = new org.jfree.chart.title.LegendGraphic(var4, var26);
    var27.setShapeOutlineVisible(false);
    org.jfree.chart.util.RectangleAnchor var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.setShapeAnchor(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    java.text.NumberFormat var1 = java.text.NumberFormat.getInstance();
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("January 0", var1, var2);
    java.lang.String var4 = var3.getFormatString();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var9 = null;
    var7.setSeriesOutlinePaint(0, var9);
    var7.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var14 = null;
    var7.setSeriesURLGenerator(0, var14, true);
    org.jfree.data.time.TimeSeries var17 = null;
    java.util.TimeZone var18 = null;
    org.jfree.data.time.TimeSeriesCollection var19 = new org.jfree.data.time.TimeSeriesCollection(var17, var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    double var28 = var27.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var36 = null;
    var34.setSeriesOutlinePaint(0, var36);
    java.awt.Paint var39 = var34.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var42.setLine(var44);
    var34.setSeriesShape(0, var44, true);
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var19, var20, (org.jfree.chart.axis.ValueAxis)var27, (org.jfree.chart.renderer.xy.XYItemRenderer)var34);
    org.jfree.chart.axis.AxisLocation var50 = null;
    var48.setRangeAxisLocation(13, var50);
    var7.setPlot(var48);
    int var53 = var48.getSeriesCount();
    boolean var54 = var3.equals((java.lang.Object)var48);
    org.jfree.data.time.TimeSeries var55 = null;
    java.util.TimeZone var56 = null;
    org.jfree.data.time.TimeSeriesCollection var57 = new org.jfree.data.time.TimeSeriesCollection(var55, var56);
    org.jfree.data.Range var58 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var61 = var3.generateLabelString((org.jfree.data.xy.XYDataset)var57, 0, 2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "January 0"+ "'", var4.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setRangeAxisLocation(1, var38, true);
//     org.jfree.chart.event.PlotChangeListener var41 = null;
//     var36.addChangeListener(var41);
//     java.awt.Paint var43 = var36.getRangeCrosshairPaint();
//     var15.setNoDataMessagePaint(var43);
//     java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var51 = var50.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var50);
//     java.awt.Font var53 = var52.getLabelFont();
//     org.jfree.chart.util.Layer var54 = null;
//     var15.addRangeMarker(1, (org.jfree.chart.plot.Marker)var52, var54);
//     org.jfree.data.category.CategoryDataset var56 = null;
//     org.jfree.chart.axis.CategoryAxis3D var58 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var60, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis("");
//     double var66 = var65.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var69 = new org.jfree.chart.entity.AxisEntity(var63, (org.jfree.chart.axis.Axis)var65, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var70 = null;
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var56, (org.jfree.chart.axis.CategoryAxis)var58, (org.jfree.chart.axis.ValueAxis)var65, var70);
//     org.jfree.chart.axis.AxisLocation var73 = null;
//     var71.setRangeAxisLocation(1, var73, true);
//     var52.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var71);
//     
//     // Checks the contract:  equals-hashcode on var36 and var71
//     assertTrue("Contract failed: equals-hashcode on var36 and var71", var36.equals(var71) ? var36.hashCode() == var71.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var71 and var36
//     assertTrue("Contract failed: equals-hashcode on var71 and var36", var71.equals(var36) ? var71.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
    double var25 = var15.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var15.getRenderer((-1));
    java.awt.Image var28 = null;
    var15.setBackgroundImage(var28);
    org.jfree.chart.plot.Plot var30 = var15.getRootPlot();
    int var31 = var30.getBackgroundImageAlignment();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 15);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
    double var25 = var24.getUpperMargin();
    org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var29 = var28.toString();
    org.jfree.data.time.Year var30 = var28.getYear();
    var24.addCategoryLabelToolTip((java.lang.Comparable)var28, "Oct");
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
    double var43 = var42.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var40, (org.jfree.chart.axis.Axis)var42, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var33, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var42, var47);
    org.jfree.chart.axis.AxisLocation var50 = null;
    var48.setRangeAxisLocation(1, var50, true);
    org.jfree.chart.event.PlotChangeListener var53 = null;
    var48.addChangeListener(var53);
    java.awt.Paint var55 = var48.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var56 = var48.getRangeAxisEdge();
    boolean var57 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var56);
    java.lang.String var58 = var56.toString();
    int var59 = var28.compareTo((java.lang.Object)var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + "January 0"+ "'", var29.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + "RectangleEdge.LEFT"+ "'", var58.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 1);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("RectangleEdge.LEFT");
    java.awt.Paint var2 = var1.getGridBandAlternatePaint();
    java.io.ObjectOutputStream var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var2, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var1 = var0.getSeries();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeSeries(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var31.getDomainMarkers(var36);
    org.jfree.chart.axis.AxisLocation var39 = null;
    var31.setDomainAxisLocation(100, var39);
    org.jfree.chart.renderer.xy.XYItemRenderer var42 = var31.getRenderer((-459));
    org.jfree.data.time.TimeSeries var44 = null;
    java.util.TimeZone var45 = null;
    org.jfree.data.time.TimeSeriesCollection var46 = new org.jfree.data.time.TimeSeriesCollection(var44, var45);
    java.lang.Number var47 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var46);
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("");
    double var58 = var57.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var61 = new org.jfree.chart.entity.AxisEntity(var55, (org.jfree.chart.axis.Axis)var57, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var48, (org.jfree.chart.axis.CategoryAxis)var50, (org.jfree.chart.axis.ValueAxis)var57, var62);
    org.jfree.chart.axis.AxisLocation var65 = null;
    var63.setRangeAxisLocation(1, var65, true);
    org.jfree.chart.event.PlotChangeListener var68 = null;
    var63.addChangeListener(var68);
    java.awt.Paint var70 = var63.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var71 = var63.getDomainGridlinePosition();
    var46.addChangeListener((org.jfree.data.general.DatasetChangeListener)var63);
    org.jfree.data.time.TimeSeries var74 = var46.getSeries((java.lang.Comparable)1.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setDataset(2147483647, (org.jfree.data.xy.XYDataset)var46);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + Double.NaN+ "'", var47.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var6 = var3.getLegendItem((-1), 13);
    org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var9.setLine(var11);
    org.jfree.data.general.PieDataset var13 = null;
    org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity(var11, var13, (-1), 0, (java.lang.Comparable)100.0f, "", "");
    var3.setLegendShape(0, var11);
    java.awt.Font var24 = var3.getItemLabelFont((-1), 1, true);
    java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var28 = var27.getColorSpace();
    org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("", var24, (java.awt.Paint)var27);
    org.jfree.chart.text.TextBlockAnchor var30 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var29.setContentAlignmentPoint(var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var1 = var0.getNumberFormatOverride();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    double var3 = var0.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 10.0d);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
//     java.text.NumberFormat var2 = var1.getPercentFormat();
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var6 = var5.toString();
//     boolean var7 = var1.equals((java.lang.Object)var6);
//     org.jfree.data.general.PieDataset var8 = null;
//     java.lang.Comparable var9 = null;
//     java.text.AttributedString var10 = var1.generateAttributedSectionLabel(var8, var9);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var6 = var2.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var7 = var2.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var11.setShadowVisible(false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    var17.setUseOutlinePaint(true);
    var17.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var26 = var17.getBaseStroke();
    var11.setSeriesOutlineStroke(100, var26, false);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var30, 0.0d, 100.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    var11.setBaseShape(var30, false);
    var2.setLegendShape(1, var30);
    double var38 = var2.getXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1.0d));

  }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     double var8 = var7.getUpperMargin();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var8);
//     org.jfree.chart.block.BlockContainer var10 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement)var4);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.data.Range var13 = null;
//     org.jfree.chart.block.RectangleConstraint var14 = new org.jfree.chart.block.RectangleConstraint(100.0d, var13);
//     double var15 = var14.getHeight();
//     org.jfree.chart.block.LengthConstraintType var16 = var14.getHeightConstraintType();
//     org.jfree.data.Range var17 = var14.getHeightRange();
//     org.jfree.chart.util.Size2D var18 = var10.arrange(var11, var14);
// 
//   }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.axis.TickType var0 = null;
    org.jfree.chart.text.TextAnchor var3 = null;
    org.jfree.chart.text.TextAnchor var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var6 = new org.jfree.chart.axis.NumberTick(var0, 0.0d, "Oct", var3, var4, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var0 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.draw(var2, var3);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     var2.setUseOutlinePaint(true);
//     org.jfree.chart.urls.XYURLGenerator var9 = null;
//     var2.setSeriesURLGenerator(0, var9, true);
//     org.jfree.data.time.TimeSeries var12 = null;
//     java.util.TimeZone var13 = null;
//     org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
//     double var23 = var22.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var31 = null;
//     var29.setSeriesOutlinePaint(0, var31);
//     java.awt.Paint var34 = var29.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var37.setLine(var39);
//     var29.setSeriesShape(0, var39, true);
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
//     org.jfree.chart.axis.AxisLocation var45 = null;
//     var43.setRangeAxisLocation(13, var45);
//     var2.setPlot(var43);
//     int var48 = var43.getSeriesCount();
//     org.jfree.chart.util.RectangleInsets var49 = var43.getAxisOffset();
//     org.jfree.data.time.TimeSeries var51 = null;
//     java.util.TimeZone var52 = null;
//     org.jfree.data.time.TimeSeriesCollection var53 = new org.jfree.data.time.TimeSeriesCollection(var51, var52);
//     org.jfree.chart.axis.ValueAxis var54 = null;
//     java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var56, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var61 = new org.jfree.chart.axis.DateAxis("");
//     double var62 = var61.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var65 = new org.jfree.chart.entity.AxisEntity(var59, (org.jfree.chart.axis.Axis)var61, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var68 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var70 = null;
//     var68.setSeriesOutlinePaint(0, var70);
//     java.awt.Paint var73 = var68.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var78 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var76.setLine(var78);
//     var68.setSeriesShape(0, var78, true);
//     org.jfree.chart.plot.XYPlot var82 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var53, var54, (org.jfree.chart.axis.ValueAxis)var61, (org.jfree.chart.renderer.xy.XYItemRenderer)var68);
//     org.jfree.chart.axis.AxisLocation var84 = null;
//     var82.setRangeAxisLocation(13, var84);
//     int var86 = var82.getDatasetCount();
//     org.jfree.chart.axis.AxisLocation var88 = var82.getRangeAxisLocation((-1));
//     org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("hi!");
//     boolean var91 = var90.isShapeVisible();
//     java.awt.Paint var92 = var90.getOutlinePaint();
//     var82.setDomainGridlinePaint(var92);
//     org.jfree.chart.axis.AxisLocation var95 = var82.getDomainAxisLocation(100);
//     var43.setDomainAxisLocation(10, var95);
//     
//     // Checks the contract:  equals-hashcode on var14 and var53
//     assertTrue("Contract failed: equals-hashcode on var14 and var53", var14.equals(var53) ? var14.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var14
//     assertTrue("Contract failed: equals-hashcode on var53 and var14", var53.equals(var14) ? var53.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var76
//     assertTrue("Contract failed: equals-hashcode on var37 and var76", var37.equals(var76) ? var37.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var37
//     assertTrue("Contract failed: equals-hashcode on var76 and var37", var76.equals(var37) ? var76.hashCode() == var37.hashCode() : true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    java.awt.Paint var14 = var2.getSeriesFillPaint(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var6 = var2.getItemCreateEntity((-1), 13, true);
//     java.awt.Shape var8 = var2.getLegendShape(100);
//     org.jfree.data.category.CategoryDataset var9 = null;
//     org.jfree.data.Range var11 = var2.findRangeBounds(var9, true);
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var17 = var14.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
//     var14.setBaseItemLabelGenerator(var18, false);
//     java.awt.Stroke var22 = null;
//     var14.setSeriesStroke(13, var22, false);
//     org.jfree.chart.util.GradientPaintTransformer var25 = var14.getGradientPaintTransformer();
//     var2.setGradientPaintTransformer(var25);
//     
//     // Checks the contract:  equals-hashcode on var2 and var14
//     assertTrue("Contract failed: equals-hashcode on var2 and var14", var2.equals(var14) ? var2.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var2
//     assertTrue("Contract failed: equals-hashcode on var14 and var2", var14.equals(var2) ? var14.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var3 = var2.toString();
    org.jfree.data.time.Year var4 = var2.getYear();
    org.jfree.chart.plot.CrosshairState var6 = new org.jfree.chart.plot.CrosshairState(false);
    double var7 = var6.getCrosshairY();
    int var8 = var6.getDomainAxisIndex();
    var6.setCrosshairY(4.0d);
    var6.setDatasetIndex((-1));
    int var13 = var4.compareTo((java.lang.Object)var6);
    double var14 = var6.getCrosshairDistance();
    var6.updateCrosshairY(10.0d, 4);
    org.jfree.chart.plot.PlotOrientation var22 = null;
    var6.updateCrosshairPoint(100.0d, 0.5d, 18.0d, 0.2d, var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "January 0"+ "'", var3.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(13, var33);
    int var35 = var31.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
    org.jfree.chart.axis.AxisLocation var38 = var31.getRangeAxisLocation();
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var46 = var42.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var47 = var42.getBarPainter();
    double var48 = var42.getItemMargin();
    java.lang.Object var49 = var42.clone();
    java.awt.Paint var53 = var42.getItemLabelPaint(0, 2147483647, false);
    org.jfree.data.category.CategoryDataset var54 = null;
    org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var58, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
    double var64 = var63.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var67 = new org.jfree.chart.entity.AxisEntity(var61, (org.jfree.chart.axis.Axis)var63, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var54, (org.jfree.chart.axis.CategoryAxis)var56, (org.jfree.chart.axis.ValueAxis)var63, var68);
    org.jfree.chart.axis.AxisLocation var71 = null;
    var69.setRangeAxisLocation(1, var71, true);
    org.jfree.chart.event.PlotChangeListener var74 = null;
    var69.addChangeListener(var74);
    org.jfree.chart.axis.AxisSpace var76 = null;
    var69.setFixedDomainAxisSpace(var76);
    org.jfree.chart.axis.CategoryAxis var78 = var69.getDomainAxis();
    double var79 = var69.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var81 = var69.getRenderer((-1));
    java.awt.Image var82 = null;
    var69.setBackgroundImage(var82);
    java.awt.Stroke var84 = var69.getDomainGridlineStroke();
    org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker(4.0d, var53, var84);
    org.jfree.chart.util.Layer var86 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.addDomainMarker((org.jfree.chart.plot.Marker)var85, var86);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
    double var25 = var15.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var15.getRenderer((-1));
    java.awt.Image var28 = null;
    var15.setBackgroundImage(var28);
    org.jfree.chart.plot.Plot var30 = var15.getRootPlot();
    org.jfree.data.time.TimeSeries var31 = null;
    java.util.TimeZone var32 = null;
    org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
    org.jfree.chart.axis.ValueAxis var34 = null;
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    double var42 = var41.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var50 = null;
    var48.setSeriesOutlinePaint(0, var50);
    java.awt.Paint var53 = var48.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var56.setLine(var58);
    var48.setSeriesShape(0, var58, true);
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var33, var34, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var48);
    org.jfree.chart.axis.AxisLocation var64 = null;
    var62.setRangeAxisLocation(13, var64);
    int var66 = var62.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var68 = var62.getRangeAxisLocation((-1));
    org.jfree.chart.axis.AxisLocation var69 = var62.getRangeAxisLocation();
    var15.setRangeAxisLocation(var69, false);
    java.lang.String var72 = var69.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var72 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT"+ "'", var72.equals("AxisLocation.BOTTOM_OR_LEFT"));

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.RendererChangeEvent var1 = new org.jfree.chart.event.RendererChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(1.0d, 4.0d, 0.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var9 = var6.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var12.setLine(var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.entity.PieSectionEntity var22 = new org.jfree.chart.entity.PieSectionEntity(var14, var16, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var6.setLegendShape(0, var14);
//     java.awt.Font var27 = var6.getItemLabelFont((-1), 1, true);
//     boolean var28 = var3.equals((java.lang.Object)1);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var36 = var32.getItemCreateEntity((-1), 13, true);
//     org.jfree.chart.renderer.category.BarPainter var37 = var32.getBarPainter();
//     int var38 = var32.getColumnCount();
//     org.jfree.chart.urls.CategoryURLGenerator var40 = var32.getSeriesURLGenerator(10);
//     var32.setShadowXOffset(10.0d);
//     java.awt.geom.RectangularShape var46 = null;
//     org.jfree.data.category.CategoryDataset var47 = null;
//     org.jfree.chart.axis.CategoryAxis3D var49 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var51 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var51, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var56 = new org.jfree.chart.axis.DateAxis("");
//     double var57 = var56.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var60 = new org.jfree.chart.entity.AxisEntity(var54, (org.jfree.chart.axis.Axis)var56, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var61 = null;
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var47, (org.jfree.chart.axis.CategoryAxis)var49, (org.jfree.chart.axis.ValueAxis)var56, var61);
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setRangeAxisLocation(1, var64, true);
//     org.jfree.chart.event.PlotChangeListener var67 = null;
//     var62.addChangeListener(var67);
//     java.awt.Paint var69 = var62.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var70 = var62.getRangeAxisEdge();
//     boolean var71 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var70);
//     java.lang.String var72 = var70.toString();
//     var3.paintBarShadow(var29, (org.jfree.chart.renderer.category.BarRenderer)var32, 13, 4, true, var46, var70, false);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 2147483647);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    var1.fireSeriesChanged();

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    java.awt.Color var36 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var37 = var36.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var38 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var36);
    java.awt.Font var39 = var38.getLabelFont();
    float var40 = var38.getAlpha();
    boolean var41 = var31.removeDomainMarker((org.jfree.chart.plot.Marker)var38);
    java.awt.Paint var42 = var31.getDomainCrosshairPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var44 = var31.getRangeAxisForDataset((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var3 = var2.toString();
    org.jfree.data.time.Year var4 = var2.getYear();
    org.jfree.chart.plot.CrosshairState var6 = new org.jfree.chart.plot.CrosshairState(false);
    double var7 = var6.getCrosshairY();
    int var8 = var6.getDomainAxisIndex();
    var6.setCrosshairY(4.0d);
    var6.setDatasetIndex((-1));
    int var13 = var4.compareTo((java.lang.Object)var6);
    double var14 = var6.getCrosshairDistance();
    var6.updateCrosshairY(10.0d, 4);
    var6.setCrosshairX((-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "January 0"+ "'", var3.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.0d);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    int var3 = java.awt.Color.HSBtoRGB(0.8f, 0.0f, 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-16777216));

  }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
    double var25 = var15.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var27 = var15.getRenderer((-1));
    java.awt.Image var28 = null;
    var15.setBackgroundImage(var28);
    org.jfree.chart.plot.Plot var30 = var15.getRootPlot();
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var37 = var34.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var38 = null;
    var34.setBaseItemLabelGenerator(var38, false);
    java.awt.Stroke var42 = null;
    var34.setSeriesStroke(13, var42, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var45 = var34.getBaseToolTipGenerator();
    var15.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    org.jfree.chart.util.RectangleInsets var47 = var15.getInsets();
    double var49 = var47.calculateTopInset(1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 4.0d);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var8 = null;
//     var6.setSeriesOutlinePaint(0, var8);
//     var6.setUseOutlinePaint(true);
//     var6.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var15 = var6.getBaseStroke();
//     java.awt.Paint var19 = var6.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var6.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var28 = var25.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = null;
//     var25.setBaseItemLabelGenerator(var29, false);
//     java.awt.Stroke var33 = null;
//     var25.setSeriesStroke(13, var33, false);
//     var25.setAutoPopulateSeriesStroke(true);
//     boolean var38 = var25.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var39 = var25.getBasePositiveItemLabelPosition();
//     var6.setSeriesNegativeItemLabelPosition(1, var39, true);
//     org.jfree.chart.text.TextAnchor var42 = var39.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("January 0", var1, 10.0f, 100.0f, var42, Double.NaN, 1.0f, (-1.0f));
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(1, 2147483647, (-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.jfree.data.general.WaferMapDataset var0 = null;
//     org.jfree.chart.plot.WaferMapPlot var1 = new org.jfree.chart.plot.WaferMapPlot(var0);
//     org.jfree.chart.LegendItemCollection var2 = var1.getLegendItems();
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.Range var5 = var2.getDomainBounds(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var7 = var2.getSeries(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX(0.05d);
    var0.setTranslateX(Double.NaN);
    boolean var5 = var0.getGenerateEntities();
    boolean var6 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setRangeAxisLocation(1, var38, true);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var36.addChangeListener(var41);
    java.awt.Paint var43 = var36.getRangeCrosshairPaint();
    var15.setNoDataMessagePaint(var43);
    java.awt.Paint var45 = var15.getDomainGridlinePaint();
    int var46 = var15.getDatasetCount();
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var49, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var54 = new org.jfree.chart.axis.DateAxis("");
    double var55 = var54.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var58 = new org.jfree.chart.entity.AxisEntity(var52, (org.jfree.chart.axis.Axis)var54, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var63 = var61.lookupSeriesFillPaint(1);
    var54.setTickLabelPaint(var63);
    java.awt.Paint var65 = var54.getTickMarkPaint();
    var54.setNegativeArrowVisible(false);
    java.lang.Object var68 = var54.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.setRangeAxis((-459), (org.jfree.chart.axis.ValueAxis)var54, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "");
//     var5.setVersion("hi!");
//     java.lang.String var8 = var5.getCopyright();
//     org.jfree.chart.ui.Library var9 = null;
//     var5.addOptionalLibrary(var9);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var3 = var2.getColorSpace();
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var7 = var6.getColorSpace();
    float[] var8 = new float[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var2.getComponents(var7, var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     java.awt.Paint var22 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var23 = var15.getDomainGridlinePosition();
//     org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.event.AxisChangeEvent var26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var25);
//     var15.setDomainAxis(10, var25);
//     var25.setTickLabelsVisible(false);
//     java.awt.geom.Rectangle2D var32 = null;
//     org.jfree.chart.axis.AxisSpace var33 = new org.jfree.chart.axis.AxisSpace();
//     var33.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis3D var39 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
//     double var47 = var46.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var50 = new org.jfree.chart.entity.AxisEntity(var44, (org.jfree.chart.axis.Axis)var46, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var51 = null;
//     org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot(var37, (org.jfree.chart.axis.CategoryAxis)var39, (org.jfree.chart.axis.ValueAxis)var46, var51);
//     org.jfree.chart.axis.AxisLocation var54 = null;
//     var52.setRangeAxisLocation(1, var54, true);
//     org.jfree.chart.event.PlotChangeListener var57 = null;
//     var52.addChangeListener(var57);
//     java.awt.Paint var59 = var52.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var60 = var52.getRangeAxisEdge();
//     boolean var61 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var60);
//     var33.ensureAtLeast(0.0d, var60);
//     double var63 = var25.getCategoryEnd(10, 0, var32, var60);
// 
//   }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    double var15 = var14.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var18 = new org.jfree.chart.entity.AxisEntity(var12, (org.jfree.chart.axis.Axis)var14, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var23 = var21.lookupSeriesFillPaint(1);
    var14.setTickLabelPaint(var23);
    java.awt.Paint var25 = var14.getTickMarkPaint();
    var2.setBaseFillPaint(var25, false);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    java.awt.geom.Point2D var3 = null;
    var0.panRangeAxes(0.05d, var2, var3);
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    var6.setUpperMargin(100.0d);
    int var9 = var6.getMaximumCategoryLabelLines();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var14 = null;
    var12.setSeriesOutlinePaint(0, var14);
    var12.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var19 = null;
    var12.setSeriesURLGenerator(0, var19, true);
    org.jfree.data.time.TimeSeries var22 = null;
    java.util.TimeZone var23 = null;
    org.jfree.data.time.TimeSeriesCollection var24 = new org.jfree.data.time.TimeSeriesCollection(var22, var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var27, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
    double var33 = var32.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var36 = new org.jfree.chart.entity.AxisEntity(var30, (org.jfree.chart.axis.Axis)var32, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var41 = null;
    var39.setSeriesOutlinePaint(0, var41);
    java.awt.Paint var44 = var39.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var47 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var49 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var47.setLine(var49);
    var39.setSeriesShape(0, var49, true);
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var24, var25, (org.jfree.chart.axis.ValueAxis)var32, (org.jfree.chart.renderer.xy.XYItemRenderer)var39);
    org.jfree.chart.axis.AxisLocation var55 = null;
    var53.setRangeAxisLocation(13, var55);
    var12.setPlot(var53);
    java.awt.Paint var58 = var53.getDomainCrosshairPaint();
    var6.setTickLabelPaint(var58);
    var0.setRangeMinorGridlinePaint(var58);
    org.jfree.chart.plot.Marker var62 = null;
    org.jfree.chart.util.Layer var63 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var64 = var0.removeRangeMarker(10, var62, var63);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.chart.ui.BasicProjectInfo var5 = new org.jfree.chart.ui.BasicProjectInfo("", "", "hi!", "hi!", "");
    java.lang.String var6 = var5.getName();
    var5.setInfo("0,100,0,100,0,100,0,100");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("AxisLocation.BOTTOM_OR_LEFT", var1);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.Range var5 = var2.getDomainBounds(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.removeSeries(15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     var31.clearDomainMarkers();
//     java.awt.Stroke var33 = var31.getDomainCrosshairStroke();
//     org.jfree.data.time.TimeSeries var34 = null;
//     java.util.TimeZone var35 = null;
//     org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var34, var35);
//     org.jfree.data.Range var37 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var36);
//     int var38 = var31.indexOf((org.jfree.data.xy.XYDataset)var36);
//     
//     // Checks the contract:  equals-hashcode on var2 and var36
//     assertTrue("Contract failed: equals-hashcode on var2 and var36", var2.equals(var36) ? var2.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var2
//     assertTrue("Contract failed: equals-hashcode on var36 and var2", var36.equals(var2) ? var36.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    double var14 = var13.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(1, var21, true);
    org.jfree.chart.event.PlotChangeListener var24 = null;
    var19.addChangeListener(var24);
    java.awt.Paint var26 = var19.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var27 = var19.getDomainGridlinePosition();
    var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var19);
    org.jfree.data.xy.XYSeriesCollection var29 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var30 = var29.getSeries();
    org.jfree.data.Range var31 = null;
    org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
    double var34 = var33.getUpperMargin();
    org.jfree.data.Range var35 = null;
    org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 0.0d);
    var33.setRange(var37, false, true);
    org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(var31, var37);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var43 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var2, var30, var31, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var8 = null;
//     var6.setSeriesOutlinePaint(0, var8);
//     var6.setUseOutlinePaint(true);
//     var6.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var15 = var6.getBaseStroke();
//     java.awt.Paint var19 = var6.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var21 = var6.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var28 = var25.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var29 = null;
//     var25.setBaseItemLabelGenerator(var29, false);
//     java.awt.Stroke var33 = null;
//     var25.setSeriesStroke(13, var33, false);
//     var25.setAutoPopulateSeriesStroke(true);
//     boolean var38 = var25.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var39 = var25.getBasePositiveItemLabelPosition();
//     var6.setSeriesNegativeItemLabelPosition(1, var39, true);
//     org.jfree.chart.text.TextAnchor var42 = var39.getTextAnchor();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var48 = null;
//     var46.setSeriesOutlinePaint(0, var48);
//     var46.setUseOutlinePaint(true);
//     var46.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var55 = var46.getBaseStroke();
//     java.awt.Paint var59 = var46.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var61 = var46.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var68 = var65.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var69 = null;
//     var65.setBaseItemLabelGenerator(var69, false);
//     java.awt.Stroke var73 = null;
//     var65.setSeriesStroke(13, var73, false);
//     var65.setAutoPopulateSeriesStroke(true);
//     boolean var78 = var65.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var79 = var65.getBasePositiveItemLabelPosition();
//     var46.setSeriesNegativeItemLabelPosition(1, var79, true);
//     org.jfree.chart.text.TextAnchor var82 = var79.getTextAnchor();
//     java.awt.Shape var83 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", var1, 0.8f, 100.0f, var42, 0.5d, var82);
//     
//     // Checks the contract:  equals-hashcode on var21 and var61
//     assertTrue("Contract failed: equals-hashcode on var21 and var61", var21.equals(var61) ? var21.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var79
//     assertTrue("Contract failed: equals-hashcode on var39 and var79", var39.equals(var79) ? var39.hashCode() == var79.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var21
//     assertTrue("Contract failed: equals-hashcode on var61 and var21", var61.equals(var21) ? var61.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var79 and var39
//     assertTrue("Contract failed: equals-hashcode on var79 and var39", var79.equals(var39) ? var79.hashCode() == var39.hashCode() : true);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    var2.setAutoPopulateSeriesStroke(true);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var16, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var21 = new org.jfree.chart.axis.DateAxis("");
    double var22 = var21.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var25 = new org.jfree.chart.entity.AxisEntity(var19, (org.jfree.chart.axis.Axis)var21, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var30 = var28.lookupSeriesFillPaint(1);
    var21.setTickLabelPaint(var30);
    java.awt.Paint var32 = var21.getTickMarkPaint();
    var2.setShadowPaint(var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-459), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    java.util.TimeZone var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var5 = null;
    var3.setSeriesOutlinePaint(0, var5);
    var3.setUseOutlinePaint(true);
    var3.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var12 = var3.getBaseStroke();
    java.awt.Paint var16 = var3.getItemFillPaint((-1), 0, false);
    org.jfree.chart.labels.ItemLabelPosition var18 = var3.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var25 = var22.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = null;
    var22.setBaseItemLabelGenerator(var26, false);
    java.awt.Stroke var30 = null;
    var22.setSeriesStroke(13, var30, false);
    var22.setAutoPopulateSeriesStroke(true);
    boolean var35 = var22.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.ItemLabelPosition var36 = var22.getBasePositiveItemLabelPosition();
    var3.setSeriesNegativeItemLabelPosition(1, var36, true);
    org.jfree.chart.text.TextAnchor var39 = var36.getTextAnchor();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var44 = null;
    var42.setSeriesOutlinePaint(0, var44);
    var42.setUseOutlinePaint(true);
    var42.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var51 = var42.getBaseStroke();
    java.awt.Paint var55 = var42.getItemFillPaint((-1), 0, false);
    org.jfree.chart.labels.ItemLabelPosition var57 = var42.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var64 = var61.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var65 = null;
    var61.setBaseItemLabelGenerator(var65, false);
    java.awt.Stroke var69 = null;
    var61.setSeriesStroke(13, var69, false);
    var61.setAutoPopulateSeriesStroke(true);
    boolean var74 = var61.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.ItemLabelPosition var75 = var61.getBasePositiveItemLabelPosition();
    var42.setSeriesNegativeItemLabelPosition(1, var75, true);
    org.jfree.chart.text.TextAnchor var78 = var75.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var80 = new org.jfree.chart.labels.ItemLabelPosition(var0, var39, var78, 4.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = var15.getRenderer(1);
    org.jfree.data.time.TimeSeries var31 = null;
    java.util.TimeZone var32 = null;
    org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
    org.jfree.chart.axis.ValueAxis var34 = null;
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    double var42 = var41.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var50 = null;
    var48.setSeriesOutlinePaint(0, var50);
    java.awt.Paint var53 = var48.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var56.setLine(var58);
    var48.setSeriesShape(0, var58, true);
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var33, var34, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var48);
    org.jfree.chart.axis.AxisLocation var64 = null;
    var62.setRangeAxisLocation(13, var64);
    int var66 = var62.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var68 = var62.getRangeAxisLocation((-1));
    var15.setDomainAxisLocation(var68);
    var15.clearAnnotations();
    org.jfree.chart.axis.DateAxis var72 = new org.jfree.chart.axis.DateAxis("");
    double var73 = var72.getUpperMargin();
    var72.setAutoRangeMinimumSize(0.05d, true);
    java.text.DateFormat var77 = null;
    var72.setDateFormatOverride(var77);
    org.jfree.chart.axis.DateTickUnit var79 = null;
    var72.setTickUnit(var79);
    var72.pan(Double.NaN);
    int var83 = var15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis)var72);
    boolean var85 = var72.isHiddenValue(0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    var1.setLabelURL("hi!");
    java.util.Date var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMinimumDate(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var9 = null;
    var2.setSeriesURLGenerator(0, var9, true);
    org.jfree.data.time.TimeSeries var12 = null;
    java.util.TimeZone var13 = null;
    org.jfree.data.time.TimeSeriesCollection var14 = new org.jfree.data.time.TimeSeriesCollection(var12, var13);
    org.jfree.chart.axis.ValueAxis var15 = null;
    java.awt.Shape var17 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var17, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var22 = new org.jfree.chart.axis.DateAxis("");
    double var23 = var22.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var26 = new org.jfree.chart.entity.AxisEntity(var20, (org.jfree.chart.axis.Axis)var22, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var31 = null;
    var29.setSeriesOutlinePaint(0, var31);
    java.awt.Paint var34 = var29.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var37.setLine(var39);
    var29.setSeriesShape(0, var39, true);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var14, var15, (org.jfree.chart.axis.ValueAxis)var22, (org.jfree.chart.renderer.xy.XYItemRenderer)var29);
    org.jfree.chart.axis.AxisLocation var45 = null;
    var43.setRangeAxisLocation(13, var45);
    var2.setPlot(var43);
    boolean var48 = var43.canSelectByRegion();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("");
    var1.setCategoryMargin(4.0d);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.jfree.chart.axis.TickType var0 = null;
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var7 = null;
//     var5.setSeriesOutlinePaint(0, var7);
//     var5.setUseOutlinePaint(true);
//     var5.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var14 = var5.getBaseStroke();
//     java.awt.Paint var18 = var5.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var20 = var5.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var27 = var24.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var28 = null;
//     var24.setBaseItemLabelGenerator(var28, false);
//     java.awt.Stroke var32 = null;
//     var24.setSeriesStroke(13, var32, false);
//     var24.setAutoPopulateSeriesStroke(true);
//     boolean var37 = var24.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var38 = var24.getBasePositiveItemLabelPosition();
//     var5.setSeriesNegativeItemLabelPosition(1, var38, true);
//     org.jfree.chart.text.TextAnchor var41 = var38.getTextAnchor();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var44 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var46 = null;
//     var44.setSeriesOutlinePaint(0, var46);
//     var44.setUseOutlinePaint(true);
//     var44.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var53 = var44.getBaseStroke();
//     java.awt.Paint var57 = var44.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var59 = var44.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var66 = var63.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var67 = null;
//     var63.setBaseItemLabelGenerator(var67, false);
//     java.awt.Stroke var71 = null;
//     var63.setSeriesStroke(13, var71, false);
//     var63.setAutoPopulateSeriesStroke(true);
//     boolean var76 = var63.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var77 = var63.getBasePositiveItemLabelPosition();
//     var44.setSeriesNegativeItemLabelPosition(1, var77, true);
//     org.jfree.chart.text.TextAnchor var80 = var77.getTextAnchor();
//     org.jfree.chart.axis.NumberTick var82 = new org.jfree.chart.axis.NumberTick(var0, 0.05d, "LegendItemEntity: seriesKey=null, dataset=null", var41, var80, 0.05d);
//     
//     // Checks the contract:  equals-hashcode on var20 and var59
//     assertTrue("Contract failed: equals-hashcode on var20 and var59", var20.equals(var59) ? var20.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var77
//     assertTrue("Contract failed: equals-hashcode on var38 and var77", var38.equals(var77) ? var38.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var20
//     assertTrue("Contract failed: equals-hashcode on var59 and var20", var59.equals(var20) ? var59.hashCode() == var20.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var38
//     assertTrue("Contract failed: equals-hashcode on var77 and var38", var77.equals(var38) ? var77.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.chart.axis.AxisState var2 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var3 = var2.getTicks();
    java.util.Collection var4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var3);
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0, var3, var5, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var0.getStartXValue(10, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    double var6 = var1.getFixedAutoRange();
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var14 = var10.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var15 = var10.getBarPainter();
    double var16 = var10.getItemMargin();
    java.lang.Object var17 = var10.clone();
    java.awt.Paint var21 = var10.getItemLabelPaint(0, 2147483647, false);
    org.jfree.data.category.CategoryDataset var22 = null;
    org.jfree.chart.axis.CategoryAxis3D var24 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var29 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var26, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var31 = new org.jfree.chart.axis.DateAxis("");
    double var32 = var31.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var35 = new org.jfree.chart.entity.AxisEntity(var29, (org.jfree.chart.axis.Axis)var31, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var36 = null;
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot(var22, (org.jfree.chart.axis.CategoryAxis)var24, (org.jfree.chart.axis.ValueAxis)var31, var36);
    org.jfree.chart.axis.AxisLocation var39 = null;
    var37.setRangeAxisLocation(1, var39, true);
    org.jfree.chart.event.PlotChangeListener var42 = null;
    var37.addChangeListener(var42);
    org.jfree.chart.axis.AxisSpace var44 = null;
    var37.setFixedDomainAxisSpace(var44);
    org.jfree.chart.axis.CategoryAxis var46 = var37.getDomainAxis();
    double var47 = var37.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var49 = var37.getRenderer((-1));
    java.awt.Image var50 = null;
    var37.setBackgroundImage(var50);
    java.awt.Stroke var52 = var37.getDomainGridlineStroke();
    org.jfree.chart.plot.ValueMarker var53 = new org.jfree.chart.plot.ValueMarker(4.0d, var21, var52);
    org.jfree.chart.renderer.category.BarRenderer3D var56 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var60 = var56.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var61 = var56.getBarPainter();
    double var62 = var56.getItemMargin();
    java.lang.Object var63 = var56.clone();
    java.awt.Paint var64 = var56.getBasePaint();
    boolean var65 = org.jfree.chart.util.PaintUtilities.equal(var21, var64);
    var1.setLabelPaint(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    boolean var4 = var3.getAllowDuplicateXValues();
    boolean var5 = var3.isEmpty();
    org.jfree.data.xy.XYDataItem var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var7 = var3.addOrUpdate(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     int var35 = var31.getDatasetCount();
//     org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
//     org.jfree.data.time.TimeSeries var38 = null;
//     java.util.TimeZone var39 = null;
//     org.jfree.data.time.TimeSeriesCollection var40 = new org.jfree.data.time.TimeSeriesCollection(var38, var39);
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("");
//     double var49 = var48.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var52 = new org.jfree.chart.entity.AxisEntity(var46, (org.jfree.chart.axis.Axis)var48, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var57 = null;
//     var55.setSeriesOutlinePaint(0, var57);
//     java.awt.Paint var60 = var55.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var63 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var65 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var63.setLine(var65);
//     var55.setSeriesShape(0, var65, true);
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var40, var41, (org.jfree.chart.axis.ValueAxis)var48, (org.jfree.chart.renderer.xy.XYItemRenderer)var55);
//     var69.clearDomainMarkers();
//     java.awt.Stroke var71 = var69.getDomainCrosshairStroke();
//     java.awt.Stroke var72 = var69.getRangeMinorGridlineStroke();
//     var31.setDomainMinorGridlineStroke(var72);
//     
//     // Checks the contract:  equals-hashcode on var2 and var40
//     assertTrue("Contract failed: equals-hashcode on var2 and var40", var2.equals(var40) ? var2.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var2
//     assertTrue("Contract failed: equals-hashcode on var40 and var2", var40.equals(var2) ? var40.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var63
//     assertTrue("Contract failed: equals-hashcode on var25 and var63", var25.equals(var63) ? var25.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var25
//     assertTrue("Contract failed: equals-hashcode on var63 and var25", var63.equals(var25) ? var63.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var69
//     assertTrue("Contract failed: equals-hashcode on var31 and var69", var31.equals(var69) ? var31.hashCode() == var69.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var69 and var31
//     assertTrue("Contract failed: equals-hashcode on var69 and var31", var69.equals(var31) ? var69.hashCode() == var31.hashCode() : true);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 100.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var6 = var3.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var9.setLine(var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity(var11, var13, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var3.setLegendShape(0, var11);
//     java.awt.Font var24 = var3.getItemLabelFont((-1), 1, true);
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("", var24, (java.awt.Paint)var27);
//     org.jfree.chart.util.RectangleAnchor var30 = var29.getTextAnchor();
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var37 = var34.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var40.setLine(var42);
//     org.jfree.data.general.PieDataset var44 = null;
//     org.jfree.chart.entity.PieSectionEntity var50 = new org.jfree.chart.entity.PieSectionEntity(var42, var44, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var34.setLegendShape(0, var42);
//     java.awt.Font var55 = var34.getItemLabelFont((-1), 1, true);
//     java.awt.Color var58 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var59 = var58.getColorSpace();
//     org.jfree.chart.block.LabelBlock var60 = new org.jfree.chart.block.LabelBlock("", var55, (java.awt.Paint)var58);
//     org.jfree.chart.util.RectangleAnchor var61 = var60.getTextAnchor();
//     var29.setTextAnchor(var61);
//     
//     // Checks the contract:  equals-hashcode on var9 and var40
//     assertTrue("Contract failed: equals-hashcode on var9 and var40", var9.equals(var40) ? var9.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var9
//     assertTrue("Contract failed: equals-hashcode on var40 and var9", var40.equals(var9) ? var40.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var60
//     assertTrue("Contract failed: equals-hashcode on var29 and var60", var29.equals(var60) ? var29.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var29
//     assertTrue("Contract failed: equals-hashcode on var60 and var29", var60.equals(var29) ? var60.hashCode() == var29.hashCode() : true);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setTranslateX(0.05d);
    var0.setTranslateX(Double.NaN);
    var0.setTranslateX(100.0d);
    boolean var7 = var0.getGenerateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("RectangleEdge.LEFT");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var7 = null;
//     var5.setSeriesOutlinePaint(0, var7);
//     var5.setUseOutlinePaint(true);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
//     double var18 = var17.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var21 = new org.jfree.chart.entity.AxisEntity(var15, (org.jfree.chart.axis.Axis)var17, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var26 = var24.lookupSeriesFillPaint(1);
//     var17.setTickLabelPaint(var26);
//     java.awt.Paint var28 = var17.getTickMarkPaint();
//     var5.setBaseFillPaint(var28, false);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("hi!", var28);
//     var1.setShadowPaint(var28);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var37 = var35.lookupSeriesFillPaint(1);
//     var35.setSeriesLinesVisible(10, (java.lang.Boolean)false);
//     boolean var42 = var35.equals((java.lang.Object)(byte)(-1));
//     var35.setBaseLinesVisible(false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var45 = var35.getLegendItemLabelGenerator();
//     java.awt.Paint var49 = var35.getItemOutlinePaint(0, 0, true);
//     var1.setAxisLabelPaint(var49);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var24 and var35.", var24.equals(var35) == var35.equals(var24));
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
//     org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var6 = var5.toString();
//     org.jfree.data.time.Year var7 = var5.getYear();
//     org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var11 = var10.toString();
//     org.jfree.data.time.TimeSeries var12 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var10);
//     org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var16 = var15.toString();
//     org.jfree.data.time.Year var17 = var15.getYear();
//     org.jfree.chart.plot.CrosshairState var19 = new org.jfree.chart.plot.CrosshairState(false);
//     double var20 = var19.getCrosshairY();
//     int var21 = var19.getDomainAxisIndex();
//     var19.setCrosshairY(4.0d);
//     var19.setDatasetIndex((-1));
//     int var26 = var17.compareTo((java.lang.Object)var19);
//     org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var17);
//     org.jfree.data.time.RegularTimePeriod var28 = var27.getFirst();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.axis.AxisSpace var31 = new org.jfree.chart.axis.AxisSpace();
//     var31.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var35 = null;
//     org.jfree.chart.axis.CategoryAxis3D var37 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var39, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
//     double var45 = var44.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var48 = new org.jfree.chart.entity.AxisEntity(var42, (org.jfree.chart.axis.Axis)var44, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var49 = null;
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var35, (org.jfree.chart.axis.CategoryAxis)var37, (org.jfree.chart.axis.ValueAxis)var44, var49);
//     org.jfree.chart.axis.AxisLocation var52 = null;
//     var50.setRangeAxisLocation(1, var52, true);
//     org.jfree.chart.event.PlotChangeListener var55 = null;
//     var50.addChangeListener(var55);
//     java.awt.Paint var57 = var50.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var58 = var50.getRangeAxisEdge();
//     boolean var59 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var58);
//     var31.ensureAtLeast(0.0d, var58);
//     double var61 = var27.valueToJava2D(0.5d, var30, var58);
// 
//   }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 0.0d);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
    double var8 = var7.getUpperMargin();
    var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var8);
    org.jfree.data.general.Dataset var10 = null;
    org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var10, (java.lang.Comparable)'4');
    var12.clear();
    var12.setToolTipText("January 0");
    org.jfree.data.general.Dataset var16 = var12.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test331() {}
//   public void test331() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var31.panDomainAxes(100.0d, var33, var34);
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var31.getDomainMarkers(var36);
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var31.setDomainAxisLocation(100, var39);
//     java.awt.Graphics2D var41 = null;
//     java.awt.geom.Rectangle2D var42 = null;
//     java.awt.geom.Point2D var43 = null;
//     org.jfree.chart.plot.PlotState var44 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var45 = null;
//     var31.draw(var41, var42, var43, var44, var45);
// 
//   }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     var31.clearDomainMarkers();
//     double var33 = var31.getDomainCrosshairValue();
//     org.jfree.chart.util.RectangleEdge var34 = var31.getRangeAxisEdge();
//     org.jfree.data.time.TimeSeries var35 = null;
//     java.util.TimeZone var36 = null;
//     org.jfree.data.time.TimeSeriesCollection var37 = new org.jfree.data.time.TimeSeriesCollection(var35, var36);
//     int var38 = var31.indexOf((org.jfree.data.xy.XYDataset)var37);
//     
//     // Checks the contract:  equals-hashcode on var2 and var37
//     assertTrue("Contract failed: equals-hashcode on var2 and var37", var2.equals(var37) ? var2.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var2
//     assertTrue("Contract failed: equals-hashcode on var37 and var2", var37.equals(var2) ? var37.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var31.getDomainMarkers(var36);
    org.jfree.chart.renderer.category.BarRenderer3D var42 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var46 = var42.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var47 = var42.getBarPainter();
    double var48 = var42.getItemMargin();
    java.lang.Object var49 = var42.clone();
    java.awt.Paint var53 = var42.getItemLabelPaint(0, 2147483647, false);
    org.jfree.data.category.CategoryDataset var54 = null;
    org.jfree.chart.axis.CategoryAxis3D var56 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var58, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var63 = new org.jfree.chart.axis.DateAxis("");
    double var64 = var63.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var67 = new org.jfree.chart.entity.AxisEntity(var61, (org.jfree.chart.axis.Axis)var63, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var68 = null;
    org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot(var54, (org.jfree.chart.axis.CategoryAxis)var56, (org.jfree.chart.axis.ValueAxis)var63, var68);
    org.jfree.chart.axis.AxisLocation var71 = null;
    var69.setRangeAxisLocation(1, var71, true);
    org.jfree.chart.event.PlotChangeListener var74 = null;
    var69.addChangeListener(var74);
    org.jfree.chart.axis.AxisSpace var76 = null;
    var69.setFixedDomainAxisSpace(var76);
    org.jfree.chart.axis.CategoryAxis var78 = var69.getDomainAxis();
    double var79 = var69.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var81 = var69.getRenderer((-1));
    java.awt.Image var82 = null;
    var69.setBackgroundImage(var82);
    java.awt.Stroke var84 = var69.getDomainGridlineStroke();
    org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker(4.0d, var53, var84);
    java.awt.Font var86 = var85.getLabelFont();
    org.jfree.chart.util.Layer var87 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.addDomainMarker(0, (org.jfree.chart.plot.Marker)var85, var87, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var5 = var4.toString();
    org.jfree.data.time.Year var6 = var4.getYear();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var10 = var9.toString();
    org.jfree.data.time.TimeSeries var11 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var9);
    org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder();
    java.awt.Paint var13 = var12.getPaint();
    int var14 = var9.compareTo((java.lang.Object)var12);
    java.util.Date var15 = var9.getStart();
    org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var15, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var17.getY(13);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "January 0"+ "'", var5.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "January 0"+ "'", var10.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.RectangleInsets var36 = var31.getAxisOffset();
    org.jfree.chart.util.RectangleEdge var37 = var31.getDomainAxisEdge();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var43 = null;
    var41.setSeriesOutlinePaint(0, var43);
    var41.setUseOutlinePaint(true);
    var41.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var50 = var41.getBaseStroke();
    java.awt.Paint var54 = var41.getItemFillPaint((-1), 0, false);
    var41.setAutoPopulateSeriesPaint(true);
    var31.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var41);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var60 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var62 = var60.lookupSeriesFillPaint(1);
    var60.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    boolean var67 = var60.equals((java.lang.Object)(byte)(-1));
    var60.setBaseLinesVisible(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var70 = var60.getLegendItemLabelGenerator();
    java.awt.Paint var74 = var60.getItemOutlinePaint(0, 0, true);
    var41.setBaseOutlinePaint(var74, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var1 = var0.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getX(4, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    boolean var24 = var15.isDomainGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    var2.setAutoPopulateSeriesStroke(true);
    boolean var15 = var2.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.ItemLabelPosition var16 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesPositiveItemLabelPosition(2147483647, var18, true);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    double var2 = var0.calculateValue(0.0d);
    var0.zoomRange(4.0d, 0.0d);
    org.jfree.chart.event.AxisChangeEvent var6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.axis.NumberTickUnit var7 = var0.getTickUnit();
    org.jfree.data.KeyedValues var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable)var7, var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
//     boolean var3 = var2.isShapeVisible();
//     java.awt.Paint var4 = var2.getOutlinePaint();
//     var0.setDomainTickBandPaint(var4);
//     org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis(0);
//     org.jfree.chart.plot.PlotRenderingInfo var10 = null;
//     var0.handleClick((-1), 13, var10);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     java.awt.Paint var22 = var15.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var23 = var15.getDomainGridlinePosition();
//     org.jfree.chart.renderer.category.BarRenderer3D var26 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var29 = var26.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var30 = null;
//     var26.setBaseItemLabelGenerator(var30, false);
//     java.awt.Stroke var34 = null;
//     var26.setSeriesStroke(13, var34, false);
//     org.jfree.chart.labels.CategoryToolTipGenerator var37 = var26.getBaseToolTipGenerator();
//     int var38 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var26);
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     var15.handleClick(10, (-1), var41);
// 
//   }

  public void test342() {}
//   public void test342() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     java.util.Locale var2 = null;
//     org.jfree.data.time.Year var3 = new org.jfree.data.time.Year(var0, var1, var2);
// 
//   }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
//     java.text.NumberFormat var2 = var1.getPercentFormat();
//     org.jfree.data.general.PieDataset var3 = null;
//     java.lang.Comparable var4 = null;
//     java.text.AttributedString var5 = var1.generateAttributedSectionLabel(var3, var4);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.awt.Polygon var0 = null;
    java.awt.Polygon var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    var3.setDescription("0.05");

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("LegendItemEntity: seriesKey=null, dataset=null", var1, var2);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     double var6 = var5.getContentXOffset();
//     org.jfree.chart.entity.TitleEntity var9 = new org.jfree.chart.entity.TitleEntity(var1, (org.jfree.chart.title.Title)var5, "AxisLabelEntity: label = null", "AxisLabelEntity: label = null");
//     var5.setID("");
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.util.Size2D var13 = var5.arrange(var12);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("RectangleEdge.LEFT");
    java.awt.Paint var2 = var1.getWallPaint();
    java.awt.Paint var3 = var1.getSubtitlePaint();
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    double var10 = var9.getContentXOffset();
    org.jfree.chart.entity.TitleEntity var13 = new org.jfree.chart.entity.TitleEntity(var5, (org.jfree.chart.title.Title)var9, "AxisLabelEntity: label = null", "AxisLabelEntity: label = null");
    org.jfree.chart.title.TextTitle var14 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    var17.setUseOutlinePaint(true);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
    double var30 = var29.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var33 = new org.jfree.chart.entity.AxisEntity(var27, (org.jfree.chart.axis.Axis)var29, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var38 = var36.lookupSeriesFillPaint(1);
    var29.setTickLabelPaint(var38);
    java.awt.Paint var40 = var29.getTickMarkPaint();
    var17.setBaseFillPaint(var40, false);
    var14.setBackgroundPaint(var40);
    var9.setBackgroundPaint(var40);
    var1.setAxisLabelPaint(var40);
    java.awt.Paint var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaselinePaint(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     double var32 = var10.getUpperBound();
//     java.util.Date var33 = var10.getMaximumDate();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day(var33);
//     java.util.TimeZone var35 = null;
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year(var33, var35);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    var1.setRange(var5, false, true);
    boolean var9 = var1.isAxisLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var6 = var5.toString();
    org.jfree.data.time.Year var7 = var5.getYear();
    org.jfree.data.time.Month var10 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var11 = var10.toString();
    org.jfree.data.time.TimeSeries var12 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var10);
    org.jfree.data.time.Month var15 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var16 = var15.toString();
    org.jfree.data.time.Year var17 = var15.getYear();
    org.jfree.chart.plot.CrosshairState var19 = new org.jfree.chart.plot.CrosshairState(false);
    double var20 = var19.getCrosshairY();
    int var21 = var19.getDomainAxisIndex();
    var19.setCrosshairY(4.0d);
    var19.setDatasetIndex((-1));
    int var26 = var17.compareTo((java.lang.Object)var19);
    org.jfree.chart.axis.PeriodAxis var27 = new org.jfree.chart.axis.PeriodAxis("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.RegularTimePeriod)var7, (org.jfree.data.time.RegularTimePeriod)var17);
    org.jfree.data.time.RegularTimePeriod var28 = var27.getFirst();
    java.awt.Paint var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.setMinorTickMarkPaint(var29);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "January 0"+ "'", var6.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "January 0"+ "'", var11.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "January 0"+ "'", var16.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var31.getDomainMarkers(var36);
    boolean var38 = var31.isSubplot();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var42 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var44 = null;
    var42.setSeriesOutlinePaint(0, var44);
    var42.setUseOutlinePaint(true);
    var42.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var51 = var42.getBaseStroke();
    java.awt.Paint var55 = var42.getItemFillPaint((-1), 0, false);
    org.jfree.chart.labels.ItemLabelPosition var57 = var42.getSeriesPositiveItemLabelPosition(1);
    org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var64 = var61.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var65 = null;
    var61.setBaseItemLabelGenerator(var65, false);
    java.awt.Stroke var69 = null;
    var61.setSeriesStroke(13, var69, false);
    var61.setAutoPopulateSeriesStroke(true);
    boolean var74 = var61.getAutoPopulateSeriesPaint();
    org.jfree.chart.labels.ItemLabelPosition var75 = var61.getBasePositiveItemLabelPosition();
    var42.setSeriesNegativeItemLabelPosition(1, var75, true);
    org.jfree.chart.event.RendererChangeEvent var78 = null;
    var42.notifyListeners(var78);
    var42.setDrawSeriesLineAsPath(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setRenderer((-16777216), (org.jfree.chart.renderer.xy.XYItemRenderer)var42, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
    double var14 = var13.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
    org.jfree.chart.axis.AxisLocation var21 = null;
    var19.setRangeAxisLocation(1, var21, true);
    org.jfree.chart.event.PlotChangeListener var24 = null;
    var19.addChangeListener(var24);
    org.jfree.chart.axis.AxisSpace var26 = null;
    var19.setFixedDomainAxisSpace(var26);
    org.jfree.chart.axis.CategoryAxis var28 = var19.getDomainAxis();
    double var29 = var19.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = var19.getRenderer((-1));
    java.awt.Image var32 = null;
    var19.setBackgroundImage(var32);
    java.awt.Stroke var34 = var19.getDomainGridlineStroke();
    var1.setOutlineStroke(var34);
    java.lang.String var36 = var1.getToolTipText();
    java.lang.String var37 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(var0);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var4 = null;
//     var2.setSeriesOutlinePaint(0, var4);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.plot.XYPlot var8 = null;
//     org.jfree.data.time.TimeSeries var9 = null;
//     java.util.TimeZone var10 = null;
//     org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = var13.getInfo();
//     int var15 = var13.getLastItemIndex();
//     org.jfree.data.time.TimeSeries var16 = null;
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var16, var17);
//     org.jfree.data.Range var19 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var18);
//     org.jfree.data.DomainOrder var20 = var18.getDomainOrder();
//     var13.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var18);
//     
//     // Checks the contract:  equals-hashcode on var11 and var18
//     assertTrue("Contract failed: equals-hashcode on var11 and var18", var11.equals(var18) ? var11.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var11
//     assertTrue("Contract failed: equals-hashcode on var18 and var11", var18.equals(var11) ? var18.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.renderer.xy.XYStepAreaRenderer var0 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer();
    java.lang.Object var1 = var0.clone();
    var0.setShapesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    org.jfree.chart.axis.AxisSpace var22 = null;
    var15.setFixedDomainAxisSpace(var22);
    org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
    java.awt.Stroke var25 = var15.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(100.0d, 0.05d, var2);
// 
//   }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(1.0d, 4.0d, 0.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var9 = var6.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var12.setLine(var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.entity.PieSectionEntity var22 = new org.jfree.chart.entity.PieSectionEntity(var14, var16, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var6.setLegendShape(0, var14);
//     java.awt.Font var27 = var6.getItemLabelFont((-1), 1, true);
//     boolean var28 = var3.equals((java.lang.Object)1);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     java.lang.Boolean var34 = var32.getSeriesVisibleInLegend(1);
//     java.awt.Paint var35 = var32.getBasePaint();
//     java.awt.geom.RectangularShape var39 = null;
//     org.jfree.chart.util.RectangleEdge var40 = null;
//     var3.paintBar(var29, (org.jfree.chart.renderer.category.BarRenderer)var32, 13, (-459), true, var39, var40);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var6.", var32.equals(var6) == var6.equals(var32));
// 
//   }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("AxisLabelEntity: label = null");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     double var8 = var7.getUpperMargin();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.Size2D var11 = var5.arrange(var10);
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
    org.jfree.chart.plot.DrawingSupplier var29 = null;
    var15.setDrawingSupplier(var29);
    org.jfree.data.category.CategoryDataset var31 = null;
    var15.setDataset(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
    boolean var2 = var1.isAxisLineVisible();
    var1.setMaximumCategoryLabelLines(13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);
//     double var3 = var2.getHeight();
//     org.jfree.chart.block.LengthConstraintType var4 = var2.getHeightConstraintType();
//     java.lang.String var5 = var2.toString();
//     org.jfree.chart.block.RectangleConstraint var7 = var2.toFixedWidth(4.0d);
//     org.jfree.chart.util.Size2D var10 = new org.jfree.chart.util.Size2D(Double.NaN, (-1.0d));
//     var10.setHeight(0.05d);
//     org.jfree.chart.util.Size2D var13 = var7.calculateConstrainedSize(var10);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var15.setFixedDomainAxisSpace(var22);
//     org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
//     double var25 = var24.getUpperMargin();
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var29 = var28.toString();
//     org.jfree.data.time.Year var30 = var28.getYear();
//     var24.addCategoryLabelToolTip((java.lang.Comparable)var28, "Oct");
//     long var33 = var28.getFirstMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 0.05d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "January 0"+ "'", var29.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == (-62167363200000L));
// 
//   }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Paint var7 = var2.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var10.setLine(var12);
    var2.setSeriesShape(0, var12, true);
    boolean var16 = var2.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var25 = var21.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var26 = var21.getBarPainter();
    double var27 = var21.getItemMargin();
    java.lang.Object var28 = var21.clone();
    java.awt.Paint var32 = var21.getItemLabelPaint(0, 2147483647, false);
    org.jfree.data.category.CategoryDataset var33 = null;
    org.jfree.chart.axis.CategoryAxis3D var35 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
    double var43 = var42.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var40, (org.jfree.chart.axis.Axis)var42, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var47 = null;
    org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot(var33, (org.jfree.chart.axis.CategoryAxis)var35, (org.jfree.chart.axis.ValueAxis)var42, var47);
    org.jfree.chart.axis.AxisLocation var50 = null;
    var48.setRangeAxisLocation(1, var50, true);
    org.jfree.chart.event.PlotChangeListener var53 = null;
    var48.addChangeListener(var53);
    org.jfree.chart.axis.AxisSpace var55 = null;
    var48.setFixedDomainAxisSpace(var55);
    org.jfree.chart.axis.CategoryAxis var57 = var48.getDomainAxis();
    double var58 = var48.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var60 = var48.getRenderer((-1));
    java.awt.Image var61 = null;
    var48.setBackgroundImage(var61);
    java.awt.Stroke var63 = var48.getDomainGridlineStroke();
    org.jfree.chart.plot.ValueMarker var64 = new org.jfree.chart.plot.ValueMarker(4.0d, var32, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesStroke((-1), var63, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    double var2 = var1.getCrosshairY();
    var1.setAnchorY(10.0d);
    var1.setDatasetIndex(13);
    var1.updateCrosshairY(0.05d);
    int var9 = var1.getDomainAxisIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    boolean var4 = var3.getNotify();
    var3.setMaximumItemCount(0);
    int var8 = var3.indexOf((java.lang.Number)13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var10 = var3.getDataItem(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, (-1), 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var31.getDomainMarkers(var36);
    org.jfree.chart.axis.AxisLocation var39 = null;
    var31.setDomainAxisLocation(100, var39);
    int var41 = var31.getDomainAxisCount();
    org.jfree.data.time.TimeSeriesCollection var43 = new org.jfree.data.time.TimeSeriesCollection();
    org.jfree.chart.axis.AxisState var45 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var46 = var45.getTicks();
    java.util.Collection var47 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var46);
    org.jfree.data.Range var48 = null;
    org.jfree.data.Range var50 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var43, var46, var48, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.mapDatasetToRangeAxes(10, var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);

  }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var6 = var5.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var5);
//     java.awt.Font var8 = var7.getLabelFont();
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("", var8);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.util.Size2D var11 = var9.calculateDimensions(var10);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     var31.clearDomainMarkers();
//     var31.setWeight(0);
//     java.awt.Paint var35 = var31.getRangeMinorGridlinePaint();
//     org.jfree.data.time.TimeSeries var36 = null;
//     java.util.TimeZone var37 = null;
//     org.jfree.data.time.TimeSeriesCollection var38 = new org.jfree.data.time.TimeSeriesCollection(var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
//     double var47 = var46.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var50 = new org.jfree.chart.entity.AxisEntity(var44, (org.jfree.chart.axis.Axis)var46, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var55 = null;
//     var53.setSeriesOutlinePaint(0, var55);
//     java.awt.Paint var58 = var53.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var61.setLine(var63);
//     var53.setSeriesShape(0, var63, true);
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var38, var39, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.renderer.xy.XYItemRenderer)var53);
//     var67.clearDomainMarkers();
//     java.awt.Stroke var69 = var67.getDomainCrosshairStroke();
//     java.awt.Stroke var70 = var67.getRangeMinorGridlineStroke();
//     var31.setDomainCrosshairStroke(var70);
//     
//     // Checks the contract:  equals-hashcode on var2 and var38
//     assertTrue("Contract failed: equals-hashcode on var2 and var38", var2.equals(var38) ? var2.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var2
//     assertTrue("Contract failed: equals-hashcode on var38 and var2", var38.equals(var2) ? var38.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var61
//     assertTrue("Contract failed: equals-hashcode on var25 and var61", var25.equals(var61) ? var25.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var25
//     assertTrue("Contract failed: equals-hashcode on var61 and var25", var61.equals(var25) ? var61.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.jfree.chart.ChartTheme var0 = org.jfree.chart.StandardChartTheme.createJFreeTheme();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test375() {}
//   public void test375() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(1.0d, 4.0d, 0.0d);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     var7.setShadowVisible(false);
//     var7.setMinimumBarLength(1.0d);
//     java.awt.geom.RectangularShape var15 = null;
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(1, var33, true);
//     org.jfree.chart.event.PlotChangeListener var36 = null;
//     var31.addChangeListener(var36);
//     java.awt.Paint var38 = var31.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var39 = var31.getRangeAxisEdge();
//     boolean var40 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var39);
//     var3.paintBarShadow(var4, (org.jfree.chart.renderer.category.BarRenderer)var7, 4, 2147483647, true, var15, var39, false);
// 
//   }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var6 = var2.getItemCreateEntity((-1), 13, true);
//     org.jfree.chart.renderer.category.BarPainter var7 = var2.getBarPainter();
//     double var8 = var2.getItemMargin();
//     java.lang.Object var9 = var2.clone();
//     org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPositionFallback();
//     java.awt.Paint var11 = var2.getBaseLegendTextPaint();
//     var2.setBaseSeriesVisibleInLegend(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.data.category.CategoryDataset var16 = null;
//     org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(1, var33, false);
//     int var36 = var31.getRangeAxisCount();
//     var31.setForegroundAlpha(10.0f);
//     org.jfree.data.category.CategoryDataset var40 = var31.getDataset(100);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var43 = var2.initialise(var14, var15, var31, 15, var42);
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.CrosshairState var1 = new org.jfree.chart.plot.CrosshairState(false);
    double var2 = var1.getCrosshairY();
    var1.updateCrosshairY(0.0d);
    var1.updateCrosshairX(0.2d, (-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.time.Year var6 = var4.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeries var11 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var9);
//     java.util.Calendar var12 = null;
//     long var13 = var6.getLastMillisecond(var12);
// 
//   }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    java.awt.Paint var1 = null;
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis3D var4 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var6 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var6, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
    double var12 = var11.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var15 = new org.jfree.chart.entity.AxisEntity(var9, (org.jfree.chart.axis.Axis)var11, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var16 = null;
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var2, (org.jfree.chart.axis.CategoryAxis)var4, (org.jfree.chart.axis.ValueAxis)var11, var16);
    org.jfree.chart.axis.AxisLocation var19 = null;
    var17.setRangeAxisLocation(1, var19, true);
    org.jfree.chart.event.PlotChangeListener var22 = null;
    var17.addChangeListener(var22);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var17.setFixedDomainAxisSpace(var24);
    org.jfree.chart.axis.CategoryAxis var26 = var17.getDomainAxis();
    double var27 = var17.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var29 = var17.getRenderer((-1));
    java.awt.Image var30 = null;
    var17.setBackgroundImage(var30);
    java.awt.Stroke var32 = var17.getDomainGridlineStroke();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var37 = null;
    var35.setSeriesOutlinePaint(0, var37);
    var35.setUseOutlinePaint(true);
    var35.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Paint var47 = var35.getItemOutlinePaint((-459), (-1), true);
    org.jfree.data.category.CategoryDataset var48 = null;
    org.jfree.chart.axis.CategoryAxis3D var50 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("");
    double var58 = var57.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var61 = new org.jfree.chart.entity.AxisEntity(var55, (org.jfree.chart.axis.Axis)var57, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var62 = null;
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot(var48, (org.jfree.chart.axis.CategoryAxis)var50, (org.jfree.chart.axis.ValueAxis)var57, var62);
    org.jfree.chart.LegendItemCollection var64 = var63.getLegendItems();
    java.awt.Stroke var65 = var63.getRangeGridlineStroke();
    org.jfree.data.category.CategoryDataset var66 = null;
    org.jfree.chart.axis.CategoryAxis3D var68 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var70 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var73 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var70, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var75 = new org.jfree.chart.axis.DateAxis("");
    double var76 = var75.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var79 = new org.jfree.chart.entity.AxisEntity(var73, (org.jfree.chart.axis.Axis)var75, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var80 = null;
    org.jfree.chart.plot.CategoryPlot var81 = new org.jfree.chart.plot.CategoryPlot(var66, (org.jfree.chart.axis.CategoryAxis)var68, (org.jfree.chart.axis.ValueAxis)var75, var80);
    org.jfree.chart.axis.AxisLocation var83 = null;
    var81.setRangeAxisLocation(1, var83, true);
    org.jfree.chart.event.PlotChangeListener var86 = null;
    var81.addChangeListener(var86);
    org.jfree.chart.axis.AxisSpace var88 = null;
    var81.setFixedDomainAxisSpace(var88);
    org.jfree.chart.axis.CategoryAxis var90 = var81.getDomainAxis();
    double var91 = var81.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var93 = var81.getRenderer((-1));
    java.awt.Image var94 = null;
    var81.setBackgroundImage(var94);
    java.awt.Stroke var96 = var81.getDomainGridlineStroke();
    var63.setOutlineStroke(var96);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var99 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var32, var47, var96, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.DomainOrder var4 = var2.getDomainOrder();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.time.TimePeriodAnchor var6 = var2.getXPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var9 = var2.getXValue(1, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.axis.AxisLocation var33 = null;
//     var31.setRangeAxisLocation(13, var33);
//     int var35 = var31.getDatasetCount();
//     org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
//     org.jfree.chart.axis.AxisLocation var38 = var31.getRangeAxisLocation();
//     java.awt.Stroke var39 = var31.getRangeZeroBaselineStroke();
//     org.jfree.data.time.TimeSeries var40 = null;
//     java.util.TimeZone var41 = null;
//     org.jfree.data.time.TimeSeriesCollection var42 = new org.jfree.data.time.TimeSeriesCollection(var40, var41);
//     org.jfree.chart.axis.ValueAxis var43 = null;
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var45, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var50 = new org.jfree.chart.axis.DateAxis("");
//     double var51 = var50.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var54 = new org.jfree.chart.entity.AxisEntity(var48, (org.jfree.chart.axis.Axis)var50, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var57 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var59 = null;
//     var57.setSeriesOutlinePaint(0, var59);
//     java.awt.Paint var62 = var57.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var65.setLine(var67);
//     var57.setSeriesShape(0, var67, true);
//     org.jfree.chart.plot.XYPlot var71 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var42, var43, (org.jfree.chart.axis.ValueAxis)var50, (org.jfree.chart.renderer.xy.XYItemRenderer)var57);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     java.awt.geom.Point2D var74 = null;
//     var71.panDomainAxes(100.0d, var73, var74);
//     org.jfree.chart.util.RectangleInsets var76 = var71.getAxisOffset();
//     org.jfree.chart.util.RectangleEdge var77 = var71.getDomainAxisEdge();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var81 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var83 = null;
//     var81.setSeriesOutlinePaint(0, var83);
//     var81.setUseOutlinePaint(true);
//     var81.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var90 = var81.getBaseStroke();
//     java.awt.Paint var94 = var81.getItemFillPaint((-1), 0, false);
//     var81.setAutoPopulateSeriesPaint(true);
//     var71.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer)var81);
//     int var98 = var31.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var81);
//     
//     // Checks the contract:  equals-hashcode on var2 and var42
//     assertTrue("Contract failed: equals-hashcode on var2 and var42", var2.equals(var42) ? var2.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var2
//     assertTrue("Contract failed: equals-hashcode on var42 and var2", var42.equals(var2) ? var42.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var65
//     assertTrue("Contract failed: equals-hashcode on var25 and var65", var25.equals(var65) ? var25.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var25
//     assertTrue("Contract failed: equals-hashcode on var65 and var25", var65.equals(var25) ? var65.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var35, 0.0d, 100.0d);
//     org.jfree.chart.title.TextTitle var39 = new org.jfree.chart.title.TextTitle();
//     double var40 = var39.getContentXOffset();
//     org.jfree.chart.entity.TitleEntity var43 = new org.jfree.chart.entity.TitleEntity(var35, (org.jfree.chart.title.Title)var39, "AxisLabelEntity: label = null", "AxisLabelEntity: label = null");
//     org.jfree.chart.title.TextTitle var44 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var49 = null;
//     var47.setSeriesOutlinePaint(0, var49);
//     var47.setUseOutlinePaint(true);
//     java.awt.Shape var54 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var54, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var59 = new org.jfree.chart.axis.DateAxis("");
//     double var60 = var59.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var63 = new org.jfree.chart.entity.AxisEntity(var57, (org.jfree.chart.axis.Axis)var59, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var66 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var68 = var66.lookupSeriesFillPaint(1);
//     var59.setTickLabelPaint(var68);
//     java.awt.Paint var70 = var59.getTickMarkPaint();
//     var47.setBaseFillPaint(var70, false);
//     var44.setBackgroundPaint(var70);
//     var39.setBackgroundPaint(var70);
//     org.jfree.chart.LegendItem var75 = new org.jfree.chart.LegendItem("RectangleEdge.LEFT", var70);
//     var17.setSeriesPaint(0, var70, false);
//     
//     // Checks the contract:  equals-hashcode on var66 and var17
//     assertTrue("Contract failed: equals-hashcode on var66 and var17", var66.equals(var17) ? var66.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var66 and var17.", var66.equals(var17) == var17.equals(var66));
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Paint var7 = var2.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var10.setLine(var12);
    var2.setSeriesShape(0, var12, true);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var12);
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection();
    double var18 = var17.getIntervalWidth();
    var16.setDataset((org.jfree.data.general.Dataset)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.setSelected((-1), 0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
    int var6 = var5.getMaximumItemCount();
    java.lang.String var7 = var5.getRangeDescription();
    org.jfree.data.time.TimeSeries var8 = var1.addAndOrUpdate(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(10, 1, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleEdge.LEFT"+ "'", var7.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     double var32 = var10.getUpperBound();
//     java.util.Date var33 = var10.getMaximumDate();
//     org.jfree.data.time.Day var34 = new org.jfree.data.time.Day(var33);
//     java.util.Calendar var35 = null;
//     var34.peg(var35);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setRangeAxisLocation(1, var38, true);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var36.addChangeListener(var41);
    java.awt.Paint var43 = var36.getRangeCrosshairPaint();
    var15.setNoDataMessagePaint(var43);
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var51 = var50.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var50);
    java.awt.Font var53 = var52.getLabelFont();
    org.jfree.chart.util.Layer var54 = null;
    var15.addRangeMarker(1, (org.jfree.chart.plot.Marker)var52, var54);
    float var56 = var52.getAlpha();
    var52.setLabel("ThreadContext");
    org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var64 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var65 = var64.toString();
    org.jfree.data.time.Year var66 = var64.getYear();
    org.jfree.data.time.Month var69 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var70 = var69.toString();
    org.jfree.data.time.TimeSeries var71 = var61.createCopy((org.jfree.data.time.RegularTimePeriod)var66, (org.jfree.data.time.RegularTimePeriod)var69);
    org.jfree.data.time.Month var74 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var75 = var74.toString();
    org.jfree.data.time.Year var76 = var74.getYear();
    org.jfree.chart.plot.CrosshairState var78 = new org.jfree.chart.plot.CrosshairState(false);
    double var79 = var78.getCrosshairY();
    int var80 = var78.getDomainAxisIndex();
    var78.setCrosshairY(4.0d);
    var78.setDatasetIndex((-1));
    int var85 = var76.compareTo((java.lang.Object)var78);
    org.jfree.chart.axis.PeriodAxis var86 = new org.jfree.chart.axis.PeriodAxis("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.RegularTimePeriod)var66, (org.jfree.data.time.RegularTimePeriod)var76);
    org.jfree.data.time.RegularTimePeriod var87 = var86.getFirst();
    java.lang.Class var88 = var86.getMinorTickTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.EventListener[] var89 = var52.getListeners(var88);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.8f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var65 + "' != '" + "January 0"+ "'", var65.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var70 + "' != '" + "January 0"+ "'", var70.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var75 + "' != '" + "January 0"+ "'", var75.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Color var1 = java.awt.Color.decode("poly");
      fail("Expected exception of type java.lang.NumberFormatException");
    } catch (java.lang.NumberFormatException e) {
      // Expected exception.
    }

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
//     var2.setBaseItemLabelGenerator(var6, false);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(13, var10, false);
//     var2.setAutoPopulateSeriesStroke(true);
//     boolean var15 = var2.getAutoPopulateSeriesPaint();
//     org.jfree.chart.labels.ItemLabelPosition var16 = var2.getBasePositiveItemLabelPosition();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var18 = null;
//     var2.setSeriesItemLabelGenerator(15, var18);
//     java.awt.Graphics2D var20 = null;
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.LegendItemCollection var37 = var36.getLegendItems();
//     java.awt.geom.Rectangle2D var38 = null;
//     var2.drawBackground(var20, var36, var38);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     org.jfree.data.general.WaferMapDataset var1 = null;
//     var0.setDataset(var1);
//     org.jfree.data.general.WaferMapDataset var3 = var0.getDataset();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var21.setRangeAxisLocation(1, var23, true);
//     org.jfree.chart.event.PlotChangeListener var26 = null;
//     var21.addChangeListener(var26);
//     java.awt.Paint var28 = var21.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var29 = var21.getRangeAxisEdge();
//     org.jfree.chart.plot.PlotRenderingInfo var31 = null;
//     org.jfree.data.time.TimeSeries var32 = null;
//     java.util.TimeZone var33 = null;
//     org.jfree.data.time.TimeSeriesCollection var34 = new org.jfree.data.time.TimeSeriesCollection(var32, var33);
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var37, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis("");
//     double var43 = var42.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var46 = new org.jfree.chart.entity.AxisEntity(var40, (org.jfree.chart.axis.Axis)var42, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var51 = null;
//     var49.setSeriesOutlinePaint(0, var51);
//     java.awt.Paint var54 = var49.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var57.setLine(var59);
//     var49.setSeriesShape(0, var59, true);
//     org.jfree.chart.plot.XYPlot var63 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var34, var35, (org.jfree.chart.axis.ValueAxis)var42, (org.jfree.chart.renderer.xy.XYItemRenderer)var49);
//     org.jfree.chart.axis.AxisLocation var65 = null;
//     var63.setRangeAxisLocation(13, var65);
//     int var67 = var63.getDatasetCount();
//     java.awt.geom.Point2D var68 = var63.getQuadrantOrigin();
//     var21.zoomDomainAxes(0.0d, var31, var68);
//     org.jfree.chart.plot.PlotState var70 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var71 = null;
//     var0.draw(var4, var5, var68, var70, var71);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(13, var33);
    int var35 = var31.getDatasetCount();
    var31.setRangeCrosshairLockedOnData(false);
    java.awt.Paint var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setDomainMinorGridlinePaint(var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setRangeAxisLocation(1, var38, true);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var36.addChangeListener(var41);
    java.awt.Paint var43 = var36.getRangeCrosshairPaint();
    var15.setNoDataMessagePaint(var43);
    java.awt.Color var50 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var51 = var50.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var52 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var50);
    java.awt.Font var53 = var52.getLabelFont();
    org.jfree.chart.util.Layer var54 = null;
    var15.addRangeMarker(1, (org.jfree.chart.plot.Marker)var52, var54);
    float var56 = var52.getAlpha();
    var52.setLabel("ThreadContext");
    org.jfree.chart.util.LengthAdjustmentType var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var52.setLabelOffsetType(var59);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.8f);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var6 = var5.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var5);
    java.awt.Font var8 = var7.getLabelFont();
    org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("", var8);
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var16 = var12.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var17 = var12.getBarPainter();
    double var18 = var12.getItemMargin();
    java.lang.Object var19 = var12.clone();
    java.awt.Paint var23 = var12.getItemLabelPaint(0, 2147483647, false);
    boolean var24 = var9.equals((java.lang.Object)var23);
    float var25 = var9.getBaselineOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0f);

  }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 100.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.axis.DateAxis var7 = new org.jfree.chart.axis.DateAxis("");
//     double var8 = var7.getUpperMargin();
//     var4.add((org.jfree.chart.block.Block)var5, (java.lang.Object)var8);
//     org.jfree.data.general.Dataset var10 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var12 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var10, (java.lang.Comparable)'4');
//     org.jfree.chart.util.HorizontalAlignment var13 = null;
//     org.jfree.chart.util.VerticalAlignment var14 = null;
//     org.jfree.chart.block.FlowArrangement var17 = new org.jfree.chart.block.FlowArrangement(var13, var14, 100.0d, 0.0d);
//     org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.axis.DateAxis var20 = new org.jfree.chart.axis.DateAxis("");
//     double var21 = var20.getUpperMargin();
//     var17.add((org.jfree.chart.block.Block)var18, (java.lang.Object)var21);
//     org.jfree.data.general.Dataset var23 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var25 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var17, var23, (java.lang.Comparable)'4');
//     var25.clear();
//     var25.setToolTipText("January 0");
//     java.awt.Graphics2D var29 = null;
//     org.jfree.data.Range var31 = null;
//     org.jfree.chart.block.RectangleConstraint var32 = new org.jfree.chart.block.RectangleConstraint(100.0d, var31);
//     java.lang.String var33 = var32.toString();
//     org.jfree.data.Range var34 = var32.getHeightRange();
//     org.jfree.chart.util.Size2D var35 = var4.arrange((org.jfree.chart.block.BlockContainer)var25, var29, var32);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    var2.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    java.awt.Shape var8 = var2.getLegendLine();
    boolean var11 = var2.getItemShapeFilled(12, (-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    java.awt.Color var2 = java.awt.Color.getColor("hi!", 1);
    int var3 = var2.getRed();
    org.jfree.data.time.TimeSeries var4 = null;
    java.util.TimeZone var5 = null;
    org.jfree.data.time.TimeSeriesCollection var6 = new org.jfree.data.time.TimeSeriesCollection(var4, var5);
    org.jfree.chart.axis.ValueAxis var7 = null;
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    double var15 = var14.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var18 = new org.jfree.chart.entity.AxisEntity(var12, (org.jfree.chart.axis.Axis)var14, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var23 = null;
    var21.setSeriesOutlinePaint(0, var23);
    java.awt.Paint var26 = var21.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var29.setLine(var31);
    var21.setSeriesShape(0, var31, true);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var6, var7, (org.jfree.chart.axis.ValueAxis)var14, (org.jfree.chart.renderer.xy.XYItemRenderer)var21);
    org.jfree.chart.axis.AxisLocation var37 = null;
    var35.setRangeAxisLocation(13, var37);
    int var39 = var35.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var41 = var35.getRangeAxisLocation((-1));
    boolean var42 = var2.equals((java.lang.Object)(-1));
    float[] var46 = new float[] { 10.0f, (-1.0f), 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var47 = var2.getComponents(var46);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    org.jfree.data.xy.DefaultXYDataset var0 = new org.jfree.data.xy.DefaultXYDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.getYValue(100, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test398() {}
//   public void test398() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }
// 
// 
//     org.jfree.chart.plot.CombinedDomainXYPlot var0 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     org.jfree.chart.LegendItem var2 = new org.jfree.chart.LegendItem("hi!");
//     boolean var3 = var2.isShapeVisible();
//     java.awt.Paint var4 = var2.getOutlinePaint();
//     var0.setDomainTickBandPaint(var4);
//     org.jfree.data.category.CategoryDataset var6 = null;
//     org.jfree.chart.axis.CategoryAxis3D var8 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var20 = null;
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var6, (org.jfree.chart.axis.CategoryAxis)var8, (org.jfree.chart.axis.ValueAxis)var15, var20);
//     org.jfree.chart.axis.AxisLocation var23 = null;
//     var21.setRangeAxisLocation(1, var23, false);
//     int var26 = var21.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis3D var29 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var31 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var31, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var36 = new org.jfree.chart.axis.DateAxis("");
//     double var37 = var36.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var40 = new org.jfree.chart.entity.AxisEntity(var34, (org.jfree.chart.axis.Axis)var36, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var27, (org.jfree.chart.axis.CategoryAxis)var29, (org.jfree.chart.axis.ValueAxis)var36, var41);
//     org.jfree.chart.axis.AxisLocation var44 = null;
//     var42.setRangeAxisLocation(1, var44, true);
//     org.jfree.chart.event.PlotChangeListener var47 = null;
//     var42.addChangeListener(var47);
//     java.awt.Paint var49 = var42.getRangeCrosshairPaint();
//     var21.setNoDataMessagePaint(var49);
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.event.AxisChangeEvent var52 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var51);
//     var21.axisChanged(var52);
//     var0.axisChanged(var52);
//     java.lang.Object var55 = var0.clone();
//     java.awt.Paint var56 = var0.getRangeGridlinePaint();
//     org.jfree.chart.plot.CombinedDomainXYPlot var57 = new org.jfree.chart.plot.CombinedDomainXYPlot();
//     var57.setDomainCrosshairValue(Double.NaN, true);
//     org.jfree.chart.axis.AxisSpace var61 = new org.jfree.chart.axis.AxisSpace();
//     var61.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var65 = null;
//     org.jfree.chart.axis.CategoryAxis3D var67 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var69, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis("");
//     double var75 = var74.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var78 = new org.jfree.chart.entity.AxisEntity(var72, (org.jfree.chart.axis.Axis)var74, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var79 = null;
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot(var65, (org.jfree.chart.axis.CategoryAxis)var67, (org.jfree.chart.axis.ValueAxis)var74, var79);
//     org.jfree.chart.axis.AxisLocation var82 = null;
//     var80.setRangeAxisLocation(1, var82, true);
//     org.jfree.chart.event.PlotChangeListener var85 = null;
//     var80.addChangeListener(var85);
//     java.awt.Paint var87 = var80.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var88 = var80.getRangeAxisEdge();
//     boolean var89 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var88);
//     var61.ensureAtLeast(0.0d, var88);
//     var61.setRight(1.0d);
//     var57.setFixedDomainAxisSpace(var61);
//     java.lang.Object var94 = null;
//     boolean var95 = var57.equals(var94);
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var57);
//     
//     // Checks the contract:  equals-hashcode on var42 and var80
//     assertTrue("Contract failed: equals-hashcode on var42 and var80", var42.equals(var80) ? var42.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var42
//     assertTrue("Contract failed: equals-hashcode on var80 and var42", var80.equals(var42) ? var80.hashCode() == var42.hashCode() : true);
// 
//   }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    org.jfree.data.time.TimeSeries var15 = var11.getSeries((java.lang.Comparable)4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test400() {}
//   public void test400() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var3 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var1.setLine(var3);
//     org.jfree.data.general.PieDataset var5 = null;
//     org.jfree.chart.entity.PieSectionEntity var11 = new org.jfree.chart.entity.PieSectionEntity(var3, var5, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     java.lang.String var12 = var11.getShapeType();
//     org.jfree.data.general.PieDataset var13 = var11.getDataset();
//     org.jfree.data.time.TimeSeries var14 = null;
//     java.util.TimeZone var15 = null;
//     org.jfree.data.time.TimeSeriesCollection var16 = new org.jfree.data.time.TimeSeriesCollection(var14, var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     java.awt.Shape var19 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var19, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis("");
//     double var25 = var24.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var28 = new org.jfree.chart.entity.AxisEntity(var22, (org.jfree.chart.axis.Axis)var24, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var31 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var33 = null;
//     var31.setSeriesOutlinePaint(0, var33);
//     java.awt.Paint var36 = var31.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var39 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var39.setLine(var41);
//     var31.setSeriesShape(0, var41, true);
//     org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var16, var17, (org.jfree.chart.axis.ValueAxis)var24, (org.jfree.chart.renderer.xy.XYItemRenderer)var31);
//     double var46 = var24.getUpperBound();
//     java.util.Date var47 = var24.getMaximumDate();
//     boolean var48 = var11.equals((java.lang.Object)var24);
//     
//     // Checks the contract:  equals-hashcode on var1 and var39
//     assertTrue("Contract failed: equals-hashcode on var1 and var39", var1.equals(var39) ? var1.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var1
//     assertTrue("Contract failed: equals-hashcode on var39 and var1", var39.equals(var1) ? var39.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    java.awt.Shape var0 = null;
    org.jfree.data.category.CategoryDataset var1 = null;
    org.jfree.chart.axis.CategoryAxis3D var3 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot(var1, (org.jfree.chart.axis.CategoryAxis)var3, (org.jfree.chart.axis.ValueAxis)var10, var15);
    org.jfree.chart.axis.AxisLocation var18 = null;
    var16.setRangeAxisLocation(1, var18, false);
    int var21 = var16.getRangeAxisCount();
    org.jfree.chart.plot.Marker var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var16.removeDomainMarker(var22, var23);
    java.awt.Paint var25 = var16.getDomainGridlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendGraphic var26 = new org.jfree.chart.title.LegendGraphic(var0, var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     org.jfree.chart.axis.AxisSpace var22 = null;
//     var15.setFixedDomainAxisSpace(var22);
//     org.jfree.chart.axis.CategoryAxis var24 = var15.getDomainAxis();
//     double var25 = var24.getLowerMargin();
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.axis.AxisState var31 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var32 = var31.getTicks();
//     var31.cursorLeft(Double.NaN);
//     org.jfree.data.category.CategoryDataset var36 = null;
//     org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
//     double var46 = var45.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var49 = new org.jfree.chart.entity.AxisEntity(var43, (org.jfree.chart.axis.Axis)var45, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
//     org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var36, (org.jfree.chart.axis.CategoryAxis)var38, (org.jfree.chart.axis.ValueAxis)var45, var50);
//     org.jfree.chart.axis.AxisLocation var53 = null;
//     var51.setRangeAxisLocation(1, var53, true);
//     org.jfree.chart.event.PlotChangeListener var56 = null;
//     var51.addChangeListener(var56);
//     java.awt.Paint var58 = var51.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var59 = var51.getRangeAxisEdge();
//     var31.moveCursor(10.0d, var59);
//     org.jfree.chart.plot.PlotRenderingInfo var61 = null;
//     org.jfree.chart.axis.AxisState var62 = var24.draw(var26, 0.2d, var28, var29, var59, var61);
// 
//   }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var3 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var6 = var3.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var9 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var9.setLine(var11);
//     org.jfree.data.general.PieDataset var13 = null;
//     org.jfree.chart.entity.PieSectionEntity var19 = new org.jfree.chart.entity.PieSectionEntity(var11, var13, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var3.setLegendShape(0, var11);
//     java.awt.Font var24 = var3.getItemLabelFont((-1), 1, true);
//     java.awt.Color var27 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var28 = var27.getColorSpace();
//     org.jfree.chart.block.LabelBlock var29 = new org.jfree.chart.block.LabelBlock("", var24, (java.awt.Paint)var27);
//     java.awt.Graphics2D var30 = null;
//     org.jfree.data.Range var31 = null;
//     org.jfree.chart.axis.DateAxis var33 = new org.jfree.chart.axis.DateAxis("");
//     double var34 = var33.getUpperMargin();
//     org.jfree.data.Range var35 = null;
//     org.jfree.data.Range var37 = org.jfree.data.Range.expandToInclude(var35, 0.0d);
//     var33.setRange(var37, false, true);
//     org.jfree.chart.block.RectangleConstraint var41 = new org.jfree.chart.block.RectangleConstraint(var31, var37);
//     org.jfree.chart.util.Size2D var42 = var29.arrange(var30, var41);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.chart.StandardChartTheme var3 = new org.jfree.chart.StandardChartTheme("");
    java.awt.Color var6 = java.awt.Color.getColor("hi!", 1);
    int var7 = var6.getRed();
    var3.setWallPaint((java.awt.Paint)var6);
    boolean var9 = var1.equals((java.lang.Object)var3);
    org.jfree.chart.axis.AxisState var11 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var12 = var11.getTicks();
    java.util.Collection var13 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var12);
    org.jfree.chart.JFreeChart var14 = null;
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.event.AxisChangeEvent var16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var15);
    org.jfree.chart.event.ChartChangeEventType var17 = var16.getType();
    org.jfree.chart.event.ChartChangeEvent var18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var13, var14, var17);
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Stroke var21 = null;
    var20.setOutlineStroke(var21);
    java.lang.Comparable var23 = var20.getSeriesKey();
    var20.setSeriesIndex(4);
    boolean var26 = var17.equals((java.lang.Object)var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var27 = var1.compareTo((java.lang.Object)var26);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.jfree.data.Range var1 = null;
//     org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(100.0d, var1);
//     double var3 = var2.getHeight();
//     org.jfree.chart.block.LengthConstraintType var4 = var2.getHeightConstraintType();
//     org.jfree.data.Range var5 = var2.getHeightRange();
//     org.jfree.chart.util.Size2D var8 = new org.jfree.chart.util.Size2D(Double.NaN, (-1.0d));
//     var8.setHeight(0.05d);
//     org.jfree.chart.util.Size2D var11 = var2.calculateConstrainedSize(var8);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.renderer.xy.XYBarPainter var0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Stroke var2 = null;
    var1.setOutlineStroke(var2);
    java.lang.Comparable var4 = var1.getSeriesKey();
    org.jfree.data.category.CategoryDataset var5 = null;
    org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
    double var15 = var14.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var18 = new org.jfree.chart.entity.AxisEntity(var12, (org.jfree.chart.axis.Axis)var14, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var14, var19);
    org.jfree.chart.axis.AxisLocation var22 = null;
    var20.setRangeAxisLocation(1, var22, true);
    org.jfree.chart.event.PlotChangeListener var25 = null;
    var20.addChangeListener(var25);
    java.awt.Paint var27 = var20.getRangeCrosshairPaint();
    var1.setLinePaint(var27);
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var34 = var31.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var35 = null;
    var31.setBaseItemLabelGenerator(var35, false);
    java.awt.Stroke var39 = null;
    var31.setSeriesStroke(13, var39, false);
    org.jfree.chart.util.GradientPaintTransformer var42 = var31.getGradientPaintTransformer();
    var1.setFillPaintTransformer(var42);
    boolean var44 = var1.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(1.0d, 4.0d, 0.0d);
//     org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var9 = var6.getLegendItem((-1), 13);
//     org.jfree.chart.LegendItem var12 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var14 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var12.setLine(var14);
//     org.jfree.data.general.PieDataset var16 = null;
//     org.jfree.chart.entity.PieSectionEntity var22 = new org.jfree.chart.entity.PieSectionEntity(var14, var16, (-1), 0, (java.lang.Comparable)100.0f, "", "");
//     var6.setLegendShape(0, var14);
//     java.awt.Font var27 = var6.getItemLabelFont((-1), 1, true);
//     boolean var28 = var3.equals((java.lang.Object)1);
//     java.awt.Graphics2D var29 = null;
//     org.jfree.chart.renderer.category.BarRenderer var30 = null;
//     java.awt.geom.RectangularShape var34 = null;
//     org.jfree.chart.axis.AxisState var36 = new org.jfree.chart.axis.AxisState(100.0d);
//     java.util.List var37 = var36.getTicks();
//     org.jfree.data.category.CategoryDataset var39 = null;
//     org.jfree.chart.axis.CategoryAxis3D var41 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var43, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("");
//     double var49 = var48.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var52 = new org.jfree.chart.entity.AxisEntity(var46, (org.jfree.chart.axis.Axis)var48, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var53 = null;
//     org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot(var39, (org.jfree.chart.axis.CategoryAxis)var41, (org.jfree.chart.axis.ValueAxis)var48, var53);
//     org.jfree.chart.axis.AxisLocation var56 = null;
//     var54.setRangeAxisLocation(1, var56, true);
//     org.jfree.chart.event.PlotChangeListener var59 = null;
//     var54.addChangeListener(var59);
//     java.awt.Paint var61 = var54.getRangeCrosshairPaint();
//     var54.zoom((-1.0d));
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     java.awt.geom.Point2D var66 = null;
//     var54.panRangeAxes(Double.NaN, var65, var66);
//     org.jfree.chart.util.RectangleEdge var68 = var54.getRangeAxisEdge();
//     org.jfree.chart.util.RectangleEdge var69 = org.jfree.chart.util.RectangleEdge.opposite(var68);
//     var36.moveCursor(2.0d, var68);
//     var3.paintBarShadow(var29, var30, 12, 12, false, var34, var68, false);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.DomainOrder var4 = var2.getDomainOrder();
    java.lang.Number var5 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.chart.axis.AxisState var7 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var8 = var7.getTicks();
    java.util.Collection var9 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var8);
    org.jfree.chart.axis.DateAxis var11 = new org.jfree.chart.axis.DateAxis("");
    double var12 = var11.getUpperMargin();
    org.jfree.data.Range var13 = null;
    org.jfree.data.Range var15 = org.jfree.data.Range.expandToInclude(var13, 0.0d);
    var11.setRange(var15, false, true);
    org.jfree.data.Range var20 = org.jfree.data.Range.shift(var15, (-1.0d));
    double var22 = var20.constrain(4.0d);
    org.jfree.data.Range var24 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset)var2, var8, var20, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var2.getEndYValue(10, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + Double.NaN+ "'", var5.equals(Double.NaN));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     var31.clearDomainMarkers();
//     var31.setWeight(0);
//     org.jfree.data.time.TimeSeries var36 = null;
//     java.util.TimeZone var37 = null;
//     org.jfree.data.time.TimeSeriesCollection var38 = new org.jfree.data.time.TimeSeriesCollection(var36, var37);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var44 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var41, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var46 = new org.jfree.chart.axis.DateAxis("");
//     double var47 = var46.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var50 = new org.jfree.chart.entity.AxisEntity(var44, (org.jfree.chart.axis.Axis)var46, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var55 = null;
//     var53.setSeriesOutlinePaint(0, var55);
//     java.awt.Paint var58 = var53.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var61 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var61.setLine(var63);
//     var53.setSeriesShape(0, var63, true);
//     org.jfree.chart.plot.XYPlot var67 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var38, var39, (org.jfree.chart.axis.ValueAxis)var46, (org.jfree.chart.renderer.xy.XYItemRenderer)var53);
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     java.awt.geom.Point2D var70 = null;
//     var67.panDomainAxes(100.0d, var69, var70);
//     org.jfree.chart.util.Layer var72 = null;
//     java.util.Collection var73 = var67.getDomainMarkers(var72);
//     boolean var74 = var67.isSubplot();
//     org.jfree.chart.axis.NumberAxis var75 = new org.jfree.chart.axis.NumberAxis();
//     var67.setRangeAxis((org.jfree.chart.axis.ValueAxis)var75);
//     var31.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis)var75, true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var38
//     assertTrue("Contract failed: equals-hashcode on var2 and var38", var2.equals(var38) ? var2.hashCode() == var38.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var38 and var2
//     assertTrue("Contract failed: equals-hashcode on var38 and var2", var38.equals(var2) ? var38.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var61
//     assertTrue("Contract failed: equals-hashcode on var25 and var61", var25.equals(var61) ? var25.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var25
//     assertTrue("Contract failed: equals-hashcode on var61 and var25", var61.equals(var25) ? var61.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.data.category.CategoryDataset var3 = null;
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var7, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    double var13 = var12.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var16 = new org.jfree.chart.entity.AxisEntity(var10, (org.jfree.chart.axis.Axis)var12, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = null;
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot(var3, (org.jfree.chart.axis.CategoryAxis)var5, (org.jfree.chart.axis.ValueAxis)var12, var17);
    org.jfree.chart.axis.AxisLocation var20 = null;
    var18.setRangeAxisLocation(1, var20, true);
    org.jfree.chart.event.PlotChangeListener var23 = null;
    var18.addChangeListener(var23);
    java.awt.Paint var25 = var18.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var26 = var18.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    org.jfree.data.time.TimeSeries var29 = null;
    java.util.TimeZone var30 = null;
    org.jfree.data.time.TimeSeriesCollection var31 = new org.jfree.data.time.TimeSeriesCollection(var29, var30);
    org.jfree.chart.axis.ValueAxis var32 = null;
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var34, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var39 = new org.jfree.chart.axis.DateAxis("");
    double var40 = var39.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var43 = new org.jfree.chart.entity.AxisEntity(var37, (org.jfree.chart.axis.Axis)var39, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var48 = null;
    var46.setSeriesOutlinePaint(0, var48);
    java.awt.Paint var51 = var46.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var56 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var54.setLine(var56);
    var46.setSeriesShape(0, var56, true);
    org.jfree.chart.plot.XYPlot var60 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var31, var32, (org.jfree.chart.axis.ValueAxis)var39, (org.jfree.chart.renderer.xy.XYItemRenderer)var46);
    org.jfree.chart.axis.AxisLocation var62 = null;
    var60.setRangeAxisLocation(13, var62);
    int var64 = var60.getDatasetCount();
    java.awt.geom.Point2D var65 = var60.getQuadrantOrigin();
    var18.zoomDomainAxes(0.0d, var28, var65);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.zoomDomainAxes(4.0d, var2, var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.data.xy.XYSeriesCollection var1 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var2 = var1.getSeries();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var4 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var2, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
    int var6 = var5.getMaximumItemCount();
    java.lang.String var7 = var5.getRangeDescription();
    org.jfree.data.time.TimeSeries var8 = var1.addAndOrUpdate(var5);
    java.util.List var9 = var8.getItems();
    org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
    int var16 = var15.getMaximumItemCount();
    java.lang.String var17 = var15.getRangeDescription();
    org.jfree.data.time.TimeSeries var18 = var11.addAndOrUpdate(var15);
    java.util.List var19 = var18.getItems();
    org.jfree.data.time.TimeSeries var20 = var8.addAndOrUpdate(var18);
    java.util.TimeZone var21 = null;
    org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var20, var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var24 = var20.getTimePeriod(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + "RectangleEdge.LEFT"+ "'", var7.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleEdge.LEFT"+ "'", var17.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = var15.getRenderer(1);
    float var31 = var15.getForegroundAlpha();
    org.jfree.chart.axis.AxisSpace var32 = new org.jfree.chart.axis.AxisSpace();
    var32.setRight(10.0d);
    org.jfree.data.category.CategoryDataset var36 = null;
    org.jfree.chart.axis.CategoryAxis3D var38 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var40 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var40, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var45 = new org.jfree.chart.axis.DateAxis("");
    double var46 = var45.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var49 = new org.jfree.chart.entity.AxisEntity(var43, (org.jfree.chart.axis.Axis)var45, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var50 = null;
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var36, (org.jfree.chart.axis.CategoryAxis)var38, (org.jfree.chart.axis.ValueAxis)var45, var50);
    org.jfree.chart.axis.AxisLocation var53 = null;
    var51.setRangeAxisLocation(1, var53, true);
    org.jfree.chart.event.PlotChangeListener var56 = null;
    var51.addChangeListener(var56);
    java.awt.Paint var58 = var51.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var59 = var51.getRangeAxisEdge();
    boolean var60 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var59);
    var32.ensureAtLeast(0.0d, var59);
    var32.setRight(1.0d);
    var15.setFixedRangeAxisSpace(var32);
    java.lang.Object var65 = var15.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     double var2 = var1.getUpperMargin();
//     var1.setAutoRangeMinimumSize(0.05d, true);
//     java.text.DateFormat var6 = null;
//     var1.setDateFormatOverride(var6);
//     org.jfree.chart.axis.DateTickUnit var8 = null;
//     var1.setTickUnit(var8);
//     var1.pan(Double.NaN);
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.axis.AxisSpace var14 = new org.jfree.chart.axis.AxisSpace();
//     var14.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
//     double var28 = var27.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var20, (org.jfree.chart.axis.ValueAxis)var27, var32);
//     org.jfree.chart.axis.AxisLocation var35 = null;
//     var33.setRangeAxisLocation(1, var35, true);
//     org.jfree.chart.event.PlotChangeListener var38 = null;
//     var33.addChangeListener(var38);
//     java.awt.Paint var40 = var33.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var41 = var33.getRangeAxisEdge();
//     boolean var42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var41);
//     var14.ensureAtLeast(0.0d, var41);
//     double var44 = var1.lengthToJava2D(10.0d, var13, var41);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Oct");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(13, var33);
    int var35 = var31.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var37 = var31.getRangeAxisLocation((-1));
    org.jfree.chart.axis.AxisLocation var38 = var31.getRangeAxisLocation();
    java.awt.Stroke var39 = var31.getRangeZeroBaselineStroke();
    java.io.ObjectOutputStream var40 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var39, var40);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     var0.setRight(10.0d);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var19.addChangeListener(var24);
//     java.awt.Paint var26 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var27 = var19.getRangeAxisEdge();
//     boolean var28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var27);
//     var0.ensureAtLeast(0.0d, var27);
//     var0.setRight(1.0d);
//     java.lang.String var32 = var0.toString();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     org.jfree.chart.axis.CategoryAxis3D var36 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var41 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var38, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var43 = new org.jfree.chart.axis.DateAxis("");
//     double var44 = var43.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var47 = new org.jfree.chart.entity.AxisEntity(var41, (org.jfree.chart.axis.Axis)var43, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot(var34, (org.jfree.chart.axis.CategoryAxis)var36, (org.jfree.chart.axis.ValueAxis)var43, var48);
//     org.jfree.chart.axis.AxisLocation var51 = null;
//     var49.setRangeAxisLocation(1, var51, true);
//     org.jfree.chart.event.PlotChangeListener var54 = null;
//     var49.addChangeListener(var54);
//     java.awt.Paint var56 = var49.getRangeCrosshairPaint();
//     org.jfree.chart.util.RectangleEdge var57 = var49.getRangeAxisEdge();
//     var0.ensureAtLeast(0.0d, var57);
//     
//     // Checks the contract:  equals-hashcode on var19 and var49
//     assertTrue("Contract failed: equals-hashcode on var19 and var49", var19.equals(var49) ? var19.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var19
//     assertTrue("Contract failed: equals-hashcode on var49 and var19", var49.equals(var19) ? var49.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("RectangleEdge.LEFT");
    org.jfree.chart.JFreeChart var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.apply(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
//     org.jfree.data.category.CategoryDataset var4 = null;
//     org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var18 = null;
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot(var4, (org.jfree.chart.axis.CategoryAxis)var6, (org.jfree.chart.axis.ValueAxis)var13, var18);
//     org.jfree.chart.axis.AxisLocation var21 = null;
//     var19.setRangeAxisLocation(1, var21, true);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var19.addChangeListener(var24);
//     java.awt.Paint var26 = var19.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var27 = var19.getDomainGridlinePosition();
//     var2.addChangeListener((org.jfree.data.general.DatasetChangeListener)var19);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.data.time.TimeSeries var31 = null;
//     java.util.TimeZone var32 = null;
//     org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     double var42 = var41.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var50 = null;
//     var48.setSeriesOutlinePaint(0, var50);
//     java.awt.Paint var53 = var48.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var56.setLine(var58);
//     var48.setSeriesShape(0, var58, true);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var33, var34, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var48);
//     org.jfree.chart.axis.AxisLocation var64 = null;
//     var62.setRangeAxisLocation(13, var64);
//     int var66 = var62.getDatasetCount();
//     java.awt.geom.Point2D var67 = var62.getQuadrantOrigin();
//     var19.zoomRangeAxes(1.0d, var30, var67, true);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, false);
    int var20 = var15.getRangeAxisCount();
    org.jfree.data.category.CategoryDataset var21 = null;
    org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
    org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
    org.jfree.chart.axis.AxisLocation var38 = null;
    var36.setRangeAxisLocation(1, var38, true);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var36.addChangeListener(var41);
    java.awt.Paint var43 = var36.getRangeCrosshairPaint();
    var15.setNoDataMessagePaint(var43);
    java.awt.Paint var45 = var15.getDomainGridlinePaint();
    org.jfree.chart.plot.Plot var46 = var15.getParent();
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var52 = var49.getLegendItem((-1), 13);
    org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var55.setLine(var57);
    org.jfree.data.general.PieDataset var59 = null;
    org.jfree.chart.entity.PieSectionEntity var65 = new org.jfree.chart.entity.PieSectionEntity(var57, var59, (-1), 0, (java.lang.Comparable)100.0f, "", "");
    var49.setLegendShape(0, var57);
    java.awt.Font var70 = var49.getItemLabelFont((-1), 1, true);
    int var71 = var15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
    org.jfree.data.time.TimeSeries var73 = null;
    java.util.TimeZone var74 = null;
    org.jfree.data.time.TimeSeriesCollection var75 = new org.jfree.data.time.TimeSeriesCollection(var73, var74);
    org.jfree.data.Range var76 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var75);
    int var78 = var75.indexOf((java.lang.Comparable)true);
    org.jfree.chart.axis.AxisState var80 = new org.jfree.chart.axis.AxisState(100.0d);
    java.util.List var81 = var80.getTicks();
    var80.cursorLeft(Double.NaN);
    java.util.List var84 = var80.getTicks();
    org.jfree.data.time.DateRange var87 = new org.jfree.data.time.DateRange(0.05d, 18.0d);
    long var88 = var87.getUpperMillis();
    org.jfree.data.Range var90 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var75, var84, (org.jfree.data.Range)var87, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.mapDatasetToRangeAxes(100, var84);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 18L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var90);

  }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var31.panDomainAxes(100.0d, var33, var34);
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var31.getDomainMarkers(var36);
//     org.jfree.chart.axis.AxisLocation var39 = null;
//     var31.setDomainAxisLocation(100, var39);
//     org.jfree.chart.renderer.xy.XYItemRenderer var42 = var31.getRenderer((-459));
//     java.awt.Shape var45 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var48 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var45, 0.0d, 100.0d);
//     org.jfree.chart.title.TextTitle var49 = new org.jfree.chart.title.TextTitle();
//     double var50 = var49.getContentXOffset();
//     org.jfree.chart.entity.TitleEntity var53 = new org.jfree.chart.entity.TitleEntity(var45, (org.jfree.chart.title.Title)var49, "AxisLabelEntity: label = null", "AxisLabelEntity: label = null");
//     org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var57 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var59 = null;
//     var57.setSeriesOutlinePaint(0, var59);
//     var57.setUseOutlinePaint(true);
//     java.awt.Shape var64 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var67 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var64, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var69 = new org.jfree.chart.axis.DateAxis("");
//     double var70 = var69.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var73 = new org.jfree.chart.entity.AxisEntity(var67, (org.jfree.chart.axis.Axis)var69, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var76 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var78 = var76.lookupSeriesFillPaint(1);
//     var69.setTickLabelPaint(var78);
//     java.awt.Paint var80 = var69.getTickMarkPaint();
//     var57.setBaseFillPaint(var80, false);
//     var54.setBackgroundPaint(var80);
//     var49.setBackgroundPaint(var80);
//     org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("RectangleEdge.LEFT", var80);
//     var31.setDomainCrosshairPaint(var80);
//     
//     // Checks the contract:  equals-hashcode on var76 and var17
//     assertTrue("Contract failed: equals-hashcode on var76 and var17", var76.equals(var17) ? var76.hashCode() == var17.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var76 and var17.", var76.equals(var17) == var17.equals(var76));
// 
//   }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Paint var14 = var2.getItemOutlinePaint((-459), (-1), true);
    org.jfree.chart.labels.ItemLabelPosition var15 = var2.getBasePositiveItemLabelPosition();
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis3D var18 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
    double var26 = var25.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = null;
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var16, (org.jfree.chart.axis.CategoryAxis)var18, (org.jfree.chart.axis.ValueAxis)var25, var30);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var31.setRangeAxisLocation(1, var33, true);
    org.jfree.chart.event.PlotChangeListener var36 = null;
    var31.addChangeListener(var36);
    org.jfree.chart.axis.AxisSpace var38 = null;
    var31.setFixedDomainAxisSpace(var38);
    org.jfree.chart.axis.CategoryAxis var40 = var31.getDomainAxis();
    double var41 = var31.getAnchorValue();
    org.jfree.chart.renderer.category.CategoryItemRenderer var43 = var31.getRenderer((-1));
    java.awt.Image var44 = null;
    var31.setBackgroundImage(var44);
    org.jfree.chart.plot.Plot var46 = var31.getRootPlot();
    org.jfree.data.time.TimeSeries var47 = null;
    java.util.TimeZone var48 = null;
    org.jfree.data.time.TimeSeriesCollection var49 = new org.jfree.data.time.TimeSeriesCollection(var47, var48);
    org.jfree.chart.axis.ValueAxis var50 = null;
    java.awt.Shape var52 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var52, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var57 = new org.jfree.chart.axis.DateAxis("");
    double var58 = var57.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var61 = new org.jfree.chart.entity.AxisEntity(var55, (org.jfree.chart.axis.Axis)var57, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var64 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var66 = null;
    var64.setSeriesOutlinePaint(0, var66);
    java.awt.Paint var69 = var64.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var72 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var72.setLine(var74);
    var64.setSeriesShape(0, var74, true);
    org.jfree.chart.plot.XYPlot var78 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var49, var50, (org.jfree.chart.axis.ValueAxis)var57, (org.jfree.chart.renderer.xy.XYItemRenderer)var64);
    org.jfree.chart.axis.AxisLocation var80 = null;
    var78.setRangeAxisLocation(13, var80);
    int var82 = var78.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var84 = var78.getRangeAxisLocation((-1));
    org.jfree.chart.axis.AxisLocation var85 = var78.getRangeAxisLocation();
    var31.setRangeAxisLocation(var85, false);
    boolean var88 = var15.equals((java.lang.Object)var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.util.LogFormat var3 = new org.jfree.chart.util.LogFormat(1.0d, "January 0", true);
    int var4 = var3.getMinimumFractionDigits();
    var3.setMaximumFractionDigits(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var3.parse("January 0");
      fail("Expected exception of type java.text.ParseException");
    } catch (java.text.ParseException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(Double.NaN);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var6 = null;
//     var4.setSeriesOutlinePaint(0, var6);
//     var4.setUseOutlinePaint(true);
//     var4.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var13 = var4.getBaseStroke();
//     java.awt.Paint var17 = var4.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var19 = var4.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var24 = null;
//     var22.setSeriesOutlinePaint(0, var24);
//     var22.setUseOutlinePaint(true);
//     var22.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var31 = var22.getBaseStroke();
//     java.awt.Paint var35 = var22.getItemFillPaint((-1), 0, false);
//     boolean var36 = var19.equals((java.lang.Object)false);
//     var1.setNegativeItemLabelPositionFallback(var19);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var42 = null;
//     var40.setSeriesOutlinePaint(0, var42);
//     var40.setUseOutlinePaint(true);
//     var40.setSeriesShapesVisible(0, (java.lang.Boolean)false);
//     java.awt.Stroke var49 = var40.getBaseStroke();
//     java.awt.Paint var53 = var40.getItemFillPaint((-1), 0, false);
//     org.jfree.chart.labels.ItemLabelPosition var55 = var40.getSeriesPositiveItemLabelPosition(1);
//     org.jfree.chart.labels.ItemLabelPosition var56 = var40.getBaseNegativeItemLabelPosition();
//     var1.setPositiveItemLabelPositionFallback(var56);
//     
//     // Checks the contract:  equals-hashcode on var19 and var55
//     assertTrue("Contract failed: equals-hashcode on var19 and var55", var19.equals(var55) ? var19.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var19
//     assertTrue("Contract failed: equals-hashcode on var55 and var19", var55.equals(var19) ? var55.hashCode() == var19.hashCode() : true);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    var2.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    boolean var9 = var2.equals((java.lang.Object)(byte)(-1));
    var2.setBaseLinesVisible(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var12 = var2.getLegendItemLabelGenerator();
    org.jfree.chart.axis.CategoryAxis3D var14 = new org.jfree.chart.axis.CategoryAxis3D("");
    var14.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.chart.axis.CategoryAxis3D var19 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
    double var27 = var26.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var30 = new org.jfree.chart.entity.AxisEntity(var24, (org.jfree.chart.axis.Axis)var26, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var31 = null;
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var17, (org.jfree.chart.axis.CategoryAxis)var19, (org.jfree.chart.axis.ValueAxis)var26, var31);
    org.jfree.chart.axis.AxisLocation var34 = null;
    var32.setRangeAxisLocation(1, var34, false);
    int var37 = var32.getRangeAxisCount();
    var32.setForegroundAlpha(10.0f);
    java.awt.Stroke var40 = var32.getRangeCrosshairStroke();
    java.awt.Paint var41 = var32.getDomainCrosshairPaint();
    var14.setLabelPaint(var41);
    var2.setBaseItemLabelPaint(var41, false);
    var2.setUseOutlinePaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle.Control var2 = null;
//     java.util.ResourceBundle var3 = java.util.ResourceBundle.getBundle("0", var1, var2);
// 
//   }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     java.util.Locale var0 = null;
//     java.text.NumberFormat var1 = java.text.NumberFormat.getIntegerInstance(var0);
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Paint var7 = var2.getSeriesFillPaint(0);
    var2.setAutoPopulateSeriesFillPaint(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var2);
//     org.jfree.data.DomainOrder var4 = var2.getDomainOrder();
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var2, true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Year var13 = var11.getYear();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var17 = var16.toString();
//     org.jfree.data.time.TimeSeries var18 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var16);
//     double var19 = var18.getMinY();
//     var2.removeSeries(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var23 = var2.getXValue(4, 0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "January 0"+ "'", var12.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "January 0"+ "'", var17.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var11 = var2.getBaseStroke();
    java.awt.Paint var15 = var2.getItemFillPaint((-1), 0, false);
    var2.setAutoPopulateSeriesPaint(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesFilled((-459), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    var2.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis3D var10 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var12, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var17 = new org.jfree.chart.axis.DateAxis("");
    double var18 = var17.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var21 = new org.jfree.chart.entity.AxisEntity(var15, (org.jfree.chart.axis.Axis)var17, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = null;
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var8, (org.jfree.chart.axis.CategoryAxis)var10, (org.jfree.chart.axis.ValueAxis)var17, var22);
    org.jfree.chart.axis.AxisLocation var25 = null;
    var23.setRangeAxisLocation(1, var25, true);
    org.jfree.chart.event.PlotChangeListener var28 = null;
    var23.addChangeListener(var28);
    java.awt.Paint var30 = var23.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var31 = var23.getDomainGridlinePosition();
    org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var34.setShadowVisible(false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var40 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var42 = null;
    var40.setSeriesOutlinePaint(0, var42);
    var40.setUseOutlinePaint(true);
    var40.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var49 = var40.getBaseStroke();
    var34.setSeriesOutlineStroke(100, var49, false);
    var23.setOutlineStroke(var49);
    var2.setBaseStroke(var49);
    boolean var55 = var2.isSeriesVisible(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.chart.axis.ValueAxis var3 = null;
//     java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
//     double var11 = var10.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var19 = null;
//     var17.setSeriesOutlinePaint(0, var19);
//     java.awt.Paint var22 = var17.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var25.setLine(var27);
//     var17.setSeriesShape(0, var27, true);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     java.awt.geom.Point2D var34 = null;
//     var31.panDomainAxes(100.0d, var33, var34);
//     org.jfree.chart.util.Layer var36 = null;
//     java.util.Collection var37 = var31.getDomainMarkers(var36);
//     java.awt.Color var43 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var44 = var43.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var45 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var43);
//     java.awt.Font var46 = var45.getLabelFont();
//     org.jfree.chart.util.Layer var47 = null;
//     var31.addRangeMarker(1, (org.jfree.chart.plot.Marker)var45, var47);
//     java.awt.Paint var49 = var31.getDomainTickBandPaint();
//     org.jfree.data.time.TimeSeries var50 = null;
//     java.util.TimeZone var51 = null;
//     org.jfree.data.time.TimeSeriesCollection var52 = new org.jfree.data.time.TimeSeriesCollection(var50, var51);
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     java.awt.Shape var55 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var55, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var60 = new org.jfree.chart.axis.DateAxis("");
//     double var61 = var60.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var64 = new org.jfree.chart.entity.AxisEntity(var58, (org.jfree.chart.axis.Axis)var60, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var67 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var69 = null;
//     var67.setSeriesOutlinePaint(0, var69);
//     java.awt.Paint var72 = var67.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var75 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var75.setLine(var77);
//     var67.setSeriesShape(0, var77, true);
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var52, var53, (org.jfree.chart.axis.ValueAxis)var60, (org.jfree.chart.renderer.xy.XYItemRenderer)var67);
//     java.awt.Color var86 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var87 = var86.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var88 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var86);
//     java.awt.Font var89 = var88.getLabelFont();
//     float var90 = var88.getAlpha();
//     boolean var91 = var81.removeDomainMarker((org.jfree.chart.plot.Marker)var88);
//     java.awt.Paint var92 = var81.getDomainCrosshairPaint();
//     var31.setDomainCrosshairPaint(var92);
//     
//     // Checks the contract:  equals-hashcode on var2 and var52
//     assertTrue("Contract failed: equals-hashcode on var2 and var52", var2.equals(var52) ? var2.hashCode() == var52.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var52 and var2
//     assertTrue("Contract failed: equals-hashcode on var52 and var2", var52.equals(var2) ? var52.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var75
//     assertTrue("Contract failed: equals-hashcode on var25 and var75", var25.equals(var75) ? var25.hashCode() == var75.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var75 and var25
//     assertTrue("Contract failed: equals-hashcode on var75 and var25", var75.equals(var25) ? var75.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var81
//     assertTrue("Contract failed: equals-hashcode on var31 and var81", var31.equals(var81) ? var31.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var31
//     assertTrue("Contract failed: equals-hashcode on var81 and var31", var81.equals(var31) ? var81.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var88
//     assertTrue("Contract failed: equals-hashcode on var45 and var88", var45.equals(var88) ? var45.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var45
//     assertTrue("Contract failed: equals-hashcode on var88 and var45", var88.equals(var45) ? var88.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.jfree.data.xy.XYSeries var3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)(short)1, true, false);
    boolean var4 = var3.getAllowDuplicateXValues();
    boolean var5 = var3.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var3.getY(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.jfree.data.time.TimeSeriesCollection var0 = new org.jfree.data.time.TimeSeriesCollection();
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset)var0, var1, var2);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var8 = null;
//     var6.setSeriesOutlinePaint(0, var8);
//     var6.setUseOutlinePaint(true);
//     org.jfree.chart.urls.XYURLGenerator var13 = null;
//     var6.setSeriesURLGenerator(0, var13, true);
//     org.jfree.data.time.TimeSeries var16 = null;
//     java.util.TimeZone var17 = null;
//     org.jfree.data.time.TimeSeriesCollection var18 = new org.jfree.data.time.TimeSeriesCollection(var16, var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var21, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var26 = new org.jfree.chart.axis.DateAxis("");
//     double var27 = var26.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var30 = new org.jfree.chart.entity.AxisEntity(var24, (org.jfree.chart.axis.Axis)var26, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var33 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var35 = null;
//     var33.setSeriesOutlinePaint(0, var35);
//     java.awt.Paint var38 = var33.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var43 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var41.setLine(var43);
//     var33.setSeriesShape(0, var43, true);
//     org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var18, var19, (org.jfree.chart.axis.ValueAxis)var26, (org.jfree.chart.renderer.xy.XYItemRenderer)var33);
//     org.jfree.chart.axis.AxisLocation var49 = null;
//     var47.setRangeAxisLocation(13, var49);
//     var6.setPlot(var47);
//     int var52 = var47.getSeriesCount();
//     var47.clearRangeMarkers();
//     java.awt.Color var58 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var59 = var58.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var60 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var58);
//     java.awt.Paint var61 = var60.getPaint();
//     var47.addRangeMarker((org.jfree.chart.plot.Marker)var60);
//     java.awt.Paint var63 = var60.getPaint();
//     var3.setAngleGridlinePaint(var63);
//     
//     // Checks the contract:  equals-hashcode on var0 and var18
//     assertTrue("Contract failed: equals-hashcode on var0 and var18", var0.equals(var18) ? var0.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var0
//     assertTrue("Contract failed: equals-hashcode on var18 and var0", var18.equals(var0) ? var18.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = var2.lookupSeriesFillPaint(1);
    var2.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    boolean var9 = var2.equals((java.lang.Object)(byte)(-1));
    var2.setBaseLinesVisible(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var12 = var2.getLegendItemLabelGenerator();
    org.jfree.chart.labels.XYToolTipGenerator var13 = var2.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
//     org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var5 = var4.toString();
//     org.jfree.data.time.Year var6 = var4.getYear();
//     org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var10 = var9.toString();
//     org.jfree.data.time.TimeSeries var11 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var9);
//     org.jfree.chart.block.BlockBorder var12 = new org.jfree.chart.block.BlockBorder();
//     java.awt.Paint var13 = var12.getPaint();
//     int var14 = var9.compareTo((java.lang.Object)var12);
//     java.util.Date var15 = var9.getStart();
//     org.jfree.data.xy.XYSeries var17 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)var15, false);
//     java.util.TimeZone var18 = null;
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var15, var18);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    java.awt.Shape var14 = var2.lookupSeriesShape(13);
    org.jfree.data.category.CategoryDataset var17 = null;
    org.jfree.data.time.TimeSeries var19 = null;
    java.util.TimeZone var20 = null;
    org.jfree.data.time.TimeSeriesCollection var21 = new org.jfree.data.time.TimeSeriesCollection(var19, var20);
    org.jfree.chart.axis.ValueAxis var22 = null;
    java.awt.Shape var24 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var24, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis("");
    double var30 = var29.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var33 = new org.jfree.chart.entity.AxisEntity(var27, (org.jfree.chart.axis.Axis)var29, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var38 = null;
    var36.setSeriesOutlinePaint(0, var38);
    java.awt.Paint var41 = var36.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var46 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var44.setLine(var46);
    var36.setSeriesShape(0, var46, true);
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var21, var22, (org.jfree.chart.axis.ValueAxis)var29, (org.jfree.chart.renderer.xy.XYItemRenderer)var36);
    double var51 = var29.getUpperBound();
    java.util.Date var52 = var29.getMaximumDate();
    org.jfree.data.time.Day var53 = new org.jfree.data.time.Day(var52);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.CategoryItemEntity var54 = new org.jfree.chart.entity.CategoryItemEntity(var14, "", "ChartChangeEventType.GENERAL", var17, (java.lang.Comparable)"AxisLabelEntity: label = null", (java.lang.Comparable)var53);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test441() {}
//   public void test441() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }
// 
// 
//     org.jfree.chart.axis.LogAxis var1 = new org.jfree.chart.axis.LogAxis("TitleEntity: tooltip = AxisLabelEntity: label = null");
//     var1.setRangeWithMargins(0.0d, 4.0d);
//     org.jfree.chart.util.RectangleInsets var5 = var1.getTickLabelInsets();
//     org.jfree.data.Range var6 = null;
//     org.jfree.data.Range var8 = org.jfree.data.Range.expandToInclude(var6, 0.0d);
//     org.jfree.data.Range var11 = org.jfree.data.Range.expand(var8, 0.2d, 10.0d);
//     var1.setDefaultAutoRange(var11);
//     java.awt.geom.Rectangle2D var14 = null;
//     org.jfree.data.time.TimeSeries var15 = null;
//     java.util.TimeZone var16 = null;
//     org.jfree.data.time.TimeSeriesCollection var17 = new org.jfree.data.time.TimeSeriesCollection(var15, var16);
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     java.awt.Shape var20 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var20, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var25 = new org.jfree.chart.axis.DateAxis("");
//     double var26 = var25.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var29 = new org.jfree.chart.entity.AxisEntity(var23, (org.jfree.chart.axis.Axis)var25, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var34 = null;
//     var32.setSeriesOutlinePaint(0, var34);
//     java.awt.Paint var37 = var32.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var40.setLine(var42);
//     var32.setSeriesShape(0, var42, true);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var17, var18, (org.jfree.chart.axis.ValueAxis)var25, (org.jfree.chart.renderer.xy.XYItemRenderer)var32);
//     var46.clearDomainMarkers();
//     double var48 = var46.getDomainCrosshairValue();
//     org.jfree.chart.util.RectangleEdge var49 = var46.getRangeAxisEdge();
//     double var50 = var1.exponentLengthToJava2D(0.0d, var14, var49);
// 
//   }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.axis.LogAxis var2 = new org.jfree.chart.axis.LogAxis();
    double var4 = var2.calculateValue(0.0d);
    var2.zoomRange(4.0d, 0.0d);
    org.jfree.chart.event.AxisChangeEvent var8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var2);
    org.jfree.chart.axis.NumberTickUnit var9 = var2.getTickUnit();
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var12.setShadowVisible(false);
    var12.setSeriesItemLabelsVisible(0, (java.lang.Boolean)false, false);
    java.awt.Font var19 = var12.getBaseItemLabelFont();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var0, var1, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var26 = null;
    var24.setSeriesOutlinePaint(0, var26);
    var24.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var31 = null;
    var24.setSeriesURLGenerator(0, var31, true);
    org.jfree.data.time.TimeSeries var34 = null;
    java.util.TimeZone var35 = null;
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var34, var35);
    org.jfree.chart.axis.ValueAxis var37 = null;
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var42 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var39, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var44 = new org.jfree.chart.axis.DateAxis("");
    double var45 = var44.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var48 = new org.jfree.chart.entity.AxisEntity(var42, (org.jfree.chart.axis.Axis)var44, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var51 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var53 = null;
    var51.setSeriesOutlinePaint(0, var53);
    java.awt.Paint var56 = var51.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var59 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var61 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var59.setLine(var61);
    var51.setSeriesShape(0, var61, true);
    org.jfree.chart.plot.XYPlot var65 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var36, var37, (org.jfree.chart.axis.ValueAxis)var44, (org.jfree.chart.renderer.xy.XYItemRenderer)var51);
    org.jfree.chart.axis.AxisLocation var67 = null;
    var65.setRangeAxisLocation(13, var67);
    var24.setPlot(var65);
    int var70 = var65.getSeriesCount();
    org.jfree.chart.util.RectangleInsets var71 = var65.getAxisOffset();
    java.awt.Font var72 = var65.getNoDataMessageFont();
    var1.setTickLabelFont((java.lang.Comparable)"RectangleConstraintType.RANGE", var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    var2.setUseOutlinePaint(true);
    var2.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var11 = var2.getBaseStroke();
    java.awt.Paint var15 = var2.getItemFillPaint((-1), 0, false);
    var2.setSeriesCreateEntities(10, (java.lang.Boolean)true, false);
    java.lang.Boolean var21 = var2.getSeriesItemLabelsVisible(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.axis.CategoryAnchor var23 = var15.getDomainGridlinePosition();
    org.jfree.chart.axis.LogAxis var24 = new org.jfree.chart.axis.LogAxis();
    org.jfree.data.Range var25 = var15.getDataRange((org.jfree.chart.axis.ValueAxis)var24);
    org.jfree.chart.util.LogFormat var29 = new org.jfree.chart.util.LogFormat(Double.NaN, "ThreadContext", false);
    var24.setNumberFormatOverride((java.text.NumberFormat)var29);
    var24.zoomRange(0.0d, 100.0d);
    var24.setVerticalTickLabels(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var6 = var2.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var7 = var2.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer3D var11 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    var11.setShadowVisible(false);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    var17.setUseOutlinePaint(true);
    var17.setSeriesShapesVisible(0, (java.lang.Boolean)false);
    java.awt.Stroke var26 = var17.getBaseStroke();
    var11.setSeriesOutlineStroke(100, var26, false);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var30, 0.0d, 100.0d);
    java.awt.Shape var34 = org.jfree.chart.util.ShapeUtilities.clone(var30);
    var11.setBaseShape(var30, false);
    var2.setLegendShape(1, var30);
    org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("Oct", "LegendItemEntity: seriesKey=null, dataset=null", "", "");

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    java.awt.geom.Point2D var34 = null;
    var31.panDomainAxes(100.0d, var33, var34);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var31.getDomainMarkers(var36);
    boolean var38 = var31.isSubplot();
    org.jfree.chart.util.RectangleInsets var39 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.setInsets(var39, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Paint var7 = var2.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var10.setLine(var12);
    var2.setSeriesShape(0, var12, true);
    org.jfree.chart.entity.LegendItemEntity var16 = new org.jfree.chart.entity.LegendItemEntity(var12);
    org.jfree.data.xy.XYSeriesCollection var17 = new org.jfree.data.xy.XYSeriesCollection();
    double var18 = var17.getIntervalWidth();
    var16.setDataset((org.jfree.data.general.Dataset)var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var22 = var17.getStartY(100, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1.0d);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.LegendItemCollection var16 = var15.getLegendItems();
    java.awt.Stroke var17 = var15.getRangeGridlineStroke();
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var15.getRangeMarkers(0, var19);
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var27 = var23.getItemCreateEntity((-1), 13, true);
    org.jfree.chart.renderer.category.BarPainter var28 = var23.getBarPainter();
    var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var32 = null;
    var23.setSeriesItemLabelGenerator(1, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    java.util.TimeZone var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, true);
//     org.jfree.chart.event.PlotChangeListener var20 = null;
//     var15.addChangeListener(var20);
//     java.awt.Paint var22 = var15.getRangeCrosshairPaint();
//     var15.zoom((-1.0d));
//     org.jfree.chart.event.RendererChangeEvent var25 = null;
//     var15.rendererChanged(var25);
//     org.jfree.chart.plot.PlotOrientation var27 = var15.getOrientation();
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis3D var31 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var33 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var33, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var38 = new org.jfree.chart.axis.DateAxis("");
//     double var39 = var38.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var42 = new org.jfree.chart.entity.AxisEntity(var36, (org.jfree.chart.axis.Axis)var38, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var43 = null;
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot(var29, (org.jfree.chart.axis.CategoryAxis)var31, (org.jfree.chart.axis.ValueAxis)var38, var43);
//     double var45 = var38.getLowerBound();
//     var15.setRangeAxis(13, (org.jfree.chart.axis.ValueAxis)var38, false);
//     
//     // Checks the contract:  equals-hashcode on var44 and var15
//     assertTrue("Contract failed: equals-hashcode on var44 and var15", var44.equals(var15) ? var44.hashCode() == var15.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var44 and var15.", var44.equals(var15) == var15.equals(var44));
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var10 = var9.toString();
    org.jfree.data.time.Year var11 = var9.getYear();
    org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var15 = var14.toString();
    org.jfree.data.time.TimeSeries var16 = var6.createCopy((org.jfree.data.time.RegularTimePeriod)var11, (org.jfree.data.time.RegularTimePeriod)var14);
    org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var20 = var19.toString();
    org.jfree.data.time.Year var21 = var19.getYear();
    org.jfree.chart.plot.CrosshairState var23 = new org.jfree.chart.plot.CrosshairState(false);
    double var24 = var23.getCrosshairY();
    int var25 = var23.getDomainAxisIndex();
    var23.setCrosshairY(4.0d);
    var23.setDatasetIndex((-1));
    int var30 = var21.compareTo((java.lang.Object)var23);
    org.jfree.chart.axis.PeriodAxis var31 = new org.jfree.chart.axis.PeriodAxis("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.RegularTimePeriod)var11, (org.jfree.data.time.RegularTimePeriod)var21);
    org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var37 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var38 = var37.toString();
    org.jfree.data.time.Year var39 = var37.getYear();
    org.jfree.data.time.Month var42 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var43 = var42.toString();
    org.jfree.data.time.TimeSeries var44 = var34.createCopy((org.jfree.data.time.RegularTimePeriod)var39, (org.jfree.data.time.RegularTimePeriod)var42);
    org.jfree.data.time.Month var47 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var48 = var47.toString();
    org.jfree.data.time.Year var49 = var47.getYear();
    org.jfree.chart.plot.CrosshairState var51 = new org.jfree.chart.plot.CrosshairState(false);
    double var52 = var51.getCrosshairY();
    int var53 = var51.getDomainAxisIndex();
    var51.setCrosshairY(4.0d);
    var51.setDatasetIndex((-1));
    int var58 = var49.compareTo((java.lang.Object)var51);
    org.jfree.chart.axis.PeriodAxis var59 = new org.jfree.chart.axis.PeriodAxis("LegendItemEntity: seriesKey=null, dataset=null", (org.jfree.data.time.RegularTimePeriod)var39, (org.jfree.data.time.RegularTimePeriod)var49);
    var31.setFirst((org.jfree.data.time.RegularTimePeriod)var49);
    java.awt.Paint var61 = var31.getMinorTickMarkPaint();
    org.jfree.chart.StandardChartTheme var63 = new org.jfree.chart.StandardChartTheme("");
    org.jfree.chart.title.TextTitle var64 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var67 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var69 = null;
    var67.setSeriesOutlinePaint(0, var69);
    var67.setUseOutlinePaint(true);
    java.awt.Shape var74 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var77 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var74, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var79 = new org.jfree.chart.axis.DateAxis("");
    double var80 = var79.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var83 = new org.jfree.chart.entity.AxisEntity(var77, (org.jfree.chart.axis.Axis)var79, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var86 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var88 = var86.lookupSeriesFillPaint(1);
    var79.setTickLabelPaint(var88);
    java.awt.Paint var90 = var79.getTickMarkPaint();
    var67.setBaseFillPaint(var90, false);
    var64.setBackgroundPaint(var90);
    var63.setTickLabelPaint(var90);
    var31.setMinorTickMarkPaint(var90);
    org.jfree.chart.block.BlockBorder var96 = new org.jfree.chart.block.BlockBorder(1.0d, Double.NaN, 2.0d, 10.0d, var90);
    org.jfree.chart.util.RectangleInsets var97 = var96.getInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "January 0"+ "'", var10.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "January 0"+ "'", var15.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "January 0"+ "'", var20.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + "January 0"+ "'", var38.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "January 0"+ "'", var43.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "January 0"+ "'", var48.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    var31.clearDomainMarkers();
    var31.mapDatasetToRangeAxis(10, 13);
    org.jfree.chart.axis.AxisLocation var36 = var31.getRangeAxisLocation();
    java.awt.Color var42 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var43 = var42.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var44 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var42);
    java.awt.Font var45 = var44.getLabelFont();
    double var46 = var44.getEndValue();
    org.jfree.chart.util.Layer var47 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.addDomainMarker(0, (org.jfree.chart.plot.Marker)var44, var47, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 10.0d);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    org.jfree.chart.plot.CombinedRangeXYPlot var6 = new org.jfree.chart.plot.CombinedRangeXYPlot((org.jfree.chart.axis.ValueAxis)var1);
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var12 = null;
    var10.setSeriesOutlinePaint(0, var12);
    var10.setUseOutlinePaint(true);
    org.jfree.chart.urls.XYURLGenerator var17 = null;
    var10.setSeriesURLGenerator(0, var17, true);
    org.jfree.data.time.TimeSeries var20 = null;
    java.util.TimeZone var21 = null;
    org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var20, var21);
    org.jfree.chart.axis.ValueAxis var23 = null;
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
    double var31 = var30.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var39 = null;
    var37.setSeriesOutlinePaint(0, var39);
    java.awt.Paint var42 = var37.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var47 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var45.setLine(var47);
    var37.setSeriesShape(0, var47, true);
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var22, var23, (org.jfree.chart.axis.ValueAxis)var30, (org.jfree.chart.renderer.xy.XYItemRenderer)var37);
    org.jfree.chart.axis.AxisLocation var53 = null;
    var51.setRangeAxisLocation(13, var53);
    var10.setPlot(var51);
    int var56 = var51.getSeriesCount();
    var51.clearRangeMarkers();
    java.awt.Color var62 = java.awt.Color.getColor("hi!", 1);
    java.awt.color.ColorSpace var63 = var62.getColorSpace();
    org.jfree.chart.plot.IntervalMarker var64 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var62);
    java.awt.Paint var65 = var64.getPaint();
    var51.addRangeMarker((org.jfree.chart.plot.Marker)var64);
    org.jfree.chart.util.Layer var67 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.addDomainMarker(12, (org.jfree.chart.plot.Marker)var64, var67, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var16 = var11.getEndY(1, (-16777216));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var23 = var15.getRangeAxisEdge();
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.zoomDomainAxes(100.0d, 0.05d, var26, var27);
    org.jfree.chart.renderer.category.CategoryItemRenderer var30 = var15.getRenderer(1);
    org.jfree.data.time.TimeSeries var31 = null;
    java.util.TimeZone var32 = null;
    org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
    org.jfree.chart.axis.ValueAxis var34 = null;
    java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
    double var42 = var41.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var50 = null;
    var48.setSeriesOutlinePaint(0, var50);
    java.awt.Paint var53 = var48.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var56.setLine(var58);
    var48.setSeriesShape(0, var58, true);
    org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var33, var34, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var48);
    org.jfree.chart.axis.AxisLocation var64 = null;
    var62.setRangeAxisLocation(13, var64);
    int var66 = var62.getDatasetCount();
    org.jfree.chart.axis.AxisLocation var68 = var62.getRangeAxisLocation((-1));
    var15.setDomainAxisLocation(var68);
    boolean var70 = var15.isRangePannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var4 = null;
    var2.setSeriesOutlinePaint(0, var4);
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.XYPlot var8 = null;
    org.jfree.data.time.TimeSeries var9 = null;
    java.util.TimeZone var10 = null;
    org.jfree.data.time.TimeSeriesCollection var11 = new org.jfree.data.time.TimeSeriesCollection(var9, var10);
    org.jfree.chart.plot.PlotRenderingInfo var12 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var13 = var2.initialise(var6, var7, var8, (org.jfree.data.xy.XYDataset)var11, var12);
    org.jfree.data.Range var14 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.event.AxisChangeEvent var1 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var0);
    org.jfree.chart.event.ChartChangeEventType var2 = var1.getType();
    org.jfree.chart.JFreeChart var3 = null;
    var1.setChart(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    double var7 = var6.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var10 = new org.jfree.chart.entity.AxisEntity(var4, (org.jfree.chart.axis.Axis)var6, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var15 = var13.lookupSeriesFillPaint(1);
    var6.setTickLabelPaint(var15);
    java.awt.Paint var17 = var6.getTickMarkPaint();
    double var18 = var6.getLowerMargin();
    java.util.TimeZone var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setTimeZone(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.05d);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    java.util.List var1 = var0.getSeries();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset)var0);
    double var3 = var0.getIntervalPositionFactor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getStartY(4, 2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.5d);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.chart.util.LogFormat var4 = new org.jfree.chart.util.LogFormat(2.0d, "TitleEntity: tooltip = AxisLabelEntity: label = null", "TitleEntity: tooltip = AxisLabelEntity: label = null", false);
    var4.setGroupingUsed(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Currency var7 = var4.getCurrency();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("RectangleEdge.LEFT");
    java.awt.Paint var2 = var1.getWallPaint();
    java.awt.Paint var3 = var1.getSubtitlePaint();
    java.awt.Paint var4 = var1.getTitlePaint();
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setExtraLargeFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.TimeSeries var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
//     org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset)var2);
//     org.jfree.data.DomainOrder var4 = var2.getDomainOrder();
//     org.jfree.data.Range var6 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset)var2, true);
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var12 = var11.toString();
//     org.jfree.data.time.Year var13 = var11.getYear();
//     org.jfree.data.time.Month var16 = new org.jfree.data.time.Month(1, 0);
//     java.lang.String var17 = var16.toString();
//     org.jfree.data.time.TimeSeries var18 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var13, (org.jfree.data.time.RegularTimePeriod)var16);
//     double var19 = var18.getMinY();
//     var2.removeSeries(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var24 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var2, 12, 0.2d, 0.2d);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "January 0"+ "'", var12.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var17 + "' != '" + "January 0"+ "'", var17.equals("January 0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == Double.NaN);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var6 = var4.lookupSeriesFillPaint(1);
    var4.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    boolean var11 = var4.equals((java.lang.Object)(byte)(-1));
    var4.setBaseLinesVisible(false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var14 = var4.getLegendItemLabelGenerator();
    org.jfree.chart.axis.CategoryAxis3D var16 = new org.jfree.chart.axis.CategoryAxis3D("");
    var16.setUpperMargin(100.0d);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis3D var21 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var26 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var23, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var28 = new org.jfree.chart.axis.DateAxis("");
    double var29 = var28.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var32 = new org.jfree.chart.entity.AxisEntity(var26, (org.jfree.chart.axis.Axis)var28, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var33 = null;
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot(var19, (org.jfree.chart.axis.CategoryAxis)var21, (org.jfree.chart.axis.ValueAxis)var28, var33);
    org.jfree.chart.axis.AxisLocation var36 = null;
    var34.setRangeAxisLocation(1, var36, false);
    int var39 = var34.getRangeAxisCount();
    var34.setForegroundAlpha(10.0f);
    java.awt.Stroke var42 = var34.getRangeCrosshairStroke();
    java.awt.Paint var43 = var34.getDomainCrosshairPaint();
    var16.setLabelPaint(var43);
    var4.setBaseItemLabelPaint(var43, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-16777216), var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var1 = var0.getNumberFormatOverride();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    double var4 = var2.calculateBottomInset(0.5d);
    double var6 = var2.calculateRightOutset((-1.0d));
    java.awt.geom.Rectangle2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var10 = var2.createOutsetRectangle(var7, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 4.0d);

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    double var2 = var1.getUpperMargin();
    var1.setAutoRangeMinimumSize(0.05d, true);
    org.jfree.data.Range var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var6, false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(1.0d, 0.2d);
    double var3 = var2.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);

  }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     boolean var2 = var1.isAxisLineVisible();
//     var1.setMaximumCategoryLabelWidthRatio(1.0f);
//     org.jfree.data.category.CategoryDataset var5 = null;
//     org.jfree.chart.axis.CategoryAxis3D var7 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var12 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var9, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var14 = new org.jfree.chart.axis.DateAxis("");
//     double var15 = var14.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var18 = new org.jfree.chart.entity.AxisEntity(var12, (org.jfree.chart.axis.Axis)var14, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var19 = null;
//     org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot(var5, (org.jfree.chart.axis.CategoryAxis)var7, (org.jfree.chart.axis.ValueAxis)var14, var19);
//     org.jfree.chart.axis.AxisLocation var22 = null;
//     var20.setRangeAxisLocation(1, var22, true);
//     org.jfree.chart.event.PlotChangeListener var25 = null;
//     var20.addChangeListener(var25);
//     java.awt.Paint var27 = var20.getRangeCrosshairPaint();
//     org.jfree.chart.axis.CategoryAnchor var28 = var20.getDomainGridlinePosition();
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.data.category.CategoryDataset var32 = null;
//     org.jfree.chart.axis.CategoryAxis3D var34 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     double var42 = var41.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var46 = null;
//     org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var32, (org.jfree.chart.axis.CategoryAxis)var34, (org.jfree.chart.axis.ValueAxis)var41, var46);
//     org.jfree.chart.axis.AxisLocation var49 = null;
//     var47.setRangeAxisLocation(1, var49, true);
//     org.jfree.chart.event.PlotChangeListener var52 = null;
//     var47.addChangeListener(var52);
//     org.jfree.chart.axis.AxisSpace var54 = null;
//     var47.setFixedDomainAxisSpace(var54);
//     org.jfree.chart.axis.CategoryAxis var56 = var47.getDomainAxis();
//     double var57 = var47.getAnchorValue();
//     org.jfree.chart.renderer.category.CategoryItemRenderer var59 = var47.getRenderer((-1));
//     java.awt.Image var60 = null;
//     var47.setBackgroundImage(var60);
//     java.awt.Stroke var62 = var47.getDomainGridlineStroke();
//     org.jfree.data.category.CategoryDataset var63 = null;
//     var47.setDataset(var63);
//     org.jfree.chart.util.RectangleEdge var66 = var47.getDomainAxisEdge(15);
//     double var67 = var1.getCategoryJava2DCoordinate(var28, 0, 10, var31, var66);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var5 = null;
//     var3.setSeriesOutlinePaint(0, var5);
//     var3.setUseOutlinePaint(true);
//     java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
//     double var16 = var15.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var24 = var22.lookupSeriesFillPaint(1);
//     var15.setTickLabelPaint(var24);
//     java.awt.Paint var26 = var15.getTickMarkPaint();
//     var3.setBaseFillPaint(var26, false);
//     var0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
//     org.jfree.data.time.TimeSeries var31 = null;
//     java.util.TimeZone var32 = null;
//     org.jfree.data.time.TimeSeriesCollection var33 = new org.jfree.data.time.TimeSeriesCollection(var31, var32);
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     java.awt.Shape var36 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var39 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var36, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var41 = new org.jfree.chart.axis.DateAxis("");
//     double var42 = var41.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var45 = new org.jfree.chart.entity.AxisEntity(var39, (org.jfree.chart.axis.Axis)var41, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var48 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var50 = null;
//     var48.setSeriesOutlinePaint(0, var50);
//     java.awt.Paint var53 = var48.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var58 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var56.setLine(var58);
//     var48.setSeriesShape(0, var58, true);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var33, var34, (org.jfree.chart.axis.ValueAxis)var41, (org.jfree.chart.renderer.xy.XYItemRenderer)var48);
//     java.awt.Color var67 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var68 = var67.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var69 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var67);
//     java.awt.Font var70 = var69.getLabelFont();
//     float var71 = var69.getAlpha();
//     boolean var72 = var62.removeDomainMarker((org.jfree.chart.plot.Marker)var69);
//     org.jfree.chart.util.Layer var73 = null;
//     var0.addRangeMarker((-1), (org.jfree.chart.plot.Marker)var69, var73, true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var48
//     assertTrue("Contract failed: equals-hashcode on var22 and var48", var22.equals(var48) ? var22.hashCode() == var48.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var48.", var22.equals(var48) == var48.equals(var22));
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var2 = null;
//     boolean var3 = var1.isBefore(var2);
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
//     var2.setBaseItemLabelGenerator(var6, false);
//     java.awt.Stroke var10 = null;
//     var2.setSeriesStroke(13, var10, false);
//     var2.setAutoPopulateSeriesStroke(true);
//     boolean var15 = var2.getAutoPopulateSeriesPaint();
//     org.jfree.chart.renderer.category.BarRenderer3D var18 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     org.jfree.chart.LegendItem var21 = var18.getLegendItem((-1), 13);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = null;
//     var18.setBaseItemLabelGenerator(var22, false);
//     org.jfree.chart.urls.CategoryURLGenerator var28 = var18.getURLGenerator(100, 13, false);
//     org.jfree.chart.renderer.category.BarPainter var29 = var18.getBarPainter();
//     var2.setBarPainter(var29);
//     
//     // Checks the contract:  equals-hashcode on var2 and var18
//     assertTrue("Contract failed: equals-hashcode on var2 and var18", var2.equals(var18) ? var2.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var2
//     assertTrue("Contract failed: equals-hashcode on var18 and var2", var18.equals(var2) ? var18.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test480() {}
//   public void test480() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var1 = new org.jfree.chart.axis.CategoryAxis3D("");
//     var1.setUpperMargin(100.0d);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     org.jfree.chart.util.RectangleEdge var8 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.axis.AxisState var11 = var1.draw(var4, (-1.0d), var6, var7, var8, var10);
// 
//   }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    org.jfree.chart.LegendItem var5 = var2.getLegendItem((-1), 13);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = null;
    var2.setBaseItemLabelGenerator(var6, false);
    java.awt.Stroke var10 = null;
    var2.setSeriesStroke(13, var10, false);
    java.awt.Shape var14 = var2.lookupSeriesShape(13);
    org.jfree.chart.JFreeChart var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var16 = new org.jfree.chart.entity.JFreeChartEntity(var14, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    org.jfree.chart.axis.ValueAxis var3 = null;
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var5, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    double var11 = var10.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var14 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var19 = null;
    var17.setSeriesOutlinePaint(0, var19);
    java.awt.Paint var22 = var17.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var25.setLine(var27);
    var17.setSeriesShape(0, var27, true);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var2, var3, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.renderer.xy.XYItemRenderer)var17);
    var31.clearDomainMarkers();
    var31.setWeight(0);
    java.awt.Paint var35 = var31.getRangeMinorGridlinePaint();
    boolean var36 = var31.isDomainCrosshairLockedOnData();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var5 = null;
    var3.setSeriesOutlinePaint(0, var5);
    var3.setUseOutlinePaint(true);
    java.awt.Shape var10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var13 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var10, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var15 = new org.jfree.chart.axis.DateAxis("");
    double var16 = var15.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var19 = new org.jfree.chart.entity.AxisEntity(var13, (org.jfree.chart.axis.Axis)var15, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var24 = var22.lookupSeriesFillPaint(1);
    var15.setTickLabelPaint(var24);
    java.awt.Paint var26 = var15.getTickMarkPaint();
    var3.setBaseFillPaint(var26, false);
    var0.setBackgroundPaint(var26);
    java.awt.Paint var30 = var0.getBackgroundPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     java.awt.geom.Point2D var3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(5.0d, (-1.0d), var2);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    boolean var17 = var2.equals((java.lang.Object)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
//     java.util.Date var2 = null;
//     org.jfree.data.time.TimeSeries var3 = null;
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.TimeSeriesCollection var5 = new org.jfree.data.time.TimeSeriesCollection(var3, var4);
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     java.awt.Shape var8 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var11 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var8, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var13 = new org.jfree.chart.axis.DateAxis("");
//     double var14 = var13.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var11, (org.jfree.chart.axis.Axis)var13, "hi!", "hi!");
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var22 = null;
//     var20.setSeriesOutlinePaint(0, var22);
//     java.awt.Paint var25 = var20.getSeriesFillPaint(0);
//     org.jfree.chart.LegendItem var28 = new org.jfree.chart.LegendItem("hi!");
//     java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     var28.setLine(var30);
//     var20.setSeriesShape(0, var30, true);
//     org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var5, var6, (org.jfree.chart.axis.ValueAxis)var13, (org.jfree.chart.renderer.xy.XYItemRenderer)var20);
//     double var35 = var13.getUpperBound();
//     java.util.Date var36 = var13.getMaximumDate();
//     var1.setRange(var2, var36);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    java.util.TimeZone var1 = null;
    java.util.Locale var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var3 = new org.jfree.chart.axis.DateAxis("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.chart.axis.LogAxis var0 = new org.jfree.chart.axis.LogAxis();
    java.text.NumberFormat var1 = var0.getNumberFormatOverride();
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]");
    java.text.NumberFormat var4 = var3.getPercentFormat();
    var0.setNumberFormatOverride(var4);
    var0.setInverted(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var1, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis("");
    double var7 = var6.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var10 = new org.jfree.chart.entity.AxisEntity(var4, (org.jfree.chart.axis.Axis)var6, "hi!", "hi!");
    org.jfree.chart.axis.DateAxis var12 = new org.jfree.chart.axis.DateAxis("");
    double var13 = var12.getUpperMargin();
    var12.setAutoRangeMinimumSize(0.05d, true);
    java.text.DateFormat var17 = null;
    var12.setDateFormatOverride(var17);
    boolean var19 = var10.equals((java.lang.Object)var12);
    var10.setURLText("RectangleConstraintType.RANGE");
    java.lang.String var22 = var10.getURLText();
    org.jfree.data.category.CategoryDataset var23 = null;
    org.jfree.chart.axis.CategoryAxis3D var25 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var27 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var30 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var27, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var32 = new org.jfree.chart.axis.DateAxis("");
    double var33 = var32.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var36 = new org.jfree.chart.entity.AxisEntity(var30, (org.jfree.chart.axis.Axis)var32, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var37 = null;
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot(var23, (org.jfree.chart.axis.CategoryAxis)var25, (org.jfree.chart.axis.ValueAxis)var32, var37);
    org.jfree.chart.LegendItemCollection var39 = var38.getLegendItems();
    java.awt.Stroke var40 = var38.getRangeGridlineStroke();
    org.jfree.chart.util.Layer var42 = null;
    java.util.Collection var43 = var38.getRangeMarkers(0, var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = null;
    var38.setRenderer(0, var45);
    org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
    boolean var53 = var49.getItemCreateEntity((-1), 13, true);
    var38.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
    org.jfree.data.time.TimeSeries var55 = null;
    java.util.TimeZone var56 = null;
    org.jfree.data.time.TimeSeriesCollection var57 = new org.jfree.data.time.TimeSeriesCollection(var55, var56);
    org.jfree.chart.axis.ValueAxis var58 = null;
    java.awt.Shape var60 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var63 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var60, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var65 = new org.jfree.chart.axis.DateAxis("");
    double var66 = var65.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var69 = new org.jfree.chart.entity.AxisEntity(var63, (org.jfree.chart.axis.Axis)var65, "hi!", "hi!");
    org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var72 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    java.awt.Paint var74 = null;
    var72.setSeriesOutlinePaint(0, var74);
    java.awt.Paint var77 = var72.getSeriesFillPaint(0);
    org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("hi!");
    java.awt.Shape var82 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    var80.setLine(var82);
    var72.setSeriesShape(0, var82, true);
    org.jfree.chart.plot.XYPlot var86 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset)var57, var58, (org.jfree.chart.axis.ValueAxis)var65, (org.jfree.chart.renderer.xy.XYItemRenderer)var72);
    org.jfree.chart.plot.PlotRenderingInfo var88 = null;
    java.awt.geom.Point2D var89 = null;
    var86.panDomainAxes(100.0d, var88, var89);
    org.jfree.chart.util.RectangleInsets var91 = var86.getAxisOffset();
    double var93 = var91.calculateTopInset(Double.NaN);
    var38.setAxisOffset(var91);
    boolean var95 = var10.equals((java.lang.Object)var38);
    float var96 = var38.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "RectangleConstraintType.RANGE"+ "'", var22.equals("RectangleConstraintType.RANGE"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == 0.5f);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
    double var10 = var9.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var15.setRangeAxisLocation(1, var17, true);
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var15.addChangeListener(var20);
    java.awt.Paint var22 = var15.getRangeCrosshairPaint();
    var15.zoom((-1.0d));
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var15.panRangeAxes(Double.NaN, var26, var27);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var30 = var15.getRangeAxisForDataset((-16777216));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    java.text.NumberFormat var1 = null;
    org.jfree.chart.util.LogFormat var5 = new org.jfree.chart.util.LogFormat(1.0d, "January 0", true);
    int var6 = var5.getMinimumFractionDigits();
    var5.setMaximumFractionDigits(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardXYToolTipGenerator var9 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, (java.text.NumberFormat)var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.chart.plot.CombinedRangeXYPlot var0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
    org.jfree.chart.renderer.xy.XYStepRenderer var1 = new org.jfree.chart.renderer.xy.XYStepRenderer();
    java.awt.Font var2 = var1.getBaseItemLabelFont();
    var0.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setStepPoint(2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleConstraint[LengthConstraintType.FIXED: width=100.0, height=0.0]", var1);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     java.awt.Color var5 = java.awt.Color.getColor("hi!", 1);
//     java.awt.color.ColorSpace var6 = var5.getColorSpace();
//     org.jfree.chart.plot.IntervalMarker var7 = new org.jfree.chart.plot.IntervalMarker(100.0d, 10.0d, (java.awt.Paint)var5);
//     java.awt.Font var8 = var7.getLabelFont();
//     org.jfree.chart.text.TextFragment var9 = new org.jfree.chart.text.TextFragment("", var8);
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var16 = var12.getItemCreateEntity((-1), 13, true);
//     org.jfree.chart.renderer.category.BarPainter var17 = var12.getBarPainter();
//     double var18 = var12.getItemMargin();
//     java.lang.Object var19 = var12.clone();
//     java.awt.Paint var23 = var12.getItemLabelPaint(0, 2147483647, false);
//     boolean var24 = var9.equals((java.lang.Object)var23);
//     java.awt.Paint var25 = var9.getPaint();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.util.Size2D var27 = var9.calculateDimensions(var26);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var7 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var4, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var9 = new org.jfree.chart.axis.DateAxis("");
//     double var10 = var9.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var13 = new org.jfree.chart.entity.AxisEntity(var7, (org.jfree.chart.axis.Axis)var9, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var0, (org.jfree.chart.axis.CategoryAxis)var2, (org.jfree.chart.axis.ValueAxis)var9, var14);
//     org.jfree.chart.axis.AxisLocation var17 = null;
//     var15.setRangeAxisLocation(1, var17, false);
//     int var20 = var15.getRangeAxisCount();
//     org.jfree.data.category.CategoryDataset var21 = null;
//     org.jfree.chart.axis.CategoryAxis3D var23 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var28 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var25, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var30 = new org.jfree.chart.axis.DateAxis("");
//     double var31 = var30.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var34 = new org.jfree.chart.entity.AxisEntity(var28, (org.jfree.chart.axis.Axis)var30, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var35 = null;
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot(var21, (org.jfree.chart.axis.CategoryAxis)var23, (org.jfree.chart.axis.ValueAxis)var30, var35);
//     org.jfree.chart.axis.AxisLocation var38 = null;
//     var36.setRangeAxisLocation(1, var38, true);
//     org.jfree.chart.event.PlotChangeListener var41 = null;
//     var36.addChangeListener(var41);
//     java.awt.Paint var43 = var36.getRangeCrosshairPaint();
//     var15.setNoDataMessagePaint(var43);
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.event.AxisChangeEvent var46 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var45);
//     var15.axisChanged(var46);
//     org.jfree.chart.renderer.xy.XYLineAndShapeRenderer var50 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
//     java.awt.Paint var52 = var50.lookupSeriesFillPaint(1);
//     var50.setSeriesLinesVisible(10, (java.lang.Boolean)false);
//     boolean var57 = var50.equals((java.lang.Object)(byte)(-1));
//     var50.setBaseLinesVisible(false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var60 = var50.getLegendItemLabelGenerator();
//     java.awt.Paint var62 = var50.lookupSeriesPaint((-459));
//     var15.setDomainGridlinePaint(var62);
//     org.jfree.data.category.CategoryDataset var65 = null;
//     org.jfree.chart.axis.CategoryAxis3D var67 = new org.jfree.chart.axis.CategoryAxis3D("");
//     java.awt.Shape var69 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
//     java.awt.Shape var72 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var69, 0.0d, 100.0d);
//     org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis("");
//     double var75 = var74.getUpperMargin();
//     org.jfree.chart.entity.AxisEntity var78 = new org.jfree.chart.entity.AxisEntity(var72, (org.jfree.chart.axis.Axis)var74, "hi!", "hi!");
//     org.jfree.chart.renderer.category.CategoryItemRenderer var79 = null;
//     org.jfree.chart.plot.CategoryPlot var80 = new org.jfree.chart.plot.CategoryPlot(var65, (org.jfree.chart.axis.CategoryAxis)var67, (org.jfree.chart.axis.ValueAxis)var74, var79);
//     org.jfree.chart.axis.AxisLocation var82 = null;
//     var80.setRangeAxisLocation(1, var82, false);
//     org.jfree.chart.plot.PlotOrientation var85 = var80.getOrientation();
//     org.jfree.chart.renderer.category.BarRenderer3D var88 = new org.jfree.chart.renderer.category.BarRenderer3D((-1.0d), 1.0d);
//     boolean var92 = var88.getItemCreateEntity((-1), 13, true);
//     java.awt.Shape var94 = var88.getLegendShape(100);
//     boolean var95 = var85.equals((java.lang.Object)var88);
//     var88.setAutoPopulateSeriesOutlineStroke(true);
//     var15.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer)var88, true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var80
//     assertTrue("Contract failed: equals-hashcode on var36 and var80", var36.equals(var80) ? var36.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var36
//     assertTrue("Contract failed: equals-hashcode on var80 and var36", var80.equals(var36) ? var80.hashCode() == var36.hashCode() : true);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var5 = var4.toString();
    org.jfree.data.time.Year var6 = var4.getYear();
    org.jfree.data.time.Month var9 = new org.jfree.data.time.Month(1, 0);
    java.lang.String var10 = var9.toString();
    org.jfree.data.time.TimeSeries var11 = var1.createCopy((org.jfree.data.time.RegularTimePeriod)var6, (org.jfree.data.time.RegularTimePeriod)var9);
    org.jfree.data.time.Month var14 = new org.jfree.data.time.Month(1, 0);
    org.jfree.data.time.RegularTimePeriod var15 = var14.next();
    org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)1.0f);
    org.jfree.data.category.CategoryDataset var18 = null;
    org.jfree.chart.axis.CategoryAxis3D var20 = new org.jfree.chart.axis.CategoryAxis3D("");
    java.awt.Shape var22 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    java.awt.Shape var25 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var22, 0.0d, 100.0d);
    org.jfree.chart.axis.DateAxis var27 = new org.jfree.chart.axis.DateAxis("");
    double var28 = var27.getUpperMargin();
    org.jfree.chart.entity.AxisEntity var31 = new org.jfree.chart.entity.AxisEntity(var25, (org.jfree.chart.axis.Axis)var27, "hi!", "hi!");
    org.jfree.chart.renderer.category.CategoryItemRenderer var32 = null;
    org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var18, (org.jfree.chart.axis.CategoryAxis)var20, (org.jfree.chart.axis.ValueAxis)var27, var32);
    org.jfree.chart.axis.AxisLocation var35 = null;
    var33.setRangeAxisLocation(1, var35, true);
    org.jfree.chart.event.PlotChangeListener var38 = null;
    var33.addChangeListener(var38);
    java.awt.Paint var40 = var33.getRangeCrosshairPaint();
    org.jfree.chart.util.RectangleEdge var41 = var33.getRangeAxisEdge();
    boolean var42 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(var41);
    java.lang.String var43 = var41.toString();
    boolean var44 = var17.equals((java.lang.Object)var41);
    var11.add(var17, true);
    java.lang.Object var47 = var11.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "January 0"+ "'", var5.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "January 0"+ "'", var10.equals("January 0"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "RectangleEdge.LEFT"+ "'", var43.equals("RectangleEdge.LEFT"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
    int var10 = var9.getMaximumItemCount();
    java.lang.String var11 = var9.getRangeDescription();
    org.jfree.data.time.TimeSeries var12 = var5.addAndOrUpdate(var9);
    java.util.List var13 = var12.getItems();
    org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)1);
    org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)0, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
    int var20 = var19.getMaximumItemCount();
    java.lang.String var21 = var19.getRangeDescription();
    org.jfree.data.time.TimeSeries var22 = var15.addAndOrUpdate(var19);
    java.util.List var23 = var22.getItems();
    org.jfree.data.time.TimeSeries var24 = var12.addAndOrUpdate(var22);
    java.util.TimeZone var25 = null;
    org.jfree.data.time.TimeSeriesCollection var26 = new org.jfree.data.time.TimeSeriesCollection(var24, var25);
    var2.addSeries(var24);
    
    // Checks the contract:  equals-hashcode on var2 and var26
    assertTrue("Contract failed: equals-hashcode on var2 and var26", var2.equals(var26) ? var2.hashCode() == var26.hashCode() : true);
    
    // Checks the contract:  equals-hashcode on var26 and var2
    assertTrue("Contract failed: equals-hashcode on var26 and var2", var26.equals(var2) ? var26.hashCode() == var2.hashCode() : true);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    org.jfree.data.xy.XYSeriesCollection var0 = new org.jfree.data.xy.XYSeriesCollection();
    double var1 = var0.getIntervalWidth();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var4 = var0.getStartYValue(2147483647, (-459));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);

  }

}
