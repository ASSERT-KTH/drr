
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 100);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    var0.setAutoPopulateSeriesOutlineStroke(false);
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getNegativeItemLabelPositionFallback();
    var0.setSeriesVisibleInLegend(1, (java.lang.Boolean)false);
    java.awt.Paint var12 = null;
    var0.setSeriesFillPaint(178, var12, false);
    var0.setIncludeBaseInRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    var0.setAutoPopulateSeriesPaint(true);
    java.awt.Stroke var11 = null;
    var0.setSeriesOutlineStroke(10, var11, false);
    int var14 = var0.getPassCount();
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getPositiveItemLabelPosition(2, 10, true);
    org.jfree.chart.labels.ItemLabelAnchor var19 = var18.getItemLabelAnchor();
    org.jfree.chart.labels.ItemLabelAnchor var20 = var18.getItemLabelAnchor();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var23 = var21.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = null;
    var21.setLegendItemURLGenerator(var24);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var21.setBaseURLGenerator(var26, false);
    var21.setAutoPopulateSeriesPaint(true);
    var21.setBaseShapesFilled(false);
    org.jfree.chart.labels.ItemLabelPosition var34 = var21.getSeriesPositiveItemLabelPosition(0);
    org.jfree.chart.labels.ItemLabelPosition var36 = var21.getSeriesNegativeItemLabelPosition(4);
    org.jfree.chart.text.TextAnchor var37 = var36.getTextAnchor();
    org.jfree.chart.text.TextAnchor var38 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var40 = new org.jfree.chart.labels.ItemLabelPosition(var20, var37, var38, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.Range var22 = var8.getDataRange(var21);
    var8.clearRangeMarkers((-1));
    org.jfree.chart.LegendItemCollection var25 = var8.getLegendItems();
    org.jfree.chart.axis.CategoryAnchor var26 = var8.getDomainGridlinePosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    boolean var18 = var8.isDomainZoomable();
    java.awt.Font var19 = var8.getNoDataMessageFont();
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var8.getRangeMarkers(var20);
    boolean var22 = var8.getDrawSharedDomainAxis();
    org.jfree.chart.event.PlotChangeEvent var23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
    var8.setRangePannable(false);
    java.awt.Paint var26 = var8.getRangeZeroBaselinePaint();
    float var27 = var8.getBackgroundImageAlpha();
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var8.panDomainAxes((-1.0d), var29, var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.5f);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
    var5.setLegendItemURLGenerator(var8);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    var5.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var15.setSeriesToolTipGenerator(0, var17, true);
    org.jfree.chart.labels.ItemLabelPosition var20 = var15.getBasePositiveItemLabelPosition();
    java.awt.Paint var21 = var15.getBaseFillPaint();
    var5.setBaseOutlinePaint(var21, false);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var4, var21);
    int var25 = var24.getSeriesIndex();
    boolean var26 = var24.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    int var6 = var4.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var11 = var9.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var7, var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var9);
    java.awt.Paint var14 = var9.lookupLegendTextPaint(0);
    java.awt.Shape var16 = var9.lookupLegendShape(10);
    org.jfree.chart.entity.ChartEntity var19 = new org.jfree.chart.entity.ChartEntity(var16, "", "GradientPaintTransformType.VERTICAL");
    org.jfree.chart.ChartColor var23 = new org.jfree.chart.ChartColor(2, 1, 2);
    int var24 = var23.getTransparency();
    int var25 = var23.getGreen();
    java.awt.color.ColorSpace var26 = var23.getColorSpace();
    java.awt.Color var27 = var23.darker();
    int var28 = var23.getRGB();
    int var29 = var23.getRed();
    java.awt.Color var30 = var23.brighter();
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("TextAnchor.TOP_CENTER", "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", "", "CategoryAnchor.MIDDLE", var16, (java.awt.Paint)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-16645886));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape((-15466498));
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var9 = var6.getLegendItem(2, 100);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var11 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("org.jfree.data.UnknownKeyException: ");
    java.lang.Object var12 = var11.clone();
    var6.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var11);
    java.lang.Object var14 = var11.clone();
    boolean var15 = var0.equals((java.lang.Object)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    java.awt.Shape var10 = var0.getItemShape(10, 4, true);
    java.awt.Font var14 = var0.getItemLabelFont(100, 2, true);
    int var15 = var0.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0.5f);
    var0.clear();
    java.util.List var4 = var0.getColumnKeys();
    java.util.List var5 = var0.getColumnKeys();
    org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
    int var8 = var6.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    double var12 = var11.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var13 = var11.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var9, var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var15.getBaseItemLabelGenerator();
    var15.setShadowYOffset(0.2d);
    var14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var15, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var25 = var23.getSeriesStroke(0);
    boolean var26 = var23.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var28 = var23.lookupSeriesFillPaint(10);
    var14.setDomainCrosshairPaint(var28);
    int var30 = var14.getRendererCount();
    java.awt.Graphics2D var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var14.drawBackgroundImage(var31, var32);
    var14.setBackgroundImageAlignment(1);
    boolean var36 = var0.equals((java.lang.Object)var14);
    int var38 = var0.getColumnIndex((java.lang.Comparable)"TextAnchor.TOP_CENTER");
    int var39 = var0.getColumnCount();
    java.util.List var40 = var0.getRowKeys();
    org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var44 = var42.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var45 = null;
    var42.setLegendItemURLGenerator(var45);
    org.jfree.chart.urls.CategoryURLGenerator var47 = null;
    var42.setBaseURLGenerator(var47, false);
    var42.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var52.setSeriesToolTipGenerator(0, var54, true);
    org.jfree.chart.labels.ItemLabelPosition var57 = var52.getBasePositiveItemLabelPosition();
    java.awt.Paint var58 = var52.getBaseFillPaint();
    var42.setBaseOutlinePaint(var58, false);
    boolean var61 = var42.getUseFillPaint();
    java.awt.Font var62 = var42.getBaseItemLabelFont();
    var41.setTickLabelFont(var62);
    var41.setCategoryMargin(1.0d);
    var41.setTickMarkInsideLength(0.0f);
    boolean var68 = var41.isTickLabelsVisible();
    double var69 = var41.getLowerMargin();
    var0.addObject((java.lang.Object)var41, (java.lang.Comparable)(-15466498), (java.lang.Comparable)(-9.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.05d);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.LegendItemCollection var12 = var8.getLegendItems();
    int var13 = var8.getBackgroundImageAlignment();
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var8.panRangeAxes(Double.NaN, var15, var16);
    var8.setRangeCrosshairVisible(true);
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    double var26 = var25.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var27 = var25.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var23, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.util.Layer var30 = null;
    java.util.Collection var31 = var28.getRangeMarkers((-1), var30);
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var35 = var32.getLegendItem(2, 100);
    java.awt.Stroke var36 = var32.getBaseStroke();
    var28.setRangeCrosshairStroke(var36);
    org.jfree.chart.plot.Marker var39 = null;
    org.jfree.chart.util.Layer var40 = null;
    boolean var41 = var28.removeDomainMarker(1, var39, var40);
    boolean var42 = var28.isRangeCrosshairVisible();
    var28.clearRangeAxes();
    org.jfree.chart.plot.DatasetRenderingOrder var44 = var28.getDatasetRenderingOrder();
    var8.setDatasetRenderingOrder(var44);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var48 = var46.getSeriesStroke(0);
    boolean var49 = var46.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var51 = var46.lookupSeriesFillPaint(10);
    java.awt.Paint var55 = var46.getItemOutlinePaint(100, 1, true);
    org.jfree.chart.event.RendererChangeEvent var56 = null;
    var46.notifyListeners(var56);
    boolean var58 = var44.equals((java.lang.Object)var56);
    org.jfree.chart.util.BooleanList var59 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var61 = var59.getBoolean(10);
    java.lang.Boolean var63 = var59.getBoolean(1);
    java.lang.Boolean var65 = var59.getBoolean(0);
    boolean var66 = var44.equals((java.lang.Object)var59);
    java.lang.String var67 = var44.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "DatasetRenderingOrder.REVERSE"+ "'", var67.equals("DatasetRenderingOrder.REVERSE"));

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    var0.setUseFillPaint(true);
    var0.setSeriesItemLabelsVisible(2, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var11.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    int var17 = var15.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var18 = new org.jfree.data.general.DatasetGroup();
    var15.setGroup(var18);
    org.jfree.data.Range var20 = var11.findRangeBounds((org.jfree.data.category.CategoryDataset)var15);
    org.jfree.data.Range var21 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var15);
    java.awt.Shape var22 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getBaseItemLabelGenerator();
    var0.setSeriesShapesVisible(15, true);
    boolean var27 = var0.getBaseSeriesVisibleInLegend();
    boolean var28 = var0.getAutoPopulateSeriesOutlineStroke();
    boolean var30 = var0.isSeriesVisible(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    java.awt.Paint var6 = var0.getBaseFillPaint();
    boolean var7 = var0.getBaseSeriesVisibleInLegend();
    var0.setSeriesShapesFilled(0, true);
    boolean var11 = var0.getAutoPopulateSeriesShape();
    boolean var12 = var0.getAutoPopulateSeriesShape();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setItemMargin(1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    java.awt.Paint var9 = var0.getItemOutlinePaint(100, 1, true);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var13, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var19.getBaseItemLabelGenerator();
    var19.setShadowYOffset(0.2d);
    var18.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var19, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var29 = var27.getSeriesStroke(0);
    boolean var30 = var27.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var32 = var27.lookupSeriesFillPaint(10);
    var18.setDomainCrosshairPaint(var32);
    int var34 = var18.getRendererCount();
    var0.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
    java.awt.Graphics2D var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    var18.drawBackgroundImage(var36, var37);
    org.jfree.chart.plot.DefaultDrawingSupplier var39 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var40 = var39.getNextShape();
    var18.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var39, false);
    java.awt.Stroke var43 = var39.getNextOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    float var1 = var0.getTickMarkInsideLength();
    java.awt.Paint var2 = var0.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var3 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var3.getCategoryEnd(2, 0, var6, var7);
    org.jfree.data.category.DefaultCategoryDataset var9 = new org.jfree.data.category.DefaultCategoryDataset();
    int var11 = var9.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    double var15 = var14.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var16 = var14.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, var12, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var17.getRangeMarkers(0, var19);
    var17.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var24 = null;
    var17.setDomainAxis(2, var24, true);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var17.zoomDomainAxes(0.0d, var28, var29, false);
    var3.setPlot((org.jfree.chart.plot.Plot)var17);
    java.awt.Paint var33 = var3.getTickLabelPaint();
    var0.setTickLabelPaint(var33);
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.util.RectangleEdge var38 = null;
    double var39 = var0.getCategoryStart(1, (-16620543), var37, var38);
    org.jfree.chart.util.StandardGradientPaintTransformer var40 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var41 = var40.getType();
    java.lang.Object var42 = var40.clone();
    java.lang.Object var43 = var40.clone();
    org.jfree.data.category.DefaultCategoryDataset var44 = new org.jfree.data.category.DefaultCategoryDataset();
    int var46 = var44.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var47 = null;
    org.jfree.chart.axis.ValueAxis var48 = null;
    org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
    double var50 = var49.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var51 = var49.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var44, var47, var48, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
    org.jfree.chart.util.Layer var54 = null;
    java.util.Collection var55 = var52.getRangeMarkers(0, var54);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var56.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var60 = var56.getLegendItems();
    var52.setFixedLegendItems(var60);
    boolean var62 = var40.equals((java.lang.Object)var52);
    boolean var63 = var0.hasListener((java.util.EventListener)var52);
    var52.setRangePannable(false);
    var52.clearDomainMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var10 = null;
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers((-1), var21);
    org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var10, var19, var24, var25, var26);
    var0.setSeriesLinesVisible(5, (java.lang.Boolean)false);
    double var31 = var0.getItemMargin();
    java.lang.Object var32 = var0.clone();
    boolean var35 = var0.getItemShapeVisible(10, (-1));
    org.jfree.chart.LegendItem var38 = var0.getLegendItem(3, (-16056321));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var15 = var12.getLegendItem(2, 100);
    java.awt.Stroke var16 = var12.getBaseStroke();
    var8.setRangeCrosshairStroke(var16);
    org.jfree.chart.plot.Marker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    boolean var21 = var8.removeDomainMarker(1, var19, var20);
    boolean var22 = var8.isRangeCrosshairVisible();
    var8.clearRangeAxes();
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    double var25 = var24.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getPositiveItemLabelPositionFallback();
    int var27 = var24.getPassCount();
    boolean var29 = var24.equals((java.lang.Object)"");
    var24.setBaseSeriesVisibleInLegend(true);
    var24.setBase(0.2d);
    boolean var34 = var24.getShadowsVisible();
    var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var24, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = null;
    var24.setSeriesToolTipGenerator(3, var38, false);
    double var41 = var24.getShadowXOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 4.0d);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Paint var6 = var2.getItemOutlinePaint((-16777216), 255, true);
    var2.setSeriesCreateEntities(255, (java.lang.Boolean)false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesVisibleInLegend((-16580609), (java.lang.Boolean)false, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0.5f);
    int var3 = var0.getColumnCount();
    int var4 = var0.getColumnCount();
    org.jfree.data.KeyedObjects var5 = new org.jfree.data.KeyedObjects();
    int var7 = var5.getIndex((java.lang.Comparable)0.05d);
    var5.clear();
    java.awt.Shape var14 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var17 = var15.getSeriesStroke(0);
    boolean var18 = var15.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var20 = var15.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var14, var20);
    var21.setSeriesKey((java.lang.Comparable)true);
    var21.setDescription("hi!");
    int var26 = var21.getDatasetIndex();
    java.awt.Stroke var27 = var21.getOutlineStroke();
    java.awt.Shape var32 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var35 = var33.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var36 = null;
    var33.setLegendItemURLGenerator(var36);
    org.jfree.chart.urls.CategoryURLGenerator var38 = null;
    var33.setBaseURLGenerator(var38, false);
    var33.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var45 = null;
    var43.setSeriesToolTipGenerator(0, var45, true);
    org.jfree.chart.labels.ItemLabelPosition var48 = var43.getBasePositiveItemLabelPosition();
    java.awt.Paint var49 = var43.getBaseFillPaint();
    var33.setBaseOutlinePaint(var49, false);
    org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var32, var49);
    java.awt.Paint var53 = var52.getOutlinePaint();
    var52.setSeriesKey((java.lang.Comparable)'a');
    java.awt.Shape var56 = var52.getLine();
    org.jfree.chart.util.StandardGradientPaintTransformer var57 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var58 = var57.getType();
    var52.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var57);
    var21.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var57);
    var5.setObject((java.lang.Comparable)"rect", (java.lang.Object)var57);
    org.jfree.chart.util.PaintList var63 = new org.jfree.chart.util.PaintList();
    var5.setObject((java.lang.Comparable)1, (java.lang.Object)var63);
    int var65 = var5.getItemCount();
    org.jfree.data.category.DefaultCategoryDataset var66 = new org.jfree.data.category.DefaultCategoryDataset();
    int var68 = var66.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var69 = null;
    org.jfree.chart.axis.ValueAxis var70 = null;
    org.jfree.chart.renderer.category.BarRenderer var71 = new org.jfree.chart.renderer.category.BarRenderer();
    double var72 = var71.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var73 = var71.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var74 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var66, var69, var70, (org.jfree.chart.renderer.category.CategoryItemRenderer)var71);
    org.jfree.chart.util.Layer var76 = null;
    java.util.Collection var77 = var74.getRangeMarkers(0, var76);
    var74.setForegroundAlpha(100.0f);
    org.jfree.chart.event.AxisChangeEvent var80 = null;
    var74.axisChanged(var80);
    org.jfree.chart.util.SortOrder var82 = var74.getRowRenderingOrder();
    var5.sortByObjects(var82);
    boolean var84 = var0.equals((java.lang.Object)var5);
    int var86 = var0.getColumnIndex((java.lang.Comparable)100.0f);
    int var88 = var0.getRowIndex((java.lang.Comparable)(-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == (-1));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
    var0.setGroup(var3);
    int var6 = var0.getRowIndex((java.lang.Comparable)(short)100);
    var0.addValue((java.lang.Number)(-1L), (java.lang.Comparable)"AxisLocation.BOTTOM_OR_RIGHT", (java.lang.Comparable)0.5f);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var15 = var13.getSeriesStroke(0);
    boolean var16 = var13.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var18 = var13.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var22 = var13.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var24 = var13.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var27 = null;
    var25.setSeriesToolTipGenerator(0, var27, true);
    org.jfree.chart.labels.ItemLabelPosition var30 = var25.getBasePositiveItemLabelPosition();
    var13.setBasePositiveItemLabelPosition(var30);
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var11, var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    boolean var34 = var13.isSeriesVisibleInLegend(178);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test20"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var2 = var0.getSeriesPaint(100);
//     java.awt.Paint var4 = var0.getSeriesFillPaint(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var9 = var5.getUseSeriesOffset();
//     java.awt.Paint var10 = var5.getBaseOutlinePaint();
//     java.awt.Shape var11 = var5.getBaseShape();
//     var0.setDefaultShape(var11);
//     org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var16 = null;
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var19 = var18.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
//     java.lang.Object var27 = var26.clone();
//     var21.setFixedLegendItems(var26);
//     org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
//     org.jfree.chart.axis.AxisSpace var31 = null;
//     var21.setFixedDomainAxisSpace(var31);
//     java.awt.Paint var33 = var21.getRangeGridlinePaint();
//     org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
//     org.jfree.chart.LegendItem var37 = var34.getLegendItem(2, 100);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var38 = var34.getLegendItemLabelGenerator();
//     var21.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var34, true);
//     java.lang.Boolean var42 = var34.getSeriesCreateEntities(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var45 = var43.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var46 = null;
//     var43.setLegendItemURLGenerator(var46);
//     org.jfree.chart.urls.CategoryURLGenerator var48 = null;
//     var43.setBaseURLGenerator(var48, false);
//     var43.setAutoPopulateSeriesPaint(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var55 = null;
//     var53.setSeriesToolTipGenerator(0, var55, true);
//     org.jfree.chart.labels.ItemLabelPosition var58 = var53.getBasePositiveItemLabelPosition();
//     java.awt.Paint var59 = var53.getBaseFillPaint();
//     var43.setBaseOutlinePaint(var59, false);
//     boolean var62 = var43.getUseFillPaint();
//     org.jfree.chart.ChartColor var66 = new org.jfree.chart.ChartColor(2, 1, 2);
//     int var67 = var66.getTransparency();
//     int var68 = var66.getGreen();
//     java.awt.color.ColorSpace var69 = var66.getColorSpace();
//     int var70 = var66.getTransparency();
//     var43.setBaseLegendTextPaint((java.awt.Paint)var66);
//     int var72 = var66.getGreen();
//     var34.setShadowPaint((java.awt.Paint)var66);
//     
//     // Checks the contract:  equals-hashcode on var53 and var5
//     assertTrue("Contract failed: equals-hashcode on var53 and var5", var53.equals(var5) ? var53.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var22
//     assertTrue("Contract failed: equals-hashcode on var53 and var22", var53.equals(var22) ? var53.hashCode() == var22.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var53 and var5.", var53.equals(var5) == var5.equals(var53));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var53 and var22.", var53.equals(var22) == var22.equals(var53));
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test21"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("Category Plot");
    java.lang.String var2 = var1.getLabel();
    boolean var3 = var1.isShapeOutlineVisible();
    java.lang.Comparable var4 = var1.getSeriesKey();
    int var5 = var1.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test22"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    int var6 = var0.getColumnCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var0.setSeriesItemLabelGenerator(10, var8);
    var0.setSeriesShapesVisible(0, (java.lang.Boolean)true);
    var0.setAutoPopulateSeriesFillPaint(false);
    var0.setBaseSeriesVisibleInLegend(false, false);
    boolean var18 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test23"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    org.jfree.chart.labels.ItemLabelPosition var10 = var0.getNegativeItemLabelPositionFallback();
    boolean var11 = var0.isDrawBarOutline();
    var0.setIncludeBaseInRange(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test24"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var4 = var0.getUseSeriesOffset();
//     var0.setSeriesShapesFilled(1, (java.lang.Boolean)false);
//     java.lang.Boolean var9 = var0.getSeriesVisible(1);
//     var0.setAutoPopulateSeriesStroke(false);
//     var0.setBaseItemLabelsVisible(false, false);
//     java.awt.Font var15 = var0.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var19 = var17.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var20 = null;
//     var17.setLegendItemURLGenerator(var20);
//     org.jfree.chart.urls.CategoryURLGenerator var22 = null;
//     var17.setBaseURLGenerator(var22, false);
//     java.lang.Boolean var26 = var17.getSeriesVisibleInLegend((-1));
//     boolean var29 = var17.getItemShapeFilled((-1), 100);
//     java.awt.Paint var33 = var17.getItemFillPaint(100, 0, true);
//     java.awt.Paint var35 = var17.lookupSeriesPaint((-1));
//     var0.setSeriesItemLabelPaint(16777228, var35);
//     
//     // Checks the contract:  equals-hashcode on var17 and var0
//     assertTrue("Contract failed: equals-hashcode on var17 and var0", var17.equals(var0) ? var17.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var17 and var0.", var17.equals(var0) == var0.equals(var17));
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test25"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var2 = var0.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
//     var0.setLegendItemURLGenerator(var3);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var0.setBaseURLGenerator(var5, false);
//     java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
//     boolean var12 = var0.getItemShapeFilled((-1), 100);
//     java.awt.Paint var16 = var0.getItemFillPaint(100, 0, true);
//     java.awt.Paint var18 = var0.lookupSeriesPaint((-1));
//     org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var0.getItemLabelGenerator(10, 0, true);
//     java.awt.Stroke var24 = var0.lookupSeriesStroke(4);
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     float var27 = var26.getMinorTickMarkOutsideLength();
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.util.RectangleEdge var31 = null;
//     double var32 = var26.getCategoryStart(0, 100, var30, var31);
//     boolean var33 = var26.isMinorTickMarksVisible();
//     java.awt.Font var35 = var26.getTickLabelFont((java.lang.Comparable)(short)(-1));
//     var0.setSeriesItemLabelFont(10, var35);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var39 = var37.getSeriesStroke(0);
//     boolean var40 = var37.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var42 = var37.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.CategoryToolTipGenerator var46 = var37.getToolTipGenerator(1, (-1), true);
//     java.awt.Shape var48 = var37.getSeriesShape(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var51 = null;
//     var49.setSeriesToolTipGenerator(0, var51, true);
//     org.jfree.chart.labels.ItemLabelPosition var54 = var49.getBasePositiveItemLabelPosition();
//     var37.setBasePositiveItemLabelPosition(var54);
//     org.jfree.chart.labels.ItemLabelAnchor var56 = var54.getItemLabelAnchor();
//     var0.setBasePositiveItemLabelPosition(var54);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var0.", var37.equals(var0) == var0.equals(var37));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var49 and var0.", var49.equals(var0) == var0.equals(var49));
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test26"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var9.getBaseItemLabelGenerator();
    var9.setShadowYOffset(0.2d);
    var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var9, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var19 = var17.getSeriesStroke(0);
    boolean var20 = var17.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var22 = var17.lookupSeriesFillPaint(10);
    var8.setDomainCrosshairPaint(var22);
    boolean var24 = var8.isOutlineVisible();
    boolean var25 = var8.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test27"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var4 = var0.getLegendItems();
    java.lang.Object var5 = var4.clone();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getPositiveItemLabelPositionFallback();
    java.awt.Font var10 = var6.lookupLegendTextFont(1);
    boolean var12 = var6.isSeriesVisibleInLegend(4);
    var6.setBaseCreateEntities(false);
    boolean var15 = var4.equals((java.lang.Object)var6);
    org.jfree.chart.labels.ItemLabelPosition var16 = var6.getPositiveItemLabelPositionFallback();
    org.jfree.chart.urls.CategoryURLGenerator var18 = null;
    var6.setSeriesURLGenerator(100, var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test28() {}
//   public void test28() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test28"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var3 = null;
//     org.jfree.chart.util.RectangleEdge var4 = null;
//     double var5 = var0.getCategoryEnd(2, 0, var3, var4);
//     java.lang.String var6 = var0.getLabel();
//     org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var13 = var12.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var17 = var16.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var18 = var16.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var16.getBaseItemLabelGenerator();
//     var16.setShadowYOffset(0.2d);
//     var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var26 = var24.getSeriesStroke(0);
//     boolean var27 = var24.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var29 = var24.lookupSeriesFillPaint(10);
//     var15.setDomainCrosshairPaint(var29);
//     var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
//     double var32 = var0.getCategoryMargin();
//     var0.setTickMarkOutsideLength((-1.0f));
//     java.awt.Paint var35 = var0.getAxisLinePaint();
//     var0.removeCategoryLabelToolTip((java.lang.Comparable)(-1.0f));
//     var0.setTickMarksVisible(true);
//     boolean var40 = var0.isMinorTickMarksVisible();
//     org.jfree.chart.axis.CategoryAxis var41 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var44 = null;
//     org.jfree.chart.util.RectangleEdge var45 = null;
//     double var46 = var41.getCategoryEnd(2, 0, var44, var45);
//     java.lang.String var47 = var41.getLabel();
//     org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var50 = var48.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var51 = null;
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.category.BarRenderer var53 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var54 = var53.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var55 = var53.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var48, var51, var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var53);
//     org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var58 = var57.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var59 = var57.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var60 = var57.getBaseItemLabelGenerator();
//     var57.setShadowYOffset(0.2d);
//     var56.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var57, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var67 = var65.getSeriesStroke(0);
//     boolean var68 = var65.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var70 = var65.lookupSeriesFillPaint(10);
//     var56.setDomainCrosshairPaint(var70);
//     var41.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var56);
//     double var73 = var41.getCategoryMargin();
//     var41.setTickMarkOutsideLength((-1.0f));
//     java.awt.Paint var77 = var41.getTickLabelPaint((java.lang.Comparable)100L);
//     var0.setLabelPaint(var77);
//     
//     // Checks the contract:  equals-hashcode on var15 and var56
//     assertTrue("Contract failed: equals-hashcode on var15 and var56", var15.equals(var56) ? var15.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var15
//     assertTrue("Contract failed: equals-hashcode on var56 and var15", var56.equals(var15) ? var56.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test29"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var10 = null;
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers((-1), var21);
    org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var10, var19, var24, var25, var26);
    var19.setDomainCrosshairColumnKey((java.lang.Comparable)2.0f, true);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var35 = var31.getURLGenerator((-1), 0, true);
    java.awt.Paint var37 = var31.getLegendTextPaint((-16777216));
    java.awt.Paint var41 = var31.getItemFillPaint((-16777216), 100, true);
    var19.setRangeZeroBaselinePaint(var41);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var19.zoomRangeAxes(0.0d, 1.0d, var45, var46);
    java.awt.Paint var48 = var19.getRangeZeroBaselinePaint();
    org.jfree.chart.plot.Marker var50 = null;
    org.jfree.chart.util.Layer var51 = null;
    boolean var53 = var19.removeDomainMarker(4, var50, var51, false);
    java.awt.Paint var54 = var19.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test30"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    int var2 = var0.getItemCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var9 = var5.getLegendItems();
    java.awt.Paint var11 = var5.lookupSeriesPaint(2);
    java.awt.Stroke var13 = var5.lookupSeriesStroke(4);
    java.awt.Stroke var15 = var5.lookupSeriesStroke(0);
    var0.insertValue(0, (java.lang.Comparable)1, (java.lang.Object)var5);
    java.lang.Object var17 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test31"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.axis.AxisSpace var14 = null;
    var8.setFixedRangeAxisSpace(var14, true);
    org.jfree.chart.renderer.RenderAttributes var17 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var19 = var17.getSeriesPaint(100);
    java.awt.Paint var21 = var17.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var26 = var22.getUseSeriesOffset();
    java.awt.Paint var27 = var22.getBaseOutlinePaint();
    java.awt.Shape var28 = var22.getBaseShape();
    var17.setDefaultShape(var28);
    org.jfree.data.category.DefaultCategoryDataset var30 = new org.jfree.data.category.DefaultCategoryDataset();
    int var32 = var30.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.category.BarRenderer var35 = new org.jfree.chart.renderer.category.BarRenderer();
    double var36 = var35.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var37 = var35.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var38 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var30, var33, var34, (org.jfree.chart.renderer.category.CategoryItemRenderer)var35);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var39.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var43 = var39.getLegendItems();
    java.lang.Object var44 = var43.clone();
    var38.setFixedLegendItems(var43);
    org.jfree.chart.entity.PlotEntity var47 = new org.jfree.chart.entity.PlotEntity(var28, (org.jfree.chart.plot.Plot)var38, "");
    org.jfree.chart.axis.AxisSpace var48 = null;
    var38.setFixedDomainAxisSpace(var48);
    var38.clearRangeMarkers();
    org.jfree.chart.renderer.category.CategoryItemRenderer var52 = var38.getRenderer((-16777216));
    org.jfree.chart.axis.AxisLocation var54 = var38.getDomainAxisLocation((-16645886));
    var8.setRangeAxisLocation(var54);
    var8.clearDomainAxes();
    org.jfree.chart.plot.Marker var57 = null;
    boolean var58 = var8.removeDomainMarker(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test32"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    boolean var12 = var0.getItemShapeFilled((-1), 100);
    java.awt.Paint var16 = var0.getItemFillPaint(100, 0, true);
    org.jfree.chart.labels.ItemLabelPosition var18 = null;
    var0.setSeriesNegativeItemLabelPosition(10, var18);
    org.jfree.chart.renderer.RenderAttributes var20 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var22 = var20.getSeriesPaint(100);
    java.awt.Shape var24 = var20.getSeriesShape(0);
    var20.setDefaultCreateEntity((java.lang.Boolean)true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var29 = null;
    var27.setSeriesToolTipGenerator(0, var29, true);
    org.jfree.chart.labels.ItemLabelPosition var32 = var27.getBasePositiveItemLabelPosition();
    java.awt.Paint var33 = var27.getBaseFillPaint();
    boolean var34 = var27.getBaseSeriesVisibleInLegend();
    var27.setSeriesShapesFilled(0, true);
    boolean var38 = var27.getAutoPopulateSeriesShape();
    java.awt.Shape var39 = var27.getBaseShape();
    var20.setDefaultShape(var39);
    var0.setBaseLegendShape(var39);
    java.awt.Stroke var45 = var0.getItemStroke(0, 255, false);
    java.awt.Stroke var46 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBaseStroke(var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test33"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    var8.setOutlineVisible(false);
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    double var26 = var25.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var27 = var25.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var23, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.LegendItemCollection var29 = var28.getFixedLegendItems();
    org.jfree.chart.plot.PlotOrientation var30 = var28.getOrientation();
    var8.setOrientation(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test34"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)"DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test35"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var11 = var0.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var12.setSeriesToolTipGenerator(0, var14, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var12.getBasePositiveItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var17);
    var0.setBaseItemLabelsVisible(false, true);
    java.awt.Shape var26 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var29 = var27.getSeriesStroke(0);
    boolean var30 = var27.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var32 = var27.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var26, var32);
    var33.setSeriesKey((java.lang.Comparable)true);
    var33.setLineVisible(false);
    java.lang.Object var38 = var33.clone();
    java.lang.String var39 = var33.getToolTipText();
    org.jfree.chart.util.StandardGradientPaintTransformer var40 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var41 = var40.getType();
    java.lang.Object var42 = var40.clone();
    var33.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var40);
    java.lang.String var44 = var33.getDescription();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var47 = var45.getSeriesStroke(0);
    boolean var48 = var45.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var50 = var45.lookupSeriesFillPaint(10);
    var33.setFillPaint(var50);
    var0.setBaseOutlinePaint(var50, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var0.setBaseToolTipGenerator(var54);
    org.jfree.chart.axis.CategoryAxis var57 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var60 = null;
    org.jfree.chart.util.RectangleEdge var61 = null;
    double var62 = var57.getCategoryEnd(2, 0, var60, var61);
    java.lang.String var63 = var57.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var64 = new org.jfree.data.category.DefaultCategoryDataset();
    int var66 = var64.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var67 = null;
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.category.BarRenderer var69 = new org.jfree.chart.renderer.category.BarRenderer();
    double var70 = var69.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var71 = var69.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var64, var67, var68, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
    org.jfree.chart.renderer.category.BarRenderer var73 = new org.jfree.chart.renderer.category.BarRenderer();
    double var74 = var73.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var75 = var73.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var76 = var73.getBaseItemLabelGenerator();
    var73.setShadowYOffset(0.2d);
    var72.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var73, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var81 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var83 = var81.getSeriesStroke(0);
    boolean var84 = var81.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var86 = var81.lookupSeriesFillPaint(10);
    var72.setDomainCrosshairPaint(var86);
    var57.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var72);
    double var89 = var57.getCategoryMargin();
    java.lang.String var90 = var57.getLabel();
    org.jfree.chart.util.RectangleInsets var91 = var57.getTickLabelInsets();
    org.jfree.chart.plot.Plot var92 = null;
    var57.setPlot(var92);
    java.awt.Paint var95 = var57.getTickLabelPaint((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=1.0]");
    var0.setSeriesOutlinePaint(4, var95);
    var0.setUseFillPaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + ""+ "'", var39.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test36"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    boolean var18 = var8.isDomainZoomable();
    java.awt.Font var19 = var8.getNoDataMessageFont();
    boolean var20 = var8.getDrawSharedDomainAxis();
    org.jfree.chart.util.RectangleInsets var21 = var8.getAxisOffset();
    double var22 = var21.getLeft();
    double var24 = var21.trimHeight(0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-7.8d));

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test37"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    java.awt.Paint var10 = var5.lookupLegendTextPaint(0);
    java.awt.Paint var12 = var5.getSeriesFillPaint(2);
    org.jfree.chart.labels.ItemLabelPosition var13 = var5.getPositiveItemLabelPositionFallback();
    java.awt.Paint var14 = var5.getBaseItemLabelPaint();
    org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
    int var17 = var15.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    double var21 = var20.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var22 = var20.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var18, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.util.Layer var25 = null;
    java.util.Collection var26 = var23.getRangeMarkers((-1), var25);
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var30 = var27.getLegendItem(2, 100);
    java.awt.Stroke var31 = var27.getBaseStroke();
    var23.setRangeCrosshairStroke(var31);
    org.jfree.chart.plot.Marker var34 = null;
    org.jfree.chart.util.Layer var35 = null;
    boolean var36 = var23.removeDomainMarker(1, var34, var35);
    boolean var37 = var23.isRangeCrosshairVisible();
    org.jfree.chart.axis.AxisSpace var38 = null;
    var23.setFixedRangeAxisSpace(var38);
    boolean var40 = var23.isDomainCrosshairVisible();
    var5.addChangeListener((org.jfree.chart.event.RendererChangeListener)var23);
    var23.setRangeCrosshairLockedOnData(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test38"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
    java.util.List var23 = var8.getCategories();
    var8.setDomainGridlinesVisible(true);
    org.jfree.chart.util.RectangleInsets var26 = var8.getAxisOffset();
    double var28 = var26.trimHeight(84.0d);
    double var30 = var26.calculateTopOutset(16.0d);
    double var32 = var26.calculateTopOutset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 76.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 4.0d);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test39"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    int var15 = var10.getColumnIndex((java.lang.Comparable)"PlotEntity: tooltip = ");
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers((-1), var26);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem(2, 100);
    java.awt.Stroke var32 = var28.getBaseStroke();
    var24.setRangeCrosshairStroke(var32);
    boolean var34 = var10.equals((java.lang.Object)var24);
    var10.setValue(0.0d, (java.lang.Comparable)0L, (java.lang.Comparable)0.5f);
    java.util.List var39 = var10.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.removeValue((java.lang.Comparable)(byte)10, (java.lang.Comparable)'a');
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test40"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var3 = null;
    var1.setSeriesToolTipGenerator(0, var3, true);
    org.jfree.chart.labels.ItemLabelPosition var6 = var1.getBasePositiveItemLabelPosition();
    int var7 = var1.getColumnCount();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
    var1.setSeriesItemLabelGenerator(10, var9);
    var1.setSeriesShapesVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var18 = var14.getURLGenerator((-1), 0, true);
    double var19 = var14.getMinimumBarLength();
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    double var21 = var20.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var22 = var20.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var22);
    var14.setBarPainter(var22);
    java.awt.Stroke var25 = var14.getBaseStroke();
    org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.util.RectangleEdge var30 = null;
    double var31 = var26.getCategoryEnd(2, 0, var29, var30);
    java.lang.String var32 = var26.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
    int var35 = var33.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var40 = var38.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var36, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    org.jfree.chart.renderer.category.BarRenderer var42 = new org.jfree.chart.renderer.category.BarRenderer();
    double var43 = var42.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var44 = var42.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var45 = var42.getBaseItemLabelGenerator();
    var42.setShadowYOffset(0.2d);
    var41.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var42, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var52 = var50.getSeriesStroke(0);
    boolean var53 = var50.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var55 = var50.lookupSeriesFillPaint(10);
    var41.setDomainCrosshairPaint(var55);
    var26.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var41);
    double var58 = var26.getCategoryMargin();
    var26.setTickMarkOutsideLength((-1.0f));
    java.awt.Paint var61 = var26.getAxisLinePaint();
    boolean var62 = var26.isVisible();
    float var63 = var26.getTickMarkInsideLength();
    org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis();
    float var65 = var64.getMinorTickMarkOutsideLength();
    double var66 = var64.getLowerMargin();
    org.jfree.data.category.DefaultCategoryDataset var67 = new org.jfree.data.category.DefaultCategoryDataset();
    int var69 = var67.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var70 = null;
    org.jfree.chart.axis.ValueAxis var71 = null;
    org.jfree.chart.renderer.category.BarRenderer var72 = new org.jfree.chart.renderer.category.BarRenderer();
    double var73 = var72.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var74 = var72.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var67, var70, var71, (org.jfree.chart.renderer.category.CategoryItemRenderer)var72);
    org.jfree.chart.util.Layer var77 = null;
    java.util.Collection var78 = var75.getRangeMarkers(0, var77);
    var75.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var82 = null;
    var75.setDomainAxis(2, var82, true);
    boolean var85 = var75.isDomainZoomable();
    java.awt.Font var86 = var75.getNoDataMessageFont();
    var64.setLabelFont(var86);
    var26.setLabelFont(var86);
    var14.setBaseItemLabelFont(var86, true);
    var1.setBaseItemLabelFont(var86, true);
    org.jfree.data.KeyedObject var93 = new org.jfree.data.KeyedObject((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=true]", (java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test41"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    float var16 = var8.getForegroundAlpha();
    java.awt.Paint var17 = var8.getRangeCrosshairPaint();
    java.awt.Image var18 = var8.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test42"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
    int var8 = var6.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    double var12 = var11.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var13 = var11.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var9, var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var14.getRangeMarkers((-1), var16);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var20 = var18.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var21 = null;
    var18.setLegendItemURLGenerator(var21);
    org.jfree.chart.urls.CategoryURLGenerator var23 = null;
    var18.setBaseURLGenerator(var23, false);
    java.lang.Boolean var27 = var18.getSeriesVisibleInLegend((-1));
    boolean var30 = var18.getItemShapeFilled((-1), 100);
    java.awt.Shape var35 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var38 = var36.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = null;
    var36.setLegendItemURLGenerator(var39);
    org.jfree.chart.urls.CategoryURLGenerator var41 = null;
    var36.setBaseURLGenerator(var41, false);
    var36.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var48 = null;
    var46.setSeriesToolTipGenerator(0, var48, true);
    org.jfree.chart.labels.ItemLabelPosition var51 = var46.getBasePositiveItemLabelPosition();
    java.awt.Paint var52 = var46.getBaseFillPaint();
    var36.setBaseOutlinePaint(var52, false);
    org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var35, var52);
    var18.setBaseOutlinePaint(var52, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var60 = var58.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var61 = null;
    var58.setLegendItemURLGenerator(var61);
    org.jfree.chart.urls.CategoryURLGenerator var63 = null;
    var58.setBaseURLGenerator(var63, false);
    java.lang.Boolean var67 = var58.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var71 = var58.getItemStroke(10, 1, false);
    var18.setBaseStroke(var71, false);
    var14.setDomainCrosshairStroke(var71);
    var0.setAxisLineStroke(var71);
    org.jfree.chart.axis.CategoryLabelPositions var76 = var0.getCategoryLabelPositions();
    double var77 = var0.getLowerMargin();
    boolean var78 = var0.isAxisLineVisible();
    java.lang.Object var79 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test43"); }


    org.jfree.data.UnknownKeyException var1 = new org.jfree.data.UnknownKeyException("ItemLabelAnchor.OUTSIDE12");
    org.jfree.data.UnknownKeyException var3 = new org.jfree.data.UnknownKeyException("ItemLabelAnchor.OUTSIDE12");
    java.lang.Throwable[] var4 = var3.getSuppressed();
    org.jfree.data.UnknownKeyException var6 = new org.jfree.data.UnknownKeyException("");
    java.lang.Throwable[] var7 = var6.getSuppressed();
    java.lang.String var8 = var6.toString();
    var3.addSuppressed((java.lang.Throwable)var6);
    org.jfree.data.UnknownKeyException var11 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var12 = var11.toString();
    org.jfree.data.UnknownKeyException var14 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var15 = var14.toString();
    var11.addSuppressed((java.lang.Throwable)var14);
    var6.addSuppressed((java.lang.Throwable)var11);
    org.jfree.data.UnknownKeyException var19 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var20 = var19.toString();
    org.jfree.data.UnknownKeyException var22 = new org.jfree.data.UnknownKeyException("");
    java.lang.String var23 = var22.toString();
    var19.addSuppressed((java.lang.Throwable)var22);
    var6.addSuppressed((java.lang.Throwable)var19);
    var1.addSuppressed((java.lang.Throwable)var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var8.equals("org.jfree.data.UnknownKeyException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var12.equals("org.jfree.data.UnknownKeyException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var15.equals("org.jfree.data.UnknownKeyException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var20.equals("org.jfree.data.UnknownKeyException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + "org.jfree.data.UnknownKeyException: "+ "'", var23.equals("org.jfree.data.UnknownKeyException: "));

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test44"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var8.zoomDomainAxes(0.0d, var19, var20, false);
    var8.setDomainCrosshairRowKey((java.lang.Comparable)'a');
    boolean var25 = var8.isNotify();
    var8.clearRangeMarkers();
    var8.setRangeCrosshairValue(6.2d, true);
    org.jfree.chart.LegendItemCollection var30 = var8.getFixedLegendItems();
    var8.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test45"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    org.jfree.chart.plot.Plot var3 = var0.getPlot();
    var0.setAxisLineVisible(false);
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var15.getRangeMarkers((-1), var17);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var21 = var19.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var22 = null;
    var19.setLegendItemURLGenerator(var22);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var19.setBaseURLGenerator(var24, false);
    java.lang.Boolean var28 = var19.getSeriesVisibleInLegend((-1));
    boolean var31 = var19.getItemShapeFilled((-1), 100);
    java.awt.Shape var36 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var39 = var37.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var40 = null;
    var37.setLegendItemURLGenerator(var40);
    org.jfree.chart.urls.CategoryURLGenerator var42 = null;
    var37.setBaseURLGenerator(var42, false);
    var37.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var47.setSeriesToolTipGenerator(0, var49, true);
    org.jfree.chart.labels.ItemLabelPosition var52 = var47.getBasePositiveItemLabelPosition();
    java.awt.Paint var53 = var47.getBaseFillPaint();
    var37.setBaseOutlinePaint(var53, false);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var36, var53);
    var19.setBaseOutlinePaint(var53, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var61 = var59.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var62 = null;
    var59.setLegendItemURLGenerator(var62);
    org.jfree.chart.urls.CategoryURLGenerator var64 = null;
    var59.setBaseURLGenerator(var64, false);
    java.lang.Boolean var68 = var59.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var72 = var59.getItemStroke(10, 1, false);
    var19.setBaseStroke(var72, false);
    var15.setDomainCrosshairStroke(var72);
    org.jfree.chart.plot.PlotRenderingInfo var77 = null;
    java.awt.geom.Point2D var78 = null;
    var15.zoomDomainAxes(0.0d, var77, var78, true);
    org.jfree.chart.plot.PlotRenderingInfo var82 = null;
    java.awt.geom.Point2D var83 = null;
    var15.panRangeAxes(0.05d, var82, var83);
    org.jfree.chart.event.PlotChangeEvent var85 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.plot.Plot var86 = var85.getPlot();
    org.jfree.chart.JFreeChart var87 = null;
    var85.setChart(var87);
    org.jfree.chart.event.ChartChangeEventType var89 = var85.getType();
    java.lang.String var90 = var89.toString();
    org.jfree.chart.event.ChartChangeEvent var91 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var6, var89);
    double var92 = var0.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var90 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var90.equals("ChartChangeEventType.GENERAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0.2d);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test46"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    java.lang.String var6 = var0.getLabel();
    double var7 = var0.getCategoryMargin();
    org.jfree.data.category.DefaultCategoryDataset var8 = new org.jfree.data.category.DefaultCategoryDataset();
    int var10 = var8.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.renderer.category.BarRenderer var13 = new org.jfree.chart.renderer.category.BarRenderer();
    double var14 = var13.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var15 = var13.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var16 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var8, var11, var12, (org.jfree.chart.renderer.category.CategoryItemRenderer)var13);
    org.jfree.chart.util.Layer var18 = null;
    java.util.Collection var19 = var16.getRangeMarkers((-1), var18);
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 100);
    java.awt.Stroke var24 = var20.getBaseStroke();
    var16.setRangeCrosshairStroke(var24);
    org.jfree.chart.util.Layer var27 = null;
    java.util.Collection var28 = var16.getRangeMarkers((-97), var27);
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var16);
    java.lang.String var31 = var0.getCategoryLabelToolTip((java.lang.Comparable)100.0d);
    var0.setMinorTickMarkInsideLength(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test47"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    java.awt.Shape var10 = var0.getItemShape(10, 4, true);
    java.awt.Font var14 = var0.getItemLabelFont(100, 2, true);
    var0.setShadowXOffset(3.0d);
    double var17 = var0.getMaximumBarWidth();
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var22 = var19.getBaseItemLabelGenerator();
    java.awt.Shape var24 = var19.lookupLegendShape(0);
    var0.setSeriesShape(0, var24);
    double var26 = var0.getShadowYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 4.0d);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test48"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var7 = var5.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
//     var5.setLegendItemURLGenerator(var8);
//     var5.setUseSeriesOffset(false);
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.Paint var13 = var12.getAxisLinePaint();
//     java.awt.Paint var14 = var12.getTickLabelPaint();
//     var5.setBaseOutlinePaint(var14);
//     org.jfree.chart.renderer.RenderAttributes var16 = new org.jfree.chart.renderer.RenderAttributes();
//     org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var18 = var17.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var19 = var17.getBarPainter();
//     java.awt.Stroke var20 = var17.getBaseStroke();
//     var16.setDefaultStroke(var20);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var24 = var22.getSeriesStroke(0);
//     boolean var25 = var22.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var27 = var22.lookupSeriesFillPaint(10);
//     java.awt.Paint var31 = var22.getItemOutlinePaint(100, 1, true);
//     org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("org.jfree.data.UnknownKeyException: ", "hi!", "AxisLocation.BOTTOM_OR_RIGHT", "AxisLocation.BOTTOM_OR_RIGHT", var4, var14, var20, var31);
//     var32.setShapeVisible(false);
//     java.awt.Shape var35 = var32.getLine();
//     org.jfree.chart.renderer.RenderAttributes var36 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var38 = var36.getSeriesPaint(100);
//     java.awt.Paint var40 = var36.getSeriesFillPaint(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var41.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var45 = var41.getUseSeriesOffset();
//     java.awt.Paint var46 = var41.getBaseOutlinePaint();
//     java.awt.Shape var47 = var41.getBaseShape();
//     var36.setDefaultShape(var47);
//     org.jfree.data.category.DefaultCategoryDataset var49 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var51 = var49.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var52 = null;
//     org.jfree.chart.axis.ValueAxis var53 = null;
//     org.jfree.chart.renderer.category.BarRenderer var54 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var55 = var54.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var56 = var54.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var57 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var49, var52, var53, (org.jfree.chart.renderer.category.CategoryItemRenderer)var54);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var58.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var62 = var58.getLegendItems();
//     java.lang.Object var63 = var62.clone();
//     var57.setFixedLegendItems(var62);
//     org.jfree.chart.entity.PlotEntity var66 = new org.jfree.chart.entity.PlotEntity(var47, (org.jfree.chart.plot.Plot)var57, "");
//     org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var68 = var67.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var69 = var67.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var70 = var67.getBaseItemLabelGenerator();
//     var67.setShadowYOffset(0.2d);
//     boolean var73 = var66.equals((java.lang.Object)var67);
//     java.lang.String var74 = var66.toString();
//     java.lang.Object var75 = var66.clone();
//     java.awt.Shape var76 = var66.getArea();
//     java.awt.Shape var77 = var66.getArea();
//     var32.setLine(var77);
//     
//     // Checks the contract:  equals-hashcode on var22 and var41
//     assertTrue("Contract failed: equals-hashcode on var22 and var41", var22.equals(var41) ? var22.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var58
//     assertTrue("Contract failed: equals-hashcode on var22 and var58", var22.equals(var58) ? var22.hashCode() == var58.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var41.", var22.equals(var41) == var41.equals(var22));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var22 and var58.", var22.equals(var58) == var58.equals(var22));
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test49"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var3 = var1.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = null;
    var1.setLegendItemURLGenerator(var4);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var1.setBaseURLGenerator(var6, false);
    var1.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var11.setSeriesToolTipGenerator(0, var13, true);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getBasePositiveItemLabelPosition();
    java.awt.Paint var17 = var11.getBaseFillPaint();
    var1.setBaseOutlinePaint(var17, false);
    boolean var20 = var1.getUseFillPaint();
    java.awt.Font var21 = var1.getBaseItemLabelFont();
    var0.setTickLabelFont(var21);
    boolean var23 = var0.isVisible();
    var0.setTickMarkInsideLength(10.0f);
    java.awt.Font var26 = var0.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test50"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var9.getBaseItemLabelGenerator();
    var9.setShadowYOffset(0.2d);
    var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var9, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var19 = var17.getSeriesStroke(0);
    boolean var20 = var17.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var22 = var17.lookupSeriesFillPaint(10);
    var8.setDomainCrosshairPaint(var22);
    java.awt.Graphics2D var24 = null;
    java.awt.geom.Rectangle2D var25 = null;
    var8.drawBackgroundImage(var24, var25);
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    double var28 = var27.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var29 = var27.getPositiveItemLabelPositionFallback();
    var27.setShadowXOffset(10.0d);
    org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
    int var34 = var32.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var35 = new org.jfree.data.general.DatasetGroup();
    var32.setGroup(var35);
    org.jfree.data.Range var38 = var27.findRangeBounds((org.jfree.data.category.CategoryDataset)var32, false);
    var32.fireSelectionEvent();
    int var40 = var8.indexOf((org.jfree.data.category.CategoryDataset)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test51"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    boolean var12 = var0.getItemShapeFilled((-1), 100);
    java.awt.Paint var16 = var0.getItemFillPaint(100, 0, true);
    java.awt.Paint var18 = var0.lookupSeriesPaint((-1));
    org.jfree.chart.JFreeChart var19 = null;
    org.jfree.chart.event.ChartChangeEventType var20 = null;
    org.jfree.chart.event.ChartChangeEvent var21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var19, var20);
    java.awt.Paint var23 = var0.lookupSeriesFillPaint((-16777216));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test52"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    java.lang.String var6 = var0.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var16.getBaseItemLabelGenerator();
    var16.setShadowYOffset(0.2d);
    var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var26 = var24.getSeriesStroke(0);
    boolean var27 = var24.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var29 = var24.lookupSeriesFillPaint(10);
    var15.setDomainCrosshairPaint(var29);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    double var32 = var0.getCategoryMargin();
    var0.setTickMarkOutsideLength((-1.0f));
    boolean var35 = var0.isVisible();
    boolean var36 = var0.isTickMarksVisible();
    var0.clearCategoryLabelToolTips();
    java.awt.Paint var38 = var0.getAxisLinePaint();
    java.lang.String var39 = var0.getLabelURL();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test53"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var4 = var2.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var5 = null;
    var2.setLegendItemURLGenerator(var5);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setBaseURLGenerator(var7, false);
    var2.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var12.setSeriesToolTipGenerator(0, var14, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var12.getBasePositiveItemLabelPosition();
    java.awt.Paint var18 = var12.getBaseFillPaint();
    var2.setBaseOutlinePaint(var18, false);
    boolean var21 = var2.getUseFillPaint();
    java.awt.Font var22 = var2.getBaseItemLabelFont();
    var1.setTickLabelFont(var22);
    var1.setCategoryMargin(1.0d);
    java.lang.String var26 = var1.getLabelURL();
    org.jfree.chart.util.DefaultShadowGenerator var27 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var28 = var27.getShadowColor();
    java.awt.Color var29 = var28.brighter();
    var1.setAxisLinePaint((java.awt.Paint)var29);
    float[] var34 = null;
    float[] var35 = java.awt.Color.RGBtoHSB(0, 2, 15, var34);
    float[] var36 = var29.getComponents(var34);
    java.awt.Color var37 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE12", var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test54"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var14 = var12.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = null;
    var12.setLegendItemURLGenerator(var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    java.lang.Boolean var21 = var12.getSeriesVisibleInLegend((-1));
    boolean var24 = var12.getItemShapeFilled((-1), 100);
    java.awt.Shape var29 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = null;
    var30.setLegendItemURLGenerator(var33);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var30.setBaseURLGenerator(var35, false);
    var30.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var40.setSeriesToolTipGenerator(0, var42, true);
    org.jfree.chart.labels.ItemLabelPosition var45 = var40.getBasePositiveItemLabelPosition();
    java.awt.Paint var46 = var40.getBaseFillPaint();
    var30.setBaseOutlinePaint(var46, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var29, var46);
    var12.setBaseOutlinePaint(var46, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var54 = var52.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = null;
    var52.setLegendItemURLGenerator(var55);
    org.jfree.chart.urls.CategoryURLGenerator var57 = null;
    var52.setBaseURLGenerator(var57, false);
    java.lang.Boolean var61 = var52.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var65 = var52.getItemStroke(10, 1, false);
    var12.setBaseStroke(var65, false);
    var8.setDomainCrosshairStroke(var65);
    double var69 = var8.getRangeCrosshairValue();
    java.awt.Graphics2D var70 = null;
    java.awt.geom.Rectangle2D var71 = null;
    org.jfree.chart.plot.PlotRenderingInfo var73 = null;
    org.jfree.chart.plot.CategoryCrosshairState var74 = null;
    boolean var75 = var8.render(var70, var71, 3, var73, var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test55"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    var0.setMaximumBarWidth(0.0d);
    double var6 = var0.getItemLabelAnchorOffset();
    java.awt.Font var7 = var0.getBaseLegendTextFont();
    var0.setAutoPopulateSeriesOutlineStroke(true);
    boolean var11 = var0.isSeriesVisibleInLegend(0);
    boolean var12 = var0.getAutoPopulateSeriesOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test56"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    boolean var18 = var8.isDomainZoomable();
    org.jfree.chart.util.ShadowGenerator var19 = var8.getShadowGenerator();
    org.jfree.chart.axis.ValueAxis var21 = var8.getRangeAxis((-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test57"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
    java.util.EventListener var10 = null;
    boolean var11 = var0.hasListener(var10);
    var0.setSeriesVisibleInLegend(100, (java.lang.Boolean)true);
    var0.setAutoPopulateSeriesFillPaint(false);
    int var17 = var0.getPassCount();
    java.awt.Paint var19 = var0.getSeriesOutlinePaint((-1));
    org.jfree.chart.ChartColor var24 = new org.jfree.chart.ChartColor(2, 1, 2);
    int var25 = var24.getTransparency();
    int var26 = var24.getGreen();
    java.awt.color.ColorSpace var27 = var24.getColorSpace();
    var0.setSeriesItemLabelPaint(1, (java.awt.Paint)var24, false);
    boolean var30 = var0.getAutoPopulateSeriesOutlineStroke();
    var0.clearSeriesPaints(true);
    org.jfree.data.category.DefaultCategoryDataset var34 = new org.jfree.data.category.DefaultCategoryDataset();
    int var36 = var34.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    double var40 = var39.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var41 = var39.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, var37, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var43.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var47 = var43.getLegendItems();
    java.lang.Object var48 = var47.clone();
    var42.setFixedLegendItems(var47);
    org.jfree.chart.plot.Plot var50 = var42.getParent();
    boolean var51 = var42.isRangeMinorGridlinesVisible();
    var42.setDomainGridlinesVisible(false);
    java.awt.Stroke var54 = var42.getDomainGridlineStroke();
    var0.setSeriesStroke(100, var54);
    org.jfree.chart.urls.CategoryURLGenerator var56 = var0.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test58"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    var1.setDefaultCreateEntity((java.lang.Boolean)true);
    java.awt.Paint var5 = var1.getSeriesPaint(4);
    java.awt.Shape var7 = var1.getSeriesShape((-16056321));
    org.jfree.data.category.DefaultCategoryDataset var9 = new org.jfree.data.category.DefaultCategoryDataset();
    int var11 = var9.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var12 = null;
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    double var15 = var14.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var16 = var14.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var9, var12, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.util.Layer var19 = null;
    java.util.Collection var20 = var17.getRangeMarkers(0, var19);
    var17.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var24 = null;
    var17.setDomainAxis(2, var24, true);
    java.awt.Paint var27 = var17.getDomainCrosshairPaint();
    org.jfree.chart.ChartColor var31 = new org.jfree.chart.ChartColor(2, 100, 1);
    int var32 = var31.getRGB();
    java.awt.Color var33 = var31.brighter();
    var17.setBackgroundPaint((java.awt.Paint)var33);
    var1.setSeriesFillPaint(10, (java.awt.Paint)var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-16620543));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test59"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
    var0.setGroup(var3);
    int var6 = var0.getRowIndex((java.lang.Comparable)(short)100);
    var0.validateObject();
    java.util.List var8 = var0.getRowKeys();
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getPositiveItemLabelPositionFallback();
    int var12 = var9.getPassCount();
    boolean var14 = var9.equals((java.lang.Object)"");
    var9.setBaseSeriesVisibleInLegend(true);
    var9.setBase(0.2d);
    boolean var19 = var9.getShadowsVisible();
    org.jfree.chart.renderer.RenderAttributes var20 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var22 = var20.getSeriesPaint(100);
    java.awt.Paint var24 = var20.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var25.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var29 = var25.getUseSeriesOffset();
    java.awt.Paint var30 = var25.getBaseOutlinePaint();
    java.awt.Shape var31 = var25.getBaseShape();
    var20.setDefaultShape(var31);
    org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
    int var35 = var33.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var40 = var38.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var36, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var42.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var46 = var42.getLegendItems();
    java.lang.Object var47 = var46.clone();
    var41.setFixedLegendItems(var46);
    org.jfree.chart.entity.PlotEntity var50 = new org.jfree.chart.entity.PlotEntity(var31, (org.jfree.chart.plot.Plot)var41, "");
    var41.clearAnnotations();
    var9.setPlot(var41);
    org.jfree.chart.plot.PlotRenderingInfo var54 = null;
    java.awt.geom.Point2D var55 = null;
    var41.zoomRangeAxes(10.0d, var54, var55);
    var41.clearRangeMarkers();
    var41.setRangeCrosshairValue(0.05d, false);
    var41.setBackgroundImageAlignment(0);
    var0.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var41);
    var0.setValue(6.250000000000001d, (java.lang.Comparable)(-15466498), (java.lang.Comparable)(-123));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test60"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    java.awt.Paint var9 = var0.getItemOutlinePaint(100, 1, true);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.notifyListeners(var10);
    boolean var15 = var0.isItemLabelVisible(0, 2, false);
    org.jfree.chart.ChartColor var19 = new org.jfree.chart.ChartColor(2, 1, 2);
    var0.setBaseOutlinePaint((java.awt.Paint)var19, false);
    var0.setSeriesLinesVisible(10, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test61"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    int var6 = var4.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var7 = new org.jfree.data.general.DatasetGroup();
    var4.setGroup(var7);
    org.jfree.data.Range var9 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    boolean var12 = var0.getItemShapeFilled(255, 100);
    boolean var13 = var0.getBaseItemLabelsVisible();
    org.jfree.data.category.DefaultCategoryDataset var14 = new org.jfree.data.category.DefaultCategoryDataset();
    int var16 = var14.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.Range var17 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-16580609), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test62"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var0.setSeriesURLGenerator(1, var11, true);
    boolean var14 = var0.getBaseLinesVisible();
    boolean var16 = var0.isSeriesItemLabelsVisible(2);
    var0.setAutoPopulateSeriesOutlinePaint(false);
    java.awt.Graphics2D var19 = null;
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    double var26 = var25.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var27 = var25.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var23, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    float var29 = var28.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var30 = new org.jfree.data.category.DefaultCategoryDataset();
    int var32 = var30.getColumnIndex((java.lang.Comparable)(byte)1);
    int var33 = var28.indexOf((org.jfree.data.category.CategoryDataset)var30);
    java.awt.Stroke var34 = var28.getRangeMinorGridlineStroke();
    org.jfree.chart.event.PlotChangeListener var35 = null;
    var28.addChangeListener(var35);
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.plot.Marker var38 = null;
    java.awt.geom.Rectangle2D var39 = null;
    var0.drawRangeMarker(var19, var28, var37, var38, var39);
    org.jfree.chart.axis.ValueAxis var41 = null;
    org.jfree.chart.axis.ValueAxis[] var42 = new org.jfree.chart.axis.ValueAxis[] { var41};
    var28.setRangeAxes(var42);
    org.jfree.chart.renderer.category.CategoryItemRenderer var45 = var28.getRenderer(5);
    java.awt.Image var46 = null;
    var28.setBackgroundImage(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test63"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    java.util.List var12 = var8.getAnnotations();
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    int var16 = var13.getRowCount();
    java.util.List var17 = var13.getColumnKeys();
    var13.clear();
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var8.getRendererForDataset((org.jfree.data.category.CategoryDataset)var13);
    boolean var20 = var8.isRangePannable();
    org.jfree.chart.axis.AxisLocation var21 = var8.getDomainAxisLocation();
    boolean var22 = var8.isRangeGridlinesVisible();
    boolean var23 = var8.isRangeZoomable();
    var8.clearDomainMarkers(1);
    boolean var26 = var8.isDomainGridlinesVisible();
    org.jfree.chart.axis.AxisLocation var27 = var8.getRangeAxisLocation();
    var8.setRangeGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test64"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    int var2 = var0.getItemCount();
    java.lang.Object var3 = var0.clone();
    java.lang.Object var4 = var0.clone();
    int var5 = var0.getItemCount();
    org.jfree.data.category.DefaultCategoryDataset var6 = new org.jfree.data.category.DefaultCategoryDataset();
    int var8 = var6.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    double var12 = var11.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var13 = var11.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var14 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var6, var9, var10, (org.jfree.chart.renderer.category.CategoryItemRenderer)var11);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var17 = var15.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var18 = var15.getBaseItemLabelGenerator();
    var15.setShadowYOffset(0.2d);
    var14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var15, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var25 = var23.getSeriesStroke(0);
    boolean var26 = var23.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var28 = var23.lookupSeriesFillPaint(10);
    var14.setDomainCrosshairPaint(var28);
    int var30 = var14.getRendererCount();
    java.awt.Graphics2D var31 = null;
    java.awt.geom.Rectangle2D var32 = null;
    var14.drawBackgroundImage(var31, var32);
    org.jfree.data.category.DefaultCategoryDataset var34 = new org.jfree.data.category.DefaultCategoryDataset();
    int var36 = var34.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    double var40 = var39.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var41 = var39.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, var37, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var42.getRangeMarkers(0, var44);
    float var46 = var42.getBackgroundImageAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var48 = null;
    var42.setRenderer(100, var48);
    org.jfree.chart.event.PlotChangeListener var50 = null;
    var42.removeChangeListener(var50);
    org.jfree.chart.util.SortOrder var52 = var42.getRowRenderingOrder();
    var14.setRowRenderingOrder(var52);
    var0.sortByKeys(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test65"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(0);
    java.lang.Object var4 = var0.get((-97));
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var6 = var5.getAxisLinePaint();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var8 = var7.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var9 = var7.getLabelInsets();
    var5.setLabelInsets(var9);
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers((-1), var21);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var25 = var23.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var26 = null;
    var23.setLegendItemURLGenerator(var26);
    org.jfree.chart.urls.CategoryURLGenerator var28 = null;
    var23.setBaseURLGenerator(var28, false);
    java.lang.Boolean var32 = var23.getSeriesVisibleInLegend((-1));
    boolean var35 = var23.getItemShapeFilled((-1), 100);
    java.awt.Shape var40 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var43 = var41.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var44 = null;
    var41.setLegendItemURLGenerator(var44);
    org.jfree.chart.urls.CategoryURLGenerator var46 = null;
    var41.setBaseURLGenerator(var46, false);
    var41.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var53 = null;
    var51.setSeriesToolTipGenerator(0, var53, true);
    org.jfree.chart.labels.ItemLabelPosition var56 = var51.getBasePositiveItemLabelPosition();
    java.awt.Paint var57 = var51.getBaseFillPaint();
    var41.setBaseOutlinePaint(var57, false);
    org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var40, var57);
    var23.setBaseOutlinePaint(var57, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var65 = var63.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var66 = null;
    var63.setLegendItemURLGenerator(var66);
    org.jfree.chart.urls.CategoryURLGenerator var68 = null;
    var63.setBaseURLGenerator(var68, false);
    java.lang.Boolean var72 = var63.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var76 = var63.getItemStroke(10, 1, false);
    var23.setBaseStroke(var76, false);
    var19.setDomainCrosshairStroke(var76);
    var5.setAxisLineStroke(var76);
    boolean var81 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == false);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test66"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    java.awt.geom.Point2D var20 = null;
    var8.zoomDomainAxes(0.0d, var19, var20, false);
    var8.setWeight(0);
    org.jfree.chart.plot.Marker var25 = null;
    org.jfree.chart.util.Layer var26 = null;
    boolean var27 = var8.removeDomainMarker(var25, var26);
    org.jfree.chart.util.PaintList var28 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    boolean var33 = var30.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var35 = var30.lookupSeriesFillPaint(10);
    var28.setPaint(100, var35);
    var8.setOutlinePaint(var35);
    var8.setDomainCrosshairColumnKey((java.lang.Comparable)10L);
    var8.setNotify(false);
    org.jfree.chart.LegendItemCollection var42 = var8.getLegendItems();
    int var43 = var8.getRendererCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);

  }

  public void test67() {}
//   public void test67() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test67"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var2 = var0.getSeriesPaint(100);
//     java.awt.Stroke var3 = var0.getDefaultOutlineStroke();
//     java.lang.Boolean var5 = var0.getSeriesLabelVisible(0);
// 
//   }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test68"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    java.awt.Stroke var14 = var8.getRangeMinorGridlineStroke();
    org.jfree.chart.util.RectangleEdge var16 = var8.getDomainAxisEdge(3);
    var8.clearDomainAxes();
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis();
    float var19 = var18.getMinorTickMarkOutsideLength();
    double var20 = var18.getLowerMargin();
    org.jfree.chart.util.RectangleInsets var21 = var18.getTickLabelInsets();
    org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var25 = null;
    org.jfree.chart.util.RectangleEdge var26 = null;
    double var27 = var22.getCategoryEnd(2, 0, var25, var26);
    java.lang.String var28 = var22.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var29 = new org.jfree.data.category.DefaultCategoryDataset();
    int var31 = var29.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    double var35 = var34.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var36 = var34.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, var32, var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var40 = var38.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var41 = var38.getBaseItemLabelGenerator();
    var38.setShadowYOffset(0.2d);
    var37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var38, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var48 = var46.getSeriesStroke(0);
    boolean var49 = var46.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var51 = var46.lookupSeriesFillPaint(10);
    var37.setDomainCrosshairPaint(var51);
    var22.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
    double var54 = var22.getCategoryMargin();
    java.lang.String var55 = var22.getLabel();
    org.jfree.chart.util.RectangleInsets var56 = var22.getTickLabelInsets();
    double var58 = var56.calculateTopInset(6.2d);
    double var59 = var56.getLeft();
    var18.setLabelInsets(var56, true);
    double var62 = var56.getLeft();
    var8.setInsets(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 4.0d);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test69"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var11 = var0.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
    var12.setSeriesToolTipGenerator(0, var14, true);
    org.jfree.chart.labels.ItemLabelPosition var17 = var12.getBasePositiveItemLabelPosition();
    var0.setBasePositiveItemLabelPosition(var17);
    var0.setBaseItemLabelsVisible(false, true);
    java.awt.Shape var26 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var29 = var27.getSeriesStroke(0);
    boolean var30 = var27.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var32 = var27.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var26, var32);
    var33.setSeriesKey((java.lang.Comparable)true);
    var33.setLineVisible(false);
    java.lang.Object var38 = var33.clone();
    java.lang.String var39 = var33.getToolTipText();
    org.jfree.chart.util.StandardGradientPaintTransformer var40 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var41 = var40.getType();
    java.lang.Object var42 = var40.clone();
    var33.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var40);
    java.lang.String var44 = var33.getDescription();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var47 = var45.getSeriesStroke(0);
    boolean var48 = var45.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var50 = var45.lookupSeriesFillPaint(10);
    var33.setFillPaint(var50);
    var0.setBaseOutlinePaint(var50, false);
    org.jfree.chart.labels.CategoryToolTipGenerator var54 = null;
    var0.setBaseToolTipGenerator(var54);
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    double var57 = var56.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var58 = var56.getPositiveItemLabelPositionFallback();
    var56.setShadowXOffset(10.0d);
    org.jfree.data.category.DefaultCategoryDataset var61 = new org.jfree.data.category.DefaultCategoryDataset();
    int var63 = var61.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var64 = new org.jfree.data.general.DatasetGroup();
    var61.setGroup(var64);
    org.jfree.data.Range var67 = var56.findRangeBounds((org.jfree.data.category.CategoryDataset)var61, false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var68 = var56.getLegendItemLabelGenerator();
    java.awt.Paint var69 = var56.getBasePaint();
    org.jfree.chart.ChartColor var73 = new org.jfree.chart.ChartColor(2, 1, 2);
    float[] var80 = new float[] { (-1.0f), 100.0f, 10.0f};
    float[] var81 = java.awt.Color.RGBtoHSB(1, 10, 0, var80);
    float[] var82 = var73.getRGBColorComponents(var81);
    var56.setBaseFillPaint((java.awt.Paint)var73);
    var0.setBaseItemLabelPaint((java.awt.Paint)var73);
    org.jfree.chart.labels.CategoryItemLabelGenerator var88 = var0.getItemLabelGenerator((-123), 70, true);
    boolean var89 = var0.getBaseLinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + ""+ "'", var39.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "hi!"+ "'", var44.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);

  }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test70"); }
// 
// 
//     org.jfree.data.UnknownKeyException var2 = new org.jfree.data.UnknownKeyException("");
//     java.lang.String var3 = var2.toString();
//     org.jfree.data.KeyedObject var4 = new org.jfree.data.KeyedObject((java.lang.Comparable)1, (java.lang.Object)var2);
//     java.lang.Object var5 = null;
//     var4.setObject(var5);
//     org.jfree.chart.renderer.RenderAttributes var7 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var9 = var7.getSeriesPaint(100);
//     java.awt.Paint var11 = var7.getSeriesPaint(2);
//     boolean var12 = var4.equals((java.lang.Object)var7);
//     java.awt.Shape var14 = var7.getSeriesShape(100);
//     var7.setDefaultLabelVisible((java.lang.Boolean)true);
//     org.jfree.chart.renderer.RenderAttributes var18 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var21 = var18.getItemPaint(0, (-1));
//     java.awt.Paint var23 = var18.getSeriesFillPaint((-1));
//     java.awt.Shape var28 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var31 = var29.getSeriesStroke(0);
//     boolean var32 = var29.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var34 = var29.lookupSeriesFillPaint(10);
//     org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var28, var34);
//     var18.setDefaultOutlinePaint(var34);
//     org.jfree.chart.renderer.RenderAttributes var38 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var41 = var38.getItemPaint(0, (-1));
//     java.awt.Paint var42 = var38.getDefaultLabelPaint();
//     java.awt.Stroke var43 = var38.getDefaultOutlineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var47 = null;
//     var45.setSeriesToolTipGenerator(0, var47, true);
//     org.jfree.chart.labels.ItemLabelPosition var50 = var45.getBasePositiveItemLabelPosition();
//     java.awt.Paint var51 = var45.getBaseFillPaint();
//     boolean var52 = var45.getBaseSeriesVisibleInLegend();
//     var45.setSeriesShapesFilled(0, true);
//     boolean var56 = var45.getAutoPopulateSeriesShape();
//     boolean var57 = var45.getAutoPopulateSeriesShape();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var60 = var58.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var61 = null;
//     var58.setLegendItemURLGenerator(var61);
//     org.jfree.chart.urls.CategoryURLGenerator var63 = null;
//     var58.setBaseURLGenerator(var63, false);
//     java.lang.Boolean var67 = var58.getSeriesVisibleInLegend((-1));
//     boolean var70 = var58.getItemShapeFilled((-1), 100);
//     java.awt.Paint var74 = var58.getItemFillPaint(100, 0, true);
//     java.awt.Paint var76 = var58.lookupSeriesPaint((-1));
//     var45.setBaseOutlinePaint(var76, false);
//     var38.setSeriesOutlinePaint(10, var76);
//     var18.setSeriesFillPaint(0, var76);
//     var7.setSeriesLabelPaint(1, var76);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test71"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var3 = var0.getItemPaint(0, (-1));
    java.awt.Paint var4 = var0.getDefaultLabelPaint();
    java.awt.Paint var6 = var0.getSeriesPaint(10);
    java.awt.Paint var7 = var0.getDefaultFillPaint();
    java.awt.Paint var8 = var0.getDefaultPaint();
    java.awt.Shape var13 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var16 = var14.getSeriesStroke(0);
    boolean var17 = var14.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var19 = var14.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var13, var19);
    var20.setSeriesKey((java.lang.Comparable)true);
    var20.setLineVisible(false);
    java.lang.Object var25 = var20.clone();
    int var26 = var20.getSeriesIndex();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var29 = var27.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var30 = null;
    var27.setLegendItemURLGenerator(var30);
    org.jfree.chart.urls.CategoryURLGenerator var32 = null;
    var27.setBaseURLGenerator(var32, false);
    var27.setAutoPopulateSeriesPaint(true);
    java.util.EventListener var37 = null;
    boolean var38 = var27.hasListener(var37);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var41 = var39.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var42 = null;
    var39.setLegendItemURLGenerator(var42);
    org.jfree.chart.urls.CategoryURLGenerator var44 = null;
    var39.setBaseURLGenerator(var44, false);
    java.lang.Boolean var48 = var39.getSeriesVisibleInLegend((-1));
    boolean var51 = var39.getItemShapeFilled((-1), 100);
    java.awt.Shape var56 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var59 = var57.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var60 = null;
    var57.setLegendItemURLGenerator(var60);
    org.jfree.chart.urls.CategoryURLGenerator var62 = null;
    var57.setBaseURLGenerator(var62, false);
    var57.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var69 = null;
    var67.setSeriesToolTipGenerator(0, var69, true);
    org.jfree.chart.labels.ItemLabelPosition var72 = var67.getBasePositiveItemLabelPosition();
    java.awt.Paint var73 = var67.getBaseFillPaint();
    var57.setBaseOutlinePaint(var73, false);
    org.jfree.chart.LegendItem var76 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var56, var73);
    var39.setBaseOutlinePaint(var73, true);
    var27.setBaseFillPaint(var73, true);
    boolean var81 = var27.getBaseShapesFilled();
    boolean var82 = var27.getBaseShapesVisible();
    var27.setBaseItemLabelsVisible(false);
    org.jfree.chart.renderer.category.BarRenderer var85 = new org.jfree.chart.renderer.category.BarRenderer();
    double var86 = var85.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var87 = var85.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var88 = var85.getBaseItemLabelGenerator();
    java.awt.Stroke var90 = var85.lookupSeriesStroke(100);
    var27.setBaseStroke(var90, true);
    var20.setOutlineStroke(var90);
    var0.setDefaultStroke(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test72"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    java.awt.Paint var2 = var0.getPaint(1);
    java.awt.Paint var4 = var0.getPaint((-16645886));
    java.lang.Object var5 = null;
    boolean var6 = var0.equals(var5);
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var16.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var20 = var16.getLegendItems();
    java.lang.Object var21 = var20.clone();
    var15.setFixedLegendItems(var20);
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    java.awt.geom.Point2D var26 = null;
    var15.zoomRangeAxes((-1.0d), 10.0d, var25, var26);
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var15.zoomRangeAxes(0.05d, var29, var30);
    var15.setNotify(true);
    boolean var34 = var0.equals((java.lang.Object)var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);

  }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test73"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var9 = var5.getUseSeriesOffset();
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    java.awt.Shape var11 = var5.getBaseShape();
    var0.setDefaultShape(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
    java.lang.Object var27 = var26.clone();
    var21.setFixedLegendItems(var26);
    org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
    org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
    int var35 = var33.getColumnIndex((java.lang.Comparable)(byte)1);
    int var36 = var33.getRowCount();
    java.util.List var37 = var33.getColumnKeys();
    org.jfree.chart.entity.CategoryItemEntity var40 = new org.jfree.chart.entity.CategoryItemEntity(var11, "org.jfree.chart.ChartColor[r=2,g=1,b=2]", "", (org.jfree.data.category.CategoryDataset)var33, (java.lang.Comparable)(byte)100, (java.lang.Comparable)2);
    var40.setColumnKey((java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=true]");
    java.lang.Comparable var43 = var40.getColumnKey();
    org.jfree.data.category.CategoryDataset var44 = var40.getDataset();
    java.lang.String var45 = var40.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=true]"+ "'", var43.equals("org.jfree.chart.event.ChartChangeEvent[source=true]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test74"); }


    org.jfree.chart.util.DefaultShadowGenerator var0 = new org.jfree.chart.util.DefaultShadowGenerator();
    int var1 = var0.getShadowSize();
    int var2 = var0.getShadowSize();
    int var3 = var0.getDistance();
    int var4 = var0.getShadowSize();
    int var5 = var0.calculateOffsetX();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2));

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test75"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    org.jfree.chart.util.StandardGradientPaintTransformer var5 = new org.jfree.chart.util.StandardGradientPaintTransformer(var1);
    org.jfree.chart.util.StandardGradientPaintTransformer var6 = new org.jfree.chart.util.StandardGradientPaintTransformer(var1);
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    float var8 = var7.getMinorTickMarkOutsideLength();
    double var9 = var7.getLowerMargin();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var13, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var18.getRangeMarkers(0, var20);
    var18.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    var18.setDomainAxis(2, var25, true);
    boolean var28 = var18.isDomainZoomable();
    java.awt.Font var29 = var18.getNoDataMessageFont();
    var7.setLabelFont(var29);
    var7.setTickMarksVisible(false);
    var7.setCategoryLabelPositionOffset(255);
    boolean var35 = var6.equals((java.lang.Object)var7);
    double var36 = var7.getUpperMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var2.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var3.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var4.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.05d);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test76"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    java.util.List var12 = var8.getAnnotations();
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    int var16 = var13.getRowCount();
    java.util.List var17 = var13.getColumnKeys();
    var13.clear();
    org.jfree.chart.renderer.category.CategoryItemRenderer var19 = var8.getRendererForDataset((org.jfree.data.category.CategoryDataset)var13);
    org.jfree.chart.axis.AxisSpace var20 = null;
    var8.setFixedDomainAxisSpace(var20);
    java.awt.Paint var22 = var8.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test77"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var4 = var0.getUseSeriesOffset();
    boolean var5 = var0.getBaseItemLabelsVisible();
    var0.setBaseShapesFilled(true);
    boolean var11 = var0.isItemLabelVisible(100, 10, true);
    java.lang.Boolean var13 = var0.getSeriesItemLabelsVisible((-15466498));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesShapesVisible((-2), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test78"); }


    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes(true);
    var1.setDefaultCreateEntity((java.lang.Boolean)true);
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    int var6 = var4.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var7 = null;
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var11 = var9.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var12 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var4, var7, var8, (org.jfree.chart.renderer.category.CategoryItemRenderer)var9);
    org.jfree.chart.util.Layer var14 = null;
    java.util.Collection var15 = var12.getRangeMarkers((-1), var14);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var18 = var16.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var19 = null;
    var16.setLegendItemURLGenerator(var19);
    org.jfree.chart.urls.CategoryURLGenerator var21 = null;
    var16.setBaseURLGenerator(var21, false);
    java.lang.Boolean var25 = var16.getSeriesVisibleInLegend((-1));
    boolean var28 = var16.getItemShapeFilled((-1), 100);
    java.awt.Shape var33 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var36 = var34.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var37 = null;
    var34.setLegendItemURLGenerator(var37);
    org.jfree.chart.urls.CategoryURLGenerator var39 = null;
    var34.setBaseURLGenerator(var39, false);
    var34.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var46 = null;
    var44.setSeriesToolTipGenerator(0, var46, true);
    org.jfree.chart.labels.ItemLabelPosition var49 = var44.getBasePositiveItemLabelPosition();
    java.awt.Paint var50 = var44.getBaseFillPaint();
    var34.setBaseOutlinePaint(var50, false);
    org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var33, var50);
    var16.setBaseOutlinePaint(var50, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var58 = var56.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var59 = null;
    var56.setLegendItemURLGenerator(var59);
    org.jfree.chart.urls.CategoryURLGenerator var61 = null;
    var56.setBaseURLGenerator(var61, false);
    java.lang.Boolean var65 = var56.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var69 = var56.getItemStroke(10, 1, false);
    var16.setBaseStroke(var69, false);
    var12.setDomainCrosshairStroke(var69);
    org.jfree.chart.plot.PlotRenderingInfo var74 = null;
    java.awt.geom.Point2D var75 = null;
    var12.zoomDomainAxes(0.0d, var74, var75, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var78 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var80 = var78.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var81 = null;
    var78.setLegendItemURLGenerator(var81);
    org.jfree.chart.urls.CategoryURLGenerator var83 = null;
    var78.setBaseURLGenerator(var83, false);
    java.lang.Boolean var87 = var78.getSeriesVisibleInLegend((-1));
    boolean var90 = var78.getItemShapeFilled((-1), 100);
    java.awt.Paint var94 = var78.getItemFillPaint(100, 0, true);
    var12.setRangeGridlinePaint(var94);
    var1.setDefaultFillPaint(var94);
    java.awt.Paint var97 = var1.getDefaultPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var97);

  }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test79"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
    var5.setLegendItemURLGenerator(var8);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    var5.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var15.setSeriesToolTipGenerator(0, var17, true);
    org.jfree.chart.labels.ItemLabelPosition var20 = var15.getBasePositiveItemLabelPosition();
    java.awt.Paint var21 = var15.getBaseFillPaint();
    var5.setBaseOutlinePaint(var21, false);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var4, var21);
    int var25 = var24.getSeriesIndex();
    java.awt.Shape var30 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var33 = var31.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = null;
    var31.setLegendItemURLGenerator(var34);
    var31.setUseSeriesOffset(false);
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var39 = var38.getAxisLinePaint();
    java.awt.Paint var40 = var38.getTickLabelPaint();
    var31.setBaseOutlinePaint(var40);
    org.jfree.chart.renderer.RenderAttributes var42 = new org.jfree.chart.renderer.RenderAttributes();
    org.jfree.chart.renderer.category.BarRenderer var43 = new org.jfree.chart.renderer.category.BarRenderer();
    double var44 = var43.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var45 = var43.getBarPainter();
    java.awt.Stroke var46 = var43.getBaseStroke();
    var42.setDefaultStroke(var46);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var50 = var48.getSeriesStroke(0);
    boolean var51 = var48.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var53 = var48.lookupSeriesFillPaint(10);
    java.awt.Paint var57 = var48.getItemOutlinePaint(100, 1, true);
    org.jfree.chart.LegendItem var58 = new org.jfree.chart.LegendItem("org.jfree.data.UnknownKeyException: ", "hi!", "AxisLocation.BOTTOM_OR_RIGHT", "AxisLocation.BOTTOM_OR_RIGHT", var30, var40, var46, var57);
    var24.setOutlineStroke(var46);
    org.jfree.chart.util.GradientPaintTransformer var60 = var24.getFillPaintTransformer();
    java.awt.Paint var61 = var24.getLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test80"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var14 = var12.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = null;
    var12.setLegendItemURLGenerator(var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    java.lang.Boolean var21 = var12.getSeriesVisibleInLegend((-1));
    boolean var24 = var12.getItemShapeFilled((-1), 100);
    java.awt.Shape var29 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = null;
    var30.setLegendItemURLGenerator(var33);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var30.setBaseURLGenerator(var35, false);
    var30.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var40.setSeriesToolTipGenerator(0, var42, true);
    org.jfree.chart.labels.ItemLabelPosition var45 = var40.getBasePositiveItemLabelPosition();
    java.awt.Paint var46 = var40.getBaseFillPaint();
    var30.setBaseOutlinePaint(var46, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var29, var46);
    var12.setBaseOutlinePaint(var46, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var54 = var52.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = null;
    var52.setLegendItemURLGenerator(var55);
    org.jfree.chart.urls.CategoryURLGenerator var57 = null;
    var52.setBaseURLGenerator(var57, false);
    java.lang.Boolean var61 = var52.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var65 = var52.getItemStroke(10, 1, false);
    var12.setBaseStroke(var65, false);
    var8.setDomainCrosshairStroke(var65);
    org.jfree.chart.plot.PlotRenderingInfo var70 = null;
    java.awt.geom.Point2D var71 = null;
    var8.zoomDomainAxes(0.0d, var70, var71, true);
    var8.setDomainCrosshairRowKey((java.lang.Comparable)0.5f, false);
    var8.clearRangeMarkers(15);
    org.jfree.chart.plot.PlotRenderingInfo var80 = null;
    java.awt.geom.Point2D var81 = null;
    var8.zoomDomainAxes(96.0d, var80, var81, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test81"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
    var5.setLegendItemURLGenerator(var8);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    var5.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var15.setSeriesToolTipGenerator(0, var17, true);
    org.jfree.chart.labels.ItemLabelPosition var20 = var15.getBasePositiveItemLabelPosition();
    java.awt.Paint var21 = var15.getBaseFillPaint();
    var5.setBaseOutlinePaint(var21, false);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var4, var21);
    int var25 = var24.getSeriesIndex();
    boolean var26 = var24.isShapeFilled();
    java.awt.Shape var27 = var24.getLine();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test82() {}
//   public void test82() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test82"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
//     java.lang.Object var14 = var13.clone();
//     var8.setFixedLegendItems(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.data.Range var22 = var8.getDataRange(var21);
//     double var23 = var8.getRangeCrosshairValue();
//     org.jfree.chart.util.RectangleInsets var24 = var8.getAxisOffset();
//     org.jfree.chart.event.PlotChangeListener var25 = null;
//     var8.addChangeListener(var25);
//     int var27 = var8.getCrosshairDatasetIndex();
//     org.jfree.data.category.DefaultCategoryDataset var28 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var30 = var28.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var31 = null;
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var34 = var33.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var35 = var33.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var36 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var28, var31, var32, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
//     org.jfree.chart.axis.AxisSpace var37 = null;
//     var36.setFixedRangeAxisSpace(var37, false);
//     var36.configureDomainAxes();
//     org.jfree.data.category.DefaultCategoryDataset var41 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var43 = var41.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var44 = null;
//     org.jfree.chart.axis.ValueAxis var45 = null;
//     org.jfree.chart.renderer.category.BarRenderer var46 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var47 = var46.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var48 = var46.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var41, var44, var45, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var50.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var54 = var50.getLegendItems();
//     java.lang.Object var55 = var54.clone();
//     var49.setFixedLegendItems(var54);
//     org.jfree.chart.plot.PlotRenderingInfo var59 = null;
//     java.awt.geom.Point2D var60 = null;
//     var49.zoomRangeAxes((-1.0d), 10.0d, var59, var60);
//     org.jfree.chart.axis.AxisLocation var63 = var49.getRangeAxisLocation(1);
//     var36.setDomainAxisLocation(var63, false);
//     org.jfree.chart.axis.AxisLocation var66 = var63.getOpposite();
//     var8.setRangeAxisLocation(var66);
//     
//     // Checks the contract:  equals-hashcode on var8 and var49
//     assertTrue("Contract failed: equals-hashcode on var8 and var49", var8.equals(var49) ? var8.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var8
//     assertTrue("Contract failed: equals-hashcode on var49 and var8", var49.equals(var8) ? var49.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var54
//     assertTrue("Contract failed: equals-hashcode on var13 and var54", var13.equals(var54) ? var13.hashCode() == var54.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var54 and var13
//     assertTrue("Contract failed: equals-hashcode on var54 and var13", var54.equals(var13) ? var54.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var55
//     assertTrue("Contract failed: equals-hashcode on var14 and var55", var14.equals(var55) ? var14.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var14
//     assertTrue("Contract failed: equals-hashcode on var55 and var14", var55.equals(var14) ? var55.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test83"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var19 = var18.getShadowColor();
    var8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var18);
    java.awt.Color var21 = var18.getShadowColor();
    org.jfree.chart.util.ObjectList var22 = new org.jfree.chart.util.ObjectList();
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    double var24 = var23.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getPositiveItemLabelPositionFallback();
    int var26 = var23.getPassCount();
    boolean var28 = var23.equals((java.lang.Object)"");
    int var29 = var22.indexOf((java.lang.Object)var28);
    java.lang.Object var30 = null;
    int var31 = var22.indexOf(var30);
    org.jfree.chart.renderer.RenderAttributes var33 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var36 = var33.getItemPaint(0, (-1));
    java.awt.Paint var37 = var33.getDefaultLabelPaint();
    java.awt.Stroke var38 = var33.getDefaultOutlineStroke();
    java.awt.Stroke var40 = var33.getSeriesStroke((-16777216));
    var22.set(100, (java.lang.Object)var33);
    org.jfree.data.category.DefaultCategoryDataset var42 = new org.jfree.data.category.DefaultCategoryDataset();
    int var44 = var42.getColumnIndex((java.lang.Comparable)(byte)1);
    int var45 = var42.getRowCount();
    java.util.List var46 = var42.getColumnKeys();
    var42.clear();
    int var48 = var22.indexOf((java.lang.Object)var42);
    var42.fireSelectionEvent();
    boolean var50 = var18.equals((java.lang.Object)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test84"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var9 = var5.getUseSeriesOffset();
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    java.awt.Shape var11 = var5.getBaseShape();
    var0.setDefaultShape(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
    java.lang.Object var27 = var26.clone();
    var21.setFixedLegendItems(var26);
    org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
    org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
    int var35 = var33.getColumnIndex((java.lang.Comparable)(byte)1);
    int var36 = var33.getRowCount();
    java.util.List var37 = var33.getColumnKeys();
    org.jfree.chart.entity.CategoryItemEntity var40 = new org.jfree.chart.entity.CategoryItemEntity(var11, "org.jfree.chart.ChartColor[r=2,g=1,b=2]", "", (org.jfree.data.category.CategoryDataset)var33, (java.lang.Comparable)(byte)100, (java.lang.Comparable)2);
    org.jfree.data.category.CategoryDataset var41 = var40.getDataset();
    java.lang.Comparable var42 = var40.getRowKey();
    org.jfree.data.category.CategoryDataset var43 = var40.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + (byte)100+ "'", var42.equals((byte)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test85"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesFillPaint(0);
    java.lang.Boolean var3 = var0.getDefaultLabelVisible();
    java.awt.Paint var4 = var0.getDefaultOutlinePaint();
    java.lang.Boolean var5 = var0.getDefaultCreateEntity();
    java.awt.Paint var7 = var0.getSeriesOutlinePaint(0);
    java.lang.Boolean var8 = var0.getDefaultLabelVisible();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.awt.Paint var15 = var9.lookupSeriesPaint(2);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var16.getBaseItemLabelGenerator();
    var16.setMaximumBarWidth(0.0d);
    double var22 = var16.getItemLabelAnchorOffset();
    org.jfree.chart.util.GradientPaintTransformer var23 = var16.getGradientPaintTransformer();
    org.jfree.chart.annotations.CategoryAnnotation var24 = null;
    boolean var25 = var16.removeAnnotation(var24);
    org.jfree.data.category.DefaultCategoryDataset var26 = new org.jfree.data.category.DefaultCategoryDataset();
    int var28 = var26.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    double var32 = var31.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var33 = var31.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var29, var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var34.getRangeMarkers(0, var36);
    var34.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var41 = null;
    var34.setDomainAxis(2, var41, true);
    boolean var44 = var34.isDomainZoomable();
    java.awt.Font var45 = var34.getNoDataMessageFont();
    var16.setBaseLegendTextFont(var45);
    var9.setBaseItemLabelFont(var45, true);
    var0.setDefaultLabelFont(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test86"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    java.lang.Comparable var21 = var8.getDomainCrosshairColumnKey();
    org.jfree.chart.plot.Marker var23 = null;
    org.jfree.chart.util.Layer var24 = null;
    boolean var25 = var8.removeDomainMarker(100, var23, var24);
    int var26 = var8.getCrosshairDatasetIndex();
    org.jfree.chart.axis.CategoryAxis var28 = var8.getDomainAxisForDataset(1);
    var8.clearDomainMarkers(0);
    boolean var31 = var8.isRangeGridlinesVisible();
    org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.util.RectangleEdge var37 = null;
    double var38 = var33.getCategoryEnd(2, 0, var36, var37);
    org.jfree.data.category.DefaultCategoryDataset var39 = new org.jfree.data.category.DefaultCategoryDataset();
    int var41 = var39.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.BarRenderer var44 = new org.jfree.chart.renderer.category.BarRenderer();
    double var45 = var44.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var46 = var44.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var39, var42, var43, (org.jfree.chart.renderer.category.CategoryItemRenderer)var44);
    org.jfree.chart.util.Layer var49 = null;
    java.util.Collection var50 = var47.getRangeMarkers(0, var49);
    var47.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var54 = null;
    var47.setDomainAxis(2, var54, true);
    org.jfree.chart.plot.PlotRenderingInfo var58 = null;
    java.awt.geom.Point2D var59 = null;
    var47.zoomDomainAxes(0.0d, var58, var59, false);
    var33.setPlot((org.jfree.chart.plot.Plot)var47);
    java.awt.Paint var63 = var33.getTickLabelPaint();
    double var64 = var33.getUpperMargin();
    var8.setDomainAxis(5, var33);
    int var66 = var8.getDatasetCount();
    org.jfree.chart.plot.Marker var67 = null;
    org.jfree.chart.util.Layer var68 = null;
    boolean var69 = var8.removeDomainMarker(var67, var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test87"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var3 = var1.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = null;
    var1.setLegendItemURLGenerator(var4);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var1.setBaseURLGenerator(var6, false);
    var1.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var11.setSeriesToolTipGenerator(0, var13, true);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getBasePositiveItemLabelPosition();
    java.awt.Paint var17 = var11.getBaseFillPaint();
    var1.setBaseOutlinePaint(var17, false);
    boolean var20 = var1.getUseFillPaint();
    java.awt.Font var21 = var1.getBaseItemLabelFont();
    var0.setTickLabelFont(var21);
    var0.setCategoryMargin(1.0d);
    java.lang.String var25 = var0.getLabelURL();
    org.jfree.data.category.DefaultCategoryDataset var26 = new org.jfree.data.category.DefaultCategoryDataset();
    int var28 = var26.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    double var32 = var31.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var33 = var31.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var29, var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var34.getRangeMarkers(0, var36);
    var34.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var41 = null;
    var34.setDomainAxis(2, var41, true);
    boolean var44 = var34.isDomainZoomable();
    var34.clearRangeMarkers(1);
    org.jfree.chart.axis.CategoryAxis var47 = var34.getDomainAxis();
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var51 = null;
    org.jfree.chart.util.RectangleEdge var52 = null;
    double var53 = var48.getCategoryEnd(2, 0, var51, var52);
    java.lang.String var54 = var48.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var55 = new org.jfree.data.category.DefaultCategoryDataset();
    int var57 = var55.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var58 = null;
    org.jfree.chart.axis.ValueAxis var59 = null;
    org.jfree.chart.renderer.category.BarRenderer var60 = new org.jfree.chart.renderer.category.BarRenderer();
    double var61 = var60.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var62 = var60.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var55, var58, var59, (org.jfree.chart.renderer.category.CategoryItemRenderer)var60);
    org.jfree.chart.renderer.category.BarRenderer var64 = new org.jfree.chart.renderer.category.BarRenderer();
    double var65 = var64.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var66 = var64.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var67 = var64.getBaseItemLabelGenerator();
    var64.setShadowYOffset(0.2d);
    var63.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var64, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var72 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var74 = var72.getSeriesStroke(0);
    boolean var75 = var72.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var77 = var72.lookupSeriesFillPaint(10);
    var63.setDomainCrosshairPaint(var77);
    var48.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var63);
    double var80 = var48.getCategoryMargin();
    java.lang.String var81 = var48.getLabel();
    org.jfree.chart.util.RectangleInsets var82 = var48.getTickLabelInsets();
    double var84 = var82.calculateLeftOutset(0.2d);
    double var86 = var82.calculateRightOutset(10.0d);
    double var87 = var82.getTop();
    var34.setInsets(var82, false);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var34);
    java.awt.Paint var91 = var0.getAxisLinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test88"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var4 = var0.getUseSeriesOffset();
    var0.setSeriesShapesFilled(1, (java.lang.Boolean)false);
    java.lang.Boolean var9 = var0.getSeriesVisible(1);
    org.jfree.chart.annotations.CategoryAnnotation var10 = null;
    boolean var11 = var0.removeAnnotation(var10);
    org.jfree.chart.renderer.RenderAttributes var12 = var0.getSelectedItemAttributes();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var13.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var17 = var13.getUseSeriesOffset();
    java.awt.Paint var18 = var13.getBaseOutlinePaint();
    java.awt.Shape var19 = var13.getBaseShape();
    org.jfree.chart.entity.ChartEntity var21 = new org.jfree.chart.entity.ChartEntity(var19, "hi!");
    var21.setToolTipText("org.jfree.data.UnknownKeyException: ");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var24.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var28 = var24.getUseSeriesOffset();
    java.awt.Paint var29 = var24.getBaseOutlinePaint();
    java.awt.Shape var30 = var24.getBaseShape();
    org.jfree.chart.entity.ChartEntity var32 = new org.jfree.chart.entity.ChartEntity(var30, "hi!");
    var21.setArea(var30);
    var0.setBaseLegendShape(var30);
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test89"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var9.getBaseItemLabelGenerator();
    var9.setShadowYOffset(0.2d);
    var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var9, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var19 = var17.getSeriesStroke(0);
    boolean var20 = var17.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var22 = var17.lookupSeriesFillPaint(10);
    var8.setDomainCrosshairPaint(var22);
    int var24 = var8.getRendererCount();
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var8.drawBackgroundImage(var25, var26);
    org.jfree.chart.axis.AxisSpace var28 = var8.getFixedDomainAxisSpace();
    int var29 = var8.getRendererCount();
    boolean var30 = var8.isRangeMinorGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test90"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Paint var6 = var2.getItemOutlinePaint((-16777216), 255, true);
    var2.setSeriesCreateEntities(255, (java.lang.Boolean)false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var2.getBaseItemLabelGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test91"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    int var2 = var0.getItemCount();
    java.lang.Object var3 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var5.getCategoryEnd(2, 0, var8, var9);
    org.jfree.chart.renderer.category.BarRenderer var11 = new org.jfree.chart.renderer.category.BarRenderer();
    double var12 = var11.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var13 = var11.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var11.getBaseItemLabelGenerator();
    var11.setMaximumBarWidth(0.0d);
    java.awt.Paint var18 = var11.getLegendTextPaint(1);
    java.awt.Paint var20 = var11.getLegendTextPaint(100);
    boolean var21 = var5.equals((java.lang.Object)var11);
    org.jfree.data.category.DefaultCategoryDataset var22 = new org.jfree.data.category.DefaultCategoryDataset();
    int var24 = var22.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    org.jfree.chart.axis.ValueAxis var26 = null;
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    double var28 = var27.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var29 = var27.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var30 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var22, var25, var26, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var30.getRangeMarkers((-1), var32);
    var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var30);
    double var35 = var5.getCategoryMargin();
    java.awt.Paint var36 = var5.getAxisLinePaint();
    var0.addObject((java.lang.Comparable)255, (java.lang.Object)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var39 = var0.getKey(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test92"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    java.lang.String var6 = var0.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var16.getBaseItemLabelGenerator();
    var16.setShadowYOffset(0.2d);
    var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var26 = var24.getSeriesStroke(0);
    boolean var27 = var24.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var29 = var24.lookupSeriesFillPaint(10);
    var15.setDomainCrosshairPaint(var29);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    double var32 = var0.getCategoryMargin();
    java.lang.String var33 = var0.getLabel();
    var0.setMinorTickMarkOutsideLength(0.5f);
    var0.setCategoryLabelPositionOffset((-1));
    var0.configure();
    boolean var39 = var0.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test93"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    java.awt.Stroke var14 = var8.getRangeMinorGridlineStroke();
    org.jfree.chart.event.PlotChangeListener var15 = null;
    var8.addChangeListener(var15);
    java.util.List var17 = var8.getCategories();
    java.awt.Shape var22 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var25 = var23.getSeriesStroke(0);
    boolean var26 = var23.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var28 = var23.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var22, var28);
    var29.setSeriesKey((java.lang.Comparable)true);
    var29.setDescription("hi!");
    int var34 = var29.getDatasetIndex();
    var29.setSeriesIndex(2);
    java.awt.Paint var37 = var29.getFillPaint();
    var8.setRangeGridlinePaint(var37);
    java.awt.Stroke var39 = var8.getDomainGridlineStroke();
    java.lang.Comparable var40 = var8.getDomainCrosshairColumnKey();
    org.jfree.chart.axis.ValueAxis var42 = var8.getRangeAxis(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test94"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    var0.setAutoPopulateSeriesPaint(true);
    java.awt.Stroke var11 = null;
    var0.setSeriesOutlineStroke(10, var11, false);
    int var14 = var0.getPassCount();
    org.jfree.chart.labels.ItemLabelPosition var18 = var0.getPositiveItemLabelPosition(2, 10, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var0.getBaseItemLabelGenerator();
    boolean var20 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.plot.CategoryPlot var21 = var0.getPlot();
    var0.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test95"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var2 = var0.getSeriesPaint(100);
//     var0.setDefaultLabelVisible((java.lang.Boolean)true);
//     java.awt.Paint var6 = var0.getSeriesOutlinePaint(100);
//     org.jfree.chart.renderer.category.BarRenderer var7 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var8 = var7.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var9 = var7.getPositiveItemLabelPositionFallback();
//     int var10 = var7.getPassCount();
//     boolean var12 = var7.equals((java.lang.Object)"");
//     var7.setBaseSeriesVisibleInLegend(true);
//     var7.setBase(0.2d);
//     var7.setMaximumBarWidth(0.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var19.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var23 = var19.getUseSeriesOffset();
//     java.awt.Paint var24 = var19.getBaseOutlinePaint();
//     java.awt.Shape var25 = var19.getBaseShape();
//     org.jfree.chart.entity.ChartEntity var27 = new org.jfree.chart.entity.ChartEntity(var25, "hi!");
//     var27.setToolTipText("org.jfree.data.UnknownKeyException: ");
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var30.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var34 = var30.getUseSeriesOffset();
//     java.awt.Paint var35 = var30.getBaseOutlinePaint();
//     java.awt.Shape var36 = var30.getBaseShape();
//     org.jfree.chart.entity.ChartEntity var38 = new org.jfree.chart.entity.ChartEntity(var36, "hi!");
//     var27.setArea(var36);
//     boolean var40 = var7.equals((java.lang.Object)var36);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = null;
//     var7.setBaseItemLabelGenerator(var41, false);
//     org.jfree.data.category.DefaultCategoryDataset var45 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var47 = var45.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var48 = null;
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var51 = var50.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var52 = var50.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var45, var48, var49, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
//     org.jfree.chart.labels.ItemLabelPosition var57 = var50.getPositiveItemLabelPosition(100, 100, true);
//     org.jfree.chart.text.TextAnchor var58 = var57.getRotationAnchor();
//     var7.setSeriesPositiveItemLabelPosition(0, var57, false);
//     org.jfree.data.category.DefaultCategoryDataset var61 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var63 = var61.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var64 = null;
//     org.jfree.chart.axis.ValueAxis var65 = null;
//     org.jfree.chart.renderer.category.BarRenderer var66 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var67 = var66.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var68 = var66.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var69 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var61, var64, var65, (org.jfree.chart.renderer.category.CategoryItemRenderer)var66);
//     org.jfree.chart.util.Layer var71 = null;
//     java.util.Collection var72 = var69.getRangeMarkers(0, var71);
//     var69.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var76 = null;
//     var69.setDomainAxis(2, var76, true);
//     var69.setOutlineVisible(false);
//     org.jfree.chart.event.AnnotationChangeEvent var81 = null;
//     var69.annotationChanged(var81);
//     java.awt.Font var83 = var69.getNoDataMessageFont();
//     boolean var84 = var57.equals((java.lang.Object)var83);
//     var0.setDefaultLabelFont(var83);
//     java.awt.Paint var87 = var0.getSeriesLabelPaint((-16777216));
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test96"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Boolean var2 = var0.getBoolean(10);
    java.lang.Boolean var4 = var0.getBoolean(1);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
    var5.setLegendItemURLGenerator(var8);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var5.setBaseURLGenerator(var10, false);
    java.lang.Boolean var14 = var5.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var16 = null;
    var5.setSeriesURLGenerator(1, var16, true);
    boolean var19 = var5.getBaseLinesVisible();
    boolean var21 = var5.isSeriesItemLabelsVisible(2);
    java.awt.Font var23 = var5.lookupLegendTextFont(1);
    var5.removeAnnotations();
    java.awt.Paint var25 = var5.getBasePaint();
    boolean var26 = var0.equals((java.lang.Object)var5);
    var0.setBoolean(2, (java.lang.Boolean)true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    boolean var33 = var30.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var35 = var30.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var39 = var30.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var41 = var30.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var42.setSeriesToolTipGenerator(0, var44, true);
    org.jfree.chart.labels.ItemLabelPosition var47 = var42.getBasePositiveItemLabelPosition();
    var30.setBasePositiveItemLabelPosition(var47);
    var30.setBaseItemLabelsVisible(false, true);
    java.awt.Shape var56 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var59 = var57.getSeriesStroke(0);
    boolean var60 = var57.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var62 = var57.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var63 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var56, var62);
    var63.setSeriesKey((java.lang.Comparable)true);
    var63.setLineVisible(false);
    java.lang.Object var68 = var63.clone();
    java.lang.String var69 = var63.getToolTipText();
    org.jfree.chart.util.StandardGradientPaintTransformer var70 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var71 = var70.getType();
    java.lang.Object var72 = var70.clone();
    var63.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var70);
    java.lang.String var74 = var63.getDescription();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var75 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var77 = var75.getSeriesStroke(0);
    boolean var78 = var75.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var80 = var75.lookupSeriesFillPaint(10);
    var63.setFillPaint(var80);
    var30.setBaseOutlinePaint(var80, false);
    boolean var84 = var0.equals((java.lang.Object)false);
    java.lang.Boolean var86 = var0.getBoolean((-15466498));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBoolean((-123), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var69 + "' != '" + ""+ "'", var69.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var74 + "' != '" + "hi!"+ "'", var74.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var86);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test97"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
    var0.setGroup(var3);
    int var6 = var0.getRowIndex((java.lang.Comparable)(short)100);
    org.jfree.data.general.DatasetGroup var8 = new org.jfree.data.general.DatasetGroup("rect");
    java.lang.Object var9 = var8.clone();
    var0.setGroup(var8);
    java.lang.Object var11 = null;
    boolean var12 = var0.equals(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var15 = var13.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var16 = null;
    var13.setLegendItemURLGenerator(var16);
    var13.removeAnnotations();
    java.awt.Shape var20 = var13.lookupSeriesShape(15);
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var24 = null;
    org.jfree.chart.util.RectangleEdge var25 = null;
    double var26 = var21.getCategoryEnd(2, 0, var24, var25);
    java.lang.String var27 = var21.getLabel();
    double var28 = var21.getCategoryMargin();
    org.jfree.data.category.DefaultCategoryDataset var29 = new org.jfree.data.category.DefaultCategoryDataset();
    int var31 = var29.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    double var35 = var34.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var36 = var34.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, var32, var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    org.jfree.chart.util.Layer var39 = null;
    java.util.Collection var40 = var37.getRangeMarkers((-1), var39);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var44 = var41.getLegendItem(2, 100);
    java.awt.Stroke var45 = var41.getBaseStroke();
    var37.setRangeCrosshairStroke(var45);
    org.jfree.chart.util.Layer var48 = null;
    java.util.Collection var49 = var37.getRangeMarkers((-97), var48);
    var21.addChangeListener((org.jfree.chart.event.AxisChangeListener)var37);
    org.jfree.chart.entity.PlotEntity var52 = new org.jfree.chart.entity.PlotEntity(var20, (org.jfree.chart.plot.Plot)var37, "AxisLocation.TOP_OR_RIGHT");
    var0.addChangeListener((org.jfree.data.event.DatasetChangeListener)var37);
    org.jfree.chart.LegendItemCollection var54 = var37.getLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test98() {}
//   public void test98() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test98"); }
// 
// 
//     org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
//     java.awt.Paint var2 = var0.getSeriesFillPaint(0);
//     java.lang.Boolean var3 = var0.getDefaultLabelVisible();
//     java.awt.Shape var4 = var0.getDefaultShape();
//     java.awt.Shape var6 = var0.getSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var10 = var8.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var11 = null;
//     var8.setLegendItemURLGenerator(var11);
//     org.jfree.chart.urls.CategoryURLGenerator var13 = null;
//     var8.setBaseURLGenerator(var13, false);
//     java.lang.Boolean var17 = var8.getSeriesVisibleInLegend((-1));
//     org.jfree.chart.urls.CategoryURLGenerator var19 = null;
//     var8.setSeriesURLGenerator(1, var19, true);
//     boolean var22 = var8.getBaseLinesVisible();
//     boolean var24 = var8.isSeriesItemLabelsVisible(2);
//     boolean var25 = var8.getDrawOutlines();
//     org.jfree.chart.axis.CategoryAxis var26 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.util.RectangleEdge var30 = null;
//     double var31 = var26.getCategoryEnd(2, 0, var29, var30);
//     org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var34 = var32.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var35 = null;
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var38 = var37.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var39 = var37.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var32, var35, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
//     org.jfree.chart.util.Layer var42 = null;
//     java.util.Collection var43 = var40.getRangeMarkers(0, var42);
//     var40.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var47 = null;
//     var40.setDomainAxis(2, var47, true);
//     org.jfree.chart.plot.PlotRenderingInfo var51 = null;
//     java.awt.geom.Point2D var52 = null;
//     var40.zoomDomainAxes(0.0d, var51, var52, false);
//     var26.setPlot((org.jfree.chart.plot.Plot)var40);
//     java.awt.Paint var56 = var26.getTickLabelPaint();
//     var8.setBaseOutlinePaint(var56, false);
//     var0.setSeriesLabelPaint((-16777216), var56);
// 
//   }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test99"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    double var5 = var0.getMinimumBarLength();
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var8 = var6.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var8);
    var0.setBarPainter(var8);
    java.awt.Stroke var11 = var0.getBaseStroke();
    double var12 = var0.getBase();
    boolean var13 = var0.getShadowsVisible();
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var25.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var29 = var25.getLegendItems();
    java.lang.Object var30 = var29.clone();
    var24.setFixedLegendItems(var29);
    float var32 = var24.getForegroundAlpha();
    java.lang.Object var33 = null;
    boolean var34 = var24.equals(var33);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var35.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var39 = var35.getLegendItems();
    java.awt.Paint var41 = var35.lookupSeriesPaint(2);
    org.jfree.data.category.DefaultCategoryDataset var42 = new org.jfree.data.category.DefaultCategoryDataset();
    int var44 = var42.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var45 = new org.jfree.data.general.DatasetGroup();
    var42.setGroup(var45);
    int var48 = var42.getRowIndex((java.lang.Comparable)(short)100);
    org.jfree.data.event.DatasetChangeListener var49 = null;
    var42.removeChangeListener(var49);
    org.jfree.data.general.DatasetGroup var51 = var42.getGroup();
    org.jfree.data.Range var52 = var35.findRangeBounds((org.jfree.data.category.CategoryDataset)var42);
    org.jfree.data.category.CategoryDatasetSelectionState var53 = var42.getSelectionState();
    int var55 = var42.getRowIndex((java.lang.Comparable)(short)10);
    org.jfree.chart.plot.PlotRenderingInfo var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var57 = var0.initialise(var14, var15, var24, (org.jfree.data.category.CategoryDataset)var42, var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-1));

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test100"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    java.awt.Stroke var14 = var8.getRangeMinorGridlineStroke();
    org.jfree.chart.util.RectangleEdge var16 = var8.getDomainAxisEdge(3);
    var8.clearRangeAxes();
    org.jfree.chart.annotations.CategoryAnnotation var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addAnnotation(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test101"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0.5f);
    int var3 = var0.getColumnCount();
    java.util.List var4 = var0.getRowKeys();
    int var5 = var0.getColumnCount();
    int var6 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)178);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test102"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("ItemLabelAnchor.OUTSIDE6", var1);
// 
//   }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test103"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.axis.AxisSpace var9 = null;
    var8.setFixedRangeAxisSpace(var9, false);
    boolean var12 = var8.isRangeZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test104"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    var8.clearDomainMarkers();
    org.jfree.chart.axis.AxisSpace var22 = null;
    var8.setFixedRangeAxisSpace(var22, true);
    var8.clearRangeMarkers(100);
    org.jfree.chart.plot.PlotRenderingInfo var28 = null;
    java.awt.geom.Point2D var29 = null;
    var8.panRangeAxes(26.0d, var28, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test105"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    java.awt.Paint var6 = var2.getItemOutlinePaint((-16777216), 255, true);
    var2.setSeriesCreateEntities(255, (java.lang.Boolean)false);
    var2.setSeriesVisible(15, (java.lang.Boolean)false);
    var2.setBaseSeriesVisible(false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var17 = var15.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var18 = null;
    var15.setLegendItemURLGenerator(var18);
    org.jfree.chart.urls.CategoryURLGenerator var20 = null;
    var15.setBaseURLGenerator(var20, false);
    java.lang.Boolean var24 = var15.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var15.setSeriesURLGenerator(1, var26, true);
    boolean var29 = var15.getBaseLinesVisible();
    boolean var31 = var15.isSeriesItemLabelsVisible(2);
    java.awt.Font var33 = var15.lookupLegendTextFont(1);
    var15.removeAnnotations();
    java.awt.Paint var35 = var15.getBasePaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var36.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var40 = var36.getLegendItems();
    java.awt.Paint var42 = var36.lookupSeriesPaint(2);
    var15.setBaseFillPaint(var42);
    java.awt.Font var44 = var15.getBaseLegendTextFont();
    org.jfree.chart.labels.ItemLabelPosition var46 = var15.getSeriesPositiveItemLabelPosition(15);
    var2.setBaseNegativeItemLabelPosition(var46, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test106"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    java.lang.Boolean var11 = var0.getSeriesItemLabelsVisible(0);
    var0.setBaseSeriesVisible(true);
    org.jfree.chart.renderer.RenderAttributes var14 = var0.getSelectedItemAttributes();
    boolean var16 = var0.isSeriesVisible((-97));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test107"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    org.jfree.chart.plot.Plot var3 = var0.getPlot();
    var0.setAxisLineVisible(false);
    org.jfree.chart.JFreeChart var6 = null;
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.util.Layer var17 = null;
    java.util.Collection var18 = var15.getRangeMarkers((-1), var17);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var21 = var19.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var22 = null;
    var19.setLegendItemURLGenerator(var22);
    org.jfree.chart.urls.CategoryURLGenerator var24 = null;
    var19.setBaseURLGenerator(var24, false);
    java.lang.Boolean var28 = var19.getSeriesVisibleInLegend((-1));
    boolean var31 = var19.getItemShapeFilled((-1), 100);
    java.awt.Shape var36 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var39 = var37.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var40 = null;
    var37.setLegendItemURLGenerator(var40);
    org.jfree.chart.urls.CategoryURLGenerator var42 = null;
    var37.setBaseURLGenerator(var42, false);
    var37.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var47.setSeriesToolTipGenerator(0, var49, true);
    org.jfree.chart.labels.ItemLabelPosition var52 = var47.getBasePositiveItemLabelPosition();
    java.awt.Paint var53 = var47.getBaseFillPaint();
    var37.setBaseOutlinePaint(var53, false);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var36, var53);
    var19.setBaseOutlinePaint(var53, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var61 = var59.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var62 = null;
    var59.setLegendItemURLGenerator(var62);
    org.jfree.chart.urls.CategoryURLGenerator var64 = null;
    var59.setBaseURLGenerator(var64, false);
    java.lang.Boolean var68 = var59.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var72 = var59.getItemStroke(10, 1, false);
    var19.setBaseStroke(var72, false);
    var15.setDomainCrosshairStroke(var72);
    org.jfree.chart.plot.PlotRenderingInfo var77 = null;
    java.awt.geom.Point2D var78 = null;
    var15.zoomDomainAxes(0.0d, var77, var78, true);
    org.jfree.chart.plot.PlotRenderingInfo var82 = null;
    java.awt.geom.Point2D var83 = null;
    var15.panRangeAxes(0.05d, var82, var83);
    org.jfree.chart.event.PlotChangeEvent var85 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.plot.Plot var86 = var85.getPlot();
    org.jfree.chart.JFreeChart var87 = null;
    var85.setChart(var87);
    org.jfree.chart.event.ChartChangeEventType var89 = var85.getType();
    java.lang.String var90 = var89.toString();
    org.jfree.chart.event.ChartChangeEvent var91 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0, var6, var89);
    org.jfree.chart.JFreeChart var92 = null;
    var91.setChart(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var90 + "' != '" + "ChartChangeEventType.GENERAL"+ "'", var90.equals("ChartChangeEventType.GENERAL"));

  }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test108"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getRangeMarkers(0, var10);
//     var8.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     var8.setDomainAxis(2, var15, true);
//     var8.setOutlineVisible(false);
//     var8.setRangeCrosshairLockedOnData(false);
//     var8.clearDomainMarkers((-16620543));
//     int var24 = var8.getWeight();
//     org.jfree.chart.renderer.category.BarRenderer var26 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var27 = var26.getItemMargin();
//     var26.setBaseSeriesVisibleInLegend(true);
//     org.jfree.chart.util.GradientPaintTransformer var30 = var26.getGradientPaintTransformer();
//     var26.setIncludeBaseInRange(true);
//     var26.setAutoPopulateSeriesShape(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var35.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     boolean var39 = var35.getUseSeriesOffset();
//     java.awt.Paint var40 = var35.getBaseOutlinePaint();
//     java.awt.Shape var41 = var35.getBaseShape();
//     org.jfree.chart.entity.ChartEntity var43 = new org.jfree.chart.entity.ChartEntity(var41, "hi!");
//     var26.setBaseShape(var41, true);
//     var26.setAutoPopulateSeriesFillPaint(true);
//     org.jfree.chart.urls.CategoryURLGenerator var48 = null;
//     var26.setBaseURLGenerator(var48);
//     org.jfree.data.KeyedObject var50 = new org.jfree.data.KeyedObject((java.lang.Comparable)8.0d, (java.lang.Object)var26);
//     var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var26, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     boolean var55 = var53.isSeriesVisibleInLegend(1);
//     java.awt.Font var56 = var53.getBaseItemLabelFont();
//     var26.setBaseItemLabelFont(var56, true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var35
//     assertTrue("Contract failed: equals-hashcode on var53 and var35", var53.equals(var35) ? var53.hashCode() == var35.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var53 and var35.", var53.equals(var35) == var35.equals(var53));
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test109"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    java.awt.Paint var9 = var0.getItemOutlinePaint(100, 1, true);
    java.lang.Object var10 = var0.clone();
    java.lang.Boolean var12 = var0.getSeriesShapesFilled(4);
    var0.setSeriesVisible(4, (java.lang.Boolean)true);
    java.lang.Boolean var17 = var0.getSeriesVisibleInLegend(10);
    var0.setSeriesShapesFilled(0, false);
    double var21 = var0.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test110"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    org.jfree.chart.util.DefaultShadowGenerator var18 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var19 = var18.getShadowColor();
    var8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var18);
    var8.setDomainCrosshairVisible(true);
    org.jfree.chart.axis.ValueAxis var23 = null;
    var8.setRangeAxis(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test111"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    boolean var8 = var5.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var10 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var4, var10);
    var11.setSeriesKey((java.lang.Comparable)true);
    var11.setDescription("hi!");
    int var16 = var11.getDatasetIndex();
    var11.setSeriesIndex(2);
    java.awt.Paint var19 = var11.getOutlinePaint();
    java.awt.Font var20 = var11.getLabelFont();
    java.awt.Shape var25 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var28 = var26.getSeriesStroke(0);
    boolean var29 = var26.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var31 = var26.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var25, var31);
    var32.setSeriesKey((java.lang.Comparable)true);
    var32.setLineVisible(false);
    java.lang.Object var37 = var32.clone();
    java.lang.String var38 = var32.getToolTipText();
    org.jfree.chart.util.StandardGradientPaintTransformer var39 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var40 = var39.getType();
    java.lang.Object var41 = var39.clone();
    var32.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var39);
    java.lang.String var43 = var32.getDescription();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var46 = var44.getSeriesStroke(0);
    boolean var47 = var44.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var49 = var44.lookupSeriesFillPaint(10);
    var32.setFillPaint(var49);
    var11.setFillPaint(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + ""+ "'", var38.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var43 + "' != '" + "hi!"+ "'", var43.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test112"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.Range var22 = var8.getDataRange(var21);
    var8.clearRangeMarkers((-1));
    org.jfree.chart.util.DefaultShadowGenerator var25 = new org.jfree.chart.util.DefaultShadowGenerator();
    org.jfree.data.category.DefaultCategoryDataset var26 = new org.jfree.data.category.DefaultCategoryDataset();
    int var28 = var26.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    double var32 = var31.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var33 = var31.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var34 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var26, var29, var30, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.util.Layer var36 = null;
    java.util.Collection var37 = var34.getRangeMarkers(0, var36);
    var34.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var41 = null;
    var34.setDomainAxis(2, var41, true);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var34.zoomDomainAxes(0.0d, var45, var46, false);
    var34.setWeight(0);
    boolean var51 = var25.equals((java.lang.Object)0);
    var8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator)var25);
    int var53 = var25.getShadowSize();
    int var54 = var25.calculateOffsetX();
    int var55 = var25.calculateOffsetY();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == (-2));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == (-2));

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test113"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
//     java.lang.Object var14 = var13.clone();
//     var8.setFixedLegendItems(var13);
//     org.jfree.chart.event.PlotChangeEvent var16 = null;
//     var8.notifyListeners(var16);
//     org.jfree.data.category.DefaultCategoryDataset var18 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var20 = var18.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var21 = null;
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var24 = var23.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var25 = var23.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var18, var21, var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var27.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var31 = var27.getLegendItems();
//     java.lang.Object var32 = var31.clone();
//     var26.setFixedLegendItems(var31);
//     org.jfree.chart.plot.PlotRenderingInfo var36 = null;
//     java.awt.geom.Point2D var37 = null;
//     var26.zoomRangeAxes((-1.0d), 10.0d, var36, var37);
//     org.jfree.chart.axis.AxisLocation var40 = var26.getRangeAxisLocation(1);
//     org.jfree.chart.axis.AxisLocation var41 = var40.getOpposite();
//     var8.setRangeAxisLocation(var40);
//     
//     // Checks the contract:  equals-hashcode on var13 and var31
//     assertTrue("Contract failed: equals-hashcode on var13 and var31", var13.equals(var31) ? var13.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var13
//     assertTrue("Contract failed: equals-hashcode on var31 and var13", var31.equals(var13) ? var31.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var32
//     assertTrue("Contract failed: equals-hashcode on var14 and var32", var14.equals(var32) ? var14.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var14
//     assertTrue("Contract failed: equals-hashcode on var32 and var14", var32.equals(var14) ? var32.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test114"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(2, 1, 2);
    int var4 = var3.getTransparency();
    int var5 = var3.getGreen();
    java.awt.image.ColorModel var6 = null;
    java.awt.Rectangle var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    java.awt.geom.AffineTransform var9 = null;
    java.awt.RenderingHints var10 = null;
    java.awt.PaintContext var11 = var3.createContext(var6, var7, var8, var9, var10);
    java.awt.color.ColorSpace var12 = var3.getColorSpace();
    int var13 = var3.getBlue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 2);

  }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test115"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var1 = var0.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
//     int var3 = var0.getPassCount();
//     boolean var5 = var0.equals((java.lang.Object)"");
//     var0.setBaseSeriesVisibleInLegend(true);
//     var0.setBase(0.2d);
//     var0.setMaximumBarWidth(0.0d);
//     org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var14 = var12.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.data.general.DatasetGroup var15 = new org.jfree.data.general.DatasetGroup();
//     var12.setGroup(var15);
//     var12.setValue((java.lang.Number)(-1), (java.lang.Comparable)(short)1, (java.lang.Comparable)"hi!");
//     var12.validateObject();
//     org.jfree.data.Range var22 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var12);
//     java.awt.Font var23 = var0.getBaseItemLabelFont();
//     org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var25 = var24.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var26 = var24.getPositiveItemLabelPositionFallback();
//     int var27 = var24.getPassCount();
//     boolean var29 = var24.equals((java.lang.Object)"");
//     var24.setBaseSeriesVisibleInLegend(true);
//     var24.setBase(0.2d);
//     var24.setMaximumBarWidth(0.0d);
//     org.jfree.data.category.DefaultCategoryDataset var36 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var38 = var36.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.data.general.DatasetGroup var39 = new org.jfree.data.general.DatasetGroup();
//     var36.setGroup(var39);
//     var36.setValue((java.lang.Number)(-1), (java.lang.Comparable)(short)1, (java.lang.Comparable)"hi!");
//     var36.validateObject();
//     org.jfree.data.Range var46 = var24.findRangeBounds((org.jfree.data.category.CategoryDataset)var36);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var47 = var24.getLegendItemLabelGenerator();
//     var0.setLegendItemURLGenerator(var47);
//     
//     // Checks the contract:  equals-hashcode on var12 and var36
//     assertTrue("Contract failed: equals-hashcode on var12 and var36", var12.equals(var36) ? var12.hashCode() == var36.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var36 and var12
//     assertTrue("Contract failed: equals-hashcode on var36 and var12", var36.equals(var12) ? var36.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var39
//     assertTrue("Contract failed: equals-hashcode on var15 and var39", var15.equals(var39) ? var15.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var15
//     assertTrue("Contract failed: equals-hashcode on var39 and var15", var39.equals(var15) ? var39.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test116"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getItemLabelGenerator(255, 0, false);
    boolean var7 = var2.getDrawOutlines();
    java.awt.Shape var9 = var2.lookupSeriesShape(1);
    boolean var12 = var2.getItemShapeFilled((-16645886), 0);
    var2.setItemLabelAnchorOffset((-3.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test117"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    float var16 = var8.getForegroundAlpha();
    java.lang.Object var17 = null;
    boolean var18 = var8.equals(var17);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var8.panDomainAxes(1.0d, var20, var21);
    org.jfree.data.category.CategoryDataset var24 = var8.getDataset((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test118"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.data.category.DefaultCategoryDataset var4 = new org.jfree.data.category.DefaultCategoryDataset();
    int var6 = var4.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var7 = new org.jfree.data.general.DatasetGroup();
    var4.setGroup(var7);
    org.jfree.data.Range var9 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var4);
    org.jfree.chart.renderer.RenderAttributes var10 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var12 = var10.getSeriesPaint(100);
    java.awt.Paint var14 = var10.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var15.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var19 = var15.getUseSeriesOffset();
    java.awt.Paint var20 = var15.getBaseOutlinePaint();
    java.awt.Shape var21 = var15.getBaseShape();
    var10.setDefaultShape(var21);
    org.jfree.data.category.DefaultCategoryDataset var23 = new org.jfree.data.category.DefaultCategoryDataset();
    int var25 = var23.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    double var29 = var28.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var30 = var28.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var23, var26, var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var32.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var36 = var32.getLegendItems();
    java.lang.Object var37 = var36.clone();
    var31.setFixedLegendItems(var36);
    org.jfree.chart.entity.PlotEntity var40 = new org.jfree.chart.entity.PlotEntity(var21, (org.jfree.chart.plot.Plot)var31, "");
    var31.clearAnnotations();
    org.jfree.chart.event.AnnotationChangeEvent var42 = null;
    var31.annotationChanged(var42);
    var31.setBackgroundImageAlpha(0.0f);
    int var46 = var31.getWeight();
    var4.removeChangeListener((org.jfree.data.event.DatasetChangeListener)var31);
    boolean var48 = var31.isDomainZoomable();
    org.jfree.chart.axis.AxisLocation var50 = var31.getRangeAxisLocation(5);
    org.jfree.chart.plot.PlotRenderingInfo var52 = null;
    java.awt.geom.Point2D var53 = null;
    var31.panDomainAxes(100.0d, var52, var53);
    var31.configureDomainAxes();
    org.jfree.chart.renderer.category.CategoryItemRenderer var57 = var31.getRenderer(4);
    org.jfree.chart.plot.PlotRenderingInfo var59 = null;
    java.awt.geom.Point2D var60 = null;
    var31.zoomRangeAxes(84.0d, var59, var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test119"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    java.awt.Font var7 = var0.getSeriesItemLabelFont(1);
    java.awt.Shape var9 = var0.lookupSeriesShape(100);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var13, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var18.getRangeMarkers(0, var20);
    var18.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    var18.setDomainAxis(2, var25, true);
    boolean var28 = var18.isDomainZoomable();
    org.jfree.chart.entity.PlotEntity var31 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var18, "hi!", "ItemLabelAnchor.OUTSIDE12");
    org.jfree.chart.renderer.category.BarRenderer var33 = new org.jfree.chart.renderer.category.BarRenderer();
    double var34 = var33.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var35 = var33.getPositiveItemLabelPositionFallback();
    java.awt.Font var37 = var33.lookupLegendTextFont(1);
    var18.setRenderer(100, (org.jfree.chart.renderer.category.CategoryItemRenderer)var33);
    java.awt.Paint var42 = var33.getItemFillPaint(10, 10, false);
    boolean var43 = var33.getShadowsVisible();
    java.awt.Paint var45 = var33.lookupLegendTextPaint(0);
    var33.setItemMargin((-7.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);

  }

  public void test120() {}
//   public void test120() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test120"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
//     java.lang.Object var14 = var13.clone();
//     var8.setFixedLegendItems(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
//     org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
//     org.jfree.data.category.CategoryDataset var24 = var8.getDataset((-16777216));
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var8.panDomainAxes(0.2d, var26, var27);
//     java.awt.Stroke var29 = var8.getRangeCrosshairStroke();
//     org.jfree.chart.plot.Marker var31 = null;
//     org.jfree.chart.util.Layer var32 = null;
//     boolean var33 = var8.removeDomainMarker((-2), var31, var32);
//     org.jfree.chart.axis.ValueAxis var34 = null;
//     org.jfree.data.Range var35 = var8.getDataRange(var34);
//     org.jfree.data.category.DefaultCategoryDataset var36 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var38 = var36.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var39 = null;
//     org.jfree.chart.axis.ValueAxis var40 = null;
//     org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var42 = var41.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var43 = var41.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var36, var39, var40, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var45.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var49 = var45.getLegendItems();
//     java.lang.Object var50 = var49.clone();
//     var44.setFixedLegendItems(var49);
//     org.jfree.chart.plot.PlotRenderingInfo var54 = null;
//     java.awt.geom.Point2D var55 = null;
//     var44.zoomRangeAxes((-1.0d), 10.0d, var54, var55);
//     var44.clearDomainMarkers();
//     org.jfree.chart.axis.AxisSpace var58 = null;
//     var44.setFixedRangeAxisSpace(var58, true);
//     org.jfree.chart.event.PlotChangeEvent var61 = null;
//     var44.notifyListeners(var61);
//     org.jfree.chart.LegendItemCollection var63 = var44.getLegendItems();
//     var8.setFixedLegendItems(var63);
//     
//     // Checks the contract:  equals-hashcode on var8 and var44
//     assertTrue("Contract failed: equals-hashcode on var8 and var44", var8.equals(var44) ? var8.hashCode() == var44.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var44 and var8
//     assertTrue("Contract failed: equals-hashcode on var44 and var8", var44.equals(var8) ? var44.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var49
//     assertTrue("Contract failed: equals-hashcode on var13 and var49", var13.equals(var49) ? var13.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var63
//     assertTrue("Contract failed: equals-hashcode on var13 and var63", var13.equals(var63) ? var13.hashCode() == var63.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var13
//     assertTrue("Contract failed: equals-hashcode on var49 and var13", var49.equals(var13) ? var49.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var63 and var13
//     assertTrue("Contract failed: equals-hashcode on var63 and var13", var63.equals(var13) ? var63.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var50
//     assertTrue("Contract failed: equals-hashcode on var14 and var50", var14.equals(var50) ? var14.hashCode() == var50.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var50 and var14
//     assertTrue("Contract failed: equals-hashcode on var50 and var14", var50.equals(var14) ? var50.hashCode() == var14.hashCode() : true);
// 
//   }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test121"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var6.getBaseItemLabelGenerator();
    var6.setMaximumBarWidth(0.0d);
    java.awt.Paint var13 = var6.getLegendTextPaint(1);
    java.awt.Paint var15 = var6.getLegendTextPaint(100);
    boolean var16 = var0.equals((java.lang.Object)var6);
    var0.setLowerMargin((-1.0d));
    var0.clearCategoryLabelToolTips();
    var0.setLabelToolTip("TextAnchor.BOTTOM_CENTER");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test122"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var3 = new org.jfree.data.general.DatasetGroup();
    var0.setGroup(var3);
    int var6 = var0.getRowIndex((java.lang.Comparable)(short)100);
    var0.validateObject();
    org.jfree.data.KeyedObjects2D var8 = new org.jfree.data.KeyedObjects2D();
    int var10 = var8.getColumnIndex((java.lang.Comparable)0.5f);
    var8.clear();
    java.util.List var12 = var8.getColumnKeys();
    java.util.List var13 = var8.getColumnKeys();
    org.jfree.data.category.DefaultCategoryDataset var14 = new org.jfree.data.category.DefaultCategoryDataset();
    int var16 = var14.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var21 = var19.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var14, var17, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    double var24 = var23.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = var23.getBaseItemLabelGenerator();
    var23.setShadowYOffset(0.2d);
    var22.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var33 = var31.getSeriesStroke(0);
    boolean var34 = var31.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var36 = var31.lookupSeriesFillPaint(10);
    var22.setDomainCrosshairPaint(var36);
    int var38 = var22.getRendererCount();
    java.awt.Graphics2D var39 = null;
    java.awt.geom.Rectangle2D var40 = null;
    var22.drawBackgroundImage(var39, var40);
    var22.setBackgroundImageAlignment(1);
    boolean var44 = var8.equals((java.lang.Object)var22);
    org.jfree.chart.axis.CategoryAxis var45 = var22.getDomainAxis();
    boolean var46 = var0.hasListener((java.util.EventListener)var22);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var49 = null;
    var47.setSeriesToolTipGenerator(0, var49, true);
    org.jfree.chart.labels.ItemLabelPosition var52 = var47.getBasePositiveItemLabelPosition();
    java.awt.Font var54 = var47.getSeriesItemLabelFont(1);
    java.awt.Shape var56 = var47.lookupSeriesShape(100);
    org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
    double var58 = var57.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var59 = var57.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var60 = var57.getBaseItemLabelGenerator();
    var57.setMaximumBarWidth(0.0d);
    java.awt.Paint var64 = var57.getLegendTextPaint(1);
    org.jfree.chart.labels.ItemLabelPosition var66 = var57.getSeriesNegativeItemLabelPosition(0);
    var47.setBaseNegativeItemLabelPosition(var66);
    java.awt.Font var69 = var47.getSeriesItemLabelFont(0);
    int var70 = var22.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == (-1));

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test123"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
    org.jfree.chart.plot.PlotOrientation var23 = var8.getOrientation();
    org.jfree.chart.axis.AxisSpace var24 = null;
    var8.setFixedRangeAxisSpace(var24, true);
    java.awt.Paint var27 = var8.getDomainGridlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test124"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var9 = var5.getUseSeriesOffset();
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    java.awt.Shape var11 = var5.getBaseShape();
    var0.setDefaultShape(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
    java.lang.Object var27 = var26.clone();
    var21.setFixedLegendItems(var26);
    org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
    org.jfree.chart.axis.AxisSpace var31 = null;
    var21.setFixedDomainAxisSpace(var31);
    org.jfree.chart.event.PlotChangeEvent var33 = null;
    var21.notifyListeners(var33);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var35.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.data.category.DefaultCategoryDataset var39 = new org.jfree.data.category.DefaultCategoryDataset();
    int var41 = var39.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var42 = new org.jfree.data.general.DatasetGroup();
    var39.setGroup(var42);
    org.jfree.data.Range var44 = var35.findRangeBounds((org.jfree.data.category.CategoryDataset)var39);
    int var45 = var21.indexOf((org.jfree.data.category.CategoryDataset)var39);
    org.jfree.data.category.DefaultCategoryDataset var46 = new org.jfree.data.category.DefaultCategoryDataset();
    int var48 = var46.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var49 = null;
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.renderer.category.BarRenderer var51 = new org.jfree.chart.renderer.category.BarRenderer();
    double var52 = var51.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var53 = var51.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var46, var49, var50, (org.jfree.chart.renderer.category.CategoryItemRenderer)var51);
    float var55 = var54.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var56 = new org.jfree.data.category.DefaultCategoryDataset();
    int var58 = var56.getColumnIndex((java.lang.Comparable)(byte)1);
    int var59 = var54.indexOf((org.jfree.data.category.CategoryDataset)var56);
    int var61 = var56.getColumnIndex((java.lang.Comparable)"PlotEntity: tooltip = ");
    var39.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var56);
    java.util.List var63 = var39.getRowKeys();
    int var64 = var39.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test125"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.BarRenderer var9 = new org.jfree.chart.renderer.category.BarRenderer();
    double var10 = var9.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var11 = var9.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var9.getBaseItemLabelGenerator();
    var9.setShadowYOffset(0.2d);
    var8.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var9, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var19 = var17.getSeriesStroke(0);
    boolean var20 = var17.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var22 = var17.lookupSeriesFillPaint(10);
    var8.setDomainCrosshairPaint(var22);
    int var24 = var8.getRendererCount();
    java.awt.Graphics2D var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var8.drawBackgroundImage(var25, var26);
    org.jfree.chart.util.RectangleEdge var29 = var8.getRangeAxisEdge((-15466498));
    org.jfree.chart.util.RectangleEdge var31 = var8.getRangeAxisEdge(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test126"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("ItemLabelAnchor.OUTSIDE6");

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test127"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    boolean var8 = var5.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var10 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var4, var10);
    var11.setSeriesKey((java.lang.Comparable)true);
    var11.setDescription("hi!");
    int var16 = var11.getDatasetIndex();
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var20 = null;
    org.jfree.chart.util.RectangleEdge var21 = null;
    double var22 = var17.getCategoryEnd(2, 0, var20, var21);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    double var24 = var23.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = var23.getBaseItemLabelGenerator();
    var23.setMaximumBarWidth(0.0d);
    java.awt.Paint var30 = var23.getLegendTextPaint(1);
    java.awt.Paint var32 = var23.getLegendTextPaint(100);
    boolean var33 = var17.equals((java.lang.Object)var23);
    org.jfree.data.category.DefaultCategoryDataset var34 = new org.jfree.data.category.DefaultCategoryDataset();
    int var36 = var34.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var37 = null;
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.BarRenderer var39 = new org.jfree.chart.renderer.category.BarRenderer();
    double var40 = var39.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var41 = var39.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var34, var37, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
    org.jfree.chart.util.Layer var44 = null;
    java.util.Collection var45 = var42.getRangeMarkers((-1), var44);
    var17.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var42);
    double var47 = var17.getCategoryMargin();
    java.awt.Paint var48 = var17.getAxisLinePaint();
    var11.setFillPaint(var48);
    var11.setSeriesIndex(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test128"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var3 = var1.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = null;
    var1.setLegendItemURLGenerator(var4);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var1.setBaseURLGenerator(var6, false);
    var1.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var11.setSeriesToolTipGenerator(0, var13, true);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getBasePositiveItemLabelPosition();
    java.awt.Paint var17 = var11.getBaseFillPaint();
    var1.setBaseOutlinePaint(var17, false);
    boolean var20 = var1.getUseFillPaint();
    java.awt.Font var21 = var1.getBaseItemLabelFont();
    var0.setTickLabelFont(var21);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    var0.setLabelToolTip("Category Plot");
    java.awt.Paint var26 = var0.getAxisLinePaint();
    var0.setLabelToolTip("PlotOrientation.VERTICAL");
    float var29 = var0.getMinorTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0.0f);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test129"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesFillPaint(0);
    java.lang.Boolean var3 = var0.getDefaultLabelVisible();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var5.getCategoryEnd(2, 0, var8, var9);
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers(0, var21);
    var19.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var26 = null;
    var19.setDomainAxis(2, var26, true);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    java.awt.geom.Point2D var31 = null;
    var19.zoomDomainAxes(0.0d, var30, var31, false);
    var5.setPlot((org.jfree.chart.plot.Plot)var19);
    java.awt.Paint var35 = var5.getTickLabelPaint();
    var0.setSeriesPaint(100, var35);
    org.jfree.chart.ChartColor var40 = new org.jfree.chart.ChartColor(2, 1, 2);
    int var41 = var40.getTransparency();
    int var42 = var40.getGreen();
    java.awt.color.ColorSpace var43 = var40.getColorSpace();
    java.awt.Color var44 = var40.darker();
    int var45 = var40.getRGB();
    int var46 = var40.getAlpha();
    var0.setDefaultLabelPaint((java.awt.Paint)var40);
    java.awt.Stroke var50 = var0.getItemStroke(4, 178);
    java.lang.Boolean var51 = var0.getDefaultLabelVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-16645886));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 255);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test130"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.awt.Shape var4 = var0.getShape(2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    boolean var8 = var5.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var10 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var5.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var16 = var5.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
    var17.setSeriesToolTipGenerator(0, var19, true);
    org.jfree.chart.labels.ItemLabelPosition var22 = var17.getBasePositiveItemLabelPosition();
    var5.setBasePositiveItemLabelPosition(var22);
    java.lang.Object var24 = var5.clone();
    boolean var25 = var0.equals((java.lang.Object)var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test131"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var8 = null;
    var5.setLegendItemURLGenerator(var8);
    var5.setUseSeriesOffset(false);
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var13 = var12.getAxisLinePaint();
    java.awt.Paint var14 = var12.getTickLabelPaint();
    var5.setBaseOutlinePaint(var14);
    org.jfree.chart.renderer.RenderAttributes var16 = new org.jfree.chart.renderer.RenderAttributes();
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    double var18 = var17.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var19 = var17.getBarPainter();
    java.awt.Stroke var20 = var17.getBaseStroke();
    var16.setDefaultStroke(var20);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var24 = var22.getSeriesStroke(0);
    boolean var25 = var22.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var27 = var22.lookupSeriesFillPaint(10);
    java.awt.Paint var31 = var22.getItemOutlinePaint(100, 1, true);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("org.jfree.data.UnknownKeyException: ", "hi!", "AxisLocation.BOTTOM_OR_RIGHT", "AxisLocation.BOTTOM_OR_RIGHT", var4, var14, var20, var31);
    java.awt.Shape var33 = var32.getLine();
    int var34 = var32.getSeriesIndex();
    java.awt.Stroke var35 = var32.getLineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var38 = var36.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var39 = null;
    var36.setLegendItemURLGenerator(var39);
    org.jfree.chart.urls.CategoryURLGenerator var41 = null;
    var36.setBaseURLGenerator(var41, false);
    var36.setAutoPopulateSeriesPaint(true);
    java.util.EventListener var46 = null;
    boolean var47 = var36.hasListener(var46);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var50 = var48.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var51 = null;
    var48.setLegendItemURLGenerator(var51);
    org.jfree.chart.urls.CategoryURLGenerator var53 = null;
    var48.setBaseURLGenerator(var53, false);
    java.lang.Boolean var57 = var48.getSeriesVisibleInLegend((-1));
    boolean var60 = var48.getItemShapeFilled((-1), 100);
    java.awt.Shape var65 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var68 = var66.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var69 = null;
    var66.setLegendItemURLGenerator(var69);
    org.jfree.chart.urls.CategoryURLGenerator var71 = null;
    var66.setBaseURLGenerator(var71, false);
    var66.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var78 = null;
    var76.setSeriesToolTipGenerator(0, var78, true);
    org.jfree.chart.labels.ItemLabelPosition var81 = var76.getBasePositiveItemLabelPosition();
    java.awt.Paint var82 = var76.getBaseFillPaint();
    var66.setBaseOutlinePaint(var82, false);
    org.jfree.chart.LegendItem var85 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var65, var82);
    var48.setBaseOutlinePaint(var82, true);
    var36.setBaseFillPaint(var82, true);
    boolean var90 = var36.getBaseShapesFilled();
    java.awt.Paint var92 = var36.lookupSeriesFillPaint((-16777216));
    var32.setFillPaint(var92);
    java.awt.Stroke var94 = var32.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test132"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    java.awt.Font var7 = var0.getSeriesItemLabelFont(1);
    java.awt.Shape var9 = var0.lookupSeriesShape(100);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var13, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var18.getRangeMarkers(0, var20);
    var18.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var25 = null;
    var18.setDomainAxis(2, var25, true);
    boolean var28 = var18.isDomainZoomable();
    org.jfree.chart.entity.PlotEntity var31 = new org.jfree.chart.entity.PlotEntity(var9, (org.jfree.chart.plot.Plot)var18, "hi!", "ItemLabelAnchor.OUTSIDE12");
    java.awt.Stroke var32 = var18.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test133"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var9 = var7.getSeriesStroke(0);
    boolean var10 = var7.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var12 = var7.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var16 = var7.getToolTipGenerator(1, (-1), true);
    java.awt.Shape var18 = var7.getSeriesShape(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = null;
    var19.setSeriesToolTipGenerator(0, var21, true);
    org.jfree.chart.labels.ItemLabelPosition var24 = var19.getBasePositiveItemLabelPosition();
    var7.setBasePositiveItemLabelPosition(var24);
    var0.setPositiveItemLabelPositionFallback(var24);
    double var27 = var0.getMinimumBarLength();
    org.jfree.chart.labels.ItemLabelPosition var28 = var0.getNegativeItemLabelPositionFallback();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test134"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    float var12 = var8.getBackgroundImageAlpha();
    org.jfree.chart.renderer.category.CategoryItemRenderer var14 = null;
    var8.setRenderer(100, var14);
    org.jfree.chart.renderer.category.CategoryItemRenderer var17 = var8.getRenderer(0);
    java.awt.Paint var18 = var8.getOutlinePaint();
    org.jfree.chart.axis.ValueAxis var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setRangeAxis((-83), var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test135"); }


    org.jfree.data.KeyedObject var2 = new org.jfree.data.KeyedObject((java.lang.Comparable)10, (java.lang.Object)'4');
    org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
    int var5 = var3.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    double var9 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var10 = var8.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, var6, var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var11.getRangeMarkers((-1), var13);
    org.jfree.chart.LegendItemCollection var15 = var11.getLegendItems();
    int var16 = var11.getBackgroundImageAlignment();
    java.awt.Paint var17 = var11.getBackgroundPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var20 = var18.getSeriesStroke(0);
    boolean var21 = var18.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var23 = var18.lookupSeriesFillPaint(10);
    java.awt.Paint var27 = var18.getItemOutlinePaint(100, 1, true);
    java.lang.Object var28 = var18.clone();
    java.lang.Boolean var30 = var18.getSeriesShapesFilled(4);
    var11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    var2.setObject((java.lang.Object)var11);
    org.jfree.data.KeyedObjects var33 = new org.jfree.data.KeyedObjects();
    int var35 = var33.getIndex((java.lang.Comparable)0.05d);
    var33.clear();
    java.awt.Shape var42 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var45 = var43.getSeriesStroke(0);
    boolean var46 = var43.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var48 = var43.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var42, var48);
    var49.setSeriesKey((java.lang.Comparable)true);
    var49.setDescription("hi!");
    int var54 = var49.getDatasetIndex();
    java.awt.Stroke var55 = var49.getOutlineStroke();
    java.awt.Shape var60 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var63 = var61.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var64 = null;
    var61.setLegendItemURLGenerator(var64);
    org.jfree.chart.urls.CategoryURLGenerator var66 = null;
    var61.setBaseURLGenerator(var66, false);
    var61.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var71 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var73 = null;
    var71.setSeriesToolTipGenerator(0, var73, true);
    org.jfree.chart.labels.ItemLabelPosition var76 = var71.getBasePositiveItemLabelPosition();
    java.awt.Paint var77 = var71.getBaseFillPaint();
    var61.setBaseOutlinePaint(var77, false);
    org.jfree.chart.LegendItem var80 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var60, var77);
    java.awt.Paint var81 = var80.getOutlinePaint();
    var80.setSeriesKey((java.lang.Comparable)'a');
    java.awt.Shape var84 = var80.getLine();
    org.jfree.chart.util.StandardGradientPaintTransformer var85 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var86 = var85.getType();
    var80.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var85);
    var49.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer)var85);
    var33.setObject((java.lang.Comparable)"rect", (java.lang.Object)var85);
    org.jfree.chart.util.PaintList var91 = new org.jfree.chart.util.PaintList();
    var33.setObject((java.lang.Comparable)1, (java.lang.Object)var91);
    int var93 = var33.getItemCount();
    java.lang.Object var94 = var33.clone();
    java.lang.Object var96 = var33.getObject(0);
    var2.setObject(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test136"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    boolean var8 = var5.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var10 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var4, var10);
    var11.setSeriesKey((java.lang.Comparable)true);
    var11.setLineVisible(false);
    java.lang.Object var16 = var11.clone();
    java.lang.String var17 = var11.getToolTipText();
    boolean var18 = var11.isShapeOutlineVisible();
    var11.setToolTipText("org.jfree.chart.event.ChartChangeEvent[source=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test137"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    org.jfree.chart.plot.CategoryPlot var8 = var0.getPlot();
    java.awt.Paint var10 = var0.lookupLegendTextPaint((-16777216));
    boolean var13 = var0.getItemLineVisible((-83), (-16777216));
    double var14 = var0.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 2.0d);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test138"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(0);
    java.lang.Object var3 = var0.clone();
    java.awt.Shape var5 = var0.getShape((-15466498));
    java.lang.Object var6 = var0.clone();
    var0.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test139"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    var8.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis();
    float var21 = var20.getTickMarkInsideLength();
    java.awt.Paint var22 = var20.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var23 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var26 = null;
    org.jfree.chart.util.RectangleEdge var27 = null;
    double var28 = var23.getCategoryEnd(2, 0, var26, var27);
    org.jfree.data.category.DefaultCategoryDataset var29 = new org.jfree.data.category.DefaultCategoryDataset();
    int var31 = var29.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    double var35 = var34.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var36 = var34.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, var32, var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    org.jfree.chart.util.Layer var39 = null;
    java.util.Collection var40 = var37.getRangeMarkers(0, var39);
    var37.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var44 = null;
    var37.setDomainAxis(2, var44, true);
    org.jfree.chart.plot.PlotRenderingInfo var48 = null;
    java.awt.geom.Point2D var49 = null;
    var37.zoomDomainAxes(0.0d, var48, var49, false);
    var23.setPlot((org.jfree.chart.plot.Plot)var37);
    java.awt.Paint var53 = var23.getTickLabelPaint();
    var20.setTickLabelPaint(var53);
    var8.setDomainCrosshairPaint(var53);
    var8.setAnchorValue(4.0d);
    org.jfree.chart.util.Layer var58 = null;
    java.util.Collection var59 = var8.getRangeMarkers(var58);
    org.jfree.chart.axis.AxisSpace var60 = var8.getFixedDomainAxisSpace();
    var8.configureRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);

  }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test140"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var14 = var12.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = null;
    var12.setLegendItemURLGenerator(var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    java.lang.Boolean var21 = var12.getSeriesVisibleInLegend((-1));
    boolean var24 = var12.getItemShapeFilled((-1), 100);
    java.awt.Shape var29 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = null;
    var30.setLegendItemURLGenerator(var33);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var30.setBaseURLGenerator(var35, false);
    var30.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var40.setSeriesToolTipGenerator(0, var42, true);
    org.jfree.chart.labels.ItemLabelPosition var45 = var40.getBasePositiveItemLabelPosition();
    java.awt.Paint var46 = var40.getBaseFillPaint();
    var30.setBaseOutlinePaint(var46, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var29, var46);
    var12.setBaseOutlinePaint(var46, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var54 = var52.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = null;
    var52.setLegendItemURLGenerator(var55);
    org.jfree.chart.urls.CategoryURLGenerator var57 = null;
    var52.setBaseURLGenerator(var57, false);
    java.lang.Boolean var61 = var52.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var65 = var52.getItemStroke(10, 1, false);
    var12.setBaseStroke(var65, false);
    var8.setDomainCrosshairStroke(var65);
    org.jfree.chart.plot.PlotRenderingInfo var70 = null;
    java.awt.geom.Point2D var71 = null;
    var8.zoomDomainAxes(0.0d, var70, var71, true);
    org.jfree.chart.plot.PlotRenderingInfo var75 = null;
    java.awt.geom.Point2D var76 = null;
    var8.panRangeAxes(0.05d, var75, var76);
    org.jfree.chart.event.PlotChangeEvent var78 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
    org.jfree.chart.JFreeChart var79 = null;
    var78.setChart(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test141"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
    int var5 = var3.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.category.BarRenderer var8 = new org.jfree.chart.renderer.category.BarRenderer();
    double var9 = var8.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var10 = var8.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var11 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var3, var6, var7, (org.jfree.chart.renderer.category.CategoryItemRenderer)var8);
    org.jfree.chart.util.Layer var13 = null;
    java.util.Collection var14 = var11.getRangeMarkers((-1), var13);
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var18 = var15.getLegendItem(2, 100);
    java.awt.Stroke var19 = var15.getBaseStroke();
    var11.setRangeCrosshairStroke(var19);
    org.jfree.chart.plot.Marker var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    boolean var24 = var11.removeDomainMarker(1, var22, var23);
    boolean var25 = var11.isDomainGridlinesVisible();
    java.awt.Stroke var26 = var11.getDomainGridlineStroke();
    double var27 = var11.getAnchorValue();
    org.jfree.chart.plot.PlotRenderingInfo var29 = null;
    java.awt.geom.Point2D var30 = null;
    var11.zoomRangeAxes((-15.8d), var29, var30);
    org.jfree.data.category.DefaultCategoryDataset var32 = new org.jfree.data.category.DefaultCategoryDataset();
    int var34 = var32.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.category.BarRenderer var37 = new org.jfree.chart.renderer.category.BarRenderer();
    double var38 = var37.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var39 = var37.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var32, var35, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var37);
    org.jfree.chart.util.Layer var42 = null;
    java.util.Collection var43 = var40.getRangeMarkers(0, var42);
    var40.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var47 = null;
    var40.setDomainAxis(2, var47, true);
    var40.setOutlineVisible(false);
    org.jfree.chart.event.AnnotationChangeEvent var52 = null;
    var40.annotationChanged(var52);
    org.jfree.chart.event.PlotChangeListener var54 = null;
    var40.addChangeListener(var54);
    java.awt.geom.GeneralPath var56 = null;
    java.awt.geom.Rectangle2D var57 = null;
    org.jfree.chart.RenderingSource var58 = null;
    var40.select(var56, var57, var58);
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.axis.ValueAxis[] var61 = new org.jfree.chart.axis.ValueAxis[] { var60};
    var40.setRangeAxes(var61);
    var11.setRangeAxes(var61);
    float var64 = var11.getBackgroundImageAlpha();
    var0.addChangeListener((org.jfree.chart.event.AxisChangeListener)var11);
    var11.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.5f);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test142"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
    java.util.EventListener var10 = null;
    boolean var11 = var0.hasListener(var10);
    var0.setSeriesVisibleInLegend(100, (java.lang.Boolean)true);
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var0.getLegendItemLabelGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var18.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var22 = var18.getUseSeriesOffset();
    java.awt.Paint var23 = var18.getBaseOutlinePaint();
    java.awt.Shape var24 = var18.getBaseShape();
    var0.setBaseLegendShape(var24);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var0.setSeriesURLGenerator(1, var27, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test143"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    int var6 = var0.getColumnCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var0.setBaseURLGenerator(var10, false);
    var0.setBaseItemLabelsVisible(true, false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var0.getSeriesPositiveItemLabelPosition((-254));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test144"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    java.awt.Paint var9 = var0.getItemOutlinePaint(100, 1, true);
    org.jfree.chart.event.RendererChangeEvent var10 = null;
    var0.notifyListeners(var10);
    boolean var15 = var0.isItemLabelVisible(0, 2, false);
    java.awt.Stroke var17 = var0.getSeriesOutlineStroke((-16777216));
    java.awt.Paint var21 = var0.getItemOutlinePaint(255, (-97), false);
    org.jfree.chart.annotations.CategoryAnnotation var22 = null;
    boolean var23 = var0.removeAnnotation(var22);
    org.jfree.chart.renderer.category.BarRenderer var24 = new org.jfree.chart.renderer.category.BarRenderer();
    double var25 = var24.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var26 = var24.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var24.getBaseItemLabelGenerator();
    var24.setShadowYOffset(0.2d);
    var24.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.renderer.RenderAttributes var32 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var35 = var32.getItemPaint(0, (-1));
    java.awt.Paint var37 = var32.getSeriesFillPaint((-1));
    java.awt.Shape var42 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var45 = var43.getSeriesStroke(0);
    boolean var46 = var43.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var48 = var43.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var42, var48);
    var32.setDefaultOutlinePaint(var48);
    var24.setBaseItemLabelPaint(var48);
    var24.setDrawBarOutline(false);
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    double var56 = var55.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var57 = var55.getPositiveItemLabelPositionFallback();
    int var58 = var55.getPassCount();
    boolean var60 = var55.equals((java.lang.Object)"");
    var55.setBaseSeriesVisibleInLegend(true);
    var55.setBase(0.2d);
    org.jfree.chart.labels.ItemLabelPosition var65 = var55.getBasePositiveItemLabelPosition();
    var24.setSeriesNegativeItemLabelPosition(255, var65, false);
    var0.setBaseNegativeItemLabelPosition(var65, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test145"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    var8.setDomainAxis(2, var15, true);
    boolean var18 = var8.isDomainZoomable();
    java.awt.Font var19 = var8.getNoDataMessageFont();
    org.jfree.chart.util.Layer var20 = null;
    java.util.Collection var21 = var8.getRangeMarkers(var20);
    boolean var22 = var8.getDrawSharedDomainAxis();
    org.jfree.chart.event.PlotChangeEvent var23 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var8);
    var8.setRangePannable(false);
    java.awt.Paint var26 = var8.getRangeZeroBaselinePaint();
    org.jfree.data.category.DefaultCategoryDataset var27 = new org.jfree.data.category.DefaultCategoryDataset();
    int var29 = var27.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var30 = null;
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.renderer.category.BarRenderer var32 = new org.jfree.chart.renderer.category.BarRenderer();
    double var33 = var32.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var34 = var32.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var27, var30, var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var36.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var40 = var36.getLegendItems();
    java.lang.Object var41 = var40.clone();
    var35.setFixedLegendItems(var40);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var35.zoomRangeAxes((-1.0d), 10.0d, var45, var46);
    var35.clearDomainMarkers();
    org.jfree.chart.axis.AxisSpace var49 = null;
    var35.setFixedRangeAxisSpace(var49, true);
    java.awt.Image var52 = null;
    var35.setBackgroundImage(var52);
    org.jfree.chart.renderer.RenderAttributes var54 = new org.jfree.chart.renderer.RenderAttributes();
    org.jfree.chart.renderer.category.BarRenderer var55 = new org.jfree.chart.renderer.category.BarRenderer();
    double var56 = var55.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var57 = var55.getBarPainter();
    java.awt.Stroke var58 = var55.getBaseStroke();
    var54.setDefaultStroke(var58);
    var35.setRangeGridlineStroke(var58);
    var8.setDomainCrosshairStroke(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test146"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var5 = var4.getNextShape();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var8 = var6.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var9 = null;
    var6.setLegendItemURLGenerator(var9);
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var6.setBaseURLGenerator(var11, false);
    java.lang.Boolean var15 = var6.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var6.setSeriesURLGenerator(1, var17, true);
    boolean var20 = var6.getBaseLinesVisible();
    boolean var22 = var6.isSeriesItemLabelsVisible(2);
    java.awt.Paint var23 = var6.getBaseFillPaint();
    org.jfree.chart.renderer.RenderAttributes var24 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var26 = var24.getSeriesFillPaint(0);
    java.lang.Boolean var27 = var24.getDefaultLabelVisible();
    java.awt.Paint var30 = var24.getItemOutlinePaint(0, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var33 = var31.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var34 = null;
    var31.setLegendItemURLGenerator(var34);
    var31.removeAnnotations();
    java.awt.Stroke var37 = var31.getBaseStroke();
    var24.setDefaultOutlineStroke(var37);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var40 = var39.getAxisLinePaint();
    java.awt.Paint var41 = var39.getTickLabelPaint();
    org.jfree.chart.LegendItem var42 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "org.jfree.chart.event.ChartChangeEvent[source=1.0]", "Category Plot", "TextAnchor.BOTTOM_CENTER", var5, var23, var37, var41);
    org.jfree.chart.entity.ChartEntity var43 = new org.jfree.chart.entity.ChartEntity(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test147"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var1 = var0.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var2 = var0.getTickLabelInsets();
    java.awt.Paint var4 = var0.getTickLabelPaint((java.lang.Comparable)(-15466498));
    var0.setTickMarksVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test148"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    var0.removeAnnotations();
    var0.setAutoPopulateSeriesStroke(true);
    boolean var9 = var0.isSeriesItemLabelsVisible(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test149"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
    org.jfree.data.category.CategoryDataset var24 = var8.getDataset((-16777216));
    var8.clearDomainMarkers(5);
    boolean var27 = var8.isDomainZoomable();
    var8.setRangeMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test150() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test150"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    org.jfree.chart.util.RectangleEdge var15 = var8.getDomainAxisEdge((-1));
    org.jfree.chart.event.MarkerChangeEvent var16 = null;
    var8.markerChanged(var16);
    boolean var18 = var8.isDomainPannable();
    org.jfree.chart.axis.AxisLocation var20 = var8.getDomainAxisLocation(255);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test151"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
    org.jfree.data.category.CategoryDataset var24 = var8.getDataset((-16777216));
    var8.setRangeGridlinesVisible(true);
    int var27 = var8.getCrosshairDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test152"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.Range var22 = var8.getDataRange(var21);
    var8.clearRangeMarkers((-1));
    var8.setRangeCrosshairValue(100.0d);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var8.setFixedRangeAxisSpace(var27);
    var8.setBackgroundImageAlpha(1.0f);
    var8.clearRangeMarkers();
    org.jfree.data.category.CategoryDataset var32 = var8.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test153"); }
// 
// 
//     org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
//     org.jfree.chart.renderer.category.BarRenderer var1 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var2 = var1.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var3 = var1.getPositiveItemLabelPositionFallback();
//     int var4 = var1.getPassCount();
//     boolean var6 = var1.equals((java.lang.Object)"");
//     int var7 = var0.indexOf((java.lang.Object)var6);
//     java.lang.Object var8 = null;
//     int var9 = var0.indexOf(var8);
//     org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var17 = var16.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
//     org.jfree.chart.util.Layer var21 = null;
//     java.util.Collection var22 = var19.getRangeMarkers(0, var21);
//     var19.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var26 = null;
//     var19.setDomainAxis(2, var26, true);
//     var19.setOutlineVisible(false);
//     org.jfree.chart.event.AnnotationChangeEvent var31 = null;
//     var19.annotationChanged(var31);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var19.addChangeListener(var33);
//     java.awt.geom.GeneralPath var35 = null;
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.RenderingSource var37 = null;
//     var19.select(var35, var36, var37);
//     var0.set(11, (java.lang.Object)var36);
//     org.jfree.chart.util.ObjectList var41 = new org.jfree.chart.util.ObjectList(0);
//     java.lang.Object var43 = var41.get((-16645886));
//     java.lang.Object var44 = var41.clone();
//     java.lang.Object var45 = var41.clone();
//     int var46 = var0.indexOf(var45);
//     
//     // Checks the contract:  equals-hashcode on var0 and var41
//     assertTrue("Contract failed: equals-hashcode on var0 and var41", var0.equals(var41) ? var0.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var0
//     assertTrue("Contract failed: equals-hashcode on var41 and var0", var41.equals(var0) ? var41.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test154"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var11 = null;
    var0.setSeriesURLGenerator(1, var11, true);
    boolean var14 = var0.getBaseLinesVisible();
    boolean var16 = var0.isSeriesItemLabelsVisible(2);
    java.awt.Font var18 = var0.lookupLegendTextFont(1);
    var0.removeAnnotations();
    java.awt.Paint var20 = var0.getBasePaint();
    var0.setBaseShapesFilled(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test155"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleInsets var14 = var8.getAxisOffset();
    double var16 = var14.extendWidth(3.0d);
    double var17 = var14.getBottom();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 11.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 4.0d);

  }

  public void test156() {}
//   public void test156() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test156"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", var1);
// 
//   }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test157"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("Category Plot");
    java.lang.String var2 = var1.getLabel();
    boolean var3 = var1.isShapeOutlineVisible();
    java.lang.Comparable var4 = var1.getSeriesKey();
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.util.RectangleEdge var9 = null;
    double var10 = var5.getCategoryEnd(2, 0, var8, var9);
    java.lang.String var11 = var5.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
    int var14 = var12.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var15 = null;
    org.jfree.chart.axis.ValueAxis var16 = null;
    org.jfree.chart.renderer.category.BarRenderer var17 = new org.jfree.chart.renderer.category.BarRenderer();
    double var18 = var17.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var19 = var17.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var20 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var12, var15, var16, (org.jfree.chart.renderer.category.CategoryItemRenderer)var17);
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var23 = var21.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var21.getBaseItemLabelGenerator();
    var21.setShadowYOffset(0.2d);
    var20.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var21, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var31 = var29.getSeriesStroke(0);
    boolean var32 = var29.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var34 = var29.lookupSeriesFillPaint(10);
    var20.setDomainCrosshairPaint(var34);
    var5.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var20);
    double var37 = var5.getCategoryMargin();
    var5.setTickMarkOutsideLength((-1.0f));
    boolean var40 = var5.isVisible();
    java.awt.Paint var41 = var5.getLabelPaint();
    java.lang.Object var42 = var5.clone();
    org.jfree.chart.event.AxisChangeListener var43 = null;
    var5.removeChangeListener(var43);
    var5.setMinorTickMarkInsideLength(0.5f);
    var5.addCategoryLabelToolTip((java.lang.Comparable)11, "org.jfree.data.UnknownKeyException: ");
    boolean var50 = var5.isAxisLineVisible();
    java.awt.Font var51 = var5.getTickLabelFont();
    org.jfree.chart.axis.CategoryAxis var52 = new org.jfree.chart.axis.CategoryAxis();
    float var53 = var52.getTickMarkInsideLength();
    java.awt.Paint var54 = var52.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var58 = var56.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var59 = null;
    var56.setLegendItemURLGenerator(var59);
    org.jfree.chart.urls.CategoryURLGenerator var61 = null;
    var56.setBaseURLGenerator(var61, false);
    var56.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var66 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var68 = null;
    var66.setSeriesToolTipGenerator(0, var68, true);
    org.jfree.chart.labels.ItemLabelPosition var71 = var66.getBasePositiveItemLabelPosition();
    java.awt.Paint var72 = var66.getBaseFillPaint();
    var56.setBaseOutlinePaint(var72, false);
    boolean var75 = var56.getUseFillPaint();
    java.awt.Font var76 = var56.getBaseItemLabelFont();
    var55.setTickLabelFont(var76);
    var52.setTickLabelFont(var76);
    var5.setTickLabelFont(var76);
    var1.setLabelFont(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Category Plot"+ "'", var2.equals("Category Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test158"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    boolean var12 = var0.getItemShapeFilled((-1), 100);
    java.awt.Paint var16 = var0.getItemFillPaint(100, 0, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = null;
    var0.setBaseToolTipGenerator(var17);
    java.lang.Boolean var20 = null;
    var0.setSeriesShapesVisible(5, var20);
    boolean var22 = var0.getBaseSeriesVisibleInLegend();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var0.getSeriesToolTipGenerator((-83));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test159"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("rect", var1);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test160"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    float var1 = var0.getMinorTickMarkOutsideLength();
    var0.setAxisLineVisible(false);
    java.awt.Font var4 = var0.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test161"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Shape var4 = var0.getSeriesShape(0);
    var0.setDefaultCreateEntity((java.lang.Boolean)true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = null;
    var7.setSeriesToolTipGenerator(0, var9, true);
    org.jfree.chart.labels.ItemLabelPosition var12 = var7.getBasePositiveItemLabelPosition();
    java.awt.Paint var13 = var7.getBaseFillPaint();
    boolean var14 = var7.getBaseSeriesVisibleInLegend();
    var7.setSeriesShapesFilled(0, true);
    boolean var18 = var7.getAutoPopulateSeriesShape();
    java.awt.Shape var19 = var7.getBaseShape();
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var23 = null;
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
    double var26 = var25.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var27 = var25.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var20, var23, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var29.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var33 = var29.getLegendItems();
    java.lang.Object var34 = var33.clone();
    var28.setFixedLegendItems(var33);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    java.awt.geom.Point2D var39 = null;
    var28.zoomRangeAxes((-1.0d), 10.0d, var38, var39);
    var28.clearDomainMarkers();
    org.jfree.chart.axis.AxisSpace var42 = null;
    var28.setFixedRangeAxisSpace(var42, true);
    org.jfree.data.category.DefaultCategoryDataset var45 = new org.jfree.data.category.DefaultCategoryDataset();
    int var47 = var45.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.renderer.category.BarRenderer var50 = new org.jfree.chart.renderer.category.BarRenderer();
    double var51 = var50.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var52 = var50.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var53 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var45, var48, var49, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
    org.jfree.chart.util.Layer var55 = null;
    java.util.Collection var56 = var53.getRangeMarkers((-1), var55);
    org.jfree.chart.renderer.category.BarRenderer var57 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var60 = var57.getLegendItem(2, 100);
    java.awt.Stroke var61 = var57.getBaseStroke();
    var53.setRangeCrosshairStroke(var61);
    var28.setRangeCrosshairStroke(var61);
    org.jfree.chart.entity.PlotEntity var65 = new org.jfree.chart.entity.PlotEntity(var19, (org.jfree.chart.plot.Plot)var28, "UnitType.ABSOLUTE");
    var0.setDefaultShape(var19);
    org.jfree.chart.entity.ChartEntity var67 = new org.jfree.chart.entity.ChartEntity(var19);
    java.lang.String var68 = var67.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var68 + "' != '" + "rect"+ "'", var68.equals("rect"));

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test162"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var4 = var0.getUseSeriesOffset();
    boolean var5 = var0.getBaseItemLabelsVisible();
    boolean var6 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.labels.ItemLabelPosition var7 = var0.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test163"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    boolean var10 = var0.getShadowsVisible();
    org.jfree.chart.renderer.RenderAttributes var11 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var13 = var11.getSeriesPaint(100);
    java.awt.Paint var15 = var11.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var16.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var20 = var16.getUseSeriesOffset();
    java.awt.Paint var21 = var16.getBaseOutlinePaint();
    java.awt.Shape var22 = var16.getBaseShape();
    var11.setDefaultShape(var22);
    org.jfree.data.category.DefaultCategoryDataset var24 = new org.jfree.data.category.DefaultCategoryDataset();
    int var26 = var24.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    double var30 = var29.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var31 = var29.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var27, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var33.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var37 = var33.getLegendItems();
    java.lang.Object var38 = var37.clone();
    var32.setFixedLegendItems(var37);
    org.jfree.chart.entity.PlotEntity var41 = new org.jfree.chart.entity.PlotEntity(var22, (org.jfree.chart.plot.Plot)var32, "");
    var32.clearAnnotations();
    var0.setPlot(var32);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var32.zoomRangeAxes(10.0d, var45, var46);
    org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
    int var50 = var48.getColumnIndex((java.lang.Comparable)(byte)1);
    int var51 = var48.getRowCount();
    java.util.List var52 = var48.getColumnKeys();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = var32.getRendererForDataset((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.chart.axis.ValueAxis var55 = var32.getRangeAxisForDataset(5);
    org.jfree.chart.util.RectangleInsets var56 = var32.getInsets();
    double var58 = var56.calculateTopInset(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 4.0d);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test164"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
    java.util.EventListener var10 = null;
    boolean var11 = var0.hasListener(var10);
    var0.setSeriesVisibleInLegend(100, (java.lang.Boolean)true);
    var0.setAutoPopulateSeriesFillPaint(false);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var17 = var0.getLegendItemLabelGenerator();
    var0.setUseSeriesOffset(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test165"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.renderer.RenderAttributes var1 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var4 = var1.getItemPaint(0, (-1));
    java.awt.Paint var5 = var1.getDefaultLabelPaint();
    java.awt.Stroke var6 = var1.getDefaultOutlineStroke();
    boolean var7 = var0.equals((java.lang.Object)var1);
    java.awt.Paint var9 = var0.getPaint((-16620543));
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var14 = var12.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = null;
    var12.setLegendItemURLGenerator(var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    var12.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = null;
    var22.setSeriesToolTipGenerator(0, var24, true);
    org.jfree.chart.labels.ItemLabelPosition var27 = var22.getBasePositiveItemLabelPosition();
    java.awt.Paint var28 = var22.getBaseFillPaint();
    var12.setBaseOutlinePaint(var28, false);
    boolean var31 = var12.getUseFillPaint();
    java.awt.Font var32 = var12.getBaseItemLabelFont();
    var11.setTickLabelFont(var32);
    var11.setCategoryMargin(1.0d);
    var11.setTickMarkInsideLength(0.0f);
    org.jfree.chart.plot.DefaultDrawingSupplier var43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var44 = var43.getNextShape();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var47 = var45.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var48 = null;
    var45.setLegendItemURLGenerator(var48);
    org.jfree.chart.urls.CategoryURLGenerator var50 = null;
    var45.setBaseURLGenerator(var50, false);
    java.lang.Boolean var54 = var45.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var56 = null;
    var45.setSeriesURLGenerator(1, var56, true);
    boolean var59 = var45.getBaseLinesVisible();
    boolean var61 = var45.isSeriesItemLabelsVisible(2);
    java.awt.Paint var62 = var45.getBaseFillPaint();
    org.jfree.chart.renderer.RenderAttributes var63 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var65 = var63.getSeriesFillPaint(0);
    java.lang.Boolean var66 = var63.getDefaultLabelVisible();
    java.awt.Paint var69 = var63.getItemOutlinePaint(0, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var72 = var70.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var73 = null;
    var70.setLegendItemURLGenerator(var73);
    var70.removeAnnotations();
    java.awt.Stroke var76 = var70.getBaseStroke();
    var63.setDefaultOutlineStroke(var76);
    org.jfree.chart.axis.CategoryAxis var78 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.Paint var79 = var78.getAxisLinePaint();
    java.awt.Paint var80 = var78.getTickLabelPaint();
    org.jfree.chart.LegendItem var81 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "org.jfree.chart.event.ChartChangeEvent[source=1.0]", "Category Plot", "TextAnchor.BOTTOM_CENTER", var44, var62, var76, var80);
    var11.setTickLabelPaint((java.lang.Comparable)2.0d, var62);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-123), var62);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test166"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.Plot var16 = var8.getParent();
    boolean var17 = var8.isRangeMinorGridlinesVisible();
    boolean var18 = var8.isRangeZeroBaselineVisible();
    org.jfree.chart.plot.CategoryMarker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.addDomainMarker(var19, var20);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test167"); }


    org.jfree.chart.ChartColor var3 = new org.jfree.chart.ChartColor(2, 1, 2);
    int var4 = var3.getTransparency();
    int var5 = var3.getGreen();
    java.awt.color.ColorSpace var6 = var3.getColorSpace();
    java.awt.Color var7 = var3.darker();
    java.awt.color.ColorSpace var8 = var3.getColorSpace();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test168"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var6 = var4.getSeriesStroke(0);
    boolean var7 = var4.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var9 = var4.lookupSeriesFillPaint(10);
    var0.setShadowPaint(var9);
    org.jfree.chart.LegendItem var13 = var0.getLegendItem((-16777216), 15);
    java.awt.Stroke var15 = var0.lookupSeriesOutlineStroke(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test169"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var13 = null;
    org.jfree.chart.axis.ValueAxis var14 = null;
    org.jfree.chart.renderer.category.BarRenderer var15 = new org.jfree.chart.renderer.category.BarRenderer();
    double var16 = var15.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var17 = var15.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var10, var13, var14, (org.jfree.chart.renderer.category.CategoryItemRenderer)var15);
    float var19 = var18.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    int var23 = var18.indexOf((org.jfree.data.category.CategoryDataset)var20);
    org.jfree.chart.util.DefaultShadowGenerator var24 = new org.jfree.chart.util.DefaultShadowGenerator();
    java.awt.Color var25 = var24.getShadowColor();
    java.awt.Color var26 = var25.brighter();
    var18.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    var0.addChangeListener((org.jfree.chart.event.RendererChangeListener)var18);
    org.jfree.data.category.DefaultCategoryDataset var29 = new org.jfree.data.category.DefaultCategoryDataset();
    int var31 = var29.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var32 = null;
    org.jfree.chart.axis.ValueAxis var33 = null;
    org.jfree.chart.renderer.category.BarRenderer var34 = new org.jfree.chart.renderer.category.BarRenderer();
    double var35 = var34.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var36 = var34.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var37 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var29, var32, var33, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var38.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var42 = var38.getLegendItems();
    java.lang.Object var43 = var42.clone();
    var37.setFixedLegendItems(var42);
    org.jfree.chart.plot.PlotRenderingInfo var47 = null;
    java.awt.geom.Point2D var48 = null;
    var37.zoomRangeAxes((-1.0d), 10.0d, var47, var48);
    var37.clearDomainMarkers();
    org.jfree.data.event.DatasetChangeEvent var51 = null;
    var37.datasetChanged(var51);
    boolean var53 = var37.isDomainGridlinesVisible();
    org.jfree.chart.axis.ValueAxis var54 = var37.getRangeAxis();
    var0.setPlot(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test170"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers(0, var10);
    var8.setForegroundAlpha(100.0f);
    org.jfree.chart.util.RectangleInsets var14 = var8.getAxisOffset();
    org.jfree.chart.util.UnitType var15 = var14.getUnitType();
    java.lang.String var16 = var14.toString();
    java.lang.String var17 = var14.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var16.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"+ "'", var17.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test171"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    org.jfree.chart.util.StandardGradientPaintTransformer var2 = new org.jfree.chart.util.StandardGradientPaintTransformer(var1);
    org.jfree.chart.util.GradientPaintTransformType var3 = var2.getType();
    org.jfree.chart.util.GradientPaintTransformType var4 = var2.getType();
    org.jfree.data.category.DefaultCategoryDataset var5 = new org.jfree.data.category.DefaultCategoryDataset();
    int var7 = var5.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var8 = null;
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    double var11 = var10.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var12 = var10.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var5, var8, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var10);
    org.jfree.chart.util.Layer var15 = null;
    java.util.Collection var16 = var13.getRangeMarkers(0, var15);
    var13.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var20 = null;
    var13.setDomainAxis(2, var20, true);
    var13.setOutlineVisible(false);
    boolean var25 = var2.equals((java.lang.Object)var13);
    org.jfree.chart.util.GradientPaintTransformType var26 = var2.getType();
    org.jfree.chart.renderer.category.BarRenderer var27 = new org.jfree.chart.renderer.category.BarRenderer();
    double var28 = var27.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var29 = var27.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var30 = var27.getBaseItemLabelGenerator();
    var27.setMaximumBarWidth(0.0d);
    org.jfree.chart.util.ObjectList var33 = new org.jfree.chart.util.ObjectList();
    boolean var34 = var27.equals((java.lang.Object)var33);
    org.jfree.chart.urls.CategoryURLGenerator var38 = var27.getURLGenerator(4, 1, false);
    boolean var39 = var27.isDrawBarOutline();
    boolean var40 = var26.equals((java.lang.Object)var27);
    boolean var41 = var27.isDrawBarOutline();
    var27.setIncludeBaseInRange(true);
    org.jfree.chart.plot.DefaultDrawingSupplier var44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Shape var45 = var44.getNextShape();
    var27.setBaseShape(var45, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test172"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var0.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var4 = var0.getUseSeriesOffset();
    var0.setBaseShapesFilled(false);
    var0.setBaseShapesFilled(true);
    java.lang.Object var9 = var0.clone();
    java.lang.Boolean var11 = var0.getSeriesShapesVisible(11);
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test173"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var7 = var5.getSeriesStroke(0);
    boolean var8 = var5.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var10 = var5.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var11 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var4, var10);
    var11.setSeriesKey((java.lang.Comparable)true);
    var11.setDescription("hi!");
    int var16 = var11.getDatasetIndex();
    var11.setSeriesIndex(2);
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var21 = var19.getPositiveItemLabelPositionFallback();
    int var22 = var19.getPassCount();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var25 = var23.getSeriesStroke(0);
    boolean var26 = var23.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var28 = var23.lookupSeriesFillPaint(10);
    var19.setBaseItemLabelPaint(var28, false);
    var11.setLinePaint(var28);
    java.lang.Object var32 = var11.clone();
    var11.setSeriesKey((java.lang.Comparable)(-1.0d));
    java.lang.String var35 = var11.getLabel();
    java.lang.Comparable var36 = var11.getSeriesKey();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var37.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var41 = var37.getUseSeriesOffset();
    var37.setSeriesShapesFilled(1, (java.lang.Boolean)false);
    org.jfree.chart.labels.ItemLabelPosition var45 = var37.getBasePositiveItemLabelPosition();
    var37.setUseSeriesOffset(true);
    java.awt.Paint var51 = var37.getItemLabelPaint(0, (-1), false);
    var11.setLabelPaint(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + ""+ "'", var35.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + (-1.0d)+ "'", var36.equals((-1.0d)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test174"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
//     var0.setSeriesToolTipGenerator(0, var2, true);
//     org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
//     java.awt.Paint var6 = var0.getBaseFillPaint();
//     boolean var7 = var0.getBaseSeriesVisibleInLegend();
//     var0.setSeriesShapesFilled(0, true);
//     boolean var11 = var0.getAutoPopulateSeriesShape();
//     boolean var13 = var0.isSeriesVisible(255);
//     org.jfree.data.category.DefaultCategoryDataset var15 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var17 = var15.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var18 = null;
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var21 = var20.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var22 = var20.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var15, var18, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     float var24 = var23.getBackgroundImageAlpha();
//     org.jfree.data.category.DefaultCategoryDataset var25 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var27 = var25.getColumnIndex((java.lang.Comparable)(byte)1);
//     int var28 = var23.indexOf((org.jfree.data.category.CategoryDataset)var25);
//     java.awt.Stroke var29 = var23.getRangeMinorGridlineStroke();
//     var0.setSeriesOutlineStroke(10, var29, false);
//     org.jfree.chart.axis.CategoryAxis var33 = new org.jfree.chart.axis.CategoryAxis();
//     java.awt.geom.Rectangle2D var36 = null;
//     org.jfree.chart.util.RectangleEdge var37 = null;
//     double var38 = var33.getCategoryEnd(2, 0, var36, var37);
//     java.lang.String var39 = var33.getLabel();
//     org.jfree.data.category.DefaultCategoryDataset var40 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var42 = var40.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.chart.renderer.category.BarRenderer var45 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var46 = var45.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var47 = var45.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var48 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var40, var43, var44, (org.jfree.chart.renderer.category.CategoryItemRenderer)var45);
//     org.jfree.chart.renderer.category.BarRenderer var49 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var50 = var49.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var51 = var49.getPositiveItemLabelPositionFallback();
//     org.jfree.chart.labels.CategoryItemLabelGenerator var52 = var49.getBaseItemLabelGenerator();
//     var49.setShadowYOffset(0.2d);
//     var48.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var49, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var59 = var57.getSeriesStroke(0);
//     boolean var60 = var57.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var62 = var57.lookupSeriesFillPaint(10);
//     var48.setDomainCrosshairPaint(var62);
//     var33.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var48);
//     double var65 = var33.getCategoryMargin();
//     var33.setTickMarkOutsideLength((-1.0f));
//     boolean var68 = var33.isVisible();
//     java.awt.Paint var69 = var33.getLabelPaint();
//     boolean var70 = var33.isVisible();
//     java.awt.Font var71 = var33.getTickLabelFont();
//     var0.setSeriesItemLabelFont(3, var71, false);
//     
//     // Checks the contract:  equals-hashcode on var57 and var0
//     assertTrue("Contract failed: equals-hashcode on var57 and var0", var57.equals(var0) ? var57.hashCode() == var0.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var57 and var0.", var57.equals(var0) == var0.equals(var57));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test175"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    boolean var10 = var0.getShadowsVisible();
    org.jfree.chart.renderer.RenderAttributes var11 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var13 = var11.getSeriesPaint(100);
    java.awt.Paint var15 = var11.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var16.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var20 = var16.getUseSeriesOffset();
    java.awt.Paint var21 = var16.getBaseOutlinePaint();
    java.awt.Shape var22 = var16.getBaseShape();
    var11.setDefaultShape(var22);
    org.jfree.data.category.DefaultCategoryDataset var24 = new org.jfree.data.category.DefaultCategoryDataset();
    int var26 = var24.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var27 = null;
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.BarRenderer var29 = new org.jfree.chart.renderer.category.BarRenderer();
    double var30 = var29.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var31 = var29.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var24, var27, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var29);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var33.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var37 = var33.getLegendItems();
    java.lang.Object var38 = var37.clone();
    var32.setFixedLegendItems(var37);
    org.jfree.chart.entity.PlotEntity var41 = new org.jfree.chart.entity.PlotEntity(var22, (org.jfree.chart.plot.Plot)var32, "");
    var32.clearAnnotations();
    var0.setPlot(var32);
    org.jfree.chart.plot.PlotRenderingInfo var45 = null;
    java.awt.geom.Point2D var46 = null;
    var32.zoomRangeAxes(10.0d, var45, var46);
    org.jfree.data.category.DefaultCategoryDataset var48 = new org.jfree.data.category.DefaultCategoryDataset();
    int var50 = var48.getColumnIndex((java.lang.Comparable)(byte)1);
    int var51 = var48.getRowCount();
    java.util.List var52 = var48.getColumnKeys();
    org.jfree.chart.renderer.category.CategoryItemRenderer var53 = var32.getRendererForDataset((org.jfree.data.category.CategoryDataset)var48);
    org.jfree.chart.axis.ValueAxis var55 = var32.getRangeAxisForDataset(5);
    org.jfree.chart.renderer.category.CategoryItemRenderer var56 = var32.getRenderer();
    org.jfree.chart.plot.Marker var57 = null;
    org.jfree.chart.util.Layer var58 = null;
    boolean var59 = var32.removeDomainMarker(var57, var58);
    var32.setCrosshairDatasetIndex((-97), false);
    org.jfree.chart.plot.CategoryMarker var64 = null;
    org.jfree.chart.util.Layer var65 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var32.addDomainMarker(0, var64, var65);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test176"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var2 = var0.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
//     var0.setLegendItemURLGenerator(var3);
//     org.jfree.chart.urls.CategoryURLGenerator var5 = null;
//     var0.setBaseURLGenerator(var5, false);
//     var0.setAutoPopulateSeriesPaint(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var12 = null;
//     var10.setSeriesToolTipGenerator(0, var12, true);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var10.getBasePositiveItemLabelPosition();
//     java.awt.Paint var16 = var10.getBaseFillPaint();
//     var0.setBaseOutlinePaint(var16, false);
//     var0.setItemLabelAnchorOffset(10.0d);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var0.getPositiveItemLabelPosition((-16620543), (-16620543), false);
//     
//     // Checks the contract:  equals-hashcode on var15 and var24
//     assertTrue("Contract failed: equals-hashcode on var15 and var24", var15.equals(var24) ? var15.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var15
//     assertTrue("Contract failed: equals-hashcode on var24 and var15", var24.equals(var15) ? var24.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test177"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.util.Layer var10 = null;
//     java.util.Collection var11 = var8.getRangeMarkers(0, var10);
//     var8.setForegroundAlpha(100.0f);
//     org.jfree.chart.axis.CategoryAxis var15 = null;
//     var8.setDomainAxis(2, var15, true);
//     boolean var18 = var8.isDomainZoomable();
//     java.awt.Font var19 = var8.getNoDataMessageFont();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var24 = var22.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = null;
//     var22.setLegendItemURLGenerator(var25);
//     org.jfree.chart.urls.CategoryURLGenerator var27 = null;
//     var22.setBaseURLGenerator(var27, false);
//     var22.setAutoPopulateSeriesPaint(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var34 = null;
//     var32.setSeriesToolTipGenerator(0, var34, true);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var32.getBasePositiveItemLabelPosition();
//     java.awt.Paint var38 = var32.getBaseFillPaint();
//     var22.setBaseOutlinePaint(var38, false);
//     boolean var41 = var22.getUseFillPaint();
//     java.awt.Font var42 = var22.getBaseItemLabelFont();
//     var21.setTickLabelFont(var42);
//     boolean var44 = var21.isVisible();
//     var8.setDomainAxis(3, var21, true);
//     org.jfree.chart.util.Layer var48 = null;
//     java.util.Collection var49 = var8.getDomainMarkers((-97), var48);
//     var8.setAnchorValue(11.0d);
//     java.awt.Graphics2D var52 = null;
//     java.awt.geom.Rectangle2D var53 = null;
//     var8.drawBackground(var52, var53);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test178"); }


    org.jfree.chart.plot.DefaultDrawingSupplier var0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var1 = var0.getNextPaint();
    java.awt.Shape var2 = var0.getNextShape();
    java.awt.Paint var3 = var0.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test179"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
    var0.setUseFillPaint(true);
    java.awt.Paint var9 = var0.getLegendTextPaint((-16620543));
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var10.getCategoryEnd(2, 0, var13, var14);
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers(0, var26);
    var24.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    var24.setDomainAxis(2, var31, true);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var24.zoomDomainAxes(0.0d, var35, var36, false);
    var10.setPlot((org.jfree.chart.plot.Plot)var24);
    var0.setPlot(var24);
    org.jfree.chart.renderer.category.BarRenderer var41 = new org.jfree.chart.renderer.category.BarRenderer();
    double var42 = var41.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var43 = var41.getPositiveItemLabelPositionFallback();
    var41.setShadowXOffset(10.0d);
    org.jfree.data.category.DefaultCategoryDataset var46 = new org.jfree.data.category.DefaultCategoryDataset();
    int var48 = var46.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var49 = new org.jfree.data.general.DatasetGroup();
    var46.setGroup(var49);
    org.jfree.data.Range var52 = var41.findRangeBounds((org.jfree.data.category.CategoryDataset)var46, false);
    java.awt.Paint var53 = var41.getBaseOutlinePaint();
    var24.setDomainGridlinePaint(var53);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var57 = var55.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var58 = null;
    var55.setLegendItemURLGenerator(var58);
    org.jfree.chart.urls.CategoryURLGenerator var60 = null;
    var55.setBaseURLGenerator(var60, false);
    java.lang.Boolean var64 = var55.getSeriesVisibleInLegend((-1));
    org.jfree.chart.urls.CategoryURLGenerator var66 = null;
    var55.setSeriesURLGenerator(1, var66, true);
    boolean var69 = var55.getBaseLinesVisible();
    boolean var71 = var55.isSeriesItemLabelsVisible(2);
    java.awt.Font var73 = var55.lookupLegendTextFont(1);
    var55.removeAnnotations();
    int var75 = var55.getColumnCount();
    java.lang.Object var76 = var55.clone();
    int var77 = var24.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == (-1));

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test180"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    float var8 = var7.getTickMarkInsideLength();
    java.awt.Paint var9 = var7.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var10.getCategoryEnd(2, 0, var13, var14);
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers(0, var26);
    var24.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    var24.setDomainAxis(2, var31, true);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var24.zoomDomainAxes(0.0d, var35, var36, false);
    var10.setPlot((org.jfree.chart.plot.Plot)var24);
    java.awt.Paint var40 = var10.getTickLabelPaint();
    var7.setTickLabelPaint(var40);
    var0.setShadowPaint(var40);
    java.awt.Stroke var44 = var0.getSeriesStroke(0);
    java.awt.Paint var45 = var0.getBaseOutlinePaint();
    java.awt.Paint var47 = var0.lookupSeriesFillPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test181"); }


    org.jfree.data.KeyedObjects var0 = new org.jfree.data.KeyedObjects();
    java.lang.Object var1 = var0.clone();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis();
    float var5 = var4.getMinorTickMarkOutsideLength();
    double var6 = var4.getLowerMargin();
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var10 = null;
    org.jfree.chart.util.RectangleEdge var11 = null;
    double var12 = var7.getCategoryEnd(2, 0, var10, var11);
    java.lang.String var13 = var7.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var14 = new org.jfree.data.category.DefaultCategoryDataset();
    int var16 = var14.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.BarRenderer var19 = new org.jfree.chart.renderer.category.BarRenderer();
    double var20 = var19.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var21 = var19.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var14, var17, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var19);
    org.jfree.chart.renderer.category.BarRenderer var23 = new org.jfree.chart.renderer.category.BarRenderer();
    double var24 = var23.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var25 = var23.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var26 = var23.getBaseItemLabelGenerator();
    var23.setShadowYOffset(0.2d);
    var22.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var23, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var33 = var31.getSeriesStroke(0);
    boolean var34 = var31.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var36 = var31.lookupSeriesFillPaint(10);
    var22.setDomainCrosshairPaint(var36);
    var7.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var22);
    double var39 = var7.getCategoryMargin();
    java.lang.String var40 = var7.getLabel();
    org.jfree.chart.util.RectangleInsets var41 = var7.getTickLabelInsets();
    var4.setTickLabelInsets(var41);
    double var43 = var41.getTop();
    java.lang.String var44 = var41.toString();
    var0.insertValue(0, (java.lang.Comparable)"org.jfree.chart.event.ChartChangeEvent[source=1.0]", (java.lang.Object)var41);
    org.jfree.data.general.DatasetGroup var48 = new org.jfree.data.general.DatasetGroup("rect");
    java.lang.String var49 = var48.getID();
    var0.addObject((java.lang.Comparable)"DatasetRenderingOrder.REVERSE", (java.lang.Object)var48);
    org.jfree.data.category.DefaultCategoryDataset var51 = new org.jfree.data.category.DefaultCategoryDataset();
    int var53 = var51.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.category.BarRenderer var56 = new org.jfree.chart.renderer.category.BarRenderer();
    double var57 = var56.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var58 = var56.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var59 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var51, var54, var55, (org.jfree.chart.renderer.category.CategoryItemRenderer)var56);
    org.jfree.chart.util.Layer var61 = null;
    java.util.Collection var62 = var59.getRangeMarkers(0, var61);
    var59.setForegroundAlpha(100.0f);
    org.jfree.chart.event.AxisChangeEvent var65 = null;
    var59.axisChanged(var65);
    org.jfree.chart.util.SortOrder var67 = var59.getRowRenderingOrder();
    java.lang.Object var68 = null;
    boolean var69 = var67.equals(var68);
    var0.sortByObjects(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"+ "'", var44.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + "rect"+ "'", var49.equals("rect"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test182"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    float var9 = var8.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var10 = new org.jfree.data.category.DefaultCategoryDataset();
    int var12 = var10.getColumnIndex((java.lang.Comparable)(byte)1);
    int var13 = var8.indexOf((org.jfree.data.category.CategoryDataset)var10);
    int var15 = var10.getColumnIndex((java.lang.Comparable)"PlotEntity: tooltip = ");
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers((-1), var26);
    org.jfree.chart.renderer.category.BarRenderer var28 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var31 = var28.getLegendItem(2, 100);
    java.awt.Stroke var32 = var28.getBaseStroke();
    var24.setRangeCrosshairStroke(var32);
    boolean var34 = var10.equals((java.lang.Object)var24);
    var10.setValue(0.0d, (java.lang.Comparable)0L, (java.lang.Comparable)0.5f);
    org.jfree.data.category.CategoryDatasetSelectionState var39 = null;
    var10.setSelectionState(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test183"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    org.jfree.chart.renderer.category.BarRenderer var6 = new org.jfree.chart.renderer.category.BarRenderer();
    double var7 = var6.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var8 = var6.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = var6.getBaseItemLabelGenerator();
    var6.setMaximumBarWidth(0.0d);
    java.awt.Paint var13 = var6.getLegendTextPaint(1);
    java.awt.Paint var15 = var6.getLegendTextPaint(100);
    boolean var16 = var0.equals((java.lang.Object)var6);
    org.jfree.data.category.DefaultCategoryDataset var17 = new org.jfree.data.category.DefaultCategoryDataset();
    int var19 = var17.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.BarRenderer var22 = new org.jfree.chart.renderer.category.BarRenderer();
    double var23 = var22.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var24 = var22.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var17, var20, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    org.jfree.chart.util.Layer var27 = null;
    java.util.Collection var28 = var25.getRangeMarkers((-1), var27);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var25);
    double var30 = var0.getCategoryMargin();
    java.awt.Paint var31 = var0.getAxisLinePaint();
    org.jfree.chart.util.RectangleInsets var32 = var0.getTickLabelInsets();
    java.awt.Shape var37 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var40 = var38.getSeriesStroke(0);
    boolean var41 = var38.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var43 = var38.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var37, var43);
    var44.setSeriesKey((java.lang.Comparable)true);
    java.lang.Comparable var47 = var44.getSeriesKey();
    boolean var48 = var44.isLineVisible();
    boolean var49 = var44.isShapeFilled();
    boolean var50 = var0.equals((java.lang.Object)var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + true+ "'", var47.equals(true));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test184"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    float var1 = var0.getMinorTickMarkOutsideLength();
    double var2 = var0.getLowerMargin();
    org.jfree.chart.util.RectangleInsets var3 = var0.getTickLabelInsets();
    org.jfree.chart.util.RectangleInsets var4 = var0.getLabelInsets();
    var0.setVisible(false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var10 = null;
    var8.setSeriesToolTipGenerator(0, var10, true);
    org.jfree.chart.labels.ItemLabelPosition var13 = var8.getBasePositiveItemLabelPosition();
    java.awt.Paint var14 = var8.getBaseFillPaint();
    boolean var15 = var8.getBaseSeriesVisibleInLegend();
    var8.setSeriesShapesFilled(0, true);
    boolean var19 = var8.getAutoPopulateSeriesShape();
    boolean var20 = var8.getAutoPopulateSeriesShape();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var23 = var21.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var24 = null;
    var21.setLegendItemURLGenerator(var24);
    org.jfree.chart.urls.CategoryURLGenerator var26 = null;
    var21.setBaseURLGenerator(var26, false);
    java.lang.Boolean var30 = var21.getSeriesVisibleInLegend((-1));
    boolean var33 = var21.getItemShapeFilled((-1), 100);
    java.awt.Paint var37 = var21.getItemFillPaint(100, 0, true);
    java.awt.Paint var39 = var21.lookupSeriesPaint((-1));
    var8.setBaseOutlinePaint(var39, false);
    var0.setTickLabelPaint((java.lang.Comparable)(-15.8d), var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test185() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test185"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var3 = null;
    org.jfree.chart.util.RectangleEdge var4 = null;
    double var5 = var0.getCategoryEnd(2, 0, var3, var4);
    java.lang.String var6 = var0.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var7 = new org.jfree.data.category.DefaultCategoryDataset();
    int var9 = var7.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    double var13 = var12.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var14 = var12.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var7, var10, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var18 = var16.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = var16.getBaseItemLabelGenerator();
    var16.setShadowYOffset(0.2d);
    var15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var16, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var26 = var24.getSeriesStroke(0);
    boolean var27 = var24.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var29 = var24.lookupSeriesFillPaint(10);
    var15.setDomainCrosshairPaint(var29);
    var0.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var15);
    boolean var32 = var15.isSubplot();
    java.awt.Image var33 = var15.getBackgroundImage();
    org.jfree.chart.util.Layer var34 = null;
    java.util.Collection var35 = var15.getRangeMarkers(var34);
    org.jfree.chart.util.SortOrder var36 = var15.getRowRenderingOrder();
    var15.setDomainCrosshairRowKey((java.lang.Comparable)0.5f);
    double var39 = var15.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0d);

  }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test186"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    org.jfree.chart.renderer.RenderAttributes var2 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var5 = var2.getItemPaint(0, (-1));
    java.awt.Paint var6 = var2.getDefaultLabelPaint();
    java.awt.Stroke var7 = var2.getDefaultOutlineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var11 = null;
    var9.setSeriesToolTipGenerator(0, var11, true);
    org.jfree.chart.labels.ItemLabelPosition var14 = var9.getBasePositiveItemLabelPosition();
    java.awt.Paint var15 = var9.getBaseFillPaint();
    boolean var16 = var9.getBaseSeriesVisibleInLegend();
    var9.setSeriesShapesFilled(0, true);
    boolean var20 = var9.getAutoPopulateSeriesShape();
    boolean var21 = var9.getAutoPopulateSeriesShape();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var24 = var22.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var25 = null;
    var22.setLegendItemURLGenerator(var25);
    org.jfree.chart.urls.CategoryURLGenerator var27 = null;
    var22.setBaseURLGenerator(var27, false);
    java.lang.Boolean var31 = var22.getSeriesVisibleInLegend((-1));
    boolean var34 = var22.getItemShapeFilled((-1), 100);
    java.awt.Paint var38 = var22.getItemFillPaint(100, 0, true);
    java.awt.Paint var40 = var22.lookupSeriesPaint((-1));
    var9.setBaseOutlinePaint(var40, false);
    var2.setSeriesOutlinePaint(10, var40);
    var2.setDefaultCreateEntity((java.lang.Boolean)false);
    boolean var46 = var0.equals((java.lang.Object)false);
    java.awt.Stroke var48 = var0.getStroke(0);
    java.lang.Object var49 = null;
    boolean var50 = var0.equals(var49);
    int var51 = var0.size();
    java.awt.Stroke var53 = var0.getStroke(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var53);

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test187"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var13 = var0.getItemStroke(10, 1, false);
    org.jfree.chart.renderer.category.BarRenderer var14 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var17 = var14.getLegendItem(2, 100);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var18 = var14.getLegendItemLabelGenerator();
    var0.setLegendItemToolTipGenerator(var18);
    org.jfree.data.category.DefaultCategoryDataset var20 = new org.jfree.data.category.DefaultCategoryDataset();
    int var22 = var20.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var23 = new org.jfree.data.general.DatasetGroup();
    var20.setGroup(var23);
    int var26 = var20.getRowIndex((java.lang.Comparable)(short)100);
    org.jfree.data.Range var27 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var20);
    org.jfree.data.event.DatasetChangeListener var28 = null;
    var20.addChangeListener(var28);
    org.jfree.chart.renderer.RenderAttributes var30 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var32 = var30.getSeriesPaint(100);
    java.awt.Paint var34 = var30.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var35.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var39 = var35.getUseSeriesOffset();
    java.awt.Paint var40 = var35.getBaseOutlinePaint();
    java.awt.Shape var41 = var35.getBaseShape();
    var30.setDefaultShape(var41);
    org.jfree.data.category.DefaultCategoryDataset var43 = new org.jfree.data.category.DefaultCategoryDataset();
    int var45 = var43.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var46 = null;
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.category.BarRenderer var48 = new org.jfree.chart.renderer.category.BarRenderer();
    double var49 = var48.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var50 = var48.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var43, var46, var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var48);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var52.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var56 = var52.getLegendItems();
    java.lang.Object var57 = var56.clone();
    var51.setFixedLegendItems(var56);
    org.jfree.chart.entity.PlotEntity var60 = new org.jfree.chart.entity.PlotEntity(var41, (org.jfree.chart.plot.Plot)var51, "");
    org.jfree.data.category.DefaultCategoryDataset var63 = new org.jfree.data.category.DefaultCategoryDataset();
    int var65 = var63.getColumnIndex((java.lang.Comparable)(byte)1);
    int var66 = var63.getRowCount();
    java.util.List var67 = var63.getColumnKeys();
    org.jfree.chart.entity.CategoryItemEntity var70 = new org.jfree.chart.entity.CategoryItemEntity(var41, "org.jfree.chart.ChartColor[r=2,g=1,b=2]", "", (org.jfree.data.category.CategoryDataset)var63, (java.lang.Comparable)(byte)100, (java.lang.Comparable)2);
    var63.setValue(Double.NaN, (java.lang.Comparable)"SortOrder.ASCENDING", (java.lang.Comparable)false);
    int var75 = var63.getColumnCount();
    var20.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState)var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test188"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    var0.setMaximumBarWidth(0.0d);
    org.jfree.chart.util.ObjectList var6 = new org.jfree.chart.util.ObjectList();
    boolean var7 = var0.equals((java.lang.Object)var6);
    org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getURLGenerator(4, 1, false);
    boolean var12 = var0.isDrawBarOutline();
    java.awt.Paint var16 = var0.getItemLabelPaint(0, 0, false);
    var0.setShadowXOffset(4.0d);
    var0.setMaximumBarWidth((-9.8d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test189"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var9 = var5.getUseSeriesOffset();
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    java.awt.Shape var11 = var5.getBaseShape();
    var0.setDefaultShape(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
    java.lang.Object var27 = var26.clone();
    var21.setFixedLegendItems(var26);
    org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
    var21.clearAnnotations();
    int var32 = var21.getDatasetCount();
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.plot.PlotRenderingInfo var36 = null;
    org.jfree.chart.plot.CategoryCrosshairState var37 = null;
    boolean var38 = var21.render(var33, var34, 5, var36, var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test190"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    float var16 = var8.getForegroundAlpha();
    java.lang.Object var17 = null;
    boolean var18 = var8.equals(var17);
    org.jfree.chart.plot.PlotRenderingInfo var20 = null;
    java.awt.geom.Point2D var21 = null;
    var8.panDomainAxes(1.0d, var20, var21);
    int var23 = var8.getRendererCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test191"); }
// 
// 
//     org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.chart.axis.CategoryAxis var3 = null;
//     org.jfree.chart.axis.ValueAxis var4 = null;
//     org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var6 = var5.getItemMargin();
//     org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
//     org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
//     java.lang.Object var14 = var13.clone();
//     var8.setFixedLegendItems(var13);
//     org.jfree.chart.plot.PlotRenderingInfo var18 = null;
//     java.awt.geom.Point2D var19 = null;
//     var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
//     org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
//     java.lang.Comparable var23 = var8.getDomainCrosshairRowKey();
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var27 = var25.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var28 = null;
//     var25.setLegendItemURLGenerator(var28);
//     org.jfree.chart.urls.CategoryURLGenerator var30 = null;
//     var25.setBaseURLGenerator(var30, false);
//     var25.setAutoPopulateSeriesPaint(true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var37 = null;
//     var35.setSeriesToolTipGenerator(0, var37, true);
//     org.jfree.chart.labels.ItemLabelPosition var40 = var35.getBasePositiveItemLabelPosition();
//     java.awt.Paint var41 = var35.getBaseFillPaint();
//     var25.setBaseOutlinePaint(var41, false);
//     boolean var44 = var25.getUseFillPaint();
//     java.awt.Font var45 = var25.getBaseItemLabelFont();
//     var24.setTickLabelFont(var45);
//     var24.setCategoryMargin(1.0d);
//     java.lang.String var49 = var24.getLabelURL();
//     java.awt.Paint var51 = var24.getTickLabelPaint((java.lang.Comparable)'#');
//     var8.setBackgroundPaint(var51);
//     
//     // Checks the contract:  equals-hashcode on var35 and var9
//     assertTrue("Contract failed: equals-hashcode on var35 and var9", var35.equals(var9) ? var35.hashCode() == var9.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var35 and var9.", var35.equals(var9) == var9.equals(var35));
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test192"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var2 = null;
    var0.setSeriesToolTipGenerator(0, var2, true);
    org.jfree.chart.labels.ItemLabelPosition var5 = var0.getBasePositiveItemLabelPosition();
    int var6 = var0.getColumnCount();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var0.setBaseToolTipGenerator(var7, true);
    org.jfree.chart.urls.CategoryURLGenerator var10 = null;
    var0.setBaseURLGenerator(var10, false);
    org.jfree.chart.plot.CategoryPlot var13 = var0.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test193"); }


    org.jfree.chart.axis.CategoryAxis var0 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var3 = var1.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var4 = null;
    var1.setLegendItemURLGenerator(var4);
    org.jfree.chart.urls.CategoryURLGenerator var6 = null;
    var1.setBaseURLGenerator(var6, false);
    var1.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var13 = null;
    var11.setSeriesToolTipGenerator(0, var13, true);
    org.jfree.chart.labels.ItemLabelPosition var16 = var11.getBasePositiveItemLabelPosition();
    java.awt.Paint var17 = var11.getBaseFillPaint();
    var1.setBaseOutlinePaint(var17, false);
    boolean var20 = var1.getUseFillPaint();
    java.awt.Font var21 = var1.getBaseItemLabelFont();
    var0.setTickLabelFont(var21);
    org.jfree.chart.plot.Plot var23 = var0.getPlot();
    org.jfree.chart.axis.CategoryLabelPositions var24 = var0.getCategoryLabelPositions();
    java.awt.Font var26 = var0.getTickLabelFont((java.lang.Comparable)4.0d);
    var0.setTickMarksVisible(false);
    java.lang.String var29 = var0.getLabelToolTip();
    var0.setTickMarkOutsideLength(0.5f);
    double var32 = var0.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.2d);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test194"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    float var8 = var7.getTickMarkInsideLength();
    java.awt.Paint var9 = var7.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var10.getCategoryEnd(2, 0, var13, var14);
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers(0, var26);
    var24.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    var24.setDomainAxis(2, var31, true);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var24.zoomDomainAxes(0.0d, var35, var36, false);
    var10.setPlot((org.jfree.chart.plot.Plot)var24);
    java.awt.Paint var40 = var10.getTickLabelPaint();
    var7.setTickLabelPaint(var40);
    var0.setShadowPaint(var40);
    java.awt.Stroke var44 = var0.getSeriesStroke(0);
    boolean var45 = var0.getDataBoundsIncludesVisibleSeriesOnly();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test195"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var4 = var0.getURLGenerator((-1), 0, true);
    java.awt.Paint var6 = var0.getLegendTextPaint((-16777216));
    org.jfree.chart.axis.CategoryAxis var7 = new org.jfree.chart.axis.CategoryAxis();
    float var8 = var7.getTickMarkInsideLength();
    java.awt.Paint var9 = var7.getLabelPaint();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.util.RectangleEdge var14 = null;
    double var15 = var10.getCategoryEnd(2, 0, var13, var14);
    org.jfree.data.category.DefaultCategoryDataset var16 = new org.jfree.data.category.DefaultCategoryDataset();
    int var18 = var16.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var19 = null;
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer var21 = new org.jfree.chart.renderer.category.BarRenderer();
    double var22 = var21.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var23 = var21.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var16, var19, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    org.jfree.chart.util.Layer var26 = null;
    java.util.Collection var27 = var24.getRangeMarkers(0, var26);
    var24.setForegroundAlpha(100.0f);
    org.jfree.chart.axis.CategoryAxis var31 = null;
    var24.setDomainAxis(2, var31, true);
    org.jfree.chart.plot.PlotRenderingInfo var35 = null;
    java.awt.geom.Point2D var36 = null;
    var24.zoomDomainAxes(0.0d, var35, var36, false);
    var10.setPlot((org.jfree.chart.plot.Plot)var24);
    java.awt.Paint var40 = var10.getTickLabelPaint();
    var7.setTickLabelPaint(var40);
    var0.setShadowPaint(var40);
    java.awt.Stroke var44 = var0.getSeriesOutlineStroke((-2));
    java.lang.Boolean var46 = var0.getSeriesItemLabelsVisible(0);
    var0.setBaseCreateEntities(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test196"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var2 = var0.getSeriesStroke(0);
//     boolean var3 = var0.getDataBoundsIncludesVisibleSeriesOnly();
//     java.awt.Paint var5 = var0.lookupSeriesFillPaint(10);
//     org.jfree.chart.labels.CategoryToolTipGenerator var9 = var0.getToolTipGenerator(1, (-1), true);
//     java.awt.Shape var11 = var0.getSeriesShape(10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     org.jfree.chart.labels.CategoryToolTipGenerator var14 = null;
//     var12.setSeriesToolTipGenerator(0, var14, true);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var12.getBasePositiveItemLabelPosition();
//     var0.setBasePositiveItemLabelPosition(var17);
//     java.lang.Object var19 = var0.clone();
//     double var20 = var0.getItemMargin();
//     boolean var21 = var0.getUseOutlinePaint();
//     java.awt.Paint var23 = var0.getSeriesOutlinePaint((-254));
//     org.jfree.chart.renderer.category.BarRenderer var25 = new org.jfree.chart.renderer.category.BarRenderer();
//     double var26 = var25.getItemMargin();
//     org.jfree.chart.labels.ItemLabelPosition var27 = var25.getPositiveItemLabelPositionFallback();
//     var25.setShadowXOffset(10.0d);
//     org.jfree.data.category.DefaultCategoryDataset var30 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var32 = var30.getColumnIndex((java.lang.Comparable)(byte)1);
//     org.jfree.data.general.DatasetGroup var33 = new org.jfree.data.general.DatasetGroup();
//     var30.setGroup(var33);
//     org.jfree.data.Range var36 = var25.findRangeBounds((org.jfree.data.category.CategoryDataset)var30, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//     java.awt.Stroke var39 = var37.getSeriesStroke(0);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var40 = null;
//     var37.setLegendItemURLGenerator(var40);
//     org.jfree.chart.urls.CategoryURLGenerator var42 = null;
//     var37.setBaseURLGenerator(var42, false);
//     var37.setAutoPopulateSeriesPaint(true);
//     java.awt.Stroke var48 = null;
//     var37.setSeriesOutlineStroke(10, var48, false);
//     int var51 = var37.getPassCount();
//     org.jfree.chart.labels.ItemLabelPosition var55 = var37.getPositiveItemLabelPosition(2, 10, true);
//     org.jfree.chart.labels.ItemLabelAnchor var56 = var55.getItemLabelAnchor();
//     var25.setBasePositiveItemLabelPosition(var55);
//     var0.setSeriesPositiveItemLabelPosition(3, var55);
//     
//     // Checks the contract:  equals-hashcode on var12 and var37
//     assertTrue("Contract failed: equals-hashcode on var12 and var37", var12.equals(var37) ? var12.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var0
//     assertTrue("Contract failed: equals-hashcode on var37 and var0", var37.equals(var0) ? var37.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var12
//     assertTrue("Contract failed: equals-hashcode on var37 and var12", var37.equals(var12) ? var37.hashCode() == var12.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var12 and var0.", var12.equals(var0) == var0.equals(var12));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var37 and var0.", var37.equals(var0) == var0.equals(var37));
//     
//     // Checks the contract:  equals-hashcode on var17 and var55
//     assertTrue("Contract failed: equals-hashcode on var17 and var55", var17.equals(var55) ? var17.hashCode() == var55.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var55 and var17
//     assertTrue("Contract failed: equals-hashcode on var55 and var17", var55.equals(var17) ? var55.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test197"); }


    org.jfree.chart.util.StandardGradientPaintTransformer var0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var1 = var0.getType();
    java.lang.String var2 = var1.toString();
    org.jfree.chart.util.StandardGradientPaintTransformer var3 = new org.jfree.chart.util.StandardGradientPaintTransformer(var1);
    java.lang.Object var4 = null;
    boolean var5 = var3.equals(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var2.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test198"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0.5f);
    int var3 = var0.getColumnCount();
    java.util.List var4 = var0.getRowKeys();
    int var5 = var0.getColumnCount();
    java.util.List var6 = var0.getColumnKeys();
    int var8 = var0.getColumnIndex((java.lang.Comparable)100L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test199"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var10 = null;
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers((-1), var21);
    org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var10, var19, var24, var25, var26);
    var19.setDomainCrosshairColumnKey((java.lang.Comparable)2.0f, true);
    org.jfree.chart.renderer.category.BarRenderer var31 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var35 = var31.getURLGenerator((-1), 0, true);
    java.awt.Paint var37 = var31.getLegendTextPaint((-16777216));
    java.awt.Paint var41 = var31.getItemFillPaint((-16777216), 100, true);
    var19.setRangeZeroBaselinePaint(var41);
    org.jfree.chart.plot.PlotRenderingInfo var44 = null;
    java.awt.geom.Point2D var45 = null;
    var19.zoomDomainAxes(0.0d, var44, var45, true);
    boolean var48 = var19.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test200"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    int var1 = var0.size();
    java.awt.Stroke var3 = var0.getStroke((-16777216));
    org.jfree.chart.renderer.category.BarRenderer var4 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.urls.CategoryURLGenerator var8 = var4.getURLGenerator((-1), 0, true);
    double var9 = var4.getMinimumBarLength();
    org.jfree.chart.renderer.category.BarRenderer var10 = new org.jfree.chart.renderer.category.BarRenderer();
    double var11 = var10.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var12 = var10.getBarPainter();
    org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(var12);
    var4.setBarPainter(var12);
    boolean var15 = var0.equals((java.lang.Object)var4);
    org.jfree.chart.util.StandardGradientPaintTransformer var16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    org.jfree.chart.util.GradientPaintTransformType var17 = var16.getType();
    java.lang.String var18 = var17.toString();
    java.lang.String var19 = var17.toString();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var22 = var20.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var23 = null;
    var20.setLegendItemURLGenerator(var23);
    org.jfree.chart.urls.CategoryURLGenerator var25 = null;
    var20.setBaseURLGenerator(var25, false);
    java.lang.Boolean var29 = var20.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var30 = null;
    org.jfree.data.category.DefaultCategoryDataset var31 = new org.jfree.data.category.DefaultCategoryDataset();
    int var33 = var31.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.renderer.category.BarRenderer var36 = new org.jfree.chart.renderer.category.BarRenderer();
    double var37 = var36.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var38 = var36.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var39 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var31, var34, var35, (org.jfree.chart.renderer.category.CategoryItemRenderer)var36);
    org.jfree.chart.util.Layer var41 = null;
    java.util.Collection var42 = var39.getRangeMarkers((-1), var41);
    org.jfree.chart.LegendItemCollection var43 = var39.getLegendItems();
    org.jfree.chart.axis.ValueAxis var44 = null;
    org.jfree.chart.plot.Marker var45 = null;
    java.awt.geom.Rectangle2D var46 = null;
    var20.drawRangeMarker(var30, var39, var44, var45, var46);
    var39.setDomainCrosshairColumnKey((java.lang.Comparable)2.0f, true);
    java.awt.Stroke var51 = var39.getRangeGridlineStroke();
    var39.setWeight((-2));
    org.jfree.chart.plot.Marker var55 = null;
    org.jfree.chart.util.Layer var56 = null;
    boolean var58 = var39.removeDomainMarker((-15466498), var55, var56, false);
    boolean var59 = var17.equals((java.lang.Object)var56);
    boolean var60 = var0.equals((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var18.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "GradientPaintTransformType.VERTICAL"+ "'", var19.equals("GradientPaintTransformType.VERTICAL"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test201"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.AxisLocation var22 = var8.getRangeAxisLocation(1);
    org.jfree.data.category.CategoryDataset var24 = var8.getDataset((-16777216));
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    java.awt.geom.Point2D var27 = null;
    var8.panDomainAxes(0.2d, var26, var27);
    java.awt.Stroke var29 = var8.getRangeCrosshairStroke();
    org.jfree.chart.plot.Marker var31 = null;
    org.jfree.chart.util.Layer var32 = null;
    boolean var33 = var8.removeDomainMarker((-2), var31, var32);
    org.jfree.chart.axis.ValueAxis var34 = null;
    var8.setRangeAxis(var34);
    int var36 = var8.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test202"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var3 = var0.getLegendItem(2, 100);
    org.jfree.chart.util.GradientPaintTransformer var4 = var0.getGradientPaintTransformer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var5 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var5);
    java.awt.Paint var7 = var0.getBasePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test203"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.BarRenderer var12 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var15 = var12.getLegendItem(2, 100);
    java.awt.Stroke var16 = var12.getBaseStroke();
    var8.setRangeCrosshairStroke(var16);
    org.jfree.chart.plot.Marker var19 = null;
    org.jfree.chart.util.Layer var20 = null;
    boolean var21 = var8.removeDomainMarker(1, var19, var20);
    boolean var22 = var8.isRangeCrosshairVisible();
    org.jfree.chart.util.RectangleInsets var23 = var8.getInsets();
    double var25 = var23.trimHeight(10.0d);
    org.jfree.chart.util.UnitType var26 = var23.getUnitType();
    double var27 = var23.getLeft();
    double var28 = var23.getRight();
    org.jfree.chart.util.UnitType var29 = var23.getUnitType();
    double var31 = var23.trimWidth(100.0d);
    org.jfree.chart.util.UnitType var32 = var23.getUnitType();
    java.lang.String var33 = var32.toString();
    org.jfree.chart.util.RectangleInsets var38 = new org.jfree.chart.util.RectangleInsets(var32, 22.0d, (-15.8d), 0.0d, 10.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 84.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + "UnitType.ABSOLUTE"+ "'", var33.equals("UnitType.ABSOLUTE"));

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test204"); }


    org.jfree.chart.renderer.RenderAttributes var0 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var2 = var0.getSeriesPaint(100);
    java.awt.Paint var4 = var0.getSeriesFillPaint(10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var5.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    boolean var9 = var5.getUseSeriesOffset();
    java.awt.Paint var10 = var5.getBaseOutlinePaint();
    java.awt.Shape var11 = var5.getBaseShape();
    var0.setDefaultShape(var11);
    org.jfree.data.category.DefaultCategoryDataset var13 = new org.jfree.data.category.DefaultCategoryDataset();
    int var15 = var13.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var16 = null;
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer var18 = new org.jfree.chart.renderer.category.BarRenderer();
    double var19 = var18.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var20 = var18.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var13, var16, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var18);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var22.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var26 = var22.getLegendItems();
    java.lang.Object var27 = var26.clone();
    var21.setFixedLegendItems(var26);
    org.jfree.chart.entity.PlotEntity var30 = new org.jfree.chart.entity.PlotEntity(var11, (org.jfree.chart.plot.Plot)var21, "");
    org.jfree.chart.axis.AxisSpace var31 = null;
    var21.setFixedDomainAxisSpace(var31);
    var21.setAnchorValue(100.0d, false);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    java.awt.geom.Point2D var39 = null;
    var21.zoomRangeAxes((-1.0d), (-1.0d), var38, var39);
    boolean var41 = var21.isRangeZeroBaselineVisible();
    org.jfree.chart.axis.ValueAxis var43 = null;
    var21.setRangeAxis(70, var43, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test205"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Paint var2 = var0.getLegendTextPaint(2);
    java.awt.Paint var4 = var0.getSeriesOutlinePaint(5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var7 = null;
    var5.setSeriesToolTipGenerator(0, var7, true);
    org.jfree.chart.labels.ItemLabelPosition var10 = var5.getBasePositiveItemLabelPosition();
    java.awt.Paint var11 = var5.getBaseFillPaint();
    boolean var12 = var5.getBaseSeriesVisibleInLegend();
    var5.setSeriesShapesFilled(0, true);
    var5.setSeriesVisible(1, (java.lang.Boolean)false);
    org.jfree.chart.plot.CategoryPlot var19 = var5.getPlot();
    org.jfree.chart.renderer.category.BarRenderer var20 = new org.jfree.chart.renderer.category.BarRenderer();
    org.jfree.chart.LegendItem var23 = var20.getLegendItem(2, 100);
    org.jfree.chart.util.GradientPaintTransformer var24 = var20.getGradientPaintTransformer();
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var25 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    var20.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var25);
    var5.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var25);
    var0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var25);
    var0.setDrawBarOutline(true);
    java.awt.Paint var32 = null;
    var0.setSeriesOutlinePaint(70, var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test206"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var10 = null;
    org.jfree.data.category.DefaultCategoryDataset var11 = new org.jfree.data.category.DefaultCategoryDataset();
    int var13 = var11.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var14 = null;
    org.jfree.chart.axis.ValueAxis var15 = null;
    org.jfree.chart.renderer.category.BarRenderer var16 = new org.jfree.chart.renderer.category.BarRenderer();
    double var17 = var16.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var18 = var16.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var19 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var11, var14, var15, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.util.Layer var21 = null;
    java.util.Collection var22 = var19.getRangeMarkers((-1), var21);
    org.jfree.chart.LegendItemCollection var23 = var19.getLegendItems();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.Marker var25 = null;
    java.awt.geom.Rectangle2D var26 = null;
    var0.drawRangeMarker(var10, var19, var24, var25, var26);
    var19.setDomainCrosshairColumnKey((java.lang.Comparable)2.0f, true);
    org.jfree.chart.axis.AxisLocation var31 = var19.getDomainAxisLocation();
    org.jfree.chart.axis.AxisLocation var32 = org.jfree.chart.axis.AxisLocation.getOpposite(var31);
    org.jfree.data.category.DefaultCategoryDataset var33 = new org.jfree.data.category.DefaultCategoryDataset();
    int var35 = var33.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var36 = null;
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.BarRenderer var38 = new org.jfree.chart.renderer.category.BarRenderer();
    double var39 = var38.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var40 = var38.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var33, var36, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var38);
    float var42 = var41.getBackgroundImageAlpha();
    org.jfree.data.category.DefaultCategoryDataset var43 = new org.jfree.data.category.DefaultCategoryDataset();
    int var45 = var43.getColumnIndex((java.lang.Comparable)(byte)1);
    int var46 = var41.indexOf((org.jfree.data.category.CategoryDataset)var43);
    java.awt.Stroke var47 = var41.getRangeMinorGridlineStroke();
    org.jfree.chart.axis.CategoryAxis var48 = new org.jfree.chart.axis.CategoryAxis();
    float var49 = var48.getMinorTickMarkOutsideLength();
    double var50 = var48.getLowerMargin();
    org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis();
    java.awt.geom.Rectangle2D var54 = null;
    org.jfree.chart.util.RectangleEdge var55 = null;
    double var56 = var51.getCategoryEnd(2, 0, var54, var55);
    java.lang.String var57 = var51.getLabel();
    org.jfree.data.category.DefaultCategoryDataset var58 = new org.jfree.data.category.DefaultCategoryDataset();
    int var60 = var58.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var61 = null;
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.category.BarRenderer var63 = new org.jfree.chart.renderer.category.BarRenderer();
    double var64 = var63.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var65 = var63.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var58, var61, var62, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.renderer.category.BarRenderer var67 = new org.jfree.chart.renderer.category.BarRenderer();
    double var68 = var67.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var69 = var67.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var70 = var67.getBaseItemLabelGenerator();
    var67.setShadowYOffset(0.2d);
    var66.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer)var67, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var75 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var77 = var75.getSeriesStroke(0);
    boolean var78 = var75.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var80 = var75.lookupSeriesFillPaint(10);
    var66.setDomainCrosshairPaint(var80);
    var51.removeChangeListener((org.jfree.chart.event.AxisChangeListener)var66);
    double var83 = var51.getCategoryMargin();
    java.lang.String var84 = var51.getLabel();
    org.jfree.chart.util.RectangleInsets var85 = var51.getTickLabelInsets();
    var48.setTickLabelInsets(var85);
    int var87 = var41.getDomainAxisIndex(var48);
    org.jfree.chart.event.RendererChangeEvent var88 = null;
    var41.rendererChanged(var88);
    double var90 = var41.getRangeCrosshairValue();
    java.util.List var91 = var41.getAnnotations();
    org.jfree.chart.plot.PlotOrientation var92 = var41.getOrientation();
    org.jfree.chart.util.RectangleEdge var93 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var31, var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.05d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test207"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    org.jfree.chart.labels.CategoryItemLabelGenerator var3 = var0.getBaseItemLabelGenerator();
    var0.setShadowYOffset(0.2d);
    var0.setItemLabelAnchorOffset(0.0d);
    org.jfree.chart.renderer.RenderAttributes var8 = new org.jfree.chart.renderer.RenderAttributes();
    java.awt.Paint var11 = var8.getItemPaint(0, (-1));
    java.awt.Paint var13 = var8.getSeriesFillPaint((-1));
    java.awt.Shape var18 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var21 = var19.getSeriesStroke(0);
    boolean var22 = var19.getDataBoundsIncludesVisibleSeriesOnly();
    java.awt.Paint var24 = var19.lookupSeriesFillPaint(10);
    org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.data.UnknownKeyException: ", var18, var24);
    var8.setDefaultOutlinePaint(var24);
    var0.setBaseItemLabelPaint(var24);
    var0.setDrawBarOutline(false);
    org.jfree.data.category.DefaultCategoryDataset var30 = new org.jfree.data.category.DefaultCategoryDataset();
    int var32 = var30.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var33 = new org.jfree.data.general.DatasetGroup();
    var30.setGroup(var33);
    int var36 = var30.getRowIndex((java.lang.Comparable)(short)100);
    org.jfree.data.event.DatasetChangeListener var37 = null;
    var30.removeChangeListener(var37);
    var30.validateObject();
    org.jfree.data.Range var41 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var30, true);
    java.awt.Paint var42 = var0.getBaseLegendTextPaint();
    java.awt.Shape var43 = var0.getBaseShape();
    org.jfree.chart.labels.CategoryToolTipGenerator var44 = null;
    var0.setBaseToolTipGenerator(var44, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test208"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    var9.setSeriesItemLabelsVisible(0, (java.lang.Boolean)true);
    org.jfree.chart.LegendItemCollection var13 = var9.getLegendItems();
    java.lang.Object var14 = var13.clone();
    var8.setFixedLegendItems(var13);
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    java.awt.geom.Point2D var19 = null;
    var8.zoomRangeAxes((-1.0d), 10.0d, var18, var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.Range var22 = var8.getDataRange(var21);
    var8.clearRangeMarkers((-1));
    var8.setRangeCrosshairValue(100.0d);
    float var27 = var8.getBackgroundImageAlpha();
    java.awt.Paint var28 = var8.getOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0.5f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test209"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var2 = var0.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var3 = null;
    var0.setLegendItemURLGenerator(var3);
    org.jfree.chart.urls.CategoryURLGenerator var5 = null;
    var0.setBaseURLGenerator(var5, false);
    java.lang.Boolean var9 = var0.getSeriesVisibleInLegend((-1));
    boolean var12 = var0.getItemShapeFilled((-1), 100);
    java.awt.Paint var16 = var0.getItemFillPaint(100, 0, true);
    boolean var17 = var0.getAutoPopulateSeriesOutlineStroke();
    boolean var20 = var0.getItemShapeVisible(100, 10);
    java.awt.Paint var21 = var0.getBasePaint();
    boolean var22 = var0.getBaseCreateEntities();
    boolean var23 = var0.getBaseSeriesVisible();
    boolean var26 = var0.getItemLineVisible(15, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test210() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test210"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    double var1 = var0.getItemMargin();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getPositiveItemLabelPositionFallback();
    int var3 = var0.getPassCount();
    boolean var5 = var0.equals((java.lang.Object)"");
    var0.setBaseSeriesVisibleInLegend(true);
    var0.setBase(0.2d);
    var0.setMaximumBarWidth(0.0d);
    org.jfree.data.category.DefaultCategoryDataset var12 = new org.jfree.data.category.DefaultCategoryDataset();
    int var14 = var12.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.data.general.DatasetGroup var15 = new org.jfree.data.general.DatasetGroup();
    var12.setGroup(var15);
    var12.setValue((java.lang.Number)(-1), (java.lang.Comparable)(short)1, (java.lang.Comparable)"hi!");
    var12.validateObject();
    org.jfree.data.Range var22 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var12);
    java.awt.Font var23 = var0.getBaseItemLabelFont();
    double var24 = var0.getShadowXOffset();
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var28 = var26.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var29 = null;
    var26.setLegendItemURLGenerator(var29);
    org.jfree.chart.urls.CategoryURLGenerator var31 = null;
    var26.setBaseURLGenerator(var31, false);
    var26.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var38 = null;
    var36.setSeriesToolTipGenerator(0, var38, true);
    org.jfree.chart.labels.ItemLabelPosition var41 = var36.getBasePositiveItemLabelPosition();
    java.awt.Paint var42 = var36.getBaseFillPaint();
    var26.setBaseOutlinePaint(var42, false);
    boolean var45 = var26.getUseFillPaint();
    java.awt.Font var46 = var26.getBaseItemLabelFont();
    var25.setTickLabelFont(var46);
    org.jfree.chart.plot.Plot var48 = var25.getPlot();
    org.jfree.chart.axis.CategoryLabelPositions var49 = var25.getCategoryLabelPositions();
    double var50 = var25.getCategoryMargin();
    java.awt.Paint var52 = var25.getTickLabelPaint((java.lang.Comparable)"RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]");
    var0.setBasePaint(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test211"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)(byte)1);
    org.jfree.chart.axis.CategoryAxis var3 = null;
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.chart.renderer.category.BarRenderer var5 = new org.jfree.chart.renderer.category.BarRenderer();
    double var6 = var5.getItemMargin();
    org.jfree.chart.renderer.category.BarPainter var7 = var5.getBarPainter();
    org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset)var0, var3, var4, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.util.Layer var10 = null;
    java.util.Collection var11 = var8.getRangeMarkers((-1), var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var14 = var12.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var15 = null;
    var12.setLegendItemURLGenerator(var15);
    org.jfree.chart.urls.CategoryURLGenerator var17 = null;
    var12.setBaseURLGenerator(var17, false);
    java.lang.Boolean var21 = var12.getSeriesVisibleInLegend((-1));
    boolean var24 = var12.getItemShapeFilled((-1), 100);
    java.awt.Shape var29 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var32 = var30.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var33 = null;
    var30.setLegendItemURLGenerator(var33);
    org.jfree.chart.urls.CategoryURLGenerator var35 = null;
    var30.setBaseURLGenerator(var35, false);
    var30.setAutoPopulateSeriesPaint(true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    org.jfree.chart.labels.CategoryToolTipGenerator var42 = null;
    var40.setSeriesToolTipGenerator(0, var42, true);
    org.jfree.chart.labels.ItemLabelPosition var45 = var40.getBasePositiveItemLabelPosition();
    java.awt.Paint var46 = var40.getBaseFillPaint();
    var30.setBaseOutlinePaint(var46, false);
    org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "org.jfree.data.UnknownKeyException: ", "", "org.jfree.data.UnknownKeyException: ", var29, var46);
    var12.setBaseOutlinePaint(var46, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    java.awt.Stroke var54 = var52.getSeriesStroke(0);
    org.jfree.chart.labels.CategorySeriesLabelGenerator var55 = null;
    var52.setLegendItemURLGenerator(var55);
    org.jfree.chart.urls.CategoryURLGenerator var57 = null;
    var52.setBaseURLGenerator(var57, false);
    java.lang.Boolean var61 = var52.getSeriesVisibleInLegend((-1));
    java.awt.Stroke var65 = var52.getItemStroke(10, 1, false);
    var12.setBaseStroke(var65, false);
    var8.setDomainCrosshairStroke(var65);
    org.jfree.chart.plot.PlotRenderingInfo var70 = null;
    java.awt.geom.Point2D var71 = null;
    var8.zoomDomainAxes(0.0d, var70, var71, true);
    org.jfree.chart.plot.PlotRenderingInfo var75 = null;
    java.awt.geom.Point2D var76 = null;
    var8.panRangeAxes(0.05d, var75, var76);
    var8.clearAnnotations();
    boolean var79 = var8.isDomainPannable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

}
