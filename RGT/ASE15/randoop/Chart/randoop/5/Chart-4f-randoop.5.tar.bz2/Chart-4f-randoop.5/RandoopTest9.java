
import junit.framework.*;

public class RandoopTest9 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test1"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setUpperMargin(1.0d);
    var1.setMaximumCategoryLabelWidthRatio(10.0f);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test2"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextAnchor var4 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("#ffff5b", var1, 1.0f, (-1.0f), var4, 0.0d, 10.0f, 1.0f);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test3"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var9 = var8.getRGB();
//     var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
//     java.awt.Font var18 = var3.getBaseLegendTextFont();
//     int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
//     org.jfree.chart.axis.AxisSpace var20 = var1.getFixedRangeAxisSpace();
//     org.jfree.chart.axis.AxisLocation var22 = var1.getRangeAxisLocation((-165));
//     org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var28 = var24.getToolTipGenerator((-1), (-165), false);
//     java.awt.Shape var30 = var24.getLegendShape(100);
//     var1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var24);
//     
//     // Checks the contract:  equals-hashcode on var3 and var24
//     assertTrue("Contract failed: equals-hashcode on var3 and var24", var3.equals(var24) ? var3.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var3
//     assertTrue("Contract failed: equals-hashcode on var24 and var3", var24.equals(var3) ? var24.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test4"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.chart.labels.XYSeriesLabelGenerator var8 = var7.getLegendItemURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test5"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isOutlineVisible();
    org.jfree.chart.util.RectangleInsets var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setInsets(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test6"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.renderer.xy.XYAreaRenderer var33 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var39 = var38.getRGB();
    var33.setSeriesFillPaint(0, (java.awt.Paint)var38, true);
    boolean var42 = var31.equals((java.lang.Object)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test7"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var13.removeDomainMarker(100, var16, var17);
//     var13.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var23 = var22.getBaseItemLabelsVisible();
//     java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
//     var13.setRangeGridlinePaint(var27);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     var13.setDataset(10, var30);
//     java.lang.Object var32 = var13.clone();
//     org.jfree.chart.plot.Marker var33 = null;
//     var13.addRangeMarker(var33);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test8"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    double var23 = var12.getMaximumBarWidth();
    java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var28 = var27.getRGB();
    var12.setWallPaint((java.awt.Paint)var27);
    double var30 = var12.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1.0d));

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test9"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setDomainMinorGridlinesVisible(false);
    org.jfree.chart.annotations.XYAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var10 = var1.removeAnnotation(var8, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test10"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.axis.AxisSpace var20 = var1.getFixedRangeAxisSpace();
    int var21 = var1.getRendererCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test11"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.clearDomainMarkers(0);
    org.jfree.chart.plot.Marker var22 = null;
    org.jfree.chart.util.Layer var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var25 = var13.removeRangeMarker(0, var22, var23, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test12"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    org.jfree.chart.ChartRenderingInfo var7 = null;
    org.jfree.chart.plot.PlotRenderingInfo var8 = new org.jfree.chart.plot.PlotRenderingInfo(var7);
    java.awt.geom.Point2D var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRangeAxes(100.0d, 10.0d, var8, var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test13"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker((-165), var20, var21, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test14"); }


    org.jfree.data.general.PieDataset var0 = null;
    boolean var1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test15"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test16"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.axis.AxisSpace var20 = var1.getFixedRangeAxisSpace();
    org.jfree.chart.plot.SeriesRenderingOrder var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesRenderingOrder(var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test17"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var1.notifyListeners(var6);
    java.awt.Stroke var9 = null;
    var1.setSeriesOutlineStroke(1, var9);
    boolean var11 = var1.getPlotArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test18"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test19"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.plot.DrawingSupplier var5 = var2.getDrawingSupplier();
    org.jfree.chart.annotations.CategoryAnnotation var6 = null;
    boolean var7 = var2.removeAnnotation(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test20"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(var0, 100);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test21"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var13.setFixedDomainAxisSpace(var27);
    boolean var29 = var13.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test22"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(0.0d, 1.0d);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test23"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    java.util.List var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds(var0, var1, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test24"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var13.removeDomainMarker(100, var16, var17);
//     var13.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var23 = var22.getBaseItemLabelsVisible();
//     java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
//     var13.setRangeGridlinePaint(var27);
//     org.jfree.data.category.CategoryDataset var30 = null;
//     var13.setDataset(10, var30);
//     java.lang.Object var32 = var13.clone();
//     var13.setDomainCrosshairRowKey((java.lang.Comparable)10L);
//     var13.zoom(10.0d);
// 
//   }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test25"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var1.setFillPaint((java.awt.Paint)var5);
//     java.awt.Shape var7 = var1.getShape();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     java.lang.String var14 = var13.getURLText();
//     int var15 = var13.getItem();
//     org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var16 = null;
//     org.jfree.chart.imagemap.URLTagFragmentGenerator var17 = null;
//     java.lang.String var18 = var13.getImageMapAreaTag(var16, var17);
// 
//   }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test26"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Preceding", var1);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test27"); }


    org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test28"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.mapDatasetToDomainAxis((-1), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test29"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test30"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    var1.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test31"); }


    java.awt.Color var2 = java.awt.Color.getColor("", 1);
    int var3 = var2.getAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 255);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test32"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.Plot var14 = var2.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test33() {}
//   public void test33() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test33"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var13.removeDomainMarker(100, var16, var17);
//     var13.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var23 = var22.getBaseItemLabelsVisible();
//     java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
//     var13.setRangeGridlinePaint(var27);
//     java.awt.Image var29 = null;
//     var13.setBackgroundImage(var29);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var38 = var37.getRGB();
//     var32.setSeriesFillPaint(0, (java.awt.Paint)var37, true);
//     java.awt.Paint[] var41 = new java.awt.Paint[] { var37};
//     java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     java.awt.Paint[] var46 = new java.awt.Paint[] { var45};
//     java.awt.Stroke var47 = null;
//     java.awt.Stroke[] var48 = new java.awt.Stroke[] { var47};
//     java.awt.Stroke[] var49 = null;
//     java.awt.Shape var50 = null;
//     java.awt.Shape[] var51 = new java.awt.Shape[] { var50};
//     org.jfree.chart.plot.DefaultDrawingSupplier var52 = new org.jfree.chart.plot.DefaultDrawingSupplier(var41, var46, var48, var49, var51);
//     java.lang.Object var53 = var52.clone();
//     var13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var52);
//     
//     // Checks the contract:  equals-hashcode on var22 and var32
//     assertTrue("Contract failed: equals-hashcode on var22 and var32", var22.equals(var32) ? var22.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var22
//     assertTrue("Contract failed: equals-hashcode on var32 and var22", var32.equals(var22) ? var32.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test34"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var2.setSeriesItemLabelGenerator(0, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test35"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var9 = var8.getRGB();
//     var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
//     java.awt.Font var18 = var3.getBaseLegendTextFont();
//     int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     var1.setRenderer(1, var21);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     var1.handleClick(1, 1, var26);
//     java.awt.Graphics2D var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     var1.drawBackground(var28, var29);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test36"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test37"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.IntervalXYDelegate var2 = new org.jfree.data.xy.IntervalXYDelegate(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test38"); }


    org.jfree.chart.util.RectangleInsets var0 = null;
    org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var10 = var9.getRGB();
    var4.setSeriesFillPaint(0, (java.awt.Paint)var9, true);
    java.awt.Color var13 = var9.brighter();
    var2.setPaint((java.awt.Paint)var13);
    java.awt.Paint var15 = var2.getPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.block.BlockBorder var16 = new org.jfree.chart.block.BlockBorder(var0, var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test39"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isOutlineVisible();
    var1.setRangeGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test40"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var1.configure();
//     java.awt.Font var3 = var1.getTickLabelFont();
//     java.awt.geom.Rectangle2D var6 = null;
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot(var7);
//     org.jfree.chart.util.RectangleEdge var10 = var8.getRangeAxisEdge((-1));
//     boolean var11 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var10);
//     double var12 = var1.getCategoryEnd(10, (-1), var6, var10);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test41"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isDomainPannable();
    org.jfree.chart.plot.PlotOrientation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setOrientation(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test42"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    double var23 = var12.getMaximumBarWidth();
    org.jfree.chart.renderer.category.BarPainter var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setBarPainter(var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test43"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var9 = var1.getLegendItemLabelGenerator();
    boolean var10 = var1.getUseFillPaint();
    org.jfree.data.xy.XYDataset var11 = null;
    org.jfree.data.Range var12 = var1.findRangeBounds(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test44"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.data.category.CategoryDataset var8 = null;
//     org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var11 = var10.isAxisLineVisible();
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var10.setTickLabelPaint((java.awt.Paint)var15);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var8, var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
//     var21.setForegroundAlpha(0.0f);
//     org.jfree.chart.axis.ValueAxis var24 = null;
//     java.awt.geom.Rectangle2D var25 = null;
//     var2.drawRangeGridline(var7, var21, var24, var25, 100.0d);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test45"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    java.awt.Shape var7 = var1.getBaseShape();
    org.jfree.chart.JFreeChart var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var11 = new org.jfree.chart.entity.JFreeChartEntity(var7, var8, "Preceding", "hi!");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test46"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    org.jfree.chart.util.VerticalAlignment var23 = null;
    org.jfree.chart.block.FlowArrangement var26 = new org.jfree.chart.block.FlowArrangement(var22, var23, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var27 = null;
    org.jfree.chart.title.LegendItemBlockContainer var29 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var26, var27, (java.lang.Comparable)(short)100);
    java.lang.Comparable var30 = var29.getSeriesKey();
    java.util.List var31 = var29.getBlocks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.mapDatasetToRangeAxes((-165), var31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + (short)100+ "'", var30.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test47"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("#ffff5b", var1);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test48"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     int var32 = var31.getItemCount();
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     var34.setSeriesIndex((-1));
//     org.jfree.data.general.Dataset var37 = var34.getDataset();
//     var34.setToolTipText("");
//     var31.add(var34);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var43 = var42.getBaseItemLabelsVisible();
//     java.awt.Shape var47 = var42.getItemShape(0, 1, false);
//     org.jfree.chart.entity.ChartEntity var48 = new org.jfree.chart.entity.ChartEntity(var47);
//     var34.setShape(var47);
//     
//     // Checks the contract:  equals-hashcode on var17 and var42
//     assertTrue("Contract failed: equals-hashcode on var17 and var42", var17.equals(var42) ? var17.hashCode() == var42.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var42 and var17
//     assertTrue("Contract failed: equals-hashcode on var42 and var17", var42.equals(var17) ? var42.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test49"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    var1.clearDomainMarkers(1);
    var1.setRangeCrosshairVisible(false);
    java.awt.Stroke var8 = var1.getDomainCrosshairStroke();
    var1.clearSelection();
    org.jfree.data.general.DatasetGroup var10 = var1.getDatasetGroup();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test50"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    var1.clearDomainMarkers(1);
    var1.setRangeCrosshairVisible(false);
    org.jfree.chart.axis.ValueAxis var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDomainAxis((-1), var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test51"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
//     org.jfree.chart.axis.AxisLocation var5 = var1.getRangeAxisLocation(1);
//     java.awt.Graphics2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     org.jfree.chart.plot.PlotState var9 = null;
//     org.jfree.chart.axis.ValueAxis var10 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot(var10);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var19 = var18.getRGB();
//     var13.setSeriesFillPaint(0, (java.awt.Paint)var18, true);
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     org.jfree.chart.plot.XYPlot var24 = null;
//     org.jfree.data.xy.XYDataset var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var27 = var13.initialise(var22, var23, var24, var25, var26);
//     java.awt.Font var28 = var13.getBaseLegendTextFont();
//     int var29 = var11.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var13);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = null;
//     var11.setRenderer(1, var31);
//     org.jfree.chart.ChartRenderingInfo var35 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var36 = new org.jfree.chart.plot.PlotRenderingInfo(var35);
//     var11.handleClick(1, 1, var36);
//     var1.draw(var6, var7, var8, var9, var36);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test52"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test53"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    var1.setURLText("Preceding");
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var28 = var27.getBaseItemLabelsVisible();
    java.awt.Shape var32 = var27.getItemShape(0, 1, false);
    var23.setBaseLegendShape(var32);
    double var34 = var23.getMaximumBarWidth();
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var39 = var38.getRGB();
    var23.setWallPaint((java.awt.Paint)var38);
    var1.setLabelPaint((java.awt.Paint)var38);
    org.jfree.data.general.Dataset var42 = null;
    var1.setDataset(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-165));

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test54"); }
// 
// 
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var2 = var1.getNumberFormat();
//     java.text.ParsePosition var4 = null;
//     java.lang.Object var5 = var2.parseObject("", var4);
// 
//   }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test55"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.ItemLabelPosition var5 = var1.getSeriesNegativeItemLabelPosition(10);
    org.jfree.chart.LegendItem var8 = var1.getLegendItem((-165), 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test56"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Color var12 = var8.brighter();
    var1.setPaint((java.awt.Paint)var12);
    var1.setID("Preceding");
    java.lang.String var16 = var1.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test57() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test57"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setSeriesIndex((-1));
    java.lang.String var4 = var1.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test58"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    var1.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test59"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    var1.setDomainZeroBaselineVisible(true);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test60"); }


    org.jfree.data.general.SeriesChangeInfo var1 = null;
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)false, var1);
    org.jfree.data.general.SeriesChangeInfo var3 = null;
    var2.setSummary(var3);

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test61"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
//     org.jfree.chart.event.RendererChangeEvent var6 = null;
//     var1.notifyListeners(var6);
//     java.awt.Stroke var9 = null;
//     var1.setSeriesOutlineStroke(1, var9);
//     var1.removeAnnotations();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var13 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var17 = var13.getToolTipGenerator((-1), (-165), false);
//     var13.setSeriesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var21 = var13.getLegendItemLabelGenerator();
//     var1.setLegendItemURLGenerator(var21);
//     
//     // Checks the contract:  equals-hashcode on var1 and var13
//     assertTrue("Contract failed: equals-hashcode on var1 and var13", var1.equals(var13) ? var1.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var1
//     assertTrue("Contract failed: equals-hashcode on var13 and var1", var13.equals(var1) ? var13.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test62"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var17 = var16.getBaseItemLabelsVisible();
//     java.awt.Shape var21 = var16.getItemShape(0, 1, false);
//     var12.setBaseLegendShape(var21);
//     double var23 = var12.getMaximumBarWidth();
//     java.awt.Paint var25 = var12.lookupSeriesFillPaint(10);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.data.category.CategoryDataset var29 = null;
//     org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var32 = var31.isAxisLineVisible();
//     java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var31.setTickLabelPaint((java.awt.Paint)var36);
//     org.jfree.chart.axis.ValueAxis var38 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var29, var31, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
//     java.awt.Image var43 = null;
//     var42.setBackgroundImage(var43);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var46 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var51 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var52 = var51.getRGB();
//     var46.setSeriesFillPaint(0, (java.awt.Paint)var51, true);
//     java.awt.Color var55 = var51.brighter();
//     var42.setRangeZeroBaselinePaint((java.awt.Paint)var55);
//     java.lang.Comparable var57 = null;
//     var42.setDomainCrosshairRowKey(var57, false);
//     org.jfree.chart.LegendItemCollection var60 = var42.getLegendItems();
//     org.jfree.chart.util.RectangleEdge var61 = var42.getRangeAxisEdge();
//     org.jfree.chart.axis.CategoryAxis var62 = null;
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.data.category.CategoryDataset var64 = null;
//     var12.drawItem(var26, var27, var28, var42, var62, var63, var64, (-1), 0, false, 0);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test63"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    org.jfree.chart.LegendItem var12 = var1.getLegendItem(0, 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test64"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isDomainPannable();
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAxisLocation(var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test65"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    boolean var2 = var1.isDrawBarOutline();
    var1.setDrawBarOutline(false);
    java.awt.Stroke var8 = var1.getItemStroke((-165), 1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test66"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var6);
    java.awt.Shape var8 = var7.getArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test67"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    java.awt.Shape var7 = var1.getLegendShape(100);
    var1.setSeriesVisible(1, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.XYToolTipGenerator var12 = var1.getBaseToolTipGenerator();
    boolean var15 = var1.getItemVisible(1, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test68"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    float var3 = var1.getTickMarkInsideLength();
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.util.RectangleEdge var7 = null;
    double var8 = var1.getCategoryEnd(0, 0, var6, var7);
    float var9 = var1.getTickMarkOutsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.0f);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test69"); }


    org.jfree.data.time.SerialDate var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var1 = new org.jfree.data.time.Day(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test70"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.axis.AxisLocation var5 = var1.getRangeAxisLocation(1);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setDatasetRenderingOrder(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test71"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.axis.AxisSpace var20 = var1.getFixedRangeAxisSpace();
    java.awt.Stroke var21 = var1.getRangeCrosshairStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test72"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((-1.0d), 10.0d, var2);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test73"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var12.setSeriesVisibleInLegend(10, (java.lang.Boolean)false, false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.setSeriesItemLabelGenerator((-165), var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test74"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var5 = var4.getBaseItemLabelsVisible();
    boolean var6 = var4.getAutoPopulateSeriesStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer[] var7 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var4};
    var1.setRenderers(var7);
    java.awt.Stroke var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeZeroBaselineStroke(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test75"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    boolean var8 = var4.getAutoPopulateSeriesStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test76"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test77"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("Preceding", var1);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test78"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     java.lang.Comparable var32 = var13.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var40 = var39.getRGB();
//     var34.setSeriesFillPaint(0, (java.awt.Paint)var39, true);
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var39};
//     java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke[] var51 = null;
//     java.awt.Shape var52 = null;
//     java.awt.Shape[] var53 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier(var43, var48, var50, var51, var53);
//     var13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var54);
//     org.jfree.chart.plot.Marker var57 = null;
//     org.jfree.chart.util.Layer var58 = null;
//     var13.addRangeMarker(0, var57, var58, true);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test79"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var3 = var1.getDataItem((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test80"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLabelToolTip("Preceding");
    float var4 = var1.getMinorTickMarkInsideLength();
    org.jfree.chart.axis.CategoryLabelPositions var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setCategoryLabelPositions(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0f);

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test81"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     var13.setForegroundAlpha(0.0f);
//     java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
//     java.lang.Object var17 = var13.clone();
//     var13.clearDomainAxes();
//     org.jfree.chart.axis.ValueAxis var20 = var13.getRangeAxis(0);
//     org.jfree.chart.util.RectangleEdge var21 = var13.getDomainAxisEdge();
//     java.awt.Graphics2D var22 = null;
//     java.awt.geom.Rectangle2D var23 = null;
//     var13.drawBackground(var22, var23);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test82"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("hi!");

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test83"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
//     var4.setUseYInterval(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var11 = var4.getItemLabelGenerator(0, 10, true);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot(var14);
//     java.lang.String var16 = var15.getNoDataMessage();
//     org.jfree.data.xy.XYDataset var17 = null;
//     org.jfree.chart.axis.ValueAxis var18 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var19 = new org.jfree.chart.plot.CombinedDomainXYPlot(var18);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var21 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var27 = var26.getRGB();
//     var21.setSeriesFillPaint(0, (java.awt.Paint)var26, true);
//     java.awt.Graphics2D var30 = null;
//     java.awt.geom.Rectangle2D var31 = null;
//     org.jfree.chart.plot.XYPlot var32 = null;
//     org.jfree.data.xy.XYDataset var33 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var34 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var35 = var21.initialise(var30, var31, var32, var33, var34);
//     java.awt.Font var36 = var21.getBaseLegendTextFont();
//     int var37 = var19.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var21);
//     org.jfree.chart.renderer.xy.XYItemRenderer var39 = null;
//     var19.setRenderer(1, var39);
//     org.jfree.chart.ChartRenderingInfo var43 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var44 = new org.jfree.chart.plot.PlotRenderingInfo(var43);
//     var19.handleClick(1, 1, var44);
//     org.jfree.chart.renderer.xy.XYItemRendererState var46 = var4.initialise(var12, var13, (org.jfree.chart.plot.XYPlot)var15, var17, var44);
// 
//   }

  public void test84() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test84"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    var1.setURLText("Preceding");
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var28 = var27.getBaseItemLabelsVisible();
    java.awt.Shape var32 = var27.getItemShape(0, 1, false);
    var23.setBaseLegendShape(var32);
    double var34 = var23.getMaximumBarWidth();
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var39 = var38.getRGB();
    var23.setWallPaint((java.awt.Paint)var38);
    var1.setLabelPaint((java.awt.Paint)var38);
    int var42 = var1.getSeriesIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test85"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var1.getY(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test86"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Comparable var8 = var7.getSeriesKey();
    java.util.List var9 = var7.getBlocks();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var9);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test87"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.plot.DrawingSupplier var27 = var13.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test88"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setRangeMinorGridlinesVisible(false);
    org.jfree.chart.plot.PlotOrientation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setOrientation(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);

  }

  public void test89() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test89"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.DateFormat var9 = var4.getXDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test90"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var2 = var1.getLabel();
    var1.setToolTipText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    boolean var5 = var1.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var2.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test91"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot(var9);
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var18 = var17.getRGB();
    var12.setSeriesFillPaint(0, (java.awt.Paint)var17, true);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.XYPlot var23 = null;
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var26 = var12.initialise(var21, var22, var23, var24, var25);
    java.awt.Font var27 = var12.getBaseLegendTextFont();
    int var28 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var10.setRenderer(1, var30);
    boolean var32 = var7.equals((java.lang.Object)1);
    var7.setURLText("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test92"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    boolean var23 = var12.getDataBoundsIncludesVisibleSeriesOnly();
    org.jfree.chart.labels.CategoryToolTipGenerator var24 = var12.getBaseToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test93"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    double var2 = var1.getBase();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test94"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    java.awt.Shape var7 = var1.getLegendShape(100);
    var1.setSeriesVisible(1, (java.lang.Boolean)true, false);
    boolean var13 = var1.isSeriesVisible((-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test95"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.awt.Paint var9 = var7.getSeriesOutlinePaint(0);
    org.jfree.chart.labels.XYItemLabelGenerator var10 = null;
    var7.setBaseItemLabelGenerator(var10, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test96"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    int var28 = var26.getRGB();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-126));

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test97"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var1.getY(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test98"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Paint var3 = var1.getSectionOutlinePaint((java.lang.Comparable)10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test99"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("Preceding");
    var1.setHeight((-1.0d));

  }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test100"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     org.jfree.data.category.CategoryDataset var2 = null;
//     org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var5 = var4.isAxisLineVisible();
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var4.setTickLabelPaint((java.awt.Paint)var9);
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var2, var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
//     org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var18 = var17.isAxisLineVisible();
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var17.setTickLabelPaint((java.awt.Paint)var22);
//     java.awt.Paint var24 = var17.getTickLabelPaint();
//     var15.setRangeZeroBaselinePaint(var24);
//     var1.setLabelBackgroundPaint(var24);
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var30 = var29.isAxisLineVisible();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var29.setTickLabelPaint((java.awt.Paint)var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var27, var29, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     org.jfree.chart.axis.CategoryAxis var42 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var43 = var42.isAxisLineVisible();
//     java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var42.setTickLabelPaint((java.awt.Paint)var47);
//     java.awt.Paint var49 = var42.getTickLabelPaint();
//     var40.setRangeZeroBaselinePaint(var49);
//     var1.setLabelOutlinePaint(var49);
//     
//     // Checks the contract:  equals-hashcode on var15 and var40
//     assertTrue("Contract failed: equals-hashcode on var15 and var40", var15.equals(var40) ? var15.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var15
//     assertTrue("Contract failed: equals-hashcode on var40 and var15", var40.equals(var15) ? var40.hashCode() == var15.hashCode() : true);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test101"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.event.RendererChangeEvent var28 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    var13.rendererChanged(var28);
    var13.setRangeZeroBaselineVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test102"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    boolean var9 = var2.getBaseSeriesVisible();
    org.jfree.chart.renderer.category.BarPainter var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBarPainter(var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test103"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    double var10 = var2.getYOffset();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    java.awt.Image var25 = null;
    var24.setBackgroundImage(var25);
    org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var34 = var33.getRGB();
    var28.setSeriesFillPaint(0, (java.awt.Paint)var33, true);
    java.awt.Color var37 = var33.brighter();
    var24.setRangeZeroBaselinePaint((java.awt.Paint)var37);
    java.lang.Comparable var39 = null;
    var24.setDomainCrosshairRowKey(var39, false);
    org.jfree.chart.LegendItemCollection var42 = var24.getLegendItems();
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var24.getRangeMarkers(var43);
    var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
    var24.clearRangeAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test104"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("", "", "hi!", "hi!");

  }

  public void test105() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test105"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.data.Range var5 = var1.getDataRange(var4);
    var1.setGap(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test106"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
//     var1.setSeriesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var16 = var15.getRGB();
//     var10.setSeriesFillPaint(0, (java.awt.Paint)var15, true);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = null;
//     org.jfree.data.xy.XYDataset var22 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var23 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var24 = var10.initialise(var19, var20, var21, var22, var23);
//     java.awt.Font var25 = var10.getBaseLegendTextFont();
//     java.awt.Paint var27 = var10.lookupSeriesFillPaint(100);
//     var1.setBasePaint(var27, true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test107"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var1.notifyListeners(var6);
    java.awt.Stroke var9 = null;
    var1.setSeriesOutlineStroke(1, var9);
    var1.removeAnnotations();
    var1.setBaseCreateEntities(false, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test108"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    java.awt.Paint var8 = var1.getTickLabelPaint();
    java.lang.Comparable var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.addCategoryLabelToolTip(var9, "");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test109"); }


    org.jfree.chart.util.Size2D var2 = new org.jfree.chart.util.Size2D(0.0d, 0.0d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test110"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test111"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var9 = var1.getLegendItemLabelGenerator();
    boolean var10 = var1.getPlotArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test112"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
//     var2.setShadowVisible(false);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.data.category.CategoryDataset var10 = null;
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var13 = var12.isAxisLineVisible();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var12.setTickLabelPaint((java.awt.Paint)var17);
//     org.jfree.chart.axis.ValueAxis var19 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
//     org.jfree.chart.plot.DrawingSupplier var24 = var23.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var26 = null;
//     org.jfree.chart.util.Layer var27 = null;
//     boolean var28 = var23.removeDomainMarker(100, var26, var27);
//     var23.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var33 = var32.getBaseItemLabelsVisible();
//     java.awt.Paint var37 = var32.getItemFillPaint((-1), (-1), true);
//     var23.setRangeGridlinePaint(var37);
//     org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     org.jfree.chart.axis.ValueAxis var41 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var42 = new org.jfree.chart.plot.CombinedDomainXYPlot(var41);
//     org.jfree.chart.axis.AxisLocation var44 = var42.getDomainAxisLocation(1);
//     boolean var45 = var40.equals((java.lang.Object)var44);
//     org.jfree.chart.axis.AxisLocation var46 = org.jfree.chart.axis.AxisLocation.getOpposite(var44);
//     var23.setRangeAxisLocation(var44);
//     org.jfree.chart.axis.ValueAxis var48 = null;
//     org.jfree.chart.entity.EntityCollection var49 = null;
//     org.jfree.chart.ChartRenderingInfo var50 = new org.jfree.chart.ChartRenderingInfo(var49);
//     java.awt.geom.Rectangle2D var51 = var50.getChartArea();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var54 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var59 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var60 = var59.getRGB();
//     var54.setSeriesFillPaint(0, (java.awt.Paint)var59, true);
//     org.jfree.chart.axis.ValueAxis var63 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var64 = new org.jfree.chart.plot.CombinedDomainXYPlot(var63);
//     java.lang.String var65 = var64.getNoDataMessage();
//     org.jfree.chart.axis.CategoryAxis var67 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var67.configure();
//     java.awt.Stroke var69 = var67.getTickMarkStroke();
//     var64.setRangeGridlineStroke(var69);
//     var2.drawRangeLine(var9, var23, var48, var51, (-1.0d), (java.awt.Paint)var59, var69);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test113"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Color var12 = var8.brighter();
    var1.setPaint((java.awt.Paint)var12);
    org.jfree.chart.renderer.xy.XYAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var21 = var20.getRGB();
    var15.setSeriesFillPaint(0, (java.awt.Paint)var20, true);
    java.awt.Paint[] var24 = new java.awt.Paint[] { var20};
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    java.awt.Paint[] var29 = new java.awt.Paint[] { var28};
    java.awt.Stroke var30 = null;
    java.awt.Stroke[] var31 = new java.awt.Stroke[] { var30};
    java.awt.Stroke[] var32 = null;
    java.awt.Shape var33 = null;
    java.awt.Shape[] var34 = new java.awt.Shape[] { var33};
    org.jfree.chart.plot.DefaultDrawingSupplier var35 = new org.jfree.chart.plot.DefaultDrawingSupplier(var24, var29, var31, var32, var34);
    boolean var36 = var1.equals((java.lang.Object)var31);
    java.awt.Paint var37 = var1.getPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test114"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete(0, (-126));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test115"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    var13.mapDatasetToRangeAxis(100, (-1));
    org.jfree.chart.annotations.CategoryAnnotation var32 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var34 = var13.removeAnnotation(var32, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test116"); }


    java.awt.Paint var0 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var8 = var7.getRGB();
    var2.setSeriesFillPaint(0, (java.awt.Paint)var7, true);
    java.awt.Color var11 = var7.brighter();
    boolean var12 = org.jfree.chart.util.PaintUtilities.equal(var0, (java.awt.Paint)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test117"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    int var3 = var1.getPieIndex();
    org.jfree.chart.labels.PieToolTipGenerator var4 = var1.getToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test118"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    org.jfree.chart.plot.Marker var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.addDomainMarker(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test119"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    org.jfree.data.category.CategoryDataset var30 = null;
    var13.setDataset(10, var30);
    java.util.List var32 = var13.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test120"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setSeriesIndex((-1));
    org.jfree.data.general.Dataset var4 = var1.getDataset();
    var1.setToolTipText("");
    java.awt.Shape var7 = var1.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test121() {}
//   public void test121() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test121"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot(var1);
//     org.jfree.chart.axis.AxisLocation var4 = var2.getDomainAxisLocation(1);
//     java.awt.Paint var5 = var2.getDomainZeroBaselinePaint();
//     java.awt.Font var6 = var2.getNoDataMessageFont();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var14 = var13.getRGB();
//     var8.setSeriesFillPaint(0, (java.awt.Paint)var13, true);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = null;
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var22 = var8.initialise(var17, var18, var19, var20, var21);
//     java.awt.Font var23 = var8.getBaseLegendTextFont();
//     java.awt.Paint var25 = var8.lookupSeriesFillPaint(100);
//     org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var25);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot(var28);
//     org.jfree.chart.axis.AxisLocation var31 = var29.getDomainAxisLocation(1);
//     java.awt.Paint var32 = var29.getDomainZeroBaselinePaint();
//     java.awt.Font var33 = var29.getNoDataMessageFont();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Paint var36 = null;
//     var35.setBasePaint(var36);
//     java.awt.Color var40 = java.awt.Color.getColor("#ffff5b", 10);
//     var35.setBaseFillPaint((java.awt.Paint)var40, false);
//     var26.addLine("", var33, (java.awt.Paint)var40);
//     
//     // Checks the contract:  equals-hashcode on var2 and var29
//     assertTrue("Contract failed: equals-hashcode on var2 and var29", var2.equals(var29) ? var2.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var2
//     assertTrue("Contract failed: equals-hashcode on var29 and var2", var29.equals(var2) ? var29.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var35
//     assertTrue("Contract failed: equals-hashcode on var8 and var35", var8.equals(var35) ? var8.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var8
//     assertTrue("Contract failed: equals-hashcode on var35 and var8", var35.equals(var8) ? var35.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test122"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var13.getRangeMarkers(var33);
    boolean var35 = var13.isRangeZoomable();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test123"); }


    java.awt.Color var2 = java.awt.Color.getColor("#ffff5b", 10);
    float[] var5 = new float[] { (-1.0f), 10.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var6 = var2.getColorComponents(var5);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test124"); }
// 
// 
//     org.jfree.chart.LegendItemSource var0 = null;
//     org.jfree.chart.util.HorizontalAlignment var1 = null;
//     org.jfree.chart.util.VerticalAlignment var2 = null;
//     org.jfree.chart.block.FlowArrangement var5 = new org.jfree.chart.block.FlowArrangement(var1, var2, (-1.0d), (-1.0d));
//     var5.clear();
//     org.jfree.chart.util.HorizontalAlignment var7 = null;
//     org.jfree.chart.util.VerticalAlignment var8 = null;
//     org.jfree.chart.block.FlowArrangement var11 = new org.jfree.chart.block.FlowArrangement(var7, var8, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var12 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var14 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, var12, (java.lang.Comparable)(short)100);
//     org.jfree.chart.title.LegendTitle var15 = new org.jfree.chart.title.LegendTitle(var0, (org.jfree.chart.block.Arrangement)var5, (org.jfree.chart.block.Arrangement)var11);
//     
//     // Checks the contract:  equals-hashcode on var5 and var11
//     assertTrue("Contract failed: equals-hashcode on var5 and var11", var5.equals(var11) ? var5.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var5
//     assertTrue("Contract failed: equals-hashcode on var11 and var5", var11.equals(var5) ? var11.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test125"); }


    org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test126"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.lang.ClassLoader var2 = null;
//     java.util.ResourceBundle var3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("XYItemEntity: series = -1, item = 100, dataset = null", var1, var2);
// 
//   }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test127"); }


    org.jfree.chart.plot.PieLabelDistributor var1 = new org.jfree.chart.plot.PieLabelDistributor((-1));
    var1.clear();
    var1.clear();
    var1.distributeLabels((-1.0d), 0.0d);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test128"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.data.general.SeriesChangeEvent var19 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test129() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test129"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var1.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test130"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(10, var1);
// 
//   }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test131"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test132"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.data.time.TimeSeries var21 = null;
    java.util.TimeZone var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
    var13.setDataset((org.jfree.data.xy.XYDataset)var23);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var27 = var23.getYValue(10, (-165));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test133"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    org.jfree.chart.ChartRenderingInfo var30 = null;
    org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
    java.awt.geom.Point2D var32 = null;
    var13.zoomDomainAxes(1.0d, 10.0d, var31, var32);
    int var34 = var31.getSubplotCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);

  }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test134"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Color var12 = var8.brighter();
    var1.setPaint((java.awt.Paint)var12);
    java.lang.String var14 = var1.getURLText();
    double var15 = var1.getContentXOffset();
    java.lang.Object var16 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test135"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     java.lang.String var2 = var1.getNoDataMessage();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var5 = var4.getBaseItemLabelsVisible();
//     boolean var6 = var4.getAutoPopulateSeriesStroke();
//     org.jfree.chart.renderer.xy.XYItemRenderer[] var7 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var4};
//     var1.setRenderers(var7);
//     org.jfree.chart.util.RectangleEdge var10 = var1.getRangeAxisEdge((-1));
//     org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var13 = var12.isAxisLineVisible();
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var12.setTickLabelPaint((java.awt.Paint)var17);
//     java.awt.Paint var19 = var12.getTickLabelPaint();
//     org.jfree.data.category.CategoryDataset var20 = null;
//     org.jfree.chart.axis.CategoryAxis var22 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var23 = var22.isAxisLineVisible();
//     java.awt.Color var27 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var22.setTickLabelPaint((java.awt.Paint)var27);
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var33 = new org.jfree.chart.plot.CategoryPlot(var20, var22, var29, (org.jfree.chart.renderer.category.CategoryItemRenderer)var32);
//     java.awt.Image var34 = null;
//     var33.setBackgroundImage(var34);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var42 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var43 = var42.getRGB();
//     var37.setSeriesFillPaint(0, (java.awt.Paint)var42, true);
//     java.awt.Color var46 = var42.brighter();
//     var33.setRangeZeroBaselinePaint((java.awt.Paint)var46);
//     java.lang.Comparable var48 = null;
//     var33.setDomainCrosshairRowKey(var48, false);
//     org.jfree.chart.LegendItemCollection var51 = var33.getLegendItems();
//     java.lang.Comparable var52 = var33.getDomainCrosshairColumnKey();
//     java.awt.Stroke var53 = var33.getOutlineStroke();
//     var12.setTickMarkStroke(var53);
//     var1.setRangeZeroBaselineStroke(var53);
//     
//     // Checks the contract:  equals-hashcode on var4 and var37
//     assertTrue("Contract failed: equals-hashcode on var4 and var37", var4.equals(var37) ? var4.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var4
//     assertTrue("Contract failed: equals-hashcode on var37 and var4", var37.equals(var4) ? var37.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test136() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test136"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var3 = var2.getBaseItemLabelsVisible();
    boolean var4 = var2.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.ItemLabelPosition var6 = var2.getSeriesNegativeItemLabelPosition(10);
    org.jfree.chart.text.TextAnchor var7 = var6.getTextAnchor();
    org.jfree.chart.renderer.xy.XYAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var10 = var9.getBaseItemLabelsVisible();
    boolean var11 = var9.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.ItemLabelPosition var13 = var9.getSeriesNegativeItemLabelPosition(10);
    org.jfree.chart.text.TextAnchor var14 = var13.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var16 = new org.jfree.chart.labels.ItemLabelPosition(var0, var7, var14, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test137"); }


    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var2.configure();
    java.awt.Font var4 = var2.getTickLabelFont();
    org.jfree.chart.event.RendererChangeEvent var6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var4, true);
    org.jfree.chart.text.TextFragment var7 = new org.jfree.chart.text.TextFragment("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test138"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.axis.AxisSpace var20 = var1.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var22 = var1.getRangeAxisLocation((-165));
    org.jfree.chart.axis.AxisSpace var23 = null;
    var1.setFixedDomainAxisSpace(var23, false);
    org.jfree.chart.plot.Marker var27 = null;
    org.jfree.chart.util.Layer var28 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var30 = var1.removeRangeMarker(1, var27, var28, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test139"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    var13.clearDomainAxes();
    var13.configureDomainAxes();
    org.jfree.chart.plot.CategoryMarker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addDomainMarker(var20, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test140"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
//     java.lang.Comparable var8 = var7.getSeriesKey();
//     org.jfree.chart.util.HorizontalAlignment var9 = null;
//     org.jfree.chart.util.VerticalAlignment var10 = null;
//     org.jfree.chart.block.FlowArrangement var13 = new org.jfree.chart.block.FlowArrangement(var9, var10, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var14 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var16 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var13, var14, (java.lang.Comparable)(short)100);
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
//     java.lang.String var19 = var18.getNoDataMessage();
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var21.configure();
//     java.awt.Stroke var23 = var21.getTickMarkStroke();
//     var18.setRangeGridlineStroke(var23);
//     org.jfree.chart.plot.Marker var25 = null;
//     boolean var26 = var18.removeDomainMarker(var25);
//     var7.add((org.jfree.chart.block.Block)var16, (java.lang.Object)var26);
//     
//     // Checks the contract:  equals-hashcode on var4 and var13
//     assertTrue("Contract failed: equals-hashcode on var4 and var13", var4.equals(var13) ? var4.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var4
//     assertTrue("Contract failed: equals-hashcode on var13 and var4", var13.equals(var4) ? var13.hashCode() == var4.hashCode() : true);
// 
//   }

  public void test141() {}
//   public void test141() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test141"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
//     var4.setUseYInterval(false);
//     org.jfree.chart.labels.XYItemLabelGenerator var11 = var4.getItemLabelGenerator(0, 10, true);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.util.Layer var16 = null;
//     org.jfree.chart.ChartRenderingInfo var17 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var18 = new org.jfree.chart.plot.PlotRenderingInfo(var17);
//     var4.drawAnnotations(var12, var13, var14, var15, var16, var18);
// 
//   }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test142"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setDomainMinorGridlinesVisible(false);
    boolean var8 = var1.isRangeZeroBaselineVisible();
    org.jfree.chart.ChartRenderingInfo var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    java.awt.geom.Point2D var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.zoomRangeAxes((-1.0d), var11, var12, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test143"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.clearSectionPaints(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));

  }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test144"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var7 = var6.getRGB();
//     var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.axis.ValueAxis var11 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot(var11);
//     java.lang.String var13 = var12.getNoDataMessage();
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     var15.configure();
//     java.awt.Stroke var17 = var15.getTickMarkStroke();
//     var12.setRangeGridlineStroke(var17);
//     org.jfree.chart.plot.Marker var19 = null;
//     boolean var20 = var12.removeDomainMarker(var19);
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var27 = var23.getToolTipGenerator((-1), (-165), false);
//     var23.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var31 = null;
//     org.jfree.chart.entity.EntityCollection var32 = null;
//     org.jfree.chart.ChartRenderingInfo var33 = new org.jfree.chart.ChartRenderingInfo(var32);
//     java.awt.geom.Rectangle2D var34 = var33.getChartArea();
//     org.jfree.chart.axis.ValueAxis var35 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var36 = new org.jfree.chart.plot.CombinedDomainXYPlot(var35);
//     org.jfree.chart.util.RectangleEdge var38 = var36.getRangeAxisEdge((-1));
//     var36.clearDomainMarkers(1);
//     var36.setRangeCrosshairVisible(false);
//     int var43 = var36.getDatasetCount();
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var46 = null;
//     org.jfree.data.time.TimeSeriesCollection var47 = new org.jfree.data.time.TimeSeriesCollection(var45, var46);
//     org.jfree.chart.plot.PlotRenderingInfo var48 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var49 = var23.initialise(var31, var34, (org.jfree.chart.plot.XYPlot)var36, (org.jfree.data.xy.XYDataset)var47, var48);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var58 = var57.getRGB();
//     var52.setSeriesFillPaint(0, (java.awt.Paint)var57, true);
//     java.awt.Graphics2D var61 = null;
//     java.awt.geom.Rectangle2D var62 = null;
//     org.jfree.chart.plot.XYPlot var63 = null;
//     org.jfree.data.xy.XYDataset var64 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var65 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var66 = var52.initialise(var61, var62, var63, var64, var65);
//     java.awt.Font var67 = var52.getBaseLegendTextFont();
//     java.awt.Paint var69 = var52.lookupSeriesFillPaint(100);
//     java.awt.Stroke var70 = null;
//     var1.drawRangeLine(var10, (org.jfree.chart.plot.XYPlot)var12, var21, var34, 1.0d, var69, var70);
// 
//   }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test145"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot(var9);
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var18 = var17.getRGB();
    var12.setSeriesFillPaint(0, (java.awt.Paint)var17, true);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.XYPlot var23 = null;
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var26 = var12.initialise(var21, var22, var23, var24, var25);
    java.awt.Font var27 = var12.getBaseLegendTextFont();
    int var28 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var10.setRenderer(1, var30);
    boolean var32 = var7.equals((java.lang.Object)1);
    org.jfree.chart.block.LabelBlock var34 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var36 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var42 = var41.getRGB();
    var36.setSeriesFillPaint(0, (java.awt.Paint)var41, true);
    java.awt.Color var45 = var41.brighter();
    var34.setPaint((java.awt.Paint)var45);
    var34.setID("Preceding");
    var7.add((org.jfree.chart.block.Block)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test146() {}
//   public void test146() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test146"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
//     java.lang.Comparable var8 = var7.getSeriesKey();
//     java.util.List var9 = var7.getBlocks();
//     java.lang.String var10 = var7.getURLText();
//     java.lang.String var11 = var7.getURLText();
//     java.awt.Graphics2D var12 = null;
//     org.jfree.data.Range var14 = null;
//     org.jfree.chart.block.RectangleConstraint var15 = new org.jfree.chart.block.RectangleConstraint(1.0d, var14);
//     org.jfree.chart.util.Size2D var16 = var7.arrange(var12, var15);
// 
//   }

  public void test147() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test147"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    java.awt.Stroke var5 = var1.getRangeZeroBaselineStroke();
    java.util.List var6 = var1.getAnnotations();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test148"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    org.jfree.chart.labels.XYToolTipGenerator var4 = var1.getSeriesToolTipGenerator(0);
    boolean var6 = var1.isSeriesItemLabelsVisible(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test149"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var9 = var1.getLegendItemLabelGenerator();
    org.jfree.chart.util.GradientPaintTransformer var10 = var1.getGradientTransformer();
    java.awt.Shape var12 = var1.lookupSeriesShape(0);
    org.jfree.chart.JFreeChart var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var14 = new org.jfree.chart.entity.JFreeChartEntity(var12, var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test150"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var17 = var16.getBaseItemLabelsVisible();
//     java.awt.Shape var21 = var16.getItemShape(0, 1, false);
//     var12.setBaseLegendShape(var21);
//     double var23 = var12.getMaximumBarWidth();
//     var12.setAutoPopulateSeriesFillPaint(false);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.data.category.CategoryDataset var27 = null;
//     org.jfree.chart.axis.CategoryAxis var29 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var30 = var29.isAxisLineVisible();
//     java.awt.Color var34 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var29.setTickLabelPaint((java.awt.Paint)var34);
//     org.jfree.chart.axis.ValueAxis var36 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var39 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var40 = new org.jfree.chart.plot.CategoryPlot(var27, var29, var36, (org.jfree.chart.renderer.category.CategoryItemRenderer)var39);
//     java.awt.Image var41 = null;
//     var40.setBackgroundImage(var41);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var44 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var49 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var50 = var49.getRGB();
//     var44.setSeriesFillPaint(0, (java.awt.Paint)var49, true);
//     java.awt.Color var53 = var49.brighter();
//     var40.setRangeZeroBaselinePaint((java.awt.Paint)var53);
//     java.lang.Comparable var55 = null;
//     var40.setDomainCrosshairRowKey(var55, false);
//     org.jfree.chart.LegendItemCollection var58 = var40.getLegendItems();
//     java.lang.Comparable var59 = var40.getDomainCrosshairColumnKey();
//     org.jfree.chart.event.MarkerChangeEvent var60 = null;
//     var40.markerChanged(var60);
//     org.jfree.chart.entity.EntityCollection var62 = null;
//     org.jfree.chart.ChartRenderingInfo var63 = new org.jfree.chart.ChartRenderingInfo(var62);
//     java.awt.geom.Rectangle2D var64 = var63.getChartArea();
//     var12.drawOutline(var26, var40, var64);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test151"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    org.jfree.chart.axis.AxisLocation var18 = var13.getDomainAxisLocation(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test152() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test152"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + Double.NaN+ "'", var3.equals(Double.NaN));

  }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test153"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths((-1), var1);
// 
//   }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test154"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.add(var4, (java.lang.Number)(short)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test155"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    java.awt.Paint var6 = var1.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.AxisSpace var7 = null;
    var1.setFixedRangeAxisSpace(var7);
    var1.setRangeCrosshairVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test156"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.plot.DrawingSupplier var5 = var2.getDrawingSupplier();
    var2.setBaseItemLabelsVisible(true, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test157() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test157"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataItem var3 = var1.remove((-126));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test158"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var2 = var1.getNumberFormat();
    int var3 = var2.getMaximumFractionDigits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 3);

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test159"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.awt.Image var28 = var13.getBackgroundImage();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test160"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var1.notifyListeners(var6);
    java.awt.Stroke var9 = null;
    var1.setSeriesOutlineStroke(1, var9);
    var1.removeAnnotations();
    boolean var12 = var1.getAutoPopulateSeriesOutlinePaint();
    var1.setSeriesVisible(100, (java.lang.Boolean)true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test161"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var5 = var3.getDomainAxisLocation(1);
    boolean var6 = var1.equals((java.lang.Object)var5);
    boolean var7 = var1.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test162"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("XYItemEntity: series = -1, item = 100, dataset = null", "#ffff5b", "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test163"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getMaximumExplodePercent();
    java.awt.Paint var3 = var1.getLabelOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test164"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("#ffff5b", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test165"); }


    org.jfree.chart.ui.Contributor var2 = new org.jfree.chart.ui.Contributor("", "Preceding");
    java.lang.String var3 = var2.getEmail();
    java.lang.String var4 = var2.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "Preceding"+ "'", var3.equals("Preceding"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test166"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    var1.setLabelURL("#ffff5b");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test167"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    double var23 = var12.getMaximumBarWidth();
    org.jfree.chart.labels.CategoryToolTipGenerator var25 = var12.getSeriesToolTipGenerator(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test168"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     java.text.DateFormat var3 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
//     org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var13 = var9.getToolTipGenerator((-1), (-165), false);
//     var9.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Shape var18 = var9.getSeriesShape((-1));
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot(var20);
//     org.jfree.chart.axis.AxisLocation var23 = var21.getDomainAxisLocation(1);
//     java.awt.Paint var24 = var21.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.ValueAxis var25 = null;
//     org.jfree.chart.plot.Marker var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     var9.drawRangeMarker(var19, (org.jfree.chart.plot.XYPlot)var21, var25, var26, var27);
//     org.jfree.data.time.TimeSeries var29 = null;
//     java.util.TimeZone var30 = null;
//     org.jfree.data.time.TimeSeriesCollection var31 = new org.jfree.data.time.TimeSeriesCollection(var29, var30);
//     var21.setDataset((org.jfree.data.xy.XYDataset)var31);
//     java.lang.String var35 = var6.generateURL((org.jfree.data.xy.XYDataset)var31, 1, (-126));
//     
//     // Checks the contract:  equals-hashcode on var7 and var9
//     assertTrue("Contract failed: equals-hashcode on var7 and var9", var7.equals(var9) ? var7.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var7
//     assertTrue("Contract failed: equals-hashcode on var9 and var7", var9.equals(var7) ? var9.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test169"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(10.0d, 0.0d);

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test170"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("Preceding");
    var1.setDomainDescription("Preceding");
    java.util.List var6 = var1.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test171() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test171"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setSeriesIndex((-1));
    org.jfree.chart.util.GradientPaintTransformer var4 = var1.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test172"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    float var3 = var1.getTickMarkInsideLength();
    var1.clearCategoryLabelToolTips();
    java.awt.Paint var5 = var1.getAxisLinePaint();
    java.lang.String var6 = var1.getLabelToolTip();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test173"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    java.awt.Paint var8 = var1.getSeriesOutlinePaint(100);
    org.jfree.data.general.PieDataset var10 = null;
    org.jfree.chart.plot.PiePlot3D var11 = new org.jfree.chart.plot.PiePlot3D(var10);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var13 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var14 = var13.getNumberFormat();
    var11.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var13);
    java.awt.Paint var16 = var11.getBaseSectionOutlinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-126), var16, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test174"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Preceding", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test175"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.data.time.TimeSeries var21 = null;
    java.util.TimeZone var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
    var13.setDataset((org.jfree.data.xy.XYDataset)var23);
    java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var23);
    java.util.List var26 = var23.getSeries();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test176"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    var1.setMaximumItemCount(100);

  }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test177"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var9 = var7.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var7.getSeriesItemLabelGenerator(0);
    var7.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var7.getBasePositiveItemLabelPosition();
    var2.setPositiveItemLabelPositionFallback(var14);
    org.jfree.chart.labels.CategoryToolTipGenerator var17 = var2.getSeriesToolTipGenerator((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test178"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-1.0d), (java.lang.Number)0);
    java.lang.Object var3 = var2.clone();
    boolean var5 = var2.equals((java.lang.Object)(short)100);
    java.lang.Number var6 = var2.getY();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 0+ "'", var6.equals(0));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test179"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete((-126), 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test180"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot(var31);
    org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(1);
    boolean var35 = var30.equals((java.lang.Object)var34);
    org.jfree.chart.axis.AxisLocation var36 = org.jfree.chart.axis.AxisLocation.getOpposite(var34);
    var13.setRangeAxisLocation(var34);
    org.jfree.chart.axis.AxisLocation var38 = var13.getDomainAxisLocation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test181"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var4 = var1.isSeriesVisible(1);
    var1.setSeriesCreateEntities(1, (java.lang.Boolean)false, false);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot(var9);
    org.jfree.chart.util.RectangleEdge var12 = var10.getRangeAxisEdge((-1));
    org.jfree.chart.axis.AxisLocation var14 = var10.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataset var15 = null;
    int var16 = var10.indexOf(var15);
    var10.setDomainZeroBaselineVisible(false);
    var1.addChangeListener((org.jfree.chart.event.RendererChangeListener)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test182"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Paint var17 = var1.lookupSeriesFillPaint(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test183"); }


    org.jfree.data.Range var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var3 = org.jfree.data.Range.shift(var0, 1.0d, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test184"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    var1.setRangeCrosshairValue(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test185"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
//     int var4 = var1.getRangeAxisCount();
//     org.jfree.chart.axis.ValueAxis var6 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot(var6);
//     org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation(1);
//     java.awt.Paint var10 = var7.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.AxisLocation var11 = var7.getDomainAxisLocation();
//     var1.setDomainAxisLocation(0, var11);
//     
//     // Checks the contract:  equals-hashcode on var1 and var7
//     assertTrue("Contract failed: equals-hashcode on var1 and var7", var1.equals(var7) ? var1.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var1
//     assertTrue("Contract failed: equals-hashcode on var7 and var1", var7.equals(var1) ? var7.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test186"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, 10.0d, 0.0d);
    var4.clear();

  }

  public void test187() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test187"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var1.setRenderer(1, var21);
    org.jfree.chart.ChartRenderingInfo var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
    var1.handleClick(1, 1, var26);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    java.awt.Stroke var30 = var29.getBaseSectionOutlineStroke();
    var1.setRangeMinorGridlineStroke(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test188() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test188"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    var1.setWeight(100);
    org.jfree.data.Range var5 = null;
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint(var5, 100.0d);
    org.jfree.chart.block.RectangleConstraint var9 = var7.toFixedWidth(10.0d);
    java.lang.String var10 = var7.toString();
    org.jfree.chart.block.RectangleConstraint var12 = var7.toFixedHeight(0.0d);
    boolean var13 = var1.equals((java.lang.Object)var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var10.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test189"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    org.jfree.data.category.CategoryDataset var18 = null;
    int var19 = var13.indexOf(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test190"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    org.jfree.chart.plot.XYCrosshairState var16 = var15.getCrosshairState();
    org.jfree.data.xy.XYDataset var17 = null;
    var15.endSeriesPass(var17, (-1), 10, 0, (-165), 0);
    org.jfree.data.xy.XYDatasetSelectionState var24 = null;
    var15.setSelectionState(var24);
    int var26 = var15.getFirstItemIndex();
    org.jfree.data.time.TimeSeries var27 = null;
    java.util.TimeZone var28 = null;
    org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
    var29.clearSelection();
    var15.endSeriesPass((org.jfree.data.xy.XYDataset)var29, 0, (-126), 10, (-1), 100);
    org.jfree.data.Range var38 = var29.getDomainBounds(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test191() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test191"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var1.notifyListeners(var6);
    java.awt.Stroke var9 = null;
    var1.setSeriesOutlineStroke(1, var9);
    boolean var11 = var1.getAutoPopulateSeriesShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test192"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    var1.setURLText("Preceding");
    org.jfree.chart.util.GradientPaintTransformer var11 = var1.getFillPaintTransformer();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test193() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test193"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.entity.EntityCollection var2 = null;
    var1.setEntityCollection(var2);

  }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test194"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-126), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test195"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Paint var2 = null;
    var1.setBasePaint(var2);
    java.awt.Color var6 = java.awt.Color.getColor("#ffff5b", 10);
    var1.setBaseFillPaint((java.awt.Paint)var6, false);
    java.lang.Object var9 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test196"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var2 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var6 = var2.getToolTipGenerator((-1), (-165), false);
//     var2.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var10 = null;
//     org.jfree.chart.entity.EntityCollection var11 = null;
//     org.jfree.chart.ChartRenderingInfo var12 = new org.jfree.chart.ChartRenderingInfo(var11);
//     java.awt.geom.Rectangle2D var13 = var12.getChartArea();
//     org.jfree.chart.axis.ValueAxis var14 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var15 = new org.jfree.chart.plot.CombinedDomainXYPlot(var14);
//     org.jfree.chart.util.RectangleEdge var17 = var15.getRangeAxisEdge((-1));
//     var15.clearDomainMarkers(1);
//     var15.setRangeCrosshairVisible(false);
//     int var22 = var15.getDatasetCount();
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var25 = null;
//     org.jfree.data.time.TimeSeriesCollection var26 = new org.jfree.data.time.TimeSeriesCollection(var24, var25);
//     org.jfree.chart.plot.PlotRenderingInfo var27 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var28 = var2.initialise(var10, var13, (org.jfree.chart.plot.XYPlot)var15, (org.jfree.data.xy.XYDataset)var26, var27);
//     boolean var29 = org.jfree.chart.util.ShapeUtilities.intersects(var0, var13);
// 
//   }

  public void test197() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test197"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)0L);
    var1.add(100.0d, (java.lang.Number)10.0d);

  }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test198"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-165), (java.lang.Number)(-1.0d));

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test199"); }


    org.jfree.data.Range var0 = null;
    org.jfree.chart.block.RectangleConstraint var2 = new org.jfree.chart.block.RectangleConstraint(var0, 100.0d);
    org.jfree.chart.block.RectangleConstraint var4 = var2.toFixedWidth(10.0d);
    java.lang.String var5 = var2.toString();
    org.jfree.data.Range var6 = var2.getHeightRange();
    org.jfree.chart.block.LengthConstraintType var7 = var2.getWidthConstraintType();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var5.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test200"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test201"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.util.RectangleInsets var9 = var7.getPadding();
    double var11 = var9.calculateTopInset(10.0d);
    double var12 = var9.getRight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test202"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("hi!");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test203"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.PieDataset var3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(var0, (java.lang.Comparable)"#ffff5b", 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test204"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    var1.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, false);
    org.jfree.chart.labels.ItemLabelPosition var22 = null;
    var1.setSeriesNegativeItemLabelPosition(0, var22, true);
    org.jfree.chart.labels.XYItemLabelGenerator var25 = null;
    var1.setBaseItemLabelGenerator(var25, false);
    org.jfree.chart.labels.XYItemLabelGenerator var29 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesItemLabelGenerator((-1), var29, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test205() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test205"); }


    java.awt.Shape var2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross(1.0f, 10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test206() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test206"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getMaximumExplodePercent();
    var1.setExplodePercent((java.lang.Comparable)"#ffff5b", 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);

  }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test207"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var13.getRangeMarkers(var32);
    org.jfree.chart.axis.ValueAxis var35 = var13.getRangeAxis((-1));
    double var36 = var13.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test208"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setDomainMinorGridlinesVisible(false);
    boolean var8 = var1.isRangeZeroBaselineVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var10 = var1.getRangeAxisForDataset((-126));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test209"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    boolean var9 = var1.isShapeVisible();
    var1.setLineVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test210"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     boolean var2 = var1.getLabelLinksVisible();
//     org.jfree.chart.plot.PieLabelLinkStyle var3 = var1.getLabelLinkStyle();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var9 = var5.getToolTipGenerator((-1), (-165), false);
//     var5.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.entity.EntityCollection var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getChartArea();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
//     org.jfree.chart.util.RectangleEdge var20 = var18.getRangeAxisEdge((-1));
//     var18.clearDomainMarkers(1);
//     var18.setRangeCrosshairVisible(false);
//     int var25 = var18.getDatasetCount();
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var31 = var5.initialise(var13, var16, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.data.xy.XYDataset)var29, var30);
//     boolean var32 = var3.equals((java.lang.Object)var18);
//     org.jfree.chart.plot.Marker var34 = null;
//     org.jfree.chart.util.Layer var35 = null;
//     var18.addRangeMarker(10, var34, var35);
// 
//   }

  public void test211() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test211"); }


    org.jfree.chart.event.RendererChangeEvent var1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=Preceding]"+ "'", var2.equals("org.jfree.chart.event.RendererChangeEvent[source=Preceding]"));

  }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test212"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.JFreeChart var14 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.JFreeChartEntity var17 = new org.jfree.chart.entity.JFreeChartEntity(var7, var14, "Preceding", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test213"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var1);
// 
//   }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test214"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var7 = var6.getRGB();
//     var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = null;
//     org.jfree.data.xy.XYDataset var13 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
//     org.jfree.chart.plot.XYCrosshairState var16 = var15.getCrosshairState();
//     org.jfree.data.xy.XYDataset var17 = null;
//     var15.endSeriesPass(var17, (-1), 10, 0, (-165), 0);
//     org.jfree.data.xy.XYDatasetSelectionState var24 = null;
//     var15.setSelectionState(var24);
//     int var26 = var15.getFirstItemIndex();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var34 = var33.getRGB();
//     var28.setSeriesFillPaint(0, (java.awt.Paint)var33, true);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.chart.plot.XYPlot var39 = null;
//     org.jfree.data.xy.XYDataset var40 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var41 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var42 = var28.initialise(var37, var38, var39, var40, var41);
//     org.jfree.chart.plot.XYCrosshairState var43 = var42.getCrosshairState();
//     org.jfree.data.xy.XYDataset var44 = null;
//     var42.endSeriesPass(var44, (-1), 10, 0, (-165), 0);
//     org.jfree.data.xy.XYDatasetSelectionState var51 = null;
//     var42.setSelectionState(var51);
//     int var53 = var42.getFirstItemIndex();
//     org.jfree.data.time.TimeSeries var54 = null;
//     java.util.TimeZone var55 = null;
//     org.jfree.data.time.TimeSeriesCollection var56 = new org.jfree.data.time.TimeSeriesCollection(var54, var55);
//     var56.clearSelection();
//     var42.endSeriesPass((org.jfree.data.xy.XYDataset)var56, 0, (-126), 10, (-1), 100);
//     var15.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState)var56);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var66 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var70 = var66.getToolTipGenerator((-1), (-165), false);
//     var66.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Shape var75 = var66.getSeriesShape((-1));
//     java.awt.Graphics2D var76 = null;
//     org.jfree.chart.axis.ValueAxis var77 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var78 = new org.jfree.chart.plot.CombinedDomainXYPlot(var77);
//     org.jfree.chart.axis.AxisLocation var80 = var78.getDomainAxisLocation(1);
//     java.awt.Paint var81 = var78.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.ValueAxis var82 = null;
//     org.jfree.chart.plot.Marker var83 = null;
//     java.awt.geom.Rectangle2D var84 = null;
//     var66.drawRangeMarker(var76, (org.jfree.chart.plot.XYPlot)var78, var82, var83, var84);
//     org.jfree.data.time.TimeSeries var86 = null;
//     java.util.TimeZone var87 = null;
//     org.jfree.data.time.TimeSeriesCollection var88 = new org.jfree.data.time.TimeSeriesCollection(var86, var87);
//     var78.setDataset((org.jfree.data.xy.XYDataset)var88);
//     org.jfree.data.general.DatasetChangeEvent var90 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var15, (org.jfree.data.general.Dataset)var88);
//     
//     // Checks the contract:  equals-hashcode on var1 and var66
//     assertTrue("Contract failed: equals-hashcode on var1 and var66", var1.equals(var66) ? var1.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var66
//     assertTrue("Contract failed: equals-hashcode on var28 and var66", var28.equals(var66) ? var28.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var1
//     assertTrue("Contract failed: equals-hashcode on var66 and var1", var66.equals(var1) ? var66.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var28
//     assertTrue("Contract failed: equals-hashcode on var66 and var28", var66.equals(var28) ? var66.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var88
//     assertTrue("Contract failed: equals-hashcode on var56 and var88", var56.equals(var88) ? var56.hashCode() == var88.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var88 and var56
//     assertTrue("Contract failed: equals-hashcode on var88 and var56", var88.equals(var56) ? var88.hashCode() == var56.hashCode() : true);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test215"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(10.0f);
    java.awt.Shape var5 = org.jfree.chart.util.ShapeUtilities.rotateShape(var1, 1.0d, 10.0f, 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test216"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Paint[] var10 = new java.awt.Paint[] { var6};
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Stroke var16 = null;
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    java.awt.Stroke[] var18 = null;
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var15, var17, var18, var20);
    java.awt.Paint var22 = var21.getNextPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var30 = var29.getRGB();
    var24.setSeriesFillPaint(0, (java.awt.Paint)var29, true);
    boolean var33 = var21.equals((java.lang.Object)0);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, (org.jfree.chart.renderer.xy.XYItemRenderer)var38);
    boolean var40 = var21.equals((java.lang.Object)var39);
    org.jfree.chart.renderer.category.BarRenderer3D var43 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var45 = var43.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var47 = var43.getSeriesItemLabelGenerator(0);
    var43.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var50 = var43.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var51 = var43.getPositiveItemLabelPositionFallback();
    int var52 = var43.getColumnCount();
    org.jfree.data.category.CategoryDataset var53 = null;
    org.jfree.chart.axis.CategoryAxis var55 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var56 = var55.isAxisLineVisible();
    java.awt.Color var60 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var55.setTickLabelPaint((java.awt.Paint)var60);
    org.jfree.chart.axis.ValueAxis var62 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var65 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var66 = new org.jfree.chart.plot.CategoryPlot(var53, var55, var62, (org.jfree.chart.renderer.category.CategoryItemRenderer)var65);
    org.jfree.chart.plot.DrawingSupplier var67 = var66.getDrawingSupplier();
    org.jfree.chart.plot.Marker var69 = null;
    org.jfree.chart.util.Layer var70 = null;
    boolean var71 = var66.removeDomainMarker(100, var69, var70);
    org.jfree.chart.plot.Marker var73 = null;
    org.jfree.chart.util.Layer var74 = null;
    boolean var76 = var66.removeDomainMarker(100, var73, var74, false);
    var43.setPlot(var66);
    java.awt.Paint var78 = var66.getRangeCrosshairPaint();
    boolean var79 = var21.equals((java.lang.Object)var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test217"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
//     org.jfree.chart.plot.DrawingSupplier var5 = var2.getDrawingSupplier();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var7 = null;
//     org.jfree.chart.util.HorizontalAlignment var8 = null;
//     org.jfree.chart.util.VerticalAlignment var9 = null;
//     org.jfree.chart.block.FlowArrangement var12 = new org.jfree.chart.block.FlowArrangement(var8, var9, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var13 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var12, var13, (java.lang.Comparable)(short)100);
//     java.lang.Object var16 = var15.clone();
//     org.jfree.chart.util.RectangleInsets var17 = var15.getPadding();
//     org.jfree.chart.entity.EntityCollection var18 = null;
//     org.jfree.chart.ChartRenderingInfo var19 = new org.jfree.chart.ChartRenderingInfo(var18);
//     java.awt.geom.Rectangle2D var20 = var19.getChartArea();
//     java.awt.geom.Rectangle2D var21 = var17.createInsetRectangle(var20);
//     org.jfree.data.category.CategoryDataset var22 = null;
//     org.jfree.chart.axis.CategoryAxis var24 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var25 = var24.isAxisLineVisible();
//     java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var24.setTickLabelPaint((java.awt.Paint)var29);
//     org.jfree.chart.axis.ValueAxis var31 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var34 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var35 = new org.jfree.chart.plot.CategoryPlot(var22, var24, var31, (org.jfree.chart.renderer.category.CategoryItemRenderer)var34);
//     org.jfree.chart.plot.DrawingSupplier var36 = var35.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var38 = null;
//     org.jfree.chart.util.Layer var39 = null;
//     boolean var40 = var35.removeDomainMarker(100, var38, var39);
//     var35.clearDomainMarkers(0);
//     org.jfree.data.category.CategoryDataset var43 = null;
//     org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var46 = var45.isAxisLineVisible();
//     java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var45.setTickLabelPaint((java.awt.Paint)var50);
//     org.jfree.chart.axis.ValueAxis var52 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var43, var45, var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
//     org.jfree.chart.plot.DrawingSupplier var57 = var56.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var59 = null;
//     org.jfree.chart.util.Layer var60 = null;
//     boolean var61 = var56.removeDomainMarker(100, var59, var60);
//     var56.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var65 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var66 = var65.getBaseItemLabelsVisible();
//     java.awt.Paint var70 = var65.getItemFillPaint((-1), (-1), true);
//     var56.setRangeGridlinePaint(var70);
//     org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     org.jfree.chart.axis.ValueAxis var74 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var75 = new org.jfree.chart.plot.CombinedDomainXYPlot(var74);
//     org.jfree.chart.axis.AxisLocation var77 = var75.getDomainAxisLocation(1);
//     boolean var78 = var73.equals((java.lang.Object)var77);
//     org.jfree.chart.axis.AxisLocation var79 = org.jfree.chart.axis.AxisLocation.getOpposite(var77);
//     var56.setRangeAxisLocation(var77);
//     org.jfree.chart.axis.CategoryAxis var81 = var56.getDomainAxis();
//     org.jfree.chart.axis.ValueAxis var82 = null;
//     org.jfree.data.category.CategoryDataset var83 = null;
//     var2.drawItem(var6, var7, var20, var35, var81, var82, var83, 0, 0, false, 10);
// 
//   }

  public void test218() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test218"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYToolTipGenerator var10 = var1.getSeriesToolTipGenerator((-126));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test219"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var6 = null;
    org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var5, var6);
    int var8 = var1.indexOf((org.jfree.data.xy.XYDataset)var7);
    var1.setDomainMinorGridlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test220() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test220"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    java.awt.Stroke var13 = var2.getItemStroke(1, (-1), true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test221"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDescription("hi!");
    org.jfree.data.time.RegularTimePeriod var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var1.getValue(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test222() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test222"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    var13.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge((-1));
    var24.clearDomainMarkers(1);
    var13.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
    org.jfree.chart.renderer.xy.XYAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var35 = var31.getToolTipGenerator((-1), (-165), false);
    var31.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var40 = var31.getSeriesShape((-1));
    java.awt.Graphics2D var41 = null;
    org.jfree.chart.axis.ValueAxis var42 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var43 = new org.jfree.chart.plot.CombinedDomainXYPlot(var42);
    org.jfree.chart.axis.AxisLocation var45 = var43.getDomainAxisLocation(1);
    java.awt.Paint var46 = var43.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.plot.Marker var48 = null;
    java.awt.geom.Rectangle2D var49 = null;
    var31.drawRangeMarker(var41, (org.jfree.chart.plot.XYPlot)var43, var47, var48, var49);
    org.jfree.data.time.TimeSeries var51 = null;
    java.util.TimeZone var52 = null;
    org.jfree.data.time.TimeSeriesCollection var53 = new org.jfree.data.time.TimeSeriesCollection(var51, var52);
    var43.setDataset((org.jfree.data.xy.XYDataset)var53);
    var24.add((org.jfree.chart.plot.XYPlot)var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test223"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
//     java.lang.Object var8 = var7.clone();
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot(var9);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var18 = var17.getRGB();
//     var12.setSeriesFillPaint(0, (java.awt.Paint)var17, true);
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     org.jfree.chart.plot.XYPlot var23 = null;
//     org.jfree.data.xy.XYDataset var24 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var25 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var26 = var12.initialise(var21, var22, var23, var24, var25);
//     java.awt.Font var27 = var12.getBaseLegendTextFont();
//     int var28 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
//     var10.setRenderer(1, var30);
//     boolean var32 = var7.equals((java.lang.Object)1);
//     org.jfree.chart.util.HorizontalAlignment var33 = null;
//     org.jfree.chart.util.VerticalAlignment var34 = null;
//     org.jfree.chart.block.FlowArrangement var37 = new org.jfree.chart.block.FlowArrangement(var33, var34, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var38 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var40 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var37, var38, (java.lang.Comparable)(short)100);
//     java.lang.Object var41 = var40.clone();
//     org.jfree.chart.util.RectangleInsets var42 = var40.getPadding();
//     org.jfree.chart.entity.EntityCollection var43 = null;
//     org.jfree.chart.ChartRenderingInfo var44 = new org.jfree.chart.ChartRenderingInfo(var43);
//     java.awt.geom.Rectangle2D var45 = var44.getChartArea();
//     java.awt.geom.Rectangle2D var46 = var42.createInsetRectangle(var45);
//     double var48 = var42.calculateBottomInset(0.0d);
//     var7.setPadding(var42);
//     
//     // Checks the contract:  equals-hashcode on var4 and var37
//     assertTrue("Contract failed: equals-hashcode on var4 and var37", var4.equals(var37) ? var4.hashCode() == var37.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var37 and var4
//     assertTrue("Contract failed: equals-hashcode on var37 and var4", var37.equals(var4) ? var37.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var40
//     assertTrue("Contract failed: equals-hashcode on var7 and var40", var7.equals(var40) ? var7.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var7
//     assertTrue("Contract failed: equals-hashcode on var40 and var7", var40.equals(var7) ? var40.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var41
//     assertTrue("Contract failed: equals-hashcode on var8 and var41", var8.equals(var41) ? var8.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var8
//     assertTrue("Contract failed: equals-hashcode on var41 and var8", var41.equals(var8) ? var41.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test224"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    org.jfree.chart.block.Arrangement var8 = var7.getArrangement();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test225() {}
//   public void test225() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test225"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.awt.Graphics2D var2 = null;
//     org.jfree.chart.util.HorizontalAlignment var3 = null;
//     org.jfree.chart.util.VerticalAlignment var4 = null;
//     org.jfree.chart.block.FlowArrangement var7 = new org.jfree.chart.block.FlowArrangement(var3, var4, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var8 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var7, var8, (java.lang.Comparable)(short)100);
//     java.lang.Object var11 = var10.clone();
//     org.jfree.chart.util.RectangleInsets var12 = var10.getPadding();
//     org.jfree.chart.entity.EntityCollection var13 = null;
//     org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
//     java.awt.geom.Rectangle2D var15 = var14.getChartArea();
//     java.awt.geom.Rectangle2D var16 = var12.createInsetRectangle(var15);
//     var1.drawBackground(var2, var15);
// 
//   }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test226"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.XYPlot var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.plot.Marker var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    var1.drawRangeMarker(var3, var4, var5, var6, var7);
    var1.setAutoPopulateSeriesStroke(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesItemLabelsVisible((-165), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test227"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setDomainMinorGridlinesVisible(false);
    boolean var8 = var1.isRangeZeroBaselineVisible();
    var1.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.data.Range var12 = var1.getDataRange(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test228"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var16 = null;
//     org.jfree.chart.util.Layer var17 = null;
//     boolean var18 = var13.removeDomainMarker(100, var16, var17);
//     org.jfree.chart.plot.Marker var20 = null;
//     org.jfree.chart.util.Layer var21 = null;
//     boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
//     org.jfree.chart.axis.AxisSpace var24 = null;
//     var13.setFixedRangeAxisSpace(var24, false);
//     org.jfree.chart.axis.AxisSpace var27 = null;
//     var13.setFixedRangeAxisSpace(var27, false);
//     org.jfree.chart.plot.Marker var30 = null;
//     var13.addRangeMarker(var30);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test229"); }


    org.jfree.chart.labels.StandardXYSeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("hi!");
    java.lang.Object var2 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test230"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    org.jfree.chart.axis.CategoryAxis var29 = var13.getDomainAxis(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test231"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    var2.setDrawBarOutline(false);
    java.lang.Object var11 = null;
    boolean var12 = var2.equals(var11);
    var2.setBaseSeriesVisibleInLegend(false);
    java.awt.Shape var16 = var2.getSeriesShape((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test232"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    java.awt.Shape var7 = var1.getBaseShape();
    var1.setAutoPopulateSeriesOutlineStroke(true);
    java.awt.Font var13 = var1.getItemLabelFont(0, (-126), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test233"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var7 = var6.getRGB();
//     var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
//     java.awt.Paint[] var10 = new java.awt.Paint[] { var6};
//     java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
//     java.awt.Stroke var16 = null;
//     java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
//     java.awt.Stroke[] var18 = null;
//     java.awt.Shape var19 = null;
//     java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
//     org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var15, var17, var18, var20);
//     java.lang.Object var22 = var21.clone();
//     java.awt.Stroke var23 = var21.getNextOutlineStroke();
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test234"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var2 = var1.getLabel();
    var1.setToolTipText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    int var5 = var1.getSeriesIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var2.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test235"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    var2.setItemMargin(1.0d);

  }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test236"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    org.jfree.chart.event.RendererChangeEvent var11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    boolean var12 = var11.getSeriesVisibilityChanged();
    var1.notifyListeners(var11);
    org.jfree.chart.JFreeChart var14 = null;
    var11.setChart(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test237"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var1.setLowerMargin(10.0d);
    java.util.TimeZone var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTimeZone(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test238"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getMaximumExplodePercent();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot(var3);
    org.jfree.chart.renderer.xy.XYAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var12 = var11.getRGB();
    var6.setSeriesFillPaint(0, (java.awt.Paint)var11, true);
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.plot.XYPlot var17 = null;
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var20 = var6.initialise(var15, var16, var17, var18, var19);
    java.awt.Font var21 = var6.getBaseLegendTextFont();
    int var22 = var4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var6);
    org.jfree.chart.axis.AxisSpace var23 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var4.getRangeAxisLocation((-165));
    java.awt.Stroke var26 = var4.getRangeGridlineStroke();
    var1.setLabelLinkStroke(var26);
    boolean var28 = var1.getLabelLinksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test239"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var2 = var1.getNumberFormat();
    java.math.RoundingMode var3 = var2.getRoundingMode();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test240"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("XYItemEntity: series = -1, item = 100, dataset = null", "org.jfree.chart.event.RendererChangeEvent[source=Preceding]", "#ffff5b", "");

  }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test241"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var2 = null;
//     org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var9 = var5.getToolTipGenerator((-1), (-165), false);
//     var5.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.entity.EntityCollection var14 = null;
//     org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
//     java.awt.geom.Rectangle2D var16 = var15.getChartArea();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
//     org.jfree.chart.util.RectangleEdge var20 = var18.getRangeAxisEdge((-1));
//     var18.clearDomainMarkers(1);
//     var18.setRangeCrosshairVisible(false);
//     int var25 = var18.getDatasetCount();
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var31 = var5.initialise(var13, var16, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.data.xy.XYDataset)var29, var30);
//     var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var3 and var29
//     assertTrue("Contract failed: equals-hashcode on var3 and var29", var3.equals(var29) ? var3.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var3
//     assertTrue("Contract failed: equals-hashcode on var29 and var3", var29.equals(var3) ? var29.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test242"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
//     int var4 = var1.getRangeAxisCount();
//     var1.clearAnnotations();
//     java.awt.Paint var6 = var1.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.ValueAxis var7 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot(var7);
//     org.jfree.chart.axis.AxisLocation var10 = var8.getDomainAxisLocation(1);
//     java.awt.Paint var11 = var8.getDomainZeroBaselinePaint();
//     java.awt.Stroke var12 = var8.getRangeZeroBaselineStroke();
//     var1.setDomainZeroBaselineStroke(var12);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test243"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var7 = var5.getSeriesItemLabelPaint(0);
//     org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var12 = var10.getSeriesItemLabelPaint(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var10.getSeriesItemLabelGenerator(0);
//     var10.setShadowVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var17 = var10.getBasePositiveItemLabelPosition();
//     var5.setPositiveItemLabelPositionFallback(var17);
//     java.awt.Shape var20 = var5.lookupSeriesShape(10);
//     java.awt.Shape var22 = var5.getSeriesShape((-165));
//     org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.plot.CategoryPlot var25 = null;
//     org.jfree.chart.axis.CategoryAxis var27 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var28 = var27.isAxisLineVisible();
//     float var29 = var27.getTickMarkInsideLength();
//     var27.clearCategoryLabelToolTips();
//     org.jfree.chart.plot.CategoryMarker var31 = null;
//     org.jfree.chart.util.HorizontalAlignment var32 = null;
//     org.jfree.chart.util.VerticalAlignment var33 = null;
//     org.jfree.chart.block.FlowArrangement var36 = new org.jfree.chart.block.FlowArrangement(var32, var33, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var37 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var39 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var36, var37, (java.lang.Comparable)(short)100);
//     java.lang.Object var40 = var39.clone();
//     org.jfree.chart.util.RectangleInsets var41 = var39.getPadding();
//     org.jfree.chart.entity.EntityCollection var42 = null;
//     org.jfree.chart.ChartRenderingInfo var43 = new org.jfree.chart.ChartRenderingInfo(var42);
//     java.awt.geom.Rectangle2D var44 = var43.getChartArea();
//     java.awt.geom.Rectangle2D var45 = var41.createInsetRectangle(var44);
//     var5.drawDomainMarker(var24, var25, var27, var31, var44);
// 
//   }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test244"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var3.getSeriesKey((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test245"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.Layer var32 = null;
    java.util.Collection var33 = var13.getRangeMarkers(var32);
    org.jfree.chart.axis.ValueAxis var35 = var13.getRangeAxis((-1));
    org.jfree.data.category.CategoryDataset var37 = var13.getDataset(10);
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot(var39);
    org.jfree.chart.renderer.xy.XYAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var48 = var47.getRGB();
    var42.setSeriesFillPaint(0, (java.awt.Paint)var47, true);
    java.awt.Graphics2D var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.plot.XYPlot var53 = null;
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var56 = var42.initialise(var51, var52, var53, var54, var55);
    java.awt.Font var57 = var42.getBaseLegendTextFont();
    int var58 = var40.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var42);
    org.jfree.chart.renderer.xy.XYItemRenderer var60 = null;
    var40.setRenderer(1, var60);
    org.jfree.chart.ChartRenderingInfo var64 = null;
    org.jfree.chart.plot.PlotRenderingInfo var65 = new org.jfree.chart.plot.PlotRenderingInfo(var64);
    var40.handleClick(1, 1, var65);
    java.awt.geom.Point2D var67 = null;
    var13.panRangeAxes(10.0d, var65, var67);
    org.jfree.chart.plot.Marker var69 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var70 = var13.removeRangeMarker(var69);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1));

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test246"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    var13.setForegroundAlpha(1.0f);
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.util.RectangleEdge var26 = var24.getRangeAxisEdge((-1));
    var24.clearDomainMarkers(1);
    var13.removeChangeListener((org.jfree.chart.event.PlotChangeListener)var24);
    java.lang.String var30 = var24.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var30 + "' != '" + "Combined_Domain_XYPlot"+ "'", var30.equals("Combined_Domain_XYPlot"));

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test247"); }


    java.text.AttributedString var0 = null;
    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Paint var7 = null;
    var6.setBasePaint(var7);
    java.awt.Color var11 = java.awt.Color.getColor("#ffff5b", 10);
    var6.setBaseFillPaint((java.awt.Paint)var11, false);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var16 = var15.isAxisLineVisible();
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var15.setTickLabelPaint((java.awt.Paint)var20);
    java.awt.Stroke var22 = var15.getTickMarkStroke();
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var24.setFillPaint((java.awt.Paint)var28);
    java.awt.Shape var30 = var24.getShape();
    java.awt.Shape var31 = var24.getShape();
    var24.setURLText("Preceding");
    org.jfree.data.category.CategoryDataset var34 = null;
    org.jfree.chart.axis.CategoryAxis var36 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var37 = var36.isAxisLineVisible();
    java.awt.Color var41 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var36.setTickLabelPaint((java.awt.Paint)var41);
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var46 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var47 = new org.jfree.chart.plot.CategoryPlot(var34, var36, var43, (org.jfree.chart.renderer.category.CategoryItemRenderer)var46);
    org.jfree.chart.labels.CategoryItemLabelGenerator var48 = var46.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var50 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var51 = var50.getBaseItemLabelsVisible();
    java.awt.Shape var55 = var50.getItemShape(0, 1, false);
    var46.setBaseLegendShape(var55);
    double var57 = var46.getMaximumBarWidth();
    java.awt.Color var61 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var62 = var61.getRGB();
    var46.setWallPaint((java.awt.Paint)var61);
    var24.setLabelPaint((java.awt.Paint)var61);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem(var0, "", "", "Preceding", var4, (java.awt.Paint)var11, var22, (java.awt.Paint)var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == (-165));

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test248"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    boolean var9 = var2.getBaseSeriesVisible();
    double var10 = var2.getItemMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0.2d);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test249"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer((-1.0d));

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test250"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPositionFallback();
    java.awt.Paint var12 = var2.lookupSeriesFillPaint(100);
    var2.setItemMargin(1.0d);
    double var15 = var2.getYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1.0d));

  }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test251"); }


    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var2 = new org.jfree.chart.plot.CombinedDomainXYPlot(var1);
    org.jfree.chart.axis.AxisLocation var4 = var2.getDomainAxisLocation(1);
    java.awt.Paint var5 = var2.getDomainZeroBaselinePaint();
    java.awt.Font var6 = var2.getNoDataMessageFont();
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var14 = var13.getRGB();
    var8.setSeriesFillPaint(0, (java.awt.Paint)var13, true);
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.XYPlot var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var8.initialise(var17, var18, var19, var20, var21);
    java.awt.Font var23 = var8.getBaseLegendTextFont();
    java.awt.Paint var25 = var8.lookupSeriesFillPaint(100);
    org.jfree.chart.text.TextBlock var26 = org.jfree.chart.text.TextUtilities.createTextBlock("", var6, var25);
    java.awt.Graphics2D var27 = null;
    org.jfree.chart.util.Size2D var28 = var26.calculateDimensions(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test252"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
//     var1.clearDomainMarkers(1);
//     var1.setRangeCrosshairVisible(false);
//     java.awt.Stroke var8 = var1.getDomainCrosshairStroke();
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var14 = var13.isAxisLineVisible();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var13.setTickLabelPaint((java.awt.Paint)var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     java.awt.Image var25 = null;
//     var24.setBackgroundImage(var25);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var34 = var33.getRGB();
//     var28.setSeriesFillPaint(0, (java.awt.Paint)var33, true);
//     java.awt.Color var37 = var33.brighter();
//     var24.setRangeZeroBaselinePaint((java.awt.Paint)var37);
//     java.lang.Comparable var39 = null;
//     var24.setDomainCrosshairRowKey(var39, false);
//     org.jfree.chart.LegendItemCollection var42 = var24.getLegendItems();
//     org.jfree.chart.util.Layer var43 = null;
//     java.util.Collection var44 = var24.getRangeMarkers(var43);
//     org.jfree.chart.axis.ValueAxis var46 = var24.getRangeAxis((-1));
//     org.jfree.data.category.CategoryDataset var48 = var24.getDataset(10);
//     org.jfree.chart.axis.ValueAxis var50 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot(var50);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var58 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var59 = var58.getRGB();
//     var53.setSeriesFillPaint(0, (java.awt.Paint)var58, true);
//     java.awt.Graphics2D var62 = null;
//     java.awt.geom.Rectangle2D var63 = null;
//     org.jfree.chart.plot.XYPlot var64 = null;
//     org.jfree.data.xy.XYDataset var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var67 = var53.initialise(var62, var63, var64, var65, var66);
//     java.awt.Font var68 = var53.getBaseLegendTextFont();
//     int var69 = var51.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var53);
//     org.jfree.chart.renderer.xy.XYItemRenderer var71 = null;
//     var51.setRenderer(1, var71);
//     org.jfree.chart.ChartRenderingInfo var75 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var76 = new org.jfree.chart.plot.PlotRenderingInfo(var75);
//     var51.handleClick(1, 1, var76);
//     java.awt.geom.Point2D var78 = null;
//     var24.panRangeAxes(10.0d, var76, var78);
//     var1.handleClick((-165), (-1), var76);
//     
//     // Checks the contract:  equals-hashcode on var1 and var51
//     assertTrue("Contract failed: equals-hashcode on var1 and var51", var1.equals(var51) ? var1.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var1
//     assertTrue("Contract failed: equals-hashcode on var51 and var1", var51.equals(var1) ? var51.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test253"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var1.setRenderer(1, var21);
    java.awt.Stroke var23 = var1.getDomainZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test254"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    var1.setURLText("Preceding");
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var28 = var27.getBaseItemLabelsVisible();
    java.awt.Shape var32 = var27.getItemShape(0, 1, false);
    var23.setBaseLegendShape(var32);
    double var34 = var23.getMaximumBarWidth();
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var39 = var38.getRGB();
    var23.setWallPaint((java.awt.Paint)var38);
    var1.setLabelPaint((java.awt.Paint)var38);
    java.awt.Shape var42 = var1.getShape();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test255"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    org.jfree.data.xy.XYDataItem var4 = var1.addOrUpdate(10.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test256"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var7 = var5.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var12 = var10.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var10.getSeriesItemLabelGenerator(0);
    var10.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var10.getBasePositiveItemLabelPosition();
    var5.setPositiveItemLabelPositionFallback(var17);
    java.awt.Shape var20 = var5.lookupSeriesShape(10);
    java.awt.Shape var22 = var5.getSeriesShape((-165));
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var30 = var26.getToolTipGenerator((-1), (-165), false);
    var26.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var34 = var26.getLegendItemLabelGenerator();
    boolean var35 = var26.getUseFillPaint();
    org.jfree.chart.axis.CategoryAxis var38 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var38.configure();
    java.awt.Font var40 = var38.getTickLabelFont();
    var26.setSeriesItemLabelFont(1, var40);
    org.jfree.chart.labels.ItemLabelPosition var42 = var26.getBaseNegativeItemLabelPosition();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSeriesNegativeItemLabelPosition((-1), var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test257"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    java.awt.Paint var10 = var2.getWallPaint();
    org.jfree.data.category.CategoryDataset var13 = null;
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var16 = var15.isAxisLineVisible();
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var15.setTickLabelPaint((java.awt.Paint)var20);
    org.jfree.chart.axis.ValueAxis var22 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var13, var15, var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
    org.jfree.chart.plot.DrawingSupplier var27 = var26.getDrawingSupplier();
    org.jfree.chart.plot.Marker var29 = null;
    org.jfree.chart.util.Layer var30 = null;
    boolean var31 = var26.removeDomainMarker(100, var29, var30);
    var26.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var36 = var35.getBaseItemLabelsVisible();
    java.awt.Paint var40 = var35.getItemFillPaint((-1), (-1), true);
    var26.setRangeGridlinePaint(var40);
    org.jfree.chart.plot.IntervalMarker var42 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var40);
    var2.setWallPaint(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);

  }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test258"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLabelToolTip("Preceding");
    var1.setLabel("hi!");
    var1.setTickLabelsVisible(true);

  }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test259"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    var1.setShadowVisible(false);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test260"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("Preceding");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete((-165), (-126), false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test261"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    var1.add((java.lang.Number)0L, (java.lang.Number)(short)(-1));
    org.jfree.data.xy.XYDataItem var6 = var1.remove(0);
    int var8 = var1.indexOf((java.lang.Number)10L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test262"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     java.lang.Comparable var32 = var13.getDomainCrosshairColumnKey();
//     java.awt.Stroke var33 = var13.getOutlineStroke();
//     org.jfree.data.category.CategoryDataset var34 = null;
//     int var35 = var13.indexOf(var34);
//     org.jfree.chart.renderer.category.CategoryItemRenderer[] var36 = null;
//     var13.setRenderers(var36);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test263"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    java.awt.Stroke var7 = var2.getBaseOutlineStroke();
    org.jfree.chart.labels.CategoryToolTipGenerator var9 = null;
    var2.setSeriesToolTipGenerator(100, var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test264"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.chart.labels.ItemLabelPosition var8 = var7.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test265"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.axis.ValueAxis var2 = null;
//     org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var8 = var7.getBaseItemLabelsVisible();
//     java.awt.Shape var12 = var7.getItemShape(0, 1, false);
//     java.awt.Shape var13 = var7.getBaseShape();
//     var4.setLegendBar(var13);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var20 = var16.getToolTipGenerator((-1), (-165), false);
//     var16.setSeriesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var24 = var16.getLegendItemLabelGenerator();
//     org.jfree.chart.util.GradientPaintTransformer var25 = var16.getGradientTransformer();
//     var4.setGradientPaintTransformer(var25);
//     
//     // Checks the contract:  equals-hashcode on var7 and var16
//     assertTrue("Contract failed: equals-hashcode on var7 and var16", var7.equals(var16) ? var7.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var7
//     assertTrue("Contract failed: equals-hashcode on var16 and var7", var16.equals(var7) ? var16.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test266"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var14 = var13.getURLText();
    var13.setItem(100);
    java.lang.String var17 = var13.getToolTipText();
    java.lang.String var18 = var13.toString();
    int var19 = var13.getSeriesIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + "XYItemEntity: series = -1, item = 100, dataset = null"+ "'", var18.equals("XYItemEntity: series = -1, item = 100, dataset = null"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test267"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var16 = var15.isAxisLineVisible();
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var15.setTickLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var15.getTickLabelPaint();
    var13.setRangeZeroBaselinePaint(var22);
    var13.setDomainCrosshairColumnKey((java.lang.Comparable)1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test268"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Preceding");

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test269"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var17 = var16.getBaseItemLabelsVisible();
//     java.awt.Shape var21 = var16.getItemShape(0, 1, false);
//     var12.setBaseLegendShape(var21);
//     double var23 = var12.getMaximumBarWidth();
//     java.awt.Paint var25 = var12.lookupSeriesFillPaint(10);
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.plot.CategoryPlot var27 = null;
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     java.awt.geom.Rectangle2D var29 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var33 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var35 = var33.getSeriesItemLabelPaint(0);
//     org.jfree.chart.renderer.category.BarRenderer3D var38 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var40 = var38.getSeriesItemLabelPaint(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var42 = var38.getSeriesItemLabelGenerator(0);
//     var38.setShadowVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var45 = var38.getBasePositiveItemLabelPosition();
//     var33.setPositiveItemLabelPositionFallback(var45);
//     java.awt.Shape var48 = var33.lookupSeriesShape(10);
//     java.lang.Object var49 = null;
//     boolean var50 = var33.equals(var49);
//     java.awt.Color var58 = java.awt.Color.getColor("#ffff5b", 10);
//     org.jfree.chart.block.BlockBorder var59 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), (-1.0d), 0.0d, (java.awt.Paint)var58);
//     var33.setSeriesFillPaint(0, (java.awt.Paint)var58, true);
//     org.jfree.data.category.CategoryDataset var62 = null;
//     org.jfree.chart.axis.CategoryAxis var64 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var65 = var64.isAxisLineVisible();
//     java.awt.Color var69 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var64.setTickLabelPaint((java.awt.Paint)var69);
//     org.jfree.chart.axis.ValueAxis var71 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var74 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var75 = new org.jfree.chart.plot.CategoryPlot(var62, var64, var71, (org.jfree.chart.renderer.category.CategoryItemRenderer)var74);
//     var75.setForegroundAlpha(0.0f);
//     java.awt.Stroke var78 = var75.getDomainCrosshairStroke();
//     org.jfree.chart.axis.ValueAxis var79 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var80 = new org.jfree.chart.plot.CombinedDomainXYPlot(var79);
//     org.jfree.chart.util.RectangleEdge var82 = var80.getRangeAxisEdge((-1));
//     var80.clearDomainMarkers(1);
//     var80.setRangeCrosshairVisible(false);
//     java.awt.Stroke var87 = var80.getDomainCrosshairStroke();
//     var75.setRangeMinorGridlineStroke(var87);
//     var12.drawRangeLine(var26, var27, var28, var29, 1.0d, (java.awt.Paint)var58, var87);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test270"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    boolean var2 = var1.getLabelLinksVisible();
    org.jfree.chart.plot.PieLabelLinkStyle var3 = var1.getLabelLinkStyle();
    org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var9 = var5.getToolTipGenerator((-1), (-165), false);
    var5.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.entity.EntityCollection var14 = null;
    org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
    java.awt.geom.Rectangle2D var16 = var15.getChartArea();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
    org.jfree.chart.util.RectangleEdge var20 = var18.getRangeAxisEdge((-1));
    var18.clearDomainMarkers(1);
    var18.setRangeCrosshairVisible(false);
    int var25 = var18.getDatasetCount();
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var28 = null;
    org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var31 = var5.initialise(var13, var16, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.data.xy.XYDataset)var29, var30);
    boolean var32 = var3.equals((java.lang.Object)var18);
    boolean var33 = var18.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test271"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    java.lang.Object var15 = var4.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test272"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    org.jfree.chart.event.RendererChangeEvent var6 = null;
    var1.notifyListeners(var6);
    java.awt.Stroke var9 = null;
    var1.setSeriesOutlineStroke(1, var9);
    var1.removeAnnotations();
    org.jfree.chart.annotations.XYAnnotation var12 = null;
    boolean var13 = var1.removeAnnotation(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test273"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var11 = var10.isAxisLineVisible();
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var10.setTickLabelPaint((java.awt.Paint)var15);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var8, var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    org.jfree.chart.plot.Marker var24 = null;
    org.jfree.chart.util.Layer var25 = null;
    boolean var26 = var21.removeDomainMarker(100, var24, var25);
    var21.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var31 = var30.getBaseItemLabelsVisible();
    java.awt.Paint var35 = var30.getItemFillPaint((-1), (-1), true);
    var21.setRangeGridlinePaint(var35);
    org.jfree.chart.event.RendererChangeEvent var38 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    boolean var39 = var38.getSeriesVisibilityChanged();
    var21.rendererChanged(var38);
    boolean var41 = var4.equals((java.lang.Object)var21);
    java.text.NumberFormat var42 = var4.getXFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test274"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Paint var2 = null;
    var1.setBasePaint(var2);
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var7 = var6.isAxisLineVisible();
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var6.setTickLabelPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var4, var6, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var22 = var17.removeDomainMarker(100, var20, var21);
    var17.setDrawSharedDomainAxis(false);
    java.util.List var25 = var17.getAnnotations();
    boolean var26 = var1.hasListener((java.util.EventListener)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test275() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test275"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLabelToolTip("Preceding");
    var1.setLabel("hi!");
    double var6 = var1.getLabelAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);

  }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test276"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    var2.clearSelection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsUpperBound((org.jfree.data.xy.XYDataset)var2, 10, 0.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test277"); }
// 
// 
//     org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
//     var1.add((java.lang.Number)0L, (java.lang.Number)(short)(-1));
//     org.jfree.data.xy.XYDataItem var6 = var1.remove(0);
//     double var7 = var1.getMaxX();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == Double.NaN);
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test278"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Comparable var8 = var7.getSeriesKey();
    java.util.List var9 = var7.getBlocks();
    java.lang.String var10 = var7.getURLText();
    java.lang.String var11 = var7.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test279"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var2 = null;
    org.jfree.data.time.TimeSeriesCollection var3 = new org.jfree.data.time.TimeSeriesCollection(var1, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var7 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset)var3, (-126), 1.0d, 0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test280"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    java.lang.Comparable var32 = var13.getDomainCrosshairColumnKey();
    org.jfree.chart.renderer.xy.XYAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var40 = var39.getRGB();
    var34.setSeriesFillPaint(0, (java.awt.Paint)var39, true);
    java.awt.Paint[] var43 = new java.awt.Paint[] { var39};
    java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
    java.awt.Stroke var49 = null;
    java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
    java.awt.Stroke[] var51 = null;
    java.awt.Shape var52 = null;
    java.awt.Shape[] var53 = new java.awt.Shape[] { var52};
    org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier(var43, var48, var50, var51, var53);
    var13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var54);
    org.jfree.data.category.CategoryDataset var57 = null;
    org.jfree.chart.axis.CategoryAxis var59 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var60 = var59.isAxisLineVisible();
    java.awt.Color var64 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var59.setTickLabelPaint((java.awt.Paint)var64);
    org.jfree.chart.axis.ValueAxis var66 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var69 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var70 = new org.jfree.chart.plot.CategoryPlot(var57, var59, var66, (org.jfree.chart.renderer.category.CategoryItemRenderer)var69);
    java.awt.Image var71 = null;
    var70.setBackgroundImage(var71);
    org.jfree.chart.renderer.xy.XYAreaRenderer var74 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var79 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var80 = var79.getRGB();
    var74.setSeriesFillPaint(0, (java.awt.Paint)var79, true);
    java.awt.Color var83 = var79.brighter();
    var70.setRangeZeroBaselinePaint((java.awt.Paint)var83);
    org.jfree.chart.ChartRenderingInfo var87 = null;
    org.jfree.chart.plot.PlotRenderingInfo var88 = new org.jfree.chart.plot.PlotRenderingInfo(var87);
    java.awt.geom.Point2D var89 = null;
    var70.zoomDomainAxes(1.0d, 10.0d, var88, var89);
    java.awt.geom.Point2D var91 = null;
    var13.zoomRangeAxes((-1.0d), var88, var91);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var94 = var88.getSubplotInfo(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test281"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    java.lang.Boolean var16 = var14.getSeriesLinesVisible(0);
    boolean var17 = var14.getBaseLinesVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setSeriesShapesVisible((-1), (java.lang.Boolean)false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test282"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var1.setRenderer(1, var21);
    var1.setDomainMinorGridlinesVisible(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));

  }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test283"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test284"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.chart.labels.XYToolTipGenerator var22 = var1.getSeriesToolTipGenerator(0);
    boolean var23 = var1.getPlotArea();
    boolean var24 = var1.isOutline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test285"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.configure();
    java.awt.Font var3 = var1.getTickLabelFont();
    org.jfree.chart.event.RendererChangeEvent var5 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)var3, true);
    boolean var6 = var5.getSeriesVisibilityChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test286"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    var1.setBaseItemLabelsVisible(false);
    org.jfree.chart.labels.XYItemLabelGenerator var6 = null;
    var1.setSeriesItemLabelGenerator(10, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test287"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-1.0d), (java.lang.Number)0);
    java.lang.Object var3 = var2.clone();
    boolean var5 = var2.equals((java.lang.Object)(short)100);
    var2.setY((java.lang.Number)10.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test288"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.XYPlot var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.plot.Marker var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    var1.drawRangeMarker(var3, var4, var5, var6, var7);
    java.awt.Stroke var10 = var1.getSeriesOutlineStroke(10);
    org.jfree.chart.labels.XYItemLabelGenerator var12 = null;
    var1.setSeriesItemLabelGenerator(100, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test289"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.data.Range var5 = var1.getDataRange(var4);
    org.jfree.chart.util.Layer var7 = null;
    java.util.Collection var8 = var1.getDomainMarkers((-126), var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test290"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)0L);
    org.jfree.data.xy.XYSeries var4 = var1.createCopy(0, (-126));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test291"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    float[] var8 = new float[] { 100.0f};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var9 = var5.getRGBComponents(var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test292"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears((-126), var1);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test293"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    double var10 = var2.getYOffset();
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    java.awt.Image var25 = null;
    var24.setBackgroundImage(var25);
    org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var34 = var33.getRGB();
    var28.setSeriesFillPaint(0, (java.awt.Paint)var33, true);
    java.awt.Color var37 = var33.brighter();
    var24.setRangeZeroBaselinePaint((java.awt.Paint)var37);
    java.lang.Comparable var39 = null;
    var24.setDomainCrosshairRowKey(var39, false);
    org.jfree.chart.LegendItemCollection var42 = var24.getLegendItems();
    org.jfree.chart.util.Layer var43 = null;
    java.util.Collection var44 = var24.getRangeMarkers(var43);
    var2.addChangeListener((org.jfree.chart.event.RendererChangeListener)var24);
    org.jfree.chart.axis.AxisSpace var46 = var24.getFixedDomainAxisSpace();
    var24.clearDomainAxes();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var46);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test294"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.data.category.CategoryDataset var19 = null;
//     org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var22 = var21.isAxisLineVisible();
//     java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var21.setTickLabelPaint((java.awt.Paint)var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var19, var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
//     org.jfree.chart.plot.DrawingSupplier var33 = var32.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var35 = null;
//     org.jfree.chart.util.Layer var36 = null;
//     boolean var37 = var32.removeDomainMarker(100, var35, var36);
//     var32.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var42 = var41.getBaseItemLabelsVisible();
//     java.awt.Paint var46 = var41.getItemFillPaint((-1), (-1), true);
//     var32.setRangeGridlinePaint(var46);
//     org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var46);
//     org.jfree.chart.util.Layer var49 = null;
//     boolean var51 = var13.removeDomainMarker(100, (org.jfree.chart.plot.Marker)var48, var49, false);
//     
//     // Checks the contract:  equals-hashcode on var13 and var32
//     assertTrue("Contract failed: equals-hashcode on var13 and var32", var13.equals(var32) ? var13.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var13
//     assertTrue("Contract failed: equals-hashcode on var32 and var13", var32.equals(var13) ? var32.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test295"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    double var10 = var2.getYOffset();
    org.jfree.chart.labels.CategoryToolTipGenerator var14 = var2.getToolTipGenerator(10, 0, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test296"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    boolean var2 = var1.getLabelLinksVisible();
    org.jfree.chart.plot.PieLabelLinkStyle var3 = var1.getLabelLinkStyle();
    org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var9 = var5.getToolTipGenerator((-1), (-165), false);
    var5.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.entity.EntityCollection var14 = null;
    org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
    java.awt.geom.Rectangle2D var16 = var15.getChartArea();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
    org.jfree.chart.util.RectangleEdge var20 = var18.getRangeAxisEdge((-1));
    var18.clearDomainMarkers(1);
    var18.setRangeCrosshairVisible(false);
    int var25 = var18.getDatasetCount();
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var28 = null;
    org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var31 = var5.initialise(var13, var16, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.data.xy.XYDataset)var29, var30);
    boolean var32 = var3.equals((java.lang.Object)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.mapDatasetToRangeAxis((-126), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test297"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.setIgnoreZeroValues(true);
    org.jfree.data.xy.XYDataItem var14 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-1.0d), (java.lang.Number)0);
    double var15 = var1.getExplodePercent((java.lang.Comparable)(-1.0d));
    var1.clearSectionPaints(false);
    java.awt.Stroke var18 = var1.getLabelLinkStroke();
    var1.setShadowYOffset(0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test298"); }
// 
// 
//     org.jfree.chart.block.LabelBlock var2 = new org.jfree.chart.block.LabelBlock("#ffff5b");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var4 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var10 = var9.getRGB();
//     var4.setSeriesFillPaint(0, (java.awt.Paint)var9, true);
//     java.awt.Color var13 = var9.brighter();
//     var2.setPaint((java.awt.Paint)var13);
//     java.lang.String var15 = var2.getURLText();
//     double var16 = var2.getHeight();
//     java.awt.Font var17 = var2.getFont();
//     org.jfree.data.category.CategoryDataset var18 = null;
//     org.jfree.chart.axis.CategoryAxis var20 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var21 = var20.isAxisLineVisible();
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var20.setTickLabelPaint((java.awt.Paint)var25);
//     org.jfree.chart.axis.ValueAxis var27 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var30 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var31 = new org.jfree.chart.plot.CategoryPlot(var18, var20, var27, (org.jfree.chart.renderer.category.CategoryItemRenderer)var30);
//     java.awt.Image var32 = null;
//     var31.setBackgroundImage(var32);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var35 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var41 = var40.getRGB();
//     var35.setSeriesFillPaint(0, (java.awt.Paint)var40, true);
//     java.awt.Color var44 = var40.brighter();
//     var31.setRangeZeroBaselinePaint((java.awt.Paint)var44);
//     org.jfree.chart.block.LabelBlock var46 = new org.jfree.chart.block.LabelBlock("#ffff5b", var17, (java.awt.Paint)var44);
//     
//     // Checks the contract:  equals-hashcode on var2 and var46
//     assertTrue("Contract failed: equals-hashcode on var2 and var46", var2.equals(var46) ? var2.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var2
//     assertTrue("Contract failed: equals-hashcode on var46 and var2", var46.equals(var2) ? var46.hashCode() == var2.hashCode() : true);
// 
//   }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test299"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.setAutoPopulateSectionOutlinePaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));

  }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test300"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var1.setLowerMargin(10.0d);
    java.util.TimeZone var4 = var1.getTimeZone();
    java.awt.Font var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setLabelFont(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test301() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test301"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.event.RendererChangeEvent var28 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    var13.rendererChanged(var28);
    org.jfree.chart.renderer.category.BarRenderer3D var32 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var34 = var32.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var36 = var32.getSeriesItemLabelGenerator(0);
    var32.setShadowVisible(false);
    var32.setDrawBarOutline(false);
    org.jfree.chart.renderer.category.CategoryItemRenderer[] var41 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { var32};
    var13.setRenderers(var41);
    double var43 = var13.getAnchorValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.0d);

  }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test302"); }


    org.jfree.data.general.PieDataset var1 = null;
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D(var1);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var4 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var5 = var4.getNumberFormat();
    var2.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var4);
    java.awt.Paint var7 = var2.getBaseSectionOutlinePaint();
    org.jfree.chart.LegendItem var8 = new org.jfree.chart.LegendItem("Preceding", var7);
    var8.setSeriesIndex(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test303"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setShapeVisible(false);
    var1.setToolTipText("");
    int var6 = var1.getDatasetIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test304"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    org.jfree.chart.plot.DatasetRenderingOrder var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.setDatasetRenderingOrder(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test305"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("XYItemEntity: series = -1, item = 100, dataset = null", var1);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test306"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test307"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.chart.event.ChartChangeEvent var8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var6);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test308"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    float var3 = var1.getTickMarkInsideLength();
    org.jfree.chart.plot.Plot var4 = var1.getPlot();
    var1.setAxisLineVisible(false);
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var11 = var10.getRGB();
    java.lang.String var12 = org.jfree.chart.util.PaintUtilities.colorToString(var10);
    var1.setTickLabelPaint((java.awt.Paint)var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "#ffff5b"+ "'", var12.equals("#ffff5b"));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test309"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    org.jfree.chart.plot.XYCrosshairState var16 = var15.getCrosshairState();
    org.jfree.data.xy.XYDataset var17 = null;
    var15.endSeriesPass(var17, (-1), 10, 0, (-165), 0);
    org.jfree.data.xy.XYDatasetSelectionState var24 = null;
    var15.setSelectionState(var24);
    int var26 = var15.getFirstItemIndex();
    int var27 = var15.getLastItemIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);

  }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test310"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    org.jfree.data.category.CategoryDataset var8 = null;
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var11 = var10.isAxisLineVisible();
    java.awt.Color var15 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var10.setTickLabelPaint((java.awt.Paint)var15);
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot(var8, var10, var17, (org.jfree.chart.renderer.category.CategoryItemRenderer)var20);
    org.jfree.chart.plot.DrawingSupplier var22 = var21.getDrawingSupplier();
    org.jfree.chart.plot.Marker var24 = null;
    org.jfree.chart.util.Layer var25 = null;
    boolean var26 = var21.removeDomainMarker(100, var24, var25);
    var21.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var30 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var31 = var30.getBaseItemLabelsVisible();
    java.awt.Paint var35 = var30.getItemFillPaint((-1), (-1), true);
    var21.setRangeGridlinePaint(var35);
    org.jfree.chart.event.RendererChangeEvent var38 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    boolean var39 = var38.getSeriesVisibilityChanged();
    var21.rendererChanged(var38);
    boolean var41 = var4.equals((java.lang.Object)var21);
    org.jfree.chart.annotations.CategoryAnnotation var42 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.addAnnotation(var42, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test311"); }


    java.lang.Class var1 = null;
    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", var1);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test312"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.data.time.TimeSeries var21 = null;
    java.util.TimeZone var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
    var13.setDataset((org.jfree.data.xy.XYDataset)var23);
    java.lang.Number var25 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset)var23);
    java.lang.Number var26 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue((org.jfree.data.xy.XYDataset)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var26 + "' != '" + Double.NaN+ "'", var26.equals(Double.NaN));

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test313"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    java.awt.Image var29 = null;
    var13.setBackgroundImage(var29);
    org.jfree.chart.plot.CategoryMarker var32 = null;
    org.jfree.chart.util.Layer var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var13.addDomainMarker((-1), var32, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test314"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    java.awt.geom.Rectangle2D var2 = var1.getChartArea();
    java.lang.Object var3 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test315"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.data.time.TimeSeries var21 = null;
    java.util.TimeZone var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
    var13.setDataset((org.jfree.data.xy.XYDataset)var23);
    var13.setDomainGridlinesVisible(false);
    boolean var27 = var13.isRangeMinorGridlinesVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test316"); }


    org.jfree.chart.urls.StandardXYURLGenerator var1 = new org.jfree.chart.urls.StandardXYURLGenerator("#ffff5b");

  }

  public void test317() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test317"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    boolean var2 = var1.getShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test318"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    boolean var2 = var1.getLabelLinksVisible();
    org.jfree.chart.plot.PieLabelLinkStyle var3 = var1.getLabelLinkStyle();
    org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var9 = var5.getToolTipGenerator((-1), (-165), false);
    var5.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var13 = null;
    org.jfree.chart.entity.EntityCollection var14 = null;
    org.jfree.chart.ChartRenderingInfo var15 = new org.jfree.chart.ChartRenderingInfo(var14);
    java.awt.geom.Rectangle2D var16 = var15.getChartArea();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var18 = new org.jfree.chart.plot.CombinedDomainXYPlot(var17);
    org.jfree.chart.util.RectangleEdge var20 = var18.getRangeAxisEdge((-1));
    var18.clearDomainMarkers(1);
    var18.setRangeCrosshairVisible(false);
    int var25 = var18.getDatasetCount();
    org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var28 = null;
    org.jfree.data.time.TimeSeriesCollection var29 = new org.jfree.data.time.TimeSeriesCollection(var27, var28);
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var31 = var5.initialise(var13, var16, (org.jfree.chart.plot.XYPlot)var18, (org.jfree.data.xy.XYDataset)var29, var30);
    boolean var32 = var3.equals((java.lang.Object)var18);
    java.awt.Stroke var33 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.setRangeMinorGridlineStroke(var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test319"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.setIgnoreZeroValues(true);
    org.jfree.chart.util.Rotation var12 = var1.getDirection();
    boolean var13 = var1.getIgnoreNullValues();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test320"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    boolean var23 = var1.isSeriesVisible(10);
    org.jfree.chart.axis.CategoryAxis var25 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var26 = var25.isAxisLineVisible();
    int var27 = var25.getCategoryLabelPositionOffset();
    double var28 = var25.getCategoryMargin();
    var25.setTickMarkOutsideLength(10.0f);
    java.awt.Font var31 = var25.getLabelFont();
    var1.setBaseItemLabelFont(var31, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test321"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var14 = var13.getURLText();
    var13.setItem(100);
    java.lang.String var17 = var13.getToolTipText();
    org.jfree.chart.renderer.category.BarRenderer3D var20 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var22 = var20.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var24 = var20.getSeriesItemLabelGenerator(0);
    var20.setShadowVisible(false);
    var20.setDrawBarOutline(false);
    java.lang.Object var29 = null;
    boolean var30 = var20.equals(var29);
    var20.setItemMargin(0.0d);
    boolean var33 = var13.equals((java.lang.Object)0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test322"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot(var13);
    org.jfree.chart.util.RectangleEdge var16 = var14.getRangeAxisEdge((-1));
    var14.clearDomainMarkers(1);
    var14.setRangeCrosshairVisible(false);
    int var21 = var14.getDatasetCount();
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var27 = var1.initialise(var9, var12, (org.jfree.chart.plot.XYPlot)var14, (org.jfree.data.xy.XYDataset)var25, var26);
    java.awt.Color var34 = java.awt.Color.getColor("#ffff5b", 10);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), (-1.0d), 0.0d, (java.awt.Paint)var34);
    var14.setDomainTickBandPaint((java.awt.Paint)var34);
    int var37 = var14.getDatasetCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);

  }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test323"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    var1.setSeparatorsVisible(false);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test324"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = new org.jfree.data.Range(100.0d, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test325"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    org.jfree.chart.axis.AxisLocation var5 = null;
    var1.setRangeAxisLocation(100, var5, true);
    var1.clearAnnotations();
    org.jfree.chart.LegendItem var10 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var12 = new org.jfree.chart.plot.CombinedDomainXYPlot(var11);
    org.jfree.chart.axis.AxisLocation var14 = var12.getDomainAxisLocation(1);
    boolean var15 = var10.equals((java.lang.Object)var14);
    org.jfree.chart.axis.AxisLocation var16 = var14.getOpposite();
    var1.setDomainAxisLocation(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test326"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.chart.plot.XYPlot var14 = null;
    org.jfree.data.xy.XYDataset var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
    java.awt.Font var18 = var3.getBaseLegendTextFont();
    int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
    var1.setRenderer(1, var21);
    org.jfree.chart.ChartRenderingInfo var25 = null;
    org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
    var1.handleClick(1, 1, var26);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var29 = var26.getSubplotInfo((-126));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test327"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     org.jfree.chart.LegendItemCollection var32 = null;
//     var31.addAll(var32);
// 
//   }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test328"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot(var13);
    org.jfree.chart.util.RectangleEdge var16 = var14.getRangeAxisEdge((-1));
    var14.clearDomainMarkers(1);
    var14.setRangeCrosshairVisible(false);
    int var21 = var14.getDatasetCount();
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var27 = var1.initialise(var9, var12, (org.jfree.chart.plot.XYPlot)var14, (org.jfree.data.xy.XYDataset)var25, var26);
    org.jfree.data.xy.XYDataset var28 = null;
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var32 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var33 = new org.jfree.chart.plot.XYPlot(var28, var29, var30, (org.jfree.chart.renderer.xy.XYItemRenderer)var32);
    var32.setUseYInterval(false);
    org.jfree.chart.renderer.xy.XYBarPainter var36 = var32.getBarPainter();
    org.jfree.data.Range var37 = null;
    org.jfree.chart.block.RectangleConstraint var39 = new org.jfree.chart.block.RectangleConstraint(var37, 100.0d);
    org.jfree.chart.block.RectangleConstraint var41 = var39.toFixedWidth(10.0d);
    java.lang.String var42 = var39.toString();
    org.jfree.data.Range var43 = var39.getHeightRange();
    boolean var44 = var32.equals((java.lang.Object)var39);
    double var45 = var32.getBarAlignmentFactor();
    var14.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var42 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var42.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == (-1.0d));

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test329"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    boolean var23 = var1.isSeriesVisible(10);
    java.awt.Font var27 = var1.getItemLabelFont((-1), 0, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test330"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("Preceding");
    var1.setKey((java.lang.Comparable)(byte)1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.delete((-165), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test331"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var13.getRangeMarkers(var33);
    java.awt.Image var35 = null;
    var13.setBackgroundImage(var35);
    var13.setCrosshairDatasetIndex((-165));
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var43 = var41.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var45 = var41.getSeriesItemLabelGenerator(0);
    var41.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var48 = var41.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var49 = var41.getPositiveItemLabelPositionFallback();
    int var50 = var41.getColumnCount();
    org.jfree.data.category.CategoryDataset var51 = null;
    org.jfree.chart.axis.CategoryAxis var53 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var54 = var53.isAxisLineVisible();
    java.awt.Color var58 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var53.setTickLabelPaint((java.awt.Paint)var58);
    org.jfree.chart.axis.ValueAxis var60 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var63 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var64 = new org.jfree.chart.plot.CategoryPlot(var51, var53, var60, (org.jfree.chart.renderer.category.CategoryItemRenderer)var63);
    org.jfree.chart.plot.DrawingSupplier var65 = var64.getDrawingSupplier();
    org.jfree.chart.plot.Marker var67 = null;
    org.jfree.chart.util.Layer var68 = null;
    boolean var69 = var64.removeDomainMarker(100, var67, var68);
    org.jfree.chart.plot.Marker var71 = null;
    org.jfree.chart.util.Layer var72 = null;
    boolean var74 = var64.removeDomainMarker(100, var71, var72, false);
    var41.setPlot(var64);
    java.awt.Paint var76 = var64.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var77 = var64.getRowRenderingOrder();
    var13.setRowRenderingOrder(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test332"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var20 = var16.getToolTipGenerator((-1), (-165), false);
    var16.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var24 = var16.getLegendItemLabelGenerator();
    boolean var25 = var16.getUseFillPaint();
    org.jfree.chart.axis.CategoryAxis var28 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var28.configure();
    java.awt.Font var30 = var28.getTickLabelFont();
    var16.setSeriesItemLabelFont(1, var30);
    org.jfree.chart.labels.ItemLabelPosition var32 = var16.getBaseNegativeItemLabelPosition();
    var12.setBasePositiveItemLabelPosition(var32, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test333"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 10.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test334"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, (-126));
// 
//   }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test335"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("Preceding");
    var1.setDomainDescription("Preceding");
    org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var7.setDescription("hi!");
    java.util.List var10 = var7.getItems();
    java.util.Collection var11 = var1.getTimePeriodsUniqueToOtherSeries(var7);
    java.lang.Class var12 = var1.getTimePeriodClass();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test336() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test336"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDomainDescription("Preceding");
    var1.setDomainDescription("Preceding");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var7 = var1.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test337"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var1, var2);
    java.lang.String var4 = var3.getFormatString();
    java.text.DateFormat var5 = var3.getYDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + ""+ "'", var4.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test338"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    double var4 = var3.getMaximumExplodePercent();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot(var5);
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var14 = var13.getRGB();
    var8.setSeriesFillPaint(0, (java.awt.Paint)var13, true);
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.XYPlot var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var8.initialise(var17, var18, var19, var20, var21);
    java.awt.Font var23 = var8.getBaseLegendTextFont();
    int var24 = var6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var8);
    org.jfree.chart.axis.AxisSpace var25 = var6.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var27 = var6.getRangeAxisLocation((-165));
    java.awt.Stroke var28 = var6.getRangeGridlineStroke();
    var3.setLabelLinkStroke(var28);
    var1.setSeparatorStroke(var28);
    var1.setIgnoreZeroValues(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test339"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var7 = var6.getRGB();
//     var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var15 = var11.getToolTipGenerator((-1), (-165), false);
//     var11.setSeriesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var19 = var11.getLegendItemLabelGenerator();
//     org.jfree.chart.util.GradientPaintTransformer var20 = var11.getGradientTransformer();
//     var1.setGradientTransformer(var20);
//     
//     // Checks the contract:  equals-hashcode on var1 and var11
//     assertTrue("Contract failed: equals-hashcode on var1 and var11", var1.equals(var11) ? var1.hashCode() == var11.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var1
//     assertTrue("Contract failed: equals-hashcode on var11 and var1", var11.equals(var1) ? var11.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test340"); }


    org.jfree.chart.renderer.category.GradientBarPainter var3 = new org.jfree.chart.renderer.category.GradientBarPainter(100.0d, 0.0d, (-1.0d));
    org.jfree.chart.renderer.xy.XYAreaRenderer var5 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var10 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var11 = var10.getRGB();
    var5.setSeriesFillPaint(0, (java.awt.Paint)var10, true);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.XYPlot var16 = null;
    org.jfree.data.xy.XYDataset var17 = null;
    org.jfree.chart.plot.PlotRenderingInfo var18 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var19 = var5.initialise(var14, var15, var16, var17, var18);
    org.jfree.chart.plot.XYCrosshairState var20 = var19.getCrosshairState();
    org.jfree.data.xy.XYDataset var21 = null;
    var19.endSeriesPass(var21, (-1), 10, 0, (-165), 0);
    org.jfree.data.xy.XYDatasetSelectionState var28 = null;
    var19.setSelectionState(var28);
    boolean var30 = var3.equals((java.lang.Object)var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test341"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.setIgnoreZeroValues(true);
    org.jfree.data.xy.XYDataItem var14 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-1.0d), (java.lang.Number)0);
    double var15 = var1.getExplodePercent((java.lang.Comparable)(-1.0d));
    var1.setSectionOutlinesVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test342"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var11 = new org.jfree.chart.plot.CombinedDomainXYPlot(var10);
    var1.removeChangeListener((org.jfree.chart.event.RendererChangeListener)var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test343"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setSeriesIndex((-1));
    org.jfree.data.general.Dataset var4 = var1.getDataset();
    java.awt.Stroke var5 = var1.getLineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test344"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    boolean var2 = var1.isDrawBarOutline();
    var1.setDrawBarOutline(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation(1);
    int var10 = var7.getRangeAxisCount();
    var7.clearAnnotations();
    java.awt.Paint var12 = var7.getDomainZeroBaselinePaint();
    var1.setSeriesPaint(100, var12, true);
    org.jfree.chart.LegendItemCollection var15 = var1.getLegendItems();
    boolean var16 = var1.getUseYInterval();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test345"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    double var10 = var1.getMinimumArcAngleToDraw();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0E-5d);

  }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test346"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.data.xy.XYDataset var14 = var13.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test347() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test347"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    float var3 = var1.getBackgroundAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1.0f);

  }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test348"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    java.awt.Font var5 = null;
    org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 0.0d, 100.0d, 10.0d, (-1.0d), var5);
    java.awt.Graphics2D var7 = null;
    java.awt.geom.Rectangle2D var8 = null;
    org.jfree.chart.entity.EntityCollection var9 = null;
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo(var9);
    java.awt.geom.Rectangle2D var11 = var10.getChartArea();
    java.awt.geom.Rectangle2D var12 = var10.getChartArea();
    var6.draw(var7, var8, var12, 0.0d, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test349"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    java.lang.Boolean var16 = var14.getSeriesLinesVisible(0);
    boolean var17 = var14.getBaseLinesVisible();
    boolean var18 = var14.getUseOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test350"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    int var3 = var1.getCategoryLabelPositionOffset();
    java.awt.Font var4 = var1.getTickLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test351"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    int var14 = var13.getItem();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1));

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test352"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
//     java.lang.Object var8 = var7.clone();
//     org.jfree.chart.util.RectangleInsets var9 = var7.getPadding();
//     org.jfree.chart.entity.EntityCollection var10 = null;
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     java.awt.geom.Rectangle2D var13 = var9.createInsetRectangle(var12);
//     double var15 = var9.calculateBottomInset(0.0d);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var21 = var17.getToolTipGenerator((-1), (-165), false);
//     var17.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var25 = null;
//     org.jfree.chart.entity.EntityCollection var26 = null;
//     org.jfree.chart.ChartRenderingInfo var27 = new org.jfree.chart.ChartRenderingInfo(var26);
//     java.awt.geom.Rectangle2D var28 = var27.getChartArea();
//     org.jfree.chart.axis.ValueAxis var29 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var30 = new org.jfree.chart.plot.CombinedDomainXYPlot(var29);
//     org.jfree.chart.util.RectangleEdge var32 = var30.getRangeAxisEdge((-1));
//     var30.clearDomainMarkers(1);
//     var30.setRangeCrosshairVisible(false);
//     int var37 = var30.getDatasetCount();
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var40 = null;
//     org.jfree.data.time.TimeSeriesCollection var41 = new org.jfree.data.time.TimeSeriesCollection(var39, var40);
//     org.jfree.chart.plot.PlotRenderingInfo var42 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var43 = var17.initialise(var25, var28, (org.jfree.chart.plot.XYPlot)var30, (org.jfree.data.xy.XYDataset)var41, var42);
//     var9.trim(var28);
//     
//     // Checks the contract:  equals-hashcode on var11 and var27
//     assertTrue("Contract failed: equals-hashcode on var11 and var27", var11.equals(var27) ? var11.hashCode() == var27.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var27 and var11
//     assertTrue("Contract failed: equals-hashcode on var27 and var11", var27.equals(var11) ? var27.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test353"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Shape var10 = var1.getSeriesShape((-1));
    java.awt.Graphics2D var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
    org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
    java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
    org.jfree.chart.axis.ValueAxis var17 = null;
    org.jfree.chart.plot.Marker var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
    org.jfree.data.time.TimeSeries var21 = null;
    java.util.TimeZone var22 = null;
    org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
    var13.setDataset((org.jfree.data.xy.XYDataset)var23);
    java.awt.Image var25 = null;
    var13.setBackgroundImage(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test354"); }


    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var9 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot(var5, var6, var7, (org.jfree.chart.renderer.xy.XYItemRenderer)var9);
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var13 = var12.getBaseItemLabelsVisible();
    java.awt.Shape var17 = var12.getItemShape(0, 1, false);
    java.awt.Shape var18 = var12.getBaseShape();
    var9.setLegendBar(var18);
    java.awt.Paint var21 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var30 = var29.getRGB();
    var24.setSeriesFillPaint(0, (java.awt.Paint)var29, true);
    java.awt.Graphics2D var33 = null;
    java.awt.geom.Rectangle2D var34 = null;
    org.jfree.chart.plot.XYPlot var35 = null;
    org.jfree.data.xy.XYDataset var36 = null;
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var38 = var24.initialise(var33, var34, var35, var36, var37);
    java.awt.Font var39 = var24.getBaseLegendTextFont();
    java.awt.Paint var41 = var24.lookupSeriesFillPaint(100);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var44 = var43.isAxisLineVisible();
    java.awt.Color var48 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var43.setTickLabelPaint((java.awt.Paint)var48);
    java.awt.Stroke var50 = var43.getTickMarkStroke();
    org.jfree.data.general.PieDataset var52 = null;
    org.jfree.chart.plot.PiePlot3D var53 = new org.jfree.chart.plot.PiePlot3D(var52);
    double var54 = var53.getMaximumExplodePercent();
    org.jfree.chart.renderer.xy.XYAreaRenderer var56 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var60 = var56.getToolTipGenerator((-1), (-165), false);
    var56.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var64 = var56.getLegendItemLabelGenerator();
    org.jfree.chart.util.GradientPaintTransformer var65 = var56.getGradientTransformer();
    java.awt.Shape var67 = var56.lookupSeriesShape(0);
    var53.setLegendItemShape(var67);
    org.jfree.chart.entity.ChartEntity var69 = new org.jfree.chart.entity.ChartEntity(var67);
    org.jfree.chart.axis.CategoryAxis var71 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var71.configure();
    java.awt.Stroke var73 = var71.getTickMarkStroke();
    org.jfree.chart.LegendItem var75 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var75.setShapeVisible(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var79 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var84 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var85 = var84.getRGB();
    var79.setSeriesFillPaint(0, (java.awt.Paint)var84, true);
    java.awt.Color var88 = var84.brighter();
    java.awt.Color var89 = var88.darker();
    var75.setLabelPaint((java.awt.Paint)var88);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var91 = new org.jfree.chart.LegendItem("", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "org.jfree.chart.event.RendererChangeEvent[source=Preceding]", "#ffff5b", false, var18, true, var21, true, var41, var50, true, var67, var73, (java.awt.Paint)var88);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test355"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    java.awt.Font var5 = var1.lookupLegendTextFont(100);
    var1.setBaseItemLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test356() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test356"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var32 = var31.getRGB();
    var26.setSeriesFillPaint(0, (java.awt.Paint)var31, true);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.plot.XYPlot var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var40 = var26.initialise(var35, var36, var37, var38, var39);
    java.awt.Font var41 = var26.getBaseLegendTextFont();
    int var42 = var24.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var26);
    org.jfree.chart.axis.AxisSpace var43 = var24.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var45 = var24.getRangeAxisLocation((-165));
    java.lang.Object var46 = var24.clone();
    org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var48.setLowerMargin(10.0d);
    java.util.TimeZone var51 = var48.getTimeZone();
    org.jfree.chart.entity.EntityCollection var52 = null;
    org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
    java.awt.geom.Rectangle2D var54 = var53.getChartArea();
    var1.fillRangeGridBand(var22, (org.jfree.chart.plot.XYPlot)var24, (org.jfree.chart.axis.ValueAxis)var48, var54, 0.0d, 0.0d);
    org.jfree.chart.axis.Timeline var58 = null;
    var48.setTimeline(var58);
    var48.setInverted(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test357"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    java.lang.Object var9 = var1.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test358"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var1.setLowerMargin(10.0d);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var5.configure();
    java.awt.Font var7 = var5.getTickLabelFont();
    var1.setLabelFont(var7);
    var1.setAutoTickUnitSelection(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test359() {}
//   public void test359() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test359"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("XYItemEntity: series = -1, item = 100, dataset = null", "", var3);
// 
//   }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test360"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var4 = org.jfree.chart.util.RectangleEdge.opposite(var3);
    boolean var5 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test361"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDescription("hi!");
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var5.setLowerMargin(10.0d);
    java.util.TimeZone var8 = var5.getTimeZone();
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var1, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var9.getStartY(1, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test362"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setLabelToolTip("Preceding");
    var1.setLabel("hi!");
    float var6 = var1.getMinorTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0f);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test363"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    org.jfree.data.general.PieDataset var23 = null;
    org.jfree.chart.entity.PieSectionEntity var29 = new org.jfree.chart.entity.PieSectionEntity(var21, var23, 0, 100, (java.lang.Comparable)(-1.0d), "hi!", "Preceding");
    org.jfree.data.xy.XYDataItem var32 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-1.0d), (java.lang.Number)0);
    java.lang.Object var33 = var32.clone();
    boolean var35 = var32.equals((java.lang.Object)(short)100);
    var29.setSectionKey((java.lang.Comparable)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test364"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    java.awt.Font var5 = var1.lookupLegendTextFont(100);
    org.jfree.chart.renderer.category.BarRenderer3D var8 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var10 = var8.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = var8.getSeriesItemLabelGenerator(0);
    var8.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var15 = var8.getBasePositiveItemLabelPosition();
    java.awt.Paint var16 = var8.getWallPaint();
    var1.setBaseOutlinePaint(var16, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test365"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot(var31);
    org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(1);
    boolean var35 = var30.equals((java.lang.Object)var34);
    org.jfree.chart.axis.AxisLocation var36 = org.jfree.chart.axis.AxisLocation.getOpposite(var34);
    var13.setRangeAxisLocation(var34);
    org.jfree.chart.axis.CategoryAxis var38 = var13.getDomainAxis();
    float var39 = var38.getMinorTickMarkInsideLength();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0.0f);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test366"); }


    org.jfree.data.xy.XYDataItem var2 = new org.jfree.data.xy.XYDataItem(0.0d, 100.0d);
    var2.setSelected(false);
    var2.setSelected(true);

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test367"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     var1.setDomainDescription("Preceding");
//     double var4 = var1.getMinY();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == Double.NaN);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test368"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Paint[] var10 = new java.awt.Paint[] { var6};
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Stroke var16 = null;
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    java.awt.Stroke[] var18 = null;
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var15, var17, var18, var20);
    java.awt.Paint var22 = var21.getNextPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var30 = var29.getRGB();
    var24.setSeriesFillPaint(0, (java.awt.Paint)var29, true);
    boolean var33 = var21.equals((java.lang.Object)0);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, (org.jfree.chart.renderer.xy.XYItemRenderer)var38);
    boolean var40 = var21.equals((java.lang.Object)var39);
    org.jfree.data.general.DatasetChangeEvent var41 = null;
    var39.datasetChanged(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);

  }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test369"); }
// 
// 
//     java.text.DateFormat var2 = null;
//     java.text.DateFormat var3 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
//     org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
//     java.lang.Object var8 = var4.clone();
//     java.text.NumberFormat var9 = var4.getXFormat();
//     org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
//     org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
//     java.lang.Boolean var16 = var14.getSeriesLinesVisible(0);
//     boolean var17 = var14.getBaseLinesVisible();
//     java.awt.Graphics2D var18 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var20 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var25 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var26 = var25.getRGB();
//     var20.setSeriesFillPaint(0, (java.awt.Paint)var25, true);
//     java.awt.Graphics2D var29 = null;
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.plot.XYPlot var31 = null;
//     org.jfree.data.xy.XYDataset var32 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var33 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var34 = var20.initialise(var29, var30, var31, var32, var33);
//     org.jfree.chart.plot.XYCrosshairState var35 = var34.getCrosshairState();
//     org.jfree.data.xy.XYDataset var36 = null;
//     var34.endSeriesPass(var36, (-1), 10, 0, (-165), 0);
//     org.jfree.data.xy.XYDatasetSelectionState var43 = null;
//     var34.setSelectionState(var43);
//     int var45 = var34.getFirstItemIndex();
//     org.jfree.data.time.TimeSeries var46 = null;
//     java.util.TimeZone var47 = null;
//     org.jfree.data.time.TimeSeriesCollection var48 = new org.jfree.data.time.TimeSeriesCollection(var46, var47);
//     var48.clearSelection();
//     var34.endSeriesPass((org.jfree.data.xy.XYDataset)var48, 0, (-126), 10, (-1), 100);
//     org.jfree.chart.entity.EntityCollection var56 = null;
//     org.jfree.chart.ChartRenderingInfo var57 = new org.jfree.chart.ChartRenderingInfo(var56);
//     java.awt.geom.Rectangle2D var58 = var57.getChartArea();
//     java.awt.geom.Rectangle2D var59 = var57.getChartArea();
//     org.jfree.chart.axis.ValueAxis var60 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var61 = new org.jfree.chart.plot.CombinedDomainXYPlot(var60);
//     org.jfree.chart.axis.AxisLocation var63 = var61.getDomainAxisLocation(1);
//     int var64 = var61.getRangeAxisCount();
//     var61.setDomainCrosshairLockedOnData(true);
//     org.jfree.data.general.DatasetGroup var67 = var61.getDatasetGroup();
//     org.jfree.chart.axis.DateAxis var69 = new org.jfree.chart.axis.DateAxis("#ffff5b");
//     var69.setLowerMargin(10.0d);
//     org.jfree.chart.axis.NumberAxis3D var73 = new org.jfree.chart.axis.NumberAxis3D("Preceding");
//     org.jfree.data.time.TimeSeries var74 = null;
//     java.util.TimeZone var75 = null;
//     org.jfree.data.time.TimeSeriesCollection var76 = new org.jfree.data.time.TimeSeriesCollection(var74, var75);
//     var14.drawItem(var18, var34, var59, (org.jfree.chart.plot.XYPlot)var61, (org.jfree.chart.axis.ValueAxis)var69, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.data.xy.XYDataset)var76, 10, 10, false, 1);
// 
//   }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test370"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var4 = var3.getNumberFormat();
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    java.awt.Paint var6 = var1.getBaseSectionOutlinePaint();
    var1.setLabelGap(0.0d);
    java.awt.Paint var10 = var1.getSectionPaint((java.lang.Comparable)1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test371"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var22 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var23 = var22.getBaseItemLabelsVisible();
    java.awt.Paint var27 = var22.getItemFillPaint((-1), (-1), true);
    var13.setRangeGridlinePaint(var27);
    org.jfree.chart.LegendItem var30 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var31 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var32 = new org.jfree.chart.plot.CombinedDomainXYPlot(var31);
    org.jfree.chart.axis.AxisLocation var34 = var32.getDomainAxisLocation(1);
    boolean var35 = var30.equals((java.lang.Object)var34);
    org.jfree.chart.axis.AxisLocation var36 = org.jfree.chart.axis.AxisLocation.getOpposite(var34);
    var13.setRangeAxisLocation(var34);
    org.jfree.chart.axis.CategoryAxis var38 = var13.getDomainAxis();
    java.lang.Comparable var39 = var13.getDomainCrosshairRowKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test372"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    var1.clearDomainMarkers(1);
    var1.setRangeCrosshairVisible(false);
    java.awt.Stroke var8 = var1.getDomainCrosshairStroke();
    var1.clearSelection();
    org.jfree.chart.axis.ValueAxis var11 = var1.getDomainAxis(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test373"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.ItemLabelPosition var14 = var12.getBasePositiveItemLabelPosition();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test374"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.util.RectangleInsets var9 = var7.getPadding();
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    java.awt.geom.Rectangle2D var13 = var9.createInsetRectangle(var12);
    double var15 = var9.calculateBottomInset(0.0d);
    org.jfree.chart.event.ChartChangeEvent var16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test375"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.lang.String var2 = var1.getLabelFormat();
    java.text.AttributedString var4 = null;
    var1.setAttributedLabel(0, var4);
    java.lang.String var6 = var1.getLabelFormat();
    java.text.AttributedString var8 = null;
    var1.setAttributedLabel(10, var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + ""+ "'", var6.equals(""));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test376"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    org.jfree.chart.axis.CategoryAxis var10 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var11 = var10.isAxisLineVisible();
    int var12 = var10.getCategoryLabelPositionOffset();
    double var13 = var10.getCategoryMargin();
    var10.setLabelAngle(0.0d);
    org.jfree.chart.entity.AxisEntity var17 = new org.jfree.chart.entity.AxisEntity(var8, (org.jfree.chart.axis.Axis)var10, "#ffff5b");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.2d);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test377"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
//     org.jfree.chart.util.Layer var33 = null;
//     java.util.Collection var34 = var13.getRangeMarkers(var33);
//     java.awt.Graphics2D var35 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var37 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var41 = var37.getToolTipGenerator((-1), (-165), false);
//     var37.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var45 = null;
//     org.jfree.chart.entity.EntityCollection var46 = null;
//     org.jfree.chart.ChartRenderingInfo var47 = new org.jfree.chart.ChartRenderingInfo(var46);
//     java.awt.geom.Rectangle2D var48 = var47.getChartArea();
//     org.jfree.chart.axis.ValueAxis var49 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot(var49);
//     org.jfree.chart.util.RectangleEdge var52 = var50.getRangeAxisEdge((-1));
//     var50.clearDomainMarkers(1);
//     var50.setRangeCrosshairVisible(false);
//     int var57 = var50.getDatasetCount();
//     org.jfree.data.time.TimeSeries var59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var60 = null;
//     org.jfree.data.time.TimeSeriesCollection var61 = new org.jfree.data.time.TimeSeriesCollection(var59, var60);
//     org.jfree.chart.plot.PlotRenderingInfo var62 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var63 = var37.initialise(var45, var48, (org.jfree.chart.plot.XYPlot)var50, (org.jfree.data.xy.XYDataset)var61, var62);
//     var13.drawBackground(var35, var48);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test378"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPositionFallback();
    int var11 = var2.getColumnCount();
    java.awt.Font var12 = null;
    var2.setBaseItemLabelFont(var12, false);
    double var15 = var2.getMaximumBarWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test379"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    var2.setDrawBarOutline(false);
    java.lang.Object var11 = null;
    boolean var12 = var2.equals(var11);
    var2.setBaseSeriesVisibleInLegend(false);
    double var15 = var2.getMinimumBarLength();
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Graphics2D var26 = null;
    java.awt.geom.Rectangle2D var27 = null;
    org.jfree.chart.plot.XYPlot var28 = null;
    org.jfree.data.xy.XYDataset var29 = null;
    org.jfree.chart.plot.PlotRenderingInfo var30 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var31 = var17.initialise(var26, var27, var28, var29, var30);
    java.awt.Font var32 = var17.getBaseLegendTextFont();
    java.awt.Paint var34 = var17.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var37 = var17.getLegendItem((-165), (-126));
    java.awt.Graphics2D var38 = null;
    org.jfree.chart.axis.ValueAxis var39 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot(var39);
    org.jfree.chart.renderer.xy.XYAreaRenderer var42 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var48 = var47.getRGB();
    var42.setSeriesFillPaint(0, (java.awt.Paint)var47, true);
    java.awt.Graphics2D var51 = null;
    java.awt.geom.Rectangle2D var52 = null;
    org.jfree.chart.plot.XYPlot var53 = null;
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.plot.PlotRenderingInfo var55 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var56 = var42.initialise(var51, var52, var53, var54, var55);
    java.awt.Font var57 = var42.getBaseLegendTextFont();
    int var58 = var40.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var42);
    org.jfree.chart.axis.AxisSpace var59 = var40.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var61 = var40.getRangeAxisLocation((-165));
    java.lang.Object var62 = var40.clone();
    org.jfree.chart.axis.DateAxis var64 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var64.setLowerMargin(10.0d);
    java.util.TimeZone var67 = var64.getTimeZone();
    org.jfree.chart.entity.EntityCollection var68 = null;
    org.jfree.chart.ChartRenderingInfo var69 = new org.jfree.chart.ChartRenderingInfo(var68);
    java.awt.geom.Rectangle2D var70 = var69.getChartArea();
    var17.fillRangeGridBand(var38, (org.jfree.chart.plot.XYPlot)var40, (org.jfree.chart.axis.ValueAxis)var64, var70, 0.0d, 0.0d);
    boolean var74 = var2.hasListener((java.util.EventListener)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);

  }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test380"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    var1.setBase(10.0d);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test381"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test382() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test382"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
    org.jfree.chart.util.Layer var33 = null;
    java.util.Collection var34 = var13.getRangeMarkers(var33);
    java.awt.Image var35 = null;
    var13.setBackgroundImage(var35);
    var13.setCrosshairDatasetIndex((-165));
    org.jfree.data.general.PieDataset var39 = null;
    org.jfree.chart.plot.PiePlot3D var40 = new org.jfree.chart.plot.PiePlot3D(var39);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var42 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var43 = var42.getNumberFormat();
    var40.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var42);
    java.awt.Paint var45 = var40.getBaseSectionOutlinePaint();
    var13.setRangeZeroBaselinePaint(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test383"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test384"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    var1.setSectionOutlinesVisible(true);
    boolean var5 = var1.getLabelLinksVisible();
    var1.setExplodePercent((java.lang.Comparable)'a', 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test385"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getMaximumExplodePercent();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot(var3);
    org.jfree.chart.renderer.xy.XYAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var12 = var11.getRGB();
    var6.setSeriesFillPaint(0, (java.awt.Paint)var11, true);
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.plot.XYPlot var17 = null;
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var20 = var6.initialise(var15, var16, var17, var18, var19);
    java.awt.Font var21 = var6.getBaseLegendTextFont();
    int var22 = var4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var6);
    org.jfree.chart.axis.AxisSpace var23 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var4.getRangeAxisLocation((-165));
    java.awt.Stroke var26 = var4.getRangeGridlineStroke();
    var1.setLabelLinkStroke(var26);
    org.jfree.data.general.PieDataset var28 = null;
    org.jfree.chart.plot.PiePlot3D var29 = new org.jfree.chart.plot.PiePlot3D(var28);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var32 = var31.getNumberFormat();
    var29.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var31);
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test386"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var4 = var3.getNumberFormat();
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    java.awt.Paint var6 = var1.getBaseSectionOutlinePaint();
    java.awt.Paint var7 = var1.getBaseSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test387"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    var1.setSeriesIndex((-1));
    org.jfree.data.general.Dataset var4 = var1.getDataset();
    var1.setToolTipText("");
    var1.setURLText("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test388"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    org.jfree.chart.LegendItem var24 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var28 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var24.setFillPaint((java.awt.Paint)var28);
    var12.setShadowPaint((java.awt.Paint)var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test389"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.axis.ValueAxis var4 = null;
    org.jfree.data.Range var5 = var1.getDataRange(var4);
    org.jfree.chart.axis.ValueAxis var7 = var1.getRangeAxis(1);
    java.text.DateFormat var10 = null;
    java.text.DateFormat var11 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var12 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var10, var11);
    org.jfree.chart.urls.StandardXYURLGenerator var14 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var12, (org.jfree.chart.urls.XYURLGenerator)var14);
    org.jfree.data.category.CategoryDataset var16 = null;
    org.jfree.chart.axis.CategoryAxis var18 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var19 = var18.isAxisLineVisible();
    java.awt.Color var23 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var18.setTickLabelPaint((java.awt.Paint)var23);
    org.jfree.chart.axis.ValueAxis var25 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var28 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var29 = new org.jfree.chart.plot.CategoryPlot(var16, var18, var25, (org.jfree.chart.renderer.category.CategoryItemRenderer)var28);
    org.jfree.chart.plot.DrawingSupplier var30 = var29.getDrawingSupplier();
    org.jfree.chart.plot.Marker var32 = null;
    org.jfree.chart.util.Layer var33 = null;
    boolean var34 = var29.removeDomainMarker(100, var32, var33);
    var29.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var38 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var39 = var38.getBaseItemLabelsVisible();
    java.awt.Paint var43 = var38.getItemFillPaint((-1), (-1), true);
    var29.setRangeGridlinePaint(var43);
    org.jfree.chart.event.RendererChangeEvent var46 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    boolean var47 = var46.getSeriesVisibilityChanged();
    var29.rendererChanged(var46);
    boolean var49 = var12.equals((java.lang.Object)var29);
    org.jfree.chart.axis.ValueAxis var50 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var51 = new org.jfree.chart.plot.CombinedDomainXYPlot(var50);
    java.lang.String var52 = var51.getNoDataMessage();
    org.jfree.chart.axis.CategoryAxis var54 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var54.configure();
    java.awt.Stroke var56 = var54.getTickMarkStroke();
    var51.setRangeGridlineStroke(var56);
    var29.setRangeZeroBaselineStroke(var56);
    var1.setDomainMinorGridlineStroke(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test390"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    var13.clearDomainAxes();
    org.jfree.chart.axis.ValueAxis var20 = var13.getRangeAxis(0);
    org.jfree.chart.plot.PlotOrientation var21 = var13.getOrientation();
    java.lang.String var22 = var13.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "Category Plot"+ "'", var22.equals("Category Plot"));

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test391"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    org.jfree.chart.event.AxisChangeEvent var2 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis)var1);
    double var3 = var1.getCategoryMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test392"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var5 = var4.isAxisLineVisible();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var4.setTickLabelPaint((java.awt.Paint)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var2, var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var18 = var17.isAxisLineVisible();
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var17.setTickLabelPaint((java.awt.Paint)var22);
    java.awt.Paint var24 = var17.getTickLabelPaint();
    var15.setRangeZeroBaselinePaint(var24);
    var1.setLabelBackgroundPaint(var24);
    var1.setLabelLinkMargin(10.0d);
    java.awt.Graphics2D var29 = null;
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var32 = var31.isAxisLineVisible();
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var31.setTickLabelPaint((java.awt.Paint)var36);
    java.awt.Paint var38 = var31.getTickLabelPaint();
    java.lang.String var39 = var31.getLabel();
    org.jfree.chart.plot.Plot var40 = var31.getPlot();
    var31.setMaximumCategoryLabelWidthRatio((-1.0f));
    java.awt.Graphics2D var43 = null;
    org.jfree.chart.util.HorizontalAlignment var45 = null;
    org.jfree.chart.util.VerticalAlignment var46 = null;
    org.jfree.chart.block.FlowArrangement var49 = new org.jfree.chart.block.FlowArrangement(var45, var46, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var50 = null;
    org.jfree.chart.title.LegendItemBlockContainer var52 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var49, var50, (java.lang.Comparable)(short)100);
    java.lang.Object var53 = var52.clone();
    org.jfree.chart.util.RectangleInsets var54 = var52.getPadding();
    org.jfree.chart.entity.EntityCollection var55 = null;
    org.jfree.chart.ChartRenderingInfo var56 = new org.jfree.chart.ChartRenderingInfo(var55);
    java.awt.geom.Rectangle2D var57 = var56.getChartArea();
    java.awt.geom.Rectangle2D var58 = var54.createInsetRectangle(var57);
    org.jfree.data.category.CategoryDataset var59 = null;
    org.jfree.chart.axis.CategoryAxis var61 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var62 = var61.isAxisLineVisible();
    java.awt.Color var66 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var61.setTickLabelPaint((java.awt.Paint)var66);
    org.jfree.chart.axis.ValueAxis var68 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var71 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var72 = new org.jfree.chart.plot.CategoryPlot(var59, var61, var68, (org.jfree.chart.renderer.category.CategoryItemRenderer)var71);
    java.awt.Image var73 = null;
    var72.setBackgroundImage(var73);
    org.jfree.chart.renderer.xy.XYAreaRenderer var76 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var81 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var82 = var81.getRGB();
    var76.setSeriesFillPaint(0, (java.awt.Paint)var81, true);
    java.awt.Color var85 = var81.brighter();
    var72.setRangeZeroBaselinePaint((java.awt.Paint)var85);
    java.lang.Comparable var87 = null;
    var72.setDomainCrosshairRowKey(var87, false);
    org.jfree.chart.LegendItemCollection var90 = var72.getLegendItems();
    org.jfree.chart.util.RectangleEdge var91 = var72.getRangeAxisEdge();
    org.jfree.chart.axis.AxisState var92 = null;
    var31.drawTickMarks(var43, 10.0d, var58, var91, var92);
    var1.drawBackgroundImage(var29, var58);
    var1.setShadowYOffset(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "hi!"+ "'", var39.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test393"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Shape var3 = var1.getLegendShape((-165));
    org.jfree.data.category.CategoryDataset var4 = null;
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var7 = var6.isAxisLineVisible();
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var6.setTickLabelPaint((java.awt.Paint)var11);
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var16 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var17 = new org.jfree.chart.plot.CategoryPlot(var4, var6, var13, (org.jfree.chart.renderer.category.CategoryItemRenderer)var16);
    org.jfree.chart.plot.DrawingSupplier var18 = var17.getDrawingSupplier();
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var22 = var17.removeDomainMarker(100, var20, var21);
    var17.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var27 = var26.getBaseItemLabelsVisible();
    java.awt.Paint var31 = var26.getItemFillPaint((-1), (-1), true);
    var17.setRangeGridlinePaint(var31);
    org.jfree.chart.event.RendererChangeEvent var34 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object)"Preceding");
    boolean var35 = var34.getSeriesVisibilityChanged();
    var17.rendererChanged(var34);
    var1.notifyListeners(var34);
    boolean var38 = var1.getBaseCreateEntities();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test394"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    org.jfree.chart.axis.AxisLocation var17 = null;
    var13.setRangeAxisLocation(1, var17, false);
    org.jfree.data.category.CategoryDataset var20 = null;
    int var21 = var13.indexOf(var20);
    boolean var22 = var13.getDrawSharedDomainAxis();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test395"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var16 = var15.isAxisLineVisible();
    java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var15.setTickLabelPaint((java.awt.Paint)var20);
    java.awt.Paint var22 = var15.getTickLabelPaint();
    var13.setRangeZeroBaselinePaint(var22);
    org.jfree.chart.event.MarkerChangeEvent var24 = null;
    var13.markerChanged(var24);
    org.jfree.data.category.CategoryDataset var29 = null;
    org.jfree.chart.axis.CategoryAxis var31 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var32 = var31.isAxisLineVisible();
    java.awt.Color var36 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var31.setTickLabelPaint((java.awt.Paint)var36);
    org.jfree.chart.axis.ValueAxis var38 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var41 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var42 = new org.jfree.chart.plot.CategoryPlot(var29, var31, var38, (org.jfree.chart.renderer.category.CategoryItemRenderer)var41);
    org.jfree.chart.plot.DrawingSupplier var43 = var42.getDrawingSupplier();
    org.jfree.chart.plot.Marker var45 = null;
    org.jfree.chart.util.Layer var46 = null;
    boolean var47 = var42.removeDomainMarker(100, var45, var46);
    var42.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var51 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var52 = var51.getBaseItemLabelsVisible();
    java.awt.Paint var56 = var51.getItemFillPaint((-1), (-1), true);
    var42.setRangeGridlinePaint(var56);
    org.jfree.chart.plot.IntervalMarker var58 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var56);
    org.jfree.chart.event.MarkerChangeEvent var59 = null;
    var58.notifyListeners(var59);
    org.jfree.chart.util.Layer var61 = null;
    boolean var62 = var13.removeDomainMarker(100, (org.jfree.chart.plot.Marker)var58, var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test396"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.chart.labels.StandardPieSectionLabelGenerator var3 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var4 = var3.getNumberFormat();
    var1.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator)var3);
    org.jfree.chart.labels.PieSectionLabelGenerator var6 = var1.getLegendLabelToolTipGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test397"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var1.setLowerMargin(10.0d);
    org.jfree.chart.axis.CategoryAxis var5 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var5.configure();
    java.awt.Font var7 = var5.getTickLabelFont();
    var1.setLabelFont(var7);
    org.jfree.data.Range var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRange(var9, true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test398"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    org.jfree.chart.axis.CategoryAnchor var3 = null;
    java.awt.geom.Rectangle2D var6 = null;
    org.jfree.chart.axis.ValueAxis var7 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var8 = new org.jfree.chart.plot.CombinedDomainXYPlot(var7);
    org.jfree.chart.util.RectangleEdge var10 = var8.getRangeAxisEdge((-1));
    org.jfree.chart.util.RectangleEdge var11 = org.jfree.chart.util.RectangleEdge.opposite(var10);
    double var12 = var1.getCategoryJava2DCoordinate(var3, (-165), (-165), var6, var10);
    java.awt.Font var14 = var1.getTickLabelFont((java.lang.Comparable)1L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test399"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var2 = var1.getBaseItemLabelsVisible();
//     java.awt.Shape var6 = var1.getItemShape(0, 1, false);
//     java.awt.Shape var7 = var1.getBaseShape();
//     java.awt.Graphics2D var8 = null;
//     org.jfree.chart.renderer.xy.XYAreaRenderer var10 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var14 = var10.getToolTipGenerator((-1), (-165), false);
//     var10.setSeriesVisible(0, (java.lang.Boolean)false);
//     org.jfree.chart.labels.XYSeriesLabelGenerator var18 = var10.getLegendItemLabelGenerator();
//     org.jfree.chart.util.GradientPaintTransformer var19 = var10.getGradientTransformer();
//     java.awt.Shape var21 = var10.lookupSeriesShape(0);
//     org.jfree.chart.util.HorizontalAlignment var23 = null;
//     org.jfree.chart.util.VerticalAlignment var24 = null;
//     org.jfree.chart.block.FlowArrangement var27 = new org.jfree.chart.block.FlowArrangement(var23, var24, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var28 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var30 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var27, var28, (java.lang.Comparable)(short)100);
//     java.lang.Object var31 = var30.clone();
//     org.jfree.chart.util.RectangleInsets var32 = var30.getPadding();
//     org.jfree.chart.entity.EntityCollection var33 = null;
//     org.jfree.chart.ChartRenderingInfo var34 = new org.jfree.chart.ChartRenderingInfo(var33);
//     java.awt.geom.Rectangle2D var35 = var34.getChartArea();
//     java.awt.geom.Rectangle2D var36 = var32.createInsetRectangle(var35);
//     var10.setLegendShape(0, (java.awt.Shape)var36);
//     org.jfree.chart.entity.LegendItemEntity var38 = new org.jfree.chart.entity.LegendItemEntity((java.awt.Shape)var36);
//     org.jfree.chart.axis.ValueAxis var39 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var40 = new org.jfree.chart.plot.CombinedDomainXYPlot(var39);
//     org.jfree.chart.util.RectangleEdge var42 = var40.getRangeAxisEdge((-1));
//     var40.clearDomainMarkers(1);
//     var40.setRangeCrosshairVisible(false);
//     int var47 = var40.getDatasetCount();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var49 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var53 = var49.getToolTipGenerator((-1), (-165), false);
//     var49.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Graphics2D var57 = null;
//     org.jfree.chart.entity.EntityCollection var58 = null;
//     org.jfree.chart.ChartRenderingInfo var59 = new org.jfree.chart.ChartRenderingInfo(var58);
//     java.awt.geom.Rectangle2D var60 = var59.getChartArea();
//     org.jfree.chart.axis.ValueAxis var61 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var62 = new org.jfree.chart.plot.CombinedDomainXYPlot(var61);
//     org.jfree.chart.util.RectangleEdge var64 = var62.getRangeAxisEdge((-1));
//     var62.clearDomainMarkers(1);
//     var62.setRangeCrosshairVisible(false);
//     int var69 = var62.getDatasetCount();
//     org.jfree.data.time.TimeSeries var71 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var72 = null;
//     org.jfree.data.time.TimeSeriesCollection var73 = new org.jfree.data.time.TimeSeriesCollection(var71, var72);
//     org.jfree.chart.plot.PlotRenderingInfo var74 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var75 = var49.initialise(var57, var60, (org.jfree.chart.plot.XYPlot)var62, (org.jfree.data.xy.XYDataset)var73, var74);
//     org.jfree.chart.entity.EntityCollection var76 = null;
//     org.jfree.chart.ChartRenderingInfo var77 = new org.jfree.chart.ChartRenderingInfo(var76);
//     org.jfree.chart.plot.PlotRenderingInfo var78 = new org.jfree.chart.plot.PlotRenderingInfo(var77);
//     org.jfree.chart.renderer.xy.XYItemRendererState var79 = var1.initialise(var8, var36, (org.jfree.chart.plot.XYPlot)var40, (org.jfree.data.xy.XYDataset)var73, var78);
//     
//     // Checks the contract:  equals-hashcode on var1 and var10
//     assertTrue("Contract failed: equals-hashcode on var1 and var10", var1.equals(var10) ? var1.hashCode() == var10.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var49
//     assertTrue("Contract failed: equals-hashcode on var1 and var49", var1.equals(var49) ? var1.hashCode() == var49.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var10 and var1
//     assertTrue("Contract failed: equals-hashcode on var10 and var1", var10.equals(var1) ? var10.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var49 and var1
//     assertTrue("Contract failed: equals-hashcode on var49 and var1", var49.equals(var1) ? var49.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var59
//     assertTrue("Contract failed: equals-hashcode on var34 and var59", var34.equals(var59) ? var34.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var77
//     assertTrue("Contract failed: equals-hashcode on var34 and var77", var34.equals(var77) ? var34.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var34
//     assertTrue("Contract failed: equals-hashcode on var59 and var34", var59.equals(var34) ? var59.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var77
//     assertTrue("Contract failed: equals-hashcode on var59 and var77", var59.equals(var77) ? var59.hashCode() == var77.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var34
//     assertTrue("Contract failed: equals-hashcode on var77 and var34", var77.equals(var34) ? var77.hashCode() == var34.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var77 and var59
//     assertTrue("Contract failed: equals-hashcode on var77 and var59", var77.equals(var59) ? var77.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var62
//     assertTrue("Contract failed: equals-hashcode on var40 and var62", var40.equals(var62) ? var40.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var40
//     assertTrue("Contract failed: equals-hashcode on var62 and var40", var62.equals(var40) ? var62.hashCode() == var40.hashCode() : true);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test400"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    org.jfree.chart.renderer.category.BarRenderer3D var4 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var6 = var4.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var9 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var11 = var9.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = var9.getSeriesItemLabelGenerator(0);
    var9.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var16 = var9.getBasePositiveItemLabelPosition();
    var4.setPositiveItemLabelPositionFallback(var16);
    java.awt.Shape var19 = var4.lookupSeriesShape(10);
    org.jfree.chart.entity.ChartEntity var22 = new org.jfree.chart.entity.ChartEntity(var19, "", "");
    boolean var23 = var1.equals((java.lang.Object)var22);
    double var24 = var1.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1.0d);

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test401"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var9 = var8.getRGB();
    var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
    java.awt.Color var12 = var8.brighter();
    var1.setPaint((java.awt.Paint)var12);
    java.awt.Paint var14 = var1.getPaint();
    java.awt.Font var15 = var1.getFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test402() {}
//   public void test402() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test402"); }
// 
// 
//     org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var1.setFillPaint((java.awt.Paint)var5);
//     java.awt.Shape var7 = var1.getShape();
//     org.jfree.data.xy.XYDataset var8 = null;
//     org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     java.lang.String var14 = var13.getURLText();
//     org.jfree.chart.axis.ValueAxis var15 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var16 = new org.jfree.chart.plot.CombinedDomainXYPlot(var15);
//     org.jfree.chart.util.RectangleEdge var18 = var16.getRangeAxisEdge((-1));
//     org.jfree.data.time.TimeSeries var20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var21 = null;
//     org.jfree.data.time.TimeSeriesCollection var22 = new org.jfree.data.time.TimeSeriesCollection(var20, var21);
//     int var23 = var16.indexOf((org.jfree.data.xy.XYDataset)var22);
//     double var25 = var22.getDomainUpperBound(false);
//     var13.setDataset((org.jfree.data.xy.XYDataset)var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == Double.NaN);
// 
//   }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test403"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot(var13);
    org.jfree.chart.util.RectangleEdge var16 = var14.getRangeAxisEdge((-1));
    var14.clearDomainMarkers(1);
    var14.setRangeCrosshairVisible(false);
    int var21 = var14.getDatasetCount();
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var27 = var1.initialise(var9, var12, (org.jfree.chart.plot.XYPlot)var14, (org.jfree.data.xy.XYDataset)var25, var26);
    org.jfree.chart.renderer.xy.XYItemRenderer var29 = var14.getRenderer(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test404"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    org.jfree.chart.labels.ItemLabelPosition var10 = var2.getPositiveItemLabelPositionFallback();
    int var11 = var2.getColumnCount();
    org.jfree.data.category.CategoryDataset var12 = null;
    org.jfree.chart.axis.CategoryAxis var14 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var15 = var14.isAxisLineVisible();
    java.awt.Color var19 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var14.setTickLabelPaint((java.awt.Paint)var19);
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var24 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var25 = new org.jfree.chart.plot.CategoryPlot(var12, var14, var21, (org.jfree.chart.renderer.category.CategoryItemRenderer)var24);
    org.jfree.chart.plot.DrawingSupplier var26 = var25.getDrawingSupplier();
    org.jfree.chart.plot.Marker var28 = null;
    org.jfree.chart.util.Layer var29 = null;
    boolean var30 = var25.removeDomainMarker(100, var28, var29);
    org.jfree.chart.plot.Marker var32 = null;
    org.jfree.chart.util.Layer var33 = null;
    boolean var35 = var25.removeDomainMarker(100, var32, var33, false);
    var2.setPlot(var25);
    java.awt.Paint var37 = var25.getRangeCrosshairPaint();
    org.jfree.chart.util.SortOrder var38 = var25.getRowRenderingOrder();
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var41 = var40.isAxisLineVisible();
    int var42 = var40.getCategoryLabelPositionOffset();
    double var43 = var40.getCategoryMargin();
    var40.setTickMarkOutsideLength(10.0f);
    org.jfree.chart.axis.CategoryLabelPositions var46 = var40.getCategoryLabelPositions();
    var25.setDomainAxis(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test405"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    double var8 = var4.getMargin();
    java.awt.Paint var12 = var4.getItemFillPaint(0, (-126), false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test406"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
    double var10 = var2.getYOffset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesCreateEntities((-1), (java.lang.Boolean)true, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1.0d));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test407"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.setDrawSharedDomainAxis(false);
    int var21 = var13.getRangeAxisCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test408"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isDomainPannable();
    boolean var6 = var1.isDomainZeroBaselineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test409"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var9 = null;
    org.jfree.chart.entity.EntityCollection var10 = null;
    org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
    java.awt.geom.Rectangle2D var12 = var11.getChartArea();
    org.jfree.chart.axis.ValueAxis var13 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var14 = new org.jfree.chart.plot.CombinedDomainXYPlot(var13);
    org.jfree.chart.util.RectangleEdge var16 = var14.getRangeAxisEdge((-1));
    var14.clearDomainMarkers(1);
    var14.setRangeCrosshairVisible(false);
    int var21 = var14.getDatasetCount();
    org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var24 = null;
    org.jfree.data.time.TimeSeriesCollection var25 = new org.jfree.data.time.TimeSeriesCollection(var23, var24);
    org.jfree.chart.plot.PlotRenderingInfo var26 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var27 = var1.initialise(var9, var12, (org.jfree.chart.plot.XYPlot)var14, (org.jfree.data.xy.XYDataset)var25, var26);
    java.awt.Color var34 = java.awt.Color.getColor("#ffff5b", 10);
    org.jfree.chart.block.BlockBorder var35 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), (-1.0d), 0.0d, (java.awt.Paint)var34);
    var14.setDomainTickBandPaint((java.awt.Paint)var34);
    java.awt.Image var37 = null;
    var14.setBackgroundImage(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test410"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("org.jfree.chart.event.RendererChangeEvent[source=Preceding]");

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test411"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     org.jfree.chart.ChartRenderingInfo var30 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var31 = new org.jfree.chart.plot.PlotRenderingInfo(var30);
//     java.awt.geom.Point2D var32 = null;
//     var13.zoomDomainAxes(1.0d, 10.0d, var31, var32);
//     org.jfree.chart.axis.CategoryAxis var35 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var36 = var35.isAxisLineVisible();
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var35.setTickLabelPaint((java.awt.Paint)var40);
//     java.awt.Paint var42 = var35.getTickLabelPaint();
//     java.lang.String var43 = var35.getLabel();
//     org.jfree.chart.plot.Plot var44 = var35.getPlot();
//     var35.setMaximumCategoryLabelWidthRatio((-1.0f));
//     java.awt.Graphics2D var47 = null;
//     org.jfree.chart.util.HorizontalAlignment var49 = null;
//     org.jfree.chart.util.VerticalAlignment var50 = null;
//     org.jfree.chart.block.FlowArrangement var53 = new org.jfree.chart.block.FlowArrangement(var49, var50, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var54 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var56 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var53, var54, (java.lang.Comparable)(short)100);
//     java.lang.Object var57 = var56.clone();
//     org.jfree.chart.util.RectangleInsets var58 = var56.getPadding();
//     org.jfree.chart.entity.EntityCollection var59 = null;
//     org.jfree.chart.ChartRenderingInfo var60 = new org.jfree.chart.ChartRenderingInfo(var59);
//     java.awt.geom.Rectangle2D var61 = var60.getChartArea();
//     java.awt.geom.Rectangle2D var62 = var58.createInsetRectangle(var61);
//     org.jfree.data.category.CategoryDataset var63 = null;
//     org.jfree.chart.axis.CategoryAxis var65 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var66 = var65.isAxisLineVisible();
//     java.awt.Color var70 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var65.setTickLabelPaint((java.awt.Paint)var70);
//     org.jfree.chart.axis.ValueAxis var72 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var75 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var76 = new org.jfree.chart.plot.CategoryPlot(var63, var65, var72, (org.jfree.chart.renderer.category.CategoryItemRenderer)var75);
//     java.awt.Image var77 = null;
//     var76.setBackgroundImage(var77);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var80 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var85 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var86 = var85.getRGB();
//     var80.setSeriesFillPaint(0, (java.awt.Paint)var85, true);
//     java.awt.Color var89 = var85.brighter();
//     var76.setRangeZeroBaselinePaint((java.awt.Paint)var89);
//     java.lang.Comparable var91 = null;
//     var76.setDomainCrosshairRowKey(var91, false);
//     org.jfree.chart.LegendItemCollection var94 = var76.getLegendItems();
//     org.jfree.chart.util.RectangleEdge var95 = var76.getRangeAxisEdge();
//     org.jfree.chart.axis.AxisState var96 = null;
//     var35.drawTickMarks(var47, 10.0d, var62, var95, var96);
//     var31.setPlotArea(var62);
//     
//     // Checks the contract:  equals-hashcode on var13 and var76
//     assertTrue("Contract failed: equals-hashcode on var13 and var76", var13.equals(var76) ? var13.hashCode() == var76.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var76 and var13
//     assertTrue("Contract failed: equals-hashcode on var76 and var13", var76.equals(var13) ? var76.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test412"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var9 = var7.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var7.getSeriesItemLabelGenerator(0);
    var7.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var7.getBasePositiveItemLabelPosition();
    var2.setPositiveItemLabelPositionFallback(var14);
    java.awt.Shape var17 = var2.lookupSeriesShape(10);
    java.lang.Object var18 = null;
    boolean var19 = var2.equals(var18);
    java.awt.Color var27 = java.awt.Color.getColor("#ffff5b", 10);
    org.jfree.chart.block.BlockBorder var28 = new org.jfree.chart.block.BlockBorder(0.0d, (-1.0d), (-1.0d), 0.0d, (java.awt.Paint)var27);
    var2.setSeriesFillPaint(0, (java.awt.Paint)var27, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var31 = null;
    var2.setBaseToolTipGenerator(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test413"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDescription("hi!");
    org.jfree.chart.axis.DateAxis var5 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var5.setLowerMargin(10.0d);
    java.util.TimeZone var8 = var5.getTimeZone();
    org.jfree.data.time.TimeSeriesCollection var9 = new org.jfree.data.time.TimeSeriesCollection(var1, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var9.getXValue((-165), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test414"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    var1.clearDomainMarkers(1);
    var1.setRangeCrosshairVisible(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var10 = var9.getBaseItemLabelsVisible();
    var9.setBaseItemLabelsVisible(false);
    var1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test415"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.lang.String var2 = var1.getLabelFormat();
    java.text.AttributedString var4 = null;
    var1.setAttributedLabel(0, var4);
    org.jfree.data.general.PieDataset var6 = null;
    org.jfree.data.xy.XYSeries var8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    var8.add((-1.0d), (java.lang.Number)0.0d, false);
    int var13 = var8.getItemCount();
    org.jfree.data.xy.XYSeries var15 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    var15.add((java.lang.Number)0L, (java.lang.Number)(short)(-1));
    org.jfree.data.xy.XYDataItem var20 = var15.remove(0);
    var8.add(var20);
    java.lang.String var22 = var1.generateSectionLabel(var6, (java.lang.Comparable)var20);
    java.lang.String var23 = var1.getLabelFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + ""+ "'", var2.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var23 + "' != '" + ""+ "'", var23.equals(""));

  }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test416"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Object var8 = var7.clone();
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var10 = new org.jfree.chart.plot.CombinedDomainXYPlot(var9);
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var18 = var17.getRGB();
    var12.setSeriesFillPaint(0, (java.awt.Paint)var17, true);
    java.awt.Graphics2D var21 = null;
    java.awt.geom.Rectangle2D var22 = null;
    org.jfree.chart.plot.XYPlot var23 = null;
    org.jfree.data.xy.XYDataset var24 = null;
    org.jfree.chart.plot.PlotRenderingInfo var25 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var26 = var12.initialise(var21, var22, var23, var24, var25);
    java.awt.Font var27 = var12.getBaseLegendTextFont();
    int var28 = var10.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var12);
    org.jfree.chart.renderer.xy.XYItemRenderer var30 = null;
    var10.setRenderer(1, var30);
    boolean var32 = var7.equals((java.lang.Object)1);
    org.jfree.chart.util.RectangleInsets var33 = var7.getMargin();
    org.jfree.chart.block.Arrangement var34 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var7.setArrangement(var34);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test417"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var13.setFixedRangeAxisSpace(var27, false);
    var13.setCrosshairDatasetIndex((-126));
    java.lang.Object var32 = var13.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test418() {}
//   public void test418() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test418"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var3 = var2.isAxisLineVisible();
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var2.setTickLabelPaint((java.awt.Paint)var7);
//     org.jfree.chart.axis.ValueAxis var9 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
//     java.awt.Image var14 = null;
//     var13.setBackgroundImage(var14);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var23 = var22.getRGB();
//     var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
//     java.awt.Color var26 = var22.brighter();
//     var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
//     java.lang.Comparable var28 = null;
//     var13.setDomainCrosshairRowKey(var28, false);
//     org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
//     java.lang.Comparable var32 = var13.getDomainCrosshairColumnKey();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var34 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var39 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var40 = var39.getRGB();
//     var34.setSeriesFillPaint(0, (java.awt.Paint)var39, true);
//     java.awt.Paint[] var43 = new java.awt.Paint[] { var39};
//     java.awt.Color var47 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     java.awt.Paint[] var48 = new java.awt.Paint[] { var47};
//     java.awt.Stroke var49 = null;
//     java.awt.Stroke[] var50 = new java.awt.Stroke[] { var49};
//     java.awt.Stroke[] var51 = null;
//     java.awt.Shape var52 = null;
//     java.awt.Shape[] var53 = new java.awt.Shape[] { var52};
//     org.jfree.chart.plot.DefaultDrawingSupplier var54 = new org.jfree.chart.plot.DefaultDrawingSupplier(var43, var48, var50, var51, var53);
//     var13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var54);
//     org.jfree.data.category.CategoryDataset var58 = null;
//     org.jfree.chart.axis.CategoryAxis var60 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var61 = var60.isAxisLineVisible();
//     java.awt.Color var65 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var60.setTickLabelPaint((java.awt.Paint)var65);
//     org.jfree.chart.axis.ValueAxis var67 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var70 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var71 = new org.jfree.chart.plot.CategoryPlot(var58, var60, var67, (org.jfree.chart.renderer.category.CategoryItemRenderer)var70);
//     org.jfree.chart.plot.DrawingSupplier var72 = var71.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var74 = null;
//     org.jfree.chart.util.Layer var75 = null;
//     boolean var76 = var71.removeDomainMarker(100, var74, var75);
//     var71.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var80 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var81 = var80.getBaseItemLabelsVisible();
//     java.awt.Paint var85 = var80.getItemFillPaint((-1), (-1), true);
//     var71.setRangeGridlinePaint(var85);
//     org.jfree.chart.plot.IntervalMarker var87 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var85);
//     org.jfree.chart.event.MarkerChangeEvent var88 = null;
//     var87.notifyListeners(var88);
//     org.jfree.chart.util.RectangleAnchor var90 = var87.getLabelAnchor();
//     org.jfree.chart.text.TextAnchor var91 = var87.getLabelTextAnchor();
//     java.awt.Color var95 = java.awt.Color.getHSBColor(100.0f, 10.0f, 10.0f);
//     var87.setOutlinePaint((java.awt.Paint)var95);
//     var13.addRangeMarker((org.jfree.chart.plot.Marker)var87);
//     
//     // Checks the contract:  equals-hashcode on var17 and var80
//     assertTrue("Contract failed: equals-hashcode on var17 and var80", var17.equals(var80) ? var17.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var34 and var80
//     assertTrue("Contract failed: equals-hashcode on var34 and var80", var34.equals(var80) ? var34.hashCode() == var80.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var17
//     assertTrue("Contract failed: equals-hashcode on var80 and var17", var80.equals(var17) ? var80.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var80 and var34
//     assertTrue("Contract failed: equals-hashcode on var80 and var34", var80.equals(var34) ? var80.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test419"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    var2.setDrawBarOutline(false);
    java.lang.Object var11 = null;
    boolean var12 = var2.equals(var11);
    var2.setItemMargin(0.0d);
    org.jfree.chart.labels.ItemLabelPosition var16 = var2.getSeriesPositiveItemLabelPosition(10);
    var2.setBaseSeriesVisibleInLegend(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test420"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var14 = var13.getURLText();
    int var15 = var13.getItem();
    java.lang.String var16 = var13.getShapeCoords();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var16 + "' != '" + "-4,-4,4,4"+ "'", var16.equals("-4,-4,4,4"));

  }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test421"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    java.lang.String var2 = var1.getNoDataMessage();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var4.configure();
    java.awt.Stroke var6 = var4.getTickMarkStroke();
    var1.setRangeGridlineStroke(var6);
    org.jfree.chart.plot.Marker var8 = null;
    boolean var9 = var1.removeDomainMarker(var8);
    var1.configureDomainAxes();
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var16 = var12.getToolTipGenerator((-1), (-165), false);
    var12.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var20 = null;
    org.jfree.chart.entity.EntityCollection var21 = null;
    org.jfree.chart.ChartRenderingInfo var22 = new org.jfree.chart.ChartRenderingInfo(var21);
    java.awt.geom.Rectangle2D var23 = var22.getChartArea();
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var25 = new org.jfree.chart.plot.CombinedDomainXYPlot(var24);
    org.jfree.chart.util.RectangleEdge var27 = var25.getRangeAxisEdge((-1));
    var25.clearDomainMarkers(1);
    var25.setRangeCrosshairVisible(false);
    int var32 = var25.getDatasetCount();
    org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var35 = null;
    org.jfree.data.time.TimeSeriesCollection var36 = new org.jfree.data.time.TimeSeriesCollection(var34, var35);
    org.jfree.chart.plot.PlotRenderingInfo var37 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var38 = var12.initialise(var20, var23, (org.jfree.chart.plot.XYPlot)var25, (org.jfree.data.xy.XYDataset)var36, var37);
    org.jfree.chart.renderer.xy.XYItemRenderer var39 = var1.getRendererForDataset((org.jfree.data.xy.XYDataset)var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test422"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var8 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var9 = var8.getRGB();
//     var3.setSeriesFillPaint(0, (java.awt.Paint)var8, true);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.chart.plot.XYPlot var14 = null;
//     org.jfree.data.xy.XYDataset var15 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var16 = null;
//     org.jfree.chart.renderer.xy.XYItemRendererState var17 = var3.initialise(var12, var13, var14, var15, var16);
//     java.awt.Font var18 = var3.getBaseLegendTextFont();
//     int var19 = var1.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var3);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = null;
//     var1.setRenderer(1, var21);
//     org.jfree.chart.ChartRenderingInfo var25 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var26 = new org.jfree.chart.plot.PlotRenderingInfo(var25);
//     var1.handleClick(1, 1, var26);
//     org.jfree.chart.axis.ValueAxis var28 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var29 = new org.jfree.chart.plot.CombinedDomainXYPlot(var28);
//     org.jfree.chart.util.RectangleEdge var31 = var29.getRangeAxisEdge((-1));
//     org.jfree.chart.axis.ValueAxis var32 = null;
//     org.jfree.data.Range var33 = var29.getDataRange(var32);
//     var29.configureDomainAxes();
//     var29.setDomainCrosshairVisible(true);
//     org.jfree.data.category.CategoryDataset var37 = null;
//     org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var40 = var39.isAxisLineVisible();
//     java.awt.Color var44 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var39.setTickLabelPaint((java.awt.Paint)var44);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var49 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var50 = new org.jfree.chart.plot.CategoryPlot(var37, var39, var46, (org.jfree.chart.renderer.category.CategoryItemRenderer)var49);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var51 = var49.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var53 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var54 = var53.getBaseItemLabelsVisible();
//     java.awt.Shape var58 = var53.getItemShape(0, 1, false);
//     var49.setBaseLegendShape(var58);
//     double var60 = var49.getMaximumBarWidth();
//     java.awt.Paint var62 = var49.lookupSeriesFillPaint(10);
//     var29.setDomainGridlinePaint(var62);
//     var1.setDomainZeroBaselinePaint(var62);
//     
//     // Checks the contract:  equals-hashcode on var3 and var53
//     assertTrue("Contract failed: equals-hashcode on var3 and var53", var3.equals(var53) ? var3.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var3
//     assertTrue("Contract failed: equals-hashcode on var53 and var3", var53.equals(var3) ? var53.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test423"); }


    org.jfree.chart.util.HorizontalAlignment var0 = null;
    org.jfree.chart.util.VerticalAlignment var1 = null;
    org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var5 = null;
    org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
    java.lang.Comparable var8 = var7.getSeriesKey();
    java.util.List var9 = var7.getBlocks();
    java.lang.String var10 = var7.getURLText();
    java.lang.String var11 = var7.getURLText();
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.util.Size2D var13 = var7.arrange(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (short)100+ "'", var8.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test424"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    var1.setTickMarkInsideLength(1.0f);
    org.jfree.chart.util.RectangleInsets var10 = var1.getLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test425"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    float var3 = var1.getTickMarkInsideLength();
    org.jfree.chart.renderer.category.BarRenderer3D var6 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var8 = var6.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var10 = var6.getSeriesItemLabelGenerator(0);
    var6.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var13 = var6.getBasePositiveItemLabelPosition();
    double var14 = var6.getYOffset();
    org.jfree.data.category.CategoryDataset var15 = null;
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var18 = var17.isAxisLineVisible();
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var17.setTickLabelPaint((java.awt.Paint)var22);
    org.jfree.chart.axis.ValueAxis var24 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var27 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var28 = new org.jfree.chart.plot.CategoryPlot(var15, var17, var24, (org.jfree.chart.renderer.category.CategoryItemRenderer)var27);
    java.awt.Image var29 = null;
    var28.setBackgroundImage(var29);
    org.jfree.chart.renderer.xy.XYAreaRenderer var32 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var37 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var38 = var37.getRGB();
    var32.setSeriesFillPaint(0, (java.awt.Paint)var37, true);
    java.awt.Color var41 = var37.brighter();
    var28.setRangeZeroBaselinePaint((java.awt.Paint)var41);
    java.lang.Comparable var43 = null;
    var28.setDomainCrosshairRowKey(var43, false);
    org.jfree.chart.LegendItemCollection var46 = var28.getLegendItems();
    org.jfree.chart.util.Layer var47 = null;
    java.util.Collection var48 = var28.getRangeMarkers(var47);
    var6.addChangeListener((org.jfree.chart.event.RendererChangeListener)var28);
    org.jfree.chart.axis.AxisSpace var50 = var28.getFixedDomainAxisSpace();
    var1.setPlot((org.jfree.chart.plot.Plot)var28);
    boolean var52 = var1.isTickMarksVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test426"); }
// 
// 
//     org.jfree.data.general.PieDataset var0 = null;
//     org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
//     java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
//     java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var7 = var6.getRGB();
//     java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
//     var1.setLabelPaint((java.awt.Paint)var6);
//     java.awt.color.ColorSpace var10 = null;
//     float[] var14 = new float[] { 100.0f, 10.0f, 0.0f};
//     float[] var15 = var6.getComponents(var10, var14);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test427"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
    org.jfree.chart.axis.AxisLocation var5 = var1.getRangeAxisLocation(1);
    org.jfree.data.xy.XYDataset var6 = null;
    int var7 = var1.indexOf(var6);
    var1.setDomainZeroBaselineVisible(false);
    java.awt.Stroke var10 = var1.getDomainZeroBaselineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test428"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    java.awt.Stroke var8 = var1.getTickMarkStroke();
    org.jfree.chart.util.RectangleInsets var9 = var1.getTickLabelInsets();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test429"); }


    java.lang.Comparable var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test430"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Paint[] var10 = new java.awt.Paint[] { var6};
    java.awt.Color var14 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    java.awt.Paint[] var15 = new java.awt.Paint[] { var14};
    java.awt.Stroke var16 = null;
    java.awt.Stroke[] var17 = new java.awt.Stroke[] { var16};
    java.awt.Stroke[] var18 = null;
    java.awt.Shape var19 = null;
    java.awt.Shape[] var20 = new java.awt.Shape[] { var19};
    org.jfree.chart.plot.DefaultDrawingSupplier var21 = new org.jfree.chart.plot.DefaultDrawingSupplier(var10, var15, var17, var18, var20);
    java.awt.Paint var22 = var21.getNextPaint();
    org.jfree.chart.renderer.xy.XYAreaRenderer var24 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var29 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var30 = var29.getRGB();
    var24.setSeriesFillPaint(0, (java.awt.Paint)var29, true);
    boolean var33 = var21.equals((java.lang.Object)0);
    org.jfree.data.xy.XYDataset var34 = null;
    org.jfree.chart.axis.ValueAxis var35 = null;
    org.jfree.chart.axis.ValueAxis var36 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var38 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot(var34, var35, var36, (org.jfree.chart.renderer.xy.XYItemRenderer)var38);
    boolean var40 = var21.equals((java.lang.Object)var39);
    java.awt.Paint var41 = var21.getNextFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test431"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    java.lang.Boolean var16 = var14.getSeriesLinesVisible(0);
    org.jfree.chart.LegendItem var19 = var14.getLegendItem((-1), 100);
    boolean var22 = var14.getItemLineVisible((-126), (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);

  }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test432"); }


    org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var2.setLowerMargin(10.0d);
    org.jfree.chart.axis.CategoryAxis var6 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var6.configure();
    java.awt.Font var8 = var6.getTickLabelFont();
    var2.setLabelFont(var8);
    org.jfree.data.category.CategoryDataset var10 = null;
    org.jfree.chart.axis.CategoryAxis var12 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var13 = var12.isAxisLineVisible();
    java.awt.Color var17 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var12.setTickLabelPaint((java.awt.Paint)var17);
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var22 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var10, var12, var19, (org.jfree.chart.renderer.category.CategoryItemRenderer)var22);
    java.awt.Image var24 = null;
    var23.setBackgroundImage(var24);
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var33 = var32.getRGB();
    var27.setSeriesFillPaint(0, (java.awt.Paint)var32, true);
    java.awt.Color var36 = var32.brighter();
    var23.setRangeZeroBaselinePaint((java.awt.Paint)var36);
    org.jfree.data.category.CategoryDataset var38 = null;
    org.jfree.chart.axis.CategoryAxis var40 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var41 = var40.isAxisLineVisible();
    java.awt.Color var45 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var40.setTickLabelPaint((java.awt.Paint)var45);
    org.jfree.chart.axis.ValueAxis var47 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var50 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var51 = new org.jfree.chart.plot.CategoryPlot(var38, var40, var47, (org.jfree.chart.renderer.category.CategoryItemRenderer)var50);
    var51.setForegroundAlpha(0.0f);
    java.awt.Stroke var54 = var51.getDomainCrosshairStroke();
    java.lang.Object var55 = var51.clone();
    var51.clearDomainAxes();
    org.jfree.chart.axis.ValueAxis var58 = var51.getRangeAxis(0);
    org.jfree.chart.util.RectangleEdge var59 = var51.getDomainAxisEdge();
    org.jfree.chart.util.HorizontalAlignment var60 = null;
    org.jfree.chart.util.VerticalAlignment var61 = null;
    org.jfree.chart.util.HorizontalAlignment var62 = null;
    org.jfree.chart.util.VerticalAlignment var63 = null;
    org.jfree.chart.block.FlowArrangement var66 = new org.jfree.chart.block.FlowArrangement(var62, var63, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var67 = null;
    org.jfree.chart.title.LegendItemBlockContainer var69 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var66, var67, (java.lang.Comparable)(short)100);
    java.lang.Object var70 = var69.clone();
    org.jfree.chart.util.RectangleInsets var71 = var69.getPadding();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var72 = new org.jfree.chart.title.TextTitle("", var8, (java.awt.Paint)var36, var59, var60, var61, var71);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test433"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test434"); }


    org.jfree.chart.entity.EntityCollection var0 = null;
    org.jfree.chart.ChartRenderingInfo var1 = new org.jfree.chart.ChartRenderingInfo(var0);
    org.jfree.chart.plot.PlotRenderingInfo var2 = new org.jfree.chart.plot.PlotRenderingInfo(var1);
    java.awt.geom.Rectangle2D var3 = var2.getDataArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test435"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    var1.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var9 = var1.getLegendItemLabelGenerator();
    boolean var10 = var1.getBaseSeriesVisibleInLegend();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test436"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    double var8 = var4.getMargin();
    boolean var9 = var4.getShadowsVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test437"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var9 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var10 = var9.getBaseItemLabelsVisible();
    java.awt.Shape var14 = var9.getItemShape(0, 1, false);
    org.jfree.chart.entity.ChartEntity var15 = new org.jfree.chart.entity.ChartEntity(var14);
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.clone(var14);
    boolean var17 = var4.equals((java.lang.Object)var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test438"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    var2.setShadowVisible(false);
    org.jfree.data.category.CategoryDataset var9 = null;
    org.jfree.chart.axis.CategoryAxis var11 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var12 = var11.isAxisLineVisible();
    java.awt.Color var16 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var11.setTickLabelPaint((java.awt.Paint)var16);
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var21 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var22 = new org.jfree.chart.plot.CategoryPlot(var9, var11, var18, (org.jfree.chart.renderer.category.CategoryItemRenderer)var21);
    java.awt.Image var23 = null;
    var22.setBackgroundImage(var23);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var32 = var31.getRGB();
    var26.setSeriesFillPaint(0, (java.awt.Paint)var31, true);
    java.awt.Color var35 = var31.brighter();
    var22.setRangeZeroBaselinePaint((java.awt.Paint)var35);
    java.lang.Comparable var37 = null;
    var22.setDomainCrosshairRowKey(var37, false);
    org.jfree.chart.LegendItemCollection var40 = var22.getLegendItems();
    org.jfree.chart.util.RectangleEdge var41 = var22.getRangeAxisEdge();
    var2.setPlot(var22);
    org.jfree.data.category.CategoryDataset var43 = null;
    org.jfree.chart.axis.CategoryAxis var45 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var46 = var45.isAxisLineVisible();
    java.awt.Color var50 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var45.setTickLabelPaint((java.awt.Paint)var50);
    org.jfree.chart.axis.ValueAxis var52 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var55 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var56 = new org.jfree.chart.plot.CategoryPlot(var43, var45, var52, (org.jfree.chart.renderer.category.CategoryItemRenderer)var55);
    var56.setForegroundAlpha(0.0f);
    java.awt.Stroke var59 = var56.getDomainCrosshairStroke();
    java.lang.Object var60 = var56.clone();
    var56.clearDomainAxes();
    org.jfree.chart.axis.ValueAxis var63 = var56.getRangeAxis(0);
    org.jfree.chart.plot.PlotOrientation var64 = var56.getOrientation();
    var22.setOrientation(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test439"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
    org.jfree.chart.util.RectangleEdge var33 = org.jfree.chart.util.RectangleEdge.opposite(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test440"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test441"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var5 = var4.isAxisLineVisible();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var4.setTickLabelPaint((java.awt.Paint)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var2, var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var18 = var17.isAxisLineVisible();
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var17.setTickLabelPaint((java.awt.Paint)var22);
    java.awt.Paint var24 = var17.getTickLabelPaint();
    var15.setRangeZeroBaselinePaint(var24);
    var1.setLabelBackgroundPaint(var24);
    var1.setLabelLinkMargin(10.0d);
    boolean var29 = var1.getAutoPopulateSectionOutlinePaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test442"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
    java.awt.Stroke var7 = var2.getBaseOutlineStroke();
    java.awt.Paint var11 = var2.getItemPaint(0, 10, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test443() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test443"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    org.jfree.data.category.CategoryDataset var2 = null;
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var5 = var4.isAxisLineVisible();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var4.setTickLabelPaint((java.awt.Paint)var9);
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var14 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var15 = new org.jfree.chart.plot.CategoryPlot(var2, var4, var11, (org.jfree.chart.renderer.category.CategoryItemRenderer)var14);
    org.jfree.chart.axis.CategoryAxis var17 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var18 = var17.isAxisLineVisible();
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var17.setTickLabelPaint((java.awt.Paint)var22);
    java.awt.Paint var24 = var17.getTickLabelPaint();
    var15.setRangeZeroBaselinePaint(var24);
    var1.setLabelBackgroundPaint(var24);
    boolean var27 = var1.getDarkerSides();
    double var28 = var1.getMaximumLabelWidth();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0.14d);

  }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test444"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    java.awt.Shape var8 = var1.getShape();
    var1.setURLText("Preceding");
    org.jfree.data.category.CategoryDataset var11 = null;
    org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var14 = var13.isAxisLineVisible();
    java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var13.setTickLabelPaint((java.awt.Paint)var18);
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
    org.jfree.chart.labels.CategoryItemLabelGenerator var25 = var23.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var28 = var27.getBaseItemLabelsVisible();
    java.awt.Shape var32 = var27.getItemShape(0, 1, false);
    var23.setBaseLegendShape(var32);
    double var34 = var23.getMaximumBarWidth();
    java.awt.Color var38 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var39 = var38.getRGB();
    var23.setWallPaint((java.awt.Paint)var38);
    var1.setLabelPaint((java.awt.Paint)var38);
    java.awt.Paint var42 = var1.getLabelPaint();
    java.lang.Comparable var43 = var1.getSeriesKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test445"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var1.setLowerMargin(10.0d);
    java.util.TimeZone var4 = var1.getTimeZone();
    java.awt.Shape var5 = var1.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test446"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    float var3 = var1.getTickMarkInsideLength();
    org.jfree.chart.plot.Plot var4 = var1.getPlot();
    var1.clearCategoryLabelToolTips();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test447"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    java.awt.Paint var4 = var1.getDomainZeroBaselinePaint();
    boolean var5 = var1.isDomainPannable();
    boolean var6 = var1.canSelectByPoint();
    var1.clearRangeMarkers();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test448"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    java.lang.String var2 = var1.getToolTipText();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var5 = var4.isAxisLineVisible();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var4.setTickLabelPaint((java.awt.Paint)var9);
    java.awt.Stroke var11 = var4.getTickMarkStroke();
    org.jfree.chart.renderer.xy.XYAreaRenderer var15 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var19 = var15.getToolTipGenerator((-1), (-165), false);
    var15.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var23 = var15.getLegendItemLabelGenerator();
    org.jfree.chart.util.GradientPaintTransformer var24 = var15.getGradientTransformer();
    java.awt.Shape var26 = var15.lookupSeriesShape(0);
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.block.FlowArrangement var32 = new org.jfree.chart.block.FlowArrangement(var28, var29, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var33 = null;
    org.jfree.chart.title.LegendItemBlockContainer var35 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var32, var33, (java.lang.Comparable)(short)100);
    java.lang.Object var36 = var35.clone();
    org.jfree.chart.util.RectangleInsets var37 = var35.getPadding();
    org.jfree.chart.entity.EntityCollection var38 = null;
    org.jfree.chart.ChartRenderingInfo var39 = new org.jfree.chart.ChartRenderingInfo(var38);
    java.awt.geom.Rectangle2D var40 = var39.getChartArea();
    java.awt.geom.Rectangle2D var41 = var37.createInsetRectangle(var40);
    var15.setLegendShape(0, (java.awt.Shape)var41);
    org.jfree.chart.util.RectangleEdge var43 = null;
    double var44 = var4.getCategoryEnd(0, 100, var41, var43);
    var1.setBounds(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0.0d);

  }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test449"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var5 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var4, var5, (java.lang.Comparable)(short)100);
//     java.lang.Object var8 = var7.clone();
//     org.jfree.chart.util.RectangleInsets var9 = var7.getPadding();
//     org.jfree.chart.entity.EntityCollection var10 = null;
//     org.jfree.chart.ChartRenderingInfo var11 = new org.jfree.chart.ChartRenderingInfo(var10);
//     java.awt.geom.Rectangle2D var12 = var11.getChartArea();
//     java.awt.geom.Rectangle2D var13 = var9.createInsetRectangle(var12);
//     double var15 = var9.calculateBottomInset(0.0d);
//     org.jfree.chart.axis.NumberAxis var16 = null;
//     java.awt.Font var21 = null;
//     org.jfree.chart.axis.MarkerAxisBand var22 = new org.jfree.chart.axis.MarkerAxisBand(var16, 0.0d, 100.0d, 10.0d, (-1.0d), var21);
//     java.awt.Graphics2D var23 = null;
//     org.jfree.chart.util.HorizontalAlignment var24 = null;
//     org.jfree.chart.util.VerticalAlignment var25 = null;
//     org.jfree.chart.block.FlowArrangement var28 = new org.jfree.chart.block.FlowArrangement(var24, var25, (-1.0d), (-1.0d));
//     org.jfree.data.general.Dataset var29 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var31 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var28, var29, (java.lang.Comparable)(short)100);
//     java.lang.Object var32 = var31.clone();
//     org.jfree.chart.util.RectangleInsets var33 = var31.getPadding();
//     org.jfree.chart.entity.EntityCollection var34 = null;
//     org.jfree.chart.ChartRenderingInfo var35 = new org.jfree.chart.ChartRenderingInfo(var34);
//     java.awt.geom.Rectangle2D var36 = var35.getChartArea();
//     java.awt.geom.Rectangle2D var37 = var33.createInsetRectangle(var36);
//     java.awt.geom.Rectangle2D var38 = null;
//     var22.draw(var23, var36, var38, 0.0d, 10.0d);
//     java.awt.geom.Rectangle2D var42 = var9.createOutsetRectangle(var36);
//     
//     // Checks the contract:  equals-hashcode on var4 and var28
//     assertTrue("Contract failed: equals-hashcode on var4 and var28", var4.equals(var28) ? var4.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var4
//     assertTrue("Contract failed: equals-hashcode on var28 and var4", var28.equals(var4) ? var28.hashCode() == var4.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var31
//     assertTrue("Contract failed: equals-hashcode on var7 and var31", var7.equals(var31) ? var7.hashCode() == var31.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var31 and var7
//     assertTrue("Contract failed: equals-hashcode on var31 and var7", var31.equals(var7) ? var31.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var32
//     assertTrue("Contract failed: equals-hashcode on var8 and var32", var8.equals(var32) ? var8.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var8
//     assertTrue("Contract failed: equals-hashcode on var32 and var8", var32.equals(var8) ? var32.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var11 and var35
//     assertTrue("Contract failed: equals-hashcode on var11 and var35", var11.equals(var35) ? var11.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var11
//     assertTrue("Contract failed: equals-hashcode on var35 and var11", var35.equals(var11) ? var35.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test450"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Shape var6 = var1.getItemShape(0, 1, false);
    org.jfree.chart.entity.ChartEntity var7 = new org.jfree.chart.entity.ChartEntity(var6);
    java.lang.String var8 = var7.getShapeCoords();
    java.lang.String var9 = var7.getURLText();
    org.jfree.chart.imagemap.ToolTipTagFragmentGenerator var10 = null;
    org.jfree.chart.imagemap.URLTagFragmentGenerator var11 = null;
    java.lang.String var12 = var7.getImageMapAreaTag(var10, var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "-3,-3,3,3"+ "'", var8.equals("-3,-3,3,3"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + ""+ "'", var12.equals(""));

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test451"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    var13.clearDomainMarkers(0);
    org.jfree.chart.renderer.category.CategoryItemRenderer var22 = var13.getRenderer((-126));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test452"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    java.awt.Font var5 = var1.lookupLegendTextFont(100);
    java.awt.Paint var7 = var1.getSeriesFillPaint((-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test453"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var3 = var2.getNumberFormat();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(0.0d, var3);
    int var5 = var4.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test454"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var32 = var31.getRGB();
    var26.setSeriesFillPaint(0, (java.awt.Paint)var31, true);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.plot.XYPlot var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var40 = var26.initialise(var35, var36, var37, var38, var39);
    java.awt.Font var41 = var26.getBaseLegendTextFont();
    int var42 = var24.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var26);
    org.jfree.chart.axis.AxisSpace var43 = var24.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var45 = var24.getRangeAxisLocation((-165));
    java.lang.Object var46 = var24.clone();
    org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var48.setLowerMargin(10.0d);
    java.util.TimeZone var51 = var48.getTimeZone();
    org.jfree.chart.entity.EntityCollection var52 = null;
    org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
    java.awt.geom.Rectangle2D var54 = var53.getChartArea();
    var1.fillRangeGridBand(var22, (org.jfree.chart.plot.XYPlot)var24, (org.jfree.chart.axis.ValueAxis)var48, var54, 0.0d, 0.0d);
    var48.setAutoRangeMinimumSize(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test455"); }


    java.awt.Graphics2D var1 = null;
    org.jfree.chart.text.TextUtilities.drawRotatedString("", var1, 0.0f, (-1.0f), 0.0d, 10.0f, 1.0f);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test456"); }
// 
// 
//     java.awt.Font var1 = null;
//     org.jfree.chart.LegendItem var3 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
//     java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var3.setFillPaint((java.awt.Paint)var7);
//     java.awt.Shape var9 = var3.getShape();
//     java.awt.Shape var10 = var3.getShape();
//     var3.setURLText("Preceding");
//     org.jfree.data.category.CategoryDataset var13 = null;
//     org.jfree.chart.axis.CategoryAxis var15 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var16 = var15.isAxisLineVisible();
//     java.awt.Color var20 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var15.setTickLabelPaint((java.awt.Paint)var20);
//     org.jfree.chart.axis.ValueAxis var22 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var25 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var26 = new org.jfree.chart.plot.CategoryPlot(var13, var15, var22, (org.jfree.chart.renderer.category.CategoryItemRenderer)var25);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var27 = var25.getBaseItemLabelGenerator();
//     org.jfree.chart.renderer.xy.XYAreaRenderer var29 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var30 = var29.getBaseItemLabelsVisible();
//     java.awt.Shape var34 = var29.getItemShape(0, 1, false);
//     var25.setBaseLegendShape(var34);
//     double var36 = var25.getMaximumBarWidth();
//     java.awt.Color var40 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var41 = var40.getRGB();
//     var25.setWallPaint((java.awt.Paint)var40);
//     var3.setLabelPaint((java.awt.Paint)var40);
//     org.jfree.chart.text.TextMeasurer var46 = null;
//     org.jfree.chart.text.TextBlock var47 = org.jfree.chart.text.TextUtilities.createTextBlock("XYItemEntity: series = -1, item = 100, dataset = null", var1, (java.awt.Paint)var40, 10.0f, 0, var46);
// 
//   }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test457"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var32 = var31.getRGB();
    var26.setSeriesFillPaint(0, (java.awt.Paint)var31, true);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.plot.XYPlot var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var40 = var26.initialise(var35, var36, var37, var38, var39);
    java.awt.Font var41 = var26.getBaseLegendTextFont();
    int var42 = var24.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var26);
    org.jfree.chart.axis.AxisSpace var43 = var24.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var45 = var24.getRangeAxisLocation((-165));
    java.lang.Object var46 = var24.clone();
    org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var48.setLowerMargin(10.0d);
    java.util.TimeZone var51 = var48.getTimeZone();
    org.jfree.chart.entity.EntityCollection var52 = null;
    org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
    java.awt.geom.Rectangle2D var54 = var53.getChartArea();
    var1.fillRangeGridBand(var22, (org.jfree.chart.plot.XYPlot)var24, (org.jfree.chart.axis.ValueAxis)var48, var54, 0.0d, 0.0d);
    var48.setVerticalTickLabels(false);
    int var60 = var48.getMinorTickCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);

  }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test458"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var2 = var1.isAxisLineVisible();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setTickLabelPaint((java.awt.Paint)var6);
    java.awt.Stroke var8 = var1.getTickMarkStroke();
    org.jfree.chart.renderer.xy.XYAreaRenderer var12 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var16 = var12.getToolTipGenerator((-1), (-165), false);
    var12.setSeriesVisible(0, (java.lang.Boolean)false);
    org.jfree.chart.labels.XYSeriesLabelGenerator var20 = var12.getLegendItemLabelGenerator();
    org.jfree.chart.util.GradientPaintTransformer var21 = var12.getGradientTransformer();
    java.awt.Shape var23 = var12.lookupSeriesShape(0);
    org.jfree.chart.util.HorizontalAlignment var25 = null;
    org.jfree.chart.util.VerticalAlignment var26 = null;
    org.jfree.chart.block.FlowArrangement var29 = new org.jfree.chart.block.FlowArrangement(var25, var26, (-1.0d), (-1.0d));
    org.jfree.data.general.Dataset var30 = null;
    org.jfree.chart.title.LegendItemBlockContainer var32 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var29, var30, (java.lang.Comparable)(short)100);
    java.lang.Object var33 = var32.clone();
    org.jfree.chart.util.RectangleInsets var34 = var32.getPadding();
    org.jfree.chart.entity.EntityCollection var35 = null;
    org.jfree.chart.ChartRenderingInfo var36 = new org.jfree.chart.ChartRenderingInfo(var35);
    java.awt.geom.Rectangle2D var37 = var36.getChartArea();
    java.awt.geom.Rectangle2D var38 = var34.createInsetRectangle(var37);
    var12.setLegendShape(0, (java.awt.Shape)var38);
    org.jfree.chart.util.RectangleEdge var40 = null;
    double var41 = var1.getCategoryEnd(0, 100, var38, var40);
    java.awt.Font var42 = var1.getLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test459"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var2 = var1.getNumberFormat();
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var4.setUpperMargin(1.0d);
    var4.setTickMarkInsideLength(0.0f);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.text.AttributedCharacterIterator var9 = var2.formatToCharacterIterator((java.lang.Object)var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test460"); }


    org.jfree.chart.axis.CategoryAxis var1 = new org.jfree.chart.axis.CategoryAxis("hi!");
    var1.setUpperMargin(1.0d);
    org.jfree.chart.plot.Plot var4 = var1.getPlot();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test461"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.LegendItemCollection var14 = var13.getFixedLegendItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test462"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    double var2 = var1.getMaximumExplodePercent();
    org.jfree.chart.axis.ValueAxis var3 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var4 = new org.jfree.chart.plot.CombinedDomainXYPlot(var3);
    org.jfree.chart.renderer.xy.XYAreaRenderer var6 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var11 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var12 = var11.getRGB();
    var6.setSeriesFillPaint(0, (java.awt.Paint)var11, true);
    java.awt.Graphics2D var15 = null;
    java.awt.geom.Rectangle2D var16 = null;
    org.jfree.chart.plot.XYPlot var17 = null;
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.plot.PlotRenderingInfo var19 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var20 = var6.initialise(var15, var16, var17, var18, var19);
    java.awt.Font var21 = var6.getBaseLegendTextFont();
    int var22 = var4.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var6);
    org.jfree.chart.axis.AxisSpace var23 = var4.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var25 = var4.getRangeAxisLocation((-165));
    java.awt.Stroke var26 = var4.getRangeGridlineStroke();
    var1.setLabelLinkStroke(var26);
    org.jfree.data.category.CategoryDataset var28 = null;
    org.jfree.chart.axis.CategoryAxis var30 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var31 = var30.isAxisLineVisible();
    java.awt.Color var35 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var30.setTickLabelPaint((java.awt.Paint)var35);
    org.jfree.chart.axis.ValueAxis var37 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var40 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var41 = new org.jfree.chart.plot.CategoryPlot(var28, var30, var37, (org.jfree.chart.renderer.category.CategoryItemRenderer)var40);
    org.jfree.chart.axis.CategoryAxis var43 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var44 = var43.isAxisLineVisible();
    java.awt.Color var48 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var43.setTickLabelPaint((java.awt.Paint)var48);
    java.awt.Paint var50 = var43.getTickLabelPaint();
    var41.setRangeZeroBaselinePaint(var50);
    var1.setLabelPaint(var50);
    org.jfree.chart.util.RectangleInsets var53 = var1.getSimpleLabelOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test463"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    var1.setIgnoreZeroValues(true);
    org.jfree.chart.event.MarkerChangeEvent var12 = null;
    var1.markerChanged(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test464"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var12.getBaseItemLabelGenerator();
    org.jfree.chart.renderer.xy.XYAreaRenderer var16 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var17 = var16.getBaseItemLabelsVisible();
    java.awt.Shape var21 = var16.getItemShape(0, 1, false);
    var12.setBaseLegendShape(var21);
    double var23 = var12.getMaximumBarWidth();
    java.awt.Paint var25 = var12.lookupSeriesFillPaint(10);
    java.awt.Shape var27 = var12.lookupLegendShape(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test465"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.plot.XYPlot var4 = null;
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.plot.Marker var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    var1.drawRangeMarker(var3, var4, var5, var6, var7);
    java.awt.Stroke var10 = var1.getSeriesOutlineStroke(10);
    var1.setItemLabelAnchorOffset((-1.0d));
    java.awt.Stroke var16 = var1.getItemOutlineStroke(1, (-165), false);
    org.jfree.chart.urls.XYURLGenerator var18 = var1.getSeriesURLGenerator(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test466"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.plot.DrawingSupplier var14 = var13.getDrawingSupplier();
    org.jfree.chart.plot.Marker var16 = null;
    org.jfree.chart.util.Layer var17 = null;
    boolean var18 = var13.removeDomainMarker(100, var16, var17);
    org.jfree.chart.plot.Marker var20 = null;
    org.jfree.chart.util.Layer var21 = null;
    boolean var23 = var13.removeDomainMarker(100, var20, var21, false);
    org.jfree.chart.axis.AxisSpace var24 = null;
    var13.setFixedRangeAxisSpace(var24, false);
    org.jfree.chart.axis.AxisSpace var27 = null;
    var13.setFixedRangeAxisSpace(var27, false);
    org.jfree.chart.LegendItemCollection var30 = var13.getLegendItems();
    org.jfree.chart.util.SortOrder var31 = var13.getRowRenderingOrder();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test467"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.PiePlot3D var1 = new org.jfree.chart.plot.PiePlot3D(var0);
    java.awt.Stroke var2 = var1.getBaseSectionOutlineStroke();
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    java.lang.String var8 = org.jfree.chart.util.PaintUtilities.colorToString(var6);
    var1.setLabelPaint((java.awt.Paint)var6);
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var14 = var12.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var17 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var19 = var17.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var21 = var17.getSeriesItemLabelGenerator(0);
    var17.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var24 = var17.getBasePositiveItemLabelPosition();
    var12.setPositiveItemLabelPositionFallback(var24);
    java.awt.Shape var27 = var12.lookupSeriesShape(10);
    java.awt.Shape var29 = var12.getSeriesShape((-165));
    org.jfree.chart.renderer.xy.XYAreaRenderer var31 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var32 = var31.getBaseItemLabelsVisible();
    boolean var33 = var31.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.ItemLabelPosition var35 = var31.getSeriesNegativeItemLabelPosition(10);
    org.jfree.chart.text.TextAnchor var36 = var35.getTextAnchor();
    var12.setNegativeItemLabelPositionFallback(var35);
    org.jfree.chart.axis.CategoryAxis var39 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var40 = var39.isAxisLineVisible();
    float var41 = var39.getTickMarkInsideLength();
    var39.clearCategoryLabelToolTips();
    java.awt.Paint var43 = var39.getAxisLinePaint();
    var12.setShadowPaint(var43);
    var1.setLabelOutlinePaint(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + "#ffff5b"+ "'", var8.equals("#ffff5b"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test468"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    var2.setIncludeBaseInRange(true);
    org.jfree.chart.urls.CategoryURLGenerator var7 = null;
    var2.setBaseURLGenerator(var7);
    var2.setSeriesVisible(100, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test469"); }


    org.jfree.data.xy.XYSeries var1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable)"");
    var1.add((-1.0d), (java.lang.Number)0.0d, false);
    var1.clear();
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var12 = var8.getToolTipGenerator((-1), (-165), false);
    var8.setSeriesVisible(0, (java.lang.Boolean)false);
    java.awt.Graphics2D var16 = null;
    org.jfree.chart.entity.EntityCollection var17 = null;
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo(var17);
    java.awt.geom.Rectangle2D var19 = var18.getChartArea();
    org.jfree.chart.axis.ValueAxis var20 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var21 = new org.jfree.chart.plot.CombinedDomainXYPlot(var20);
    org.jfree.chart.util.RectangleEdge var23 = var21.getRangeAxisEdge((-1));
    var21.clearDomainMarkers(1);
    var21.setRangeCrosshairVisible(false);
    int var28 = var21.getDatasetCount();
    org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.util.TimeZone var31 = null;
    org.jfree.data.time.TimeSeriesCollection var32 = new org.jfree.data.time.TimeSeriesCollection(var30, var31);
    org.jfree.chart.plot.PlotRenderingInfo var33 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var34 = var8.initialise(var16, var19, (org.jfree.chart.plot.XYPlot)var21, (org.jfree.data.xy.XYDataset)var32, var33);
    org.jfree.data.xy.XYDatasetSelectionState var35 = null;
    var32.setSelectionState(var35);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test470"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
    java.awt.Shape var7 = var1.getLegendShape(100);
    var1.setSeriesVisible(1, (java.lang.Boolean)true, false);
    org.jfree.chart.labels.XYToolTipGenerator var12 = var1.getBaseToolTipGenerator();
    org.jfree.chart.labels.XYItemLabelGenerator var13 = null;
    var1.setBaseItemLabelGenerator(var13, false);
    org.jfree.data.category.CategoryDataset var19 = null;
    org.jfree.chart.axis.CategoryAxis var21 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var22 = var21.isAxisLineVisible();
    java.awt.Color var26 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var21.setTickLabelPaint((java.awt.Paint)var26);
    org.jfree.chart.axis.ValueAxis var28 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var31 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var32 = new org.jfree.chart.plot.CategoryPlot(var19, var21, var28, (org.jfree.chart.renderer.category.CategoryItemRenderer)var31);
    org.jfree.chart.plot.DrawingSupplier var33 = var32.getDrawingSupplier();
    org.jfree.chart.plot.Marker var35 = null;
    org.jfree.chart.util.Layer var36 = null;
    boolean var37 = var32.removeDomainMarker(100, var35, var36);
    var32.setDrawSharedDomainAxis(false);
    org.jfree.chart.renderer.xy.XYAreaRenderer var41 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var42 = var41.getBaseItemLabelsVisible();
    java.awt.Paint var46 = var41.getItemFillPaint((-1), (-1), true);
    var32.setRangeGridlinePaint(var46);
    org.jfree.chart.plot.IntervalMarker var48 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var46);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setSeriesOutlinePaint((-126), var46);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test471() {}
//   public void test471() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test471"); }
// 
// 
//     org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var6 = var2.getSeriesItemLabelGenerator(0);
//     var2.setShadowVisible(false);
//     org.jfree.chart.labels.ItemLabelPosition var9 = var2.getBasePositiveItemLabelPosition();
//     java.awt.Graphics2D var10 = null;
//     org.jfree.data.category.CategoryDataset var11 = null;
//     org.jfree.chart.axis.CategoryAxis var13 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var14 = var13.isAxisLineVisible();
//     java.awt.Color var18 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var13.setTickLabelPaint((java.awt.Paint)var18);
//     org.jfree.chart.axis.ValueAxis var20 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var23 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot(var11, var13, var20, (org.jfree.chart.renderer.category.CategoryItemRenderer)var23);
//     java.awt.Image var25 = null;
//     var24.setBackgroundImage(var25);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var28 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     java.awt.Color var33 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     int var34 = var33.getRGB();
//     var28.setSeriesFillPaint(0, (java.awt.Paint)var33, true);
//     java.awt.Color var37 = var33.brighter();
//     var24.setRangeZeroBaselinePaint((java.awt.Paint)var37);
//     java.lang.Comparable var39 = null;
//     var24.setDomainCrosshairRowKey(var39, false);
//     org.jfree.chart.LegendItemCollection var42 = var24.getLegendItems();
//     org.jfree.chart.util.RectangleEdge var43 = var24.getRangeAxisEdge();
//     org.jfree.chart.util.Layer var44 = null;
//     java.util.Collection var45 = var24.getRangeMarkers(var44);
//     org.jfree.chart.axis.ValueAxis var46 = null;
//     org.jfree.data.category.CategoryDataset var49 = null;
//     org.jfree.chart.axis.CategoryAxis var51 = new org.jfree.chart.axis.CategoryAxis("hi!");
//     boolean var52 = var51.isAxisLineVisible();
//     java.awt.Color var56 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
//     var51.setTickLabelPaint((java.awt.Paint)var56);
//     org.jfree.chart.axis.ValueAxis var58 = null;
//     org.jfree.chart.renderer.category.BarRenderer3D var61 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
//     org.jfree.chart.plot.CategoryPlot var62 = new org.jfree.chart.plot.CategoryPlot(var49, var51, var58, (org.jfree.chart.renderer.category.CategoryItemRenderer)var61);
//     org.jfree.chart.plot.DrawingSupplier var63 = var62.getDrawingSupplier();
//     org.jfree.chart.plot.Marker var65 = null;
//     org.jfree.chart.util.Layer var66 = null;
//     boolean var67 = var62.removeDomainMarker(100, var65, var66);
//     var62.setDrawSharedDomainAxis(false);
//     org.jfree.chart.renderer.xy.XYAreaRenderer var71 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     boolean var72 = var71.getBaseItemLabelsVisible();
//     java.awt.Paint var76 = var71.getItemFillPaint((-1), (-1), true);
//     var62.setRangeGridlinePaint(var76);
//     org.jfree.chart.plot.IntervalMarker var78 = new org.jfree.chart.plot.IntervalMarker(0.0d, (-1.0d), var76);
//     org.jfree.chart.event.MarkerChangeEvent var79 = null;
//     var78.notifyListeners(var79);
//     org.jfree.chart.util.RectangleAnchor var81 = var78.getLabelAnchor();
//     java.awt.geom.Rectangle2D var82 = null;
//     var2.drawRangeMarker(var10, var24, var46, (org.jfree.chart.plot.Marker)var78, var82);
// 
//   }

  public void test472() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test472"); }


    org.jfree.chart.JFreeChart var1 = null;
    org.jfree.chart.event.ChartProgressEvent var4 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object)100.0f, var1, 10, (-1));
    org.jfree.chart.JFreeChart var5 = var4.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test473"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    org.jfree.chart.plot.XYCrosshairState var16 = var15.getCrosshairState();
    org.jfree.data.xy.XYDataset var17 = null;
    var15.endSeriesPass(var17, (-1), 10, 0, (-165), 0);
    org.jfree.chart.entity.EntityCollection var24 = var15.getEntityCollection();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test474"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    var1.setDescription("hi!");
    boolean var4 = var1.getNotify();
    java.util.List var5 = var1.getItems();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test475"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    org.jfree.chart.axis.CategoryAxis var4 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var5 = var4.isAxisLineVisible();
    java.awt.Color var9 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var4.setTickLabelPaint((java.awt.Paint)var9);
    java.awt.Paint var11 = var4.getTickLabelPaint();
    java.lang.String var12 = var4.getLabel();
    org.jfree.chart.entity.EntityCollection var13 = null;
    org.jfree.chart.ChartRenderingInfo var14 = new org.jfree.chart.ChartRenderingInfo(var13);
    java.awt.geom.Rectangle2D var15 = var14.getChartArea();
    org.jfree.chart.entity.AxisLabelEntity var18 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var4, (java.awt.Shape)var15, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]", "");
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var20 = new org.jfree.chart.plot.CombinedDomainXYPlot(var19);
    java.lang.String var21 = var20.getNoDataMessage();
    org.jfree.chart.renderer.xy.XYAreaRenderer var23 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var24 = var23.getBaseItemLabelsVisible();
    boolean var25 = var23.getAutoPopulateSeriesStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer[] var26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { var23};
    var20.setRenderers(var26);
    org.jfree.chart.util.RectangleEdge var29 = var20.getRangeAxisEdge((-1));
    boolean var30 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var29);
    double var31 = var1.valueToJava2D(0.0d, var15, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "hi!"+ "'", var12.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0.0d);

  }

  public void test476() {}
//   public void test476() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test476"); }
// 
// 
//     java.lang.Comparable[] var1 = new java.lang.Comparable[] { '4'};
//     org.jfree.data.xy.XYDataItem var4 = new org.jfree.data.xy.XYDataItem((java.lang.Number)(-165), (java.lang.Number)(-1.0d));
//     java.lang.Comparable[] var5 = new java.lang.Comparable[] { var4};
//     double[] var6 = null;
//     double[][] var7 = new double[][] { var6};
//     org.jfree.data.category.CategoryDataset var8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var5, var7);
// 
//   }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test477"); }
// 
// 
//     java.util.Locale var1 = null;
//     org.jfree.chart.labels.StandardPieToolTipGenerator var2 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var1);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test478"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    org.jfree.chart.axis.AxisLocation var6 = var1.getRangeAxisLocation(0);
    org.jfree.chart.entity.EntityCollection var9 = null;
    org.jfree.chart.ChartRenderingInfo var10 = new org.jfree.chart.ChartRenderingInfo(var9);
    org.jfree.chart.plot.PlotRenderingInfo var11 = new org.jfree.chart.plot.PlotRenderingInfo(var10);
    java.awt.geom.Point2D var12 = null;
    var1.zoomDomainAxes(1.0d, 1.0d, var11, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test479"); }
// 
// 
//     org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
//     org.jfree.chart.labels.XYToolTipGenerator var5 = var1.getToolTipGenerator((-1), (-165), false);
//     var1.setSeriesVisible(0, (java.lang.Boolean)false);
//     java.awt.Shape var10 = var1.getSeriesShape((-1));
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.axis.ValueAxis var12 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var13 = new org.jfree.chart.plot.CombinedDomainXYPlot(var12);
//     org.jfree.chart.axis.AxisLocation var15 = var13.getDomainAxisLocation(1);
//     java.awt.Paint var16 = var13.getDomainZeroBaselinePaint();
//     org.jfree.chart.axis.ValueAxis var17 = null;
//     org.jfree.chart.plot.Marker var18 = null;
//     java.awt.geom.Rectangle2D var19 = null;
//     var1.drawRangeMarker(var11, (org.jfree.chart.plot.XYPlot)var13, var17, var18, var19);
//     org.jfree.data.time.TimeSeries var21 = null;
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.TimeSeriesCollection var23 = new org.jfree.data.time.TimeSeriesCollection(var21, var22);
//     var13.setDataset((org.jfree.data.xy.XYDataset)var23);
//     double var26 = var23.getDomainUpperBound(true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == Double.NaN);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test480"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var4 = var2.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var7 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var9 = var7.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var11 = var7.getSeriesItemLabelGenerator(0);
    var7.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var14 = var7.getBasePositiveItemLabelPosition();
    var2.setPositiveItemLabelPositionFallback(var14);
    var2.setBaseItemLabelsVisible(true, false);
    int var19 = var2.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test481"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    var1.setSeriesVisibleInLegend(0, (java.lang.Boolean)false, false);
    org.jfree.chart.labels.ItemLabelPosition var22 = null;
    var1.setSeriesNegativeItemLabelPosition(0, var22, true);
    org.jfree.chart.labels.XYItemLabelGenerator var25 = null;
    var1.setBaseItemLabelGenerator(var25, false);
    org.jfree.chart.urls.XYURLGenerator var29 = var1.getSeriesURLGenerator((-126));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test482"); }
// 
// 
//     org.jfree.chart.axis.ValueAxis var0 = null;
//     org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
//     org.jfree.chart.util.RectangleEdge var3 = var1.getRangeAxisEdge((-1));
//     org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.TimeSeriesCollection var7 = new org.jfree.data.time.TimeSeriesCollection(var5, var6);
//     int var8 = var1.indexOf((org.jfree.data.xy.XYDataset)var7);
//     double var10 = var7.getDomainUpperBound(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var7.getStartYValue(0, 10);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == Double.NaN);
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test483"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.awt.Font var16 = var1.getBaseLegendTextFont();
    java.awt.Paint var18 = var1.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var21 = var1.getLegendItem((-165), (-126));
    java.awt.Graphics2D var22 = null;
    org.jfree.chart.axis.ValueAxis var23 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var24 = new org.jfree.chart.plot.CombinedDomainXYPlot(var23);
    org.jfree.chart.renderer.xy.XYAreaRenderer var26 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var31 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var32 = var31.getRGB();
    var26.setSeriesFillPaint(0, (java.awt.Paint)var31, true);
    java.awt.Graphics2D var35 = null;
    java.awt.geom.Rectangle2D var36 = null;
    org.jfree.chart.plot.XYPlot var37 = null;
    org.jfree.data.xy.XYDataset var38 = null;
    org.jfree.chart.plot.PlotRenderingInfo var39 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var40 = var26.initialise(var35, var36, var37, var38, var39);
    java.awt.Font var41 = var26.getBaseLegendTextFont();
    int var42 = var24.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var26);
    org.jfree.chart.axis.AxisSpace var43 = var24.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var45 = var24.getRangeAxisLocation((-165));
    java.lang.Object var46 = var24.clone();
    org.jfree.chart.axis.DateAxis var48 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var48.setLowerMargin(10.0d);
    java.util.TimeZone var51 = var48.getTimeZone();
    org.jfree.chart.entity.EntityCollection var52 = null;
    org.jfree.chart.ChartRenderingInfo var53 = new org.jfree.chart.ChartRenderingInfo(var52);
    java.awt.geom.Rectangle2D var54 = var53.getChartArea();
    var1.fillRangeGridBand(var22, (org.jfree.chart.plot.XYPlot)var24, (org.jfree.chart.axis.ValueAxis)var48, var54, 0.0d, 0.0d);
    var48.setVerticalTickLabels(false);
    java.text.DateFormat var60 = var48.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var60);

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test484"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var3 = new org.jfree.chart.plot.CombinedDomainXYPlot(var2);
    org.jfree.chart.axis.AxisLocation var5 = var3.getDomainAxisLocation(1);
    boolean var6 = var1.equals((java.lang.Object)var5);
    java.lang.Object var7 = var1.clone();
    java.awt.Paint var8 = var1.getLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test485"); }


    org.jfree.chart.block.LabelBlock var1 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    java.lang.String var2 = var1.getToolTipText();
    var1.setURLText("Preceding");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test486"); }
// 
// 
//     java.awt.geom.Rectangle2D var2 = null;
//     boolean var3 = org.jfree.chart.util.ShapeUtilities.isPointInRect(1.0d, 10.0d, var2);
// 
//   }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test487"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Preceding");
    boolean var2 = var1.getAutoRangeIncludesZero();
    var1.setAutoRangeIncludesZero(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test488"); }


    org.jfree.data.time.TimeSeries var0 = null;
    java.util.TimeZone var1 = null;
    org.jfree.data.time.TimeSeriesCollection var2 = new org.jfree.data.time.TimeSeriesCollection(var0, var1);
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset)var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test489"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    java.lang.Object var16 = var1.clone();
    var1.setAutoPopulateSeriesStroke(true);
    org.jfree.chart.labels.XYToolTipGenerator var20 = var1.getSeriesToolTipGenerator(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var20);

  }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest9.test490"); }
// 
// 
//     java.text.DateFormat var3 = null;
//     java.text.DateFormat var4 = null;
//     org.jfree.chart.labels.StandardXYToolTipGenerator var5 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var3, var4);
//     org.jfree.chart.urls.StandardXYURLGenerator var7 = new org.jfree.chart.urls.StandardXYURLGenerator("");
//     org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var5, (org.jfree.chart.urls.XYURLGenerator)var7);
//     java.lang.Object var9 = var5.clone();
//     java.text.NumberFormat var10 = var5.getXFormat();
//     org.jfree.chart.labels.StandardPieSectionLabelGenerator var12 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
//     java.text.NumberFormat var13 = var12.getNumberFormat();
//     org.jfree.chart.labels.StandardPieToolTipGenerator var14 = new org.jfree.chart.labels.StandardPieToolTipGenerator("", var10, var13);
//     java.util.Currency var15 = null;
//     var10.setCurrency(var15);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test491"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    org.jfree.chart.util.RectangleEdge var32 = var13.getRangeAxisEdge();
    boolean var33 = var13.isRangeMinorGridlinesVisible();
    org.jfree.chart.util.Layer var34 = null;
    java.util.Collection var35 = var13.getRangeMarkers(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test492"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("org.jfree.chart.event.RendererChangeEvent[source=Preceding]");
    java.awt.Paint var2 = var1.getDomainGridlinePaint();
    java.awt.Paint var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setThermometerPaint(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test493"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var6 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var7 = var6.getRGB();
    var1.setSeriesFillPaint(0, (java.awt.Paint)var6, true);
    java.awt.Graphics2D var10 = null;
    java.awt.geom.Rectangle2D var11 = null;
    org.jfree.chart.plot.XYPlot var12 = null;
    org.jfree.data.xy.XYDataset var13 = null;
    org.jfree.chart.plot.PlotRenderingInfo var14 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var15 = var1.initialise(var10, var11, var12, var13, var14);
    org.jfree.chart.plot.XYCrosshairState var16 = var15.getCrosshairState();
    org.jfree.chart.plot.XYCrosshairState var17 = null;
    var15.setCrosshairState(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);

  }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test494"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    var13.setForegroundAlpha(0.0f);
    java.awt.Stroke var16 = var13.getDomainCrosshairStroke();
    java.lang.Object var17 = var13.clone();
    org.jfree.chart.util.RectangleEdge var18 = var13.getDomainAxisEdge();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test495"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var5 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var7 = var5.getSeriesItemLabelPaint(0);
    org.jfree.chart.renderer.category.BarRenderer3D var10 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    java.awt.Paint var12 = var10.getSeriesItemLabelPaint(0);
    org.jfree.chart.labels.CategoryItemLabelGenerator var14 = var10.getSeriesItemLabelGenerator(0);
    var10.setShadowVisible(false);
    org.jfree.chart.labels.ItemLabelPosition var17 = var10.getBasePositiveItemLabelPosition();
    var5.setPositiveItemLabelPositionFallback(var17);
    java.awt.Shape var20 = var5.lookupSeriesShape(10);
    java.awt.Shape var22 = var5.getSeriesShape((-165));
    org.jfree.chart.plot.CategoryPlot var23 = new org.jfree.chart.plot.CategoryPlot(var0, var1, var2, (org.jfree.chart.renderer.category.CategoryItemRenderer)var5);
    java.awt.Graphics2D var24 = null;
    org.jfree.chart.plot.CategoryPlot var25 = null;
    org.jfree.chart.renderer.xy.XYAreaRenderer var27 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var32 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var33 = var32.getRGB();
    var27.setSeriesFillPaint(0, (java.awt.Paint)var32, true);
    java.awt.Graphics2D var36 = null;
    java.awt.geom.Rectangle2D var37 = null;
    org.jfree.chart.plot.XYPlot var38 = null;
    org.jfree.data.xy.XYDataset var39 = null;
    org.jfree.chart.plot.PlotRenderingInfo var40 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var41 = var27.initialise(var36, var37, var38, var39, var40);
    java.awt.Font var42 = var27.getBaseLegendTextFont();
    java.awt.Paint var44 = var27.lookupSeriesFillPaint(100);
    org.jfree.chart.LegendItem var47 = var27.getLegendItem((-165), (-126));
    java.awt.Graphics2D var48 = null;
    org.jfree.chart.axis.ValueAxis var49 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var50 = new org.jfree.chart.plot.CombinedDomainXYPlot(var49);
    org.jfree.chart.renderer.xy.XYAreaRenderer var52 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var57 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var58 = var57.getRGB();
    var52.setSeriesFillPaint(0, (java.awt.Paint)var57, true);
    java.awt.Graphics2D var61 = null;
    java.awt.geom.Rectangle2D var62 = null;
    org.jfree.chart.plot.XYPlot var63 = null;
    org.jfree.data.xy.XYDataset var64 = null;
    org.jfree.chart.plot.PlotRenderingInfo var65 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var66 = var52.initialise(var61, var62, var63, var64, var65);
    java.awt.Font var67 = var52.getBaseLegendTextFont();
    int var68 = var50.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var52);
    org.jfree.chart.axis.AxisSpace var69 = var50.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var71 = var50.getRangeAxisLocation((-165));
    java.lang.Object var72 = var50.clone();
    org.jfree.chart.axis.DateAxis var74 = new org.jfree.chart.axis.DateAxis("#ffff5b");
    var74.setLowerMargin(10.0d);
    java.util.TimeZone var77 = var74.getTimeZone();
    org.jfree.chart.entity.EntityCollection var78 = null;
    org.jfree.chart.ChartRenderingInfo var79 = new org.jfree.chart.ChartRenderingInfo(var78);
    java.awt.geom.Rectangle2D var80 = var79.getChartArea();
    var27.fillRangeGridBand(var48, (org.jfree.chart.plot.XYPlot)var50, (org.jfree.chart.axis.ValueAxis)var74, var80, 0.0d, 0.0d);
    var74.setVerticalTickLabels(false);
    java.awt.geom.Rectangle2D var86 = null;
    var5.drawRangeGridline(var24, var25, (org.jfree.chart.axis.ValueAxis)var74, var86, 10.0d);
    java.text.DateFormat var89 = var74.getDateFormatOverride();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test496"); }


    java.text.DateFormat var1 = null;
    java.text.DateFormat var2 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("-4,-4,4,4", var1, var2);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test497"); }


    org.jfree.chart.labels.StandardPieSectionLabelGenerator var2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("");
    java.text.NumberFormat var3 = var2.getNumberFormat();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(0.0d, var3);
    java.lang.String var6 = var3.format(10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "10"+ "'", var6.equals("10"));

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test498"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("org.jfree.chart.event.RendererChangeEvent[source=Preceding]");
    java.lang.String var2 = var1.getName();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=Preceding]"+ "'", var2.equals("org.jfree.chart.event.RendererChangeEvent[source=Preceding]"));

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test499"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.labels.ItemLabelPosition var2 = var1.getNegativeItemLabelPositionFallback();
    java.awt.Stroke var4 = var1.getSeriesOutlineStroke(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest9.test500"); }


    org.jfree.chart.axis.ValueAxis var0 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var1 = new org.jfree.chart.plot.CombinedDomainXYPlot(var0);
    org.jfree.chart.axis.AxisLocation var3 = var1.getDomainAxisLocation(1);
    int var4 = var1.getRangeAxisCount();
    var1.clearAnnotations();
    var1.setRangeMinorGridlinesVisible(false);
    org.jfree.data.xy.XYDataset var8 = var1.getDataset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

}
