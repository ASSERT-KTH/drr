
import junit.framework.*;

public class RandoopTest10 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test1"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    java.awt.Shape var7 = var1.getShape();
    org.jfree.data.xy.XYDataset var8 = null;
    org.jfree.chart.entity.XYItemEntity var13 = new org.jfree.chart.entity.XYItemEntity(var7, var8, (-1), (-1), "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.lang.String var14 = var13.getURLText();
    var13.setItem(100);
    java.lang.String var17 = var13.getToolTipText();
    java.lang.Object var18 = null;
    boolean var19 = var13.equals(var18);
    var13.setSeriesIndex((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + ""+ "'", var17.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test2"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    org.jfree.chart.labels.XYItemLabelGenerator var11 = var4.getItemLabelGenerator(0, 10, true);
    var4.setBase((-1.0d));
    double var14 = var4.getMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test3"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    java.awt.Image var14 = null;
    var13.setBackgroundImage(var14);
    org.jfree.chart.renderer.xy.XYAreaRenderer var17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var22 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var23 = var22.getRGB();
    var17.setSeriesFillPaint(0, (java.awt.Paint)var22, true);
    java.awt.Color var26 = var22.brighter();
    var13.setRangeZeroBaselinePaint((java.awt.Paint)var26);
    java.lang.Comparable var28 = null;
    var13.setDomainCrosshairRowKey(var28, false);
    org.jfree.chart.LegendItemCollection var31 = var13.getLegendItems();
    java.lang.Object var32 = null;
    boolean var33 = var31.equals(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test4"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    boolean var2 = var1.isDrawBarOutline();
    var1.setDrawBarOutline(false);
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var7 = new org.jfree.chart.plot.CombinedDomainXYPlot(var6);
    org.jfree.chart.axis.AxisLocation var9 = var7.getDomainAxisLocation(1);
    int var10 = var7.getRangeAxisCount();
    var7.clearAnnotations();
    java.awt.Paint var12 = var7.getDomainZeroBaselinePaint();
    var1.setSeriesPaint(100, var12, true);
    java.awt.Paint var15 = null;
    boolean var16 = org.jfree.chart.util.PaintUtilities.equal(var12, var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test5"); }


    org.jfree.chart.axis.NumberAxis var0 = null;
    java.awt.Font var5 = null;
    org.jfree.chart.axis.MarkerAxisBand var6 = new org.jfree.chart.axis.MarkerAxisBand(var0, 0.0d, 100.0d, 10.0d, (-1.0d), var5);
    org.jfree.chart.block.LabelBlock var8 = new org.jfree.chart.block.LabelBlock("#ffff5b");
    java.lang.String var9 = var8.getToolTipText();
    boolean var10 = var6.equals((java.lang.Object)var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test6"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    java.lang.Boolean var16 = var14.getSeriesLinesVisible(0);
    org.jfree.chart.LegendItem var19 = var14.getLegendItem((-1), 100);
    var14.setBaseShapesFilled(false);
    boolean var22 = var14.getBaseShapesVisible();
    var14.setUseOutlinePaint(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test7"); }


    org.jfree.chart.LegendItem var1 = new org.jfree.chart.LegendItem("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]");
    java.awt.Color var5 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var1.setFillPaint((java.awt.Paint)var5);
    var1.setSeriesKey((java.lang.Comparable)10L);
    java.lang.String var9 = var1.getLabel();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"+ "'", var9.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=100.0]"));

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test8"); }


    org.jfree.data.Range var2 = new org.jfree.data.Range(0.0d, 10.0d);
    org.jfree.data.Range var4 = org.jfree.data.Range.expandToInclude(var2, 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test9"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getPlotLines();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test10"); }


    java.text.DateFormat var2 = null;
    java.text.DateFormat var3 = null;
    org.jfree.chart.labels.StandardXYToolTipGenerator var4 = new org.jfree.chart.labels.StandardXYToolTipGenerator("", var2, var3);
    org.jfree.chart.urls.StandardXYURLGenerator var6 = new org.jfree.chart.urls.StandardXYURLGenerator("");
    org.jfree.chart.renderer.xy.XYAreaRenderer var7 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var6);
    java.lang.Object var8 = var4.clone();
    java.text.NumberFormat var9 = var4.getXFormat();
    org.jfree.chart.urls.StandardXYURLGenerator var13 = new org.jfree.chart.urls.StandardXYURLGenerator("", "", "Preceding");
    org.jfree.chart.renderer.xy.XYStepRenderer var14 = new org.jfree.chart.renderer.xy.XYStepRenderer((org.jfree.chart.labels.XYToolTipGenerator)var4, (org.jfree.chart.urls.XYURLGenerator)var13);
    org.jfree.chart.urls.XYURLGenerator var15 = var14.getBaseURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test11"); }


    org.jfree.data.category.CategoryDataset var0 = null;
    org.jfree.chart.axis.CategoryAxis var2 = new org.jfree.chart.axis.CategoryAxis("hi!");
    boolean var3 = var2.isAxisLineVisible();
    java.awt.Color var7 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    var2.setTickLabelPaint((java.awt.Paint)var7);
    org.jfree.chart.axis.ValueAxis var9 = null;
    org.jfree.chart.renderer.category.BarRenderer3D var12 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-1.0d));
    org.jfree.chart.plot.CategoryPlot var13 = new org.jfree.chart.plot.CategoryPlot(var0, var2, var9, (org.jfree.chart.renderer.category.CategoryItemRenderer)var12);
    org.jfree.chart.axis.ValueAxis var14 = var13.getRangeAxis();
    org.jfree.chart.renderer.category.CategoryItemRenderer var15 = var13.getRenderer();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test12"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("Preceding");
    boolean var2 = var1.getAutoRangeIncludesZero();
    java.text.NumberFormat var3 = var1.getNumberFormatOverride();
    double var4 = var1.getLowerMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.05d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test13"); }


    org.jfree.chart.renderer.xy.XYBarRenderer var1 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    boolean var2 = var1.isDrawBarOutline();
    var1.setDrawBarOutline(false);
    org.jfree.chart.renderer.xy.XYBarPainter var5 = var1.getBarPainter();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test14"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)100);
    java.beans.PropertyChangeListener var2 = null;
    var1.removePropertyChangeListener(var2);
    var1.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var1.getValue(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest10.test15"); }
// 
// 
//     org.jfree.chart.block.BlockBorder var4 = new org.jfree.chart.block.BlockBorder(100.0d, (-1.0d), 100.0d, 1.0d);
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var4.draw(var5, var6);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test16"); }


    org.jfree.data.general.PieDataset var0 = null;
    org.jfree.chart.plot.RingPlot var1 = new org.jfree.chart.plot.RingPlot(var0);
    org.jfree.data.general.PieDataset var2 = null;
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D(var2);
    double var4 = var3.getMaximumExplodePercent();
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.plot.CombinedDomainXYPlot var6 = new org.jfree.chart.plot.CombinedDomainXYPlot(var5);
    org.jfree.chart.renderer.xy.XYAreaRenderer var8 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    java.awt.Color var13 = java.awt.Color.getHSBColor(0.0f, 10.0f, 10.0f);
    int var14 = var13.getRGB();
    var8.setSeriesFillPaint(0, (java.awt.Paint)var13, true);
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.XYPlot var19 = null;
    org.jfree.data.xy.XYDataset var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    org.jfree.chart.renderer.xy.XYItemRendererState var22 = var8.initialise(var17, var18, var19, var20, var21);
    java.awt.Font var23 = var8.getBaseLegendTextFont();
    int var24 = var6.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer)var8);
    org.jfree.chart.axis.AxisSpace var25 = var6.getFixedRangeAxisSpace();
    org.jfree.chart.axis.AxisLocation var27 = var6.getRangeAxisLocation((-165));
    java.awt.Stroke var28 = var6.getRangeGridlineStroke();
    var3.setLabelLinkStroke(var28);
    var1.setSeparatorStroke(var28);
    var1.setSectionDepth(100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-165));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test17"); }


    org.jfree.chart.StandardChartTheme var1 = new org.jfree.chart.StandardChartTheme("org.jfree.chart.event.RendererChangeEvent[source=Preceding]");
    java.awt.Paint var2 = var1.getDomainGridlinePaint();
    org.jfree.chart.plot.DrawingSupplier var3 = var1.getDrawingSupplier();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test18"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.axis.ValueAxis var2 = null;
    org.jfree.chart.renderer.xy.XYBarRenderer var4 = new org.jfree.chart.renderer.xy.XYBarRenderer(1.0d);
    org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot(var0, var1, var2, (org.jfree.chart.renderer.xy.XYItemRenderer)var4);
    var4.setUseYInterval(false);
    org.jfree.chart.labels.XYItemLabelGenerator var11 = var4.getItemLabelGenerator(0, 10, true);
    org.jfree.data.xy.XYDataset var12 = null;
    org.jfree.data.Range var13 = var4.findDomainBounds(var12);
    double var14 = var4.getBarAlignmentFactor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0d));

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest10.test19"); }


    org.jfree.chart.renderer.xy.XYAreaRenderer var1 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-1));
    boolean var2 = var1.getBaseItemLabelsVisible();
    boolean var3 = var1.getAutoPopulateSeriesStroke();
    org.jfree.chart.labels.ItemLabelPosition var5 = var1.getSeriesNegativeItemLabelPosition(10);
    org.jfree.chart.urls.XYURLGenerator var6 = var1.getBaseURLGenerator();
    java.awt.Stroke var8 = var1.getSeriesOutlineStroke((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

}
