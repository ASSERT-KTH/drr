
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.ChartEntity var1 = new org.jfree.chart.entity.ChartEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("hi!");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.geom.Rectangle2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    java.awt.Graphics2D var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var2 = var0.arrange(var1);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)(short)1);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }


    int var3 = java.awt.Color.HSBtoRGB(0.0f, (-1.0f), 1.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == (-2));

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    java.awt.Color var1 = null;
    java.awt.Color var2 = java.awt.Color.getColor("hi!", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.text.NumberFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(10.0d, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.geom.Rectangle2D var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setBounds(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    org.jfree.chart.labels.ItemLabelAnchor var0 = null;
    org.jfree.chart.text.TextAnchor var1 = null;
    org.jfree.chart.text.TextAnchor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.ItemLabelPosition var4 = new org.jfree.chart.labels.ItemLabelPosition(var0, var1, var2, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Point2D var1 = org.jfree.chart.util.SerialUtilities.readPoint2D(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.HorizontalAlignment var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setHorizontalAlignment(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test18() {}
//   public void test18() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(var0);
// 
//   }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(var0, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 100);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    java.awt.Shape var4 = null;
    java.awt.Paint var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var6 = new org.jfree.chart.LegendItem("", "hi!", "", "hi!", var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.LegendItemEntity var1 = new org.jfree.chart.entity.LegendItemEntity(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test23() {}
//   public void test23() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.util.RectangleAnchor var3 = null;
//     java.awt.geom.Rectangle2D var4 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, (-1.0d), 100.0d, var3);
// 
//   }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     org.jfree.chart.plot.Plot var0 = null;
//     org.jfree.chart.JFreeChart var1 = new org.jfree.chart.JFreeChart(var0);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesFillPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesLinesVisible((-2), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test26() {}
//   public void test26() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     org.jfree.chart.axis.CategoryAxis var11 = null;
//     org.jfree.chart.plot.CategoryMarker var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     var2.drawDomainMarker(var9, var10, var11, var12, var13);
// 
//   }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var0.getStartValue((java.lang.Comparable)(-2), (java.lang.Comparable)0, (-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    java.awt.Font var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextLine var2 = new org.jfree.chart.text.TextLine("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = var1.getFollowingDayOfWeek(2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getFollowingDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Graphics2D var1 = null;
//     java.awt.geom.Rectangle2D var2 = null;
//     var0.drawOutline(var1, var2);
// 
//   }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    var0.setPadding(var2);
    org.jfree.chart.util.HorizontalAlignment var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setTextAlignment(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }


    org.jfree.chart.plot.Marker var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.MarkerChangeEvent var1 = new org.jfree.chart.event.MarkerChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    boolean var2 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)10.0f, (java.lang.Object)'4');
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    java.awt.Font var1 = null;
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var2.axisChanged(var3);
    java.awt.Paint var5 = var2.getRangeZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var6 = new org.jfree.chart.text.TextFragment("hi!", var1, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    boolean var0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == false);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.awt.geom.Ellipse2D var0 = null;
    java.awt.geom.Ellipse2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    boolean var1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
    java.awt.geom.Rectangle2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var6 = var1.createInsetRectangle(var3, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    java.awt.Shape var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.entity.TickLabelEntity var3 = new org.jfree.chart.entity.TickLabelEntity(var0, "hi!", "({0}, {1}) = {3} - {4}");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getEndValue(0, (-459));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var2.axisChanged(var3);
    java.awt.Paint var5 = var2.getRangeZeroBaselinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setPaint((-459), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("({0}, {1}) = {3} - {4}", var1);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var3 = var0.containsDomainRange(1L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    java.awt.Shape var0 = null;
    org.jfree.chart.util.RectangleAnchor var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(var0, var1, 1.0d, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
//     var2.setSeriesItemLabelGenerator(2, var4);
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     org.jfree.chart.axis.ValueAxis var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     var2.drawRangeGridline(var6, var7, var8, var9, 0.0d);
// 
//   }

  public void test48() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    boolean var5 = var0.equals((java.lang.Object)(-1.0d));
    java.awt.Graphics2D var6 = null;
    java.awt.geom.Rectangle2D var7 = null;
    org.jfree.chart.plot.CategoryPlot var8 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var11 = var0.initialise(var6, var7, var8, 100, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);

  }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getSeriesCount();
    org.jfree.chart.plot.SeriesRenderingOrder var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesRenderingOrder(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    boolean var5 = var0.equals((java.lang.Object)(-1.0d));
    java.awt.Graphics2D var6 = null;
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var7);
    java.awt.geom.Rectangle2D var9 = null;
    org.jfree.chart.plot.CategoryPlot var10 = null;
    org.jfree.chart.axis.CategoryAxis var11 = null;
    org.jfree.chart.axis.ValueAxis var12 = null;
    org.jfree.data.gantt.TaskSeriesCollection var13 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var14 = null;
    boolean var15 = var13.hasListener(var14);
    int var17 = var13.getRowIndex((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var6, var8, var9, var10, var11, var12, (org.jfree.data.category.CategoryDataset)var13, (-2), 100, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == (-1));

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getSeriesKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
    java.awt.Shape var22 = var21.getLine();
    org.jfree.chart.util.GradientPaintTransformer var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.setFillPaintTransformer(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test53() {}
//   public void test53() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getLastMillisecond(var1);
// 
//   }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    var0.setDomainZeroBaselineVisible(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var8 = var0.getDomainAxisForDataset((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     java.util.List var1 = null;
//     var0.addExceptions(var1);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey(2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
//     org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
//     org.jfree.chart.axis.AxisLocation var7 = null;
//     var0.setDomainAxisLocation(2, var7, false);
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var0.drawBackground(var10, var11);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    org.jfree.chart.util.RectangleEdge var0 = null;
    org.jfree.chart.util.RectangleEdge var1 = org.jfree.chart.util.RectangleEdge.opposite(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    var0.setBackgroundPaint(var4);
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = var0.getRenderer();
    java.awt.Stroke var7 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.annotations.XYAnnotation var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var9 = var0.removeAnnotation(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.general.PieDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var1 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = var2.getFollowingDayOfWeek(2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test62() {}
//   public void test62() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     java.util.Date var2 = null;
//     long var3 = var1.getTime(var2);
// 
//   }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(2, var4);
    java.awt.Font var6 = var2.getBaseItemLabelFont();
    java.lang.Boolean var8 = var2.getSeriesVisibleInLegend(100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesShapesVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var6.axisChanged(var7);
//     java.awt.Paint var9 = var6.getRangeZeroBaselinePaint();
//     var5.setBackgroundPaint(var9);
//     var0.setDomainTickBandPaint(var9);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    java.text.AttributedString var0 = null;
    java.io.ObjectOutputStream var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeAttributedString(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test66() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove((-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var7 = null;
    var0.setDomainAxisLocation(2, var7, false);
    org.jfree.chart.block.Arrangement var10 = null;
    org.jfree.chart.block.Arrangement var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test68() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.renderer.xy.XYItemRenderer var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRenderer((-1), var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    int var4 = var0.getRowIndex((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getEndValue(10, 0, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
    var0.setBackgroundPaint(var10);
    var0.setExpandToFitSpace(false);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var16.axisChanged(var17);
    java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
    java.lang.Object var21 = var0.draw(var14, var15, (java.lang.Object)var20);
    org.jfree.chart.util.HorizontalAlignment var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setHorizontalAlignment(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var5 = var3.lookupSeriesStroke(1);
    java.awt.Paint var7 = var3.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
    var3.setBaseItemLabelPaint(var11);
    java.awt.Font var15 = var3.getItemLabelFont(100, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var23.axisChanged(var24);
    java.awt.Paint var26 = var23.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var27 = var23.getRangeAxisEdge();
    org.jfree.chart.util.HorizontalAlignment var28 = null;
    org.jfree.chart.util.VerticalAlignment var29 = null;
    org.jfree.chart.util.RectangleInsets var30 = new org.jfree.chart.util.RectangleInsets();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var31 = new org.jfree.chart.title.TextTitle("", var15, var22, var27, var28, var29, var30);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test72() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(100, (-2), (-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test73() {}
//   public void test73() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var0, 10.0d);
//     org.jfree.chart.util.Size2D var5 = null;
//     org.jfree.chart.util.Size2D var6 = var4.calculateConstrainedSize(var5);
// 
//   }

  public void test74() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.text.NumberFormat var1 = var0.getNumberFormat();
    org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var4 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var2, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var6 = var0.generateColumnLabel((org.jfree.data.category.CategoryDataset)var2, (-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.jfree.data.function.Function2D var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.xy.XYDataset var5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(var0, 8.0d, 100.0d, 1, (java.lang.Comparable)'a');
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test76() {}
//   public void test76() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }
// 
// 
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var3);
// 
//   }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     java.awt.Shape var5 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var10 = var8.lookupSeriesStroke(1);
//     java.awt.Paint var12 = var8.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var14 = var13.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
//     java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var22 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var5, var12, var14, var21);
//     java.awt.Shape var23 = var22.getLine();
//     java.awt.Paint var24 = var22.getFillPaint();
//     boolean var25 = var22.isShapeFilled();
//     java.awt.Paint var26 = var22.getLinePaint();
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var29 = null;
//     var28.axisChanged(var29);
//     java.awt.Paint var31 = var28.getRangeZeroBaselinePaint();
//     var27.setBackgroundPaint(var31);
//     org.jfree.chart.renderer.xy.XYItemRenderer var33 = var27.getRenderer();
//     java.awt.Stroke var34 = var27.getDomainZeroBaselineStroke();
//     java.awt.Shape var43 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var48 = var46.lookupSeriesStroke(1);
//     java.awt.Paint var50 = var46.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var52 = var51.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var57 = var55.lookupSeriesStroke(1);
//     java.awt.Paint var59 = var55.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var43, var50, var52, var59);
//     org.jfree.chart.block.BlockBorder var61 = new org.jfree.chart.block.BlockBorder(100.0d, (-1.0d), 10.0d, 100.0d, var50);
//     org.jfree.chart.plot.XYPlot var62 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var63 = var62.getDomainZeroBaselineStroke();
//     org.jfree.chart.plot.CategoryMarker var65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)100.0f, var26, var34, var50, var63, 0.0f);
//     
//     // Checks the contract:  equals-hashcode on var13 and var28
//     assertTrue("Contract failed: equals-hashcode on var13 and var28", var13.equals(var28) ? var13.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var51
//     assertTrue("Contract failed: equals-hashcode on var13 and var51", var13.equals(var51) ? var13.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var62
//     assertTrue("Contract failed: equals-hashcode on var13 and var62", var13.equals(var62) ? var13.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var13
//     assertTrue("Contract failed: equals-hashcode on var28 and var13", var28.equals(var13) ? var28.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var51
//     assertTrue("Contract failed: equals-hashcode on var28 and var51", var28.equals(var51) ? var28.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var62
//     assertTrue("Contract failed: equals-hashcode on var28 and var62", var28.equals(var62) ? var28.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var13
//     assertTrue("Contract failed: equals-hashcode on var51 and var13", var51.equals(var13) ? var51.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var28
//     assertTrue("Contract failed: equals-hashcode on var51 and var28", var51.equals(var28) ? var51.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var51 and var62
//     assertTrue("Contract failed: equals-hashcode on var51 and var62", var51.equals(var62) ? var51.hashCode() == var62.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var13
//     assertTrue("Contract failed: equals-hashcode on var62 and var13", var62.equals(var13) ? var62.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var28
//     assertTrue("Contract failed: equals-hashcode on var62 and var28", var62.equals(var28) ? var62.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var62 and var51
//     assertTrue("Contract failed: equals-hashcode on var62 and var51", var62.equals(var51) ? var62.hashCode() == var51.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var60
//     assertTrue("Contract failed: equals-hashcode on var22 and var60", var22.equals(var60) ? var22.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var22
//     assertTrue("Contract failed: equals-hashcode on var60 and var22", var60.equals(var22) ? var60.hashCode() == var22.hashCode() : true);
// 
//   }

  public void test78() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 100);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var0.getPercentComplete(2, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var2.setSeriesItemLabelPaint(100, var11, false);
//     java.awt.Paint var14 = var2.getBaseItemLabelPaint();
//     java.awt.Shape var20 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var25 = var23.lookupSeriesStroke(1);
//     java.awt.Paint var27 = var23.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var34 = var32.lookupSeriesStroke(1);
//     java.awt.Paint var36 = var32.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var20, var27, var29, var36);
//     java.awt.Shape var38 = var37.getLine();
//     java.awt.Paint var39 = var37.getFillPaint();
//     var2.setSeriesOutlinePaint(0, var39, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var2.", var23.equals(var2) == var2.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var32 and var2.", var32.equals(var2) == var2.equals(var32));
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Paint var2 = var0.getSectionOutlinePaint((java.lang.Comparable)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test81() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var1 = var0.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var2 = var0.getBasePositiveItemLabelPosition();
    org.jfree.chart.renderer.category.LineRenderer3D var4 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var7 = var4.getItemShapeFilled(1, (-2));
    boolean var9 = var4.equals((java.lang.Object)(-1.0d));
    var4.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var15 = var4.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var16 = var15.getTextAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesNegativeItemLabelPosition((-2), var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.labels.PieSectionLabelGenerator var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLegendLabelGenerator(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var6.setBaseCreateEntities(false);
    java.lang.Boolean var10 = null;
    var6.setSeriesVisibleInLegend(0, var10, true);
    boolean var13 = var6.getAutoPopulateSeriesStroke();
    java.awt.Shape var15 = var6.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var20 = null;
    var18.setSeriesItemLabelGenerator(2, var20);
    java.awt.Font var22 = var18.getBaseItemLabelFont();
    java.lang.Boolean var24 = var18.getSeriesVisibleInLegend(100);
    java.awt.Stroke var27 = var18.getItemStroke(15, (-1));
    org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var30 = null;
    var29.axisChanged(var30);
    java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
    var28.setBackgroundPaint(var32);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem(var0, "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var15, var27, var32);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "hi!", var3);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.jfree.chart.util.PaintList var0 = new org.jfree.chart.util.PaintList();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var2.axisChanged(var3);
    java.awt.Paint var5 = var2.getRangeZeroBaselinePaint();
    var1.setBackgroundPaint(var5);
    org.jfree.chart.renderer.xy.XYItemRenderer var7 = var1.getRenderer();
    java.awt.Stroke var8 = var1.getDomainZeroBaselineStroke();
    org.jfree.chart.event.PlotChangeListener var9 = null;
    var1.removeChangeListener(var9);
    boolean var11 = var0.equals((java.lang.Object)var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    int var9 = var2.getPassCount();
    java.lang.Boolean var11 = var2.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var12 = null;
    org.jfree.chart.plot.PlotRenderingInfo var13 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var14 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var13);
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.CategoryPlot var16 = null;
    org.jfree.chart.axis.CategoryAxis var17 = null;
    org.jfree.chart.axis.ValueAxis var18 = null;
    org.jfree.data.gantt.TaskSeriesCollection var19 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var21 = var19.getSeries((java.lang.Comparable)"hi!");
    var2.drawItem(var12, var14, var15, var16, var17, var18, (org.jfree.data.category.CategoryDataset)var19, (-2), (-459), 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var27 = var19.getColumnKey(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);

  }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var0);
// 
//   }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var8 = null;
    var7.axisChanged(var8);
    java.awt.Paint var10 = var7.getRangeZeroBaselinePaint();
    var2.setBaseItemLabelPaint(var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesVisibleInLegend((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var2.setSeriesItemLabelPaint(100, var11, false);
//     java.awt.Paint var14 = var2.getBaseItemLabelPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var20 = null;
//     var18.setSeriesItemLabelGenerator(2, var20);
//     java.awt.Font var22 = var18.getBaseItemLabelFont();
//     java.lang.Boolean var24 = var18.getSeriesVisibleInLegend(100);
//     java.awt.Stroke var27 = var18.getItemStroke(15, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var32 = var30.lookupSeriesStroke(1);
//     boolean var33 = var30.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var34 = var30.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var37.setBaseCreateEntities(false);
//     java.lang.Boolean var41 = null;
//     var37.setSeriesVisibleInLegend(0, var41, true);
//     boolean var44 = var37.getAutoPopulateSeriesStroke();
//     java.awt.Shape var46 = var37.lookupSeriesShape((-2));
//     boolean var48 = var37.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var49 = var37.getBasePositiveItemLabelPosition();
//     var30.setBasePositiveItemLabelPosition(var49, false);
//     var18.setBasePositiveItemLabelPosition(var49);
//     var2.setSeriesNegativeItemLabelPosition(1, var49);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var30 and var2.", var30.equals(var2) == var2.equals(var30));
// 
//   }

  public void test90() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var2 = var0.getSeries((java.lang.Comparable)"hi!");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getPercentComplete(0, 100, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    var0.setBackgroundPaint(var4);
    java.io.ObjectOutputStream var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var10 = var7.getItemShapeFilled(1, (-2));
//     boolean var12 = var7.equals((java.lang.Object)(-1.0d));
//     var7.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var7.getNegativeItemLabelPosition((-2), (-459));
//     org.jfree.chart.text.TextAnchor var19 = var18.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var21 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var5, var6, var19, 100.0d);
//     org.jfree.chart.renderer.category.LineRenderer3D var23 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var26 = var23.getItemShapeFilled(1, (-2));
//     boolean var28 = var23.equals((java.lang.Object)(-1.0d));
//     var23.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.labels.ItemLabelPosition var34 = var23.getNegativeItemLabelPosition((-2), (-459));
//     org.jfree.chart.text.TextAnchor var35 = var34.getTextAnchor();
//     org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", var1, 1.0f, 1.0f, var19, 1.0d, var35);
// 
//   }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    java.lang.Comparable var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getStartValue(var4, (java.lang.Comparable)1.0d, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     java.awt.Color var0 = null;
//     java.lang.String var1 = org.jfree.chart.util.PaintUtilities.colorToString(var0);
// 
//   }

  public void test95() {}
//   public void test95() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     boolean var5 = var2.getBaseSeriesVisibleInLegend();
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var2.drawBackground(var6, var7, var8);
// 
//   }

  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setCircular(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);

  }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var1 = org.jfree.chart.util.SerialUtilities.readPaint(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test99() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    int var4 = var0.getRowIndex((java.lang.Comparable)0L);
    java.util.List var5 = var0.getRowKeys();
    org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var7 = var6.getBaseTimeline();
    java.util.Date var9 = var7.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var11 = var10.getBaseTimeline();
    java.util.Date var13 = var11.getDate(10L);
    var7.addException(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var17 = var0.getEndValue((java.lang.Comparable)var13, (java.lang.Comparable)(-459), 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("", var1);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var7 = null;
//     var6.axisChanged(var7);
//     java.awt.Paint var9 = var6.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.Layer var11 = null;
//     java.util.Collection var12 = var6.getDomainMarkers((-459), var11);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var6.drawBackgroundImage(var13, var14);
//     var0.setParent((org.jfree.chart.plot.Plot)var6);
//     
//     // Checks the contract:  equals-hashcode on var1 and var6
//     assertTrue("Contract failed: equals-hashcode on var1 and var6", var1.equals(var6) ? var1.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var1
//     assertTrue("Contract failed: equals-hashcode on var6 and var1", var6.equals(var1) ? var6.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.FontMetrics var2 = null;
//     java.awt.geom.Rectangle2D var3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", var1, var2);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.util.ResourceBundle.Control var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", var1);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    java.awt.Paint var1 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var6 = var4.lookupSeriesStroke(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.ValueMarker var7 = new org.jfree.chart.plot.ValueMarker(100.0d, var1, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     var1.addAll(var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var2
//     assertTrue("Contract failed: equals-hashcode on var0 and var2", var0.equals(var2) ? var0.hashCode() == var2.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var2 and var0
//     assertTrue("Contract failed: equals-hashcode on var2 and var0", var2.equals(var0) ? var2.hashCode() == var0.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.lang.Number var1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.time.Month var2 = new org.jfree.data.time.Month();
    org.jfree.data.time.SpreadsheetDate var4 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var7 = var4.isBefore(var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getPercentComplete((java.lang.Comparable)var2, (java.lang.Comparable)var6, 15);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test109() {}
//   public void test109() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var3 = var0.getItemShapeFilled(1, (-2));
//     boolean var5 = var0.equals((java.lang.Object)(-1.0d));
//     var0.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getURLGenerator((-459), 100);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var0.drawOutline(var12, var13, var14);
// 
//   }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateAxis var2 = new org.jfree.chart.axis.DateAxis("", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers((-459), var5);
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
    java.awt.geom.Point2D var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantOrigin(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     java.awt.geom.Rectangle2D var3 = null;
//     var1.trim(var3);
// 
//   }

  public void test113() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Object var5 = var2.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     java.util.Date var3 = var1.getDate(10L);
//     java.util.TimeZone var4 = null;
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year(var3, var4);
// 
//   }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var6.setBaseCreateEntities(false);
    java.lang.Boolean var10 = null;
    var6.setSeriesVisibleInLegend(0, var10, true);
    boolean var13 = var6.getAutoPopulateSeriesStroke();
    java.awt.Shape var15 = var6.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var23 = new org.jfree.chart.title.LegendGraphic(var15, var22);
    org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var25 = null;
    var24.axisChanged(var25);
    org.jfree.chart.renderer.xy.XYItemRenderer var28 = var24.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var29 = null;
    org.jfree.chart.axis.ValueAxis[] var30 = new org.jfree.chart.axis.ValueAxis[] { var29};
    var24.setDomainAxes(var30);
    org.jfree.chart.title.TextTitle var32 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var33 = var32.getPadding();
    org.jfree.chart.event.TitleChangeListener var34 = null;
    var32.addChangeListener(var34);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var40 = var38.lookupSeriesStroke(1);
    java.awt.Paint var42 = var38.lookupSeriesOutlinePaint(10);
    var32.setBackgroundPaint(var42);
    var24.setBackgroundPaint(var42);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var15, var42);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    var0.setLeft(10.0d);

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    org.jfree.chart.axis.AxisLocation var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(0, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    boolean var5 = var0.equals((java.lang.Object)(-1.0d));
    var0.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getURLGenerator((-459), 100);
    org.jfree.chart.renderer.category.LineRenderer3D var13 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var16 = var13.getItemShapeFilled(1, (-2));
    boolean var18 = var13.equals((java.lang.Object)(-1.0d));
    var13.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var24 = var13.getNegativeItemLabelPosition((-2), (-459));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesPositiveItemLabelPosition((-2), var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var2 = var0.equals((java.lang.Object)(-1));
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     double var4 = var3.getShadowXOffset();
//     var3.setDepthFactor(1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 100);
//     var3.setDataset(var9);
//     org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
//     var0.addChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
//     
//     // Checks the contract:  equals-hashcode on var0 and var7
//     assertTrue("Contract failed: equals-hashcode on var0 and var7", var0.equals(var7) ? var0.hashCode() == var7.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var7 and var0
//     assertTrue("Contract failed: equals-hashcode on var7 and var0", var7.equals(var0) ? var7.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.StandardCategoryToolTipGenerator var2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator("hi!", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDiamond(100.0f);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     java.lang.Number[] var0 = null;
//     java.lang.Number[][] var1 = new java.lang.Number[][] { var0};
//     java.lang.Number[] var2 = null;
//     java.lang.Number[][] var3 = new java.lang.Number[][] { var2};
//     org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     java.util.Date var2 = null;
//     long var3 = var0.getTime(var2);
// 
//   }

  public void test124() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    org.jfree.chart.axis.CategoryLabelPositions var0 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.axis.CategoryLabelPosition var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPositions var2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test126() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek(1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getNearestDayOfWeek(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test127() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    int var4 = var0.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
    org.jfree.data.general.SeriesChangeEvent var7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
    var0.seriesChanged(var7);
    int var9 = var0.getRowCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var12 = var0.getStartValue(10, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    boolean var5 = var0.equals((java.lang.Object)(-1.0d));
    var0.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var11 = var0.getNegativeItemLabelPosition((-2), (-459));
    boolean var13 = var11.equals((java.lang.Object)"({0}, {1}) = {3} - {4}");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers((-459), var5);
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var0.drawBackgroundImage(var7, var8);
//     int var10 = var0.getDatasetCount();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var15 = var13.lookupSeriesStroke(1);
//     java.awt.Paint var17 = var13.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var19.axisChanged(var20);
//     java.awt.Paint var22 = var19.getRangeZeroBaselinePaint();
//     var13.setSeriesItemLabelPaint(100, var22, false);
//     var0.setRangeTickBandPaint(var22);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.lang.Comparable[] var1 = new java.lang.Comparable[] { 1.0E-5d};
    java.lang.Comparable[] var2 = null;
    double[] var3 = null;
    double[][] var4 = new double[][] { var3};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.CategoryDataset var5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(var1, var2, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    java.awt.Shape var0 = null;
    java.awt.Shape var4 = org.jfree.chart.util.ShapeUtilities.rotateShape(var0, 12.0d, 10.0f, (-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(61200000L, 0L);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test133() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.jfree.data.category.CategoryDataset var0 = null;
//     org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(var0, 15);
// 
//   }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var7 = var2.getItemCreateEntity(10, (-1));
    var2.setDrawOutlines(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     boolean var5 = var2.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var6 = var2.clone();
//     boolean var7 = var2.getBaseItemLabelsVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var11.setBaseCreateEntities(false);
//     java.lang.Boolean var15 = null;
//     var11.setSeriesVisibleInLegend(0, var15, true);
//     boolean var18 = var11.getAutoPopulateSeriesStroke();
//     java.awt.Shape var20 = var11.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var25 = var23.lookupSeriesStroke(1);
//     java.awt.Paint var27 = var23.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var28 = new org.jfree.chart.title.LegendGraphic(var20, var27);
//     java.awt.Shape var33 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
//     java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var42 = var41.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
//     java.awt.Paint var49 = var45.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var33, var40, var42, var49);
//     java.awt.Shape var51 = var50.getLine();
//     org.jfree.chart.entity.ChartEntity var54 = new org.jfree.chart.entity.ChartEntity(var51, "hi!", "hi!");
//     var28.setLine(var51);
//     java.awt.Paint var56 = var28.getFillPaint();
//     var2.setSeriesPaint(1, var56, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var23 and var2.", var23.equals(var2) == var2.equals(var23));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var36 and var2.", var36.equals(var2) == var2.equals(var36));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var45 and var2.", var45.equals(var2) == var2.equals(var45));
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleEdge.TOP", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, 0.05d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     java.lang.Class var42 = null;
//     java.util.EventListener[] var43 = var41.getListeners(var42);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
    int var6 = var0.getBackgroundImageAlignment();
    java.awt.geom.Point2D var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantOrigin(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 15);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    org.jfree.chart.util.RectangleAnchor var20 = var19.getShapeAnchor();
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var24 = new org.jfree.chart.axis.CategoryLabelPosition(var20, var21, var22, 10.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    org.jfree.chart.text.TextBlock var3 = null;
    org.jfree.chart.text.TextBlockAnchor var4 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var5 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var8 = var5.getItemShapeFilled(1, (-2));
    boolean var10 = var5.equals((java.lang.Object)(-1.0d));
    var5.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var16 = var5.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var17 = var16.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var19 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var3, var4, var17, 100.0d);
    org.jfree.chart.text.TextAnchor var20 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.NumberTick var22 = new org.jfree.chart.axis.NumberTick((java.lang.Number)172800000L, "hi!", var17, var20, 0.2d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(var0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesFillPaint();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var9.setBaseCreateEntities(false);
    java.lang.Boolean var13 = null;
    var9.setSeriesVisibleInLegend(0, var13, true);
    boolean var16 = var9.getAutoPopulateSeriesStroke();
    java.awt.Shape var18 = var9.lookupSeriesShape((-2));
    boolean var20 = var9.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var21 = var9.getBasePositiveItemLabelPosition();
    var2.setBasePositiveItemLabelPosition(var21, false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var33 = null;
    var32.axisChanged(var33);
    java.awt.Paint var35 = var32.getRangeZeroBaselinePaint();
    var27.setBaseItemLabelPaint(var35);
    java.awt.Font var39 = var27.getItemLabelFont(100, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelFont((-459), var39, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    boolean var3 = var2.getUseOutlinePaint();
    java.awt.Stroke var5 = var2.getSeriesOutlineStroke(1);
    org.jfree.chart.block.Arrangement var6 = null;
    org.jfree.chart.block.Arrangement var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.LegendTitle var8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var2, var6, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
    var2.setSeriesItemLabelPaint(100, var11, false);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var15 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var2.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var15, true);
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesToolTipGenerator((-2), var19, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     var2.setAutoPopulateSeriesOutlineStroke(true);
//     var2.setUseOutlinePaint(true);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.plot.CategoryPlot var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     var2.drawBackground(var13, var14, var15);
// 
//   }

  public void test148() {}
//   public void test148() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     var1.addBaseTimelineException(1L);
// 
//   }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
//     var6.setSeriesItemLabelGenerator(2, var8);
//     java.awt.Font var10 = var6.getBaseItemLabelFont();
//     java.lang.Boolean var12 = var6.getSeriesVisibleInLegend(100);
//     java.awt.Stroke var15 = var6.getItemStroke(15, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
//     boolean var21 = var18.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var22 = var18.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var25.setBaseCreateEntities(false);
//     java.lang.Boolean var29 = null;
//     var25.setSeriesVisibleInLegend(0, var29, true);
//     boolean var32 = var25.getAutoPopulateSeriesStroke();
//     java.awt.Shape var34 = var25.lookupSeriesShape((-2));
//     boolean var36 = var25.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var37 = var25.getBasePositiveItemLabelPosition();
//     var18.setBasePositiveItemLabelPosition(var37, false);
//     var6.setBasePositiveItemLabelPosition(var37);
//     var2.setSeriesPositiveItemLabelPosition(15, var37);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var2.", var6.equals(var2) == var2.equals(var6));
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var3 = var0.getItemShapeFilled(1, (-2));
//     boolean var5 = var0.equals((java.lang.Object)(-1.0d));
//     var0.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.urls.CategoryURLGenerator var11 = var0.getURLGenerator((-459), 100);
//     java.awt.Graphics2D var12 = null;
//     org.jfree.chart.plot.CategoryPlot var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     var0.drawBackground(var12, var13, var14);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     java.awt.geom.Rectangle2D var2 = null;
//     var1.trim(var2);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     java.awt.Graphics2D var0 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var3.setBaseCreateEntities(false);
//     java.lang.Boolean var7 = null;
//     var3.setSeriesVisibleInLegend(0, var7, true);
//     boolean var10 = var3.getAutoPopulateSeriesStroke();
//     java.awt.Shape var12 = var3.lookupSeriesShape((-2));
//     org.jfree.chart.util.ShapeUtilities.drawRotatedShape(var0, var12, 0.0d, 1.0f, (-1.0f));
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var42);
    java.lang.String var48 = var47.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var48 + "' != '" + "ChartEntity: tooltip = null"+ "'", var48.equals("ChartEntity: tooltip = null"));

  }

  public void test154() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    var0.setDomainZeroBaselineVisible(false);
    org.jfree.chart.annotations.XYAnnotation var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    double var4 = var3.getShadowXOffset();
    var3.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 100);
    var3.setDataset(var9);
    org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
    org.jfree.chart.plot.Plot var12 = var11.getPlot();
    var0.notifyListeners(var11);
    org.jfree.chart.renderer.category.LineRenderer3D var15 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var18 = var15.getItemShapeFilled(1, (-2));
    java.awt.Shape var23 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var28 = var26.lookupSeriesStroke(1);
    java.awt.Paint var30 = var26.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var32 = var31.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var37 = var35.lookupSeriesStroke(1);
    java.awt.Paint var39 = var35.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var40 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var23, var30, var32, var39);
    var15.setBaseFillPaint(var39, false);
    org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var44 = null;
    var43.axisChanged(var44);
    java.awt.Paint var46 = var43.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var47 = null;
    var43.notifyListeners(var47);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var53 = var51.lookupSeriesStroke(1);
    var43.setDomainCrosshairStroke(var53);
    org.jfree.chart.plot.ValueMarker var55 = new org.jfree.chart.plot.ValueMarker((-3.0d), var39, var53);
    org.jfree.chart.util.Layer var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var55, var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.AxisLocation var1 = org.jfree.chart.axis.AxisLocation.getOpposite(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(15, var1);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-1.0d));
    int var7 = var0.indexOf((java.lang.Comparable)61200000L);
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var0.getEndValue(var8, (java.lang.Comparable)"ChartEntity: tooltip = null");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == (-1));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.awt.geom.GeneralPath var0 = null;
    java.awt.geom.GeneralPath var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    java.text.DateFormat var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.labels.IntervalCategoryToolTipGenerator var2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("ThreadContext", var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var6 = var4.lookupSeriesStroke(1);
//     java.awt.Paint var8 = var4.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var9.axisChanged(var10);
//     java.awt.Paint var12 = var9.getRangeZeroBaselinePaint();
//     var4.setBaseItemLabelPaint(var12);
//     java.awt.Font var16 = var4.getItemLabelFont(100, 0);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
//     java.awt.Paint var23 = var19.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.text.TextLine var24 = new org.jfree.chart.text.TextLine("hi!", var16, var23);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var27 = null;
//     var26.axisChanged(var27);
//     java.awt.Paint var29 = var26.getRangeZeroBaselinePaint();
//     var25.setBackgroundPaint(var29);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = var25.getRenderer();
//     java.awt.Stroke var32 = var25.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var25.removeChangeListener(var33);
//     java.awt.Paint var35 = var25.getRangeCrosshairPaint();
//     org.jfree.chart.text.TextMeasurer var38 = null;
//     org.jfree.chart.text.TextBlock var39 = org.jfree.chart.text.TextUtilities.createTextBlock("({0}, {1}) = {3} - {4}", var16, var35, 1.0f, (-459), var38);
// 
//   }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getSeriesCount();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var0.drawBackgroundImage(var2, var3);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var0.zoomRangeAxes((-1.0d), var6, var7);
    org.jfree.chart.axis.AxisLocation var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation((-459), var10, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test164() {}
//   public void test164() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var6 = var5.getDomainZeroBaselineStroke();
//     org.jfree.chart.axis.CategoryLabelPositions var7 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var9.axisChanged(var10);
//     java.awt.Paint var12 = var9.getRangeZeroBaselinePaint();
//     var8.setBackgroundPaint(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var8.getRenderer();
//     java.awt.Stroke var15 = var8.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var16 = null;
//     var8.removeChangeListener(var16);
//     java.awt.Paint var18 = var8.getRangeCrosshairPaint();
//     boolean var19 = var7.equals((java.lang.Object)var18);
//     org.jfree.chart.LegendItem var20 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "", "hi!", "hi!", var4, var6, var18);
//     
//     // Checks the contract:  equals-hashcode on var5 and var9
//     assertTrue("Contract failed: equals-hashcode on var5 and var9", var5.equals(var9) ? var5.hashCode() == var9.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var9 and var5
//     assertTrue("Contract failed: equals-hashcode on var9 and var5", var9.equals(var5) ? var9.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    java.awt.Shape var10 = var6.lookupSeriesShape((-459));
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var12 = null;
    var11.axisChanged(var12);
    java.awt.Paint var14 = var11.getRangeZeroBaselinePaint();
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    double var16 = var15.getShadowXOffset();
    var15.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    var15.setLabelLinkStroke(var23);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var27.setBaseCreateEntities(false);
    java.lang.Boolean var31 = null;
    var27.setSeriesVisibleInLegend(0, var31, true);
    boolean var34 = var27.getAutoPopulateSeriesStroke();
    java.awt.Shape var36 = var27.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var41 = var39.lookupSeriesStroke(1);
    java.awt.Paint var43 = var39.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var44 = new org.jfree.chart.title.LegendGraphic(var36, var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var45 = new org.jfree.chart.LegendItem(var0, "ChartEntity: tooltip = null", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "", var10, var14, var23, var43);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
    var0.setBackgroundPaint(var10);
    org.jfree.chart.util.HorizontalAlignment var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setHorizontalAlignment(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test167() {}
//   public void test167() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     var0.setDomainZeroBaselineVisible(false);
//     org.jfree.chart.renderer.category.LineRenderer3D var8 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var11 = var8.getItemShapeFilled(1, (-2));
//     java.awt.Shape var16 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
//     java.awt.Paint var23 = var19.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var25 = var24.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var30 = var28.lookupSeriesStroke(1);
//     java.awt.Paint var32 = var28.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var16, var23, var25, var32);
//     var8.setBaseFillPaint(var32, false);
//     var0.setRangeTickBandPaint(var32);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     java.lang.Class var0 = null;
//     boolean var1 = org.jfree.chart.util.SerialUtilities.isSerializable(var0);
// 
//   }

  public void test169() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.DateTickUnit var2 = new org.jfree.chart.axis.DateTickUnit(10, 5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test170() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var7 = null;
    boolean var8 = var6.hasListener(var7);
    int var10 = var6.getRowIndex((java.lang.Comparable)0L);
    java.util.List var11 = var6.getRowKeys();
    boolean var12 = var0.equals((java.lang.Object)var6);
    java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var16 = var6.getStartValue(2, (-2));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(var0);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(2, var4);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    java.awt.Font var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setBaseItemLabelFont(var9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.awt.Shape var1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    var0.removeAll();
    org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesFillPaint();
    java.lang.Object var6 = var2.clone();
    int var7 = var2.getRowCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var4 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var7 = var4.getItemShapeFilled(1, (-2));
//     boolean var9 = var4.equals((java.lang.Object)(-1.0d));
//     var4.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.labels.ItemLabelPosition var15 = var4.getNegativeItemLabelPosition((-2), (-459));
//     org.jfree.chart.text.TextAnchor var16 = var15.getTextAnchor();
//     java.awt.geom.Rectangle2D var17 = org.jfree.chart.text.TextUtilities.drawAlignedString("", var1, (-1.0f), 0.0f, var16);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
    var0.setBackgroundPaint(var10);
    var0.setExpandToFitSpace(false);
    java.awt.Graphics2D var14 = null;
    java.awt.geom.Rectangle2D var15 = null;
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var16.axisChanged(var17);
    java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
    java.lang.Object var21 = var0.draw(var14, var15, (java.lang.Object)var20);
    java.awt.Font var22 = var0.getFont();
    java.awt.Graphics2D var23 = null;
    org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var26, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var29 = var0.arrange(var23, var28);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.time.DateRange var3 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range)var3);
//     org.jfree.chart.util.Size2D var5 = null;
//     org.jfree.chart.util.Size2D var6 = var4.calculateConstrainedSize(var5);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    int var1 = var0.getSeriesCount();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    var0.drawBackgroundImage(var2, var3);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var2.setSeriesItemLabelPaint(100, var11, false);
//     java.awt.Graphics2D var14 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var17.setBaseCreateEntities(false);
//     java.lang.Boolean var21 = null;
//     var17.setSeriesVisibleInLegend(0, var21, true);
//     int var24 = var17.getPassCount();
//     java.lang.Boolean var26 = var17.getSeriesVisibleInLegend((-1));
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var28 = null;
//     org.jfree.chart.renderer.category.CategoryItemRendererState var29 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var28);
//     java.awt.geom.Rectangle2D var30 = null;
//     org.jfree.chart.plot.CategoryPlot var31 = null;
//     org.jfree.chart.axis.CategoryAxis var32 = null;
//     org.jfree.chart.axis.ValueAxis var33 = null;
//     org.jfree.data.gantt.TaskSeriesCollection var34 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.gantt.TaskSeries var36 = var34.getSeries((java.lang.Comparable)"hi!");
//     var17.drawItem(var27, var29, var30, var31, var32, var33, (org.jfree.data.category.CategoryDataset)var34, (-2), (-459), 10);
//     java.awt.geom.Rectangle2D var41 = null;
//     org.jfree.chart.plot.CategoryPlot var42 = null;
//     org.jfree.chart.axis.CategoryAxis var43 = null;
//     org.jfree.chart.axis.ValueAxis var44 = null;
//     org.jfree.data.gantt.TaskSeriesCollection var45 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var46 = null;
//     boolean var47 = var45.hasListener(var46);
//     org.jfree.data.Range var48 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var45);
//     org.jfree.data.gantt.TaskSeries var50 = new org.jfree.data.gantt.TaskSeries("hi!");
//     var45.remove(var50);
//     var45.removeAll();
//     var2.drawItem(var14, var29, var41, var42, var43, var44, (org.jfree.data.category.CategoryDataset)var45, 0, 0, 100);
//     
//     // Checks the contract:  equals-hashcode on var34 and var45
//     assertTrue("Contract failed: equals-hashcode on var34 and var45", var34.equals(var45) ? var34.hashCode() == var45.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var34
//     assertTrue("Contract failed: equals-hashcode on var45 and var34", var45.equals(var34) ? var45.hashCode() == var34.hashCode() : true);
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     java.awt.Paint var7 = var0.getRangeGridlinePaint();
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     java.awt.geom.Point2D var10 = null;
//     org.jfree.chart.plot.PlotState var11 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var12 = null;
//     var0.draw(var8, var9, var10, var11, var12);
// 
//   }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var6 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.text.NumberFormat var7 = var6.getNumberFormat();
    java.text.NumberFormat var8 = var6.getNumberFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesToolTipGenerator((-1), (org.jfree.chart.labels.CategoryToolTipGenerator)var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
    org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var4 = var1.equals((java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var3.getStartValue((java.lang.Comparable)(-2), (java.lang.Comparable)(-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     java.util.Locale var1 = null;
//     java.util.ResourceBundle var2 = java.util.ResourceBundle.getBundle("ThreadContext", var1);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     boolean var3 = var1.containsDomainValue((-1L));
//     var1.addBaseTimelineExclusions(24180L, 0L);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     boolean var9 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Shape var11 = var2.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
//     java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
//     java.awt.Shape var24 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
//     java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
//     java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
//     java.awt.Shape var42 = var41.getLine();
//     org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
//     var19.setLine(var42);
//     java.awt.Paint var47 = var19.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var52 = var49.isBefore(var51);
//     boolean var53 = var19.equals((java.lang.Object)var52);
//     double var54 = var19.getHeight();
//     java.awt.Graphics2D var55 = null;
//     java.awt.geom.Rectangle2D var56 = null;
//     var19.draw(var55, var56);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     var41.setAlpha(1.0f);
//     org.jfree.chart.renderer.category.LineRenderer3D var45 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var48 = var45.getItemShapeFilled(1, (-2));
//     java.awt.Shape var53 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var58 = var56.lookupSeriesStroke(1);
//     java.awt.Paint var60 = var56.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var62 = var61.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var67 = var65.lookupSeriesStroke(1);
//     java.awt.Paint var69 = var65.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var53, var60, var62, var69);
//     var45.setBaseFillPaint(var69, false);
//     org.jfree.chart.plot.XYPlot var73 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var74 = null;
//     var73.axisChanged(var74);
//     java.awt.Paint var76 = var73.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var77 = null;
//     var73.notifyListeners(var77);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var81 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var83 = var81.lookupSeriesStroke(1);
//     var73.setDomainCrosshairStroke(var83);
//     org.jfree.chart.plot.ValueMarker var85 = new org.jfree.chart.plot.ValueMarker((-3.0d), var69, var83);
//     var85.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var88 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var85);
//     var41.notifyListeners(var88);
//     
//     // Checks the contract:  equals-hashcode on var17 and var61
//     assertTrue("Contract failed: equals-hashcode on var17 and var61", var17.equals(var61) ? var17.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var29 and var73
//     assertTrue("Contract failed: equals-hashcode on var29 and var73", var29.equals(var73) ? var29.hashCode() == var73.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var17
//     assertTrue("Contract failed: equals-hashcode on var61 and var17", var61.equals(var17) ? var61.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var73 and var29
//     assertTrue("Contract failed: equals-hashcode on var73 and var29", var73.equals(var29) ? var73.hashCode() == var29.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var70
//     assertTrue("Contract failed: equals-hashcode on var26 and var70", var26.equals(var70) ? var26.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var26
//     assertTrue("Contract failed: equals-hashcode on var70 and var26", var70.equals(var26) ? var70.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var85
//     assertTrue("Contract failed: equals-hashcode on var41 and var85", var41.equals(var85) ? var41.hashCode() == var85.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var85 and var41
//     assertTrue("Contract failed: equals-hashcode on var85 and var41", var85.equals(var41) ? var85.hashCode() == var41.hashCode() : true);
// 
//   }

  public void test189() {}
//   public void test189() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var7.setBackgroundPaint(var11);
//     org.jfree.chart.renderer.xy.XYItemRenderer var13 = var7.getRenderer();
//     java.awt.Stroke var14 = var7.getDomainZeroBaselineStroke();
//     var0.setDomainGridlineStroke(var14);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.event.TitleChangeListener var2 = null;
//     var0.addChangeListener(var2);
//     double var4 = var0.getWidth();
//     java.awt.Graphics2D var5 = null;
//     java.awt.geom.Rectangle2D var6 = null;
//     var0.draw(var5, var6);
//     java.lang.Object var8 = var0.clone();
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
//     var0.setMargin(var10);
//     java.awt.geom.Rectangle2D var12 = null;
//     var10.trim(var12);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
//     java.lang.String var1 = var0.getPlotType();
//     org.jfree.chart.LegendItemCollection var2 = var0.getLegendItems();
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var5 = var2.isBefore(var4);
//     int var6 = var2.getYYYY();
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(15, (org.jfree.data.time.SerialDate)var2);
//     org.jfree.data.time.SerialDate var8 = null;
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var12 = var10.getFollowingDayOfWeek(2);
//     boolean var13 = var2.isInRange(var8, var10);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var8 = null;
//     var7.axisChanged(var8);
//     java.awt.Paint var10 = var7.getRangeZeroBaselinePaint();
//     var2.setBaseItemLabelPaint(var10);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
//     java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var21.axisChanged(var22);
//     java.awt.Paint var24 = var21.getRangeZeroBaselinePaint();
//     var15.setSeriesItemLabelPaint(100, var24, false);
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var28 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     var15.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var28, true);
//     org.jfree.chart.urls.StandardCategoryURLGenerator var31 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var36 = var34.lookupSeriesStroke(1);
//     boolean var37 = var34.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var38 = var34.clone();
//     boolean var39 = var34.getBaseItemLabelsVisible();
//     boolean var40 = var31.equals((java.lang.Object)var39);
//     var15.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var31, false);
//     var2.setSeriesURLGenerator(10, (org.jfree.chart.urls.CategoryURLGenerator)var31, false);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var34 and var2.", var34.equals(var2) == var2.equals(var34));
//     
//     // Checks the contract:  equals-hashcode on var7 and var21
//     assertTrue("Contract failed: equals-hashcode on var7 and var21", var7.equals(var21) ? var7.hashCode() == var21.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var7
//     assertTrue("Contract failed: equals-hashcode on var21 and var7", var21.equals(var7) ? var21.hashCode() == var7.hashCode() : true);
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var14 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var15 = null;
//     var14.axisChanged(var15);
//     java.awt.Paint var17 = var14.getRangeZeroBaselinePaint();
//     var13.setBackgroundPaint(var17);
//     org.jfree.chart.renderer.xy.XYItemRenderer var19 = var13.getRenderer();
//     java.awt.Stroke var20 = var13.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var21 = null;
//     var13.removeChangeListener(var21);
//     java.awt.Paint var23 = var13.getRangeCrosshairPaint();
//     var12.setBackgroundPaint(var23);
//     
//     // Checks the contract:  equals-hashcode on var1 and var14
//     assertTrue("Contract failed: equals-hashcode on var1 and var14", var1.equals(var14) ? var1.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var1
//     assertTrue("Contract failed: equals-hashcode on var14 and var1", var14.equals(var1) ? var14.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getMinimumArcAngleToDraw();
    org.jfree.chart.plot.AbstractPieLabelDistributor var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelDistributor(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0E-5d);

  }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    double[] var0 = null;
    double[][] var1 = new double[][] { var0};
    double[] var2 = null;
    double[][] var3 = new double[][] { var2};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.category.DefaultIntervalCategoryDataset var4 = new org.jfree.data.category.DefaultIntervalCategoryDataset(var1, var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("ChartEntity: tooltip = null", 15);
//     java.awt.color.ColorSpace var3 = null;
//     float[] var7 = new float[] { 1.0f, 0.0f, 0.0f};
//     float[] var8 = var2.getComponents(var3, var7);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.jfree.chart.plot.PiePlot var0 = new org.jfree.chart.plot.PiePlot();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Paint var2 = var0.getSectionPaint(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     org.jfree.chart.renderer.category.LineRenderer3D var6 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var9 = var6.getItemShapeFilled(1, (-2));
//     java.awt.Shape var14 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
//     java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var28 = var26.lookupSeriesStroke(1);
//     java.awt.Paint var30 = var26.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var14, var21, var23, var30);
//     var6.setBaseFillPaint(var30, false);
//     var0.setRangeZeroBaselinePaint(var30);
//     
//     // Checks the contract:  equals-hashcode on var1 and var22
//     assertTrue("Contract failed: equals-hashcode on var1 and var22", var1.equals(var22) ? var1.hashCode() == var22.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var22 and var1
//     assertTrue("Contract failed: equals-hashcode on var22 and var1", var22.equals(var1) ? var22.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.ChartRenderingInfo var2 = var1.getOwner();
    java.awt.geom.Point2D var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.getSubplotIndex(var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var12.createBufferedImage(15, (-2), 10, var16);
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var0.setBaseSeriesVisible(false);
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawBackground(var3, var4, var5);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);

  }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var2.setSeriesItemLabelPaint(100, var11, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
//     java.awt.Paint var22 = var18.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var24 = null;
//     var23.axisChanged(var24);
//     java.awt.Paint var26 = var23.getRangeZeroBaselinePaint();
//     var18.setBaseItemLabelPaint(var26);
//     java.awt.Font var30 = var18.getItemLabelFont(100, 0);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var35 = var33.lookupSeriesStroke(1);
//     java.awt.Paint var37 = var33.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("hi!", var30, var37);
//     var2.setSeriesFillPaint(5, var37, true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var18 and var2.", var18.equals(var2) == var2.equals(var18));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var33 and var2.", var33.equals(var2) == var2.equals(var33));
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var1 = var0.getShadowPaint();
//     boolean var2 = var0.isCircular();
//     org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     org.jfree.chart.plot.PiePlot var6 = null;
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     org.jfree.chart.ChartRenderingInfo var10 = var9.getOwner();
//     org.jfree.chart.plot.PiePlotState var11 = var0.initialise(var4, var5, var6, (java.lang.Integer)1, var9);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     java.awt.geom.Rectangle2D var0 = null;
//     java.awt.geom.Rectangle2D var1 = null;
//     boolean var2 = org.jfree.chart.util.ShapeUtilities.contains(var0, var1);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    org.jfree.chart.labels.ItemLabelPosition var2 = null;
    var0.setSeriesPositiveItemLabelPosition(100, var2, true);
    boolean var5 = var0.getBaseCreateEntities();
    java.awt.Stroke var7 = var0.lookupSeriesOutlineStroke(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesCreateEntities((-2), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    boolean var4 = var1.containsDomainRange((-1L), 10L);
    long var5 = var1.getSegmentsExcludedSize();
    int var6 = var1.getSegmentsIncluded();
    org.jfree.data.DefaultKeyedValues2D var8 = new org.jfree.data.DefaultKeyedValues2D(false);
    var8.removeValue((java.lang.Comparable)1, (java.lang.Comparable)2);
    java.util.List var12 = var8.getColumnKeys();
    var1.setExceptionSegments(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     var3.setAngleLabelsVisible(true);
//     java.awt.geom.Rectangle2D var8 = null;
//     java.awt.Point var9 = var3.translateValueThetaRadiusToJava2D(0.0d, 0.2d, var8);
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var3 = var2.getPadding();
//     var1.setPadding(var3);
//     boolean var5 = var0.equals((java.lang.Object)var1);
//     java.util.Calendar var6 = null;
//     long var7 = var0.getLastMillisecond(var6);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
//     var7.setSeriesItemLabelGenerator(2, var9);
//     java.awt.Font var11 = var7.getBaseItemLabelFont();
//     java.lang.Boolean var13 = var7.getSeriesVisibleInLegend(100);
//     java.awt.Stroke var16 = var7.getItemStroke(15, (-1));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
//     boolean var22 = var19.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var23 = var19.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var26.setBaseCreateEntities(false);
//     java.lang.Boolean var30 = null;
//     var26.setSeriesVisibleInLegend(0, var30, true);
//     boolean var33 = var26.getAutoPopulateSeriesStroke();
//     java.awt.Shape var35 = var26.lookupSeriesShape((-2));
//     boolean var37 = var26.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var38 = var26.getBasePositiveItemLabelPosition();
//     var19.setBasePositiveItemLabelPosition(var38, false);
//     var7.setBasePositiveItemLabelPosition(var38);
//     boolean var42 = var4.equals((java.lang.Object)var7);
//     org.jfree.chart.labels.CategorySeriesLabelGenerator var43 = null;
//     var7.setLegendItemURLGenerator(var43);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var49 = var47.lookupSeriesStroke(1);
//     boolean var50 = var47.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var51 = var47.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var54.setBaseCreateEntities(false);
//     java.lang.Boolean var58 = null;
//     var54.setSeriesVisibleInLegend(0, var58, true);
//     boolean var61 = var54.getAutoPopulateSeriesStroke();
//     java.awt.Shape var63 = var54.lookupSeriesShape((-2));
//     boolean var65 = var54.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var66 = var54.getBasePositiveItemLabelPosition();
//     var47.setBasePositiveItemLabelPosition(var66, false);
//     var7.setBaseNegativeItemLabelPosition(var66);
//     
//     // Checks the contract:  equals-hashcode on var38 and var66
//     assertTrue("Contract failed: equals-hashcode on var38 and var66", var38.equals(var66) ? var38.hashCode() == var66.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var66 and var38
//     assertTrue("Contract failed: equals-hashcode on var66 and var38", var66.equals(var38) ? var66.hashCode() == var38.hashCode() : true);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = var0.getRenderer();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var9.setBaseCreateEntities(false);
//     java.lang.Boolean var13 = null;
//     var9.setSeriesVisibleInLegend(0, var13, true);
//     boolean var16 = var9.getAutoPopulateSeriesStroke();
//     java.awt.Shape var18 = var9.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var26 = new org.jfree.chart.title.LegendGraphic(var18, var25);
//     java.awt.Shape var31 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var36 = var34.lookupSeriesStroke(1);
//     java.awt.Paint var38 = var34.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var40 = var39.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
//     java.awt.Paint var47 = var43.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var31, var38, var40, var47);
//     java.awt.Shape var49 = var48.getLine();
//     org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity(var49, "hi!", "hi!");
//     var26.setLine(var49);
//     java.awt.Paint var54 = var26.getFillPaint();
//     org.jfree.chart.util.StrokeList var55 = new org.jfree.chart.util.StrokeList();
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var58 = null;
//     var57.axisChanged(var58);
//     java.awt.Paint var60 = var57.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var61 = null;
//     var57.notifyListeners(var61);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var67 = var65.lookupSeriesStroke(1);
//     var57.setDomainCrosshairStroke(var67);
//     org.jfree.chart.plot.PiePlot3D var69 = new org.jfree.chart.plot.PiePlot3D();
//     double var70 = var69.getShadowXOffset();
//     var69.setDepthFactor(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var75 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var77 = var75.lookupSeriesStroke(1);
//     var69.setLabelLinkStroke(var77);
//     var57.setDomainGridlineStroke(var77);
//     var55.setStroke(12, var77);
//     org.jfree.chart.title.TextTitle var81 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var82 = var81.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var83 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var82);
//     org.jfree.data.gantt.TaskSeriesCollection var84 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var85 = var82.equals((java.lang.Object)var84);
//     org.jfree.chart.block.LineBorder var86 = new org.jfree.chart.block.LineBorder(var54, var77, var82);
//     var0.setInsets(var82);
//     
//     // Checks the contract:  equals-hashcode on var1 and var39
//     assertTrue("Contract failed: equals-hashcode on var1 and var39", var1.equals(var39) ? var1.hashCode() == var39.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var39 and var1
//     assertTrue("Contract failed: equals-hashcode on var39 and var1", var39.equals(var1) ? var39.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test213() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.ResourceBundle var1 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }

  }

  public void test214() {}
//   public void test214() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }
// 
// 
//     java.util.Locale var0 = null;
//     org.jfree.chart.axis.TickUnitSource var1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(var0);
// 
//   }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var0.getRowKey(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.chart.axis.AxisLocation var0 = null;
    org.jfree.chart.plot.PlotOrientation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.RectangleEdge var2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     java.util.Date var3 = var1.getDate(10L);
//     org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var5 = var4.getBaseTimeline();
//     java.util.Date var7 = var5.getDate(10L);
//     var1.addException(var7);
//     org.jfree.chart.axis.SegmentedTimeline var9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var10 = var9.getBaseTimeline();
//     java.util.Date var12 = var10.getDate(10L);
//     org.jfree.chart.axis.SegmentedTimeline var13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var14 = var13.getBaseTimeline();
//     java.util.Date var16 = var14.getDate(10L);
//     var10.addException(var16);
//     org.jfree.chart.axis.SegmentedTimeline var18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var19 = var18.getBaseTimeline();
//     java.util.Date var21 = var19.getDate(10L);
//     org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var23 = var22.getBaseTimeline();
//     java.util.Date var25 = var23.getDate(10L);
//     var19.addException(var25);
//     boolean var27 = var1.containsDomainRange(var16, var25);
//     java.util.TimeZone var28 = null;
//     org.jfree.data.time.Month var29 = new org.jfree.data.time.Month(var25, var28);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     double var1 = var0.getShadowXOffset();
//     var0.setDepthFactor(1.0d);
//     java.awt.Graphics2D var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     java.awt.geom.Point2D var6 = null;
//     org.jfree.chart.plot.PlotState var7 = null;
//     org.jfree.chart.ChartRenderingInfo var8 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var9 = new org.jfree.chart.plot.PlotRenderingInfo(var8);
//     org.jfree.chart.ChartRenderingInfo var10 = var9.getOwner();
//     var0.draw(var4, var5, var6, var7, var9);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var18 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var20 = var18.equals((java.lang.Object)(-1));
    var18.validateObject();
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var26 = var23.isBefore(var25);
    int var27 = var23.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var29 = new org.jfree.chart.entity.CategoryItemEntity(var15, "hi!", "", (org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)var23, (java.lang.Comparable)(-3.0d));
    org.jfree.chart.entity.ChartEntity var31 = new org.jfree.chart.entity.ChartEntity(var15, "");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1900);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     org.jfree.chart.plot.PlotRenderingInfo var6 = null;
//     java.awt.geom.Point2D var7 = null;
//     var3.zoomDomainAxes(100.0d, 0.05d, var6, var7);
//     java.awt.Graphics2D var9 = null;
//     java.awt.geom.Rectangle2D var10 = null;
//     var3.drawBackground(var9, var10);
// 
//   }

  public void test221() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var2 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var5 = var3.lookupSeriesStroke(1);
//     java.awt.Paint var7 = var3.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var3.setBaseItemLabelPaint(var11);
//     java.awt.Font var15 = var3.getItemLabelFont(100, 0);
//     java.awt.Shape var20 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var25 = var23.lookupSeriesStroke(1);
//     java.awt.Paint var27 = var23.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var29 = var28.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var34 = var32.lookupSeriesStroke(1);
//     java.awt.Paint var36 = var32.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var37 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var20, var27, var29, var36);
//     org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("", var15, var27);
//     
//     // Checks the contract:  equals-hashcode on var8 and var28
//     assertTrue("Contract failed: equals-hashcode on var8 and var28", var8.equals(var28) ? var8.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var8
//     assertTrue("Contract failed: equals-hashcode on var28 and var8", var28.equals(var8) ? var28.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var3 = var0.getValue((java.lang.Comparable)(-1.0d), (java.lang.Comparable)(-1));
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    org.jfree.chart.util.RectangleAnchor var20 = var19.getShapeAnchor();
    org.jfree.chart.text.TextBlockAnchor var21 = null;
    org.jfree.chart.text.TextBlock var23 = null;
    org.jfree.chart.text.TextBlockAnchor var24 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var25 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var28 = var25.getItemShapeFilled(1, (-2));
    boolean var30 = var25.equals((java.lang.Object)(-1.0d));
    var25.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var36 = var25.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var37 = var36.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var39 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var23, var24, var37, 100.0d);
    org.jfree.chart.axis.CategoryLabelWidthType var41 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var43 = new org.jfree.chart.axis.CategoryLabelPosition(var20, var21, var37, 1.0d, var41, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.LegendTitle var14 = var12.getLegend(5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryPlot var15 = var12.getCategoryPlot();
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test227() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var13.removeChangeListener(var14);
    var12.setTitle(var13);
    org.jfree.chart.event.ChartProgressListener var17 = null;
    var12.removeProgressListener(var17);
    org.jfree.chart.title.LegendTitle var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.addLegend(var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var6.setBaseCreateEntities(false);
//     java.lang.Boolean var10 = null;
//     var6.setSeriesVisibleInLegend(0, var10, true);
//     boolean var13 = var6.getAutoPopulateSeriesStroke();
//     java.awt.Shape var15 = var6.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
//     boolean var21 = var18.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
//     var18.setSeriesOutlineStroke(1, var24, false);
//     org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var27 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
//     org.jfree.chart.plot.XYPlot var28 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var29 = null;
//     var28.axisChanged(var29);
//     java.awt.Paint var31 = var28.getRangeZeroBaselinePaint();
//     var27.setArtifactPaint(var31);
//     org.jfree.chart.LegendItem var33 = new org.jfree.chart.LegendItem("ChartEntity: tooltip = null", "WMAP_Plot", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "java.awt.Color[r=0,g=0,b=15]", var15, var24, var31);
//     
//     // Checks the contract:  equals-hashcode on var23 and var28
//     assertTrue("Contract failed: equals-hashcode on var23 and var28", var23.equals(var28) ? var23.hashCode() == var28.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var28 and var23
//     assertTrue("Contract failed: equals-hashcode on var28 and var23", var28.equals(var23) ? var28.hashCode() == var23.hashCode() : true);
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLabelAngle(0.2d);
    var1.setLowerBound(12.0d);
    var1.setLowerBound(0.0d);
    var1.setTickMarksVisible(true);
    org.jfree.chart.axis.NumberTickUnit var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setTickUnit(var10, false, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test230() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var2 = var0.getSeries((java.lang.Comparable)"hi!");
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var0.getPercentComplete((java.lang.Comparable)0.05d, (java.lang.Comparable)"");
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.0d+ "'", var3.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.chart.renderer.category.BarRenderer var0 = new org.jfree.chart.renderer.category.BarRenderer();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.plot.CategoryPlot var3 = null;
    org.jfree.data.xy.XYDataset var5 = null;
    org.jfree.chart.axis.ValueAxis var6 = null;
    org.jfree.chart.renderer.PolarItemRenderer var7 = null;
    org.jfree.chart.plot.PolarPlot var8 = new org.jfree.chart.plot.PolarPlot(var5, var6, var7);
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    java.awt.geom.Point2D var12 = null;
    var8.zoomDomainAxes(100.0d, 0.05d, var11, var12);
    org.jfree.chart.ChartRenderingInfo var16 = null;
    org.jfree.chart.plot.PlotRenderingInfo var17 = new org.jfree.chart.plot.PlotRenderingInfo(var16);
    org.jfree.chart.ChartRenderingInfo var18 = var17.getOwner();
    java.awt.geom.Point2D var19 = null;
    var8.zoomDomainAxes(8.0d, (-3.0d), var17, var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var21 = var0.initialise(var1, var2, var3, 1, var17);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.jfree.data.KeyToGroupMap var0 = new org.jfree.data.KeyToGroupMap();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var5 = var2.isBefore(var4);
    var0.mapKeyToGroup((java.lang.Comparable)var4, (java.lang.Comparable)1.0E-5d);
    java.lang.String var8 = var4.getDescription();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
    java.awt.Shape var22 = var21.getLine();
    java.awt.Paint var23 = var21.getFillPaint();
    java.awt.Shape var24 = var21.getShape();
    boolean var25 = var21.isLineVisible();
    java.awt.Shape var26 = var21.getShape();
    java.lang.String var27 = var21.getToolTipText();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var27 + "' != '" + "hi!"+ "'", var27.equals("hi!"));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     boolean var9 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Shape var11 = var2.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
//     java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
//     org.jfree.chart.util.RectangleAnchor var20 = var19.getShapeAnchor();
//     java.awt.Graphics2D var21 = null;
//     java.awt.geom.Rectangle2D var22 = null;
//     var19.draw(var21, var22);
// 
//   }

  public void test235() {}
//   public void test235() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }
// 
// 
//     org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var7 = var5.lookupSeriesStroke(1);
//     java.awt.Paint var9 = var5.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var12 = null;
//     var11.axisChanged(var12);
//     java.awt.Paint var14 = var11.getRangeZeroBaselinePaint();
//     var5.setSeriesItemLabelPaint(100, var14, false);
//     java.awt.Paint var17 = var5.getBaseItemLabelPaint();
//     var2.setErrorIndicatorPaint(var17);
//     org.jfree.data.xy.XYDataset var20 = null;
//     org.jfree.chart.axis.ValueAxis var21 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var22 = null;
//     org.jfree.chart.plot.PolarPlot var23 = new org.jfree.chart.plot.PolarPlot(var20, var21, var22);
//     org.jfree.chart.plot.PlotRenderingInfo var26 = null;
//     java.awt.geom.Point2D var27 = null;
//     var23.zoomDomainAxes(100.0d, 0.05d, var26, var27);
//     org.jfree.chart.ChartRenderingInfo var31 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var32 = new org.jfree.chart.plot.PlotRenderingInfo(var31);
//     org.jfree.chart.ChartRenderingInfo var33 = var32.getOwner();
//     java.awt.geom.Point2D var34 = null;
//     var23.zoomDomainAxes(8.0d, (-3.0d), var32, var34);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var40 = var38.lookupSeriesStroke(1);
//     boolean var41 = var38.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var44 = var43.getDomainZeroBaselineStroke();
//     var38.setSeriesOutlineStroke(1, var44, false);
//     var23.setRadiusGridlineStroke(var44);
//     var2.setSeriesStroke(14, var44);
//     
//     // Checks the contract:  equals-hashcode on var11 and var43
//     assertTrue("Contract failed: equals-hashcode on var11 and var43", var11.equals(var43) ? var11.hashCode() == var43.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var43 and var11
//     assertTrue("Contract failed: equals-hashcode on var43 and var11", var43.equals(var11) ? var43.hashCode() == var11.hashCode() : true);
// 
//   }

  public void test236() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }


    org.jfree.chart.ui.Library var4 = new org.jfree.chart.ui.Library("ChartEntity: tooltip = null", "hi!", "java.awt.Color[r=0,g=0,b=15]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");

  }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
//     java.awt.Paint var1 = var0.getPaint();
//     java.awt.Graphics2D var2 = null;
//     java.awt.geom.Rectangle2D var3 = null;
//     var0.draw(var2, var3);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var9 = null;
//     var8.axisChanged(var9);
//     java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
//     var2.setSeriesItemLabelPaint(100, var11, false);
//     org.jfree.chart.plot.CategoryPlot var14 = var2.getPlot();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
//     java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var24 = null;
//     var23.axisChanged(var24);
//     java.awt.Paint var26 = var23.getRangeZeroBaselinePaint();
//     var17.setSeriesItemLabelPaint(100, var26, false);
//     var2.setBaseFillPaint(var26, true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var23
//     assertTrue("Contract failed: equals-hashcode on var8 and var23", var8.equals(var23) ? var8.hashCode() == var23.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var23 and var8
//     assertTrue("Contract failed: equals-hashcode on var23 and var8", var23.equals(var8) ? var23.hashCode() == var8.hashCode() : true);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var13.removeChangeListener(var14);
    var12.setTitle(var13);
    org.jfree.chart.ChartRenderingInfo var19 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var20 = var12.createBufferedImage(0, 10, var19);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test240() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }


    org.jfree.chart.block.CenterArrangement var0 = new org.jfree.chart.block.CenterArrangement();
    var0.clear();

  }

  public void test241() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    var0.mapDatasetToDomainAxis(0, 2);
    org.jfree.chart.axis.AxisLocation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var5, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     double[] var2 = null;
//     double[][] var3 = new double[][] { var2};
//     org.jfree.data.category.CategoryDataset var4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var3);
// 
//   }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var13.removeChangeListener(var14);
    var12.setTitle(var13);
    java.awt.Graphics2D var17 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var18 = var13.arrange(var17);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.axis.AxisLocation var2 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxisLocation(var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.event.TitleChangeEvent var13 = null;
//     var12.titleChanged(var13);
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.lang.String var1 = var0.getLabelFormat();
    org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var3 = null;
    boolean var4 = var2.hasListener(var3);
    int var6 = var2.getRowIndex((java.lang.Comparable)0L);
    java.util.List var7 = var2.getRowKeys();
    org.jfree.chart.axis.NumberAxis3D var9 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var9.setLabelAngle(0.2d);
    var9.setLowerBound(12.0d);
    var9.setLowerBound(0.0d);
    var9.setTickMarksVisible(true);
    boolean var18 = var9.isPositiveArrowVisible();
    boolean var19 = var2.equals((java.lang.Object)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var21 = var0.generateRowLabel((org.jfree.data.category.CategoryDataset)var2, (-2));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "({0}, {1}) = {3} - {4}"+ "'", var1.equals("({0}, {1}) = {3} - {4}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test247() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.LegendTitle var14 = var12.getLegend(5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var17 = var12.createBufferedImage(0, 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test248() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    java.lang.Object var4 = null;
    boolean var5 = var0.equals(var4);
    java.lang.String var6 = var0.getNoDataMessage();
    boolean var7 = var0.isRangeCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var12.setBaseCreateEntities(false);
    java.lang.Boolean var16 = null;
    var12.setSeriesVisibleInLegend(0, var16, true);
    boolean var19 = var12.getAutoPopulateSeriesStroke();
    java.awt.Shape var21 = var12.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var26 = var24.lookupSeriesStroke(1);
    java.awt.Paint var28 = var24.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var29 = new org.jfree.chart.title.LegendGraphic(var21, var28);
    java.awt.Shape var34 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
    java.awt.Paint var41 = var37.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var42 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var43 = var42.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var48 = var46.lookupSeriesStroke(1);
    java.awt.Paint var50 = var46.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var51 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var34, var41, var43, var50);
    java.awt.Shape var52 = var51.getLine();
    org.jfree.chart.entity.ChartEntity var55 = new org.jfree.chart.entity.ChartEntity(var52, "hi!", "hi!");
    var29.setLine(var52);
    java.awt.Paint var57 = var29.getFillPaint();
    var9.setBaseItemLabelPaint(var57);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(5, var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var4 = null;
    var0.notifyListeners(var4);
    org.jfree.chart.axis.ValueAxis var7 = null;
    var0.setRangeAxis(1900, var7, false);
    org.jfree.chart.renderer.category.LineRenderer3D var11 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var14 = var11.getItemShapeFilled(1, (-2));
    java.awt.Shape var19 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var24 = var22.lookupSeriesStroke(1);
    java.awt.Paint var26 = var22.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var28 = var27.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var33 = var31.lookupSeriesStroke(1);
    java.awt.Paint var35 = var31.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var19, var26, var28, var35);
    var11.setBaseFillPaint(var35, false);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var40 = null;
    var39.axisChanged(var40);
    java.awt.Paint var42 = var39.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var43 = null;
    var39.notifyListeners(var43);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var49 = var47.lookupSeriesStroke(1);
    var39.setDomainCrosshairStroke(var49);
    org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker((-3.0d), var35, var49);
    var51.setAlpha(1.0f);
    org.jfree.chart.event.MarkerChangeEvent var54 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var51);
    org.jfree.chart.util.Layer var55 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var51, var55);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     java.lang.String var6 = var0.getNoDataMessage();
//     java.awt.Graphics2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var0.drawOutline(var7, var8);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    org.jfree.data.xy.XYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test253() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-459), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    org.jfree.chart.axis.NumberTickUnit var3 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var5 = var3.equals((java.lang.Object)0.0f);
    double var6 = var3.getSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var0.getValue((java.lang.Comparable)(short)100, (java.lang.Comparable)var3);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.0d);

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    java.awt.Graphics2D var1 = null;
    java.awt.geom.Rectangle2D var2 = null;
    org.jfree.chart.plot.RingPlot var3 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var4 = var3.getShadowPaint();
    java.lang.Object var5 = null;
    boolean var6 = var3.equals(var5);
    java.awt.Font var7 = var3.getNoDataMessageFont();
    org.jfree.chart.ChartRenderingInfo var9 = null;
    org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
    org.jfree.chart.ChartRenderingInfo var11 = var10.getOwner();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var12 = var0.initialise(var1, var2, (org.jfree.chart.plot.PiePlot)var3, (java.lang.Integer)1, var10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getNearestDayOfWeek(255);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

//  public void test257() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
//
//
//    java.lang.Class var0 = null;
//    java.lang.ClassLoader var1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var0);
//    org.jfree.chart.util.ObjectUtilities.setClassLoader(var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var1);
//
//  }
//
  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     java.awt.Shape var8 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var13 = var11.lookupSeriesStroke(1);
//     java.awt.Paint var15 = var11.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var25 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var8, var15, var17, var24);
//     org.jfree.chart.block.BlockBorder var26 = new org.jfree.chart.block.BlockBorder(100.0d, (-1.0d), 10.0d, 100.0d, var15);
//     java.awt.Graphics2D var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     var26.draw(var27, var28);
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 100);
    var0.setDataset(var6);
    org.jfree.chart.event.PlotChangeEvent var8 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var0);
    org.jfree.chart.labels.PieSectionLabelGenerator var9 = var0.getLegendLabelGenerator();
    java.awt.Stroke var10 = var0.getOutlineStroke();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    var0.setBackgroundPaint(var4);
    org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
    java.awt.Shape var12 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
    java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var21 = var20.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var26 = var24.lookupSeriesStroke(1);
    java.awt.Paint var28 = var24.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var12, var19, var21, var28);
    java.awt.Shape var30 = var29.getLine();
    java.awt.Paint var31 = var29.getFillPaint();
    boolean var32 = var29.isShapeFilled();
    java.awt.Paint var33 = var29.getLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setQuadrantPaint(100, var33);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
    java.awt.Shape var22 = var21.getLine();
    java.awt.Paint var23 = var21.getFillPaint();
    java.awt.Shape var24 = var21.getShape();
    boolean var25 = var21.isLineVisible();
    org.jfree.chart.util.GradientPaintTransformer var26 = var21.getFillPaintTransformer();
    java.text.AttributedString var27 = var21.getAttributedLabel();
    boolean var28 = var21.isShapeFilled();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     boolean var9 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Shape var11 = var2.lookupSeriesShape((-2));
//     java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 4.0d, 10.0f, 10.0f);
//     org.jfree.data.gantt.TaskSeriesCollection var18 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var20 = var18.equals((java.lang.Object)(-1));
//     var18.validateObject();
//     org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var26 = var23.isBefore(var25);
//     int var27 = var23.getYYYY();
//     org.jfree.chart.entity.CategoryItemEntity var29 = new org.jfree.chart.entity.CategoryItemEntity(var15, "hi!", "", (org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)var23, (java.lang.Comparable)(-3.0d));
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var34 = var31.isBefore(var33);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var38 = var36.getPreviousDayOfWeek(1);
//     boolean var40 = var23.isInRange((org.jfree.data.time.SerialDate)var31, var38, 1900);
//     int var41 = var31.getDayOfMonth();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var44.setBaseCreateEntities(false);
//     java.lang.Boolean var48 = null;
//     var44.setSeriesVisibleInLegend(0, var48, true);
//     boolean var51 = var44.getAutoPopulateSeriesStroke();
//     java.awt.Shape var53 = var44.lookupSeriesShape((-2));
//     java.awt.Shape var57 = org.jfree.chart.util.ShapeUtilities.rotateShape(var53, 4.0d, 10.0f, 10.0f);
//     org.jfree.data.gantt.TaskSeriesCollection var60 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var62 = var60.equals((java.lang.Object)(-1));
//     var60.validateObject();
//     org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var68 = var65.isBefore(var67);
//     int var69 = var65.getYYYY();
//     org.jfree.chart.entity.CategoryItemEntity var71 = new org.jfree.chart.entity.CategoryItemEntity(var57, "hi!", "", (org.jfree.data.category.CategoryDataset)var60, (java.lang.Comparable)var65, (java.lang.Comparable)(-3.0d));
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var76 = var73.isBefore(var75);
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var80 = var78.getPreviousDayOfWeek(1);
//     boolean var82 = var65.isInRange((org.jfree.data.time.SerialDate)var73, var80, 1900);
//     int var83 = var73.getDayOfMonth();
//     boolean var84 = var31.isOnOrAfter((org.jfree.data.time.SerialDate)var73);
//     
//     // Checks the contract:  equals-hashcode on var18 and var60
//     assertTrue("Contract failed: equals-hashcode on var18 and var60", var18.equals(var60) ? var18.hashCode() == var60.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var60 and var18
//     assertTrue("Contract failed: equals-hashcode on var60 and var18", var60.equals(var18) ? var60.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test263() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    int var4 = var3.getSeriesCount();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    var3.drawBackgroundImage(var5, var6);
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var9.addChangeListener(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
    java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
    var9.setBackgroundPaint(var19);
    java.awt.Paint var21 = var9.getPaint();
    var3.setRangeTickBandPaint(var21);
    org.jfree.chart.plot.Plot var23 = var3.getParent();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.ValueAxis var25 = var3.getDomainAxisForDataset(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);

  }

  public void test264() {}
//   public void test264() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     java.awt.Paint var42 = var41.getOutlinePaint();
//     java.awt.Paint var43 = var41.getOutlinePaint();
//     boolean var45 = var41.equals((java.lang.Object)0L);
//     java.awt.Stroke var46 = var41.getStroke();
//     java.awt.Shape var51 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var56 = var54.lookupSeriesStroke(1);
//     java.awt.Paint var58 = var54.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var60 = var59.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var65 = var63.lookupSeriesStroke(1);
//     java.awt.Paint var67 = var63.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var68 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var51, var58, var60, var67);
//     var41.setLabelPaint(var58);
//     
//     // Checks the contract:  equals-hashcode on var17 and var59
//     assertTrue("Contract failed: equals-hashcode on var17 and var59", var17.equals(var59) ? var17.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var17
//     assertTrue("Contract failed: equals-hashcode on var59 and var17", var59.equals(var17) ? var59.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var68
//     assertTrue("Contract failed: equals-hashcode on var26 and var68", var26.equals(var68) ? var26.hashCode() == var68.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var68 and var26
//     assertTrue("Contract failed: equals-hashcode on var68 and var26", var68.equals(var26) ? var68.hashCode() == var26.hashCode() : true);
// 
//   }

  public void test265() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    java.util.Locale var1 = var0.getLocale();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String[] var3 = var0.getStringArray("WMAP_Plot");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    org.jfree.chart.block.BlockParams var0 = new org.jfree.chart.block.BlockParams();
    var0.setGenerateEntities(false);

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    int var4 = var0.getSeriesCount();
    org.jfree.data.time.SpreadsheetDate var7 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var11 = var9.getFollowingDayOfWeek(2);
    org.jfree.data.time.SpreadsheetDate var13 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var16 = var13.isBefore(var15);
    int var17 = var13.getYYYY();
    boolean var19 = var7.isInRange(var9, (org.jfree.data.time.SerialDate)var13, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var22.setBaseCreateEntities(false);
    java.lang.Boolean var26 = null;
    var22.setSeriesVisibleInLegend(0, var26, true);
    boolean var29 = var22.getAutoPopulateSeriesStroke();
    java.awt.Shape var31 = var22.lookupSeriesShape((-2));
    java.awt.Shape var35 = org.jfree.chart.util.ShapeUtilities.rotateShape(var31, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var38 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var40 = var38.equals((java.lang.Object)(-1));
    var38.validateObject();
    org.jfree.data.time.SpreadsheetDate var43 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var46 = var43.isBefore(var45);
    int var47 = var43.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var49 = new org.jfree.chart.entity.CategoryItemEntity(var35, "hi!", "", (org.jfree.data.category.CategoryDataset)var38, (java.lang.Comparable)var43, (java.lang.Comparable)(-3.0d));
    org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var54 = var51.isBefore(var53);
    org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var58 = var56.getPreviousDayOfWeek(1);
    boolean var60 = var43.isInRange((org.jfree.data.time.SerialDate)var51, var58, 1900);
    boolean var61 = var7.isOn((org.jfree.data.time.SerialDate)var43);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var62 = var0.getSubIntervalCount((java.lang.Comparable)0.0d, (java.lang.Comparable)var43);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    java.lang.Comparable var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeValue(var1, (java.lang.Comparable)(byte)(-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryAnchor var1 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
//     org.jfree.chart.event.TitleChangeListener var7 = null;
//     var5.addChangeListener(var7);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var13 = var11.lookupSeriesStroke(1);
//     java.awt.Paint var15 = var11.lookupSeriesOutlinePaint(10);
//     var5.setBackgroundPaint(var15);
//     var5.setExpandToFitSpace(false);
//     java.awt.Graphics2D var19 = null;
//     java.awt.geom.Rectangle2D var20 = null;
//     org.jfree.chart.plot.XYPlot var21 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var22 = null;
//     var21.axisChanged(var22);
//     java.awt.Paint var24 = var21.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var25 = var21.getRangeAxisEdge();
//     java.lang.Object var26 = var5.draw(var19, var20, (java.lang.Object)var25);
//     double var27 = var0.getCategoryJava2DCoordinate(var1, 1900, 5, var4, var25);
// 
//   }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     org.jfree.chart.util.Size2D var0 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var5.setBaseCreateEntities(false);
//     java.lang.Boolean var9 = null;
//     var5.setSeriesVisibleInLegend(0, var9, true);
//     boolean var12 = var5.getAutoPopulateSeriesStroke();
//     java.awt.Shape var14 = var5.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
//     java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var22 = new org.jfree.chart.title.LegendGraphic(var14, var21);
//     java.awt.Shape var27 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var32 = var30.lookupSeriesStroke(1);
//     java.awt.Paint var34 = var30.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var36 = var35.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var41 = var39.lookupSeriesStroke(1);
//     java.awt.Paint var43 = var39.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var44 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var27, var34, var36, var43);
//     java.awt.Shape var45 = var44.getLine();
//     org.jfree.chart.entity.ChartEntity var48 = new org.jfree.chart.entity.ChartEntity(var45, "hi!", "hi!");
//     var22.setLine(var45);
//     org.jfree.chart.util.RectangleAnchor var50 = var22.getShapeAnchor();
//     java.awt.geom.Rectangle2D var51 = org.jfree.chart.util.RectangleAnchor.createRectangle(var0, 12.0d, 1.0E-5d, var50);
// 
//   }

  public void test271() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), 14);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    int var1 = var0.getPassCount();
    java.awt.Graphics2D var2 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var5.setBaseCreateEntities(false);
    java.lang.Boolean var9 = null;
    var5.setSeriesVisibleInLegend(0, var9, true);
    int var12 = var5.getPassCount();
    java.lang.Boolean var14 = var5.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var16);
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.gantt.TaskSeriesCollection var22 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var24 = var22.getSeries((java.lang.Comparable)"hi!");
    var5.drawItem(var15, var17, var18, var19, var20, var21, (org.jfree.data.category.CategoryDataset)var22, (-2), (-459), 10);
    java.awt.geom.Rectangle2D var29 = null;
    org.jfree.chart.plot.CategoryPlot var30 = null;
    org.jfree.chart.axis.CategoryAxis var31 = null;
    org.jfree.chart.axis.ValueAxis var32 = null;
    org.jfree.data.gantt.TaskSeries var34 = new org.jfree.data.gantt.TaskSeries("hi!");
    java.lang.Comparable var35 = var34.getKey();
    org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var38 = var36.equals((java.lang.Object)(-1));
    var36.validateObject();
    var34.addChangeListener((org.jfree.data.general.SeriesChangeListener)var36);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var2, var17, var29, var30, var31, var32, (org.jfree.data.category.CategoryDataset)var36, (-2), (-459), 2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var35 + "' != '" + "hi!"+ "'", var35.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.Range var2 = org.jfree.data.Range.expandToInclude(var0, 0.0d);
//     org.jfree.data.Range var4 = org.jfree.data.Range.shift(var0, 0.2d);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getValue(12, 14);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var13.removeChangeListener(var14);
//     var12.setTitle(var13);
//     org.jfree.chart.plot.XYPlot var18 = new org.jfree.chart.plot.XYPlot();
//     int var19 = var18.getSeriesCount();
//     java.awt.Graphics2D var20 = null;
//     java.awt.geom.Rectangle2D var21 = null;
//     var18.drawBackgroundImage(var20, var21);
//     org.jfree.chart.plot.PlotRenderingInfo var24 = null;
//     java.awt.geom.Point2D var25 = null;
//     var18.zoomRangeAxes((-1.0d), var24, var25);
//     org.jfree.chart.event.PlotChangeListener var27 = null;
//     var18.removeChangeListener(var27);
//     org.jfree.chart.JFreeChart var29 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var18);
//     java.awt.Image var30 = null;
//     var29.setBackgroundImage(var30);
//     var13.addChangeListener((org.jfree.chart.event.TitleChangeListener)var29);
//     
//     // Checks the contract:  equals-hashcode on var1 and var18
//     assertTrue("Contract failed: equals-hashcode on var1 and var18", var1.equals(var18) ? var1.hashCode() == var18.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var18 and var1
//     assertTrue("Contract failed: equals-hashcode on var18 and var1", var18.equals(var1) ? var18.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test276() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }


    org.jfree.data.resources.DataPackageResources var0 = new org.jfree.data.resources.DataPackageResources();
    java.util.Enumeration var1 = var0.getKeys();
    boolean var3 = var0.containsKey("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var5 = var0.getObject("ThreadContext");
      fail("Expected exception of type java.util.MissingResourceException");
    } catch (java.util.MissingResourceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test277() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(false);
    var1.removeValue((java.lang.Comparable)1, (java.lang.Comparable)2);
    int var6 = var1.getColumnIndex((java.lang.Comparable)(byte)(-1));
    org.jfree.chart.axis.NumberTickUnit var8 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var10 = var8.equals((java.lang.Object)0.0f);
    double var11 = var8.getSize();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.removeRow((java.lang.Comparable)var8);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 2.0d);

  }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(2, var4);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var7 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var7);
    org.jfree.chart.axis.AxisSpace var9 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var11 = var10.getPadding();
    org.jfree.chart.event.TitleChangeListener var12 = null;
    var10.addChangeListener(var12);
    boolean var14 = var9.equals((java.lang.Object)var12);
    org.jfree.data.gantt.TaskSeriesCollection var15 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var16 = null;
    boolean var17 = var15.hasListener(var16);
    int var19 = var15.getRowIndex((java.lang.Comparable)0L);
    java.util.List var20 = var15.getRowKeys();
    boolean var21 = var9.equals((java.lang.Object)var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var23 = var7.generateLabel((org.jfree.data.category.CategoryDataset)var15, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 100);
    var0.setDataset(var6);
    double var8 = var0.getShadowYOffset();
    double var9 = var0.getDepthFactor();
    org.jfree.chart.labels.PieSectionLabelGenerator var10 = var0.getLegendLabelGenerator();
    org.jfree.chart.title.TextTitle var11 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var12 = var11.getPadding();
    org.jfree.chart.event.TitleChangeListener var13 = null;
    var11.addChangeListener(var13);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
    java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
    var11.setBackgroundPaint(var21);
    java.awt.Paint var23 = var11.getPaint();
    var0.setLabelLinkPaint(var23);
    java.awt.Paint var25 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelPaint(var25);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test280() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var6 = var3.getItemShapeFilled(1, (-2));
    boolean var8 = var3.equals((java.lang.Object)(-1.0d));
    var3.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var14 = var3.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var15 = var14.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var17 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var1, var2, var15, 100.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var20.setBaseCreateEntities(false);
    java.lang.Boolean var24 = null;
    var20.setSeriesVisibleInLegend(0, var24, true);
    boolean var27 = var20.getAutoPopulateSeriesStroke();
    java.awt.Shape var29 = var20.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var34 = var32.lookupSeriesStroke(1);
    java.awt.Paint var36 = var32.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var29, var36);
    org.jfree.chart.util.RectangleAnchor var38 = var37.getShapeAnchor();
    boolean var39 = var17.equals((java.lang.Object)var37);
    java.lang.String var40 = var17.getText();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var40 + "' != '" + ""+ "'", var40.equals(""));

  }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var42);
    org.jfree.data.time.DateRange var50 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    boolean var51 = var47.equals((java.lang.Object)1.0d);
    java.lang.Object var52 = var47.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
    var2.setSeriesItemLabelPaint(100, var11, false);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var15 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var2.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var15, true);
    java.text.DateFormat var18 = var15.getDateFormat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     java.awt.Paint var42 = var41.getOutlinePaint();
//     java.awt.Paint var43 = var41.getOutlinePaint();
//     boolean var45 = var41.equals((java.lang.Object)0L);
//     org.jfree.chart.plot.PiePlot var46 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var50 = var48.getPreviousDayOfWeek(1);
//     org.jfree.chart.axis.CategoryLabelPositions var51 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.XYPlot var52 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var54 = null;
//     var53.axisChanged(var54);
//     java.awt.Paint var56 = var53.getRangeZeroBaselinePaint();
//     var52.setBackgroundPaint(var56);
//     org.jfree.chart.renderer.xy.XYItemRenderer var58 = var52.getRenderer();
//     java.awt.Stroke var59 = var52.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var60 = null;
//     var52.removeChangeListener(var60);
//     java.awt.Paint var62 = var52.getRangeCrosshairPaint();
//     boolean var63 = var51.equals((java.lang.Object)var62);
//     var46.setSectionPaint((java.lang.Comparable)var50, var62);
//     var41.setPaint(var62);
//     
//     // Checks the contract:  equals-hashcode on var17 and var53
//     assertTrue("Contract failed: equals-hashcode on var17 and var53", var17.equals(var53) ? var17.hashCode() == var53.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var53 and var17
//     assertTrue("Contract failed: equals-hashcode on var53 and var17", var53.equals(var17) ? var53.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    java.awt.Font var1 = null;
    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var13.axisChanged(var14);
    java.awt.Paint var16 = var13.getRangeZeroBaselinePaint();
    var7.setSeriesItemLabelPaint(100, var16, false);
    java.awt.Paint var19 = var7.getBaseItemLabelPaint();
    var4.setErrorIndicatorPaint(var19);
    org.jfree.chart.labels.CategoryToolTipGenerator var21 = var4.getBaseToolTipGenerator();
    java.awt.Paint var22 = var4.getErrorIndicatorPaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var23 = new org.jfree.chart.text.TextFragment("({0}, {1}) = {3} - {4}", var1, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    org.jfree.chart.util.BooleanList var0 = new org.jfree.chart.util.BooleanList();
    java.lang.Object var1 = var0.clone();
    java.lang.Boolean var3 = var0.getBoolean(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var14 = var12.getLegend(5);
//     java.awt.Image var15 = var12.getBackgroundImage();
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var17 = var16.getDomainZeroBaselineStroke();
//     var12.setBorderStroke(var17);
//     
//     // Checks the contract:  equals-hashcode on var1 and var16
//     assertTrue("Contract failed: equals-hashcode on var1 and var16", var1.equals(var16) ? var1.hashCode() == var16.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var16 and var1
//     assertTrue("Contract failed: equals-hashcode on var16 and var1", var16.equals(var1) ? var16.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test287() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    java.util.Date var3 = var0.getMaximumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeWithMargins(10.0d, 2.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test289() {}
//   public void test289() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     double var4 = var3.getShadowXOffset();
//     var3.setDepthFactor(1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 100);
//     var3.setDataset(var9);
//     org.jfree.chart.event.PlotChangeEvent var11 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot)var3);
//     org.jfree.chart.plot.Plot var12 = var11.getPlot();
//     var0.notifyListeners(var11);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     int var16 = var15.getSeriesCount();
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     var15.drawBackgroundImage(var17, var18);
//     org.jfree.chart.plot.PlotRenderingInfo var21 = null;
//     java.awt.geom.Point2D var22 = null;
//     var15.zoomRangeAxes((-1.0d), var21, var22);
//     org.jfree.chart.event.PlotChangeListener var24 = null;
//     var15.removeChangeListener(var24);
//     org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var15);
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var28 = null;
//     var27.removeChangeListener(var28);
//     var26.setTitle(var27);
//     var11.setChart(var26);
//     
//     // Checks the contract:  equals-hashcode on var0 and var15
//     assertTrue("Contract failed: equals-hashcode on var0 and var15", var0.equals(var15) ? var0.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var0
//     assertTrue("Contract failed: equals-hashcode on var15 and var0", var15.equals(var0) ? var15.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test290() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    java.util.Date var3 = var0.getMaximumDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setAutoRangeMinimumSize(0.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var1 = var0.getShadowPaint();
    boolean var2 = var0.isCircular();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.RingPlot var6 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var7 = var6.getShadowPaint();
    org.jfree.data.xy.XYDataset var9 = null;
    org.jfree.chart.axis.ValueAxis var10 = null;
    org.jfree.chart.renderer.PolarItemRenderer var11 = null;
    org.jfree.chart.plot.PolarPlot var12 = new org.jfree.chart.plot.PolarPlot(var9, var10, var11);
    org.jfree.chart.plot.PlotRenderingInfo var15 = null;
    java.awt.geom.Point2D var16 = null;
    var12.zoomDomainAxes(100.0d, 0.05d, var15, var16);
    org.jfree.chart.ChartRenderingInfo var20 = null;
    org.jfree.chart.plot.PlotRenderingInfo var21 = new org.jfree.chart.plot.PlotRenderingInfo(var20);
    org.jfree.chart.ChartRenderingInfo var22 = var21.getOwner();
    java.awt.geom.Point2D var23 = null;
    var12.zoomDomainAxes(8.0d, (-3.0d), var21, var23);
    java.lang.Object var25 = var21.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var26 = var0.initialise(var4, var5, (org.jfree.chart.plot.PiePlot)var6, (java.lang.Integer)0, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test292() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var10 = var8.lookupSeriesStroke(1);
    var0.setDomainZeroBaselineStroke(var10);
    org.jfree.chart.util.RectangleInsets var12 = var0.getInsets();
    java.awt.geom.Rectangle2D var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var14 = var12.createOutsetRectangle(var13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test293() {}
//   public void test293() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     java.awt.Shape var7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleEdge.TOP", var1, 0.0f, 100.0f, 1.0E-5d, 0.0f, 100.0f);
// 
//   }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    org.jfree.chart.util.ObjectList var0 = new org.jfree.chart.util.ObjectList();
    java.lang.Object var2 = var0.get(100);
    org.jfree.data.Range var3 = null;
    org.jfree.data.Range var5 = org.jfree.data.Range.expandToInclude(var3, 0.0d);
    int var6 = var0.indexOf((java.lang.Object)var3);
    var0.clear();
    java.lang.Object var8 = null;
    int var9 = var0.indexOf(var8);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var11 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.text.NumberFormat var12 = var11.getNumberFormat();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.set((-2), (java.lang.Object)var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.plot.PlotOrientation var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setOrientation(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
    java.awt.Shape var22 = var21.getLine();
    boolean var23 = var21.isShapeVisible();
    boolean var24 = var21.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextBlock var5 = null;
//     org.jfree.chart.text.TextBlockAnchor var6 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var10 = var7.getItemShapeFilled(1, (-2));
//     boolean var12 = var7.equals((java.lang.Object)(-1.0d));
//     var7.setBaseSeriesVisibleInLegend(true, true);
//     org.jfree.chart.labels.ItemLabelPosition var18 = var7.getNegativeItemLabelPosition((-2), (-459));
//     org.jfree.chart.text.TextAnchor var19 = var18.getTextAnchor();
//     org.jfree.chart.axis.CategoryTick var21 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var5, var6, var19, 100.0d);
//     java.awt.geom.Rectangle2D var22 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleEdge.BOTTOM", var1, 100.0f, 1.0f, var19);
// 
//   }

  public void test298() {}
//   public void test298() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var3 = var0.getItemShapeFilled(1, (-2));
//     boolean var5 = var0.equals((java.lang.Object)(-1.0d));
//     var0.setBaseSeriesVisibleInLegend(true, true);
//     java.awt.Graphics2D var9 = null;
//     org.jfree.chart.plot.CategoryPlot var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var0.drawOutline(var9, var10, var11);
// 
//   }

  public void test299() {}
//   public void test299() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     org.jfree.chart.plot.RingPlot var2 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.LegendItemCollection var3 = var2.getLegendItems();
//     var1.addAll(var3);
//     
//     // Checks the contract:  equals-hashcode on var1 and var3
//     assertTrue("Contract failed: equals-hashcode on var1 and var3", var1.equals(var3) ? var1.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var3 and var1
//     assertTrue("Contract failed: equals-hashcode on var3 and var1", var3.equals(var1) ? var3.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test300() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(2, var4);
    java.awt.Font var6 = var2.getBaseItemLabelFont();
    java.lang.Boolean var8 = var2.getSeriesVisibleInLegend(100);
    java.awt.Paint var10 = var2.getSeriesPaint((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     double var1 = var0.getYOffset();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getBasePositiveItemLabelPosition();
//     java.awt.Graphics2D var3 = null;
//     org.jfree.chart.plot.CategoryPlot var4 = null;
//     java.awt.geom.Rectangle2D var5 = null;
//     var0.drawOutline(var3, var4, var5);
// 
//   }

  public void test302() {}
//   public void test302() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.general.DatasetGroup var5 = var3.getGroup();
//     java.lang.Object var6 = var5.clone();
//     org.jfree.chart.axis.AxisSpace var7 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
//     org.jfree.chart.event.TitleChangeListener var10 = null;
//     var8.addChangeListener(var10);
//     boolean var12 = var7.equals((java.lang.Object)var10);
//     org.jfree.data.gantt.TaskSeriesCollection var13 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var14 = null;
//     boolean var15 = var13.hasListener(var14);
//     int var17 = var13.getRowIndex((java.lang.Comparable)0L);
//     java.util.List var18 = var13.getRowKeys();
//     boolean var19 = var7.equals((java.lang.Object)var13);
//     boolean var20 = var5.equals((java.lang.Object)var7);
//     
//     // Checks the contract:  equals-hashcode on var3 and var13
//     assertTrue("Contract failed: equals-hashcode on var3 and var13", var3.equals(var13) ? var3.hashCode() == var13.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var13 and var3
//     assertTrue("Contract failed: equals-hashcode on var13 and var3", var13.equals(var3) ? var13.hashCode() == var3.hashCode() : true);
// 
//   }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    var0.setSeriesShapesFilled(10, (java.lang.Boolean)false);
    var0.setSeriesItemLabelsVisible(0, false);
    double var10 = var0.getItemLabelAnchorOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 2.0d);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    var0.setPadding(var2);
    double var4 = var2.getBottom();
    java.awt.geom.Rectangle2D var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.geom.Rectangle2D var8 = var2.createInsetRectangle(var5, true, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 1.0d);

  }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("ThreadContext");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var1.setKey((java.lang.Comparable)10);
    org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var5 = var4.getBaseTimeline();
    java.util.Date var7 = var5.getDate(10L);
    var1.setKey((java.lang.Comparable)10L);
    boolean var9 = var1.getNotify();
    org.jfree.data.gantt.Task var10 = null;
    var1.remove(var10);
    org.jfree.chart.axis.SegmentedTimeline var13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var14 = var13.getBaseTimeline();
    long var15 = var13.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var17 = var16.getBaseTimeline();
    java.util.Date var19 = var17.getDate(10L);
    boolean var20 = var13.containsDomainValue(var19);
    org.jfree.chart.axis.SegmentedTimeline var21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var22 = var21.getBaseTimeline();
    java.util.Date var24 = var22.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var26 = var25.getBaseTimeline();
    java.util.Date var28 = var26.getDate(10L);
    var22.addException(var28);
    org.jfree.chart.axis.SegmentedTimeline var30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var31 = var30.getBaseTimeline();
    boolean var34 = var31.containsDomainRange((-1L), 10L);
    long var35 = var31.getSegmentsExcludedSize();
    int var36 = var31.getSegmentsIncluded();
    org.jfree.chart.axis.SegmentedTimeline var37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var38 = var37.getBaseTimeline();
    java.util.Date var40 = var38.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var42 = var41.getBaseTimeline();
    java.util.Date var44 = var42.getDate(10L);
    var38.addException(var44);
    boolean var46 = var31.containsDomainValue(var44);
    org.jfree.data.time.DateRange var47 = new org.jfree.data.time.DateRange(var28, var44);
    org.jfree.data.gantt.Task var48 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", var19, var44);
    var1.remove(var48);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.gantt.Task var51 = var48.getSubtask(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);

  }

  public void test307() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLabelAngle(0.2d);
    var1.setLabel("ChartEntity: tooltip = null");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var8.setBaseCreateEntities(false);
    java.lang.Boolean var12 = null;
    var8.setSeriesVisibleInLegend(0, var12, true);
    boolean var15 = var8.getAutoPopulateSeriesStroke();
    java.awt.Shape var17 = var8.lookupSeriesShape((-2));
    java.awt.Shape var21 = org.jfree.chart.util.ShapeUtilities.rotateShape(var17, 4.0d, 10.0f, 10.0f);
    org.jfree.chart.entity.AxisLabelEntity var24 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var1, var17, "ChartEntity: tooltip = null", "java.awt.Color[r=0,g=0,b=15]");
    var1.setTickLabelsVisible(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesFillPaint();
    java.lang.Object var6 = var2.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var9.setBaseCreateEntities(false);
    java.lang.Boolean var13 = null;
    var9.setSeriesVisibleInLegend(0, var13, true);
    boolean var16 = var9.getAutoPopulateSeriesStroke();
    java.awt.Shape var18 = var9.lookupSeriesShape((-2));
    boolean var20 = var9.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var21 = var9.getBasePositiveItemLabelPosition();
    var2.setBasePositiveItemLabelPosition(var21, false);
    org.jfree.chart.urls.StandardCategoryURLGenerator var24 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    boolean var30 = var27.getAutoPopulateSeriesFillPaint();
    java.lang.Object var31 = var27.clone();
    boolean var32 = var27.getBaseItemLabelsVisible();
    boolean var33 = var24.equals((java.lang.Object)var32);
    var2.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var24, false);
    org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var38 = var36.equals((java.lang.Object)(-1));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var41 = var24.generateURL((org.jfree.data.category.CategoryDataset)var36, 0, 2);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var3 = var1.getRowKey(15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
//     boolean var4 = var2.equals((java.lang.Object)0.0f);
//     java.lang.Object var5 = null;
//     boolean var6 = var2.equals(var5);
//     java.awt.Font var7 = var0.getTickLabelFont((java.lang.Comparable)var6);
//     org.jfree.chart.axis.CategoryAnchor var8 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var14 = null;
//     var13.axisChanged(var14);
//     java.awt.Paint var16 = var13.getRangeZeroBaselinePaint();
//     var12.setBackgroundPaint(var16);
//     org.jfree.chart.util.RectangleEdge var18 = var12.getDomainAxisEdge();
//     org.jfree.chart.util.RectangleEdge var19 = var12.getDomainAxisEdge();
//     double var20 = var0.getCategoryJava2DCoordinate(var8, (-459), 14, var11, var19);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.plot.PlotRenderingInfo var2 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var3 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var2);
    java.awt.geom.Rectangle2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.CategoryAxis3D var6 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.CategoryLabelPositions var7 = var6.getCategoryLabelPositions();
    org.jfree.chart.axis.ValueAxis var8 = null;
    org.jfree.data.gantt.TaskSeriesCollection var9 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var10 = null;
    boolean var11 = var9.hasListener(var10);
    org.jfree.data.Range var12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var9);
    org.jfree.data.general.DatasetGroup var13 = var9.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var1, var3, var4, var5, (org.jfree.chart.axis.CategoryAxis)var6, var8, (org.jfree.data.category.CategoryDataset)var9, (-459), 2, 1);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    boolean var4 = var1.containsDomainRange((-1L), 10L);
    long var5 = var1.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var7 = var6.getBaseTimeline();
    long var8 = var6.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline.Segment var10 = var6.getSegment(172800000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setBaseTimeline(var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.jfree.chart.util.StrokeList var0 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var2.axisChanged(var3);
    java.awt.Paint var5 = var2.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var6 = null;
    var2.notifyListeners(var6);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var12 = var10.lookupSeriesStroke(1);
    var2.setDomainCrosshairStroke(var12);
    org.jfree.chart.plot.PiePlot3D var14 = new org.jfree.chart.plot.PiePlot3D();
    double var15 = var14.getShadowXOffset();
    var14.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
    var14.setLabelLinkStroke(var22);
    var2.setDomainGridlineStroke(var22);
    var0.setStroke(12, var22);
    java.lang.Object var26 = var0.clone();
    org.jfree.chart.renderer.category.LineRenderer3D var29 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var32 = var29.getItemShapeFilled(1, (-2));
    java.awt.Shape var37 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var42 = var40.lookupSeriesStroke(1);
    java.awt.Paint var44 = var40.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var46 = var45.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var51 = var49.lookupSeriesStroke(1);
    java.awt.Paint var53 = var49.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var37, var44, var46, var53);
    var29.setBaseFillPaint(var53, false);
    org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var58 = null;
    var57.axisChanged(var58);
    java.awt.Paint var60 = var57.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var61 = null;
    var57.notifyListeners(var61);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var67 = var65.lookupSeriesStroke(1);
    var57.setDomainCrosshairStroke(var67);
    org.jfree.chart.plot.ValueMarker var69 = new org.jfree.chart.plot.ValueMarker((-3.0d), var53, var67);
    java.awt.Paint var70 = var69.getOutlinePaint();
    java.awt.Paint var71 = var69.getOutlinePaint();
    boolean var73 = var69.equals((java.lang.Object)0L);
    java.awt.Stroke var74 = var69.getStroke();
    var0.setStroke(5, var74);
    java.io.ObjectOutputStream var76 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writeStroke(var74, var76);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    java.awt.Graphics2D var2 = null;
    java.awt.geom.Rectangle2D var3 = null;
    java.lang.Object var4 = null;
    java.lang.Object var5 = var0.draw(var2, var3, var4);
    var0.setText("ThreadContext");
    org.jfree.chart.event.TitleChangeListener var8 = null;
    var0.addChangeListener(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setInverted(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setRangeAboutValue((-3.0d), (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     boolean var9 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Shape var11 = var2.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
//     java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
//     java.awt.Shape var24 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
//     java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
//     java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
//     java.awt.Shape var42 = var41.getLine();
//     org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
//     var19.setLine(var42);
//     java.awt.Paint var47 = var19.getFillPaint();
//     boolean var48 = var19.isShapeVisible();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var51.setBaseCreateEntities(false);
//     java.lang.Boolean var55 = null;
//     var51.setSeriesVisibleInLegend(0, var55, true);
//     boolean var58 = var51.getAutoPopulateSeriesStroke();
//     java.awt.Shape var60 = var51.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var65 = var63.lookupSeriesStroke(1);
//     java.awt.Paint var67 = var63.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var68 = new org.jfree.chart.title.LegendGraphic(var60, var67);
//     java.awt.Shape var73 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var78 = var76.lookupSeriesStroke(1);
//     java.awt.Paint var80 = var76.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var81 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var82 = var81.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var85 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var87 = var85.lookupSeriesStroke(1);
//     java.awt.Paint var89 = var85.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var90 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var73, var80, var82, var89);
//     java.awt.Shape var91 = var90.getLine();
//     org.jfree.chart.entity.ChartEntity var94 = new org.jfree.chart.entity.ChartEntity(var91, "hi!", "hi!");
//     var68.setLine(var91);
//     java.awt.Paint var96 = var68.getLinePaint();
//     org.jfree.chart.util.GradientPaintTransformer var97 = var68.getFillPaintTransformer();
//     var19.setFillPaintTransformer(var97);
//     
//     // Checks the contract:  equals-hashcode on var32 and var81
//     assertTrue("Contract failed: equals-hashcode on var32 and var81", var32.equals(var81) ? var32.hashCode() == var81.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var81 and var32
//     assertTrue("Contract failed: equals-hashcode on var81 and var32", var81.equals(var32) ? var81.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var41 and var90
//     assertTrue("Contract failed: equals-hashcode on var41 and var90", var41.equals(var90) ? var41.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var41
//     assertTrue("Contract failed: equals-hashcode on var90 and var41", var90.equals(var41) ? var90.hashCode() == var41.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var45 and var94
//     assertTrue("Contract failed: equals-hashcode on var45 and var94", var45.equals(var94) ? var45.hashCode() == var94.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var94 and var45
//     assertTrue("Contract failed: equals-hashcode on var94 and var45", var94.equals(var45) ? var94.hashCode() == var45.hashCode() : true);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var13 = null;
//     java.awt.geom.Rectangle2D var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     org.jfree.chart.entity.EntityCollection var16 = null;
//     org.jfree.chart.ChartRenderingInfo var17 = new org.jfree.chart.ChartRenderingInfo(var16);
//     var12.draw(var13, var14, var15, var17);
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    org.jfree.chart.util.ShapeList var0 = new org.jfree.chart.util.ShapeList();
    java.awt.Shape var2 = var0.getShape(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    var0.setDomainZeroBaselineVisible(false);
    java.util.List var7 = var0.getAnnotations();
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
    org.jfree.data.general.SeriesChangeEvent var10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var9);
    org.jfree.data.gantt.TaskSeriesCollection var11 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var12 = var9.equals((java.lang.Object)var11);
    java.lang.String var13 = var9.toString();
    double var15 = var9.calculateTopInset(100.0d);
    var0.setAxisOffset(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"+ "'", var13.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1.0d);

  }

  public void test320() {}
//   public void test320() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.general.DatasetGroup var5 = var3.getGroup();
//     var3.removeAll();
//     org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, 0);
//     org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
//     org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var13 = var10.equals((java.lang.Object)var12);
//     org.jfree.data.general.DatasetGroup var14 = var12.getGroup();
//     var3.setGroup(var14);
//     
//     // Checks the contract:  equals-hashcode on var3 and var12
//     assertTrue("Contract failed: equals-hashcode on var3 and var12", var3.equals(var12) ? var3.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var3
//     assertTrue("Contract failed: equals-hashcode on var12 and var3", var12.equals(var3) ? var12.hashCode() == var3.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var14
//     assertTrue("Contract failed: equals-hashcode on var5 and var14", var5.equals(var14) ? var5.hashCode() == var14.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var14 and var5
//     assertTrue("Contract failed: equals-hashcode on var14 and var5", var14.equals(var5) ? var14.hashCode() == var5.hashCode() : true);
// 
//   }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    var0.setLabelLinkStroke(var8);
    var0.setCircular(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
//     org.jfree.chart.event.TitleChangeListener var3 = null;
//     var1.addChangeListener(var3);
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     java.awt.geom.Rectangle2D var6 = null;
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.geom.Rectangle2D var8 = var0.shrink(var6, var7);
// 
//   }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    java.text.NumberFormat var1 = var0.getNumberFormat();
    java.text.NumberFormat var2 = var0.getNumberFormat();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var5.setBaseCreateEntities(false);
    java.lang.Boolean var9 = null;
    var5.setSeriesVisibleInLegend(0, var9, true);
    int var12 = var5.getPassCount();
    java.lang.Boolean var14 = var5.getSeriesVisibleInLegend((-1));
    java.awt.Graphics2D var15 = null;
    org.jfree.chart.plot.PlotRenderingInfo var16 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var17 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var16);
    java.awt.geom.Rectangle2D var18 = null;
    org.jfree.chart.plot.CategoryPlot var19 = null;
    org.jfree.chart.axis.CategoryAxis var20 = null;
    org.jfree.chart.axis.ValueAxis var21 = null;
    org.jfree.data.gantt.TaskSeriesCollection var22 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var24 = var22.getSeries((java.lang.Comparable)"hi!");
    var5.drawItem(var15, var17, var18, var19, var20, var21, (org.jfree.data.category.CategoryDataset)var22, (-2), (-459), 10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var30 = var0.generateColumnLabel((org.jfree.data.category.CategoryDataset)var22, 14);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var24);

  }

  public void test325() {}
//   public void test325() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     org.jfree.chart.plot.DatasetRenderingOrder var6 = var0.getDatasetRenderingOrder();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var11 = var9.lookupSeriesStroke(1);
//     java.awt.Paint var13 = var9.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var16 = null;
//     var15.axisChanged(var16);
//     java.awt.Paint var18 = var15.getRangeZeroBaselinePaint();
//     var9.setSeriesItemLabelPaint(100, var18, false);
//     java.awt.Paint var21 = var9.getBaseItemLabelPaint();
//     boolean var22 = var6.equals((java.lang.Object)var9);
//     
//     // Checks the contract:  equals-hashcode on var1 and var15
//     assertTrue("Contract failed: equals-hashcode on var1 and var15", var1.equals(var15) ? var1.hashCode() == var15.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var15 and var1
//     assertTrue("Contract failed: equals-hashcode on var15 and var1", var15.equals(var1) ? var15.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
    org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var4 = var1.equals((java.lang.Object)var3);
    org.jfree.data.general.DatasetGroup var5 = var3.getGroup();
    var3.removeAll();
    org.jfree.data.general.PieDataset var8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var3, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var10 = var3.getColumnKey(5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10.0d, (java.lang.Number)0L);
    org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    boolean var9 = var6.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var15 = null;
    var13.setSeriesItemLabelGenerator(2, var15);
    java.awt.Font var17 = var13.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var18 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var17);
    var6.setBaseItemLabelFont(var17);
    var3.setLabelFont(var17);
    boolean var21 = var2.equals((java.lang.Object)var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers((-459), var5);
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
    var0.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var11 = null;
    var10.setTickUnit(var11);
    java.util.Date var13 = var10.getMaximumDate();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var10);
    java.util.TimeZone var15 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.setTimeZone(var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test329() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    var2.setAutoPopulateSeriesOutlineStroke(true);
    var2.setUseOutlinePaint(true);
    boolean var13 = var2.getBaseSeriesVisible();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    boolean var19 = var16.getAutoPopulateSeriesFillPaint();
    java.lang.Object var20 = var16.clone();
    org.jfree.chart.labels.ItemLabelPosition var21 = var16.getBaseNegativeItemLabelPosition();
    var2.setBaseNegativeItemLabelPosition(var21);
    org.jfree.chart.plot.CategoryPlot var23 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setPlot(var23);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test330() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    long var2 = var0.getSegmentsExcludedSize();
    long var3 = var0.getSegmentSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 900000L);

  }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
    var2.setSeriesItemLabelPaint(100, var11, false);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var15 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var2.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var15, true);
    boolean var18 = var2.getAutoPopulateSeriesOutlineStroke();
    boolean var19 = var2.getUseOutlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var21 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var22 = var21.getYOffset();
    org.jfree.chart.labels.ItemLabelPosition var23 = var21.getBasePositiveItemLabelPosition();
    var2.setSeriesNegativeItemLabelPosition(15, var23);
    double var25 = var23.getAngle();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0.0d);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.jfree.data.Range var0 = null;
    org.jfree.data.Range var1 = null;
    org.jfree.data.Range var3 = org.jfree.data.Range.expandToInclude(var1, 0.0d);
    org.jfree.chart.block.RectangleConstraint var4 = new org.jfree.chart.block.RectangleConstraint(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var3 = var0.getItemShapeFilled(1, (-2));
//     boolean var5 = var0.equals((java.lang.Object)(-1.0d));
//     java.awt.Graphics2D var6 = null;
//     org.jfree.chart.plot.CategoryPlot var7 = null;
//     java.awt.geom.Rectangle2D var8 = null;
//     var0.drawBackground(var6, var7, var8);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    java.lang.Object var4 = var0.clone();
    org.jfree.chart.annotations.XYAnnotation var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var6 = var0.removeAnnotation(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.jfree.chart.axis.NumberAxis var0 = new org.jfree.chart.axis.NumberAxis();
    java.awt.Shape var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLeftArrow(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.event.TitleChangeListener var2 = null;
//     var0.addChangeListener(var2);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
//     java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
//     var0.setBackgroundPaint(var10);
//     var0.setExpandToFitSpace(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var16.axisChanged(var17);
//     java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
//     java.lang.Object var21 = var0.draw(var14, var15, (java.lang.Object)var20);
//     java.lang.String var22 = var0.getURLText();
//     org.jfree.chart.event.ChartChangeEvent var23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)var0);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var28 = var26.lookupSeriesStroke(1);
//     java.awt.Paint var30 = var26.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var32.axisChanged(var33);
//     java.awt.Paint var35 = var32.getRangeZeroBaselinePaint();
//     var26.setSeriesItemLabelPaint(100, var35, false);
//     var0.setPaint(var35);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var6 and var26.", var6.equals(var26) == var26.equals(var6));
//     
//     // Checks the contract:  equals-hashcode on var16 and var32
//     assertTrue("Contract failed: equals-hashcode on var16 and var32", var16.equals(var32) ? var16.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var16
//     assertTrue("Contract failed: equals-hashcode on var32 and var16", var32.equals(var16) ? var32.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    java.awt.Paint var6 = var2.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var9 = null;
    var8.axisChanged(var9);
    java.awt.Paint var11 = var8.getRangeZeroBaselinePaint();
    var2.setSeriesItemLabelPaint(100, var11, false);
    org.jfree.chart.plot.CategoryPlot var14 = var2.getPlot();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-1), (java.lang.Boolean)true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var6 = var3.getItemShapeFilled(1, (-2));
    boolean var8 = var3.equals((java.lang.Object)(-1.0d));
    var3.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var14 = var3.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var15 = var14.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var17 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var1, var2, var15, 100.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var20.setBaseCreateEntities(false);
    java.lang.Boolean var24 = null;
    var20.setSeriesVisibleInLegend(0, var24, true);
    boolean var27 = var20.getAutoPopulateSeriesStroke();
    java.awt.Shape var29 = var20.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var34 = var32.lookupSeriesStroke(1);
    java.awt.Paint var36 = var32.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var37 = new org.jfree.chart.title.LegendGraphic(var29, var36);
    org.jfree.chart.util.RectangleAnchor var38 = var37.getShapeAnchor();
    boolean var39 = var17.equals((java.lang.Object)var37);
    var37.setShapeFilled(true);
    org.jfree.chart.plot.PiePlot var42 = new org.jfree.chart.plot.PiePlot();
    org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var46 = var44.getPreviousDayOfWeek(1);
    org.jfree.chart.axis.CategoryLabelPositions var47 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var49 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var50 = null;
    var49.axisChanged(var50);
    java.awt.Paint var52 = var49.getRangeZeroBaselinePaint();
    var48.setBackgroundPaint(var52);
    org.jfree.chart.renderer.xy.XYItemRenderer var54 = var48.getRenderer();
    java.awt.Stroke var55 = var48.getDomainZeroBaselineStroke();
    org.jfree.chart.event.PlotChangeListener var56 = null;
    var48.removeChangeListener(var56);
    java.awt.Paint var58 = var48.getRangeCrosshairPaint();
    boolean var59 = var47.equals((java.lang.Object)var58);
    var42.setSectionPaint((java.lang.Comparable)var46, var58);
    var37.setOutlinePaint(var58);
    boolean var62 = var37.isShapeVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);

  }

  public void test339() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    java.awt.Graphics2D var2 = null;
    org.jfree.data.time.DateRange var5 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var7 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var5, 100.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var8 = var0.arrange(var1, var2, var7);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }

  }

  public void test340() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(14, 255, 1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    org.jfree.data.general.DatasetGroup var1 = new org.jfree.data.general.DatasetGroup("");

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    var0.addOptionalLibrary("ChartEntity: tooltip = null");
    java.awt.Image var3 = var0.getLogo();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var5 = var3.lookupSeriesStroke(1);
//     boolean var6 = var3.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var7 = var3.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var10.setBaseCreateEntities(false);
//     java.lang.Boolean var14 = null;
//     var10.setSeriesVisibleInLegend(0, var14, true);
//     boolean var17 = var10.getAutoPopulateSeriesStroke();
//     java.awt.Shape var19 = var10.lookupSeriesShape((-2));
//     boolean var21 = var10.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var22 = var10.getBasePositiveItemLabelPosition();
//     var3.setBasePositiveItemLabelPosition(var22, false);
//     var0.setBaseNegativeItemLabelPosition(var22, true);
//     java.awt.Graphics2D var27 = null;
//     org.jfree.chart.plot.CategoryPlot var28 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var31.setBaseCreateEntities(false);
//     java.lang.Boolean var35 = null;
//     var31.setSeriesVisibleInLegend(0, var35, true);
//     boolean var38 = var31.getAutoPopulateSeriesStroke();
//     java.awt.Shape var40 = var31.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
//     java.awt.Paint var47 = var43.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic(var40, var47);
//     java.awt.Shape var53 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var58 = var56.lookupSeriesStroke(1);
//     java.awt.Paint var60 = var56.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var62 = var61.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var67 = var65.lookupSeriesStroke(1);
//     java.awt.Paint var69 = var65.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var53, var60, var62, var69);
//     java.awt.Shape var71 = var70.getLine();
//     org.jfree.chart.entity.ChartEntity var74 = new org.jfree.chart.entity.ChartEntity(var71, "hi!", "hi!");
//     var48.setLine(var71);
//     java.awt.Paint var76 = var48.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var78 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var81 = var78.isBefore(var80);
//     boolean var82 = var48.equals((java.lang.Object)var81);
//     java.awt.Shape var83 = var48.getLine();
//     java.awt.geom.Rectangle2D var84 = var48.getBounds();
//     var0.drawDomainGridline(var27, var28, var84, 0.05d);
// 
//   }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis[] var6 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var8.addChangeListener(var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    var8.setBackgroundPaint(var18);
    var0.setBackgroundPaint(var18);
    boolean var21 = var0.isDomainGridlinesVisible();
    org.jfree.chart.axis.NumberAxis3D var24 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var24.setLabelAngle(0.2d);
    var24.setLowerBound(12.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeAxis((-459), (org.jfree.chart.axis.ValueAxis)var24, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    java.awt.Color var1 = java.awt.Color.getColor("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     java.awt.Graphics2D var13 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var16.setBaseCreateEntities(false);
//     java.lang.Boolean var20 = null;
//     var16.setSeriesVisibleInLegend(0, var20, true);
//     boolean var23 = var16.getAutoPopulateSeriesStroke();
//     java.awt.Shape var25 = var16.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var30 = var28.lookupSeriesStroke(1);
//     java.awt.Paint var32 = var28.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var33 = new org.jfree.chart.title.LegendGraphic(var25, var32);
//     java.awt.Shape var38 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var43 = var41.lookupSeriesStroke(1);
//     java.awt.Paint var45 = var41.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var47 = var46.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var52 = var50.lookupSeriesStroke(1);
//     java.awt.Paint var54 = var50.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var55 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var38, var45, var47, var54);
//     java.awt.Shape var56 = var55.getLine();
//     org.jfree.chart.entity.ChartEntity var59 = new org.jfree.chart.entity.ChartEntity(var56, "hi!", "hi!");
//     var33.setLine(var56);
//     java.awt.Paint var61 = var33.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var63 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var65 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var66 = var63.isBefore(var65);
//     boolean var67 = var33.equals((java.lang.Object)var66);
//     java.awt.Shape var68 = var33.getLine();
//     java.awt.geom.Rectangle2D var69 = var33.getBounds();
//     org.jfree.chart.plot.PlotRenderingInfo var70 = null;
//     var1.drawAnnotations(var13, var69, var70);
//     
//     // Checks the contract:  equals-hashcode on var1 and var46
//     assertTrue("Contract failed: equals-hashcode on var1 and var46", var1.equals(var46) ? var1.hashCode() == var46.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var46 and var1
//     assertTrue("Contract failed: equals-hashcode on var46 and var1", var46.equals(var1) ? var46.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     org.jfree.chart.title.TextTitle var3 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var4 = var3.getPadding();
//     org.jfree.chart.event.TitleChangeListener var5 = null;
//     var3.addChangeListener(var5);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var11 = var9.lookupSeriesStroke(1);
//     java.awt.Paint var13 = var9.lookupSeriesOutlinePaint(10);
//     var3.setBackgroundPaint(var13);
//     var3.setExpandToFitSpace(false);
//     java.awt.Graphics2D var17 = null;
//     java.awt.geom.Rectangle2D var18 = null;
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var19.axisChanged(var20);
//     java.awt.Paint var22 = var19.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var23 = var19.getRangeAxisEdge();
//     java.lang.Object var24 = var3.draw(var17, var18, (java.lang.Object)var23);
//     java.awt.Paint var25 = var3.getBackgroundPaint();
//     var0.setDomainTickBandPaint(var25);
//     
//     // Checks the contract:  equals-hashcode on var0 and var19
//     assertTrue("Contract failed: equals-hashcode on var0 and var19", var0.equals(var19) ? var0.hashCode() == var19.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var19 and var0
//     assertTrue("Contract failed: equals-hashcode on var19 and var0", var19.equals(var0) ? var19.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test348() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var7 = null;
    boolean var8 = var6.hasListener(var7);
    int var10 = var6.getRowIndex((java.lang.Comparable)0L);
    java.util.List var11 = var6.getRowKeys();
    boolean var12 = var0.equals((java.lang.Object)var6);
    java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var17 = var6.getSubIntervalCount(0, 15);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     org.jfree.data.xy.TableXYDataset var0 = null;
//     double var2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(var0, 0);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var2 = var0.getSeries((java.lang.Comparable)"hi!");
    java.lang.Number var3 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.general.PieDataset var5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var0, (java.lang.Comparable)1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var0.getStartValue(14, 14, 5);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0.0d+ "'", var3.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test351() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    int var4 = var3.getSeriesCount();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    var3.drawBackgroundImage(var5, var6);
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var9.addChangeListener(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
    java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
    var9.setBackgroundPaint(var19);
    java.awt.Paint var21 = var9.getPaint();
    var3.setRangeTickBandPaint(var21);
    org.jfree.chart.renderer.xy.XYItemRenderer var23 = null;
    var3.setRenderer(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     org.jfree.chart.labels.IntervalCategoryToolTipGenerator var0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
//     java.text.NumberFormat var1 = var0.getNumberFormat();
//     org.jfree.data.category.CategoryDataset var2 = null;
//     java.lang.String var4 = var0.generateRowLabel(var2, 0);
// 
//   }

  public void test353() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.event.TitleChangeListener var2 = null;
    var0.addChangeListener(var2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
    java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
    var0.setBackgroundPaint(var10);
    var0.setExpandToFitSpace(false);
    double var14 = var0.getContentYOffset();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1.0d);

  }

  public void test354() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    boolean var5 = var2.getBaseSeriesVisibleInLegend();
    int var6 = var2.getPassCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);

  }

  public void test355() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var9 = null;
    var7.setSeriesItemLabelGenerator(2, var9);
    java.awt.Font var11 = var7.getBaseItemLabelFont();
    java.lang.Boolean var13 = var7.getSeriesVisibleInLegend(100);
    java.awt.Stroke var16 = var7.getItemStroke(15, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
    boolean var22 = var19.getAutoPopulateSeriesFillPaint();
    java.lang.Object var23 = var19.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var26.setBaseCreateEntities(false);
    java.lang.Boolean var30 = null;
    var26.setSeriesVisibleInLegend(0, var30, true);
    boolean var33 = var26.getAutoPopulateSeriesStroke();
    java.awt.Shape var35 = var26.lookupSeriesShape((-2));
    boolean var37 = var26.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var38 = var26.getBasePositiveItemLabelPosition();
    var19.setBasePositiveItemLabelPosition(var38, false);
    var7.setBasePositiveItemLabelPosition(var38);
    boolean var42 = var4.equals((java.lang.Object)var7);
    var7.setBaseSeriesVisibleInLegend(false);
    java.awt.Paint var45 = var7.getBaseItemLabelPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
//     org.jfree.chart.event.TitleChangeListener var3 = null;
//     var1.addChangeListener(var3);
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var7 = null;
//     boolean var8 = var6.hasListener(var7);
//     int var10 = var6.getRowIndex((java.lang.Comparable)0L);
//     java.util.List var11 = var6.getRowKeys();
//     boolean var12 = var0.equals((java.lang.Object)var6);
//     java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
//     org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var6);
//     java.awt.Graphics2D var15 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var18.setBaseCreateEntities(false);
//     java.lang.Boolean var22 = null;
//     var18.setSeriesVisibleInLegend(0, var22, true);
//     boolean var25 = var18.getAutoPopulateSeriesStroke();
//     java.awt.Shape var27 = var18.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var32 = var30.lookupSeriesStroke(1);
//     java.awt.Paint var34 = var30.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var35 = new org.jfree.chart.title.LegendGraphic(var27, var34);
//     java.awt.Shape var40 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
//     java.awt.Paint var47 = var43.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var48 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var49 = var48.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var54 = var52.lookupSeriesStroke(1);
//     java.awt.Paint var56 = var52.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var57 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var40, var47, var49, var56);
//     java.awt.Shape var58 = var57.getLine();
//     org.jfree.chart.entity.ChartEntity var61 = new org.jfree.chart.entity.ChartEntity(var58, "hi!", "hi!");
//     var35.setLine(var58);
//     java.awt.Paint var63 = var35.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var65 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var67 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var68 = var65.isBefore(var67);
//     boolean var69 = var35.equals((java.lang.Object)var68);
//     java.awt.Shape var70 = var35.getLine();
//     java.awt.geom.Rectangle2D var71 = var35.getBounds();
//     java.awt.geom.Point2D var72 = null;
//     org.jfree.chart.plot.PlotState var73 = null;
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = new org.jfree.chart.plot.PlotRenderingInfo(var74);
//     var14.draw(var15, var71, var72, var73, var75);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var13 = var12.getTitle();
    org.jfree.chart.entity.EntityCollection var17 = null;
    org.jfree.chart.ChartRenderingInfo var18 = new org.jfree.chart.ChartRenderingInfo(var17);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var19 = var12.createBufferedImage(0, 255, 5, var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test358() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var6 = var0.getPercentComplete((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=15]", (java.lang.Comparable)(-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);

  }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.block.BlockBorder var2 = new org.jfree.chart.block.BlockBorder();
    var0.setFrame((org.jfree.chart.block.BlockFrame)var2);
    double var4 = var0.getHeight();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "May"+ "'", var1.equals("May"));

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.chart.block.BlockContainer var1 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var2 = var1.clone();
    java.awt.Graphics2D var3 = null;
    org.jfree.chart.block.RectangleConstraint var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var5 = var0.arrange(var1, var3, var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
    org.jfree.chart.block.BlockBorder var2 = new org.jfree.chart.block.BlockBorder();
    var0.setFrame((org.jfree.chart.block.BlockFrame)var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.data.Range var5 = null;
    org.jfree.data.Range var7 = org.jfree.data.Range.expandToInclude(var5, 0.0d);
    org.jfree.chart.block.RectangleConstraint var9 = new org.jfree.chart.block.RectangleConstraint(var5, 10.0d);
    double var10 = var9.getHeight();
    org.jfree.chart.block.LengthConstraintType var11 = var9.getHeightConstraintType();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.Size2D var12 = var0.arrange(var4, var9);
      fail("Expected exception of type java.lang.RuntimeException");
    } catch (java.lang.RuntimeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    org.jfree.chart.renderer.category.BoxAndWhiskerRenderer var0 = new org.jfree.chart.renderer.category.BoxAndWhiskerRenderer();
    org.jfree.chart.plot.DrawingSupplier var1 = var0.getDrawingSupplier();
    org.jfree.data.time.DateRange var4 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var6 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var4, 100.0d);
    boolean var7 = var0.equals((java.lang.Object)var4);
    var0.setItemMargin(8.0d);
    java.awt.Graphics2D var10 = null;
    org.jfree.chart.plot.PlotRenderingInfo var11 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var15.setBaseCreateEntities(false);
    java.lang.Boolean var19 = null;
    var15.setSeriesVisibleInLegend(0, var19, true);
    boolean var22 = var15.getAutoPopulateSeriesStroke();
    java.awt.Shape var24 = var15.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var32 = new org.jfree.chart.title.LegendGraphic(var24, var31);
    java.awt.Shape var37 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var42 = var40.lookupSeriesStroke(1);
    java.awt.Paint var44 = var40.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var46 = var45.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var51 = var49.lookupSeriesStroke(1);
    java.awt.Paint var53 = var49.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var54 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var37, var44, var46, var53);
    java.awt.Shape var55 = var54.getLine();
    org.jfree.chart.entity.ChartEntity var58 = new org.jfree.chart.entity.ChartEntity(var55, "hi!", "hi!");
    var32.setLine(var55);
    java.awt.Paint var60 = var32.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var62 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var65 = var62.isBefore(var64);
    boolean var66 = var32.equals((java.lang.Object)var65);
    java.awt.Shape var67 = var32.getLine();
    java.awt.geom.Rectangle2D var68 = var32.getBounds();
    org.jfree.chart.plot.CategoryPlot var69 = null;
    org.jfree.chart.axis.CategoryAxis3D var70 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.plot.Plot var71 = var70.getPlot();
    org.jfree.chart.axis.NumberAxis3D var73 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    org.jfree.data.gantt.TaskSeriesCollection var74 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var75 = null;
    boolean var76 = var74.hasListener(var75);
    int var78 = var74.getRowIndex((java.lang.Comparable)0L);
    java.util.List var79 = var74.getRowKeys();
    org.jfree.chart.axis.NumberAxis3D var81 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var81.setLabelAngle(0.2d);
    var81.setLowerBound(12.0d);
    var81.setLowerBound(0.0d);
    var81.setTickMarksVisible(true);
    boolean var90 = var81.isPositiveArrowVisible();
    boolean var91 = var74.equals((java.lang.Object)var90);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.drawItem(var10, var12, var68, var69, (org.jfree.chart.axis.CategoryAxis)var70, (org.jfree.chart.axis.ValueAxis)var73, (org.jfree.data.category.CategoryDataset)var74, 12, 14, (-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == false);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 100);
    var0.setDataset(var6);
    double var8 = var0.getShadowYOffset();
    double var9 = var0.getDepthFactor();
    org.jfree.chart.labels.PieSectionLabelGenerator var10 = var0.getLegendLabelGenerator();
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var12 = var11.getFixedDomainAxisSpace();
    org.jfree.chart.plot.DrawingSupplier var13 = null;
    var11.setDrawingSupplier(var13);
    org.jfree.chart.util.Layer var16 = null;
    java.util.Collection var17 = var11.getDomainMarkers(100, var16);
    java.awt.Paint var18 = var11.getRangeGridlinePaint();
    var0.setBaseSectionOutlinePaint(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var5 = null;
    var1.notifyListeners(var5);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var11 = var9.lookupSeriesStroke(1);
    var1.setDomainCrosshairStroke(var11);
    org.jfree.chart.plot.PiePlot3D var13 = new org.jfree.chart.plot.PiePlot3D();
    double var14 = var13.getShadowXOffset();
    var13.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
    var13.setLabelLinkStroke(var21);
    var1.setDomainGridlineStroke(var21);
    var0.setRangeGridlineStroke(var21);
    org.jfree.data.xy.XYDataset var25 = null;
    var0.setDataset(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    int var3 = var2.getSeriesCount();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var2.drawBackgroundImage(var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var2.zoomRangeAxes((-1.0d), var8, var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var2.removeChangeListener(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.title.TextTitle var14 = var13.getTitle();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
    java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var23.axisChanged(var24);
    java.awt.Paint var26 = var23.getRangeZeroBaselinePaint();
    var17.setSeriesItemLabelPaint(100, var26, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var14, (java.lang.Object)var17);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test367() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.jfree.chart.util.HorizontalAlignment var0 = null;
//     org.jfree.chart.util.VerticalAlignment var1 = null;
//     org.jfree.chart.block.FlowArrangement var4 = new org.jfree.chart.block.FlowArrangement(var0, var1, (-3.0d), 0.0d);
//     java.lang.Object var5 = null;
//     boolean var6 = var4.equals(var5);
//     org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var8 = null;
//     boolean var9 = var7.hasListener(var8);
//     int var11 = var7.getRowIndex((java.lang.Comparable)0L);
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
//     var7.seriesChanged(var14);
//     int var16 = var7.getRowCount();
//     boolean var17 = var4.equals((java.lang.Object)var16);
//     org.jfree.chart.block.BlockContainer var18 = null;
//     java.awt.Graphics2D var19 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var22.setBaseCreateEntities(false);
//     java.lang.Boolean var26 = null;
//     var22.setSeriesVisibleInLegend(0, var26, true);
//     boolean var29 = var22.getAutoPopulateSeriesStroke();
//     java.awt.Shape var31 = var22.lookupSeriesShape((-2));
//     boolean var33 = var22.isSeriesVisibleInLegend(1);
//     org.jfree.data.time.DateRange var36 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
//     org.jfree.chart.block.RectangleConstraint var38 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var36, 100.0d);
//     org.jfree.chart.block.LengthConstraintType var39 = var38.getHeightConstraintType();
//     boolean var40 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var22, (java.lang.Object)var38);
//     org.jfree.chart.util.Size2D var41 = var4.arrange(var18, var19, var38);
// 
//   }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    org.jfree.chart.util.RectangleInsets var0 = new org.jfree.chart.util.RectangleInsets();
    double var1 = var0.getLeft();
    org.jfree.chart.renderer.category.LineRenderer3D var2 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var2.setBaseSeriesVisible(false);
    var2.setBaseCreateEntities(false, false);
    java.lang.Boolean var9 = null;
    var2.setSeriesShapesFilled(12, var9);
    java.awt.Paint var12 = var2.lookupSeriesPaint(5);
    org.jfree.chart.block.BlockBorder var13 = new org.jfree.chart.block.BlockBorder(var0, var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test370() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }


    java.awt.Color var2 = java.awt.Color.getColor("RectangleEdge.TOP", 0);
    float[] var9 = new float[] { 100.0f, 10.0f, (-1.0f)};
    float[] var10 = java.awt.Color.RGBtoHSB((-2), 14, 1900, var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var11 = var2.getRGBComponents(var9);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test371() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var3.setBaseCreateEntities(false);
    java.lang.Boolean var7 = null;
    var3.setSeriesVisibleInLegend(0, var7, true);
    boolean var10 = var3.getAutoPopulateSeriesStroke();
    java.awt.Shape var12 = var3.lookupSeriesShape((-2));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var19 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var21 = var19.equals((java.lang.Object)(-1));
    var19.validateObject();
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var27 = var24.isBefore(var26);
    int var28 = var24.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var30 = new org.jfree.chart.entity.CategoryItemEntity(var16, "hi!", "", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)var24, (java.lang.Comparable)(-3.0d));
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var35 = var32.isBefore(var34);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var39 = var37.getPreviousDayOfWeek(1);
    boolean var41 = var24.isInRange((org.jfree.data.time.SerialDate)var32, var39, 1900);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(12, (org.jfree.data.time.SerialDate)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test372() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    double var2 = var1.getMinimumBarLength();
    org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
    int var5 = var3.getColumnIndex((java.lang.Comparable)0L);
    var3.clear();
    org.jfree.data.Range var7 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var3);
    org.jfree.data.time.SpreadsheetDate var10 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = var12.getFollowingDayOfWeek(2);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var19 = var16.isBefore(var18);
    int var20 = var16.getYYYY();
    boolean var22 = var10.isInRange(var12, (org.jfree.data.time.SerialDate)var16, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var25.setBaseCreateEntities(false);
    java.lang.Boolean var29 = null;
    var25.setSeriesVisibleInLegend(0, var29, true);
    boolean var32 = var25.getAutoPopulateSeriesStroke();
    java.awt.Shape var34 = var25.lookupSeriesShape((-2));
    java.awt.Shape var38 = org.jfree.chart.util.ShapeUtilities.rotateShape(var34, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var41 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var43 = var41.equals((java.lang.Object)(-1));
    var41.validateObject();
    org.jfree.data.time.SpreadsheetDate var46 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var49 = var46.isBefore(var48);
    int var50 = var46.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var52 = new org.jfree.chart.entity.CategoryItemEntity(var38, "hi!", "", (org.jfree.data.category.CategoryDataset)var41, (java.lang.Comparable)var46, (java.lang.Comparable)(-3.0d));
    org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var57 = var54.isBefore(var56);
    org.jfree.data.time.SerialDate var59 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var61 = var59.getPreviousDayOfWeek(1);
    boolean var63 = var46.isInRange((org.jfree.data.time.SerialDate)var54, var61, 1900);
    boolean var64 = var10.isOn((org.jfree.data.time.SerialDate)var46);
    org.jfree.chart.axis.NumberTickUnit var66 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.incrementValue(10.0d, (java.lang.Comparable)var10, (java.lang.Comparable)var66);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);

  }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    java.io.ObjectInputStream var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.Stroke var1 = org.jfree.chart.util.SerialUtilities.readStroke(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.jfree.data.statistics.MeanAndStandardDeviation var2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number)10.0d, (java.lang.Number)0L);
    java.lang.Number var3 = var2.getMean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    var0.setRight(0.05d);
    java.lang.Object var8 = null;
    boolean var9 = var0.equals(var8);
    java.lang.Object var10 = var0.clone();
    org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
    var12.setWidth(0.0d);
    org.jfree.chart.util.RectangleEdge var15 = var12.getPosition();
    org.jfree.chart.util.RectangleEdge var16 = org.jfree.chart.util.RectangleEdge.opposite(var15);
    java.lang.String var17 = var16.toString();
    var0.ensureAtLeast(6.0d, var16);
    java.lang.Object var19 = null;
    boolean var20 = var0.equals(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var17 + "' != '" + "RectangleEdge.BOTTOM"+ "'", var17.equals("RectangleEdge.BOTTOM"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var1 = var0.getShadowPaint();
    boolean var2 = var0.isCircular();
    org.jfree.chart.plot.DrawingSupplier var3 = var0.getDrawingSupplier();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    org.jfree.chart.plot.PiePlot var6 = new org.jfree.chart.plot.PiePlot();
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var10 = var8.getPreviousDayOfWeek(1);
    org.jfree.chart.axis.CategoryLabelPositions var11 = new org.jfree.chart.axis.CategoryLabelPositions();
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var13.axisChanged(var14);
    java.awt.Paint var16 = var13.getRangeZeroBaselinePaint();
    var12.setBackgroundPaint(var16);
    org.jfree.chart.renderer.xy.XYItemRenderer var18 = var12.getRenderer();
    java.awt.Stroke var19 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.event.PlotChangeListener var20 = null;
    var12.removeChangeListener(var20);
    java.awt.Paint var22 = var12.getRangeCrosshairPaint();
    boolean var23 = var11.equals((java.lang.Object)var22);
    var6.setSectionPaint((java.lang.Comparable)var10, var22);
    org.jfree.data.xy.XYDataset var26 = null;
    org.jfree.chart.axis.ValueAxis var27 = null;
    org.jfree.chart.renderer.PolarItemRenderer var28 = null;
    org.jfree.chart.plot.PolarPlot var29 = new org.jfree.chart.plot.PolarPlot(var26, var27, var28);
    org.jfree.chart.plot.PlotRenderingInfo var32 = null;
    java.awt.geom.Point2D var33 = null;
    var29.zoomDomainAxes(100.0d, 0.05d, var32, var33);
    org.jfree.chart.ChartRenderingInfo var37 = null;
    org.jfree.chart.plot.PlotRenderingInfo var38 = new org.jfree.chart.plot.PlotRenderingInfo(var37);
    org.jfree.chart.ChartRenderingInfo var39 = var38.getOwner();
    java.awt.geom.Point2D var40 = null;
    var29.zoomDomainAxes(8.0d, (-3.0d), var38, var40);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PiePlotState var42 = var0.initialise(var4, var5, var6, (java.lang.Integer)12, var38);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var39);

  }

  public void test378() {}
//   public void test378() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }
// 
// 
//     org.jfree.data.Range var0 = null;
//     org.jfree.data.time.DateRange var1 = new org.jfree.data.time.DateRange(var0);
// 
//   }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     java.awt.Graphics2D var1 = null;
//     org.jfree.chart.text.TextUtilities.drawRotatedString("Polar Plot", var1, 1.0d, (-1.0f), 10.0f);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    java.util.List var1 = var0.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)false);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    org.jfree.chart.renderer.category.LevelRenderer var0 = new org.jfree.chart.renderer.category.LevelRenderer();
    java.awt.Graphics2D var1 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var4.setBaseCreateEntities(false);
    java.lang.Boolean var8 = null;
    var4.setSeriesVisibleInLegend(0, var8, true);
    boolean var11 = var4.getAutoPopulateSeriesStroke();
    java.awt.Shape var13 = var4.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var21 = new org.jfree.chart.title.LegendGraphic(var13, var20);
    java.awt.Shape var26 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
    java.awt.Paint var33 = var29.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var35 = var34.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var40 = var38.lookupSeriesStroke(1);
    java.awt.Paint var42 = var38.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var43 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var26, var33, var35, var42);
    java.awt.Shape var44 = var43.getLine();
    org.jfree.chart.entity.ChartEntity var47 = new org.jfree.chart.entity.ChartEntity(var44, "hi!", "hi!");
    var21.setLine(var44);
    java.awt.Paint var49 = var21.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var51 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var54 = var51.isBefore(var53);
    boolean var55 = var21.equals((java.lang.Object)var54);
    java.awt.Shape var56 = var21.getLine();
    java.awt.geom.Rectangle2D var57 = var21.getBounds();
    org.jfree.chart.plot.CategoryPlot var58 = null;
    org.jfree.data.xy.XYDataset var60 = null;
    org.jfree.chart.axis.ValueAxis var61 = null;
    org.jfree.chart.renderer.PolarItemRenderer var62 = null;
    org.jfree.chart.plot.PolarPlot var63 = new org.jfree.chart.plot.PolarPlot(var60, var61, var62);
    org.jfree.chart.plot.PlotRenderingInfo var66 = null;
    java.awt.geom.Point2D var67 = null;
    var63.zoomDomainAxes(100.0d, 0.05d, var66, var67);
    org.jfree.chart.ChartRenderingInfo var71 = null;
    org.jfree.chart.plot.PlotRenderingInfo var72 = new org.jfree.chart.plot.PlotRenderingInfo(var71);
    org.jfree.chart.ChartRenderingInfo var73 = var72.getOwner();
    java.awt.geom.Point2D var74 = null;
    var63.zoomDomainAxes(8.0d, (-3.0d), var72, var74);
    java.awt.geom.Rectangle2D var76 = null;
    var72.setPlotArea(var76);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.renderer.category.CategoryItemRendererState var78 = var0.initialise(var1, var57, var58, 14, var72);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var73);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var14 = null;
//     var13.removeChangeListener(var14);
//     var12.setTitle(var13);
//     int var17 = var12.getSubtitleCount();
//     java.awt.RenderingHints var18 = null;
//     var12.setRenderingHints(var18);
// 
//   }

  public void test383() {}
//   public void test383() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }
// 
// 
//     org.jfree.data.xy.XYDataset var0 = null;
//     org.jfree.chart.axis.ValueAxis var1 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var2 = null;
//     org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
//     java.lang.String var4 = var3.getPlotType();
//     java.awt.geom.Rectangle2D var7 = null;
//     java.awt.Point var8 = var3.translateValueThetaRadiusToJava2D(12.0d, 2.0d, var7);
// 
//   }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    var0.setRenderAsPercentages(false);
    java.awt.Stroke var3 = var0.getBaseStroke();
    org.jfree.chart.renderer.AreaRendererEndType var4 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setEndType(var4);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var4 = var0.getRangeAxisEdge();
//     boolean var5 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.renderer.xy.XYItemRenderer var7 = var0.getRenderer(0);
//     java.awt.Graphics2D var8 = null;
//     java.awt.geom.Rectangle2D var9 = null;
//     org.jfree.chart.renderer.category.LineRenderer3D var11 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var14 = var11.getItemShapeFilled(1, (-2));
//     java.awt.Shape var19 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var24 = var22.lookupSeriesStroke(1);
//     java.awt.Paint var26 = var22.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var28 = var27.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var33 = var31.lookupSeriesStroke(1);
//     java.awt.Paint var35 = var31.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var36 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var19, var26, var28, var35);
//     var11.setBaseFillPaint(var35, false);
//     org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var40 = null;
//     var39.axisChanged(var40);
//     java.awt.Paint var42 = var39.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var43 = null;
//     var39.notifyListeners(var43);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var49 = var47.lookupSeriesStroke(1);
//     var39.setDomainCrosshairStroke(var49);
//     org.jfree.chart.plot.ValueMarker var51 = new org.jfree.chart.plot.ValueMarker((-3.0d), var35, var49);
//     var51.setAlpha(1.0f);
//     org.jfree.chart.plot.XYPlot var54 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var55 = var54.getDomainZeroBaselineStroke();
//     var54.mapDatasetToDomainAxis(0, 2);
//     org.jfree.chart.axis.AxisSpace var59 = var54.getFixedDomainAxisSpace();
//     org.jfree.chart.axis.ValueAxis var61 = var54.getDomainAxis((-1));
//     var51.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var54);
//     java.awt.geom.Point2D var63 = var54.getQuadrantOrigin();
//     org.jfree.chart.plot.PlotState var64 = null;
//     org.jfree.chart.ChartRenderingInfo var65 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var66 = new org.jfree.chart.plot.PlotRenderingInfo(var65);
//     org.jfree.chart.ChartRenderingInfo var67 = var66.getOwner();
//     var0.draw(var8, var9, var63, var64, var66);
// 
//   }

  public void test386() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }


    org.jfree.data.category.DefaultCategoryDataset var0 = new org.jfree.data.category.DefaultCategoryDataset();
    int var2 = var0.getColumnIndex((java.lang.Comparable)0L);
    org.jfree.data.general.DatasetGroup var3 = var0.getGroup();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var5 = var0.getColumnKey((-459));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.chart.block.LineBorder var0 = new org.jfree.chart.block.LineBorder();
    java.awt.Paint var1 = var0.getPaint();
    org.jfree.chart.plot.PiePlot3D var2 = new org.jfree.chart.plot.PiePlot3D();
    double var3 = var2.getShadowXOffset();
    var2.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var10 = var8.lookupSeriesStroke(1);
    var2.setLabelLinkStroke(var10);
    org.jfree.chart.axis.NumberAxis3D var13 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var13.setLabelAngle(0.2d);
    var13.setLabel("ChartEntity: tooltip = null");
    var13.setAutoRangeIncludesZero(false);
    org.jfree.chart.util.RectangleInsets var20 = var13.getLabelInsets();
    org.jfree.chart.block.LineBorder var21 = new org.jfree.chart.block.LineBorder(var1, var10, var20);
    org.jfree.chart.axis.SegmentedTimeline var22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var23 = var22.getBaseTimeline();
    java.util.Date var25 = var23.getDate(10L);
    boolean var26 = var21.equals((java.lang.Object)var23);
    long var27 = var23.getSegmentsExcludedSize();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 172800000L);

  }

  public void test388() {}
//   public void test388() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var12 = var9.getItemShapeFilled(1, (-2));
//     java.awt.Shape var17 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var26 = var25.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
//     java.awt.Paint var33 = var29.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var17, var24, var26, var33);
//     var9.setBaseFillPaint(var33, false);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var37.axisChanged(var38);
//     java.awt.Paint var40 = var37.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var41 = null;
//     var37.notifyListeners(var41);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
//     var37.setDomainCrosshairStroke(var47);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker((-3.0d), var33, var47);
//     var49.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var52 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var49);
//     org.jfree.chart.util.Layer var53 = null;
//     var0.addRangeMarker(1900, (org.jfree.chart.plot.Marker)var49, var53);
//     java.awt.Paint var55 = var49.getLabelPaint();
//     org.jfree.data.gantt.TaskSeriesCollection var56 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var56, 100);
//     org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
//     int var60 = var59.getSeriesCount();
//     java.awt.Graphics2D var61 = null;
//     java.awt.geom.Rectangle2D var62 = null;
//     var59.drawBackgroundImage(var61, var62);
//     var56.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var59);
//     org.jfree.chart.title.TextTitle var65 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var66 = var65.getPadding();
//     org.jfree.chart.event.TitleChangeListener var67 = null;
//     var65.addChangeListener(var67);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var71 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var73 = var71.lookupSeriesStroke(1);
//     java.awt.Paint var75 = var71.lookupSeriesOutlinePaint(10);
//     var65.setBackgroundPaint(var75);
//     java.awt.Paint var77 = var65.getPaint();
//     var59.setRangeTickBandPaint(var77);
//     var49.setPaint(var77);
//     
//     // Checks the contract:  equals-hashcode on var25 and var59
//     assertTrue("Contract failed: equals-hashcode on var25 and var59", var25.equals(var59) ? var25.hashCode() == var59.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var59 and var25
//     assertTrue("Contract failed: equals-hashcode on var59 and var25", var59.equals(var25) ? var59.hashCode() == var25.hashCode() : true);
// 
//   }

  public void test389() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
    java.awt.Paint var3 = var0.getQuadrantPaint(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
    var2.setUseFillPaint(false);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test392() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }


    org.jfree.chart.urls.StandardCategoryURLGenerator var1 = new org.jfree.chart.urls.StandardCategoryURLGenerator("May");

  }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    org.jfree.chart.ui.Licences var0 = new org.jfree.chart.ui.Licences();
    java.lang.String var1 = var0.getGPL();

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    boolean var3 = var2.getUseOutlinePaint();
    boolean var4 = var2.getAutoPopulateSeriesShape();
    java.awt.Graphics2D var5 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var6 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var9.setBaseCreateEntities(false);
    java.lang.Boolean var13 = null;
    var9.setSeriesVisibleInLegend(0, var13, true);
    boolean var16 = var9.getAutoPopulateSeriesStroke();
    java.awt.Shape var18 = var9.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var26 = new org.jfree.chart.title.LegendGraphic(var18, var25);
    java.awt.Shape var31 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var36 = var34.lookupSeriesStroke(1);
    java.awt.Paint var38 = var34.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var39 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var40 = var39.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
    java.awt.Paint var47 = var43.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var48 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var31, var38, var40, var47);
    java.awt.Shape var49 = var48.getLine();
    org.jfree.chart.entity.ChartEntity var52 = new org.jfree.chart.entity.ChartEntity(var49, "hi!", "hi!");
    var26.setLine(var49);
    java.awt.Paint var54 = var26.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var56 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var58 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var59 = var56.isBefore(var58);
    boolean var60 = var26.equals((java.lang.Object)var59);
    java.awt.Shape var61 = var26.getLine();
    java.awt.geom.Rectangle2D var62 = var26.getBounds();
    org.jfree.chart.plot.CategoryPlot var63 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.axis.CategoryAxis3D var64 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var66 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var68 = var66.equals((java.lang.Object)0.0f);
    java.lang.Object var69 = null;
    boolean var70 = var66.equals(var69);
    java.awt.Font var71 = var64.getTickLabelFont((java.lang.Comparable)var70);
    var64.setMaximumCategoryLabelLines((-459));
    org.jfree.chart.axis.ValueAxis var74 = null;
    org.jfree.data.gantt.TaskSeriesCollection var75 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var76 = null;
    boolean var77 = var75.hasListener(var76);
    int var79 = var75.getRowIndex((java.lang.Comparable)0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawItem(var5, var6, var62, var63, (org.jfree.chart.axis.CategoryAxis)var64, var74, (org.jfree.data.category.CategoryDataset)var75, 1900, 5, (-459));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == (-1));

  }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    java.awt.Color var1 = java.awt.Color.getColor("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test396() {}
//   public void test396() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var12 = var9.getItemShapeFilled(1, (-2));
//     java.awt.Shape var17 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var26 = var25.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
//     java.awt.Paint var33 = var29.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var17, var24, var26, var33);
//     var9.setBaseFillPaint(var33, false);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var37.axisChanged(var38);
//     java.awt.Paint var40 = var37.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var41 = null;
//     var37.notifyListeners(var41);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
//     var37.setDomainCrosshairStroke(var47);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker((-3.0d), var33, var47);
//     var49.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var52 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var49);
//     org.jfree.chart.util.Layer var53 = null;
//     var0.addRangeMarker(1900, (org.jfree.chart.plot.Marker)var49, var53);
//     org.jfree.chart.plot.XYPlot var55 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var57 = null;
//     var56.axisChanged(var57);
//     java.awt.Paint var59 = var56.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var60 = null;
//     var56.notifyListeners(var60);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var66 = var64.lookupSeriesStroke(1);
//     var56.setDomainCrosshairStroke(var66);
//     org.jfree.chart.plot.PiePlot3D var68 = new org.jfree.chart.plot.PiePlot3D();
//     double var69 = var68.getShadowXOffset();
//     var68.setDepthFactor(1.0d);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var74 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var76 = var74.lookupSeriesStroke(1);
//     var68.setLabelLinkStroke(var76);
//     var56.setDomainGridlineStroke(var76);
//     var55.setRangeGridlineStroke(var76);
//     var49.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var55);
// 
//   }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     int var1 = var0.getPassCount();
//     var0.setRenderAsPercentages(false);
//     java.awt.Graphics2D var4 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var7.setBaseCreateEntities(false);
//     java.lang.Boolean var11 = null;
//     var7.setSeriesVisibleInLegend(0, var11, true);
//     boolean var14 = var7.getAutoPopulateSeriesStroke();
//     java.awt.Shape var16 = var7.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var21 = var19.lookupSeriesStroke(1);
//     java.awt.Paint var23 = var19.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var24 = new org.jfree.chart.title.LegendGraphic(var16, var23);
//     java.awt.Shape var29 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var34 = var32.lookupSeriesStroke(1);
//     java.awt.Paint var36 = var32.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var38 = var37.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var43 = var41.lookupSeriesStroke(1);
//     java.awt.Paint var45 = var41.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var46 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var29, var36, var38, var45);
//     java.awt.Shape var47 = var46.getLine();
//     org.jfree.chart.entity.ChartEntity var50 = new org.jfree.chart.entity.ChartEntity(var47, "hi!", "hi!");
//     var24.setLine(var47);
//     java.awt.Paint var52 = var24.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var54 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var57 = var54.isBefore(var56);
//     boolean var58 = var24.equals((java.lang.Object)var57);
//     java.awt.Shape var59 = var24.getLine();
//     java.awt.geom.Rectangle2D var60 = var24.getBounds();
//     org.jfree.chart.plot.CategoryPlot var61 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.data.xy.XYDataset var63 = null;
//     org.jfree.chart.axis.ValueAxis var64 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var65 = null;
//     org.jfree.chart.plot.PolarPlot var66 = new org.jfree.chart.plot.PolarPlot(var63, var64, var65);
//     org.jfree.chart.plot.PlotRenderingInfo var69 = null;
//     java.awt.geom.Point2D var70 = null;
//     var66.zoomDomainAxes(100.0d, 0.05d, var69, var70);
//     org.jfree.chart.ChartRenderingInfo var74 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var75 = new org.jfree.chart.plot.PlotRenderingInfo(var74);
//     org.jfree.chart.ChartRenderingInfo var76 = var75.getOwner();
//     java.awt.geom.Point2D var77 = null;
//     var66.zoomDomainAxes(8.0d, (-3.0d), var75, var77);
//     org.jfree.chart.renderer.category.CategoryItemRendererState var79 = var0.initialise(var4, var60, var61, (-459), var75);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.ObjectList var1 = new org.jfree.chart.util.ObjectList((-459));
      fail("Expected exception of type java.lang.NegativeArraySizeException");
    } catch (java.lang.NegativeArraySizeException e) {
      // Expected exception.
    }

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.chart.annotations.CategoryAnnotation var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addAnnotation(var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getWeight();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var5 = null;
    boolean var6 = var4.hasListener(var5);
    int var8 = var4.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
    var4.seriesChanged(var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var13.axisChanged(var14);
    java.awt.Paint var16 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var17 = null;
    var13.notifyListeners(var17);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    var13.setDomainCrosshairStroke(var23);
    boolean var25 = var4.hasListener((java.util.EventListener)var13);
    org.jfree.chart.axis.AxisLocation var27 = var13.getDomainAxisLocation(255);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setDomainAxisLocation((-459), var27, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.event.TitleChangeListener var2 = null;
//     var0.addChangeListener(var2);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
//     java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
//     var0.setBackgroundPaint(var10);
//     var0.setExpandToFitSpace(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var16.axisChanged(var17);
//     java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
//     java.lang.Object var21 = var0.draw(var14, var15, (java.lang.Object)var20);
//     java.awt.Font var22 = var0.getFont();
//     java.lang.String var23 = var0.getText();
//     java.awt.Graphics2D var24 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var27.setBaseCreateEntities(false);
//     java.lang.Boolean var31 = null;
//     var27.setSeriesVisibleInLegend(0, var31, true);
//     boolean var34 = var27.getAutoPopulateSeriesStroke();
//     java.awt.Shape var36 = var27.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var41 = var39.lookupSeriesStroke(1);
//     java.awt.Paint var43 = var39.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var44 = new org.jfree.chart.title.LegendGraphic(var36, var43);
//     java.awt.Shape var49 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var54 = var52.lookupSeriesStroke(1);
//     java.awt.Paint var56 = var52.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var57 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var58 = var57.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var61 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var63 = var61.lookupSeriesStroke(1);
//     java.awt.Paint var65 = var61.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var66 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var49, var56, var58, var65);
//     java.awt.Shape var67 = var66.getLine();
//     org.jfree.chart.entity.ChartEntity var70 = new org.jfree.chart.entity.ChartEntity(var67, "hi!", "hi!");
//     var44.setLine(var67);
//     java.awt.Paint var72 = var44.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var74 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var77 = var74.isBefore(var76);
//     boolean var78 = var44.equals((java.lang.Object)var77);
//     java.awt.Shape var79 = var44.getLine();
//     java.awt.geom.Rectangle2D var80 = var44.getBounds();
//     var0.draw(var24, var80);
//     
//     // Checks the contract:  equals-hashcode on var16 and var57
//     assertTrue("Contract failed: equals-hashcode on var16 and var57", var16.equals(var57) ? var16.hashCode() == var57.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var57 and var16
//     assertTrue("Contract failed: equals-hashcode on var57 and var16", var57.equals(var16) ? var57.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    int var3 = var2.getSeriesCount();
    java.awt.Graphics2D var4 = null;
    java.awt.geom.Rectangle2D var5 = null;
    var2.drawBackgroundImage(var4, var5);
    org.jfree.chart.plot.PlotRenderingInfo var8 = null;
    java.awt.geom.Point2D var9 = null;
    var2.zoomRangeAxes((-1.0d), var8, var9);
    org.jfree.chart.event.PlotChangeListener var11 = null;
    var2.removeChangeListener(var11);
    org.jfree.chart.JFreeChart var13 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.title.LegendTitle var15 = var13.getLegend(5);
    java.awt.Image var16 = var13.getBackgroundImage();
    org.jfree.chart.title.LegendTitle var17 = var13.getLegend();
    org.jfree.chart.plot.RingPlot var18 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var19 = var18.getShadowPaint();
    java.lang.Object var20 = null;
    boolean var21 = var18.equals(var20);
    java.awt.Font var22 = var18.getNoDataMessageFont();
    var17.setItemFont(var22);
    java.awt.Paint var24 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextBlock var25 = org.jfree.chart.text.TextUtilities.createTextBlock("DatasetRenderingOrder.REVERSE", var22, var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var1 = var0.getDomainZeroBaselineStroke();
//     var0.mapDatasetToDomainAxis(0, 2);
//     org.jfree.chart.axis.AxisSpace var5 = var0.getFixedDomainAxisSpace();
//     boolean var6 = var0.isRangeCrosshairVisible();
//     org.jfree.chart.axis.DateAxis var8 = new org.jfree.chart.axis.DateAxis("ThreadContext");
//     org.jfree.chart.axis.ValueAxis[] var9 = new org.jfree.chart.axis.ValueAxis[] { var8};
//     var0.setDomainAxes(var9);
//     java.awt.Graphics2D var11 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var14.setBaseCreateEntities(false);
//     java.lang.Boolean var18 = null;
//     var14.setSeriesVisibleInLegend(0, var18, true);
//     boolean var21 = var14.getAutoPopulateSeriesStroke();
//     java.awt.Shape var23 = var14.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var28 = var26.lookupSeriesStroke(1);
//     java.awt.Paint var30 = var26.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var31 = new org.jfree.chart.title.LegendGraphic(var23, var30);
//     java.awt.Shape var36 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var41 = var39.lookupSeriesStroke(1);
//     java.awt.Paint var43 = var39.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var44 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var45 = var44.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var50 = var48.lookupSeriesStroke(1);
//     java.awt.Paint var52 = var48.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var53 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var36, var43, var45, var52);
//     java.awt.Shape var54 = var53.getLine();
//     org.jfree.chart.entity.ChartEntity var57 = new org.jfree.chart.entity.ChartEntity(var54, "hi!", "hi!");
//     var31.setLine(var54);
//     java.awt.Paint var59 = var31.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var61 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var63 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var64 = var61.isBefore(var63);
//     boolean var65 = var31.equals((java.lang.Object)var64);
//     java.awt.Shape var66 = var31.getLine();
//     java.awt.geom.Rectangle2D var67 = var31.getBounds();
//     org.jfree.chart.axis.SegmentedTimeline var68 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var69 = var68.getBaseTimeline();
//     org.jfree.chart.plot.XYPlot var70 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var71 = null;
//     var70.axisChanged(var71);
//     org.jfree.chart.renderer.xy.XYItemRenderer var74 = var70.getRenderer((-2));
//     org.jfree.chart.axis.ValueAxis var75 = var70.getDomainAxis();
//     org.jfree.chart.axis.AxisLocation var77 = null;
//     var70.setDomainAxisLocation(2, var77, false);
//     java.awt.Graphics2D var80 = null;
//     java.awt.geom.Rectangle2D var81 = null;
//     org.jfree.data.gantt.TaskSeries var83 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var83.setKey((java.lang.Comparable)10);
//     org.jfree.chart.axis.SegmentedTimeline var86 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var87 = var86.getBaseTimeline();
//     java.util.Date var89 = var87.getDate(10L);
//     var83.setKey((java.lang.Comparable)10L);
//     java.util.List var91 = var83.getTasks();
//     var70.drawRangeTickBands(var80, var81, var91);
//     var69.addExceptions(var91);
//     var0.drawRangeTickBands(var11, var67, var91);
//     
//     // Checks the contract:  equals-hashcode on var44 and var70
//     assertTrue("Contract failed: equals-hashcode on var44 and var70", var44.equals(var70) ? var44.hashCode() == var70.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var70 and var44
//     assertTrue("Contract failed: equals-hashcode on var70 and var44", var70.equals(var44) ? var70.hashCode() == var44.hashCode() : true);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    double var1 = var0.getRangeCrosshairValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test405() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var7 = var5.lookupSeriesStroke(1);
    java.awt.Paint var9 = var5.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var12 = null;
    var11.axisChanged(var12);
    java.awt.Paint var14 = var11.getRangeZeroBaselinePaint();
    var5.setSeriesItemLabelPaint(100, var14, false);
    java.awt.Paint var17 = var5.getBaseItemLabelPaint();
    var2.setErrorIndicatorPaint(var17);
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = var2.getBaseToolTipGenerator();
    java.awt.Paint var20 = var2.getErrorIndicatorPaint();
    java.awt.Graphics2D var21 = null;
    org.jfree.chart.renderer.category.CategoryItemRendererState var22 = null;
    java.awt.geom.Rectangle2D var23 = null;
    org.jfree.chart.plot.CategoryPlot var24 = new org.jfree.chart.plot.CategoryPlot();
    int var25 = var24.getWeight();
    org.jfree.chart.axis.CategoryAxis3D var26 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.CategoryLabelPositions var27 = var26.getCategoryLabelPositions();
    var26.setMaximumCategoryLabelWidthRatio(1.0f);
    org.jfree.chart.axis.ValueAxis var30 = null;
    org.jfree.data.gantt.TaskSeriesCollection var31 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var32 = null;
    boolean var33 = var31.hasListener(var32);
    int var35 = var31.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var36 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var37 = var36.getPadding();
    org.jfree.data.general.SeriesChangeEvent var38 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var37);
    var31.seriesChanged(var38);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.drawItem(var21, var22, var23, var24, (org.jfree.chart.axis.CategoryAxis)var26, var30, (org.jfree.data.category.CategoryDataset)var31, 1900, 1900, 10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    org.jfree.chart.text.TextBlock var1 = null;
    org.jfree.chart.text.TextBlockAnchor var2 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var3 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var6 = var3.getItemShapeFilled(1, (-2));
    boolean var8 = var3.equals((java.lang.Object)(-1.0d));
    var3.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var14 = var3.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var15 = var14.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var17 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var1, var2, var15, 100.0d);
    org.jfree.data.xy.XYDataset var18 = null;
    org.jfree.chart.axis.ValueAxis var19 = null;
    org.jfree.chart.renderer.PolarItemRenderer var20 = null;
    org.jfree.chart.plot.PolarPlot var21 = new org.jfree.chart.plot.PolarPlot(var18, var19, var20);
    var21.setAngleLabelsVisible(true);
    java.awt.Paint var24 = var21.getAngleGridlinePaint();
    var21.setRadiusGridlinesVisible(false);
    boolean var27 = var17.equals((java.lang.Object)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    org.jfree.chart.ChartRenderingInfo var0 = null;
    org.jfree.chart.plot.PlotRenderingInfo var1 = new org.jfree.chart.plot.PlotRenderingInfo(var0);
    org.jfree.chart.ChartRenderingInfo var2 = var1.getOwner();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.PlotRenderingInfo var4 = var1.getSubplotInfo(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.axis.DateTickUnit var3 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    org.jfree.chart.axis.DateTickUnit var6 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    var0.removeObject((java.lang.Comparable)var3, (java.lang.Comparable)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var10 = var0.getObject(2, 1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var1 = null;
//     boolean var2 = var0.hasListener(var1);
//     int var4 = var0.getRowIndex((java.lang.Comparable)0L);
//     java.util.List var5 = var0.getRowKeys();
//     org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var8 = var7.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var8);
//     org.jfree.data.gantt.TaskSeriesCollection var10 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var11 = var8.equals((java.lang.Object)var10);
//     org.jfree.data.general.DatasetGroup var12 = var10.getGroup();
//     org.jfree.data.time.Month var13 = new org.jfree.data.time.Month();
//     int var14 = var10.indexOf((java.lang.Comparable)var13);
//     long var15 = var13.getSerialIndex();
//     org.jfree.data.time.Year var16 = var13.getYear();
//     org.jfree.data.time.Month var17 = new org.jfree.data.time.Month(10, var16);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var27 = null;
//     var26.axisChanged(var27);
//     java.awt.Paint var29 = var26.getRangeZeroBaselinePaint();
//     var20.setSeriesItemLabelPaint(100, var29, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var36 = null;
//     var34.setSeriesItemLabelGenerator(2, var36);
//     java.awt.Font var38 = var34.getBaseItemLabelFont();
//     var20.setBaseItemLabelFont(var38);
//     boolean var40 = var16.equals((java.lang.Object)var20);
//     long var41 = var16.getLastMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var43 = var0.getStartValue((java.lang.Comparable)var41, (java.lang.Comparable)"Polar Plot");
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var40 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == 1420099199999L);
// 
//   }

  public void test410() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    java.util.List var2 = var1.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var4 = var1.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     org.jfree.chart.title.LegendTitle var14 = var12.getLegend(5);
//     java.awt.Image var15 = var12.getBackgroundImage();
//     org.jfree.chart.title.LegendTitle var16 = var12.getLegend();
//     org.jfree.chart.plot.RingPlot var17 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var18 = var17.getShadowPaint();
//     java.lang.Object var19 = null;
//     boolean var20 = var17.equals(var19);
//     java.awt.Font var21 = var17.getNoDataMessageFont();
//     var16.setItemFont(var21);
//     org.jfree.chart.plot.XYPlot var24 = new org.jfree.chart.plot.XYPlot();
//     int var25 = var24.getSeriesCount();
//     java.awt.Graphics2D var26 = null;
//     java.awt.geom.Rectangle2D var27 = null;
//     var24.drawBackgroundImage(var26, var27);
//     org.jfree.chart.plot.PlotRenderingInfo var30 = null;
//     java.awt.geom.Point2D var31 = null;
//     var24.zoomRangeAxes((-1.0d), var30, var31);
//     org.jfree.chart.event.PlotChangeListener var33 = null;
//     var24.removeChangeListener(var33);
//     org.jfree.chart.JFreeChart var35 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var24);
//     org.jfree.chart.title.LegendTitle var37 = var35.getLegend(5);
//     java.awt.Image var38 = var35.getBackgroundImage();
//     org.jfree.chart.title.LegendTitle var39 = var35.getLegend();
//     org.jfree.chart.plot.RingPlot var40 = new org.jfree.chart.plot.RingPlot();
//     java.awt.Paint var41 = var40.getShadowPaint();
//     java.lang.Object var42 = null;
//     boolean var43 = var40.equals(var42);
//     java.awt.Font var44 = var40.getNoDataMessageFont();
//     var39.setItemFont(var44);
//     org.jfree.chart.util.RectangleAnchor var46 = var39.getLegendItemGraphicAnchor();
//     var16.setLegendItemGraphicAnchor(var46);
//     
//     // Checks the contract:  equals-hashcode on var1 and var24
//     assertTrue("Contract failed: equals-hashcode on var1 and var24", var1.equals(var24) ? var1.hashCode() == var24.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var24 and var1
//     assertTrue("Contract failed: equals-hashcode on var24 and var1", var24.equals(var1) ? var24.hashCode() == var1.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var12 and var35
//     assertTrue("Contract failed: equals-hashcode on var12 and var35", var12.equals(var35) ? var12.hashCode() == var35.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var35 and var12
//     assertTrue("Contract failed: equals-hashcode on var35 and var12", var35.equals(var12) ? var35.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var40
//     assertTrue("Contract failed: equals-hashcode on var17 and var40", var17.equals(var40) ? var17.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var17
//     assertTrue("Contract failed: equals-hashcode on var40 and var17", var40.equals(var17) ? var40.hashCode() == var17.hashCode() : true);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    org.jfree.data.xy.TableXYDataset var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.Range var2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(var0, (-1.0d));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test413() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLabelAngle(0.2d);
    var1.setLabel("ChartEntity: tooltip = null");
    org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var10 = var7.getItemShapeFilled(1, (-2));
    java.awt.Shape var15 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var24 = var23.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var32 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var15, var22, var24, var31);
    var7.setBaseFillPaint(var31, false);
    org.jfree.chart.plot.XYPlot var35 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var36 = null;
    var35.axisChanged(var36);
    java.awt.Paint var38 = var35.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var39 = null;
    var35.notifyListeners(var39);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
    var35.setDomainCrosshairStroke(var45);
    org.jfree.chart.plot.ValueMarker var47 = new org.jfree.chart.plot.ValueMarker((-3.0d), var31, var45);
    var1.setLabelPaint(var31);
    java.io.ObjectOutputStream var49 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.util.SerialUtilities.writePaint(var31, var49);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    java.awt.Paint var47 = var19.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var52 = var49.isBefore(var51);
    boolean var53 = var19.equals((java.lang.Object)var52);
    double var54 = var19.getHeight();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var59 = var57.lookupSeriesStroke(1);
    java.awt.Shape var61 = var57.lookupSeriesShape((-459));
    var19.setLine(var61);
    org.jfree.chart.entity.TickLabelEntity var65 = new org.jfree.chart.entity.TickLabelEntity(var61, "hi!", "");
    java.lang.String var66 = var65.getURLText();
    java.lang.String var67 = var65.getShapeType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + ""+ "'", var66.equals(""));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "rect"+ "'", var67.equals("rect"));

  }

  public void test415() {}
//   public void test415() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }
// 
// 
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var0 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
//     org.jfree.chart.block.BorderArrangement var1 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.data.gantt.TaskSeriesCollection var2 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.List var3 = var2.getRowKeys();
//     java.lang.Comparable var4 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var5 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var1, (org.jfree.data.general.Dataset)var2, var4);
//     org.jfree.data.Range var6 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var2);
//     java.awt.Graphics2D var7 = null;
//     org.jfree.chart.plot.CategoryPlot var8 = new org.jfree.chart.plot.CategoryPlot();
//     int var9 = var8.getWeight();
//     org.jfree.chart.axis.CategoryAxis var11 = var8.getDomainAxis(0);
//     java.awt.geom.Rectangle2D var12 = null;
//     var0.drawOutline(var7, var8, var12);
// 
//   }

  public void test416() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }


    org.jfree.chart.axis.TickUnitSource var0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    org.jfree.chart.text.TextLine var1 = new org.jfree.chart.text.TextLine("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    java.awt.Paint var47 = var19.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var52 = var49.isBefore(var51);
    boolean var53 = var19.equals((java.lang.Object)var52);
    java.awt.Stroke var54 = var19.getOutlineStroke();
    var19.setShapeOutlineVisible(false);
    org.jfree.chart.util.RectangleAnchor var57 = var19.getShapeLocation();
    org.jfree.chart.text.TextBlockAnchor var58 = null;
    org.jfree.chart.axis.CategoryLabelWidthType var59 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.axis.CategoryLabelPosition var61 = new org.jfree.chart.axis.CategoryLabelPosition(var57, var58, var59, 100.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     java.awt.Color var2 = java.awt.Color.getColor("ChartEntity: tooltip = null", 15);
//     java.lang.String var3 = var2.toString();
//     java.awt.Color var4 = var2.brighter();
//     java.awt.color.ColorSpace var5 = null;
//     float[] var6 = new float[] { };
//     float[] var7 = var2.getComponents(var5, var6);
// 
//   }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
    java.util.List var2 = var1.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var5 = var1.getValue(15, 0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.chart.event.TitleChangeListener var2 = null;
//     var0.addChangeListener(var2);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var8 = var6.lookupSeriesStroke(1);
//     java.awt.Paint var10 = var6.lookupSeriesOutlinePaint(10);
//     var0.setBackgroundPaint(var10);
//     var0.setExpandToFitSpace(false);
//     java.awt.Graphics2D var14 = null;
//     java.awt.geom.Rectangle2D var15 = null;
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var16.axisChanged(var17);
//     java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
//     java.lang.Object var21 = var0.draw(var14, var15, (java.lang.Object)var20);
//     java.awt.Font var22 = var0.getFont();
//     java.lang.String var23 = var0.getText();
//     java.awt.Shape var32 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var37 = var35.lookupSeriesStroke(1);
//     java.awt.Paint var39 = var35.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var40 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var41 = var40.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var46 = var44.lookupSeriesStroke(1);
//     java.awt.Paint var48 = var44.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var49 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var32, var39, var41, var48);
//     org.jfree.chart.block.BlockBorder var50 = new org.jfree.chart.block.BlockBorder(100.0d, (-1.0d), 10.0d, 100.0d, var39);
//     var0.setFrame((org.jfree.chart.block.BlockFrame)var50);
//     
//     // Checks the contract:  equals-hashcode on var16 and var40
//     assertTrue("Contract failed: equals-hashcode on var16 and var40", var16.equals(var40) ? var16.hashCode() == var40.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var40 and var16
//     assertTrue("Contract failed: equals-hashcode on var40 and var16", var40.equals(var16) ? var40.hashCode() == var16.hashCode() : true);
// 
//   }

  public void test422() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }


    org.jfree.data.DefaultKeyedValues var0 = new org.jfree.data.DefaultKeyedValues();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var4.getFollowingDayOfWeek(2);
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var11 = var8.isBefore(var10);
    int var12 = var8.getYYYY();
    boolean var14 = var2.isInRange(var4, (org.jfree.data.time.SerialDate)var8, 0);
    org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var20 = var18.getFollowingDayOfWeek(2);
    org.jfree.data.time.SpreadsheetDate var22 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var25 = var22.isBefore(var24);
    int var26 = var22.getYYYY();
    boolean var28 = var16.isInRange(var18, (org.jfree.data.time.SerialDate)var22, 0);
    boolean var29 = var8.isOnOrAfter(var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var30 = var0.getValue((java.lang.Comparable)var8);
      fail("Expected exception of type org.jfree.data.UnknownKeyException");
    } catch (org.jfree.data.UnknownKeyException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);

  }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("ChartEntity: tooltip = null");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    org.jfree.chart.JFreeChart var4 = null;
    org.jfree.chart.event.ChartChangeEvent var5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object)(-2), var4);
    org.jfree.chart.JFreeChart var6 = null;
    var5.setChart(var6);
    org.jfree.chart.JFreeChart var8 = var5.getChart();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test425() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    int var3 = var2.getColumnCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);

  }

  public void test426() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLabelAngle(0.2d);
    var1.setLabel("ChartEntity: tooltip = null");
    double var6 = var1.getLabelAngle();
    var1.setAutoRange(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.2d);

  }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var1.setKey((java.lang.Comparable)10);
    org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var5 = var4.getBaseTimeline();
    java.util.Date var7 = var5.getDate(10L);
    var1.setKey((java.lang.Comparable)10L);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
    org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var13 = var10.equals((java.lang.Object)var12);
    var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var12);
    org.jfree.chart.axis.NumberTickUnit var17 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var19 = var17.equals((java.lang.Object)0.0f);
    java.lang.Object var20 = null;
    boolean var21 = var17.equals(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var22 = var12.getSubIntervalCount((java.lang.Comparable)2, (java.lang.Comparable)var21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);

  }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 100);
    org.jfree.chart.plot.XYPlot var3 = new org.jfree.chart.plot.XYPlot();
    int var4 = var3.getSeriesCount();
    java.awt.Graphics2D var5 = null;
    java.awt.geom.Rectangle2D var6 = null;
    var3.drawBackgroundImage(var5, var6);
    var0.removeChangeListener((org.jfree.data.general.DatasetChangeListener)var3);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.chart.event.TitleChangeListener var11 = null;
    var9.addChangeListener(var11);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
    java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
    var9.setBackgroundPaint(var19);
    java.awt.Paint var21 = var9.getPaint();
    var3.setRangeTickBandPaint(var21);
    org.jfree.chart.plot.Plot var23 = var3.getParent();
    var3.setRangeCrosshairValue(1.0E-5d);
    org.jfree.data.xy.XYDataset var26 = null;
    var3.setDataset(var26);
    boolean var28 = var3.isDomainCrosshairVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);

  }

  public void test429() {}
//   public void test429() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
//     boolean var5 = var2.getAutoPopulateSeriesFillPaint();
//     java.lang.Object var6 = var2.clone();
//     java.lang.Boolean var8 = var2.getSeriesItemLabelsVisible(15);
//     org.jfree.chart.renderer.category.StackedBarRenderer3D var10 = new org.jfree.chart.renderer.category.StackedBarRenderer3D();
//     org.jfree.chart.block.BorderArrangement var11 = new org.jfree.chart.block.BorderArrangement();
//     org.jfree.data.gantt.TaskSeriesCollection var12 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.List var13 = var12.getRowKeys();
//     java.lang.Comparable var14 = null;
//     org.jfree.chart.title.LegendItemBlockContainer var15 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var11, (org.jfree.data.general.Dataset)var12, var14);
//     org.jfree.data.Range var16 = var10.findRangeBounds((org.jfree.data.category.CategoryDataset)var12);
//     java.awt.Graphics2D var17 = null;
//     org.jfree.chart.plot.CategoryPlot var18 = new org.jfree.chart.plot.CategoryPlot();
//     org.jfree.chart.plot.XYPlot var19 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var20 = null;
//     var19.axisChanged(var20);
//     java.awt.Paint var22 = var19.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.Layer var24 = null;
//     java.util.Collection var25 = var19.getDomainMarkers((-459), var24);
//     org.jfree.chart.axis.ValueAxis var26 = var19.getRangeAxis();
//     var19.setDomainCrosshairLockedOnData(false);
//     org.jfree.chart.axis.DateAxis var29 = new org.jfree.chart.axis.DateAxis();
//     org.jfree.chart.axis.DateTickUnit var30 = null;
//     var29.setTickUnit(var30);
//     java.util.Date var32 = var29.getMaximumDate();
//     var19.setRangeAxis((org.jfree.chart.axis.ValueAxis)var29);
//     var29.centerRange(0.05d);
//     org.jfree.chart.util.RectangleInsets var36 = var29.getLabelInsets();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var39.setBaseCreateEntities(false);
//     java.lang.Boolean var43 = null;
//     var39.setSeriesVisibleInLegend(0, var43, true);
//     boolean var46 = var39.getAutoPopulateSeriesStroke();
//     java.awt.Shape var48 = var39.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var53 = var51.lookupSeriesStroke(1);
//     java.awt.Paint var55 = var51.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var56 = new org.jfree.chart.title.LegendGraphic(var48, var55);
//     java.awt.Shape var61 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var64 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var66 = var64.lookupSeriesStroke(1);
//     java.awt.Paint var68 = var64.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var69 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var70 = var69.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var73 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var75 = var73.lookupSeriesStroke(1);
//     java.awt.Paint var77 = var73.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var78 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var61, var68, var70, var77);
//     java.awt.Shape var79 = var78.getLine();
//     org.jfree.chart.entity.ChartEntity var82 = new org.jfree.chart.entity.ChartEntity(var79, "hi!", "hi!");
//     var56.setLine(var79);
//     java.awt.Paint var84 = var56.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var86 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var88 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var89 = var86.isBefore(var88);
//     boolean var90 = var56.equals((java.lang.Object)var89);
//     java.awt.Shape var91 = var56.getLine();
//     java.awt.geom.Rectangle2D var92 = var56.getBounds();
//     var10.drawRangeGridline(var17, var18, (org.jfree.chart.axis.ValueAxis)var29, var92, (-3.0d));
//     var2.setSeriesShape(12, (java.awt.Shape)var92);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var51 and var2.", var51.equals(var2) == var2.equals(var51));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var64 and var2.", var64.equals(var2) == var2.equals(var64));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var73 and var2.", var73.equals(var2) == var2.equals(var73));
// 
//   }

  public void test430() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers((-459), var5);
    org.jfree.chart.axis.ValueAxis var7 = var0.getRangeAxis();
    var0.setDomainCrosshairLockedOnData(false);
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var11 = null;
    var10.setTickUnit(var11);
    java.util.Date var13 = var10.getMaximumDate();
    var0.setRangeAxis((org.jfree.chart.axis.ValueAxis)var10);
    var10.setUpperMargin(2.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var5 = var3.lookupSeriesStroke(1);
//     boolean var6 = var3.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
//     var10.setSeriesItemLabelGenerator(2, var12);
//     java.awt.Font var14 = var10.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var14);
//     var3.setBaseItemLabelFont(var14);
//     var0.setLabelFont(var14);
//     org.jfree.chart.labels.PieSectionLabelGenerator var18 = var0.getLabelGenerator();
//     org.jfree.chart.plot.RingPlot var19 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.LegendItemCollection var20 = var19.getLegendItems();
//     double var21 = var19.getOuterSeparatorExtension();
//     org.jfree.chart.plot.PiePlot3D var22 = new org.jfree.chart.plot.PiePlot3D();
//     double var23 = var22.getShadowXOffset();
//     var22.setDepthFactor(1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var26 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var28 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var26, 100);
//     var22.setDataset(var28);
//     double var30 = var22.getShadowYOffset();
//     double var31 = var22.getDepthFactor();
//     org.jfree.chart.labels.PieSectionLabelGenerator var32 = var22.getLegendLabelGenerator();
//     var19.setLabelGenerator(var32);
//     var0.setLabelGenerator(var32);
//     
//     // Checks the contract:  equals-hashcode on var18 and var32
//     assertTrue("Contract failed: equals-hashcode on var18 and var32", var18.equals(var32) ? var18.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var18
//     assertTrue("Contract failed: equals-hashcode on var32 and var18", var32.equals(var18) ? var32.hashCode() == var18.hashCode() : true);
// 
//   }

  public void test432() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    int var4 = var0.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
    org.jfree.data.general.SeriesChangeEvent var7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
    var0.seriesChanged(var7);
    int var9 = var0.getRowCount();
    int var11 = var0.indexOf((java.lang.Comparable)"java.awt.Color[r=0,g=0,b=15]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-1));

  }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.awt.Color var2 = java.awt.Color.getColor("ChartEntity: tooltip = null", 15);
    java.awt.Color var3 = var2.brighter();
    float[] var10 = new float[] { 100.0f, 10.0f, (-1.0f)};
    float[] var11 = java.awt.Color.RGBtoHSB((-2), 14, 1900, var10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      float[] var12 = var2.getRGBComponents(var11);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(1.0d, (-3.0d));
    java.awt.Paint var3 = var2.getWallPaint();
    java.lang.Object var4 = var2.clone();
    java.lang.Boolean var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesVisible((-459), var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("12/31/69", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis[] var6 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var6);
    boolean var8 = var0.isRangeZoomable();
    org.jfree.chart.renderer.category.LineRenderer3D var10 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var13 = var10.getItemShapeFilled(1, (-2));
    java.awt.Shape var18 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var26 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var27 = var26.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var32 = var30.lookupSeriesStroke(1);
    java.awt.Paint var34 = var30.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var35 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var18, var25, var27, var34);
    var10.setBaseFillPaint(var34, false);
    org.jfree.chart.plot.XYPlot var38 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var39 = null;
    var38.axisChanged(var39);
    java.awt.Paint var41 = var38.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var42 = null;
    var38.notifyListeners(var42);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var48 = var46.lookupSeriesStroke(1);
    var38.setDomainCrosshairStroke(var48);
    org.jfree.chart.plot.ValueMarker var50 = new org.jfree.chart.plot.ValueMarker((-3.0d), var34, var48);
    var50.setAlpha(1.0f);
    org.jfree.chart.event.MarkerChangeEvent var53 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var50);
    org.jfree.chart.plot.Marker var54 = var53.getMarker();
    java.lang.Object var55 = var54.clone();
    org.jfree.chart.util.Layer var56 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker(var54, var56);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);

  }

  public void test437() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var2 = null;
    var1.setTickUnit(var2);
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var5.setLabelAngle(0.2d);
    var5.setLowerBound(12.0d);
    var5.setLowerBound(0.0d);
    var5.setTickMarksVisible(true);
    org.jfree.data.Range var14 = var5.getRange();
    var1.setRange(var14);
    org.jfree.data.time.DateRange var18 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var20 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var18, 100.0d);
    org.jfree.chart.block.LengthConstraintType var21 = var20.getHeightConstraintType();
    org.jfree.data.Range var23 = null;
    org.jfree.data.time.DateRange var26 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var28 = new org.jfree.chart.block.RectangleConstraint((org.jfree.data.Range)var26, 100.0d);
    org.jfree.chart.block.LengthConstraintType var29 = var28.getHeightConstraintType();
    org.jfree.chart.block.RectangleConstraint var30 = new org.jfree.chart.block.RectangleConstraint(3.0d, var14, var21, 100.0d, var23, var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test438() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }


    java.awt.Shape var4 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
    java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
    java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
    java.awt.Shape var22 = var21.getLine();
    java.awt.Paint var23 = var21.getFillPaint();
    org.jfree.data.gantt.TaskSeriesCollection var24 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var25 = null;
    boolean var26 = var24.hasListener(var25);
    int var28 = var24.getRowIndex((java.lang.Comparable)0L);
    int var30 = var24.getColumnIndex((java.lang.Comparable)0.0d);
    var21.setDataset((org.jfree.data.general.Dataset)var24);
    java.lang.Comparable var32 = var21.getSeriesKey();
    boolean var33 = var21.isShapeOutlineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);

  }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.jfree.chart.block.BorderArrangement var0 = new org.jfree.chart.block.BorderArrangement();
    org.jfree.data.gantt.TaskSeriesCollection var1 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.List var2 = var1.getRowKeys();
    java.lang.Comparable var3 = null;
    org.jfree.chart.title.LegendItemBlockContainer var4 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement)var0, (org.jfree.data.general.Dataset)var1, var3);
    org.jfree.data.time.Month var5 = new org.jfree.data.time.Month();
    org.jfree.chart.title.TextTitle var6 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var7 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var8 = var7.getPadding();
    var6.setPadding(var8);
    boolean var10 = var5.equals((java.lang.Object)var6);
    org.jfree.chart.util.HorizontalAlignment var11 = var6.getTextAlignment();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var16 = null;
    var14.setSeriesItemLabelGenerator(2, var16);
    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var14.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator)var19);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.add((org.jfree.chart.block.Block)var6, (java.lang.Object)var19);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var7 = null;
    boolean var8 = var6.hasListener(var7);
    int var10 = var6.getRowIndex((java.lang.Comparable)0L);
    java.util.List var11 = var6.getRowKeys();
    boolean var12 = var0.equals((java.lang.Object)var6);
    java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.axis.DateTickUnit var16 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var18 = var17.getBaseTimeline();
    java.util.Date var20 = var18.getDate(10L);
    java.util.Date var21 = var16.addToDate(var20);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var23 = var6.getStartValue((java.lang.Comparable)var20, (java.lang.Comparable)255);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    java.awt.Paint var47 = var19.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var49 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var51 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var52 = var49.isBefore(var51);
    boolean var53 = var19.equals((java.lang.Object)var52);
    java.awt.Shape var54 = var19.getLine();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var59 = var57.lookupSeriesStroke(1);
    java.awt.Shape var61 = var57.lookupSeriesShape((-459));
    boolean var62 = org.jfree.chart.util.ShapeUtilities.equal(var54, var61);
    java.awt.Shape var63 = null;
    boolean var64 = org.jfree.chart.util.ShapeUtilities.equal(var61, var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = null;
    org.jfree.chart.axis.ValueAxis[] var6 = new org.jfree.chart.axis.ValueAxis[] { var5};
    var0.setDomainAxes(var6);
    org.jfree.chart.title.TextTitle var8 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var9 = var8.getPadding();
    org.jfree.chart.event.TitleChangeListener var10 = null;
    var8.addChangeListener(var10);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    var8.setBackgroundPaint(var18);
    var0.setBackgroundPaint(var18);
    boolean var21 = var0.isDomainGridlinesVisible();
    java.awt.Stroke var22 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setRangeZeroBaselineStroke(var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var2.setBaseCreateEntities(false);
//     java.lang.Boolean var6 = null;
//     var2.setSeriesVisibleInLegend(0, var6, true);
//     boolean var9 = var2.getAutoPopulateSeriesStroke();
//     java.awt.Shape var11 = var2.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
//     java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
//     org.jfree.chart.util.RectangleAnchor var20 = var19.getShapeAnchor();
//     java.awt.Stroke var21 = var19.getOutlineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var24.setBaseCreateEntities(false);
//     java.lang.Boolean var28 = null;
//     var24.setSeriesVisibleInLegend(0, var28, true);
//     boolean var31 = var24.getAutoPopulateSeriesStroke();
//     java.awt.Shape var33 = var24.lookupSeriesShape((-2));
//     java.awt.Shape var37 = org.jfree.chart.util.ShapeUtilities.rotateShape(var33, 4.0d, 10.0f, 10.0f);
//     org.jfree.data.gantt.TaskSeriesCollection var40 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var42 = var40.equals((java.lang.Object)(-1));
//     var40.validateObject();
//     org.jfree.data.time.SpreadsheetDate var45 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var47 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var48 = var45.isBefore(var47);
//     int var49 = var45.getYYYY();
//     org.jfree.chart.entity.CategoryItemEntity var51 = new org.jfree.chart.entity.CategoryItemEntity(var37, "hi!", "", (org.jfree.data.category.CategoryDataset)var40, (java.lang.Comparable)var45, (java.lang.Comparable)(-3.0d));
//     org.jfree.chart.entity.ChartEntity var54 = new org.jfree.chart.entity.ChartEntity(var37, "RectangleEdge.BOTTOM", "hi!");
//     var19.setShape(var37);
//     java.awt.Shape var56 = var19.getShape();
//     org.jfree.data.category.DefaultCategoryDataset var59 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var61 = var59.getColumnIndex((java.lang.Comparable)0L);
//     org.jfree.data.general.DatasetGroup var62 = var59.getGroup();
//     org.jfree.data.general.PieDataset var64 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var59, 1900);
//     org.jfree.data.KeyedObjects2D var65 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.axis.DateTickUnit var68 = new org.jfree.chart.axis.DateTickUnit(0, 14);
//     org.jfree.chart.axis.DateTickUnit var71 = new org.jfree.chart.axis.DateTickUnit(0, 14);
//     var65.removeObject((java.lang.Comparable)var68, (java.lang.Comparable)var71);
//     org.jfree.chart.entity.CategoryItemEntity var74 = new org.jfree.chart.entity.CategoryItemEntity(var56, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (org.jfree.data.category.CategoryDataset)var59, (java.lang.Comparable)var71, (java.lang.Comparable)10);
//     org.jfree.data.time.SpreadsheetDate var78 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var81 = var78.isBefore(var80);
//     int var82 = var78.getYYYY();
//     org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.addYears(15, (org.jfree.data.time.SerialDate)var78);
//     org.jfree.data.KeyedObjects2D var84 = new org.jfree.data.KeyedObjects2D();
//     org.jfree.chart.axis.DateTickUnit var87 = new org.jfree.chart.axis.DateTickUnit(0, 14);
//     org.jfree.chart.axis.DateTickUnit var90 = new org.jfree.chart.axis.DateTickUnit(0, 14);
//     var84.removeObject((java.lang.Comparable)var87, (java.lang.Comparable)var90);
//     var59.setValue(100.0d, (java.lang.Comparable)15, (java.lang.Comparable)var90);
//     
//     // Checks the contract:  equals-hashcode on var65 and var84
//     assertTrue("Contract failed: equals-hashcode on var65 and var84", var65.equals(var84) ? var65.hashCode() == var84.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var84 and var65
//     assertTrue("Contract failed: equals-hashcode on var84 and var65", var84.equals(var65) ? var84.hashCode() == var65.hashCode() : true);
// 
//   }

  public void test444() {}
//   public void test444() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }
// 
// 
//     org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
//     org.jfree.chart.axis.CategoryLabelPositions var1 = var0.getCategoryLabelPositions();
//     var0.setMaximumCategoryLabelWidthRatio(1.0f);
//     java.awt.Font var5 = var0.getTickLabelFont((java.lang.Comparable)"({0}, {1}) = {3} - {4}");
//     org.jfree.chart.axis.CategoryAnchor var6 = null;
//     org.jfree.chart.ChartRenderingInfo var9 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var10 = new org.jfree.chart.plot.PlotRenderingInfo(var9);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var13.setBaseCreateEntities(false);
//     java.lang.Boolean var17 = null;
//     var13.setSeriesVisibleInLegend(0, var17, true);
//     boolean var20 = var13.getAutoPopulateSeriesStroke();
//     java.awt.Shape var22 = var13.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var27 = var25.lookupSeriesStroke(1);
//     java.awt.Paint var29 = var25.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var30 = new org.jfree.chart.title.LegendGraphic(var22, var29);
//     java.awt.Shape var35 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var40 = var38.lookupSeriesStroke(1);
//     java.awt.Paint var42 = var38.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var43 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var44 = var43.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var49 = var47.lookupSeriesStroke(1);
//     java.awt.Paint var51 = var47.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var52 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var35, var42, var44, var51);
//     java.awt.Shape var53 = var52.getLine();
//     org.jfree.chart.entity.ChartEntity var56 = new org.jfree.chart.entity.ChartEntity(var53, "hi!", "hi!");
//     var30.setLine(var53);
//     java.awt.Paint var58 = var30.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var60 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var63 = var60.isBefore(var62);
//     boolean var64 = var30.equals((java.lang.Object)var63);
//     java.awt.Shape var65 = var30.getLine();
//     java.awt.geom.Rectangle2D var66 = var30.getBounds();
//     var10.setPlotArea(var66);
//     org.jfree.chart.title.TextTitle var68 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.title.TextTitle var69 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var70 = var69.getPadding();
//     var68.setPadding(var70);
//     double var73 = var70.trimHeight((-1.0d));
//     double var74 = var70.getBottom();
//     org.jfree.chart.plot.XYPlot var75 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var76 = null;
//     var75.axisChanged(var76);
//     java.awt.Paint var78 = var75.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.RectangleEdge var79 = var75.getRangeAxisEdge();
//     boolean var80 = var70.equals((java.lang.Object)var79);
//     double var81 = var0.getCategoryJava2DCoordinate(var6, 0, (-2), var66, var79);
// 
//   }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    boolean var13 = var2.isSeriesVisibleInLegend(1);
    boolean var14 = var2.getUseOutlinePaint();
    java.lang.Boolean var16 = null;
    var2.setSeriesVisibleInLegend(100, var16, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.awt.Shape var4 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var9 = var7.lookupSeriesStroke(1);
//     java.awt.Paint var11 = var7.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var12 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var13 = var12.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var18 = var16.lookupSeriesStroke(1);
//     java.awt.Paint var20 = var16.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var21 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var4, var11, var13, var20);
//     java.awt.Shape var22 = var21.getLine();
//     java.awt.Paint var23 = var21.getFillPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var26.setBaseCreateEntities(false);
//     java.lang.Boolean var30 = null;
//     var26.setSeriesVisibleInLegend(0, var30, true);
//     boolean var33 = var26.getAutoPopulateSeriesStroke();
//     java.awt.Shape var35 = var26.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var40 = var38.lookupSeriesStroke(1);
//     java.awt.Paint var42 = var38.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var43 = new org.jfree.chart.title.LegendGraphic(var35, var42);
//     java.awt.Shape var48 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var53 = var51.lookupSeriesStroke(1);
//     java.awt.Paint var55 = var51.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var57 = var56.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var60 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var62 = var60.lookupSeriesStroke(1);
//     java.awt.Paint var64 = var60.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var65 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var48, var55, var57, var64);
//     java.awt.Shape var66 = var65.getLine();
//     org.jfree.chart.entity.ChartEntity var69 = new org.jfree.chart.entity.ChartEntity(var66, "hi!", "hi!");
//     var43.setLine(var66);
//     java.awt.Paint var71 = var43.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var73 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var76 = var73.isBefore(var75);
//     boolean var77 = var43.equals((java.lang.Object)var76);
//     java.awt.Stroke var78 = var43.getOutlineStroke();
//     var43.setShapeOutlineVisible(false);
//     org.jfree.chart.util.GradientPaintTransformer var81 = var43.getFillPaintTransformer();
//     var21.setFillPaintTransformer(var81);
//     
//     // Checks the contract:  equals-hashcode on var12 and var56
//     assertTrue("Contract failed: equals-hashcode on var12 and var56", var12.equals(var56) ? var12.hashCode() == var56.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var56 and var12
//     assertTrue("Contract failed: equals-hashcode on var56 and var12", var56.equals(var12) ? var56.hashCode() == var12.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var21 and var65
//     assertTrue("Contract failed: equals-hashcode on var21 and var65", var21.equals(var65) ? var21.hashCode() == var65.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var65 and var21
//     assertTrue("Contract failed: equals-hashcode on var65 and var21", var65.equals(var21) ? var65.hashCode() == var21.hashCode() : true);
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getWeight();
    org.jfree.chart.axis.CategoryAxis var3 = var0.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis3D var5 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var7 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var9 = var7.equals((java.lang.Object)0.0f);
    java.lang.Object var10 = null;
    boolean var11 = var7.equals(var10);
    java.awt.Font var12 = var5.getTickLabelFont((java.lang.Comparable)var11);
    var5.setMaximumCategoryLabelLines((-459));
    var0.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var5, true);
    boolean var17 = var0.isRangeCrosshairLockedOnData();
    java.awt.Graphics2D var18 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var21.setBaseCreateEntities(false);
    java.lang.Boolean var25 = null;
    var21.setSeriesVisibleInLegend(0, var25, true);
    boolean var28 = var21.getAutoPopulateSeriesStroke();
    java.awt.Shape var30 = var21.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var35 = var33.lookupSeriesStroke(1);
    java.awt.Paint var37 = var33.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var38 = new org.jfree.chart.title.LegendGraphic(var30, var37);
    java.awt.Shape var43 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var48 = var46.lookupSeriesStroke(1);
    java.awt.Paint var50 = var46.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var51 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var52 = var51.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var55 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var57 = var55.lookupSeriesStroke(1);
    java.awt.Paint var59 = var55.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var60 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var43, var50, var52, var59);
    java.awt.Shape var61 = var60.getLine();
    org.jfree.chart.entity.ChartEntity var64 = new org.jfree.chart.entity.ChartEntity(var61, "hi!", "hi!");
    var38.setLine(var61);
    java.awt.Paint var66 = var38.getFillPaint();
    org.jfree.data.time.SpreadsheetDate var68 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var71 = var68.isBefore(var70);
    boolean var72 = var38.equals((java.lang.Object)var71);
    java.awt.Shape var73 = var38.getLine();
    java.awt.geom.Rectangle2D var74 = var38.getBounds();
    org.jfree.data.xy.XYDataset var76 = null;
    org.jfree.chart.axis.ValueAxis var77 = null;
    org.jfree.chart.renderer.PolarItemRenderer var78 = null;
    org.jfree.chart.plot.PolarPlot var79 = new org.jfree.chart.plot.PolarPlot(var76, var77, var78);
    org.jfree.chart.plot.PlotRenderingInfo var82 = null;
    java.awt.geom.Point2D var83 = null;
    var79.zoomDomainAxes(100.0d, 0.05d, var82, var83);
    org.jfree.chart.ChartRenderingInfo var87 = null;
    org.jfree.chart.plot.PlotRenderingInfo var88 = new org.jfree.chart.plot.PlotRenderingInfo(var87);
    org.jfree.chart.ChartRenderingInfo var89 = var88.getOwner();
    java.awt.geom.Point2D var90 = null;
    var79.zoomDomainAxes(8.0d, (-3.0d), var88, var90);
    java.awt.geom.Rectangle2D var92 = null;
    var88.setPlotArea(var92);
    int var94 = var88.getSubplotCount();
    java.awt.geom.Rectangle2D var95 = var88.getPlotArea();
    boolean var96 = var0.render(var18, var74, 1900, var88);
    java.awt.geom.Rectangle2D var97 = var88.getDataArea();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var96 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

//  public void test448() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
//
//
//    java.lang.Class var1 = null;
//    java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=0,g=0,b=15]", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNull(var2);
//
//  }
//
  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    org.jfree.chart.event.TitleChangeListener var3 = null;
    var1.addChangeListener(var3);
    boolean var5 = var0.equals((java.lang.Object)var3);
    org.jfree.data.gantt.TaskSeriesCollection var6 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var7 = null;
    boolean var8 = var6.hasListener(var7);
    int var10 = var6.getRowIndex((java.lang.Comparable)0L);
    java.util.List var11 = var6.getRowKeys();
    boolean var12 = var0.equals((java.lang.Object)var6);
    java.lang.Number var13 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.plot.MultiplePiePlot var14 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset)var6);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    int var17 = var16.getSeriesCount();
    java.awt.Graphics2D var18 = null;
    java.awt.geom.Rectangle2D var19 = null;
    var16.drawBackgroundImage(var18, var19);
    org.jfree.chart.plot.PlotRenderingInfo var22 = null;
    java.awt.geom.Point2D var23 = null;
    var16.zoomRangeAxes((-1.0d), var22, var23);
    org.jfree.chart.event.PlotChangeListener var25 = null;
    var16.removeChangeListener(var25);
    org.jfree.chart.JFreeChart var27 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var16);
    org.jfree.chart.title.TextTitle var28 = var27.getTitle();
    org.jfree.chart.plot.Plot var29 = var27.getPlot();
    java.awt.image.BufferedImage var32 = var27.createBufferedImage(5, 15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var14.setPieChart(var27);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setLabelAngle(0.2d);
    var1.setLabel("ChartEntity: tooltip = null");
    var1.setAutoRangeIncludesZero(false);
    org.jfree.chart.util.RectangleInsets var8 = var1.getLabelInsets();
    java.lang.String var9 = var8.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"+ "'", var9.equals("RectangleInsets[t=3.0,l=3.0,b=3.0,r=3.0]"));

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
//     org.jfree.chart.plot.DrawingSupplier var2 = null;
//     var0.setDrawingSupplier(var2);
//     org.jfree.chart.util.Layer var5 = null;
//     java.util.Collection var6 = var0.getDomainMarkers(100, var5);
//     org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var12 = var9.getItemShapeFilled(1, (-2));
//     java.awt.Shape var17 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var26 = var25.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
//     java.awt.Paint var33 = var29.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var17, var24, var26, var33);
//     var9.setBaseFillPaint(var33, false);
//     org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var38 = null;
//     var37.axisChanged(var38);
//     java.awt.Paint var40 = var37.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var41 = null;
//     var37.notifyListeners(var41);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
//     var37.setDomainCrosshairStroke(var47);
//     org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker((-3.0d), var33, var47);
//     var49.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var52 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var49);
//     org.jfree.chart.util.Layer var53 = null;
//     var0.addRangeMarker(1900, (org.jfree.chart.plot.Marker)var49, var53);
//     java.awt.Paint var55 = var49.getLabelPaint();
//     org.jfree.chart.plot.XYPlot var56 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var57 = null;
//     var56.axisChanged(var57);
//     java.awt.Paint var59 = var56.getRangeZeroBaselinePaint();
//     org.jfree.chart.util.Layer var61 = null;
//     java.util.Collection var62 = var56.getDomainMarkers((-459), var61);
//     org.jfree.chart.axis.ValueAxis var63 = var56.getRangeAxis();
//     var56.setDomainCrosshairLockedOnData(false);
//     java.awt.Stroke var66 = var56.getRangeZeroBaselineStroke();
//     org.jfree.data.xy.XYDataset var67 = null;
//     org.jfree.chart.axis.ValueAxis var68 = null;
//     org.jfree.chart.renderer.PolarItemRenderer var69 = null;
//     org.jfree.chart.plot.PolarPlot var70 = new org.jfree.chart.plot.PolarPlot(var67, var68, var69);
//     org.jfree.chart.plot.PlotRenderingInfo var73 = null;
//     java.awt.geom.Point2D var74 = null;
//     var70.zoomDomainAxes(100.0d, 0.05d, var73, var74);
//     org.jfree.chart.ChartRenderingInfo var78 = null;
//     org.jfree.chart.plot.PlotRenderingInfo var79 = new org.jfree.chart.plot.PlotRenderingInfo(var78);
//     org.jfree.chart.ChartRenderingInfo var80 = var79.getOwner();
//     java.awt.geom.Point2D var81 = null;
//     var70.zoomDomainAxes(8.0d, (-3.0d), var79, var81);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var85 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var87 = var85.lookupSeriesStroke(1);
//     boolean var88 = var85.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.plot.XYPlot var90 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var91 = var90.getDomainZeroBaselineStroke();
//     var85.setSeriesOutlineStroke(1, var91, false);
//     var70.setRadiusGridlineStroke(var91);
//     var56.setDomainCrosshairStroke(var91);
//     var49.setOutlineStroke(var91);
//     
//     // Checks the contract:  equals-hashcode on var25 and var90
//     assertTrue("Contract failed: equals-hashcode on var25 and var90", var25.equals(var90) ? var25.hashCode() == var90.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var90 and var25
//     assertTrue("Contract failed: equals-hashcode on var90 and var25", var90.equals(var25) ? var90.hashCode() == var25.hashCode() : true);
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var20 and var85.", var20.equals(var85) == var85.equals(var20));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var29 and var85.", var29.equals(var85) == var85.equals(var29));
//     
//     // This assertion (symmetry of equals) fails 
//     assertTrue("Contract failed: equals-symmetric on var45 and var85.", var45.equals(var85) == var85.equals(var45));
// 
//   }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    boolean var1 = var0.getRenderAsPercentages();
    var0.setBaseCreateEntities(true, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var4 = var3.getBaseTimeline();
    long var5 = var3.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var6 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var7 = var6.getBaseTimeline();
    java.util.Date var9 = var7.getDate(10L);
    boolean var10 = var3.containsDomainValue(var9);
    org.jfree.chart.axis.SegmentedTimeline var11 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var12 = var11.getBaseTimeline();
    java.util.Date var14 = var12.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var16 = var15.getBaseTimeline();
    java.util.Date var18 = var16.getDate(10L);
    var12.addException(var18);
    org.jfree.chart.axis.SegmentedTimeline var20 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var21 = var20.getBaseTimeline();
    boolean var24 = var21.containsDomainRange((-1L), 10L);
    long var25 = var21.getSegmentsExcludedSize();
    int var26 = var21.getSegmentsIncluded();
    org.jfree.chart.axis.SegmentedTimeline var27 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var28 = var27.getBaseTimeline();
    java.util.Date var30 = var28.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var31 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var32 = var31.getBaseTimeline();
    java.util.Date var34 = var32.getDate(10L);
    var28.addException(var34);
    boolean var36 = var21.containsDomainValue(var34);
    org.jfree.data.time.DateRange var37 = new org.jfree.data.time.DateRange(var18, var34);
    org.jfree.data.gantt.Task var38 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", var9, var34);
    org.jfree.chart.axis.SegmentedTimeline.Segment var39 = var0.getSegment(var9);
    java.awt.Paint var40 = null;
    org.jfree.chart.plot.PiePlot3D var41 = new org.jfree.chart.plot.PiePlot3D();
    double var42 = var41.getShadowXOffset();
    var41.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var45 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var47 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var45, 100);
    var41.setDataset(var47);
    double var49 = var41.getShadowYOffset();
    double var50 = var41.getMaximumLabelWidth();
    java.awt.Stroke var51 = var41.getBaseSectionOutlineStroke();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.plot.CategoryMarker var52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var39, var40, var51);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(15, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.text.AttributedString var0 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var8 = null;
    var6.setSeriesItemLabelGenerator(2, var8);
    java.awt.Font var10 = var6.getBaseItemLabelFont();
    java.lang.Boolean var12 = var6.getSeriesVisibleInLegend(100);
    java.awt.Stroke var15 = var6.getItemStroke(15, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
    boolean var21 = var18.getAutoPopulateSeriesFillPaint();
    java.lang.Object var22 = var18.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var25.setBaseCreateEntities(false);
    java.lang.Boolean var29 = null;
    var25.setSeriesVisibleInLegend(0, var29, true);
    boolean var32 = var25.getAutoPopulateSeriesStroke();
    java.awt.Shape var34 = var25.lookupSeriesShape((-2));
    boolean var36 = var25.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var37 = var25.getBasePositiveItemLabelPosition();
    var18.setBasePositiveItemLabelPosition(var37, false);
    var6.setBasePositiveItemLabelPosition(var37);
    java.awt.Shape var45 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var50 = var48.lookupSeriesStroke(1);
    java.awt.Paint var52 = var48.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var53 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var54 = var53.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var57 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var59 = var57.lookupSeriesStroke(1);
    java.awt.Paint var61 = var57.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var62 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var45, var52, var54, var61);
    java.awt.Shape var63 = var62.getLine();
    org.jfree.chart.entity.ChartEntity var66 = new org.jfree.chart.entity.ChartEntity(var63, "hi!", "hi!");
    var6.setBaseShape(var63, false);
    java.awt.Shape var69 = var6.getBaseShape();
    java.awt.Paint var70 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.LegendItem var71 = new org.jfree.chart.LegendItem(var0, "Polar Plot", "May", "", var69, var70);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    double var2 = var0.getLabelLinkMargin();
    org.jfree.chart.event.MarkerChangeEvent var3 = null;
    var0.markerChanged(var3);
    var0.setIgnoreNullValues(false);
    java.awt.Paint var7 = null;
    var0.setLabelOutlinePaint(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.05d);

  }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var1 = var0.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var2 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var1);
//     org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var4 = var1.equals((java.lang.Object)var3);
//     org.jfree.data.general.DatasetGroup var5 = var3.getGroup();
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month();
//     int var7 = var3.indexOf((java.lang.Comparable)var6);
//     long var8 = var6.getSerialIndex();
//     org.jfree.data.time.Year var9 = var6.getYear();
//     java.util.Calendar var10 = null;
//     long var11 = var9.getFirstMillisecond(var10);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.chart.title.Title var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.event.TitleChangeEvent var1 = new org.jfree.chart.event.TitleChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setAutoPopulateSeriesPaint(false);
    var0.setBaseLinesVisible(false);
    org.jfree.chart.labels.CategoryItemLabelGenerator var5 = null;
    var0.setBaseItemLabelGenerator(var5, true);

  }

  public void test460() {}
//   public void test460() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var2 = null;
//     var1.axisChanged(var2);
//     java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
//     var0.setBackgroundPaint(var4);
//     var0.clearAnnotations();
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     int var9 = var8.getSeriesCount();
//     java.awt.Graphics2D var10 = null;
//     java.awt.geom.Rectangle2D var11 = null;
//     var8.drawBackgroundImage(var10, var11);
//     org.jfree.chart.plot.PlotRenderingInfo var14 = null;
//     java.awt.geom.Point2D var15 = null;
//     var8.zoomRangeAxes((-1.0d), var14, var15);
//     org.jfree.chart.event.PlotChangeListener var17 = null;
//     var8.removeChangeListener(var17);
//     org.jfree.chart.JFreeChart var19 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var8);
//     org.jfree.chart.title.TextTitle var20 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.event.TitleChangeListener var21 = null;
//     var20.removeChangeListener(var21);
//     var19.setTitle(var20);
//     boolean var25 = var19.equals((java.lang.Object)"RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var0.addChangeListener((org.jfree.chart.event.PlotChangeListener)var19);
//     
//     // Checks the contract:  equals-hashcode on var1 and var8
//     assertTrue("Contract failed: equals-hashcode on var1 and var8", var1.equals(var8) ? var1.hashCode() == var8.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var8 and var1
//     assertTrue("Contract failed: equals-hashcode on var8 and var1", var8.equals(var1) ? var8.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     var41.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var44 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var41);
//     double var45 = var41.getValue();
//     java.lang.Class var46 = null;
//     java.util.EventListener[] var47 = var41.getListeners(var46);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    java.awt.Paint var47 = var19.getFillPaint();
    org.jfree.chart.util.StrokeList var48 = new org.jfree.chart.util.StrokeList();
    org.jfree.chart.plot.XYPlot var50 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var51 = null;
    var50.axisChanged(var51);
    java.awt.Paint var53 = var50.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var54 = null;
    var50.notifyListeners(var54);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var60 = var58.lookupSeriesStroke(1);
    var50.setDomainCrosshairStroke(var60);
    org.jfree.chart.plot.PiePlot3D var62 = new org.jfree.chart.plot.PiePlot3D();
    double var63 = var62.getShadowXOffset();
    var62.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var70 = var68.lookupSeriesStroke(1);
    var62.setLabelLinkStroke(var70);
    var50.setDomainGridlineStroke(var70);
    var48.setStroke(12, var70);
    org.jfree.chart.title.TextTitle var74 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var75 = var74.getPadding();
    org.jfree.data.general.SeriesChangeEvent var76 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var75);
    org.jfree.data.gantt.TaskSeriesCollection var77 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var78 = var75.equals((java.lang.Object)var77);
    org.jfree.chart.block.LineBorder var79 = new org.jfree.chart.block.LineBorder(var47, var70, var75);
    org.jfree.chart.plot.RingPlot var80 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var81 = var80.getShadowPaint();
    boolean var82 = var80.isCircular();
    boolean var83 = var75.equals((java.lang.Object)var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == false);

  }

  public void test463() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.event.TitleChangeListener var14 = null;
    var13.removeChangeListener(var14);
    var12.setTitle(var13);
    org.jfree.chart.event.ChartProgressListener var17 = null;
    var12.removeProgressListener(var17);
    java.awt.Image var19 = var12.getBackgroundImage();
    float var20 = var12.getBackgroundImageAlpha();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0.5f);

  }

  public void test464() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    java.awt.Shape var15 = org.jfree.chart.util.ShapeUtilities.rotateShape(var11, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var18 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var20 = var18.equals((java.lang.Object)(-1));
    var18.validateObject();
    org.jfree.data.time.SpreadsheetDate var23 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var26 = var23.isBefore(var25);
    int var27 = var23.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var29 = new org.jfree.chart.entity.CategoryItemEntity(var15, "hi!", "", (org.jfree.data.category.CategoryDataset)var18, (java.lang.Comparable)var23, (java.lang.Comparable)(-3.0d));
    org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var34 = var31.isBefore(var33);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var38 = var36.getPreviousDayOfWeek(1);
    boolean var40 = var23.isInRange((org.jfree.data.time.SerialDate)var31, var38, 1900);
    boolean var42 = var31.equals((java.lang.Object)0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
//     int var2 = var1.getSeriesCount();
//     java.awt.Graphics2D var3 = null;
//     java.awt.geom.Rectangle2D var4 = null;
//     var1.drawBackgroundImage(var3, var4);
//     org.jfree.chart.plot.PlotRenderingInfo var7 = null;
//     java.awt.geom.Point2D var8 = null;
//     var1.zoomRangeAxes((-1.0d), var7, var8);
//     org.jfree.chart.event.PlotChangeListener var10 = null;
//     var1.removeChangeListener(var10);
//     org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
//     var12.setBackgroundImageAlignment(1);
//     java.lang.Object var15 = null;
//     boolean var16 = var12.equals(var15);
//     org.jfree.chart.axis.SegmentedTimeline var17 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var18 = var17.getBaseTimeline();
//     boolean var20 = var18.containsDomainValue((-1L));
//     long var22 = var18.toTimelineValue(10L);
//     org.jfree.data.DefaultKeyedValues2D var24 = new org.jfree.data.DefaultKeyedValues2D(false);
//     var24.removeValue((java.lang.Comparable)1, (java.lang.Comparable)2);
//     java.util.List var28 = var24.getColumnKeys();
//     var18.setExceptionSegments(var28);
//     var12.setSubtitles(var28);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var33 = null;
//     var32.axisChanged(var33);
//     java.awt.Paint var35 = var32.getRangeZeroBaselinePaint();
//     var31.setBackgroundPaint(var35);
//     org.jfree.chart.renderer.xy.XYItemRenderer var37 = var31.getRenderer();
//     java.awt.Stroke var38 = var31.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var39 = null;
//     var31.removeChangeListener(var39);
//     java.awt.Paint var41 = var31.getRangeCrosshairPaint();
//     boolean var42 = var31.isRangeCrosshairLockedOnData();
//     java.awt.Stroke var43 = var31.getOutlineStroke();
//     var12.setBorderStroke(var43);
//     
//     // Checks the contract:  equals-hashcode on var1 and var32
//     assertTrue("Contract failed: equals-hashcode on var1 and var32", var1.equals(var32) ? var1.hashCode() == var32.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var32 and var1
//     assertTrue("Contract failed: equals-hashcode on var32 and var1", var32.equals(var1) ? var32.hashCode() == var1.hashCode() : true);
// 
//   }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.KeyedObjects2D var0 = new org.jfree.data.KeyedObjects2D();
    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var4.getFollowingDayOfWeek(2);
    org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var11 = var8.isBefore(var10);
    int var12 = var8.getYYYY();
    boolean var14 = var2.isInRange(var4, (org.jfree.data.time.SerialDate)var8, 0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.removeRow((java.lang.Comparable)0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test467() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }


    org.jfree.chart.axis.CategoryAxis3D var2 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var4 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var6 = var4.equals((java.lang.Object)0.0f);
    java.lang.Object var7 = null;
    boolean var8 = var4.equals(var7);
    java.awt.Font var9 = var2.getTickLabelFont((java.lang.Comparable)var8);
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=15]", var9);
    java.awt.Paint var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var12 = new org.jfree.chart.text.TextFragment("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", var9, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    java.awt.Font var1 = null;
    org.jfree.chart.axis.NumberAxis3D var3 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var3.setLabelAngle(0.2d);
    var3.setLabel("ChartEntity: tooltip = null");
    java.awt.Shape var12 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var17 = var15.lookupSeriesStroke(1);
    java.awt.Paint var19 = var15.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var20 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var21 = var20.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var26 = var24.lookupSeriesStroke(1);
    java.awt.Paint var28 = var24.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var29 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var12, var19, var21, var28);
    java.awt.Shape var30 = var29.getLine();
    org.jfree.chart.entity.ChartEntity var33 = new org.jfree.chart.entity.ChartEntity(var30, "hi!", "hi!");
    org.jfree.chart.entity.AxisLabelEntity var36 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var3, var30, "({0}, {1}) = {3} - {4}", "hi!");
    var3.setLabel("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    java.awt.Paint var39 = var3.getAxisLinePaint();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.text.TextFragment var41 = new org.jfree.chart.text.TextFragment("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var1, var39, 0.0f);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);

  }

  public void test469() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(10, (-1), (-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test470() {}
//   public void test470() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     java.lang.Object var4 = null;
//     boolean var5 = var0.equals(var4);
//     org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.LegendItemCollection var7 = var6.getLegendItems();
//     var0.setFixedLegendItems(var7);
//     
//     // Checks the contract:  equals-hashcode on var0 and var6
//     assertTrue("Contract failed: equals-hashcode on var0 and var6", var0.equals(var6) ? var0.hashCode() == var6.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var6 and var0
//     assertTrue("Contract failed: equals-hashcode on var6 and var0", var6.equals(var0) ? var6.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    org.jfree.chart.labels.StandardCategorySeriesLabelGenerator var1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var7 = null;
    var5.setSeriesItemLabelGenerator(2, var7);
    java.awt.Font var9 = var5.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var10 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var9);
    boolean var11 = var1.equals((java.lang.Object)var9);
    org.jfree.chart.axis.AxisSpace var12 = new org.jfree.chart.axis.AxisSpace();
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
    org.jfree.chart.event.TitleChangeListener var15 = null;
    var13.addChangeListener(var15);
    boolean var17 = var12.equals((java.lang.Object)var15);
    org.jfree.data.gantt.TaskSeriesCollection var18 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var19 = null;
    boolean var20 = var18.hasListener(var19);
    int var22 = var18.getRowIndex((java.lang.Comparable)0L);
    java.util.List var23 = var18.getRowKeys();
    boolean var24 = var12.equals((java.lang.Object)var18);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var26 = var1.generateLabel((org.jfree.data.category.CategoryDataset)var18, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.chart.renderer.category.LineRenderer3D var1 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var4 = var1.getItemShapeFilled(1, (-2));
//     java.awt.Shape var9 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
//     java.awt.Paint var16 = var12.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var18 = var17.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
//     java.awt.Paint var25 = var21.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var26 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var9, var16, var18, var25);
//     var1.setBaseFillPaint(var25, false);
//     org.jfree.chart.plot.XYPlot var29 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var30 = null;
//     var29.axisChanged(var30);
//     java.awt.Paint var32 = var29.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var33 = null;
//     var29.notifyListeners(var33);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var39 = var37.lookupSeriesStroke(1);
//     var29.setDomainCrosshairStroke(var39);
//     org.jfree.chart.plot.ValueMarker var41 = new org.jfree.chart.plot.ValueMarker((-3.0d), var25, var39);
//     var41.setAlpha(1.0f);
//     org.jfree.chart.event.MarkerChangeEvent var44 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker)var41);
//     org.jfree.chart.plot.Marker var45 = var44.getMarker();
//     java.lang.Object var46 = var45.clone();
//     java.lang.Class var47 = null;
//     java.util.EventListener[] var48 = var45.getListeners(var47);
// 
//   }

  public void test473() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    boolean var4 = var0.isCircular();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var3 = null;
    var2.axisChanged(var3);
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = var2.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var7 = var2.getDomainAxis();
    org.jfree.chart.axis.AxisLocation var9 = null;
    var2.setDomainAxisLocation(2, var9, false);
    java.awt.Graphics2D var12 = null;
    java.awt.geom.Rectangle2D var13 = null;
    org.jfree.data.gantt.TaskSeries var15 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var15.setKey((java.lang.Comparable)10);
    org.jfree.chart.axis.SegmentedTimeline var18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var19 = var18.getBaseTimeline();
    java.util.Date var21 = var19.getDate(10L);
    var15.setKey((java.lang.Comparable)10L);
    java.util.List var23 = var15.getTasks();
    var2.drawRangeTickBands(var12, var13, var23);
    var1.addExceptions(var23);
    var1.addException((-1L));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.jfree.data.DefaultKeyedValues2D var1 = new org.jfree.data.DefaultKeyedValues2D(true);
//     org.jfree.data.category.DefaultCategoryDataset var2 = new org.jfree.data.category.DefaultCategoryDataset();
//     int var4 = var2.getColumnIndex((java.lang.Comparable)0L);
//     var2.clear();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     long var8 = var7.getSerialIndex();
//     org.jfree.chart.plot.PiePlot var9 = new org.jfree.chart.plot.PiePlot();
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var13 = var11.getPreviousDayOfWeek(1);
//     org.jfree.chart.axis.CategoryLabelPositions var14 = new org.jfree.chart.axis.CategoryLabelPositions();
//     org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var17 = null;
//     var16.axisChanged(var17);
//     java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
//     var15.setBackgroundPaint(var19);
//     org.jfree.chart.renderer.xy.XYItemRenderer var21 = var15.getRenderer();
//     java.awt.Stroke var22 = var15.getDomainZeroBaselineStroke();
//     org.jfree.chart.event.PlotChangeListener var23 = null;
//     var15.removeChangeListener(var23);
//     java.awt.Paint var25 = var15.getRangeCrosshairPaint();
//     boolean var26 = var14.equals((java.lang.Object)var25);
//     var9.setSectionPaint((java.lang.Comparable)var13, var25);
//     var2.setValue(6.0d, (java.lang.Comparable)var8, (java.lang.Comparable)var13);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.removeRow((java.lang.Comparable)var8);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate((-2));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     java.util.EventListener var1 = null;
//     boolean var2 = var0.hasListener(var1);
//     int var4 = var0.getRowIndex((java.lang.Comparable)0L);
//     org.jfree.chart.title.TextTitle var5 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var6 = var5.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var7 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var6);
//     var0.seriesChanged(var7);
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var9.axisChanged(var10);
//     java.awt.Paint var12 = var9.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var13 = null;
//     var9.notifyListeners(var13);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
//     var9.setDomainCrosshairStroke(var19);
//     boolean var21 = var0.hasListener((java.util.EventListener)var9);
//     org.jfree.data.gantt.TaskSeries var23 = new org.jfree.data.gantt.TaskSeries("hi!");
//     java.lang.Comparable var24 = var23.getKey();
//     org.jfree.data.gantt.TaskSeriesCollection var25 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var27 = var25.equals((java.lang.Object)(-1));
//     var25.validateObject();
//     var23.addChangeListener((org.jfree.data.general.SeriesChangeListener)var25);
//     var0.remove(var23);
//     
//     // Checks the contract:  equals-hashcode on var0 and var25
//     assertTrue("Contract failed: equals-hashcode on var0 and var25", var0.equals(var25) ? var0.hashCode() == var25.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var25 and var0
//     assertTrue("Contract failed: equals-hashcode on var25 and var0", var25.equals(var0) ? var25.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test478() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var3 = var0.getItemShapeFilled(1, (-2));
    boolean var5 = var0.equals((java.lang.Object)(-1.0d));
    org.jfree.chart.axis.DateTickUnit var9 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    org.jfree.chart.axis.SegmentedTimeline var10 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var11 = var10.getBaseTimeline();
    java.util.Date var13 = var11.getDate(10L);
    java.util.Date var14 = var9.addToDate(var13);
    org.jfree.chart.axis.NumberAxis var15 = null;
    java.awt.Font var20 = null;
    org.jfree.chart.axis.MarkerAxisBand var21 = new org.jfree.chart.axis.MarkerAxisBand(var15, 0.0d, 0.0d, 0.0d, 100.0d, var20);
    org.jfree.chart.renderer.category.LineRenderer3D var22 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var25 = var22.getItemShapeFilled(1, (-2));
    var22.setSeriesShapesFilled(10, (java.lang.Boolean)false);
    boolean var29 = var21.equals((java.lang.Object)false);
    org.jfree.chart.renderer.category.LineRenderer3D var31 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var34 = var31.getItemShapeFilled(1, (-2));
    java.awt.Shape var39 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var44 = var42.lookupSeriesStroke(1);
    java.awt.Paint var46 = var42.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var47 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var48 = var47.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var53 = var51.lookupSeriesStroke(1);
    java.awt.Paint var55 = var51.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var56 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var39, var46, var48, var55);
    var31.setBaseFillPaint(var55, false);
    org.jfree.chart.plot.XYPlot var59 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var60 = null;
    var59.axisChanged(var60);
    java.awt.Paint var62 = var59.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var63 = null;
    var59.notifyListeners(var63);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var69 = var67.lookupSeriesStroke(1);
    var59.setDomainCrosshairStroke(var69);
    org.jfree.chart.plot.ValueMarker var71 = new org.jfree.chart.plot.ValueMarker((-3.0d), var55, var69);
    boolean var72 = var21.equals((java.lang.Object)var55);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var75 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var77 = null;
    var75.setSeriesItemLabelGenerator(2, var77);
    java.awt.Font var79 = var75.getBaseItemLabelFont();
    java.lang.Boolean var81 = var75.getSeriesVisibleInLegend(100);
    java.awt.Stroke var84 = var75.getItemStroke(15, (-1));
    org.jfree.chart.plot.CategoryMarker var85 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable)var9, var55, var84);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setSeriesFillPaint((-2), var55, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);

  }

  public void test479() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var4 = null;
    var2.setSeriesItemLabelGenerator(2, var4);
    java.awt.Font var6 = var2.getBaseItemLabelFont();
    org.jfree.chart.event.RendererChangeListener var7 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.addChangeListener(var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    java.lang.String var1 = var0.getPlotType();
    org.jfree.data.general.WaferMapDataset var2 = null;
    var0.setDataset(var2);
    org.jfree.chart.event.RendererChangeEvent var4 = null;
    var0.rendererChanged(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "WMAP_Plot"+ "'", var1.equals("WMAP_Plot"));

  }

  public void test481() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var1 = var0.getShadowPaint();
    boolean var2 = var0.isCircular();
    double var3 = var0.getInnerSeparatorExtension();
    boolean var4 = var0.isOutlineVisible();
    java.awt.Stroke var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.setLabelLinkStroke(var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
//     var1.setLabelAngle(0.2d);
//     var1.setLabel("ChartEntity: tooltip = null");
//     var1.setAutoRangeIncludesZero(false);
//     org.jfree.chart.util.RectangleInsets var8 = var1.getLabelInsets();
//     org.jfree.chart.axis.NumberAxis var9 = null;
//     java.awt.Font var14 = null;
//     org.jfree.chart.axis.MarkerAxisBand var15 = new org.jfree.chart.axis.MarkerAxisBand(var9, 0.0d, 0.0d, 0.0d, 100.0d, var14);
//     org.jfree.chart.renderer.category.LineRenderer3D var16 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var19 = var16.getItemShapeFilled(1, (-2));
//     var16.setSeriesShapesFilled(10, (java.lang.Boolean)false);
//     boolean var23 = var15.equals((java.lang.Object)false);
//     var1.setMarkerBand(var15);
//     java.awt.Paint var25 = var1.getLabelPaint();
//     java.awt.Graphics2D var26 = null;
//     org.jfree.chart.axis.AxisState var27 = null;
//     java.awt.geom.Rectangle2D var28 = null;
//     org.jfree.chart.axis.AxisSpace var29 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.title.TextTitle var30 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var31 = var30.getPadding();
//     org.jfree.chart.event.TitleChangeListener var32 = null;
//     var30.addChangeListener(var32);
//     boolean var34 = var29.equals((java.lang.Object)var32);
//     var29.setRight(0.05d);
//     java.lang.Object var37 = null;
//     boolean var38 = var29.equals(var37);
//     java.lang.Object var39 = var29.clone();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle();
//     var41.setWidth(0.0d);
//     org.jfree.chart.util.RectangleEdge var44 = var41.getPosition();
//     org.jfree.chart.util.RectangleEdge var45 = org.jfree.chart.util.RectangleEdge.opposite(var44);
//     java.lang.String var46 = var45.toString();
//     var29.ensureAtLeast(6.0d, var45);
//     java.util.List var48 = var1.refreshTicks(var26, var27, var28, var45);
// 
//   }

  public void test483() {}
//   public void test483() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }
// 
// 
//     org.jfree.chart.block.BlockContainer var0 = new org.jfree.chart.block.BlockContainer();
//     java.lang.Object var1 = var0.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var7 = var5.lookupSeriesStroke(1);
//     java.awt.Paint var9 = var5.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var10 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var11 = null;
//     var10.axisChanged(var11);
//     java.awt.Paint var13 = var10.getRangeZeroBaselinePaint();
//     var5.setBaseItemLabelPaint(var13);
//     java.awt.Font var17 = var5.getItemLabelFont(100, 0);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
//     java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.text.TextLine var25 = new org.jfree.chart.text.TextLine("hi!", var17, var24);
//     boolean var26 = var0.equals((java.lang.Object)"hi!");
//     org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var28 = var27.getPadding();
//     org.jfree.chart.event.TitleChangeListener var29 = null;
//     var27.addChangeListener(var29);
//     double var31 = var27.getWidth();
//     org.jfree.chart.axis.NumberAxis var32 = null;
//     java.awt.Font var37 = null;
//     org.jfree.chart.axis.MarkerAxisBand var38 = new org.jfree.chart.axis.MarkerAxisBand(var32, 0.0d, 0.0d, 0.0d, 100.0d, var37);
//     org.jfree.chart.renderer.category.LineRenderer3D var39 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var42 = var39.getItemShapeFilled(1, (-2));
//     var39.setSeriesShapesFilled(10, (java.lang.Boolean)false);
//     boolean var46 = var38.equals((java.lang.Object)false);
//     org.jfree.chart.renderer.category.LineRenderer3D var48 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     boolean var51 = var48.getItemShapeFilled(1, (-2));
//     java.awt.Shape var56 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var61 = var59.lookupSeriesStroke(1);
//     java.awt.Paint var63 = var59.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var64 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var65 = var64.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var70 = var68.lookupSeriesStroke(1);
//     java.awt.Paint var72 = var68.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var73 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var56, var63, var65, var72);
//     var48.setBaseFillPaint(var72, false);
//     org.jfree.chart.plot.XYPlot var76 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var77 = null;
//     var76.axisChanged(var77);
//     java.awt.Paint var79 = var76.getRangeZeroBaselinePaint();
//     org.jfree.chart.event.PlotChangeEvent var80 = null;
//     var76.notifyListeners(var80);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var84 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var86 = var84.lookupSeriesStroke(1);
//     var76.setDomainCrosshairStroke(var86);
//     org.jfree.chart.plot.ValueMarker var88 = new org.jfree.chart.plot.ValueMarker((-3.0d), var72, var86);
//     boolean var89 = var38.equals((java.lang.Object)var72);
//     boolean var90 = var27.equals((java.lang.Object)var72);
//     java.lang.Object var91 = null;
//     var0.add((org.jfree.chart.block.Block)var27, var91);
//     
//     // Checks the contract:  equals-hashcode on var10 and var64
//     assertTrue("Contract failed: equals-hashcode on var10 and var64", var10.equals(var64) ? var10.hashCode() == var64.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var64 and var10
//     assertTrue("Contract failed: equals-hashcode on var64 and var10", var64.equals(var10) ? var64.hashCode() == var10.hashCode() : true);
// 
//   }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
//     org.jfree.chart.LegendItemCollection var1 = var0.getLegendItems();
//     double var2 = var0.getOuterSeparatorExtension();
//     org.jfree.chart.plot.PiePlot3D var3 = new org.jfree.chart.plot.PiePlot3D();
//     double var4 = var3.getShadowXOffset();
//     var3.setDepthFactor(1.0d);
//     org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
//     org.jfree.data.general.PieDataset var9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var7, 100);
//     var3.setDataset(var9);
//     double var11 = var3.getShadowYOffset();
//     double var12 = var3.getDepthFactor();
//     org.jfree.chart.labels.PieSectionLabelGenerator var13 = var3.getLegendLabelGenerator();
//     var0.setLabelGenerator(var13);
//     var0.setOuterSeparatorExtension(100.0d);
//     org.jfree.chart.labels.PieSectionLabelGenerator var17 = var0.getLegendLabelGenerator();
//     
//     // Checks the contract:  equals-hashcode on var13 and var17
//     assertTrue("Contract failed: equals-hashcode on var13 and var17", var13.equals(var17) ? var13.hashCode() == var17.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var17 and var13
//     assertTrue("Contract failed: equals-hashcode on var17 and var13", var17.equals(var13) ? var17.hashCode() == var13.hashCode() : true);
// 
//   }

  public void test485() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.axis.AxisSpace var1 = var0.getFixedDomainAxisSpace();
    org.jfree.chart.plot.DrawingSupplier var2 = null;
    var0.setDrawingSupplier(var2);
    org.jfree.chart.util.Layer var5 = null;
    java.util.Collection var6 = var0.getDomainMarkers(100, var5);
    java.awt.Paint var7 = var0.getRangeGridlinePaint();
    org.jfree.chart.renderer.category.LineRenderer3D var9 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var12 = var9.getItemShapeFilled(1, (-2));
    java.awt.Shape var17 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var22 = var20.lookupSeriesStroke(1);
    java.awt.Paint var24 = var20.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var26 = var25.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
    java.awt.Paint var33 = var29.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var34 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var17, var24, var26, var33);
    var9.setBaseFillPaint(var33, false);
    org.jfree.chart.plot.XYPlot var37 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var38 = null;
    var37.axisChanged(var38);
    java.awt.Paint var40 = var37.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var41 = null;
    var37.notifyListeners(var41);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
    var37.setDomainCrosshairStroke(var47);
    org.jfree.chart.plot.ValueMarker var49 = new org.jfree.chart.plot.ValueMarker((-3.0d), var33, var47);
    java.awt.Paint var50 = var49.getOutlinePaint();
    java.awt.Paint var51 = var49.getOutlinePaint();
    boolean var53 = var49.equals((java.lang.Object)0L);
    org.jfree.data.xy.XYDataset var54 = null;
    org.jfree.chart.axis.ValueAxis var55 = null;
    org.jfree.chart.renderer.PolarItemRenderer var56 = null;
    org.jfree.chart.plot.PolarPlot var57 = new org.jfree.chart.plot.PolarPlot(var54, var55, var56);
    var57.setAngleGridlinesVisible(false);
    var49.removeChangeListener((org.jfree.chart.event.MarkerChangeListener)var57);
    org.jfree.chart.util.Layer var61 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.addDomainMarker((org.jfree.chart.plot.Marker)var49, var61);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    var1.setWidth(0.0d);
    org.jfree.chart.util.RectangleEdge var4 = var1.getPosition();
    java.awt.Font var5 = var1.getFont();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var8 = null;
    var7.axisChanged(var8);
    java.awt.Paint var10 = var7.getRangeZeroBaselinePaint();
    var6.setBackgroundPaint(var10);
    org.jfree.chart.renderer.xy.XYItemRenderer var12 = var6.getRenderer();
    java.awt.Stroke var13 = var6.getDomainZeroBaselineStroke();
    org.jfree.chart.event.PlotChangeListener var14 = null;
    var6.removeChangeListener(var14);
    java.awt.Paint var16 = var6.getRangeCrosshairPaint();
    org.jfree.chart.title.TextTitle var17 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var18 = var17.getPadding();
    org.jfree.chart.event.TitleChangeListener var19 = null;
    var17.addChangeListener(var19);
    org.jfree.chart.util.RectangleEdge var21 = var17.getPosition();
    java.lang.String var22 = var21.toString();
    org.jfree.data.time.Month var23 = new org.jfree.data.time.Month();
    org.jfree.chart.title.TextTitle var24 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var26 = var25.getPadding();
    var24.setPadding(var26);
    boolean var28 = var23.equals((java.lang.Object)var24);
    org.jfree.chart.util.HorizontalAlignment var29 = var24.getTextAlignment();
    org.jfree.chart.util.VerticalAlignment var30 = null;
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    int var33 = var32.getSeriesCount();
    java.awt.Graphics2D var34 = null;
    java.awt.geom.Rectangle2D var35 = null;
    var32.drawBackgroundImage(var34, var35);
    org.jfree.chart.plot.PlotRenderingInfo var38 = null;
    java.awt.geom.Point2D var39 = null;
    var32.zoomRangeAxes((-1.0d), var38, var39);
    org.jfree.chart.event.PlotChangeListener var41 = null;
    var32.removeChangeListener(var41);
    org.jfree.chart.JFreeChart var43 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var32);
    org.jfree.chart.title.TextTitle var44 = var43.getTitle();
    org.jfree.chart.util.RectangleInsets var45 = var43.getPadding();
    org.jfree.chart.title.TextTitle var46 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var47 = var46.getPadding();
    org.jfree.data.general.SeriesChangeEvent var48 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var47);
    org.jfree.data.gantt.TaskSeriesCollection var49 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var50 = var47.equals((java.lang.Object)var49);
    double var52 = var47.calculateLeftOutset(0.05d);
    var43.setPadding(var47);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.chart.title.TextTitle var54 = new org.jfree.chart.title.TextTitle("RectangleEdge.TOP", var5, var16, var21, var29, var30, var47);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + "RectangleEdge.TOP"+ "'", var22.equals("RectangleEdge.TOP"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1.0d);

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.chart.plot.WaferMapPlot var0 = new org.jfree.chart.plot.WaferMapPlot();
    org.jfree.chart.event.RendererChangeEvent var1 = null;
    var0.rendererChanged(var1);
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    java.lang.String var5 = var0.getPlotType();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "WMAP_Plot"+ "'", var5.equals("WMAP_Plot"));

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var5 = var2.isBefore(var4);
    int var6 = var2.getYYYY();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(15, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var12 = var9.isBefore(var11);
    boolean var13 = var2.isOnOrAfter((org.jfree.data.time.SerialDate)var9);
    org.jfree.chart.plot.XYPlot var15 = new org.jfree.chart.plot.XYPlot();
    int var16 = var15.getSeriesCount();
    java.awt.Graphics2D var17 = null;
    java.awt.geom.Rectangle2D var18 = null;
    var15.drawBackgroundImage(var17, var18);
    org.jfree.chart.plot.PlotRenderingInfo var21 = null;
    java.awt.geom.Point2D var22 = null;
    var15.zoomRangeAxes((-1.0d), var21, var22);
    org.jfree.chart.event.PlotChangeListener var24 = null;
    var15.removeChangeListener(var24);
    org.jfree.chart.JFreeChart var26 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var15);
    org.jfree.chart.title.LegendTitle var28 = var26.getLegend(5);
    java.awt.Image var29 = var26.getBackgroundImage();
    org.jfree.chart.title.LegendTitle var30 = var26.getLegend();
    org.jfree.chart.plot.RingPlot var31 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var32 = var31.getShadowPaint();
    java.lang.Object var33 = null;
    boolean var34 = var31.equals(var33);
    java.awt.Font var35 = var31.getNoDataMessageFont();
    var30.setItemFont(var35);
    org.jfree.chart.block.BlockContainer var37 = var30.getItemContainer();
    org.jfree.chart.util.RectangleAnchor var38 = var30.getLegendItemGraphicAnchor();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var39 = var2.compareTo((java.lang.Object)var30);
      fail("Expected exception of type java.lang.ClassCastException");
    } catch (java.lang.ClassCastException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var2 = var0.equals((java.lang.Object)(-1));
//     var0.validateObject();
//     org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-1.0d));
//     int var7 = var0.indexOf((java.lang.Comparable)61200000L);
//     int var9 = var0.indexOf((java.lang.Comparable)(-3.0d));
//     var0.validateObject();
//     java.lang.Comparable var11 = null;
//     org.jfree.data.gantt.TaskSeries var12 = var0.getSeries(var11);
// 
//   }

  public void test490() {}
//   public void test490() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }
// 
// 
//     org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
//     org.jfree.chart.plot.XYPlot var2 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var3 = null;
//     var2.axisChanged(var3);
//     org.jfree.chart.renderer.xy.XYItemRenderer var6 = var2.getRenderer((-2));
//     org.jfree.chart.axis.ValueAxis var7 = var2.getDomainAxis();
//     org.jfree.chart.axis.AxisLocation var9 = null;
//     var2.setDomainAxisLocation(2, var9, false);
//     java.awt.Graphics2D var12 = null;
//     java.awt.geom.Rectangle2D var13 = null;
//     org.jfree.data.gantt.TaskSeries var15 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var15.setKey((java.lang.Comparable)10);
//     org.jfree.chart.axis.SegmentedTimeline var18 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var19 = var18.getBaseTimeline();
//     java.util.Date var21 = var19.getDate(10L);
//     var15.setKey((java.lang.Comparable)10L);
//     java.util.List var23 = var15.getTasks();
//     var2.drawRangeTickBands(var12, var13, var23);
//     var1.addExceptions(var23);
//     var1.addBaseTimelineExclusions(1L, 100L);
// 
//   }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-459));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test492() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    org.jfree.data.Range var5 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset)var0, (-1.0d));
    org.jfree.data.Range var7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0, false);
    var0.removeAll();
    boolean var10 = var0.equals((java.lang.Object)12.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var12 = var0.getColumnKey(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var2);
//     org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var5 = var2.equals((java.lang.Object)var4);
//     org.jfree.data.general.DatasetGroup var6 = var4.getGroup();
//     org.jfree.data.time.Month var7 = new org.jfree.data.time.Month();
//     int var8 = var4.indexOf((java.lang.Comparable)var7);
//     long var9 = var7.getSerialIndex();
//     org.jfree.data.time.Year var10 = var7.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(0, var10);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
// 
//   }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var1 = null;
//     var0.axisChanged(var1);
//     java.awt.Paint var3 = var0.getRangeZeroBaselinePaint();
//     java.lang.Object var4 = var0.clone();
//     org.jfree.chart.plot.XYPlot var5 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var6 = null;
//     var5.axisChanged(var6);
//     org.jfree.chart.renderer.xy.XYItemRenderer var9 = var5.getRenderer((-2));
//     org.jfree.chart.axis.ValueAxis var10 = var5.getDomainAxis();
//     var0.setParent((org.jfree.chart.plot.Plot)var5);
//     
//     // Checks the contract:  equals-hashcode on var0 and var5
//     assertTrue("Contract failed: equals-hashcode on var0 and var5", var0.equals(var5) ? var0.hashCode() == var5.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var5 and var0
//     assertTrue("Contract failed: equals-hashcode on var5 and var0", var5.equals(var0) ? var5.hashCode() == var0.hashCode() : true);
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var1 = null;
    boolean var2 = var0.hasListener(var1);
    org.jfree.data.Range var3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var0);
    org.jfree.data.gantt.TaskSeries var5 = new org.jfree.data.gantt.TaskSeries("hi!");
    var0.remove(var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var0.remove(14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test496() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var3.setBaseCreateEntities(false);
    java.lang.Boolean var7 = null;
    var3.setSeriesVisibleInLegend(0, var7, true);
    boolean var10 = var3.getAutoPopulateSeriesStroke();
    java.awt.Shape var12 = var3.lookupSeriesShape((-2));
    java.awt.Shape var16 = org.jfree.chart.util.ShapeUtilities.rotateShape(var12, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var19 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var21 = var19.equals((java.lang.Object)(-1));
    var19.validateObject();
    org.jfree.data.time.SpreadsheetDate var24 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var27 = var24.isBefore(var26);
    int var28 = var24.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var30 = new org.jfree.chart.entity.CategoryItemEntity(var16, "hi!", "", (org.jfree.data.category.CategoryDataset)var19, (java.lang.Comparable)var24, (java.lang.Comparable)(-3.0d));
    org.jfree.data.time.SpreadsheetDate var32 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var35 = var32.isBefore(var34);
    org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var39 = var37.getPreviousDayOfWeek(1);
    boolean var41 = var24.isInRange((org.jfree.data.time.SerialDate)var32, var39, 1900);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(1900, (org.jfree.data.time.SerialDate)var24);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    double var2 = var1.getMinimumBarLength();
    org.jfree.data.category.DefaultCategoryDataset var3 = new org.jfree.data.category.DefaultCategoryDataset();
    int var5 = var3.getColumnIndex((java.lang.Comparable)0L);
    var3.clear();
    org.jfree.data.Range var7 = var1.findRangeBounds((org.jfree.data.category.CategoryDataset)var3);
    java.lang.Comparable var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var3.addValue(0.25d, var9, (java.lang.Comparable)"DatasetRenderingOrder.REVERSE");
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test498() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }


    java.awt.geom.Arc2D var0 = null;
    java.awt.geom.Arc2D var1 = null;
    boolean var2 = org.jfree.chart.util.ShapeUtilities.equal(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.chart.axis.NumberAxis3D var1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var1.setPositiveArrowVisible(true);
    org.jfree.data.time.DateRange var6 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    var1.setRange((org.jfree.data.Range)var6, true, false);
    double var10 = var6.getUpperBound();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1.0d);

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("hi!");
//     java.lang.Comparable var2 = var1.getKey();
//     org.jfree.data.gantt.TaskSeriesCollection var3 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var5 = var3.equals((java.lang.Object)(-1));
//     var3.validateObject();
//     var1.addChangeListener((org.jfree.data.general.SeriesChangeListener)var3);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var10.setBaseCreateEntities(false);
//     java.lang.Boolean var14 = null;
//     var10.setSeriesVisibleInLegend(0, var14, true);
//     boolean var17 = var10.getAutoPopulateSeriesStroke();
//     java.awt.Shape var19 = var10.lookupSeriesShape((-2));
//     java.awt.Shape var23 = org.jfree.chart.util.ShapeUtilities.rotateShape(var19, 4.0d, 10.0f, 10.0f);
//     org.jfree.data.gantt.TaskSeriesCollection var26 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var28 = var26.equals((java.lang.Object)(-1));
//     var26.validateObject();
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var34 = var31.isBefore(var33);
//     int var35 = var31.getYYYY();
//     org.jfree.chart.entity.CategoryItemEntity var37 = new org.jfree.chart.entity.CategoryItemEntity(var23, "hi!", "", (org.jfree.data.category.CategoryDataset)var26, (java.lang.Comparable)var31, (java.lang.Comparable)(-3.0d));
//     org.jfree.data.time.SpreadsheetDate var39 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var42 = var39.isBefore(var41);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var46 = var44.getPreviousDayOfWeek(1);
//     boolean var48 = var31.isInRange((org.jfree.data.time.SerialDate)var39, var46, 1900);
//     int var49 = var3.getColumnIndex((java.lang.Comparable)var46);
//     
//     // Checks the contract:  equals-hashcode on var3 and var26
//     assertTrue("Contract failed: equals-hashcode on var3 and var26", var3.equals(var26) ? var3.hashCode() == var26.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var26 and var3
//     assertTrue("Contract failed: equals-hashcode on var26 and var3", var26.equals(var3) ? var26.hashCode() == var3.hashCode() : true);
// 
//   }

}
