
import junit.framework.*;

public class RandoopTest8 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test1"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var4.setLabelAngle(0.2d);
    var4.setLowerBound(12.0d);
    var4.setLowerBound(0.0d);
    var4.setTickMarksVisible(true);
    org.jfree.data.Range var13 = var4.getRange();
    var0.setRange(var13);
    var0.setUpperMargin(1.0d);
    boolean var17 = var0.isInverted();
    org.jfree.chart.axis.DateTickUnit var20 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    int var21 = var20.getRollCount();
    java.util.Date var22 = var0.calculateLowestVisibleTickValue(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test2() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test2"); }


    org.jfree.chart.axis.CategoryAxis3D var0 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var2 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var4 = var2.equals((java.lang.Object)0.0f);
    java.lang.Object var5 = null;
    boolean var6 = var2.equals(var5);
    java.awt.Font var7 = var0.getTickLabelFont((java.lang.Comparable)var6);
    var0.setMaximumCategoryLabelLines((-459));
    var0.setMaximumCategoryLabelWidthRatio((-1.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test3"); }


    org.jfree.chart.ui.ProjectInfo var0 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var1 = null;
    var0.setLogo(var1);
    org.jfree.chart.ui.ProjectInfo var3 = new org.jfree.chart.ui.ProjectInfo();
    java.awt.Image var4 = null;
    var3.setLogo(var4);
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var3);
    org.jfree.chart.ui.Library[] var7 = var0.getOptionalLibraries();
    java.lang.String var8 = var0.getLicenceName();
    org.jfree.chart.ui.ProjectInfo var9 = new org.jfree.chart.ui.ProjectInfo();
    var9.addOptionalLibrary("ChartEntity: tooltip = null");
    java.lang.String var12 = var9.getVersion();
    org.jfree.chart.block.BlockContainer var13 = new org.jfree.chart.block.BlockContainer();
    java.lang.Object var14 = var13.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var20 = var18.lookupSeriesStroke(1);
    java.awt.Paint var22 = var18.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var23 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var24 = null;
    var23.axisChanged(var24);
    java.awt.Paint var26 = var23.getRangeZeroBaselinePaint();
    var18.setBaseItemLabelPaint(var26);
    java.awt.Font var30 = var18.getItemLabelFont(100, 0);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var35 = var33.lookupSeriesStroke(1);
    java.awt.Paint var37 = var33.lookupSeriesOutlinePaint(10);
    org.jfree.chart.text.TextLine var38 = new org.jfree.chart.text.TextLine("hi!", var30, var37);
    boolean var39 = var13.equals((java.lang.Object)"hi!");
    org.jfree.chart.block.Arrangement var40 = var13.getArrangement();
    java.util.List var41 = var13.getBlocks();
    var9.setContributors(var41);
    var0.addOptionalLibrary((org.jfree.chart.ui.Library)var9);
    var0.setLicenceText("UnitType.ABSOLUTE");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test4"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var16 = var14.lookupSeriesStroke(1);
    java.awt.Paint var18 = var14.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var19 = new org.jfree.chart.title.LegendGraphic(var11, var18);
    java.awt.Shape var24 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var29 = var27.lookupSeriesStroke(1);
    java.awt.Paint var31 = var27.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var32 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var33 = var32.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var41 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var24, var31, var33, var40);
    java.awt.Shape var42 = var41.getLine();
    org.jfree.chart.entity.ChartEntity var45 = new org.jfree.chart.entity.ChartEntity(var42, "hi!", "hi!");
    var19.setLine(var42);
    boolean var47 = var19.isLineVisible();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test5"); }


    org.jfree.data.gantt.TaskSeriesCollection var0 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var2 = var0.equals((java.lang.Object)(-1));
    var0.validateObject();
    int var4 = var0.getSeriesCount();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var0, 12);
    org.jfree.chart.plot.RingPlot var7 = new org.jfree.chart.plot.RingPlot(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test6() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test6"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    java.awt.Paint var2 = var0.getLabelBackgroundPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var6.setBaseCreateEntities(false);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var14 = var12.lookupSeriesStroke(1);
    var6.setSeriesStroke(10, var14);
    var0.setSectionOutlineStroke((java.lang.Comparable)(-2), var14);
    java.awt.Paint var18 = var0.getSectionOutlinePaint((java.lang.Comparable)"");
    double var19 = var0.getLabelLinkMargin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0.05d);

  }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test7"); }


    org.jfree.chart.axis.SegmentedTimeline var0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var1 = var0.getBaseTimeline();
    long var2 = var0.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var4 = var3.getBaseTimeline();
    java.util.Date var6 = var4.getDate(10L);
    boolean var7 = var0.containsDomainValue(var6);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var13 = null;
    var11.setSeriesItemLabelGenerator(2, var13);
    java.awt.Font var15 = var11.getBaseItemLabelFont();
    java.lang.Boolean var17 = var11.getSeriesVisibleInLegend(100);
    java.awt.Stroke var20 = var11.getItemStroke(15, (-1));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var25 = var23.lookupSeriesStroke(1);
    boolean var26 = var23.getAutoPopulateSeriesFillPaint();
    java.lang.Object var27 = var23.clone();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var30.setBaseCreateEntities(false);
    java.lang.Boolean var34 = null;
    var30.setSeriesVisibleInLegend(0, var34, true);
    boolean var37 = var30.getAutoPopulateSeriesStroke();
    java.awt.Shape var39 = var30.lookupSeriesShape((-2));
    boolean var41 = var30.isSeriesVisibleInLegend(1);
    org.jfree.chart.labels.ItemLabelPosition var42 = var30.getBasePositiveItemLabelPosition();
    var23.setBasePositiveItemLabelPosition(var42, false);
    var11.setBasePositiveItemLabelPosition(var42);
    org.jfree.chart.text.TextAnchor var46 = var42.getRotationAnchor();
    org.jfree.chart.text.TextBlock var48 = null;
    org.jfree.chart.text.TextBlockAnchor var49 = null;
    org.jfree.chart.renderer.category.LineRenderer3D var50 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var53 = var50.getItemShapeFilled(1, (-2));
    boolean var55 = var50.equals((java.lang.Object)(-1.0d));
    var50.setBaseSeriesVisibleInLegend(true, true);
    org.jfree.chart.labels.ItemLabelPosition var61 = var50.getNegativeItemLabelPosition((-2), (-459));
    org.jfree.chart.text.TextAnchor var62 = var61.getTextAnchor();
    org.jfree.chart.axis.CategoryTick var64 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable)(short)(-1), var48, var49, var62, 100.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var67 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var67.setBaseCreateEntities(false);
    java.lang.Boolean var71 = null;
    var67.setSeriesVisibleInLegend(0, var71, true);
    boolean var74 = var67.getAutoPopulateSeriesStroke();
    java.awt.Shape var76 = var67.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var79 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var81 = var79.lookupSeriesStroke(1);
    java.awt.Paint var83 = var79.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var84 = new org.jfree.chart.title.LegendGraphic(var76, var83);
    org.jfree.chart.util.RectangleAnchor var85 = var84.getShapeAnchor();
    boolean var86 = var64.equals((java.lang.Object)var84);
    org.jfree.chart.text.TextAnchor var87 = var64.getTextAnchor();
    org.jfree.chart.axis.DateTick var89 = new org.jfree.chart.axis.DateTick(var6, "TextBlockAnchor.BOTTOM_CENTER", var46, var87, 0.35d);
    java.util.Date var90 = var89.getDate();
    java.util.Date var91 = var89.getDate();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test8"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    var0.setBackgroundPaint(var4);
    org.jfree.chart.util.RectangleEdge var6 = var0.getDomainAxisEdge();
    org.jfree.chart.util.RectangleEdge var7 = var0.getDomainAxisEdge();
    int var8 = var0.getWeight();
    boolean var9 = var0.isDomainZoomable();
    java.awt.Stroke var10 = var0.getRangeGridlineStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer var11 = null;
    int var12 = var0.getIndexOf(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test9() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test9"); }


    org.jfree.chart.renderer.category.StackedBarRenderer var1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    var1.setAutoPopulateSeriesPaint(true);
    java.awt.Paint var6 = var1.getItemLabelPaint(1901, 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test10"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.ValueAxis var1 = null;
    org.jfree.chart.renderer.PolarItemRenderer var2 = null;
    org.jfree.chart.plot.PolarPlot var3 = new org.jfree.chart.plot.PolarPlot(var0, var1, var2);
    org.jfree.chart.plot.PlotRenderingInfo var6 = null;
    java.awt.geom.Point2D var7 = null;
    var3.zoomDomainAxes(100.0d, 0.05d, var6, var7);
    org.jfree.data.xy.XYDataset var9 = var3.getDataset();
    var3.setRadiusGridlinesVisible(true);
    org.jfree.chart.renderer.category.LineRenderer3D var12 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var12.setBaseSeriesVisible(false);
    var12.setBaseCreateEntities(false, false);
    java.lang.Boolean var19 = null;
    var12.setSeriesShapesFilled(12, var19);
    boolean var23 = var12.isItemLabelVisible(12, 1);
    java.awt.Font var24 = var12.getBaseItemLabelFont();
    var3.setAngleLabelFont(var24);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var30 = var28.lookupSeriesStroke(1);
    java.awt.Paint var32 = var28.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var34 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var35 = null;
    var34.axisChanged(var35);
    java.awt.Paint var37 = var34.getRangeZeroBaselinePaint();
    var28.setSeriesItemLabelPaint(100, var37, false);
    org.jfree.chart.labels.IntervalCategoryToolTipGenerator var41 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
    var28.setSeriesToolTipGenerator(2, (org.jfree.chart.labels.CategoryToolTipGenerator)var41, true);
    org.jfree.chart.urls.StandardCategoryURLGenerator var44 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var49 = var47.lookupSeriesStroke(1);
    boolean var50 = var47.getAutoPopulateSeriesFillPaint();
    java.lang.Object var51 = var47.clone();
    boolean var52 = var47.getBaseItemLabelsVisible();
    boolean var53 = var44.equals((java.lang.Object)var52);
    var28.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var44, false);
    java.awt.Stroke var58 = var28.getItemStroke((-2), (-1));
    var3.setRadiusGridlineStroke(var58);
    int var60 = var3.getSeriesCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test11"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var2 = null;
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var2, var4, var5);
    java.util.List var7 = var6.getColumnKeys();
    java.lang.Comparable var9 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var6.setEndValue((-2), var9, (java.lang.Number)100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test12"); }


    org.jfree.chart.renderer.category.BarRenderer3D var2 = new org.jfree.chart.renderer.category.BarRenderer3D(0.05d, 0.0d);

  }

  public void test13() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test13"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var1 = null;
    var0.axisChanged(var1);
    org.jfree.chart.renderer.xy.XYItemRenderer var4 = var0.getRenderer((-2));
    org.jfree.chart.axis.ValueAxis var5 = var0.getDomainAxis();
    var0.setRangeCrosshairValue(100.0d, true);
    boolean var9 = var0.isRangeCrosshairLockedOnData();
    org.jfree.data.xy.XYDataset var10 = null;
    org.jfree.chart.axis.ValueAxis var11 = null;
    org.jfree.chart.renderer.PolarItemRenderer var12 = null;
    org.jfree.chart.plot.PolarPlot var13 = new org.jfree.chart.plot.PolarPlot(var10, var11, var12);
    var13.setAngleLabelsVisible(true);
    org.jfree.chart.plot.XYPlot var16 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var17 = null;
    var16.axisChanged(var17);
    java.awt.Paint var19 = var16.getRangeZeroBaselinePaint();
    org.jfree.chart.util.RectangleEdge var20 = var16.getRangeAxisEdge();
    boolean var21 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(var20);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var24.setBaseCreateEntities(false);
    java.lang.Boolean var28 = null;
    var24.setSeriesVisibleInLegend(0, var28, true);
    boolean var31 = var24.getAutoPopulateSeriesStroke();
    java.awt.Shape var33 = var24.lookupSeriesShape((-2));
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.title.LegendGraphic var41 = new org.jfree.chart.title.LegendGraphic(var33, var40);
    org.jfree.chart.util.RectangleAnchor var42 = var41.getShapeAnchor();
    java.awt.Stroke var43 = var41.getOutlineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var46 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var46.setBaseCreateEntities(false);
    java.lang.Boolean var50 = null;
    var46.setSeriesVisibleInLegend(0, var50, true);
    boolean var53 = var46.getAutoPopulateSeriesStroke();
    java.awt.Shape var55 = var46.lookupSeriesShape((-2));
    java.awt.Shape var59 = org.jfree.chart.util.ShapeUtilities.rotateShape(var55, 4.0d, 10.0f, 10.0f);
    org.jfree.data.gantt.TaskSeriesCollection var62 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var64 = var62.equals((java.lang.Object)(-1));
    var62.validateObject();
    org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var69 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var70 = var67.isBefore(var69);
    int var71 = var67.getYYYY();
    org.jfree.chart.entity.CategoryItemEntity var73 = new org.jfree.chart.entity.CategoryItemEntity(var59, "hi!", "", (org.jfree.data.category.CategoryDataset)var62, (java.lang.Comparable)var67, (java.lang.Comparable)(-3.0d));
    org.jfree.chart.entity.ChartEntity var76 = new org.jfree.chart.entity.ChartEntity(var59, "RectangleEdge.BOTTOM", "hi!");
    var41.setShape(var59);
    java.awt.Shape var78 = var41.getShape();
    org.jfree.data.category.DefaultCategoryDataset var81 = new org.jfree.data.category.DefaultCategoryDataset();
    int var83 = var81.getColumnIndex((java.lang.Comparable)0L);
    org.jfree.data.general.DatasetGroup var84 = var81.getGroup();
    org.jfree.data.general.PieDataset var86 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var81, 1900);
    org.jfree.data.KeyedObjects2D var87 = new org.jfree.data.KeyedObjects2D();
    org.jfree.chart.axis.DateTickUnit var90 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    org.jfree.chart.axis.DateTickUnit var93 = new org.jfree.chart.axis.DateTickUnit(0, 14);
    var87.removeObject((java.lang.Comparable)var90, (java.lang.Comparable)var93);
    org.jfree.chart.entity.CategoryItemEntity var96 = new org.jfree.chart.entity.CategoryItemEntity(var78, "", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", (org.jfree.data.category.CategoryDataset)var81, (java.lang.Comparable)var93, (java.lang.Comparable)10);
    org.jfree.data.general.DatasetChangeEvent var97 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object)var21, (org.jfree.data.general.Dataset)var81);
    var13.datasetChanged(var97);
    var0.datasetChanged(var97);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);

  }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test14"); }


    org.jfree.data.time.SimpleTimePeriod var2 = new org.jfree.data.time.SimpleTimePeriod(900000L, 172800000L);
    java.util.Date var3 = var2.getStart();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test15"); }
// 
// 
//     org.jfree.chart.renderer.category.LayeredBarRenderer var0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
//     var0.setSeriesBarWidth(15, 3.0d);
//     org.jfree.chart.block.ColumnArrangement var4 = new org.jfree.chart.block.ColumnArrangement();
//     org.jfree.chart.block.BorderArrangement var5 = new org.jfree.chart.block.BorderArrangement();
//     var5.clear();
//     org.jfree.chart.title.LegendTitle var7 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource)var0, (org.jfree.chart.block.Arrangement)var4, (org.jfree.chart.block.Arrangement)var5);
//     double var9 = var0.getSeriesBarWidth(0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == Double.NaN);
// 
//   }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test16"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var5 = var3.lookupSeriesStroke(1);
    boolean var6 = var3.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
    org.jfree.chart.labels.CategoryItemLabelGenerator var12 = null;
    var10.setSeriesItemLabelGenerator(2, var12);
    java.awt.Font var14 = var10.getBaseItemLabelFont();
    org.jfree.chart.title.TextTitle var15 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var14);
    var3.setBaseItemLabelFont(var14);
    var0.setLabelFont(var14);
    var0.setPieIndex(1901);
    boolean var20 = var0.getIgnoreNullValues();
    org.jfree.chart.plot.CategoryPlot var21 = new org.jfree.chart.plot.CategoryPlot();
    int var22 = var21.getWeight();
    var21.setAnchorValue(0.0d);
    org.jfree.chart.axis.ValueAxis var25 = null;
    var21.setRangeAxis(var25);
    java.lang.Object var27 = null;
    boolean var28 = var21.equals(var27);
    java.awt.Shape var33 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var38 = var36.lookupSeriesStroke(1);
    java.awt.Paint var40 = var36.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var41 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var42 = var41.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var47 = var45.lookupSeriesStroke(1);
    java.awt.Paint var49 = var45.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var50 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var33, var40, var42, var49);
    java.awt.Shape var51 = var50.getLine();
    var50.setSeriesIndex(2);
    java.awt.Paint var54 = var50.getFillPaint();
    var21.setDomainGridlinePaint(var54);
    var0.setOutlinePaint(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test17"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var5 = var2.isBefore(var4);
    int var6 = var2.getMonth();
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addYears(96, (org.jfree.data.time.SerialDate)var2);
    org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var12 = var9.isBefore(var11);
    org.jfree.data.time.SpreadsheetDate var15 = new org.jfree.data.time.SpreadsheetDate(15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(10);
    boolean var18 = var15.isBefore(var17);
    int var19 = var15.getYYYY();
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.addYears(15, (org.jfree.data.time.SerialDate)var15);
    boolean var22 = var2.isInRange((org.jfree.data.time.SerialDate)var9, var20, 255);
    int var23 = var9.toSerial();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 15);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test18"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    var0.setBaseSeriesVisible(false);
    var0.setBaseCreateEntities(false, false);
    java.awt.Shape var8 = var0.getItemShape(96, 0);
    java.awt.Shape var9 = org.jfree.chart.util.ShapeUtilities.clone(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test19"); }


    org.jfree.chart.plot.PiePlot3D var0 = new org.jfree.chart.plot.PiePlot3D();
    double var1 = var0.getShadowXOffset();
    var0.setDepthFactor(1.0d);
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.general.PieDataset var6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset)var4, 100);
    var0.setDataset(var6);
    double var8 = var0.getShadowYOffset();
    double var9 = var0.getMaximumLabelWidth();
    java.awt.Stroke var10 = var0.getBaseSectionOutlineStroke();
    java.awt.Paint var11 = var0.getBackgroundPaint();
    var0.setCircular(true, false);
    java.awt.Paint var15 = var0.getLabelLinkPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test20() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test20"); }


    org.jfree.chart.plot.XYPlot var0 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var2 = null;
    var1.axisChanged(var2);
    java.awt.Paint var4 = var1.getRangeZeroBaselinePaint();
    var0.setBackgroundPaint(var4);
    org.jfree.chart.renderer.xy.XYItemRenderer var6 = var0.getRenderer();
    java.awt.Stroke var7 = var0.getDomainZeroBaselineStroke();
    org.jfree.chart.event.PlotChangeListener var8 = null;
    var0.removeChangeListener(var8);
    java.awt.Paint var10 = var0.getRangeCrosshairPaint();
    boolean var11 = var0.isRangeCrosshairLockedOnData();
    java.lang.Object var12 = var0.clone();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test21"); }


    org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var2 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var3 = var2.getPadding();
    var1.setPadding(var3);
    boolean var5 = var0.equals((java.lang.Object)var1);
    org.jfree.chart.util.HorizontalAlignment var6 = var1.getTextAlignment();
    org.jfree.chart.plot.CategoryPlot var7 = new org.jfree.chart.plot.CategoryPlot();
    int var8 = var7.getWeight();
    org.jfree.chart.axis.CategoryAxis var10 = var7.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis3D var12 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var14 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var16 = var14.equals((java.lang.Object)0.0f);
    java.lang.Object var17 = null;
    boolean var18 = var14.equals(var17);
    java.awt.Font var19 = var12.getTickLabelFont((java.lang.Comparable)var18);
    var12.setMaximumCategoryLabelLines((-459));
    var7.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var12, true);
    org.jfree.chart.plot.XYPlot var25 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var26 = null;
    var25.axisChanged(var26);
    java.awt.Paint var28 = var25.getRangeZeroBaselinePaint();
    org.jfree.chart.util.Layer var30 = null;
    java.util.Collection var31 = var25.getDomainMarkers((-459), var30);
    org.jfree.chart.axis.AxisLocation var33 = null;
    var25.setRangeAxisLocation(5, var33, true);
    org.jfree.data.gantt.TaskSeriesCollection var36 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var37 = null;
    boolean var38 = var36.hasListener(var37);
    int var40 = var36.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var42 = var41.getPadding();
    org.jfree.data.general.SeriesChangeEvent var43 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var42);
    var36.seriesChanged(var43);
    org.jfree.chart.plot.XYPlot var45 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var46 = null;
    var45.axisChanged(var46);
    java.awt.Paint var48 = var45.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var49 = null;
    var45.notifyListeners(var49);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var55 = var53.lookupSeriesStroke(1);
    var45.setDomainCrosshairStroke(var55);
    boolean var57 = var36.hasListener((java.util.EventListener)var45);
    org.jfree.chart.axis.AxisLocation var59 = var45.getDomainAxisLocation(255);
    var25.setDomainAxisLocation(var59, true);
    var7.setDomainAxisLocation(1900, var59);
    java.awt.Paint var63 = var7.getRangeGridlinePaint();
    org.jfree.chart.util.SortOrder var64 = var7.getColumnRenderingOrder();
    boolean var65 = var6.equals((java.lang.Object)var64);
    java.lang.String var66 = var64.toString();
    java.lang.String var67 = var64.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var66 + "' != '" + "SortOrder.ASCENDING"+ "'", var66.equals("SortOrder.ASCENDING"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var67 + "' != '" + "SortOrder.ASCENDING"+ "'", var67.equals("SortOrder.ASCENDING"));

  }

  public void test22() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test22"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
    var0.setPadding(var2);
    double var5 = var2.trimHeight((-1.0d));
    double var6 = var2.getBottom();
    double var7 = var2.getLeft();
    double var8 = var2.getBottom();
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("ThreadContext");
    org.jfree.chart.axis.DateTickMarkPosition var11 = var10.getTickMarkPosition();
    var10.zoomRange((-3.0d), 0.0d);
    org.jfree.data.Range var15 = var10.getDefaultAutoRange();
    org.jfree.chart.axis.CategoryAxis3D var17 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var19 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var21 = var19.equals((java.lang.Object)0.0f);
    java.lang.Object var22 = null;
    boolean var23 = var19.equals(var22);
    java.awt.Font var24 = var17.getTickLabelFont((java.lang.Comparable)var23);
    org.jfree.chart.title.TextTitle var25 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=0,g=0,b=15]", var24);
    java.awt.Color var28 = java.awt.Color.getColor("RectangleEdge.TOP", 0);
    var25.setBackgroundPaint((java.awt.Paint)var28);
    java.awt.geom.Rectangle2D var30 = var25.getBounds();
    var10.setLeftArrow((java.awt.Shape)var30);
    var2.trim(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-3.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);

  }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test23"); }


    org.jfree.chart.axis.CategoryLabelPositions var1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(10.0d);
    org.jfree.chart.ui.ProjectInfo var2 = new org.jfree.chart.ui.ProjectInfo();
    var2.addOptionalLibrary("ChartEntity: tooltip = null");
    java.lang.String var5 = var2.getVersion();
    org.jfree.chart.axis.CategoryLabelPosition var6 = new org.jfree.chart.axis.CategoryLabelPosition();
    org.jfree.chart.util.RectangleAnchor var7 = var6.getCategoryAnchor();
    org.jfree.chart.util.RectangleAnchor var8 = var6.getCategoryAnchor();
    boolean var9 = var2.equals((java.lang.Object)var6);
    org.jfree.chart.axis.CategoryLabelWidthType var10 = var6.getWidthType();
    org.jfree.chart.axis.CategoryLabelPositions var11 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(var1, var6);
    org.jfree.chart.axis.CategoryLabelWidthType var12 = var6.getWidthType();
    org.jfree.chart.text.TextBlockAnchor var13 = var6.getLabelAnchor();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var16.setBaseCreateEntities(false);
    java.lang.Boolean var20 = null;
    var16.setSeriesVisibleInLegend(0, var20, true);
    boolean var23 = var16.getAutoPopulateSeriesStroke();
    java.awt.Shape var25 = var16.lookupSeriesShape((-2));
    var16.setSeriesItemLabelsVisible(100, (java.lang.Boolean)false, false);
    java.lang.Boolean var31 = var16.getSeriesCreateEntities((-459));
    boolean var32 = var13.equals((java.lang.Object)var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test24"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    java.lang.Comparable[] var2 = null;
    java.lang.Number[] var3 = null;
    java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
    java.lang.Number[][] var5 = null;
    org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var2, var4, var5);
    java.util.List var7 = var6.getColumnKeys();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Comparable var9 = var6.getSeriesKey(1901);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test25"); }
// 
// 
//     org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset var0 = new org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset();
//     org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var6 = var3.isBefore(var5);
//     org.jfree.data.time.SpreadsheetDate var8 = new org.jfree.data.time.SpreadsheetDate(15);
//     int var9 = var8.getMonth();
//     boolean var10 = var3.isOnOrBefore((org.jfree.data.time.SerialDate)var8);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var14 = var12.getPreviousDayOfWeek(1);
//     var14.setDescription("May");
//     boolean var17 = var8.isOn(var14);
//     java.lang.Number var18 = var0.getValue((java.lang.Comparable)2, (java.lang.Comparable)var17);
//     org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var28 = null;
//     var27.axisChanged(var28);
//     org.jfree.chart.renderer.xy.XYItemRenderer var31 = var27.getRenderer((-2));
//     org.jfree.chart.axis.ValueAxis var32 = var27.getDomainAxis();
//     org.jfree.chart.axis.AxisLocation var34 = null;
//     var27.setDomainAxisLocation(2, var34, false);
//     java.awt.Graphics2D var37 = null;
//     java.awt.geom.Rectangle2D var38 = null;
//     org.jfree.data.gantt.TaskSeries var40 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
//     var40.setKey((java.lang.Comparable)10);
//     org.jfree.chart.axis.SegmentedTimeline var43 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//     org.jfree.chart.axis.SegmentedTimeline var44 = var43.getBaseTimeline();
//     java.util.Date var46 = var44.getDate(10L);
//     var40.setKey((java.lang.Comparable)10L);
//     java.util.List var48 = var40.getTasks();
//     var27.drawRangeTickBands(var37, var38, var48);
//     org.jfree.data.statistics.BoxAndWhiskerItem var50 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number)1, (java.lang.Number)1.0f, (java.lang.Number)2, (java.lang.Number)0.0d, (java.lang.Number)1, (java.lang.Number)1420099199999L, (java.lang.Number)0.0d, (java.lang.Number)(short)0, var48);
//     java.lang.Number var51 = var50.getMaxOutlier();
//     java.lang.Number var52 = var50.getQ1();
//     java.lang.Number var53 = var50.getQ1();
//     java.lang.Number var54 = var50.getMaxOutlier();
//     org.jfree.chart.title.TextTitle var57 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var58 = var57.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var59 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var58);
//     org.jfree.data.gantt.TaskSeriesCollection var60 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var61 = var58.equals((java.lang.Object)var60);
//     org.jfree.data.general.DatasetGroup var62 = var60.getGroup();
//     org.jfree.data.time.Month var63 = new org.jfree.data.time.Month();
//     int var64 = var60.indexOf((java.lang.Comparable)var63);
//     long var65 = var63.getSerialIndex();
//     org.jfree.data.time.Year var66 = var63.getYear();
//     org.jfree.data.time.Month var67 = new org.jfree.data.time.Month(10, var66);
//     long var68 = var66.getFirstMillisecond();
//     java.util.Date var69 = var66.getEnd();
//     var0.add(var50, (java.lang.Comparable)"ChartEntity: tooltip = null", (java.lang.Comparable)var66);
//     java.lang.Number var73 = var0.getQ3Value((java.lang.Comparable)10L, (java.lang.Comparable)"Default Group");
//     java.util.List var74 = var0.getColumnKeys();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.statistics.BoxAndWhiskerItem var77 = var0.getItem(2014, (-16777201));
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var51 + "' != '" + (short)0+ "'", var51.equals((short)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var52 + "' != '" + 2+ "'", var52.equals(2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var53 + "' != '" + 2+ "'", var53.equals(2));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var54 + "' != '" + (short)0+ "'", var54.equals((short)0));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var65 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var66);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var68 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test26"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var2 = var1.getDomainZeroBaselineStroke();
    var1.mapDatasetToDomainAxis(0, 2);
    org.jfree.chart.axis.AxisSpace var6 = var1.getFixedDomainAxisSpace();
    org.jfree.chart.axis.ValueAxis var8 = var1.getDomainAxis((-1));
    org.jfree.chart.axis.DateAxis var10 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.util.RectangleInsets var11 = var10.getTickLabelInsets();
    org.jfree.chart.axis.SegmentedTimeline var12 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var13 = var12.getBaseTimeline();
    long var14 = var12.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var15 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var16 = var15.getBaseTimeline();
    java.util.Date var18 = var16.getDate(10L);
    boolean var19 = var12.containsDomainValue(var18);
    var10.setTimeline((org.jfree.chart.axis.Timeline)var12);
    var1.setRangeAxis((org.jfree.chart.axis.ValueAxis)var10);
    org.jfree.chart.axis.DateAxis var23 = new org.jfree.chart.axis.DateAxis("ThreadContext");
    var23.centerRange(12.0d);
    org.jfree.chart.renderer.xy.XYItemRenderer var26 = null;
    org.jfree.chart.plot.XYPlot var27 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var10, (org.jfree.chart.axis.ValueAxis)var23, var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test27"); }


    org.jfree.chart.plot.XYPlot var1 = new org.jfree.chart.plot.XYPlot();
    int var2 = var1.getSeriesCount();
    java.awt.Graphics2D var3 = null;
    java.awt.geom.Rectangle2D var4 = null;
    var1.drawBackgroundImage(var3, var4);
    org.jfree.chart.plot.PlotRenderingInfo var7 = null;
    java.awt.geom.Point2D var8 = null;
    var1.zoomRangeAxes((-1.0d), var7, var8);
    org.jfree.chart.event.PlotChangeListener var10 = null;
    var1.removeChangeListener(var10);
    org.jfree.chart.JFreeChart var12 = new org.jfree.chart.JFreeChart("({0}, {1}) = {3} - {4}", (org.jfree.chart.plot.Plot)var1);
    var12.setBackgroundImageAlignment(1);
    org.jfree.chart.event.ChartProgressListener var15 = null;
    var12.addProgressListener(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.awt.image.BufferedImage var19 = var12.createBufferedImage((-460), 7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test28"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    int var1 = var0.getPassCount();
    var0.setRenderAsPercentages(false);
    var0.setRenderAsPercentages(true);
    double var6 = var0.getLowerClip();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var7, 10.0d);
    double var12 = var11.getHeight();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range)var16);
    org.jfree.chart.block.RectangleConstraint var18 = var11.toRangeWidth((org.jfree.data.Range)var16);
    org.jfree.chart.block.RectangleConstraint var20 = var18.toFixedHeight(10.0d);
    boolean var21 = var0.equals((java.lang.Object)var18);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getSeriesItemLabelGenerator(21);
    java.awt.Font var24 = var0.getBaseItemLabelFont();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test29"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getWeight();
    org.jfree.chart.axis.CategoryAxis var2 = var0.getDomainAxis();
    org.jfree.chart.event.RendererChangeEvent var3 = null;
    var0.rendererChanged(var3);
    org.jfree.chart.axis.AxisLocation var5 = var0.getDomainAxisLocation();
    org.jfree.chart.plot.CategoryPlot var6 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.gantt.TaskSeriesCollection var8 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var9 = null;
    boolean var10 = var8.hasListener(var9);
    int var12 = var8.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var13 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var14 = var13.getPadding();
    org.jfree.data.general.SeriesChangeEvent var15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var14);
    var8.seriesChanged(var15);
    org.jfree.chart.plot.XYPlot var17 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var18 = null;
    var17.axisChanged(var18);
    java.awt.Paint var20 = var17.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var21 = null;
    var17.notifyListeners(var21);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var27 = var25.lookupSeriesStroke(1);
    var17.setDomainCrosshairStroke(var27);
    boolean var29 = var8.hasListener((java.util.EventListener)var17);
    org.jfree.chart.axis.AxisLocation var31 = var17.getDomainAxisLocation(255);
    var6.setRangeAxisLocation(1, var31);
    org.jfree.data.xy.XYDataset var33 = null;
    org.jfree.chart.axis.ValueAxis var34 = null;
    org.jfree.chart.renderer.PolarItemRenderer var35 = null;
    org.jfree.chart.plot.PolarPlot var36 = new org.jfree.chart.plot.PolarPlot(var33, var34, var35);
    var36.setAngleGridlinesVisible(false);
    var36.removeCornerTextItem("ChartEntity: tooltip = null");
    org.jfree.data.xy.XYDataset var42 = null;
    org.jfree.chart.axis.ValueAxis var43 = null;
    org.jfree.chart.renderer.PolarItemRenderer var44 = null;
    org.jfree.chart.plot.PolarPlot var45 = new org.jfree.chart.plot.PolarPlot(var42, var43, var44);
    org.jfree.chart.plot.PlotRenderingInfo var48 = null;
    java.awt.geom.Point2D var49 = null;
    var45.zoomDomainAxes(100.0d, 0.05d, var48, var49);
    org.jfree.chart.ChartRenderingInfo var53 = null;
    org.jfree.chart.plot.PlotRenderingInfo var54 = new org.jfree.chart.plot.PlotRenderingInfo(var53);
    org.jfree.chart.ChartRenderingInfo var55 = var54.getOwner();
    java.awt.geom.Point2D var56 = null;
    var45.zoomDomainAxes(8.0d, (-3.0d), var54, var56);
    java.awt.geom.Rectangle2D var58 = null;
    var54.setPlotArea(var58);
    int var60 = var54.getSubplotCount();
    java.awt.geom.Rectangle2D var61 = var54.getPlotArea();
    java.awt.geom.Point2D var62 = null;
    var36.zoomDomainAxes(1.0d, var54, var62);
    org.jfree.chart.plot.PlotOrientation var64 = var36.getOrientation();
    org.jfree.chart.util.RectangleEdge var65 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(var31, var64);
    var0.setRangeAxisLocation(var31);
    boolean var67 = var0.getDrawSharedDomainAxis();
    var0.clearRangeMarkers();
    org.jfree.chart.plot.DefaultDrawingSupplier var69 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    java.awt.Paint var70 = var69.getNextPaint();
    var0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier)var69);
    java.awt.Paint var72 = var69.getNextFillPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test30"); }


    org.jfree.chart.plot.CategoryPlot var0 = new org.jfree.chart.plot.CategoryPlot();
    int var1 = var0.getWeight();
    org.jfree.chart.plot.MultiplePiePlot var2 = new org.jfree.chart.plot.MultiplePiePlot();
    org.jfree.chart.util.TableOrder var3 = var2.getDataExtractOrder();
    org.jfree.data.category.CategoryDataset var4 = var2.getDataset();
    java.lang.String var5 = var2.getPlotType();
    java.awt.Paint var6 = var2.getAggregatedItemsPaint();
    var0.setParent((org.jfree.chart.plot.Plot)var2);
    org.jfree.chart.renderer.category.CategoryItemRenderer var8 = var0.getRenderer();
    org.jfree.chart.plot.PlotOrientation var9 = var0.getOrientation();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + "Multiple Pie Plot"+ "'", var5.equals("Multiple Pie Plot"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test31"); }


    org.jfree.chart.renderer.OutlierListCollection var0 = new org.jfree.chart.renderer.OutlierListCollection();
    var0.setLowFarOut(false);
    boolean var3 = var0.isHighFarOut();
    var0.setHighFarOut(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == false);

  }

  public void test32() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test32"); }


    org.jfree.chart.axis.DateAxis var1 = new org.jfree.chart.axis.DateAxis("");
    org.jfree.chart.util.RectangleInsets var2 = var1.getTickLabelInsets();
    boolean var4 = var1.isHiddenValue(172800000L);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var5 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    int var6 = var5.getPassCount();
    org.jfree.data.gantt.TaskSeriesCollection var7 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var9 = var7.getSeries((java.lang.Comparable)"hi!");
    java.lang.Number var10 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var7);
    org.jfree.data.Range var11 = var5.findRangeBounds((org.jfree.data.category.CategoryDataset)var7);
    double var13 = var11.constrain(8.0d);
    var1.setRangeWithMargins(var11);
    boolean var15 = var1.isAutoRange();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0.0d+ "'", var10.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test33"); }


    org.jfree.chart.renderer.category.LineRenderer3D var0 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var1 = var0.getYOffset();
    org.jfree.chart.urls.StandardCategoryURLGenerator var2 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    var0.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var2);
    java.awt.Graphics2D var4 = null;
    org.jfree.chart.plot.CategoryPlot var5 = null;
    org.jfree.chart.axis.DateAxis var6 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var7 = null;
    var6.setTickUnit(var7);
    java.util.Date var9 = var6.getMaximumDate();
    java.awt.geom.Rectangle2D var10 = null;
    var0.drawRangeGridline(var4, var5, (org.jfree.chart.axis.ValueAxis)var6, var10, 6.0d);
    java.text.DateFormat var13 = null;
    var6.setDateFormatOverride(var13);
    org.jfree.chart.plot.PiePlot3D var15 = new org.jfree.chart.plot.PiePlot3D();
    double var16 = var15.getShadowXOffset();
    var15.setDepthFactor(1.0d);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    var15.setLabelLinkStroke(var23);
    java.awt.Font var25 = var15.getLabelFont();
    org.jfree.chart.plot.PiePlot3D var26 = new org.jfree.chart.plot.PiePlot3D();
    double var27 = var26.getShadowXOffset();
    var26.setDepthFactor(1.0d);
    boolean var30 = var26.getIgnoreZeroValues();
    org.jfree.chart.labels.PieSectionLabelGenerator var31 = var26.getLegendLabelGenerator();
    var15.setLegendLabelGenerator(var31);
    boolean var33 = var6.equals((java.lang.Object)var15);
    org.jfree.chart.axis.DateTickUnit var34 = null;
    var6.setTickUnit(var34);
    org.jfree.chart.axis.SegmentedTimeline var36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var37 = var36.getBaseTimeline();
    boolean var40 = var37.containsDomainRange((-1L), 10L);
    long var41 = var37.getSegmentsExcludedSize();
    int var42 = var37.getSegmentsIncluded();
    org.jfree.chart.axis.SegmentedTimeline var43 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var44 = var43.getBaseTimeline();
    boolean var47 = var44.containsDomainRange((-1L), 10L);
    long var48 = var44.getSegmentsExcludedSize();
    int var49 = var44.getSegmentsIncluded();
    org.jfree.chart.axis.SegmentedTimeline var50 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var51 = var50.getBaseTimeline();
    java.util.Date var53 = var51.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var54 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var55 = var54.getBaseTimeline();
    java.util.Date var57 = var55.getDate(10L);
    var51.addException(var57);
    boolean var59 = var44.containsDomainValue(var57);
    boolean var60 = var37.containsDomainValue(var57);
    org.jfree.data.time.Year var61 = new org.jfree.data.time.Year(var57);
    var6.setMaximumDate(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 4.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test34"); }


    org.jfree.chart.plot.IntervalMarker var2 = new org.jfree.chart.plot.IntervalMarker(1.0d, 8.0d);
    var2.setStartValue(8.0d);
    java.lang.Object var5 = var2.clone();
    org.jfree.chart.util.RectangleAnchor var6 = var2.getLabelAnchor();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test35"); }


    org.jfree.data.xy.XYDataset var0 = null;
    org.jfree.chart.axis.NumberAxis3D var2 = new org.jfree.chart.axis.NumberAxis3D("December 2014");
    java.awt.Shape var3 = var2.getUpArrow();
    org.jfree.chart.axis.NumberAxis3D var5 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var5.setLabelAngle(0.2d);
    var5.setLabel("ChartEntity: tooltip = null");
    java.awt.Shape var14 = null;
    org.jfree.chart.renderer.category.LineAndShapeRenderer var17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var19 = var17.lookupSeriesStroke(1);
    java.awt.Paint var21 = var17.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var22 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var23 = var22.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.category.LineAndShapeRenderer var26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var28 = var26.lookupSeriesStroke(1);
    java.awt.Paint var30 = var26.lookupSeriesOutlinePaint(10);
    org.jfree.chart.LegendItem var31 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var14, var21, var23, var30);
    java.awt.Shape var32 = var31.getLine();
    org.jfree.chart.entity.ChartEntity var35 = new org.jfree.chart.entity.ChartEntity(var32, "hi!", "hi!");
    org.jfree.chart.entity.AxisLabelEntity var38 = new org.jfree.chart.entity.AxisLabelEntity((org.jfree.chart.axis.Axis)var5, var32, "({0}, {1}) = {3} - {4}", "hi!");
    var5.configure();
    var5.setAutoRangeIncludesZero(true);
    org.jfree.chart.axis.MarkerAxisBand var42 = var5.getMarkerBand();
    org.jfree.chart.axis.TickUnitSource var43 = var5.getStandardTickUnits();
    java.awt.Shape var44 = var5.getLeftArrow();
    org.jfree.chart.renderer.xy.XYItemRenderer var45 = null;
    org.jfree.chart.plot.XYPlot var46 = new org.jfree.chart.plot.XYPlot(var0, (org.jfree.chart.axis.ValueAxis)var2, (org.jfree.chart.axis.ValueAxis)var5, var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test36"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var1.setKey((java.lang.Comparable)10);
    org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var5 = var4.getBaseTimeline();
    java.util.Date var7 = var5.getDate(10L);
    var1.setKey((java.lang.Comparable)10L);
    boolean var9 = var1.getNotify();
    org.jfree.data.gantt.Task var10 = null;
    var1.remove(var10);
    java.beans.PropertyChangeListener var12 = null;
    var1.removePropertyChangeListener(var12);
    java.lang.String var14 = var1.getDescription();
    java.lang.Object var15 = var1.clone();
    org.jfree.data.gantt.Task var17 = var1.get("October");
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var17);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test37"); }


    org.jfree.chart.renderer.category.StackedAreaRenderer var0 = new org.jfree.chart.renderer.category.StackedAreaRenderer();
    boolean var1 = var0.getRenderAsPercentages();
    org.jfree.chart.plot.CategoryPlot var2 = new org.jfree.chart.plot.CategoryPlot();
    org.jfree.data.gantt.TaskSeriesCollection var4 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var5 = null;
    boolean var6 = var4.hasListener(var5);
    int var8 = var4.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var9 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var10 = var9.getPadding();
    org.jfree.data.general.SeriesChangeEvent var11 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var10);
    var4.seriesChanged(var11);
    org.jfree.chart.plot.XYPlot var13 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var14 = null;
    var13.axisChanged(var14);
    java.awt.Paint var16 = var13.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var17 = null;
    var13.notifyListeners(var17);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var23 = var21.lookupSeriesStroke(1);
    var13.setDomainCrosshairStroke(var23);
    boolean var25 = var4.hasListener((java.util.EventListener)var13);
    org.jfree.chart.axis.AxisLocation var27 = var13.getDomainAxisLocation(255);
    var2.setRangeAxisLocation(1, var27);
    var0.setPlot(var2);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Paint var35 = var32.getItemPaint(1, 12);
    org.jfree.chart.renderer.category.LineRenderer3D var36 = new org.jfree.chart.renderer.category.LineRenderer3D();
    double var37 = var36.getYOffset();
    org.jfree.chart.urls.StandardCategoryURLGenerator var38 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
    var36.setBaseURLGenerator((org.jfree.chart.urls.CategoryURLGenerator)var38);
    java.awt.Graphics2D var40 = null;
    org.jfree.chart.plot.CategoryPlot var41 = null;
    org.jfree.chart.axis.DateAxis var42 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var43 = null;
    var42.setTickUnit(var43);
    java.util.Date var45 = var42.getMaximumDate();
    java.awt.geom.Rectangle2D var46 = null;
    var36.drawRangeGridline(var40, var41, (org.jfree.chart.axis.ValueAxis)var42, var46, 6.0d);
    var36.setBaseCreateEntities(true, false);
    java.awt.Paint var52 = var36.getBaseItemLabelPaint();
    boolean var53 = org.jfree.chart.util.PaintUtilities.equal(var35, var52);
    org.jfree.chart.block.BlockBorder var54 = new org.jfree.chart.block.BlockBorder(var35);
    boolean var55 = var0.equals((java.lang.Object)var35);
    var0.setSeriesItemLabelsVisible(15, (java.lang.Boolean)false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 8.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test38"); }


    org.jfree.chart.title.TextTitle var0 = new org.jfree.chart.title.TextTitle();
    var0.setWidth(0.0d);
    org.jfree.chart.util.RectangleEdge var3 = var0.getPosition();
    org.jfree.chart.plot.XYPlot var4 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.LegendItemCollection var5 = var4.getLegendItems();
    boolean var6 = var3.equals((java.lang.Object)var4);
    java.awt.Stroke var7 = var4.getDomainZeroBaselineStroke();
    org.jfree.chart.renderer.xy.XYItemRenderer var9 = var4.getRenderer((-459));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test39"); }


    org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer(false, true);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var7 = var5.lookupSeriesStroke(1);
    java.awt.Paint var9 = var5.lookupSeriesOutlinePaint(10);
    org.jfree.chart.plot.XYPlot var11 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var12 = null;
    var11.axisChanged(var12);
    java.awt.Paint var14 = var11.getRangeZeroBaselinePaint();
    var5.setSeriesItemLabelPaint(100, var14, false);
    java.awt.Paint var17 = var5.getBaseItemLabelPaint();
    var2.setErrorIndicatorPaint(var17);
    org.jfree.chart.labels.CategoryToolTipGenerator var19 = var2.getBaseToolTipGenerator();
    boolean var20 = var2.getBaseItemLabelsVisible();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSeriesItemLabelsVisible((-32384), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test40"); }
// 
// 
//     org.jfree.chart.axis.AxisSpace var0 = new org.jfree.chart.axis.AxisSpace();
//     org.jfree.chart.title.TextTitle var1 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var2 = var1.getPadding();
//     org.jfree.chart.event.TitleChangeListener var3 = null;
//     var1.addChangeListener(var3);
//     boolean var5 = var0.equals((java.lang.Object)var3);
//     var0.setRight(0.05d);
//     org.jfree.chart.plot.XYPlot var8 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.plot.XYPlot var9 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var10 = null;
//     var9.axisChanged(var10);
//     java.awt.Paint var12 = var9.getRangeZeroBaselinePaint();
//     var8.setBackgroundPaint(var12);
//     org.jfree.chart.renderer.xy.XYItemRenderer var14 = var8.getRenderer();
//     java.awt.Stroke var15 = var8.getDomainZeroBaselineStroke();
//     boolean var16 = var0.equals((java.lang.Object)var8);
//     var0.setTop(0.0d);
//     org.jfree.chart.axis.AxisState var20 = new org.jfree.chart.axis.AxisState();
//     var20.cursorDown(12.0d);
//     org.jfree.chart.axis.DateAxis var24 = new org.jfree.chart.axis.DateAxis();
//     var24.setUpperMargin(1.0d);
//     java.lang.Object var27 = var24.clone();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var31.setBaseCreateEntities(false);
//     java.lang.Boolean var35 = null;
//     var31.setSeriesVisibleInLegend(0, var35, true);
//     boolean var38 = var31.getAutoPopulateSeriesStroke();
//     java.awt.Shape var40 = var31.lookupSeriesShape((-2));
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var45 = var43.lookupSeriesStroke(1);
//     java.awt.Paint var47 = var43.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.title.LegendGraphic var48 = new org.jfree.chart.title.LegendGraphic(var40, var47);
//     java.awt.Shape var53 = null;
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var58 = var56.lookupSeriesStroke(1);
//     java.awt.Paint var60 = var56.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var61 = new org.jfree.chart.plot.XYPlot();
//     java.awt.Stroke var62 = var61.getDomainZeroBaselineStroke();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var67 = var65.lookupSeriesStroke(1);
//     java.awt.Paint var69 = var65.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.LegendItem var70 = new org.jfree.chart.LegendItem("", "({0}, {1}) = {3} - {4}", "hi!", "hi!", var53, var60, var62, var69);
//     java.awt.Shape var71 = var70.getLine();
//     org.jfree.chart.entity.ChartEntity var74 = new org.jfree.chart.entity.ChartEntity(var71, "hi!", "hi!");
//     var48.setLine(var71);
//     java.awt.Paint var76 = var48.getFillPaint();
//     org.jfree.data.time.SpreadsheetDate var78 = new org.jfree.data.time.SpreadsheetDate(15);
//     org.jfree.data.time.SerialDate var80 = org.jfree.data.time.SerialDate.createInstance(10);
//     boolean var81 = var78.isBefore(var80);
//     boolean var82 = var48.equals((java.lang.Object)var81);
//     java.awt.Shape var83 = var48.getLine();
//     java.awt.geom.Rectangle2D var84 = var48.getBounds();
//     org.jfree.chart.title.TextTitle var85 = new org.jfree.chart.title.TextTitle();
//     var85.setWidth(0.0d);
//     org.jfree.chart.util.RectangleEdge var88 = var85.getPosition();
//     org.jfree.chart.util.RectangleEdge var89 = org.jfree.chart.util.RectangleEdge.opposite(var88);
//     java.lang.String var90 = var89.toString();
//     double var91 = var24.java2DToValue((-3.0d), var84, var89);
//     var20.moveCursor(0.2d, var89);
//     var0.add(0.05d, var89);
//     
//     // Checks the contract:  equals-hashcode on var9 and var61
//     assertTrue("Contract failed: equals-hashcode on var9 and var61", var9.equals(var61) ? var9.hashCode() == var61.hashCode() : true);
//     
//     // Checks the contract:  equals-hashcode on var61 and var9
//     assertTrue("Contract failed: equals-hashcode on var61 and var9", var61.equals(var9) ? var61.hashCode() == var9.hashCode() : true);
// 
//   }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test41"); }


    java.awt.Paint[] var0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var1 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Paint[] var2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
    java.awt.Stroke[] var3 = null;
    org.jfree.chart.plot.CategoryPlot var4 = new org.jfree.chart.plot.CategoryPlot();
    int var5 = var4.getWeight();
    org.jfree.chart.axis.CategoryAxis var7 = var4.getDomainAxis(0);
    org.jfree.chart.axis.CategoryAxis3D var9 = new org.jfree.chart.axis.CategoryAxis3D();
    org.jfree.chart.axis.NumberTickUnit var11 = new org.jfree.chart.axis.NumberTickUnit(2.0d);
    boolean var13 = var11.equals((java.lang.Object)0.0f);
    java.lang.Object var14 = null;
    boolean var15 = var11.equals(var14);
    java.awt.Font var16 = var9.getTickLabelFont((java.lang.Comparable)var15);
    var9.setMaximumCategoryLabelLines((-459));
    var4.setDomainAxis(1900, (org.jfree.chart.axis.CategoryAxis)var9, true);
    boolean var21 = var4.isRangeCrosshairLockedOnData();
    org.jfree.data.gantt.TaskSeriesCollection var22 = new org.jfree.data.gantt.TaskSeriesCollection();
    java.util.EventListener var23 = null;
    boolean var24 = var22.hasListener(var23);
    int var26 = var22.getRowIndex((java.lang.Comparable)0L);
    org.jfree.chart.title.TextTitle var27 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var28 = var27.getPadding();
    org.jfree.data.general.SeriesChangeEvent var29 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var28);
    var22.seriesChanged(var29);
    org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var32 = null;
    var31.axisChanged(var32);
    java.awt.Paint var34 = var31.getRangeZeroBaselinePaint();
    org.jfree.chart.event.PlotChangeEvent var35 = null;
    var31.notifyListeners(var35);
    org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var41 = var39.lookupSeriesStroke(1);
    var31.setDomainCrosshairStroke(var41);
    boolean var43 = var22.hasListener((java.util.EventListener)var31);
    org.jfree.chart.axis.AxisLocation var45 = var31.getDomainAxisLocation(255);
    var4.setDomainAxisLocation(var45, true);
    java.awt.Stroke var48 = var4.getDomainGridlineStroke();
    java.awt.Stroke[] var49 = new java.awt.Stroke[] { var48};
    java.awt.Shape[] var50 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
    org.jfree.chart.plot.DefaultDrawingSupplier var51 = new org.jfree.chart.plot.DefaultDrawingSupplier(var0, var1, var2, var3, var49, var50);
    java.awt.Paint var52 = var51.getNextPaint();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test42"); }


    org.jfree.chart.axis.DateAxis var0 = new org.jfree.chart.axis.DateAxis();
    org.jfree.chart.axis.DateTickUnit var1 = null;
    var0.setTickUnit(var1);
    org.jfree.chart.axis.NumberAxis3D var4 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var4.setLabelAngle(0.2d);
    var4.setLowerBound(12.0d);
    var4.setLowerBound(0.0d);
    var4.setTickMarksVisible(true);
    org.jfree.data.Range var13 = var4.getRange();
    var0.setRange(var13);
    var0.setUpperMargin(1.0d);
    boolean var17 = var0.isInverted();
    java.awt.Shape var18 = var0.getUpArrow();
    java.awt.Shape var19 = var0.getUpArrow();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test43"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    java.awt.Stroke var4 = var2.lookupSeriesStroke(1);
    boolean var5 = var2.getAutoPopulateSeriesFillPaint();
    org.jfree.chart.plot.XYPlot var7 = new org.jfree.chart.plot.XYPlot();
    java.awt.Stroke var8 = var7.getDomainZeroBaselineStroke();
    var2.setSeriesOutlineStroke(1, var8, false);
    java.lang.Boolean var12 = var2.getSeriesShapesFilled(100);
    var2.setSeriesItemLabelsVisible(1, false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test44"); }


    org.jfree.chart.renderer.category.LineAndShapeRenderer var2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    var2.setBaseCreateEntities(false);
    java.lang.Boolean var6 = null;
    var2.setSeriesVisibleInLegend(0, var6, true);
    boolean var9 = var2.getAutoPopulateSeriesStroke();
    java.awt.Shape var11 = var2.lookupSeriesShape((-2));
    java.awt.Stroke var14 = var2.getItemOutlineStroke(100, 2);
    var2.setSeriesVisible(10, (java.lang.Boolean)false);
    var2.setBaseCreateEntities(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test45() {}
//   public void test45() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test45"); }
// 
// 
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     boolean var1 = var0.getBaseSeriesVisibleInLegend();
//     org.jfree.chart.labels.ItemLabelPosition var2 = var0.getNegativeItemLabelPositionFallback();
//     org.jfree.chart.renderer.category.GroupedStackedBarRenderer var3 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
//     int var4 = var3.getPassCount();
//     var3.setRenderAsPercentages(false);
//     org.jfree.data.KeyToGroupMap var7 = new org.jfree.data.KeyToGroupMap();
//     int var9 = var7.getGroupIndex((java.lang.Comparable)(short)100);
//     java.lang.Object var10 = var7.clone();
//     org.jfree.chart.title.TextTitle var12 = new org.jfree.chart.title.TextTitle();
//     org.jfree.chart.util.RectangleInsets var13 = var12.getPadding();
//     org.jfree.data.general.SeriesChangeEvent var14 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var13);
//     org.jfree.data.gantt.TaskSeriesCollection var15 = new org.jfree.data.gantt.TaskSeriesCollection();
//     boolean var16 = var13.equals((java.lang.Object)var15);
//     org.jfree.data.general.DatasetGroup var17 = var15.getGroup();
//     org.jfree.data.time.Month var18 = new org.jfree.data.time.Month();
//     int var19 = var15.indexOf((java.lang.Comparable)var18);
//     long var20 = var18.getSerialIndex();
//     org.jfree.data.time.Year var21 = var18.getYear();
//     org.jfree.data.time.Month var22 = new org.jfree.data.time.Month(10, var21);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var27 = var25.lookupSeriesStroke(1);
//     java.awt.Paint var29 = var25.lookupSeriesOutlinePaint(10);
//     org.jfree.chart.plot.XYPlot var31 = new org.jfree.chart.plot.XYPlot();
//     org.jfree.chart.event.AxisChangeEvent var32 = null;
//     var31.axisChanged(var32);
//     java.awt.Paint var34 = var31.getRangeZeroBaselinePaint();
//     var25.setSeriesItemLabelPaint(100, var34, false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var41 = null;
//     var39.setSeriesItemLabelGenerator(2, var41);
//     java.awt.Font var43 = var39.getBaseItemLabelFont();
//     var25.setBaseItemLabelFont(var43);
//     boolean var45 = var21.equals((java.lang.Object)var25);
//     long var46 = var21.getLastMillisecond();
//     int var47 = var7.getKeyCount((java.lang.Comparable)var46);
//     var3.setSeriesToGroupMap(var7);
//     java.util.List var49 = var7.getGroups();
//     int var51 = var7.getKeyCount((java.lang.Comparable)(-460));
//     var0.setSeriesToGroupMap(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 24180L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var45 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var46 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var51 == 0);
// 
//   }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test46"); }


    org.jfree.chart.plot.RingPlot var0 = new org.jfree.chart.plot.RingPlot();
    java.awt.Paint var1 = var0.getShadowPaint();
    boolean var2 = var0.isCircular();
    double var3 = var0.getInnerSeparatorExtension();
    double var4 = var0.getOuterSeparatorExtension();
    double var5 = var0.getInnerSeparatorExtension();
    org.jfree.chart.plot.XYPlot var6 = new org.jfree.chart.plot.XYPlot();
    org.jfree.chart.event.AxisChangeEvent var7 = null;
    var6.axisChanged(var7);
    java.awt.Paint var9 = var6.getRangeZeroBaselinePaint();
    java.lang.Object var10 = var6.clone();
    org.jfree.chart.axis.NumberAxis3D var12 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var12.setLabelAngle(0.2d);
    var12.setLowerBound(12.0d);
    var12.setLowerBound(0.0d);
    var12.setTickMarksVisible(true);
    org.jfree.data.Range var21 = var12.getRange();
    int var22 = var6.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis)var12);
    org.jfree.data.Range var23 = null;
    org.jfree.data.Range var25 = org.jfree.data.Range.expandToInclude(var23, 0.0d);
    org.jfree.chart.block.RectangleConstraint var27 = new org.jfree.chart.block.RectangleConstraint(var23, 10.0d);
    double var28 = var27.getHeight();
    org.jfree.data.time.DateRange var32 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var33 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range)var32);
    org.jfree.chart.block.RectangleConstraint var34 = var27.toRangeWidth((org.jfree.data.Range)var32);
    var12.setRange((org.jfree.data.Range)var32, true, true);
    boolean var38 = var0.equals((java.lang.Object)var32);
    java.awt.Paint var39 = var0.getBackgroundPaint();
    double var40 = var0.getOuterSeparatorExtension();
    java.awt.Paint var41 = var0.getBaseSectionPaint();
    boolean var42 = var0.getIgnoreZeroValues();
    org.jfree.chart.urls.PieURLGenerator var43 = var0.getLegendLabelURLGenerator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0.2d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var43);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test47"); }


    org.jfree.data.gantt.TaskSeries var1 = new org.jfree.data.gantt.TaskSeries("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
    var1.setKey((java.lang.Comparable)10);
    org.jfree.chart.axis.SegmentedTimeline var4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var5 = var4.getBaseTimeline();
    java.util.Date var7 = var5.getDate(10L);
    var1.setKey((java.lang.Comparable)10L);
    boolean var9 = var1.getNotify();
    org.jfree.data.gantt.Task var10 = null;
    var1.remove(var10);
    org.jfree.chart.axis.SegmentedTimeline var13 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var14 = var13.getBaseTimeline();
    long var15 = var13.getSegmentsExcludedSize();
    org.jfree.chart.axis.SegmentedTimeline var16 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var17 = var16.getBaseTimeline();
    java.util.Date var19 = var17.getDate(10L);
    boolean var20 = var13.containsDomainValue(var19);
    org.jfree.chart.axis.SegmentedTimeline var21 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var22 = var21.getBaseTimeline();
    java.util.Date var24 = var22.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var25 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var26 = var25.getBaseTimeline();
    java.util.Date var28 = var26.getDate(10L);
    var22.addException(var28);
    org.jfree.chart.axis.SegmentedTimeline var30 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var31 = var30.getBaseTimeline();
    boolean var34 = var31.containsDomainRange((-1L), 10L);
    long var35 = var31.getSegmentsExcludedSize();
    int var36 = var31.getSegmentsIncluded();
    org.jfree.chart.axis.SegmentedTimeline var37 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var38 = var37.getBaseTimeline();
    java.util.Date var40 = var38.getDate(10L);
    org.jfree.chart.axis.SegmentedTimeline var41 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
    org.jfree.chart.axis.SegmentedTimeline var42 = var41.getBaseTimeline();
    java.util.Date var44 = var42.getDate(10L);
    var38.addException(var44);
    boolean var46 = var31.containsDomainValue(var44);
    org.jfree.data.time.DateRange var47 = new org.jfree.data.time.DateRange(var28, var44);
    org.jfree.data.gantt.Task var48 = new org.jfree.data.gantt.Task("({0}, {1}) = {3} - {4}", var19, var44);
    var1.remove(var48);
    org.jfree.chart.title.TextTitle var50 = new org.jfree.chart.title.TextTitle();
    org.jfree.chart.util.RectangleInsets var51 = var50.getPadding();
    org.jfree.data.general.SeriesChangeEvent var52 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var51);
    org.jfree.data.gantt.TaskSeriesCollection var53 = new org.jfree.data.gantt.TaskSeriesCollection();
    boolean var54 = var51.equals((java.lang.Object)var53);
    org.jfree.data.general.DatasetGroup var55 = var53.getGroup();
    org.jfree.data.time.Month var56 = new org.jfree.data.time.Month();
    int var57 = var53.indexOf((java.lang.Comparable)var56);
    var48.setDuration((org.jfree.data.time.TimePeriod)var56);
    java.lang.String var59 = var48.getDescription();
    org.jfree.chart.axis.NumberAxis3D var61 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.TOP");
    var61.setLabelAngle(0.2d);
    org.jfree.chart.util.RectangleInsets var64 = var61.getTickLabelInsets();
    org.jfree.chart.axis.NumberAxis var65 = null;
    java.awt.Font var70 = null;
    org.jfree.chart.axis.MarkerAxisBand var71 = new org.jfree.chart.axis.MarkerAxisBand(var65, 0.0d, 0.0d, 0.0d, 100.0d, var70);
    org.jfree.chart.renderer.category.LineRenderer3D var72 = new org.jfree.chart.renderer.category.LineRenderer3D();
    boolean var75 = var72.getItemShapeFilled(1, (-2));
    var72.setSeriesShapesFilled(10, (java.lang.Boolean)false);
    boolean var79 = var71.equals((java.lang.Object)false);
    var61.setMarkerBand(var71);
    var61.setNegativeArrowVisible(false);
    var61.setFixedDimension((-1.0d));
    org.jfree.chart.axis.TickUnitSource var85 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
    var61.setStandardTickUnits(var85);
    var61.configure();
    org.jfree.chart.axis.MarkerAxisBand var88 = var61.getMarkerBand();
    boolean var89 = var48.equals((java.lang.Object)var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 61200000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 172800000L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var59 + "' != '" + "({0}, {1}) = {3} - {4}"+ "'", var59.equals("({0}, {1}) = {3} - {4}"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == false);

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest8.test48"); }
// 
// 
//     java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
//     java.lang.Comparable[] var2 = null;
//     java.lang.Number[] var3 = null;
//     java.lang.Number[][] var4 = new java.lang.Number[][] { var3};
//     java.lang.Number[][] var5 = null;
//     org.jfree.data.category.DefaultIntervalCategoryDataset var6 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[])var1, var2, var4, var5);
//     org.jfree.chart.renderer.category.LineRenderer3D var7 = new org.jfree.chart.renderer.category.LineRenderer3D();
//     var7.setAutoPopulateSeriesPaint(false);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     var12.setBaseCreateEntities(false);
//     java.lang.Boolean var16 = null;
//     var12.setSeriesVisibleInLegend(0, var16, true);
//     boolean var19 = var12.getAutoPopulateSeriesStroke();
//     java.awt.Shape var21 = var12.lookupSeriesShape((-2));
//     boolean var23 = var12.isSeriesVisibleInLegend(1);
//     org.jfree.chart.labels.ItemLabelPosition var24 = var12.getBasePositiveItemLabelPosition();
//     var7.setBasePositiveItemLabelPosition(var24);
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
//     java.awt.Stroke var31 = var29.lookupSeriesStroke(1);
//     boolean var32 = var29.getAutoPopulateSeriesFillPaint();
//     org.jfree.chart.renderer.category.LineAndShapeRenderer var36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
//     org.jfree.chart.labels.CategoryItemLabelGenerator var38 = null;
//     var36.setSeriesItemLabelGenerator(2, var38);
//     java.awt.Font var40 = var36.getBaseItemLabelFont();
//     org.jfree.chart.title.TextTitle var41 = new org.jfree.chart.title.TextTitle("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", var40);
//     var29.setBaseItemLabelFont(var40);
//     var7.setSeriesItemLabelFont(0, var40);
//     var7.setSeriesShapesVisible(2014, (java.lang.Boolean)false);
//     var7.setBaseLinesVisible(true);
//     boolean var49 = var6.equals((java.lang.Object)true);
//     java.lang.Number var52 = var6.getStartValue((java.lang.Comparable)0.8f, (java.lang.Comparable)0.95f);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest8.test49"); }


    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    int var1 = var0.getPassCount();
    var0.setRenderAsPercentages(false);
    var0.setRenderAsPercentages(true);
    double var6 = var0.getLowerClip();
    org.jfree.data.Range var7 = null;
    org.jfree.data.Range var9 = org.jfree.data.Range.expandToInclude(var7, 0.0d);
    org.jfree.chart.block.RectangleConstraint var11 = new org.jfree.chart.block.RectangleConstraint(var7, 10.0d);
    double var12 = var11.getHeight();
    org.jfree.data.time.DateRange var16 = new org.jfree.data.time.DateRange(0.0d, 1.0d);
    org.jfree.chart.block.RectangleConstraint var17 = new org.jfree.chart.block.RectangleConstraint(0.0d, (org.jfree.data.Range)var16);
    org.jfree.chart.block.RectangleConstraint var18 = var11.toRangeWidth((org.jfree.data.Range)var16);
    org.jfree.chart.block.RectangleConstraint var20 = var18.toFixedHeight(10.0d);
    boolean var21 = var0.equals((java.lang.Object)var18);
    org.jfree.chart.labels.CategoryItemLabelGenerator var23 = var0.getSeriesItemLabelGenerator(21);
    org.jfree.chart.renderer.category.GroupedStackedBarRenderer var24 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    int var25 = var24.getPassCount();
    org.jfree.data.gantt.TaskSeriesCollection var26 = new org.jfree.data.gantt.TaskSeriesCollection();
    org.jfree.data.gantt.TaskSeries var28 = var26.getSeries((java.lang.Comparable)"hi!");
    java.lang.Number var29 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset)var26);
    org.jfree.data.Range var30 = var24.findRangeBounds((org.jfree.data.category.CategoryDataset)var26);
    org.jfree.data.general.PieDataset var32 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset)var26, 5);
    org.jfree.data.Range var33 = var0.findRangeBounds((org.jfree.data.category.CategoryDataset)var26);
    org.jfree.data.Range var35 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset)var26, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 10.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0.0d+ "'", var29.equals(0.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var35);

  }

}
