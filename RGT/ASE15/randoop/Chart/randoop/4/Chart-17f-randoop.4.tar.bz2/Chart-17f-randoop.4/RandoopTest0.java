
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

//  public void test2() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
//
//
//    java.lang.String var0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertTrue("'" + var0 + "' != '" + "ThreadContext"+ "'", var0.equals("ThreadContext"));
//
//  }
//
  public void test3() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)"hi!");
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test4() {}
//   public void test4() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("", var1);
// 
//   }

  public void test5() {}
//   public void test5() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(0, var1);
// 
//   }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addMonths(0, var1);
// 
//   }

  public void test7() {}
//   public void test7() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("", var1);
// 
//   }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("hi!", var1);
// 
//   }

  public void test10() {}
//   public void test10() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(var0);
// 
//   }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("2014", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test12() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     long var2 = var0.getFirstMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var0.getFirstMillisecond(var3);
// 
//   }

  public void test14() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test15() {}
//   public void test15() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addYears(10, var1);
// 
//   }

  public void test16() {}
//   public void test16() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.Month var1 = new org.jfree.data.time.Month(var0);
// 
//   }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    java.lang.String[] var0 = org.jfree.data.time.SerialDate.getMonths();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test19() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("2014");

  }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-460));

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getLastMillisecond(var2);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test24() {}
//   public void test24() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     long var6 = var4.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var4, 100.0d);
// 
//   }

  public void test25() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day((-460), 100, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    org.jfree.data.time.RegularTimePeriod var5 = null;
    java.lang.Number var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var5, var6, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test27() {}
//   public void test27() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     var2.removeAgedItems(1L, false);
// 
//   }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = var1.getPreviousDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(0, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test30() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var1.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test31() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     var0.peg(var2);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)1388563200000L);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test34() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-460), (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test35() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }


    java.lang.ClassLoader var0 = null;
    org.jfree.chart.util.ObjectUtilities.setClassLoader(var0);

  }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    java.lang.ClassLoader var0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var0);

  }

  public void test37() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Following"+ "'", var1.equals("Following"));

  }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test39() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(0, 1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test40() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test41() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(100, 10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test42() {}
//   public void test42() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var9 = var8.getPeriod();
//     var2.add(var8, false);
// 
//   }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    java.util.Date var0 = null;
    java.util.TimeZone var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var2 = new org.jfree.data.time.Day(var0, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test44() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    java.lang.Class var5 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var2.getValue((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update((-1), (java.lang.Number)100.0d);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test47() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.Comparable var3 = var2.getKey();
    var2.setMaximumItemAge(0L);
    var2.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)1+ "'", var3.equals((byte)1));

  }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.lang.Object var17 = var2.clone();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete(0, (-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test49() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test50() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    java.lang.Class var5 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);

  }

  public void test51() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    var2.removeAgedItems(false);
    org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((org.jfree.data.time.RegularTimePeriod)var6, (java.lang.Number)(byte)100);
      fail("Expected exception of type org.jfree.data.general.SeriesException");
    } catch (org.jfree.data.general.SeriesException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test52() {}
//   public void test52() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     long var22 = var20.getFirstMillisecond();
//     var10.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)1L);
//     java.util.Date var25 = var20.getStart();
//     org.jfree.data.time.Day var26 = new org.jfree.data.time.Day(var25);
//     long var27 = var26.getMiddleMillisecond();
//     int var28 = var26.getMonth();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)1388563200000L, true);
// 
//   }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Preceding"+ "'", var1.equals("Preceding"));

  }

  public void test54() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "Nearest"+ "'", var1.equals("Nearest"));

  }

  public void test55() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    var2.removeAgedItems(false);
    var2.fireSeriesChanged();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var2.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Preceding");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var10, (java.lang.Number)(byte)0);
// 
//   }

  public void test58() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(1, (-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test59() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 13);

  }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Following");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test61() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-1), 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    java.lang.Comparable var0 = null;
    java.lang.Class var3 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries(var0, "", "9-January-1900", var3);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test64() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(100, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test65() {}
//   public void test65() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     int var10 = var4.getYear();
//     java.util.Date var11 = var4.getStart();
//     java.util.TimeZone var12 = null;
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year(var11, var12);
// 
//   }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var19);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    java.lang.Class var2 = null;
    org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
    java.util.List var4 = var3.getItems();
    var3.setMaximumItemAge(1388563200000L);
    java.lang.Class var7 = var3.getTimePeriodClass();
    boolean var8 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)100.0d, (java.lang.Object)var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var10 = var3.getDataItem(2014);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     java.util.Calendar var8 = null;
//     var7.peg(var8);
// 
//   }

  public void test69() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    long var2 = var1.getFirstMillisecond();
    org.jfree.data.time.RegularTimePeriod var3 = var1.previous();
    long var4 = var1.getFirstMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);

  }

  public void test70() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("9-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var3);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var17, var19);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    java.lang.Class var1 = null;
    java.lang.Class var2 = null;
    java.lang.Object var3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ThreadContext", var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     java.lang.String var11 = var4.toString();
//     java.util.Calendar var12 = null;
//     long var13 = var4.getLastMillisecond(var12);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var6 = var2.getDataItem(10);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    java.lang.String[] var1 = org.jfree.data.time.SerialDate.getMonths(false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);

  }

  public void test77() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.Comparable var3 = var2.getKey();
    var2.setMaximumItemAge(0L);
    var2.removeAgedItems(true);
    org.jfree.data.time.RegularTimePeriod var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)1+ "'", var3.equals((byte)1));

  }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     java.util.Calendar var4 = null;
//     var0.peg(var4);
// 
//   }

  public void test79() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var7 = var4.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var13);
    org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var13);
    org.jfree.data.time.SerialDate var16 = var7.getEndOfCurrentMonth(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test80() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = var18.getNearestDayOfWeek(0);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    boolean var0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var0 == true);

  }

  public void test83() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=4]");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var11 = var4.next();
//     java.util.Calendar var12 = null;
//     long var13 = var4.getFirstMillisecond(var12);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test86() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(100, 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test87() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var7 = var2.getValue(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test88() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Time", var1);
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var5, (java.lang.Number)(-1.0f), false);
// 
//   }

  public void test91() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test92() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(10, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test93() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var11 = var8.getEndOfCurrentMonth(var10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.addMonths(1, var11);
    org.jfree.data.time.SerialDate var14 = var11.getPreviousDayOfWeek(1);
    org.jfree.data.time.SerialDate var15 = var4.getEndOfCurrentMonth(var14);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var14);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test94() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(31, (-460), 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

//  public void test95() throws Throwable {
//
//    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }
//
//
//    java.lang.Class var1 = null;
//    java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResource("", var1);
//    
//    // Regression assertion (captures the current behavior of the code)
//    assertNotNull(var2);
//
//  }
//
  public void test96() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    org.jfree.data.general.SeriesChangeListener var3 = null;
    var2.addChangeListener(var3);
    var2.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var2.getTimePeriod(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test97() {}
//   public void test97() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getStart();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1388563200000L);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     int var17 = var12.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 2014);
// 
//   }

  public void test100() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    java.lang.Class var7 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var8 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Following", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test102() {}
//   public void test102() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     var2.removeAgedItems(1388649599999L, false);
// 
//   }

  public void test103() {}
//   public void test103() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete(0, (-1));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
// 
//   }

  public void test104() {}
//   public void test104() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     var2.setMaximumItemAge(0L);
//     var2.removeAgedItems(true);
//     var2.setDescription("");
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 1.0d);
//     long var14 = var10.getMiddleMillisecond();
//     long var15 = var10.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var10, 1.0d, true);
// 
//   }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ThreadContext", var1);
// 
//   }

  public void test106() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(31, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test107() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("org.jfree.data.general.SeriesChangeEvent[source=4]");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test108() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    java.lang.Class var0 = null;
    java.util.Date var1 = null;
    java.util.TimeZone var2 = null;
    org.jfree.data.time.RegularTimePeriod var3 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var1, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test111() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
    org.jfree.data.time.SerialDate var6 = var3.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var12 = var9.getEndOfCurrentMonth(var11);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var12);
    org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var12);
    org.jfree.data.time.SerialDate var15 = var6.getEndOfCurrentMonth(var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var17 = var12.getPreviousDayOfWeek(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test112() {}
//   public void test112() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     java.util.Calendar var8 = null;
//     long var9 = var7.getMiddleMillisecond(var8);
// 
//   }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     java.lang.String var11 = var4.toString();
//     int var13 = var4.compareTo((java.lang.Object)0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2014"+ "'", var10.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1);
// 
//   }

  public void test114() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test115() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.String var6 = var2.getRangeDescription();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getTimePeriod((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));

  }

  public void test116() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(13, 12);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.Comparable var3 = var2.getKey();
    var2.setMaximumItemAge(0L);
    var2.removeAgedItems(true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)true);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)1+ "'", var3.equals((byte)1));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var2.removeChangeListener(var12);
//     var2.removeAgedItems(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var17 = var2.getValue(13);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    var9.setDescription("Value");
    org.jfree.data.time.SerialDate var21 = var2.getEndOfCurrentMonth(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addMonths((-1), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test122() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var16 = var13.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var18 = var6.getEndOfCurrentMonth(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var20 = var6.getFollowingDayOfWeek(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);

  }

  public void test123() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, (-1), 1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     org.jfree.data.time.TimeSeries var13 = var8.createCopy(10, 2014);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var18 = var17.getPeriod();
//     java.lang.Object var19 = var17.clone();
//     var17.setValue((java.lang.Number)1420099199999L);
//     var8.add(var17, false);
// 
//   }

  public void test125() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getEnd();
//     long var18 = var12.getLastMillisecond();
//     java.util.Calendar var19 = null;
//     var12.peg(var19);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     java.util.Calendar var11 = null;
//     long var12 = var4.getFirstMillisecond(var11);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("9-January-1900", var1);
// 
//   }

  public void test130() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.Class var6 = var2.getTimePeriodClass();
    java.lang.Class var7 = var2.getTimePeriodClass();
    java.lang.Class var8 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(100, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);

  }

  public void test131() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var10 = var2.getValue(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var6 = var1.getPreviousDayOfWeek(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test133() {}
//   public void test133() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     java.util.TimeZone var18 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var17, var18);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test134() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test135() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var1 = org.jfree.data.time.RegularTimePeriod.downsize(var0);
// 
//   }

  public void test137() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    java.lang.Class var5 = var2.getTimePeriodClass();
    int var6 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var2.getValue(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test139() {}
//   public void test139() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     boolean var6 = var2.getNotify();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var11 = var10.getPeriod();
//     var2.add(var10);
// 
//   }

  public void test140() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    org.jfree.data.time.RegularTimePeriod var9 = null;
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = var11.getEndOfCurrentMonth(var13);
    org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var13);
    org.jfree.data.time.SerialDate var16 = var15.getSerialDate();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var17 = var2.createCopy(var9, (org.jfree.data.time.RegularTimePeriod)var15);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(0, 2147483647, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test142() {}
//   public void test142() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getStart();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day(var21);
//     long var23 = var22.getFirstMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)12);
// 
//   }

  public void test143() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    org.jfree.data.time.RegularTimePeriod var4 = var1.next();
    java.util.Date var5 = var1.getTime();
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test144() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addDays(10, var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = var2.getPreviousDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test145() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    java.lang.String var11 = var8.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var8.getTimePeriod(100);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Nearest"+ "'", var11.equals("Nearest"));

  }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)0L);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var11);
//     java.util.List var13 = var12.getItems();
//     var12.setMaximumItemAge(1388563200000L);
//     java.lang.Class var16 = var12.getTimePeriodClass();
//     java.lang.Class var17 = var12.getTimePeriodClass();
//     java.lang.Class var18 = var12.getTimePeriodClass();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var20);
//     java.lang.String var22 = var21.getDescription();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     long var24 = var23.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 1.0d);
//     java.lang.Number var27 = null;
//     org.jfree.data.time.TimeSeriesDataItem var28 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, var27);
//     org.jfree.data.general.SeriesChangeListener var29 = null;
//     var21.removeChangeListener(var29);
//     org.jfree.data.time.FixedMillisecond var32 = new org.jfree.data.time.FixedMillisecond(0L);
//     var21.delete((org.jfree.data.time.RegularTimePeriod)var32);
//     java.util.Calendar var34 = null;
//     var32.peg(var34);
//     org.jfree.data.time.TimeSeriesDataItem var36 = var12.getDataItem((org.jfree.data.time.RegularTimePeriod)var32);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var32, 0.0d);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
    java.lang.String var7 = var6.getDescription();
    var6.removeAgedItems(false);
    var6.fireSeriesChanged();
    int var11 = var1.compareTo((java.lang.Object)var6);
    var6.clear();
    java.beans.PropertyChangeListener var13 = null;
    var6.addPropertyChangeListener(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var16 = var6.getTimePeriod((-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test149() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    java.lang.Class var7 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(12, 12);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var18.getMonth();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.next();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var22 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var18);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1388606399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test151() {}
//   public void test151() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     java.util.Calendar var21 = null;
//     long var22 = var19.getFirstMillisecond(var21);
// 
//   }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.lang.Object var17 = var2.clone();
//     var2.setMaximumItemAge(1388606399999L);
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var24 = var23.getPeriod();
//     var2.add(var23, true);
// 
//   }

  public void test153() {}
//   public void test153() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
//     org.jfree.data.time.SerialDate var6 = var3.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var12 = var9.getEndOfCurrentMonth(var11);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.addMonths(1, var12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var12);
//     org.jfree.data.time.SerialDate var15 = var6.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.SerialDate var16 = null;
//     org.jfree.data.time.SerialDate var17 = var15.getEndOfCurrentMonth(var16);
// 
//   }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Sun Dec 21 00:23:19 PST 2014", var1);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var12 = var8.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.setMaximumItemCount((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
    int var8 = var7.getDayOfMonth();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 31);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     java.util.TimeZone var20 = null;
//     org.jfree.data.time.RegularTimePeriod var21 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var18, var20);
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.Month var23 = new org.jfree.data.time.Month(var18, var22);
// 
//   }

  public void test158() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.String var6 = var2.getRangeDescription();
    var2.clear();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update((-460), (java.lang.Number)0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));

  }

  public void test159() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test161() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Time");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test162() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }


    org.jfree.data.time.Year var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(31, var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test163() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2014);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 28);

  }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    java.lang.Class var7 = var2.getTimePeriodClass();
    java.lang.Comparable var8 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setKey(var8);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test165() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10, 0, 31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test166() {}
//   public void test166() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.getPeriod();
//     java.lang.Object var5 = var3.clone();
//     var3.setValue((java.lang.Number)10.0f);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    java.lang.Class var4 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var6 = var2.getDataItem(0);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);

  }

  public void test168() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode((-460));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.io.InputStream var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Value", var1);
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getLastMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     var2.setDescription("");
//     int var18 = var2.getMaximumItemCount();
//     org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var21 = null;
//     long var22 = var20.getMiddleMillisecond(var21);
//     java.util.Date var23 = var20.getStart();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)2014L, false);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     java.util.Calendar var19 = null;
//     long var20 = var18.getFirstMillisecond(var19);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Nearest");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test174() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    var10.setNotify(false);
    org.jfree.data.time.RegularTimePeriod var13 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var15 = var10.addOrUpdate(var13, 1.0d);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test175() {}
//   public void test175() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getEnd();
//     java.lang.Number var22 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     java.util.Calendar var23 = null;
//     var16.peg(var23);
// 
//   }

  public void test176() {}
//   public void test176() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     int var1 = var0.getMonth();
//     int var2 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014);
// 
//   }

  public void test177() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = var5.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test178() {}
//   public void test178() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.lang.String var10 = var9.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 1.0d);
//     java.lang.Number var15 = null;
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var9.removeChangeListener(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     long var21 = var19.getFirstMillisecond();
//     var9.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1L);
//     java.lang.Object var24 = var9.clone();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var9);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var28 = null;
//     long var29 = var27.getMiddleMillisecond(var28);
//     org.jfree.data.time.RegularTimePeriod var30 = var27.next();
//     var9.add((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)2014L, false);
// 
//   }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.Class var6 = var2.getTimePeriodClass();
    int var7 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var9 = var2.getValue(31);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test180() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(100, var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test181() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("");
    java.lang.String var2 = var1.toString();
    java.lang.Throwable[] var3 = var1.getSuppressed();
    java.lang.String var4 = var1.toString();
    java.lang.Throwable[] var5 = var1.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var4.equals("org.jfree.data.time.TimePeriodFormatException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test182() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesException: Value");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test183() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2147483647, 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var19);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var20);
//     java.util.List var22 = var21.getItems();
//     var21.setMaximumItemAge(1388563200000L);
//     java.lang.String var25 = var21.getRangeDescription();
//     int var26 = var18.compareTo((java.lang.Object)var21);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     long var28 = var27.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var31 = var30.getPeriod();
//     var21.add(var30, true);
// 
//   }

  public void test186() {}
//   public void test186() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("org.jfree.data.general.SeriesException: Value", var1);
// 
//   }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var17);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var22 = var20.getNearestDayOfWeek((-460));
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.util.Calendar var10 = null;
//     long var11 = var4.getLastMillisecond(var10);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    var10.setNotify(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.update(28, (java.lang.Number)(-1.0d));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test190() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    java.lang.String var11 = var8.getDescription();
    org.jfree.data.time.RegularTimePeriod var12 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var13 = var8.getValue(var12);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "Nearest"+ "'", var11.equals("Nearest"));

  }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     java.util.Calendar var23 = null;
//     var19.peg(var23);
// 
//   }

  public void test192() {}
//   public void test192() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }
// 
// 
//     org.jfree.data.time.Year var1 = new org.jfree.data.time.Year();
//     long var2 = var1.getMiddleMillisecond();
//     long var3 = var1.getFirstMillisecond();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var4 = new org.jfree.data.time.Month(13, var1);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1388563200000L);
// 
//   }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     var6.removeAgedItems(false);
//     var6.fireSeriesChanged();
//     int var11 = var1.compareTo((java.lang.Object)var6);
//     var6.clear();
//     java.beans.PropertyChangeListener var13 = null;
//     var6.addPropertyChangeListener(var13);
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var19 = var18.getPeriod();
//     java.lang.Object var20 = var18.clone();
//     java.lang.Number var21 = var18.getValue();
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var22, 1.0d);
//     long var26 = var22.getMiddleMillisecond();
//     int var27 = var18.compareTo((java.lang.Object)var26);
//     var6.add(var18);
// 
//   }

  public void test194() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-460), 0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test195() {}
//   public void test195() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     int var22 = var19.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var23 = var19.previous();
//     java.util.Calendar var24 = null;
//     long var25 = var19.getMiddleMillisecond(var24);
// 
//   }

  public void test196() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     java.util.Calendar var4 = null;
//     long var5 = var0.getFirstMillisecond(var4);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test199() {}
//   public void test199() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     java.util.TimeZone var20 = null;
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year(var17, var20);
// 
//   }

  public void test200() {}
//   public void test200() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     java.lang.String var11 = var8.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var13);
//     java.lang.String var15 = var14.getDescription();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 1.0d);
//     java.lang.Number var20 = null;
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, var20);
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var14.removeChangeListener(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     long var25 = var24.getMiddleMillisecond();
//     long var26 = var24.getFirstMillisecond();
//     var14.update((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1L);
//     java.lang.Object var29 = var14.clone();
//     var14.setMaximumItemAge(1388606399999L);
//     var14.setMaximumItemCount(13);
//     var14.setMaximumItemCount(28);
//     java.util.Collection var36 = var8.getTimePeriodsUniqueToOtherSeries(var14);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var42 = var39.getEndOfCurrentMonth(var41);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.addMonths(1, var42);
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var43, var44);
//     var45.setDescription("Nearest");
//     org.jfree.data.time.TimeSeries var50 = var45.createCopy(10, 2014);
//     java.lang.Class var52 = null;
//     org.jfree.data.time.TimeSeries var53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var52);
//     java.lang.String var54 = var53.getDescription();
//     org.jfree.data.time.Year var55 = new org.jfree.data.time.Year();
//     long var56 = var55.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var55, 1.0d);
//     java.lang.Number var59 = null;
//     org.jfree.data.time.TimeSeriesDataItem var60 = var53.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var55, var59);
//     org.jfree.data.general.SeriesChangeListener var61 = null;
//     var53.removeChangeListener(var61);
//     org.jfree.data.time.Year var63 = new org.jfree.data.time.Year();
//     long var64 = var63.getMiddleMillisecond();
//     long var65 = var63.getFirstMillisecond();
//     var53.update((org.jfree.data.time.RegularTimePeriod)var63, (java.lang.Number)1L);
//     java.util.Date var68 = var63.getStart();
//     java.lang.Number var69 = var45.getValue((org.jfree.data.time.RegularTimePeriod)var63);
//     var8.add((org.jfree.data.time.RegularTimePeriod)var63, (-1.0d), true);
// 
//   }

  public void test201() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-1), false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test202() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    java.util.Date var4 = var1.getStart();
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var7 = var5.getNearestDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test203() {}
//   public void test203() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     org.jfree.data.general.SeriesChangeListener var3 = null;
//     var2.addChangeListener(var3);
//     var2.setDescription("org.jfree.data.general.SeriesException: Value");
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.util.List var10 = var9.getItems();
//     var9.setMaximumItemAge(1388563200000L);
//     java.lang.Class var13 = var9.getTimePeriodClass();
//     java.lang.Class var14 = var9.getTimePeriodClass();
//     java.lang.Class var15 = var9.getTimePeriodClass();
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.Number var24 = null;
//     org.jfree.data.time.TimeSeriesDataItem var25 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, var24);
//     org.jfree.data.general.SeriesChangeListener var26 = null;
//     var18.removeChangeListener(var26);
//     org.jfree.data.time.FixedMillisecond var29 = new org.jfree.data.time.FixedMillisecond(0L);
//     var18.delete((org.jfree.data.time.RegularTimePeriod)var29);
//     java.util.Calendar var31 = null;
//     var29.peg(var31);
//     org.jfree.data.time.TimeSeriesDataItem var33 = var9.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     java.util.Calendar var34 = null;
//     long var35 = var29.getMiddleMillisecond(var34);
//     java.lang.Number var36 = null;
//     var2.add((org.jfree.data.time.RegularTimePeriod)var29, var36, false);
// 
//   }

  public void test204() {}
//   public void test204() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }
// 
// 
//     java.lang.Class var1 = null;
//     java.net.URL var2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Time", var1);
// 
//   }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     int var18 = var12.getYear();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var12);
//     var2.clear();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     long var23 = var21.getFirstMillisecond();
//     long var24 = var21.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var25 = var21.next();
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var21);
//     java.lang.String var27 = var21.toString();
//     org.jfree.data.time.TimeSeriesDataItem var28 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var27 + "' != '" + "2014"+ "'", var27.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     org.jfree.data.time.RegularTimePeriod var1 = var0.next();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(13, 10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test209() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    var2.setDescription("Following");

  }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var9 = var8.getLastMillisecond();
//     java.util.Calendar var10 = null;
//     long var11 = var8.getMiddleMillisecond(var10);
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, (-1.0d));
//     var2.add(var13, true);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var20);
//     java.util.List var22 = var21.getItems();
//     var21.setMaximumItemAge(1388563200000L);
//     java.lang.String var25 = var21.getRangeDescription();
//     int var26 = var18.compareTo((java.lang.Object)var21);
//     int var27 = var18.getMonth();
//     java.util.Calendar var28 = null;
//     long var29 = var18.getLastMillisecond(var28);
// 
//   }

  public void test212() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     java.util.Calendar var23 = null;
//     var21.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var26 = var2.isEmpty();
//     var2.setRangeDescription("Time");
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     long var31 = var29.getFirstMillisecond();
//     long var32 = var29.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var33 = var29.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     org.jfree.data.time.FixedMillisecond var36 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var37 = var36.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var36, 1.0d, false);
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(31);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test215() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("ERROR : Relative To String");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test216() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }


    org.jfree.data.time.TimePeriodFormatException var1 = new org.jfree.data.time.TimePeriodFormatException("");
    java.lang.String var2 = var1.toString();
    java.lang.String var3 = var1.toString();
    java.lang.String var4 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var2.equals("org.jfree.data.time.TimePeriodFormatException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var3.equals("org.jfree.data.time.TimePeriodFormatException: "));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: "+ "'", var4.equals("org.jfree.data.time.TimePeriodFormatException: "));

  }

  public void test217() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(9, 0, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year(var17);
//     java.util.TimeZone var19 = null;
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var17, var19);
// 
//   }

  public void test219() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    java.util.Date var4 = var1.getStart();
    org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var4, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var12 = var11.getPeriod();
//     java.lang.Object var13 = var11.clone();
//     java.lang.Number var14 = var11.getValue();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 1.0d);
//     long var19 = var15.getMiddleMillisecond();
//     int var20 = var11.compareTo((java.lang.Object)var19);
//     java.lang.Number var21 = var11.getValue();
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var23);
//     java.lang.String var25 = var24.getDescription();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     long var27 = var26.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 1.0d);
//     java.lang.Number var30 = null;
//     org.jfree.data.time.TimeSeriesDataItem var31 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, var30);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var24.removeChangeListener(var32);
//     org.jfree.data.time.Year var34 = new org.jfree.data.time.Year();
//     long var35 = var34.getMiddleMillisecond();
//     long var36 = var34.getFirstMillisecond();
//     var24.update((org.jfree.data.time.RegularTimePeriod)var34, (java.lang.Number)1L);
//     java.util.Date var39 = var34.getStart();
//     org.jfree.data.time.Day var40 = new org.jfree.data.time.Day(var39);
//     long var41 = var40.getFirstMillisecond();
//     boolean var42 = var11.equals((java.lang.Object)var41);
//     var2.add(var11);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(var0);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var4 = var3.getTimePeriodClass();
//     java.lang.Object var5 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var1, var4);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var7);
//     java.lang.String var9 = var8.getDescription();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 1.0d);
//     java.lang.Number var14 = null;
//     org.jfree.data.time.TimeSeriesDataItem var15 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, var14);
//     int var16 = var10.getYear();
//     java.util.Date var17 = var10.getStart();
//     java.util.TimeZone var18 = null;
//     org.jfree.data.time.RegularTimePeriod var19 = org.jfree.data.time.RegularTimePeriod.createInstance(var1, var17, var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
// 
//   }

  public void test223() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test224() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var12 = null;
    long var13 = var11.getLastMillisecond(var12);
    org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
    var2.setDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var19 = var2.getValue(2147483647);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-460), (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    java.lang.Class var2 = var1.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var4 = var1.getValue(1);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     org.jfree.data.time.RegularTimePeriod var11 = var4.next();
//     org.jfree.data.time.RegularTimePeriod var12 = var4.previous();
//     java.util.Calendar var13 = null;
//     var4.peg(var13);
// 
//   }

  public void test228() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidMonthCode(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test229() {}
//   public void test229() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     long var4 = var1.getLastMillisecond();
//     java.util.Date var5 = var1.getTime();
//     java.util.TimeZone var6 = null;
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year(var5, var6);
// 
//   }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.lang.String var10 = var9.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 1.0d);
//     java.lang.Number var15 = null;
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var9.removeChangeListener(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     long var21 = var19.getFirstMillisecond();
//     var9.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1L);
//     java.lang.Object var24 = var9.clone();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var9);
//     java.lang.String var26 = var9.getDomainDescription();
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     long var28 = var27.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var27, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var31 = var30.getPeriod();
//     java.lang.Object var32 = var30.clone();
//     java.lang.Number var33 = var30.getValue();
//     var9.add(var30, false);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    long var2 = var1.getLastMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    long var6 = var1.getFirstMillisecond(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    java.lang.Object var4 = var2.clone();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(31, (java.lang.Number)1388563200000L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test233() {}
//   public void test233() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     int var11 = var10.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 100.0d);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     long var16 = var14.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     org.jfree.data.time.RegularTimePeriod var18 = var17.getPeriod();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test234() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)13);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }

  }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     int var22 = var19.getYearValue();
//     java.lang.String var23 = var19.toString();
//     long var24 = var19.getSerialIndex();
//     java.util.Calendar var25 = null;
//     long var26 = var19.getLastMillisecond(var25);
// 
//   }

  public void test237() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2014, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test238() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.RegularTimePeriod var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var10, 0.0d, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);

  }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    int var2 = var1.getYYYY();
    java.lang.String var3 = var1.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var5 = var1.getPreviousDayOfWeek(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "12-January-1900"+ "'", var3.equals("12-January-1900"));

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Calendar var17 = null;
//     long var18 = var12.getFirstMillisecond(var17);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     var2.clear();
//     org.jfree.data.time.TimeSeries var10 = var2.createCopy(10, 31);
//     org.jfree.data.time.TimeSeries var11 = null;
//     org.jfree.data.time.TimeSeries var12 = var2.addAndOrUpdate(var11);
// 
//   }

  public void test242() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test243() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var12 = null;
    long var13 = var11.getLastMillisecond(var12);
    org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
    var2.setDescription("");
    org.jfree.data.time.RegularTimePeriod var18 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var19 = var2.getDataItem(var18);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);

  }

  public void test244() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(2014);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test245() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 520764324);

  }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
    java.lang.String var7 = var6.getDescription();
    var6.removeAgedItems(false);
    var6.fireSeriesChanged();
    int var11 = var1.compareTo((java.lang.Object)var6);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var13 = var6.getTimePeriod((-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     java.lang.Class var0 = null;
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     java.util.TimeZone var20 = null;
//     org.jfree.data.time.RegularTimePeriod var21 = org.jfree.data.time.RegularTimePeriod.createInstance(var0, var18, var20);
//     java.util.TimeZone var22 = null;
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year(var18, var22);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.Year var23 = var19.getYear();
//     java.util.Calendar var24 = null;
//     long var25 = var23.getLastMillisecond(var24);
// 
//   }

  public void test249() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    var2.removeAgedItems(false);
    var2.fireSeriesChanged();
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.addChangeListener(var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var9 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test250() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getLastMillisecond();
    java.util.Date var5 = var1.getStart();
    java.util.TimeZone var6 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5, var6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test251() {}
//   public void test251() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var8 = var2.getTimePeriodClass();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var10);
//     java.lang.String var12 = var11.getDescription();
//     org.jfree.data.time.FixedMillisecond var14 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var15 = var14.getLastMillisecond();
//     java.util.Calendar var16 = null;
//     long var17 = var14.getMiddleMillisecond(var16);
//     org.jfree.data.time.TimeSeriesDataItem var18 = var11.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     long var19 = var14.getLastMillisecond();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)10.0d, false);
// 
//   }

  public void test252() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     var2.removeAgedItems(false);
//     var2.fireSeriesChanged();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.lang.String var10 = var9.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 1.0d);
//     java.lang.Number var15 = null;
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var9.removeChangeListener(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     long var21 = var19.getFirstMillisecond();
//     var9.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1L);
//     java.util.Date var24 = var19.getStart();
//     org.jfree.data.time.Day var25 = new org.jfree.data.time.Day(var24);
//     long var26 = var25.getMiddleMillisecond();
//     int var27 = var25.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 0.0d);
//     java.lang.String var30 = var25.toString();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var25, 10.0d);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(2147483647, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test255() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + ""+ "'", var1.equals(""));

  }

  public void test256() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(0, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test257() {}
//   public void test257() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     java.lang.String var18 = var12.toString();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var20);
//     java.lang.String var22 = var21.getDescription();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     long var24 = var23.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 1.0d);
//     java.lang.Number var27 = null;
//     org.jfree.data.time.TimeSeriesDataItem var28 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, var27);
//     java.lang.String var29 = var23.toString();
//     org.jfree.data.time.RegularTimePeriod var30 = var23.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var23.previous();
//     org.jfree.data.time.TimeSeries var32 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var23);
//     java.util.Calendar var33 = null;
//     long var34 = var12.getLastMillisecond(var33);
// 
//   }

  public void test258() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(520764324, (-460));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test259() {}
//   public void test259() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     long var4 = var0.getMiddleMillisecond();
//     java.lang.String var5 = var0.toString();
//     int var6 = var0.getYear();
//     java.util.Calendar var7 = null;
//     long var8 = var0.getLastMillisecond(var7);
// 
//   }

  public void test260() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }


    org.jfree.data.time.SerialDate var1 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((-1), var1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test261() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.lang.Object var17 = var2.clone();
//     var2.setMaximumItemAge(1388606399999L);
//     var2.setMaximumItemCount(13);
//     var2.setMaximumItemCount(28);
//     org.jfree.data.time.RegularTimePeriod var24 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var25 = var2.getValue(var24);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.Year var23 = var19.getYear();
//     org.jfree.data.time.Year var24 = var19.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Object var25 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var19);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    java.lang.Object var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     int var18 = var12.getYear();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var12);
//     java.lang.String var20 = var12.toString();
//     long var21 = var12.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "2014"+ "'", var20.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014L);
// 
//   }

  public void test266() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(13, (-1));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test267() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    java.lang.Class var5 = var2.getTimePeriodClass();
    int var6 = var2.getItemCount();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeries var9 = var2.createCopy(10, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var7 = var4.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var13);
    org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var13);
    org.jfree.data.time.SerialDate var16 = var7.getEndOfCurrentMonth(var13);
    var7.setDescription("Value");
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addYears(13, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = var7.getPreviousDayOfWeek((-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test269() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }


    java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(1, true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "Jan"+ "'", var2.equals("Jan"));

  }

  public void test270() {}
//   public void test270() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     var2.clear();
//     java.lang.String var8 = var2.getDomainDescription();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var12);
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     java.lang.String var16 = var14.toString();
//     long var17 = var14.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)28);
//     java.util.Calendar var20 = null;
//     var14.peg(var20);
// 
//   }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var2 = var1.getYYYY();
//     java.lang.String var3 = var1.toString();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.util.List var7 = var6.getItems();
//     var6.setMaximumItemAge(1388563200000L);
//     java.lang.Class var10 = var6.getTimePeriodClass();
//     java.lang.Class var11 = var6.getTimePeriodClass();
//     java.lang.Class var12 = var6.getTimePeriodClass();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var14);
//     java.lang.String var16 = var15.getDescription();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 1.0d);
//     java.lang.Number var21 = null;
//     org.jfree.data.time.TimeSeriesDataItem var22 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, var21);
//     org.jfree.data.general.SeriesChangeListener var23 = null;
//     var15.removeChangeListener(var23);
//     org.jfree.data.time.FixedMillisecond var26 = new org.jfree.data.time.FixedMillisecond(0L);
//     var15.delete((org.jfree.data.time.RegularTimePeriod)var26);
//     java.util.Calendar var28 = null;
//     var26.peg(var28);
//     org.jfree.data.time.TimeSeriesDataItem var30 = var6.getDataItem((org.jfree.data.time.RegularTimePeriod)var26);
//     boolean var31 = var1.equals((java.lang.Object)var26);
//     org.jfree.data.time.SerialDate var32 = null;
//     boolean var33 = var1.isBefore(var32);
// 
//   }

  public void test272() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(520764324, 28, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test273() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.setMaximumItemAge((-2208268800000L));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(1);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     int var23 = var19.compareTo((java.lang.Object)1.0f);
//     java.lang.Class var25 = null;
//     org.jfree.data.time.TimeSeries var26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var25);
//     java.lang.String var27 = var26.getDescription();
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var28, 1.0d);
//     java.lang.Number var32 = null;
//     org.jfree.data.time.TimeSeriesDataItem var33 = var26.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var28, var32);
//     org.jfree.data.general.SeriesChangeListener var34 = null;
//     var26.removeChangeListener(var34);
//     org.jfree.data.time.Year var36 = new org.jfree.data.time.Year();
//     long var37 = var36.getMiddleMillisecond();
//     long var38 = var36.getFirstMillisecond();
//     var26.update((org.jfree.data.time.RegularTimePeriod)var36, (java.lang.Number)1L);
//     java.util.Date var41 = var36.getStart();
//     org.jfree.data.time.Day var42 = new org.jfree.data.time.Day(var41);
//     long var43 = var42.getMiddleMillisecond();
//     java.lang.String var44 = var42.toString();
//     java.lang.String var45 = var42.toString();
//     int var46 = var19.compareTo((java.lang.Object)var42);
//     java.lang.String var47 = var19.toString();
//     java.lang.String var48 = var19.toString();
//     java.util.Calendar var49 = null;
//     long var50 = var19.getFirstMillisecond(var49);
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getEnd();
//     java.util.TimeZone var18 = null;
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year(var17, var18);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var13 = null;
//     long var14 = var12.getMiddleMillisecond(var13);
//     org.jfree.data.time.RegularTimePeriod var15 = var12.next();
//     java.util.Date var16 = var12.getTime();
//     var8.add((org.jfree.data.time.RegularTimePeriod)var12, 10.0d);
// 
//   }

  public void test278() {}
//   public void test278() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getStart();
//     org.jfree.data.time.Day var22 = new org.jfree.data.time.Day(var21);
//     long var23 = var22.getMiddleMillisecond();
//     int var24 = var22.getMonth();
//     org.jfree.data.time.RegularTimePeriod var25 = var22.next();
//     org.jfree.data.time.RegularTimePeriod var26 = var22.next();
//     org.jfree.data.time.RegularTimePeriod var27 = var22.previous();
//     var2.add(var27, 100.0d);
// 
//   }

  public void test279() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     var2.clear();
//     java.lang.String var8 = var2.getDomainDescription();
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.Day var14 = new org.jfree.data.time.Day(var12);
//     org.jfree.data.time.RegularTimePeriod var15 = var14.next();
//     java.lang.String var16 = var14.toString();
//     long var17 = var14.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)28);
//     var2.removeAgedItems(1419148800000L, true);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    var9.setDescription("Value");
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(13, var9);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays((-460), var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(21, var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test282() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }


    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    var9.setDescription("Value");
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.addYears(13, var9);
    org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addDays((-460), var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, var22);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test283() {}
//   public void test283() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.getPeriod();
//     java.lang.Object var5 = var3.clone();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var7);
//     java.lang.String var9 = var8.getDescription();
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 1.0d);
//     java.lang.Number var14 = null;
//     org.jfree.data.time.TimeSeriesDataItem var15 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, var14);
//     org.jfree.data.general.SeriesChangeListener var16 = null;
//     var8.removeChangeListener(var16);
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     long var20 = var18.getFirstMillisecond();
//     var8.update((org.jfree.data.time.RegularTimePeriod)var18, (java.lang.Number)1L);
//     java.util.Date var23 = var18.getStart();
//     org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var23);
//     long var25 = var24.getMiddleMillisecond();
//     int var26 = var24.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, 0.0d);
//     boolean var29 = var3.equals((java.lang.Object)var24);
//     java.lang.String var30 = var24.toString();
//     java.util.Calendar var31 = null;
//     long var32 = var24.getMiddleMillisecond(var31);
// 
//   }

  public void test284() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test285() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.Comparable var3 = var2.getKey();
    var2.setMaximumItemAge(0L);
    var2.removeAgedItems(true);
    var2.setDescription("");
    java.beans.PropertyChangeListener var10 = null;
    var2.removePropertyChangeListener(var10);
    int var12 = var2.getItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + (byte)1+ "'", var3.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);

  }

  public void test286() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond();
    org.jfree.data.time.TimeSeriesDataItem var12 = var8.getDataItem((org.jfree.data.time.RegularTimePeriod)var11);
    var8.fireSeriesChanged();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);

  }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.Year var23 = var19.getYear();
//     org.jfree.data.time.Year var24 = var19.getYear();
//     java.util.Calendar var25 = null;
//     long var26 = var19.getLastMillisecond(var25);
// 
//   }

  public void test288() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(520764324, 2147483647, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     org.jfree.data.general.SeriesChangeListener var7 = null;
//     var2.removeChangeListener(var7);
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var10);
//     java.lang.String var12 = var11.getDescription();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     java.lang.Number var17 = null;
//     org.jfree.data.time.TimeSeriesDataItem var18 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, var17);
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var11.removeChangeListener(var19);
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     long var23 = var21.getFirstMillisecond();
//     var11.update((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)1L);
//     java.util.Date var26 = var21.getStart();
//     org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(var26);
//     org.jfree.data.time.Month var28 = new org.jfree.data.time.Month(var26);
//     long var29 = var28.getSerialIndex();
//     int var30 = var28.getMonth();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.next();
//     org.jfree.data.time.Year var32 = var28.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, (java.lang.Number)1419150198886L);
//     var2.add(var34);
// 
//   }

  public void test291() {}
//   public void test291() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)12, "Sun Dec 21 00:23:19 PST 2014", "Preceding", var3);
//     java.lang.Comparable var5 = var4.getKey();
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var7);
//     java.lang.String var9 = var8.getDescription();
//     java.lang.Object var10 = var8.clone();
//     java.lang.Class var12 = null;
//     org.jfree.data.time.TimeSeries var13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var12);
//     java.lang.String var14 = var13.getDescription();
//     org.jfree.data.time.Year var15 = new org.jfree.data.time.Year();
//     long var16 = var15.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var15, 1.0d);
//     java.lang.Number var19 = null;
//     org.jfree.data.time.TimeSeriesDataItem var20 = var13.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var15, var19);
//     org.jfree.data.general.SeriesChangeListener var21 = null;
//     var13.removeChangeListener(var21);
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     long var24 = var23.getMiddleMillisecond();
//     long var25 = var23.getFirstMillisecond();
//     var13.update((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)1L);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var29);
//     java.lang.String var31 = var30.getDescription();
//     org.jfree.data.time.Year var32 = new org.jfree.data.time.Year();
//     long var33 = var32.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var32, 1.0d);
//     java.lang.Number var36 = null;
//     org.jfree.data.time.TimeSeriesDataItem var37 = var30.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var32, var36);
//     org.jfree.data.general.SeriesChangeListener var38 = null;
//     var30.removeChangeListener(var38);
//     org.jfree.data.time.FixedMillisecond var41 = new org.jfree.data.time.FixedMillisecond(0L);
//     var30.delete((org.jfree.data.time.RegularTimePeriod)var41);
//     org.jfree.data.time.TimeSeries var43 = var8.createCopy((org.jfree.data.time.RegularTimePeriod)var23, (org.jfree.data.time.RegularTimePeriod)var41);
//     var4.add((org.jfree.data.time.RegularTimePeriod)var23, (java.lang.Number)(short)0, false);
// 
//   }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var2 = var1.getLastMillisecond();
//     java.util.Calendar var3 = null;
//     long var4 = var1.getMiddleMillisecond(var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var1.next();
//     java.util.Date var6 = var1.getTime();
//     java.util.TimeZone var7 = null;
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year(var6, var7);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.String var6 = var2.getRangeDescription();
    var2.clear();
    org.jfree.data.time.TimeSeries var10 = var2.createCopy(10, 31);
    java.util.Collection var11 = var2.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test294() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    var2.setDomainDescription("January 2014");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(1900, (java.lang.Number)1419150203064L);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test296() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-1), 28, 21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test297() {}
//   public void test297() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var4 = var3.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getMiddleMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var3.next();
//     int var8 = var0.compareTo((java.lang.Object)var3);
//     java.util.Calendar var9 = null;
//     long var10 = var3.getMiddleMillisecond(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("January 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    int var1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     int var10 = var4.getYear();
//     java.util.Date var11 = var4.getStart();
//     java.util.Calendar var12 = null;
//     var4.peg(var12);
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getEnd();
//     java.lang.Number var22 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     long var23 = var2.getMaximumItemAge();
//     var2.setRangeDescription("31-January-1900");
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 9223372036854775807L);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    long var4 = var2.getMaximumItemAge();
    java.lang.Comparable var5 = var2.getKey();
    org.jfree.data.time.FixedMillisecond var7 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var8 = null;
    long var9 = var7.getLastMillisecond(var8);
    org.jfree.data.time.TimeSeriesDataItem var10 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.update(0, (java.lang.Number)(-2208268800000L));
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)1+ "'", var5.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test303() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var2 = var1.toString();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var19 = var1.getEndOfCurrentMonth(var15);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = var15.getPreviousDayOfWeek(10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "9-January-1900"+ "'", var2.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test304() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test305() {}
//   public void test305() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getLastMillisecond();
//     long var20 = var18.getLastMillisecond();
//     java.util.Calendar var21 = null;
//     var18.peg(var21);
// 
//   }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var5 = var4.getTimePeriodClass();
//     java.lang.Object var6 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var2, var5);
//     java.io.InputStream var7 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("1-January-2014", var2);
// 
//   }

  public void test308() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-452));

  }

  public void test309() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }


    java.util.Collection var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.util.Collection var1 = org.jfree.chart.util.ObjectUtilities.deepClone(var0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test310() {}
//   public void test310() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Object var4 = var2.clone();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var6);
//     java.lang.String var8 = var7.getDescription();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     java.lang.Number var13 = null;
//     org.jfree.data.time.TimeSeriesDataItem var14 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, var13);
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var7.removeChangeListener(var15);
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     long var19 = var17.getFirstMillisecond();
//     var7.update((org.jfree.data.time.RegularTimePeriod)var17, (java.lang.Number)1L);
//     java.lang.Class var23 = null;
//     org.jfree.data.time.TimeSeries var24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var23);
//     java.lang.String var25 = var24.getDescription();
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     long var27 = var26.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var26, 1.0d);
//     java.lang.Number var30 = null;
//     org.jfree.data.time.TimeSeriesDataItem var31 = var24.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var26, var30);
//     org.jfree.data.general.SeriesChangeListener var32 = null;
//     var24.removeChangeListener(var32);
//     org.jfree.data.time.FixedMillisecond var35 = new org.jfree.data.time.FixedMillisecond(0L);
//     var24.delete((org.jfree.data.time.RegularTimePeriod)var35);
//     org.jfree.data.time.TimeSeries var37 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var17, (org.jfree.data.time.RegularTimePeriod)var35);
//     java.util.List var38 = var2.getItems();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var43 = var42.getPeriod();
//     java.lang.Object var44 = var42.clone();
//     java.lang.Number var45 = var42.getValue();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var46, 1.0d);
//     long var50 = var46.getMiddleMillisecond();
//     int var51 = var42.compareTo((java.lang.Object)var50);
//     java.lang.Number var52 = var42.getValue();
//     java.lang.Number var53 = var42.getValue();
//     var2.add(var42, true);
// 
//   }

  public void test311() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-1), 520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(520764324);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = org.jfree.data.time.Year.parseYear("Following");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test315() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("SerialDate.weekInMonthToString(): invalid code.");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test316() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    org.jfree.data.general.SeriesChangeListener var3 = null;
    var2.addChangeListener(var3);
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(9223372036854775807L);
    int var9 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
    org.jfree.data.time.RegularTimePeriod var10 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.add(var10, (java.lang.Number)1391241599999L, false);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));

  }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     int var18 = var12.getYear();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var12);
//     var2.clear();
//     long var21 = var2.getMaximumItemAge();
//     var2.setMaximumItemAge(10L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 9223372036854775807L);
// 
//   }

  public void test318() {}
//   public void test318() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     boolean var9 = var1.equals((java.lang.Object)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var12 = var11.getYYYY();
//     boolean var13 = var1.isAfter((org.jfree.data.time.SerialDate)var11);
//     int var14 = var1.getYYYY();
//     org.jfree.data.time.SerialDate var15 = null;
//     org.jfree.data.time.SpreadsheetDate var17 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var22 = var19.getEndOfCurrentMonth(var21);
//     org.jfree.data.time.Day var23 = new org.jfree.data.time.Day(var21);
//     org.jfree.data.time.RegularTimePeriod var24 = var23.next();
//     boolean var25 = var17.equals((java.lang.Object)var23);
//     org.jfree.data.time.SpreadsheetDate var27 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var28 = var27.getYYYY();
//     boolean var29 = var17.isAfter((org.jfree.data.time.SerialDate)var27);
//     boolean var30 = var1.isInRange(var15, (org.jfree.data.time.SerialDate)var17);
// 
//   }

  public void test319() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("9-January-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("Value");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test321() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getMiddleMillisecond();
    java.util.Date var5 = var1.getEnd();
    java.util.Calendar var6 = null;
    long var7 = var1.getMiddleMillisecond(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0L);

  }

  public void test322() {}
//   public void test322() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     int var2 = var0.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2014);
// 
//   }

  public void test323() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    var2.removeAgedItems(false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var6 = var2.getNextTimePeriod();
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);

  }

  public void test324() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var6);
    org.jfree.data.time.RegularTimePeriod var9 = var8.next();
    boolean var10 = var2.equals((java.lang.Object)var8);
    org.jfree.data.time.SpreadsheetDate var12 = new org.jfree.data.time.SpreadsheetDate(13);
    int var13 = var12.getYYYY();
    boolean var14 = var2.isAfter((org.jfree.data.time.SerialDate)var12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek(10, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-1), 520764324, 9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test326() {}
//   public void test326() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Month var2 = new org.jfree.data.time.Month(var0, var1);
// 
//   }

  public void test327() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test328() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(13);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var7 = var6.getLastMillisecond();
//     java.util.Calendar var8 = null;
//     long var9 = var6.getMiddleMillisecond(var8);
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.getDataItem((org.jfree.data.time.RegularTimePeriod)var6);
//     org.jfree.data.time.FixedMillisecond var12 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var13 = null;
//     long var14 = var12.getLastMillisecond(var13);
//     org.jfree.data.time.TimeSeriesDataItem var16 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, (-1.0d));
//     java.lang.Class var18 = null;
//     org.jfree.data.time.TimeSeries var19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var18);
//     java.lang.String var20 = var19.getDescription();
//     org.jfree.data.time.Year var21 = new org.jfree.data.time.Year();
//     long var22 = var21.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var21, 1.0d);
//     java.lang.Number var25 = null;
//     org.jfree.data.time.TimeSeriesDataItem var26 = var19.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var21, var25);
//     int var27 = var21.getYear();
//     java.util.Date var28 = var21.getStart();
//     long var29 = var21.getSerialIndex();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var21, (java.lang.Number)10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(0, var21);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var29 == 2014L);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.removeAgedItems(false);
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var10 = var9.getPeriod();
//     java.lang.Object var11 = var9.clone();
//     java.lang.Number var12 = var9.getValue();
//     org.jfree.data.time.RegularTimePeriod var13 = var9.getPeriod();
//     var2.add(var9, false);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test332() {}
//   public void test332() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     java.lang.String var11 = var8.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var13);
//     java.lang.String var15 = var14.getDescription();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 1.0d);
//     java.lang.Number var20 = null;
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, var20);
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var14.removeChangeListener(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     long var25 = var24.getMiddleMillisecond();
//     long var26 = var24.getFirstMillisecond();
//     var14.update((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1L);
//     java.util.Date var29 = var24.getStart();
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(short)(-1));
//     long var33 = var30.getFirstMillisecond();
//     java.lang.String var34 = var30.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "Nearest"+ "'", var11.equals("Nearest"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var34 + "' != '" + "1-January-2014"+ "'", var34.equals("1-January-2014"));
// 
//   }

  public void test333() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test334() {}
//   public void test334() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     java.lang.String var18 = var12.toString();
//     java.lang.Class var20 = null;
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var20);
//     java.lang.String var22 = var21.getDescription();
//     org.jfree.data.time.Year var23 = new org.jfree.data.time.Year();
//     long var24 = var23.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var23, 1.0d);
//     java.lang.Number var27 = null;
//     org.jfree.data.time.TimeSeriesDataItem var28 = var21.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var23, var27);
//     java.lang.String var29 = var23.toString();
//     org.jfree.data.time.RegularTimePeriod var30 = var23.next();
//     org.jfree.data.time.RegularTimePeriod var31 = var23.previous();
//     org.jfree.data.time.TimeSeries var32 = var2.createCopy((org.jfree.data.time.RegularTimePeriod)var12, (org.jfree.data.time.RegularTimePeriod)var23);
//     int var33 = var2.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var18 + "' != '" + "2014"+ "'", var18.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "2014"+ "'", var29.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 0);
// 
//   }

  public void test335() {}
//   public void test335() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     int var10 = var4.getYear();
//     java.util.Date var11 = var4.getStart();
//     org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var11);
//     java.util.Calendar var13 = null;
//     long var14 = var12.getMiddleMillisecond(var13);
// 
//   }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getFirstMillisecond();
//     java.util.Calendar var20 = null;
//     var18.peg(var20);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-2001));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test338() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     java.lang.Comparable var4 = var2.getKey();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var6);
//     java.lang.String var8 = var7.getDescription();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     java.lang.Number var13 = null;
//     org.jfree.data.time.TimeSeriesDataItem var14 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, var13);
//     org.jfree.data.general.SeriesChangeListener var15 = null;
//     var7.removeChangeListener(var15);
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(0L);
//     var7.delete((org.jfree.data.time.RegularTimePeriod)var18);
//     java.util.Calendar var20 = null;
//     var18.peg(var20);
//     java.util.Calendar var22 = null;
//     long var23 = var18.getMiddleMillisecond(var22);
//     var2.add((org.jfree.data.time.RegularTimePeriod)var18, 10.0d, true);
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(var18);
//     org.jfree.data.time.Month var20 = new org.jfree.data.time.Month(var18);
//     long var21 = var20.getSerialIndex();
//     int var22 = var20.getMonth();
//     org.jfree.data.time.RegularTimePeriod var23 = var20.next();
//     java.lang.Object var24 = null;
//     int var25 = var20.compareTo(var24);
//     org.jfree.data.time.Year var26 = var20.getYear();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var27 = new org.jfree.data.time.Month((-1), var26);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
// 
//   }

  public void test341() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount((-2001));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-945));

  }

  public void test343() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString((-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test344() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    org.jfree.data.general.SeriesChangeListener var7 = null;
    var2.removeChangeListener(var7);
    java.util.Collection var9 = var2.getTimePeriods();
    java.util.Collection var10 = org.jfree.chart.util.ObjectUtilities.deepClone(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test345() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(28);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test346() {}
//   public void test346() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var3);
//     java.lang.String var5 = var4.getDescription();
//     int var6 = var0.compareTo((java.lang.Object)var4);
//     java.lang.Object var7 = var4.clone();
//     org.jfree.data.time.FixedMillisecond var9 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var10 = null;
//     long var11 = var9.getMiddleMillisecond(var10);
//     java.util.Date var12 = var9.getStart();
//     org.jfree.data.time.RegularTimePeriod var13 = var9.next();
//     var4.add((org.jfree.data.time.RegularTimePeriod)var9, 0.0d, true);
// 
//   }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     java.util.TimeZone var19 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var17, var19);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = null;
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.addDays(28, var1);
// 
//   }

  public void test349() {}
//   public void test349() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     java.util.Calendar var23 = null;
//     var21.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var26 = var2.isEmpty();
//     var2.setRangeDescription("Time");
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     long var31 = var29.getFirstMillisecond();
//     long var32 = var29.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var33 = var29.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     java.lang.Class var36 = null;
//     org.jfree.data.time.TimeSeries var37 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var36);
//     java.lang.String var38 = var37.getDescription();
//     org.jfree.data.time.Year var39 = new org.jfree.data.time.Year();
//     long var40 = var39.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var39, 1.0d);
//     java.lang.Number var43 = null;
//     org.jfree.data.time.TimeSeriesDataItem var44 = var37.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var39, var43);
//     org.jfree.data.general.SeriesChangeListener var45 = null;
//     var37.removeChangeListener(var45);
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     long var48 = var47.getMiddleMillisecond();
//     long var49 = var47.getFirstMillisecond();
//     var37.update((org.jfree.data.time.RegularTimePeriod)var47, (java.lang.Number)1L);
//     java.util.Date var52 = var47.getStart();
//     org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(var52);
//     org.jfree.data.time.Month var54 = new org.jfree.data.time.Month(var52);
//     long var55 = var54.getSerialIndex();
//     int var56 = var54.getMonth();
//     org.jfree.data.time.RegularTimePeriod var57 = var54.next();
//     org.jfree.data.time.Year var58 = var54.getYear();
//     org.jfree.data.time.Year var59 = var54.getYear();
//     org.jfree.data.time.Year var60 = var54.getYear();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var60, 10.0d, true);
// 
//   }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(21, 21);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.Year var23 = var19.getYear();
//     org.jfree.data.time.Year var24 = var19.getYear();
//     java.util.Calendar var25 = null;
//     var24.peg(var25);
// 
//   }

  public void test352() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }


    org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    var1.setNotify(true);

  }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getLastMillisecond();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var21);
//     boolean var24 = var22.equals((java.lang.Object)'#');
//     var22.setDomainDescription("");
//     int var27 = var18.compareTo((java.lang.Object)var22);
//     org.jfree.data.time.TimeSeries var28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var27);
//     java.lang.Comparable var29 = var28.getKey();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1388649599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + 1+ "'", var29.equals(1));
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     org.jfree.data.time.Year var8 = new org.jfree.data.time.Year();
//     long var9 = var8.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var8, 1.0d);
//     java.lang.Number var12 = null;
//     org.jfree.data.time.TimeSeriesDataItem var13 = var6.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var8, var12);
//     org.jfree.data.general.SeriesChangeListener var14 = null;
//     var6.removeChangeListener(var14);
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     long var18 = var16.getFirstMillisecond();
//     var6.update((org.jfree.data.time.RegularTimePeriod)var16, (java.lang.Number)1L);
//     java.util.Date var21 = var16.getEnd();
//     java.lang.Number var22 = var2.getValue((org.jfree.data.time.RegularTimePeriod)var16);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var24 = var2.getTimePeriod(0);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     int var10 = var4.getYear();
//     java.util.Calendar var11 = null;
//     var4.peg(var11);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getMiddleMillisecond(var2);
//     java.util.Date var4 = var1.getStart();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     org.jfree.data.time.Month var6 = new org.jfree.data.time.Month(var4);
//     org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(var4);
//     org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(var4);
//     java.util.TimeZone var9 = null;
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year(var4, var9);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    java.lang.Class var6 = var5.getTimePeriodClass();
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("org.jfree.data.time.TimePeriodFormatException: ", var6);
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    java.lang.Class var10 = var9.getTimePeriodClass();
    java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("Sun Dec 21 00:23:19 PST 2014", var6, var10);
    java.lang.Object var12 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("9-January-1900", var10);
    java.io.InputStream var13 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("28-February-1900", var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var13);

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var3 = var2.getYYYY();
//     java.lang.String var4 = var2.toString();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var6);
//     java.util.List var8 = var7.getItems();
//     var7.setMaximumItemAge(1388563200000L);
//     java.lang.Class var11 = var7.getTimePeriodClass();
//     java.lang.Class var12 = var7.getTimePeriodClass();
//     java.lang.Class var13 = var7.getTimePeriodClass();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var15);
//     java.lang.String var17 = var16.getDescription();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 1.0d);
//     java.lang.Number var22 = null;
//     org.jfree.data.time.TimeSeriesDataItem var23 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var18, var22);
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var16.removeChangeListener(var24);
//     org.jfree.data.time.FixedMillisecond var27 = new org.jfree.data.time.FixedMillisecond(0L);
//     var16.delete((org.jfree.data.time.RegularTimePeriod)var27);
//     java.util.Calendar var29 = null;
//     var27.peg(var29);
//     org.jfree.data.time.TimeSeriesDataItem var31 = var7.getDataItem((org.jfree.data.time.RegularTimePeriod)var27);
//     boolean var32 = var2.equals((java.lang.Object)var27);
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var37 = var34.getEndOfCurrentMonth(var36);
//     org.jfree.data.time.SerialDate var40 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var42 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var43 = var40.getEndOfCurrentMonth(var42);
//     org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.addMonths(1, var43);
//     org.jfree.data.time.SerialDate var46 = var43.getPreviousDayOfWeek(1);
//     org.jfree.data.time.SerialDate var47 = var36.getEndOfCurrentMonth(var46);
//     boolean var48 = var2.equals((java.lang.Object)var47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var49 = org.jfree.data.time.SerialDate.addDays((-945), var47);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "12-January-1900"+ "'", var4.equals("12-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == false);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString((-452));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test360() {}
//   public void test360() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     int var12 = var11.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var14 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, 100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Month var15 = new org.jfree.data.time.Month((-19), var11);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
// 
//   }

  public void test361() {}
//   public void test361() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.String var6 = var2.getRangeDescription();
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     var2.setDescription("Wed Dec 31 15:59:59 PST 1969");
//     java.lang.Class var11 = null;
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var11);
//     java.lang.String var13 = var12.getDescription();
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var14, 1.0d);
//     java.lang.Number var18 = null;
//     org.jfree.data.time.TimeSeriesDataItem var19 = var12.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var14, var18);
//     org.jfree.data.general.SeriesChangeListener var20 = null;
//     var12.removeChangeListener(var20);
//     org.jfree.data.time.Year var22 = new org.jfree.data.time.Year();
//     long var23 = var22.getMiddleMillisecond();
//     long var24 = var22.getFirstMillisecond();
//     var12.update((org.jfree.data.time.RegularTimePeriod)var22, (java.lang.Number)1L);
//     java.util.Date var27 = var22.getStart();
//     org.jfree.data.time.Day var28 = new org.jfree.data.time.Day(var27);
//     org.jfree.data.time.RegularTimePeriod var29 = var28.previous();
//     long var30 = var28.getLastMillisecond();
//     org.jfree.data.time.RegularTimePeriod var31 = var28.next();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var28, 0.0d);
// 
//   }

  public void test362() {}
//   public void test362() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     org.jfree.data.general.SeriesChangeEvent var20 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)var19);
//     java.lang.String var21 = var20.toString();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var21 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=January 2014]"+ "'", var21.equals("org.jfree.data.general.SeriesChangeEvent[source=January 2014]"));
// 
//   }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.String var6 = var2.getRangeDescription();
    var2.clear();
    org.jfree.data.time.TimeSeries var10 = var2.createCopy(10, 31);
    org.jfree.data.time.RegularTimePeriod var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.delete(var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test364() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(1900);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test365() {}
//   public void test365() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var4 = var3.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getMiddleMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var3.next();
//     int var8 = var0.compareTo((java.lang.Object)var3);
//     java.util.Calendar var9 = null;
//     long var10 = var0.getLastMillisecond(var9);
// 
//   }

  public void test366() {}
//   public void test366() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var4.toString();
//     java.lang.String var11 = var4.toString();
//     long var12 = var4.getLastMillisecond();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "2014"+ "'", var10.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "2014"+ "'", var11.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1420099199999L);
// 
//   }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.jfree.data.time.Month var0 = new org.jfree.data.time.Month();
//     java.util.Calendar var1 = null;
//     long var2 = var0.getFirstMillisecond(var1);
// 
//   }

  public void test368() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    org.jfree.data.time.TimeSeries var13 = var8.createCopy(10, 2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var13.getTimePeriod(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test369() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString(0, true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     boolean var9 = var1.equals((java.lang.Object)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var12 = var11.getYYYY();
//     boolean var13 = var1.isAfter((org.jfree.data.time.SerialDate)var11);
//     int var14 = var1.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(2014);
//     int var19 = var16.compare(var18);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var25 = var22.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var25);
//     boolean var28 = var1.isInRange((org.jfree.data.time.SerialDate)var16, var26, 31);
//     org.jfree.data.time.SerialDate var29 = null;
//     boolean var30 = var16.isOn(var29);
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getLastMillisecond();
//     long var20 = var18.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var18);
//     java.util.Calendar var22 = null;
//     var18.peg(var22);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     var2.setMaximumItemAge(0L);
//     var2.removeAgedItems(true);
//     var2.setDescription("");
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     long var11 = var10.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var10, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var14 = var13.getPeriod();
//     java.lang.Object var15 = var13.clone();
//     org.jfree.data.time.RegularTimePeriod var16 = var13.getPeriod();
//     var2.add(var13);
// 
//   }

  public void test373() {}
//   public void test373() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     int var10 = var4.getYear();
//     long var11 = var4.getLastMillisecond();
//     org.jfree.data.time.TimeSeries var12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var4);
//     org.jfree.data.time.SpreadsheetDate var14 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var19 = var16.getEndOfCurrentMonth(var18);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var18);
//     org.jfree.data.time.RegularTimePeriod var21 = var20.next();
//     boolean var22 = var14.equals((java.lang.Object)var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var12.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(byte)100);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1420099199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == false);
// 
//   }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    boolean var1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth((-460), (-2001));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test376() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var9 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var10 = var7.getEndOfCurrentMonth(var9);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.addMonths(1, var10);
    org.jfree.data.time.SerialDate var13 = var10.getPreviousDayOfWeek(1);
    org.jfree.data.time.SerialDate var14 = var3.getEndOfCurrentMonth(var13);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var16 = var13.getNearestDayOfWeek(31);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test377() {}
//   public void test377() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Comparable var3 = var2.getKey();
//     var2.setMaximumItemAge(0L);
//     var2.removeAgedItems(true);
//     var2.setDescription("");
//     java.beans.PropertyChangeListener var10 = null;
//     var2.removePropertyChangeListener(var10);
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var13);
//     boolean var16 = var14.equals((java.lang.Object)'#');
//     var14.setDomainDescription("");
//     java.lang.Class var19 = var14.getTimePeriodClass();
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var21);
//     java.lang.String var23 = var22.getDescription();
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     long var25 = var24.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var24, 1.0d);
//     java.lang.Number var28 = null;
//     org.jfree.data.time.TimeSeriesDataItem var29 = var22.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var24, var28);
//     org.jfree.data.general.SeriesChangeListener var30 = null;
//     var22.removeChangeListener(var30);
//     org.jfree.data.time.FixedMillisecond var33 = new org.jfree.data.time.FixedMillisecond(0L);
//     var22.delete((org.jfree.data.time.RegularTimePeriod)var33);
//     java.util.Calendar var35 = null;
//     var33.peg(var35);
//     org.jfree.data.time.TimeSeriesDataItem var37 = var14.getDataItem((org.jfree.data.time.RegularTimePeriod)var33);
//     boolean var38 = var14.getNotify();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var40);
//     java.lang.String var42 = var41.getDescription();
//     org.jfree.data.time.Year var43 = new org.jfree.data.time.Year();
//     long var44 = var43.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var43, 1.0d);
//     java.lang.Number var47 = null;
//     org.jfree.data.time.TimeSeriesDataItem var48 = var41.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var43, var47);
//     org.jfree.data.general.SeriesChangeListener var49 = null;
//     var41.removeChangeListener(var49);
//     org.jfree.data.time.Year var51 = new org.jfree.data.time.Year();
//     long var52 = var51.getMiddleMillisecond();
//     long var53 = var51.getFirstMillisecond();
//     var41.update((org.jfree.data.time.RegularTimePeriod)var51, (java.lang.Number)1L);
//     java.util.Date var56 = var51.getStart();
//     org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.createInstance(var56);
//     org.jfree.data.time.Month var58 = new org.jfree.data.time.Month(var56);
//     long var59 = var58.getSerialIndex();
//     int var60 = var58.getMonth();
//     int var61 = var58.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var62 = var58.previous();
//     int var63 = var58.getMonth();
//     long var64 = var58.getFirstMillisecond();
//     var14.setKey((java.lang.Comparable)var58);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update((org.jfree.data.time.RegularTimePeriod)var58, (java.lang.Number)100.0d);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + (byte)1+ "'", var3.equals((byte)1));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var44 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var60 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == 1388563200000L);
// 
//   }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    long var2 = var1.getLastMillisecond();
    java.util.Calendar var3 = null;
    long var4 = var1.getMiddleMillisecond(var3);
    java.util.Calendar var5 = null;
    var1.peg(var5);
    java.util.Calendar var7 = null;
    long var8 = var1.getMiddleMillisecond(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);

  }

  public void test379() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
    java.lang.String var7 = var6.getDescription();
    var6.removeAgedItems(false);
    var6.fireSeriesChanged();
    int var11 = var1.compareTo((java.lang.Object)var6);
    org.jfree.data.general.SeriesChangeListener var12 = null;
    var6.addChangeListener(var12);
    java.lang.String var14 = var6.getRangeDescription();
    int var15 = var6.getMaximumItemCount();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + "Value"+ "'", var14.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 2147483647);

  }

  public void test380() {}
//   public void test380() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }
// 
// 
//     java.util.Date var0 = null;
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(var0);
//     
//     // Checks the contract:  var1.equals(var1)
//     assertTrue("Contract failed: var1.equals(var1)", var1.equals(var1));
// 
//   }

  public void test381() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var12 = null;
    long var13 = var11.getLastMillisecond(var12);
    org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
    java.util.Calendar var16 = null;
    long var17 = var11.getMiddleMillisecond(var16);
    java.util.Date var18 = var11.getStart();
    long var19 = var11.getFirstMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0L);

  }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var18.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 0.0d);
//     java.lang.String var23 = var18.toString();
//     java.util.Calendar var24 = null;
//     long var25 = var18.getFirstMillisecond(var24);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.monthCodeToString(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "October"+ "'", var1.equals("October"));

  }

  public void test384() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }


    int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 4);

  }

  public void test385() {}
//   public void test385() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014);
//     int var4 = var1.compare(var3);
//     java.util.Date var5 = var1.toDate();
//     java.lang.Object var6 = null;
//     int var7 = var1.compareTo(var6);
// 
//   }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var17);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var21);
//     java.lang.String var23 = var22.getDescription();
//     java.lang.Object var24 = var22.clone();
//     java.lang.Class var26 = null;
//     org.jfree.data.time.TimeSeries var27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var26);
//     java.lang.String var28 = var27.getDescription();
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var29, 1.0d);
//     java.lang.Number var33 = null;
//     org.jfree.data.time.TimeSeriesDataItem var34 = var27.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var29, var33);
//     org.jfree.data.general.SeriesChangeListener var35 = null;
//     var27.removeChangeListener(var35);
//     org.jfree.data.time.Year var37 = new org.jfree.data.time.Year();
//     long var38 = var37.getMiddleMillisecond();
//     long var39 = var37.getFirstMillisecond();
//     var27.update((org.jfree.data.time.RegularTimePeriod)var37, (java.lang.Number)1L);
//     java.lang.Class var43 = null;
//     org.jfree.data.time.TimeSeries var44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var43);
//     java.lang.String var45 = var44.getDescription();
//     org.jfree.data.time.Year var46 = new org.jfree.data.time.Year();
//     long var47 = var46.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var49 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var46, 1.0d);
//     java.lang.Number var50 = null;
//     org.jfree.data.time.TimeSeriesDataItem var51 = var44.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var46, var50);
//     org.jfree.data.general.SeriesChangeListener var52 = null;
//     var44.removeChangeListener(var52);
//     org.jfree.data.time.FixedMillisecond var55 = new org.jfree.data.time.FixedMillisecond(0L);
//     var44.delete((org.jfree.data.time.RegularTimePeriod)var55);
//     org.jfree.data.time.TimeSeries var57 = var22.createCopy((org.jfree.data.time.RegularTimePeriod)var37, (org.jfree.data.time.RegularTimePeriod)var55);
//     java.util.List var58 = var22.getItems();
//     boolean var59 = var19.equals((java.lang.Object)var58);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.util.Collection var60 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection)var58);
//       fail("Expected exception of type java.lang.CloneNotSupportedException");
//     } catch (java.lang.CloneNotSupportedException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    int var2 = var1.getYYYY();
    java.lang.String var3 = var1.toString();
    java.util.Date var4 = var1.toDate();
    org.jfree.data.time.SpreadsheetDate var6 = new org.jfree.data.time.SpreadsheetDate(13);
    int var7 = var6.toSerial();
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = var11.getEndOfCurrentMonth(var13);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.addMonths(1, var14);
    java.lang.Class var16 = null;
    org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var15, var16);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.addDays(21, var15);
    boolean var20 = var1.isInRange((org.jfree.data.time.SerialDate)var6, var15, 12);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = var15.getPreviousDayOfWeek(9);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "12-January-1900"+ "'", var3.equals("12-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString(100);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.time.Year var10 = new org.jfree.data.time.Year();
//     int var11 = var10.getYear();
//     org.jfree.data.time.TimeSeriesDataItem var13 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var10, 100.0d);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     long var16 = var14.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.Number var19 = var2.getValue(2014);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
// 
//   }

  public void test390() {}
//   public void test390() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var18.getMonth();
//     org.jfree.data.time.RegularTimePeriod var21 = var18.next();
//     org.jfree.data.time.RegularTimePeriod var22 = var18.next();
//     java.util.Calendar var23 = null;
//     var18.peg(var23);
// 
//   }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance((-945), 6, (-1));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     java.lang.String var7 = var5.toString();
//     long var8 = var5.getFirstMillisecond();
//     java.lang.String var9 = var5.toString();
//     java.util.Calendar var10 = null;
//     var5.peg(var10);
// 
//   }

  public void test393() {}
//   public void test393() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }
// 
// 
//     org.jfree.data.time.Day var0 = new org.jfree.data.time.Day();
//     java.lang.String var1 = var0.toString();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getFirstMillisecond(var2);
// 
//   }

  public void test394() {}
//   public void test394() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var18.getMonth();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 0.0d);
//     int var23 = var18.getDayOfMonth();
//     java.util.Calendar var24 = null;
//     long var25 = var18.getFirstMillisecond(var24);
// 
//   }

  public void test395() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(1900, 1, 28);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(1419150198886L);

  }

  public void test397() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(6, (-945), (-2001));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.jfree.data.general.SeriesChangeEvent var1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)9223372036854775807L);
    java.lang.String var2 = var1.toString();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]"+ "'", var2.equals("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]"));

  }

  public void test399() {}
//   public void test399() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }
// 
// 
//     java.util.Date var0 = null;
//     java.util.TimeZone var1 = null;
//     org.jfree.data.time.Year var2 = new org.jfree.data.time.Year(var0, var1);
// 
//   }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    int var1 = org.jfree.data.time.SerialDate.leapYearCount(1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-459));

  }

  public void test401() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate(9, 520764324, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    java.lang.Class var7 = var2.getTimePeriodClass();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(13, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test403() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 2014);

  }

  public void test404() {}
//   public void test404() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     java.util.Calendar var23 = null;
//     var21.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var26 = var2.isEmpty();
//     var2.setRangeDescription("Time");
//     org.jfree.data.time.Year var29 = new org.jfree.data.time.Year();
//     long var30 = var29.getMiddleMillisecond();
//     long var31 = var29.getFirstMillisecond();
//     long var32 = var29.getSerialIndex();
//     org.jfree.data.time.RegularTimePeriod var33 = var29.next();
//     org.jfree.data.time.TimeSeriesDataItem var34 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var29);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var35 = var2.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == true);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
// 
//   }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     java.util.Calendar var23 = null;
//     var21.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     boolean var26 = var2.isEmpty();
//     var2.setRangeDescription("Time");
//     var2.removeAgedItems(1388606399999L, false);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    int var1 = org.jfree.data.time.SerialDate.stringToMonthCode("28-February-1900");
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == (-1));

  }

  public void test407() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }


    int var2 = org.jfree.data.time.SerialDate.lastDayOfMonth(10, 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 31);

  }

  public void test408() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getFirstMillisecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);

  }

  public void test409() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(100);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    var9.setDescription("Value");
    org.jfree.data.time.SerialDate var21 = var2.getEndOfCurrentMonth(var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.addMonths((-459), var21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.Year var23 = var19.getYear();
//     org.jfree.data.time.Year var24 = var19.getYear();
//     long var25 = var24.getSerialIndex();
//     java.util.Calendar var26 = null;
//     long var27 = var24.getFirstMillisecond(var26);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var2.removeChangeListener(var12);
//     var2.removeAgedItems(false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeriesDataItem var17 = var2.getDataItem((-2001));
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
// 
//   }

  public void test412() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear((-452));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(0L);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var13);
//     java.lang.String var15 = var2.getDescription();
//     java.lang.String var16 = var2.getDomainDescription();
//     org.jfree.data.time.FixedMillisecond var18 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var19 = var18.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var18);
//     var2.fireSeriesChanged();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.delete(0, 12);
//       fail("Expected exception of type java.lang.IndexOutOfBoundsException");
//     } catch (java.lang.IndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "Time"+ "'", var16.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var20);
// 
//   }

  public void test414() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(9, 1900, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var2 = new org.jfree.data.time.Month((-2001), 6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     int var1 = var0.getYear();
//     java.util.Calendar var2 = null;
//     long var3 = var0.getMiddleMillisecond(var2);
// 
//   }

  public void test417() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    int var2 = var1.getYYYY();
    java.lang.String var3 = var1.toString();
    java.util.Date var4 = var1.toDate();
    int var5 = var1.getYYYY();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var7 = var1.getNearestDayOfWeek((-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + "12-January-1900"+ "'", var3.equals("12-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 1900);

  }

  public void test419() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.weekInMonthToString(12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code."+ "'", var1.equals("SerialDate.weekInMonthToString(): invalid code."));

  }

  public void test420() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(4);

  }

  public void test421() {}
//   public void test421() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     int var22 = var19.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var23 = var19.previous();
//     java.util.Calendar var24 = null;
//     long var25 = var19.getFirstMillisecond(var24);
// 
//   }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getLastMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.Number var24 = null;
//     org.jfree.data.time.TimeSeriesDataItem var25 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, var24);
//     org.jfree.data.general.SeriesChangeListener var26 = null;
//     var18.removeChangeListener(var26);
//     org.jfree.data.time.Year var28 = new org.jfree.data.time.Year();
//     long var29 = var28.getMiddleMillisecond();
//     long var30 = var28.getFirstMillisecond();
//     var18.update((org.jfree.data.time.RegularTimePeriod)var28, (java.lang.Number)1L);
//     java.util.Date var33 = var28.getStart();
//     org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.createInstance(var33);
//     org.jfree.data.time.Month var35 = new org.jfree.data.time.Month(var33);
//     long var36 = var35.getSerialIndex();
//     int var37 = var35.getMonth();
//     org.jfree.data.time.RegularTimePeriod var38 = var35.next();
//     java.lang.Object var39 = null;
//     int var40 = var35.compareTo(var39);
//     org.jfree.data.time.Year var41 = var35.getYear();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)100);
// 
//   }

  public void test423() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
    int var3 = var2.getYYYY();
    java.lang.String var4 = var2.toString();
    java.util.Date var5 = var2.toDate();
    int var6 = var2.getYYYY();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + "12-January-1900"+ "'", var4.equals("12-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 1900);

  }

  public void test424() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    java.lang.Class var4 = var2.getTimePeriodClass();
    java.util.Collection var5 = var2.getTimePeriods();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.delete(2147483647, (-452));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014);
//     int var4 = var1.compare(var3);
//     java.util.Date var5 = var1.toDate();
//     int var6 = var1.getMonth();
//     org.jfree.data.time.SerialDate var7 = null;
//     org.jfree.data.time.SpreadsheetDate var9 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var14 = var11.getEndOfCurrentMonth(var13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var13);
//     org.jfree.data.time.RegularTimePeriod var16 = var15.next();
//     boolean var17 = var9.equals((java.lang.Object)var15);
//     org.jfree.data.time.SpreadsheetDate var19 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var20 = var19.getYYYY();
//     boolean var21 = var9.isAfter((org.jfree.data.time.SerialDate)var19);
//     org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.createInstance(10);
//     java.lang.String var24 = var23.toString();
//     boolean var25 = var9.equals((java.lang.Object)var23);
//     boolean var26 = var1.isInRange(var7, (org.jfree.data.time.SerialDate)var9);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var7 = var4.getFollowingDayOfWeek(1);
//     org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var13 = var10.getEndOfCurrentMonth(var12);
//     org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.addMonths(1, var13);
//     org.jfree.data.time.Day var15 = new org.jfree.data.time.Day(var13);
//     org.jfree.data.time.SerialDate var16 = var7.getEndOfCurrentMonth(var13);
//     var7.setDescription("Value");
//     org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.addYears(13, var7);
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var19);
//     long var21 = var20.getFirstMillisecond();
//     int var22 = var20.getMonth();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == (-1797609600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
// 
//   }

  public void test427() {}
//   public void test427() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     java.util.Calendar var20 = null;
//     long var21 = var18.getLastMillisecond(var20);
// 
//   }

  public void test428() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var6);
    java.lang.Class var8 = null;
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(100, var7);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    org.jfree.data.time.TimeSeries var13 = var8.createCopy(10, 2014);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.RegularTimePeriod var15 = var8.getTimePeriod((-2001));
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getLastMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.Number var24 = null;
//     org.jfree.data.time.TimeSeriesDataItem var25 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, var24);
//     int var26 = var20.getYear();
//     java.util.Date var27 = var20.getStart();
//     long var28 = var20.getSerialIndex();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var32);
//     java.lang.String var34 = var33.getDescription();
//     var33.removeAgedItems(false);
//     java.lang.Class var38 = null;
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var38);
//     java.lang.String var40 = var39.getDescription();
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     long var42 = var41.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, 1.0d);
//     java.lang.Number var45 = null;
//     org.jfree.data.time.TimeSeriesDataItem var46 = var39.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var41, var45);
//     org.jfree.data.general.SeriesChangeListener var47 = null;
//     var39.removeChangeListener(var47);
//     org.jfree.data.general.SeriesChangeListener var49 = null;
//     var39.removeChangeListener(var49);
//     java.util.Collection var51 = var33.getTimePeriodsUniqueToOtherSeries(var39);
//     org.jfree.data.time.TimeSeries var52 = var2.addAndOrUpdate(var39);
// 
//   }

  public void test431() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var1 = org.jfree.data.time.SerialDate.weekdayCodeToString(10);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }

  }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     java.lang.String var20 = var18.toString();
//     int var21 = var18.getYear();
//     int var22 = var18.getDayOfMonth();
//     long var23 = var18.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1388606399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var20 + "' != '" + "1-January-2014"+ "'", var20.equals("1-January-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 41640L);
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var12 = null;
    long var13 = var11.getLastMillisecond(var12);
    org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
    long var16 = var2.getMaximumItemAge();
    var2.clear();
    boolean var19 = var2.equals((java.lang.Object)1419150205672L);
    var2.clear();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 9223372036854775807L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test434() {}
//   public void test434() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     java.lang.String var1 = var0.toString();
//     org.jfree.data.time.FixedMillisecond var3 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var4 = var3.getLastMillisecond();
//     java.util.Calendar var5 = null;
//     long var6 = var3.getMiddleMillisecond(var5);
//     org.jfree.data.time.RegularTimePeriod var7 = var3.next();
//     int var8 = var0.compareTo((java.lang.Object)var3);
//     java.util.Calendar var9 = null;
//     long var10 = var3.getFirstMillisecond(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var1 + "' != '" + "2014"+ "'", var1.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0L);
// 
//   }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var2 = org.jfree.data.time.SerialDate.monthCodeToString((-2001), true);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test436() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    java.lang.Class var5 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
    java.lang.String var7 = var6.getDescription();
    var6.removeAgedItems(false);
    var6.fireSeriesChanged();
    int var11 = var1.compareTo((java.lang.Object)var6);
    var6.clear();
    java.lang.String var13 = var6.getDomainDescription();
    java.lang.Object var14 = null;
    boolean var15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var13, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "Time"+ "'", var13.equals("Time"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     java.lang.Class var2 = null;
//     org.jfree.data.time.TimeSeries var3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var2);
//     java.lang.String var4 = var3.getDescription();
//     org.jfree.data.time.Year var5 = new org.jfree.data.time.Year();
//     long var6 = var5.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var5, 1.0d);
//     java.lang.Number var9 = null;
//     org.jfree.data.time.TimeSeriesDataItem var10 = var3.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var5, var9);
//     org.jfree.data.general.SeriesChangeListener var11 = null;
//     var3.removeChangeListener(var11);
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     long var15 = var13.getFirstMillisecond();
//     var3.update((org.jfree.data.time.RegularTimePeriod)var13, (java.lang.Number)1L);
//     java.util.Date var18 = var13.getStart();
//     org.jfree.data.time.Day var19 = new org.jfree.data.time.Day(var18);
//     long var20 = var19.getMiddleMillisecond();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.RegularTimePeriod var23 = var19.next();
//     long var24 = var19.getLastMillisecond();
//     java.lang.Class var31 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var34 = var33.getTimePeriodClass();
//     java.lang.Object var35 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var31, var34);
//     java.net.URL var36 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=4]", var34);
//     java.net.URL var37 = org.jfree.chart.util.ObjectUtilities.getResource("1-January-2014", var34);
//     java.net.URL var38 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var34);
//     org.jfree.data.time.TimeSeries var39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var19, "org.jfree.data.general.SeriesException: Value", "Following", var34);
//     java.io.InputStream var40 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Value", var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1388606399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1388649599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var3);
//     java.lang.String var5 = var4.getDescription();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 1.0d);
//     java.lang.Number var10 = null;
//     org.jfree.data.time.TimeSeriesDataItem var11 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, var10);
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var4.removeChangeListener(var12);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     long var16 = var14.getFirstMillisecond();
//     var4.update((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)1L);
//     java.util.Date var19 = var14.getStart();
//     org.jfree.data.time.Day var20 = new org.jfree.data.time.Day(var19);
//     long var21 = var20.getMiddleMillisecond();
//     int var22 = var20.getMonth();
//     org.jfree.data.time.RegularTimePeriod var23 = var20.next();
//     org.jfree.data.time.RegularTimePeriod var24 = var20.next();
//     long var25 = var20.getLastMillisecond();
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var35 = var34.getTimePeriodClass();
//     java.lang.Object var36 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var32, var35);
//     java.net.URL var37 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=4]", var35);
//     java.net.URL var38 = org.jfree.chart.util.ObjectUtilities.getResource("1-January-2014", var35);
//     java.net.URL var39 = org.jfree.chart.util.ObjectUtilities.getResource("Time", var35);
//     org.jfree.data.time.TimeSeries var40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var20, "org.jfree.data.general.SeriesException: Value", "Following", var35);
//     java.io.InputStream var41 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("ERROR : Relative To String", var35);
//     java.net.URL var42 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("9-January-1900", var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1388606399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 1388649599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var39);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
// 
//   }

  public void test439() {}
//   public void test439() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     java.lang.String var11 = var8.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var13);
//     java.util.List var15 = var14.getItems();
//     var14.setMaximumItemAge(1388563200000L);
//     java.lang.Class var18 = var14.getTimePeriodClass();
//     int var19 = var14.getItemCount();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     long var24 = var20.getMiddleMillisecond();
//     long var25 = var20.getFirstMillisecond();
//     int var26 = var14.getIndex((org.jfree.data.time.RegularTimePeriod)var20);
//     org.jfree.data.general.SeriesChangeEvent var28 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object)2147483647);
//     boolean var29 = var20.equals((java.lang.Object)2147483647);
//     var8.add((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)(byte)100);
// 
//   }

  public void test440() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014);
    int var4 = var1.compare(var3);
    java.util.Date var5 = var1.toDate();
    java.lang.String var6 = var1.getDescription();
    int var7 = var1.toSerial();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-2001));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 13);

  }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.lang.String var3 = var2.getDescription();
    org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
    long var6 = var5.getLastMillisecond();
    java.util.Calendar var7 = null;
    long var8 = var5.getMiddleMillisecond(var7);
    org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
    org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var12 = null;
    long var13 = var11.getLastMillisecond(var12);
    org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
    var2.setDescription("");
    int var18 = var2.getMaximumItemCount();
    org.jfree.data.time.FixedMillisecond var20 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var21 = null;
    long var22 = var20.getMiddleMillisecond(var21);
    java.util.Date var23 = var20.getStart();
    org.jfree.data.time.TimeSeriesDataItem var24 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var20);
    java.util.Calendar var25 = null;
    var20.peg(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 2147483647);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test442() {}
//   public void test442() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     java.lang.String var12 = var2.getDomainDescription();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var14);
//     boolean var17 = var15.equals((java.lang.Object)'#');
//     var15.setDomainDescription("");
//     java.lang.Class var20 = var15.getTimePeriodClass();
//     java.lang.Class var22 = null;
//     org.jfree.data.time.TimeSeries var23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var22);
//     java.lang.String var24 = var23.getDescription();
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     long var26 = var25.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var25, 1.0d);
//     java.lang.Number var29 = null;
//     org.jfree.data.time.TimeSeriesDataItem var30 = var23.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var25, var29);
//     org.jfree.data.general.SeriesChangeListener var31 = null;
//     var23.removeChangeListener(var31);
//     org.jfree.data.time.FixedMillisecond var34 = new org.jfree.data.time.FixedMillisecond(0L);
//     var23.delete((org.jfree.data.time.RegularTimePeriod)var34);
//     java.util.Calendar var36 = null;
//     var34.peg(var36);
//     org.jfree.data.time.TimeSeriesDataItem var38 = var15.getDataItem((org.jfree.data.time.RegularTimePeriod)var34);
//     boolean var39 = var15.getNotify();
//     org.jfree.data.time.FixedMillisecond var40 = new org.jfree.data.time.FixedMillisecond();
//     java.lang.Class var42 = null;
//     org.jfree.data.time.TimeSeries var43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var42);
//     java.lang.String var44 = var43.getDescription();
//     org.jfree.data.time.Year var45 = new org.jfree.data.time.Year();
//     long var46 = var45.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var45, 1.0d);
//     java.lang.Number var49 = null;
//     org.jfree.data.time.TimeSeriesDataItem var50 = var43.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, var49);
//     org.jfree.data.general.SeriesChangeListener var51 = null;
//     var43.removeChangeListener(var51);
//     org.jfree.data.time.FixedMillisecond var54 = new org.jfree.data.time.FixedMillisecond(0L);
//     var43.delete((org.jfree.data.time.RegularTimePeriod)var54);
//     java.lang.String var56 = var43.getDescription();
//     java.lang.String var57 = var43.getDomainDescription();
//     org.jfree.data.time.Year var58 = new org.jfree.data.time.Year();
//     long var59 = var58.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var61 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var58, 1.0d);
//     long var62 = var58.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var64 = var43.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var58, (java.lang.Number)13);
//     org.jfree.data.time.TimeSeries var65 = var15.createCopy((org.jfree.data.time.RegularTimePeriod)var40, (org.jfree.data.time.RegularTimePeriod)var58);
//     java.lang.Number var66 = null;
//     var2.add((org.jfree.data.time.RegularTimePeriod)var40, var66);
// 
//   }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.Day var18 = new org.jfree.data.time.Day(var17);
//     long var19 = var18.getMiddleMillisecond();
//     int var20 = var18.getMonth();
//     int var21 = var18.getMonth();
//     java.util.Calendar var22 = null;
//     var18.peg(var22);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var3 = new org.jfree.data.time.Day(13, 28, (-2001));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test445() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    org.jfree.data.general.SeriesChangeListener var3 = null;
    var2.addChangeListener(var3);
    var2.removeAgedItems(false);
    org.jfree.data.time.FixedMillisecond var8 = new org.jfree.data.time.FixedMillisecond(9223372036854775807L);
    int var9 = var2.getIndex((org.jfree.data.time.RegularTimePeriod)var8);
    java.util.Date var10 = var8.getTime();
    java.util.TimeZone var11 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var12 = new org.jfree.data.time.Day(var10, var11);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == (-1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test446() {}
//   public void test446() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var8 = var7.getTimePeriodClass();
//     java.lang.Object var9 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var5, var8);
//     java.io.InputStream var10 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", var8);
//     boolean var11 = var2.equals((java.lang.Object)"Jan");
//     org.jfree.data.time.FixedMillisecond var13 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var14 = var13.getFirstMillisecond();
//     org.jfree.data.time.RegularTimePeriod var15 = var13.previous();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var13, (-1.0d));
// 
//   }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(21, 21, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test448() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var6);
    org.jfree.data.time.RegularTimePeriod var9 = var8.next();
    boolean var10 = var2.equals((java.lang.Object)var8);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var13 = var12.toString();
    boolean var14 = var2.isOnOrAfter(var12);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var21 = var18.getEndOfCurrentMonth(var20);
    org.jfree.data.time.SerialDate var23 = var20.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var29 = var26.getEndOfCurrentMonth(var28);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(1, var29);
    org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29);
    org.jfree.data.time.SerialDate var32 = var23.getEndOfCurrentMonth(var29);
    var23.setDescription("Value");
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addYears(13, var23);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addDays((-460), var35);
    boolean var37 = var2.isAfter(var36);
    int var38 = var2.toSerial();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "9-January-1900"+ "'", var13.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 13);

  }

  public void test449() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }


    java.lang.Class var4 = null;
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    java.lang.Class var7 = var6.getTimePeriodClass();
    java.lang.Object var8 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var4, var7);
    java.net.URL var9 = org.jfree.chart.util.ObjectUtilities.getResource("org.jfree.data.general.SeriesChangeEvent[source=4]", var7);
    java.net.URL var10 = org.jfree.chart.util.ObjectUtilities.getResource("2014", var7);
    java.net.URL var11 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("Time", var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var11);

  }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(2014);
    int var5 = var2.compare(var4);
    java.util.Date var6 = var2.toDate();
    java.lang.String var7 = var2.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var8 = org.jfree.data.time.SerialDate.addDays(2147483647, (org.jfree.data.time.SerialDate)var2);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == (-2001));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);

  }

  public void test451() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
    org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
    org.jfree.data.time.RegularTimePeriod var8 = var7.next();
    boolean var9 = var1.equals((java.lang.Object)var7);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var12 = var11.toString();
    boolean var13 = var1.isOnOrAfter(var11);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var20 = var17.getEndOfCurrentMonth(var19);
    org.jfree.data.time.SerialDate var22 = var19.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var27 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var28 = var25.getEndOfCurrentMonth(var27);
    org.jfree.data.time.SerialDate var29 = org.jfree.data.time.SerialDate.addMonths(1, var28);
    org.jfree.data.time.Day var30 = new org.jfree.data.time.Day(var28);
    org.jfree.data.time.SerialDate var31 = var22.getEndOfCurrentMonth(var28);
    var22.setDescription("Value");
    org.jfree.data.time.SerialDate var34 = org.jfree.data.time.SerialDate.addYears(13, var22);
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addDays((-460), var34);
    boolean var36 = var1.isAfter(var35);
    java.lang.String var37 = var1.getDescription();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var39 = var1.getPreviousDayOfWeek(21);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + "9-January-1900"+ "'", var12.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var37);

  }

  public void test452() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Number var8 = var2.getValue(21);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);

  }

  public void test453() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    boolean var4 = var2.equals((java.lang.Object)'#');
    var2.setDomainDescription("");
    java.lang.Class var7 = var2.getTimePeriodClass();
    java.util.Collection var8 = var2.getTimePeriods();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test454() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object)var6);
      fail("Expected exception of type java.lang.CloneNotSupportedException");
    } catch (java.lang.CloneNotSupportedException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test455() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    java.util.List var3 = var2.getItems();
    var2.setMaximumItemAge(1388563200000L);
    java.lang.String var6 = var2.getRangeDescription();
    var2.clear();
    org.jfree.data.time.TimeSeries var10 = var2.createCopy(10, 31);
    org.jfree.data.general.SeriesChangeListener var11 = null;
    var10.removeChangeListener(var11);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var10.delete(2147483647, (-460));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + "Value"+ "'", var6.equals("Value"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test456() {}
//   public void test456() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     int var18 = var12.getYear();
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var12);
//     java.lang.Class var21 = null;
//     org.jfree.data.time.TimeSeries var22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var21);
//     java.lang.String var23 = var22.getDescription();
//     org.jfree.data.time.FixedMillisecond var25 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var26 = var25.getLastMillisecond();
//     java.util.Calendar var27 = null;
//     long var28 = var25.getMiddleMillisecond(var27);
//     org.jfree.data.time.TimeSeriesDataItem var29 = var22.getDataItem((org.jfree.data.time.RegularTimePeriod)var25);
//     long var30 = var25.getLastMillisecond();
//     long var31 = var25.getSerialIndex();
//     var2.add((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)(-1797609600000L));
// 
//   }

  public void test457() {}
//   public void test457() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var8 = var2.getTimePeriodClass();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var10);
//     java.lang.String var12 = var11.getDescription();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     java.lang.Number var17 = null;
//     org.jfree.data.time.TimeSeriesDataItem var18 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, var17);
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var11.removeChangeListener(var19);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(0L);
//     var11.delete((org.jfree.data.time.RegularTimePeriod)var22);
//     java.util.Calendar var24 = null;
//     var22.peg(var24);
//     org.jfree.data.time.TimeSeriesDataItem var26 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var22);
//     int var27 = var2.getItemCount();
//     long var28 = var2.getMaximumItemAge();
//     java.lang.Class var30 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var30);
//     java.lang.String var32 = var31.getDescription();
//     org.jfree.data.time.Year var33 = new org.jfree.data.time.Year();
//     long var34 = var33.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var33, 1.0d);
//     java.lang.Number var37 = null;
//     org.jfree.data.time.TimeSeriesDataItem var38 = var31.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var33, var37);
//     org.jfree.data.general.SeriesChangeListener var39 = null;
//     var31.removeChangeListener(var39);
//     org.jfree.data.time.Year var41 = new org.jfree.data.time.Year();
//     long var42 = var41.getMiddleMillisecond();
//     long var43 = var41.getFirstMillisecond();
//     var31.update((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)1L);
//     java.util.Date var46 = var41.getStart();
//     org.jfree.data.time.Day var47 = new org.jfree.data.time.Day(var46);
//     long var48 = var47.getMiddleMillisecond();
//     java.lang.String var49 = var47.toString();
//     org.jfree.data.time.TimeSeriesDataItem var51 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 0.0d);
//     org.jfree.data.time.RegularTimePeriod var52 = var51.getPeriod();
//     org.jfree.data.time.TimeSeriesDataItem var53 = var2.getDataItem(var52);
//     org.jfree.data.time.RegularTimePeriod var54 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var2.update(var54, (java.lang.Number)1.0f);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var42 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var43 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1388606399999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var49 + "' != '" + "1-January-2014"+ "'", var49.equals("1-January-2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var53);
// 
//   }

  public void test458() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var9 = null;
    org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, "ThreadContext", "hi!", var9);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var16 = var13.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var17 = org.jfree.data.time.SerialDate.addMonths(1, var16);
    org.jfree.data.time.SerialDate var18 = var6.getEndOfCurrentMonth(var16);
    java.lang.String var19 = var18.toString();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var21 = var18.getNearestDayOfWeek(0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var19 + "' != '" + "31-January-1900"+ "'", var19.equals("31-January-1900"));

  }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    java.lang.String var1 = org.jfree.data.time.SerialDate.relativeToString((-19));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var1 + "' != '" + "ERROR : Relative To String"+ "'", var1.equals("ERROR : Relative To String"));

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
    org.jfree.data.time.SerialDate var7 = org.jfree.data.time.SerialDate.addMonths(1, var6);
    java.lang.Class var8 = null;
    org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var7, var8);
    org.jfree.data.time.SerialDate var10 = org.jfree.data.time.SerialDate.addDays(21, var7);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var12 = var7.getPreviousDayOfWeek(2014);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test461() {}
//   public void test461() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     org.jfree.data.time.RegularTimePeriod var22 = var19.next();
//     org.jfree.data.time.RegularTimePeriod var23 = var19.next();
//     int var24 = var19.getMonth();
//     long var25 = var19.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == 24169L);
// 
//   }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.jfree.data.general.SeriesException var1 = new org.jfree.data.general.SeriesException("");

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var2 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var3 = null;
//     long var4 = var2.getMiddleMillisecond(var3);
//     org.jfree.data.time.RegularTimePeriod var5 = var2.next();
//     java.util.Date var6 = var2.getTime();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.lang.String var10 = var9.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 1.0d);
//     java.lang.Number var15 = null;
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var9.removeChangeListener(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     long var21 = var19.getFirstMillisecond();
//     var9.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1L);
//     java.util.Date var24 = var19.getStart();
//     org.jfree.data.time.SerialDate var25 = org.jfree.data.time.SerialDate.createInstance(var24);
//     boolean var26 = var2.equals((java.lang.Object)var25);
//     java.lang.Class var29 = null;
//     org.jfree.data.time.TimeSeries var31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var32 = var31.getTimePeriodClass();
//     java.lang.Object var33 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var29, var32);
//     java.io.InputStream var34 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", var32);
//     org.jfree.data.time.TimeSeries var35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var25, var32);
//     java.lang.String var36 = var25.toString();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.addMonths(2147483647, var25);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var36 + "' != '" + "1-January-2014"+ "'", var36.equals("1-January-2014"));
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.jfree.data.time.Year var0 = new org.jfree.data.time.Year();
//     long var1 = var0.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var0, 1.0d);
//     org.jfree.data.time.RegularTimePeriod var4 = var3.getPeriod();
//     java.lang.Object var5 = var3.clone();
//     java.lang.Number var6 = var3.getValue();
//     org.jfree.data.time.Year var7 = new org.jfree.data.time.Year();
//     long var8 = var7.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var7, 1.0d);
//     long var11 = var7.getMiddleMillisecond();
//     int var12 = var3.compareTo((java.lang.Object)var11);
//     java.lang.Number var13 = var3.getValue();
//     java.lang.Class var15 = null;
//     org.jfree.data.time.TimeSeries var16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var15);
//     java.lang.String var17 = var16.getDescription();
//     org.jfree.data.time.Year var18 = new org.jfree.data.time.Year();
//     long var19 = var18.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var18, 1.0d);
//     java.lang.Number var22 = null;
//     org.jfree.data.time.TimeSeriesDataItem var23 = var16.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var18, var22);
//     org.jfree.data.general.SeriesChangeListener var24 = null;
//     var16.removeChangeListener(var24);
//     org.jfree.data.time.Year var26 = new org.jfree.data.time.Year();
//     long var27 = var26.getMiddleMillisecond();
//     long var28 = var26.getFirstMillisecond();
//     var16.update((org.jfree.data.time.RegularTimePeriod)var26, (java.lang.Number)1L);
//     java.util.Date var31 = var26.getStart();
//     org.jfree.data.time.Day var32 = new org.jfree.data.time.Day(var31);
//     long var33 = var32.getFirstMillisecond();
//     boolean var34 = var3.equals((java.lang.Object)var33);
//     org.jfree.data.time.SpreadsheetDate var36 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var37 = var36.getYYYY();
//     java.lang.String var38 = var36.toString();
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var40);
//     java.util.List var42 = var41.getItems();
//     var41.setMaximumItemAge(1388563200000L);
//     java.lang.Class var45 = var41.getTimePeriodClass();
//     java.lang.Class var46 = var41.getTimePeriodClass();
//     java.lang.Class var47 = var41.getTimePeriodClass();
//     java.lang.Class var49 = null;
//     org.jfree.data.time.TimeSeries var50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var49);
//     java.lang.String var51 = var50.getDescription();
//     org.jfree.data.time.Year var52 = new org.jfree.data.time.Year();
//     long var53 = var52.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var55 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var52, 1.0d);
//     java.lang.Number var56 = null;
//     org.jfree.data.time.TimeSeriesDataItem var57 = var50.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var52, var56);
//     org.jfree.data.general.SeriesChangeListener var58 = null;
//     var50.removeChangeListener(var58);
//     org.jfree.data.time.FixedMillisecond var61 = new org.jfree.data.time.FixedMillisecond(0L);
//     var50.delete((org.jfree.data.time.RegularTimePeriod)var61);
//     java.util.Calendar var63 = null;
//     var61.peg(var63);
//     org.jfree.data.time.TimeSeriesDataItem var65 = var41.getDataItem((org.jfree.data.time.RegularTimePeriod)var61);
//     boolean var66 = var36.equals((java.lang.Object)var61);
//     org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var70 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var71 = var68.getEndOfCurrentMonth(var70);
//     org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var76 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var77 = var74.getEndOfCurrentMonth(var76);
//     org.jfree.data.time.SerialDate var78 = org.jfree.data.time.SerialDate.addMonths(1, var77);
//     org.jfree.data.time.SerialDate var80 = var77.getPreviousDayOfWeek(1);
//     org.jfree.data.time.SerialDate var81 = var70.getEndOfCurrentMonth(var80);
//     boolean var82 = var36.equals((java.lang.Object)var81);
//     boolean var83 = var3.equals((java.lang.Object)var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var1 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + 1.0d+ "'", var6.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var13 + "' != '" + 1.0d+ "'", var13.equals(1.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var38 + "' != '" + "12-January-1900"+ "'", var38.equals("12-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var53 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var70);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var74);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var81);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var82 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == false);
// 
//   }

  public void test465() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    java.util.Date var4 = var1.getStart();
    java.util.TimeZone var5 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Day var6 = new org.jfree.data.time.Day(var4, var5);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test466() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }


    org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var2 = var1.toString();
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.SerialDate var9 = var6.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var15 = var12.getEndOfCurrentMonth(var14);
    org.jfree.data.time.SerialDate var16 = org.jfree.data.time.SerialDate.addMonths(1, var15);
    org.jfree.data.time.Day var17 = new org.jfree.data.time.Day(var15);
    org.jfree.data.time.SerialDate var18 = var9.getEndOfCurrentMonth(var15);
    org.jfree.data.time.SerialDate var19 = var1.getEndOfCurrentMonth(var15);
    var19.setDescription("ERROR : Relative To String");
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var23 = var19.getFollowingDayOfWeek(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var2 + "' != '" + "9-January-1900"+ "'", var2.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);

  }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     org.jfree.data.time.SerialDate var1 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = var1.getEndOfCurrentMonth(var3);
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var3);
//     org.jfree.data.time.RegularTimePeriod var6 = var5.next();
//     java.lang.Class var8 = null;
//     org.jfree.data.time.TimeSeries var9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var8);
//     java.lang.String var10 = var9.getDescription();
//     org.jfree.data.time.Year var11 = new org.jfree.data.time.Year();
//     long var12 = var11.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var11, 1.0d);
//     java.lang.Number var15 = null;
//     org.jfree.data.time.TimeSeriesDataItem var16 = var9.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, var15);
//     org.jfree.data.general.SeriesChangeListener var17 = null;
//     var9.removeChangeListener(var17);
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     long var21 = var19.getFirstMillisecond();
//     var9.update((org.jfree.data.time.RegularTimePeriod)var19, (java.lang.Number)1L);
//     java.lang.Object var24 = var9.clone();
//     boolean var25 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object)var5, (java.lang.Object)var9);
//     java.lang.String var26 = var9.getDomainDescription();
//     var9.setMaximumItemAge(24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var26 + "' != '" + "Time"+ "'", var26.equals("Time"));
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(2147483647);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.jfree.data.time.TimeSeries var1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
//     java.lang.Class var3 = null;
//     org.jfree.data.time.TimeSeries var4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var3);
//     java.lang.String var5 = var4.getDescription();
//     org.jfree.data.time.Year var6 = new org.jfree.data.time.Year();
//     long var7 = var6.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var6, 1.0d);
//     java.lang.Number var10 = null;
//     org.jfree.data.time.TimeSeriesDataItem var11 = var4.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var6, var10);
//     org.jfree.data.general.SeriesChangeListener var12 = null;
//     var4.removeChangeListener(var12);
//     org.jfree.data.time.Year var14 = new org.jfree.data.time.Year();
//     long var15 = var14.getMiddleMillisecond();
//     long var16 = var14.getFirstMillisecond();
//     var4.update((org.jfree.data.time.RegularTimePeriod)var14, (java.lang.Number)1L);
//     java.util.Date var19 = var14.getStart();
//     org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(var19);
//     org.jfree.data.time.Month var21 = new org.jfree.data.time.Month(var19);
//     long var22 = var21.getSerialIndex();
//     int var23 = var21.getMonth();
//     int var24 = var21.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var25 = var21.previous();
//     long var26 = var21.getLastMillisecond();
//     long var27 = var21.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.add((org.jfree.data.time.RegularTimePeriod)var21, 100.0d, false);
//       fail("Expected exception of type org.jfree.data.general.SeriesException");
//     } catch (org.jfree.data.general.SeriesException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1391241599999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 24169L);
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SpreadsheetDate var3 = new org.jfree.data.time.SpreadsheetDate((-1), 100, 0);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(2014, 2014, 10);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
//     org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
//     java.lang.Class var7 = null;
//     org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
//     var8.setDescription("Nearest");
//     java.lang.String var11 = var8.getDescription();
//     java.lang.Class var13 = null;
//     org.jfree.data.time.TimeSeries var14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var13);
//     java.lang.String var15 = var14.getDescription();
//     org.jfree.data.time.Year var16 = new org.jfree.data.time.Year();
//     long var17 = var16.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var16, 1.0d);
//     java.lang.Number var20 = null;
//     org.jfree.data.time.TimeSeriesDataItem var21 = var14.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var16, var20);
//     org.jfree.data.general.SeriesChangeListener var22 = null;
//     var14.removeChangeListener(var22);
//     org.jfree.data.time.Year var24 = new org.jfree.data.time.Year();
//     long var25 = var24.getMiddleMillisecond();
//     long var26 = var24.getFirstMillisecond();
//     var14.update((org.jfree.data.time.RegularTimePeriod)var24, (java.lang.Number)1L);
//     java.util.Date var29 = var24.getStart();
//     org.jfree.data.time.Day var30 = new org.jfree.data.time.Day(var29);
//     org.jfree.data.time.TimeSeriesDataItem var32 = var8.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var30, (java.lang.Number)(short)(-1));
//     org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var37 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var38 = var35.getEndOfCurrentMonth(var37);
//     org.jfree.data.time.SerialDate var39 = org.jfree.data.time.SerialDate.addMonths(1, var38);
//     java.lang.Class var40 = null;
//     org.jfree.data.time.TimeSeries var41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var39, var40);
//     var41.setDescription("Nearest");
//     java.lang.String var44 = var41.getDescription();
//     java.lang.Class var46 = null;
//     org.jfree.data.time.TimeSeries var47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var46);
//     java.lang.String var48 = var47.getDescription();
//     org.jfree.data.time.Year var49 = new org.jfree.data.time.Year();
//     long var50 = var49.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var49, 1.0d);
//     java.lang.Number var53 = null;
//     org.jfree.data.time.TimeSeriesDataItem var54 = var47.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var49, var53);
//     org.jfree.data.general.SeriesChangeListener var55 = null;
//     var47.removeChangeListener(var55);
//     org.jfree.data.time.Year var57 = new org.jfree.data.time.Year();
//     long var58 = var57.getMiddleMillisecond();
//     long var59 = var57.getFirstMillisecond();
//     var47.update((org.jfree.data.time.RegularTimePeriod)var57, (java.lang.Number)1L);
//     java.util.Date var62 = var57.getStart();
//     org.jfree.data.time.Day var63 = new org.jfree.data.time.Day(var62);
//     org.jfree.data.time.TimeSeriesDataItem var65 = var41.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var63, (java.lang.Number)(short)(-1));
//     java.lang.Object var66 = null;
//     boolean var67 = var63.equals(var66);
//     var8.add((org.jfree.data.time.RegularTimePeriod)var63, (java.lang.Number)(short)1);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     boolean var4 = var2.equals((java.lang.Object)'#');
//     var2.setDomainDescription("");
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var9 = null;
//     org.jfree.data.time.TimeSeries var10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var9);
//     java.lang.String var11 = var10.getDescription();
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var12, 1.0d);
//     java.lang.Number var16 = null;
//     org.jfree.data.time.TimeSeriesDataItem var17 = var10.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var12, var16);
//     org.jfree.data.general.SeriesChangeListener var18 = null;
//     var10.removeChangeListener(var18);
//     org.jfree.data.time.FixedMillisecond var21 = new org.jfree.data.time.FixedMillisecond(0L);
//     var10.delete((org.jfree.data.time.RegularTimePeriod)var21);
//     java.util.Calendar var23 = null;
//     var21.peg(var23);
//     org.jfree.data.time.TimeSeriesDataItem var25 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var21);
//     long var26 = var21.getSerialIndex();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 0L);
// 
//   }

  public void test474() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }


    java.lang.Class var1 = null;
    org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
    org.jfree.data.general.SeriesChangeListener var3 = null;
    var2.removeChangeListener(var3);
    java.lang.Comparable var5 = var2.getKey();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setMaximumItemCount((-19));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (byte)1+ "'", var5.equals((byte)1));

  }

  public void test475() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == true);

  }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
    org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
    org.jfree.data.time.RegularTimePeriod var8 = var7.next();
    boolean var9 = var1.equals((java.lang.Object)var7);
    org.jfree.data.time.SerialDate var11 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var13 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var14 = var11.getEndOfCurrentMonth(var13);
    org.jfree.data.time.SerialDate var16 = var13.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var19 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var21 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var22 = var19.getEndOfCurrentMonth(var21);
    org.jfree.data.time.SerialDate var23 = org.jfree.data.time.SerialDate.addMonths(1, var22);
    org.jfree.data.time.Day var24 = new org.jfree.data.time.Day(var22);
    org.jfree.data.time.SerialDate var25 = var16.getEndOfCurrentMonth(var22);
    int var26 = var1.compare(var22);
    org.jfree.data.time.SpreadsheetDate var28 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var32 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var33 = var30.getEndOfCurrentMonth(var32);
    org.jfree.data.time.Day var34 = new org.jfree.data.time.Day(var32);
    org.jfree.data.time.RegularTimePeriod var35 = var34.next();
    boolean var36 = var28.equals((java.lang.Object)var34);
    org.jfree.data.time.SerialDate var38 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var39 = var38.toString();
    boolean var40 = var28.isOnOrAfter(var38);
    org.jfree.data.time.SerialDate var44 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var46 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var47 = var44.getEndOfCurrentMonth(var46);
    org.jfree.data.time.SerialDate var49 = var46.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var52 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var54 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var55 = var52.getEndOfCurrentMonth(var54);
    org.jfree.data.time.SerialDate var56 = org.jfree.data.time.SerialDate.addMonths(1, var55);
    org.jfree.data.time.Day var57 = new org.jfree.data.time.Day(var55);
    org.jfree.data.time.SerialDate var58 = var49.getEndOfCurrentMonth(var55);
    var49.setDescription("Value");
    org.jfree.data.time.SerialDate var61 = org.jfree.data.time.SerialDate.addYears(13, var49);
    org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addDays((-460), var61);
    boolean var63 = var28.isAfter(var62);
    int var64 = var28.toSerial();
    int var65 = var28.getYYYY();
    org.jfree.data.time.SpreadsheetDate var67 = new org.jfree.data.time.SpreadsheetDate(13);
    int var68 = var67.getYYYY();
    java.util.Date var69 = var67.toDate();
    org.jfree.data.time.SerialDate var71 = org.jfree.data.time.SerialDate.createInstance(2014);
    boolean var72 = var67.isOn(var71);
    org.jfree.data.time.SerialDate var74 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var75 = var74.getDescription();
    boolean var76 = var28.isInRange(var71, var74);
    boolean var77 = var1.isOnOrAfter(var71);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var79 = var1.getPreviousDayOfWeek(520764324);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == (-19));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var39 + "' != '" + "9-January-1900"+ "'", var39.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == false);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     java.lang.Object var4 = var2.clone();
//     java.lang.Class var6 = null;
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var6);
//     java.lang.String var8 = var7.getDescription();
//     org.jfree.data.time.Year var9 = new org.jfree.data.time.Year();
//     long var10 = var9.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var9, 1.0d);
//     java.lang.Number var13 = null;
//     org.jfree.data.time.TimeSeriesDataItem var14 = var7.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var9, var13);
//     java.lang.String var15 = var9.toString();
//     org.jfree.data.time.RegularTimePeriod var16 = var9.next();
//     org.jfree.data.time.TimeSeriesDataItem var17 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var9);
//     java.util.List var18 = var2.getItems();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var19 = var2.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var15 + "' != '" + "2014"+ "'", var15.equals("2014"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.RegularTimePeriod var4 = null;
//     org.jfree.data.time.FixedMillisecond var6 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var7 = null;
//     long var8 = var6.getMiddleMillisecond(var7);
//     java.util.Date var9 = var6.getStart();
//     org.jfree.data.time.Day var10 = new org.jfree.data.time.Day(var9);
//     org.jfree.data.time.Month var11 = new org.jfree.data.time.Month(var9);
//     org.jfree.data.time.RegularTimePeriod var12 = var11.next();
//     java.lang.Class var14 = null;
//     org.jfree.data.time.TimeSeries var15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var14);
//     java.lang.String var16 = var15.getDescription();
//     org.jfree.data.time.Year var17 = new org.jfree.data.time.Year();
//     long var18 = var17.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var17, 1.0d);
//     java.lang.Number var21 = null;
//     org.jfree.data.time.TimeSeriesDataItem var22 = var15.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var17, var21);
//     org.jfree.data.general.SeriesChangeListener var23 = null;
//     var15.removeChangeListener(var23);
//     org.jfree.data.time.Year var25 = new org.jfree.data.time.Year();
//     long var26 = var25.getMiddleMillisecond();
//     long var27 = var25.getFirstMillisecond();
//     var15.update((org.jfree.data.time.RegularTimePeriod)var25, (java.lang.Number)1L);
//     java.util.Date var30 = var25.getStart();
//     org.jfree.data.time.SerialDate var31 = org.jfree.data.time.SerialDate.createInstance(var30);
//     org.jfree.data.time.Month var32 = new org.jfree.data.time.Month(var30);
//     long var33 = var32.getSerialIndex();
//     int var34 = var32.getMonth();
//     int var35 = var32.getYearValue();
//     org.jfree.data.time.RegularTimePeriod var36 = var32.previous();
//     int var37 = var32.getMonth();
//     boolean var38 = var11.equals((java.lang.Object)var32);
//     long var39 = var32.getSerialIndex();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.TimeSeries var40 = var2.createCopy(var4, (org.jfree.data.time.RegularTimePeriod)var32);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 24169L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var34 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var37 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var39 == 24169L);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getLastMillisecond(var2);
//     java.lang.Class var5 = null;
//     org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var5);
//     java.lang.String var7 = var6.getDescription();
//     var6.removeAgedItems(false);
//     var6.fireSeriesChanged();
//     int var11 = var1.compareTo((java.lang.Object)var6);
//     var6.clear();
//     java.lang.Class var13 = var6.getTimePeriodClass();
//     var6.clear();
//     java.lang.Class var16 = null;
//     org.jfree.data.time.TimeSeries var17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var16);
//     java.lang.String var18 = var17.getDescription();
//     org.jfree.data.time.Year var19 = new org.jfree.data.time.Year();
//     long var20 = var19.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var19, 1.0d);
//     java.lang.Number var23 = null;
//     org.jfree.data.time.TimeSeriesDataItem var24 = var17.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var19, var23);
//     org.jfree.data.general.SeriesChangeListener var25 = null;
//     var17.removeChangeListener(var25);
//     org.jfree.data.time.Year var27 = new org.jfree.data.time.Year();
//     long var28 = var27.getMiddleMillisecond();
//     long var29 = var27.getFirstMillisecond();
//     var17.update((org.jfree.data.time.RegularTimePeriod)var27, (java.lang.Number)1L);
//     java.util.Date var32 = var27.getStart();
//     org.jfree.data.time.SerialDate var33 = org.jfree.data.time.SerialDate.createInstance(var32);
//     org.jfree.data.time.Month var34 = new org.jfree.data.time.Month(var32);
//     long var35 = var34.getSerialIndex();
//     int var36 = var34.getMonth();
//     org.jfree.data.time.RegularTimePeriod var37 = var34.next();
//     org.jfree.data.time.TimeSeriesDataItem var39 = var6.addOrUpdate(var37, 10.0d);
//     org.jfree.data.time.Year var41 = org.jfree.data.time.Year.parseYear("2014");
//     org.jfree.data.time.TimeSeriesDataItem var43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var41, (java.lang.Number)100L);
//     var6.add(var43);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.jfree.data.time.SerialDate var2 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var5 = var2.getEndOfCurrentMonth(var4);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.addMonths(1, var5);
    java.lang.Class var7 = null;
    org.jfree.data.time.TimeSeries var8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var6, var7);
    var8.setDescription("Nearest");
    org.jfree.data.time.TimeSeries var13 = var8.createCopy(10, 2014);
    var8.removeAgedItems(false);
    java.beans.PropertyChangeListener var16 = null;
    var8.addPropertyChangeListener(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.util.List var3 = var2.getItems();
//     var2.setMaximumItemAge(1388563200000L);
//     java.lang.Class var6 = var2.getTimePeriodClass();
//     java.lang.Class var7 = var2.getTimePeriodClass();
//     java.lang.Class var8 = var2.getTimePeriodClass();
//     java.lang.Class var10 = null;
//     org.jfree.data.time.TimeSeries var11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var10);
//     java.lang.String var12 = var11.getDescription();
//     org.jfree.data.time.Year var13 = new org.jfree.data.time.Year();
//     long var14 = var13.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var13, 1.0d);
//     java.lang.Number var17 = null;
//     org.jfree.data.time.TimeSeriesDataItem var18 = var11.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var13, var17);
//     org.jfree.data.general.SeriesChangeListener var19 = null;
//     var11.removeChangeListener(var19);
//     org.jfree.data.time.FixedMillisecond var22 = new org.jfree.data.time.FixedMillisecond(0L);
//     var11.delete((org.jfree.data.time.RegularTimePeriod)var22);
//     java.util.Calendar var24 = null;
//     var22.peg(var24);
//     org.jfree.data.time.TimeSeriesDataItem var26 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var22);
//     org.jfree.data.time.FixedMillisecond var28 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var29 = null;
//     long var30 = var28.getLastMillisecond(var29);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var32);
//     java.lang.String var34 = var33.getDescription();
//     var33.removeAgedItems(false);
//     var33.fireSeriesChanged();
//     int var38 = var28.compareTo((java.lang.Object)var33);
//     var2.delete((org.jfree.data.time.RegularTimePeriod)var28);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.RegularTimePeriod var40 = var2.getNextTimePeriod();
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var30 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 1);
// 
//   }

  public void test482() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }


    org.jfree.data.time.SpreadsheetDate var2 = new org.jfree.data.time.SpreadsheetDate(13);
    org.jfree.data.time.SerialDate var4 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var6 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var7 = var4.getEndOfCurrentMonth(var6);
    org.jfree.data.time.Day var8 = new org.jfree.data.time.Day(var6);
    org.jfree.data.time.RegularTimePeriod var9 = var8.next();
    boolean var10 = var2.equals((java.lang.Object)var8);
    org.jfree.data.time.SerialDate var12 = org.jfree.data.time.SerialDate.createInstance(10);
    java.lang.String var13 = var12.toString();
    boolean var14 = var2.isOnOrAfter(var12);
    org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var20 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var21 = var18.getEndOfCurrentMonth(var20);
    org.jfree.data.time.SerialDate var23 = var20.getFollowingDayOfWeek(1);
    org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var28 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var29 = var26.getEndOfCurrentMonth(var28);
    org.jfree.data.time.SerialDate var30 = org.jfree.data.time.SerialDate.addMonths(1, var29);
    org.jfree.data.time.Day var31 = new org.jfree.data.time.Day(var29);
    org.jfree.data.time.SerialDate var32 = var23.getEndOfCurrentMonth(var29);
    var23.setDescription("Value");
    org.jfree.data.time.SerialDate var35 = org.jfree.data.time.SerialDate.addYears(13, var23);
    org.jfree.data.time.SerialDate var36 = org.jfree.data.time.SerialDate.addDays((-460), var35);
    boolean var37 = var2.isAfter(var36);
    int var38 = var2.toSerial();
    int var39 = var2.getYYYY();
    org.jfree.data.time.SpreadsheetDate var41 = new org.jfree.data.time.SpreadsheetDate(13);
    int var42 = var41.getYYYY();
    java.util.Date var43 = var41.toDate();
    org.jfree.data.time.SerialDate var45 = org.jfree.data.time.SerialDate.createInstance(2014);
    boolean var46 = var41.isOn(var45);
    org.jfree.data.time.SerialDate var48 = org.jfree.data.time.SerialDate.createInstance(100);
    java.lang.String var49 = var48.getDescription();
    boolean var50 = var2.isInRange(var45, var48);
    org.jfree.data.time.SerialDate var53 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var55 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var56 = var53.getEndOfCurrentMonth(var55);
    org.jfree.data.time.SerialDate var57 = org.jfree.data.time.SerialDate.addMonths(1, var56);
    java.lang.Class var60 = null;
    org.jfree.data.time.TimeSeries var61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var57, "ThreadContext", "hi!", var60);
    org.jfree.data.time.SerialDate var64 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var66 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var67 = var64.getEndOfCurrentMonth(var66);
    org.jfree.data.time.SerialDate var68 = org.jfree.data.time.SerialDate.addMonths(1, var67);
    java.lang.Class var71 = null;
    org.jfree.data.time.TimeSeries var72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var68, "ThreadContext", "hi!", var71);
    org.jfree.data.time.SerialDate var75 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var77 = org.jfree.data.time.SerialDate.createInstance(10);
    org.jfree.data.time.SerialDate var78 = var75.getEndOfCurrentMonth(var77);
    org.jfree.data.time.SerialDate var79 = org.jfree.data.time.SerialDate.addMonths(1, var78);
    org.jfree.data.time.SerialDate var80 = var68.getEndOfCurrentMonth(var78);
    boolean var82 = var2.isInRange(var57, var68, 1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.SerialDate var83 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((-460), var57);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + "9-January-1900"+ "'", var13.equals("9-January-1900"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1900);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == false);

  }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test484() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Year var1 = new org.jfree.data.time.Year(6);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var2 = null;
//     long var3 = var1.getMiddleMillisecond(var2);
//     java.util.Date var4 = var1.getStart();
//     org.jfree.data.time.Day var5 = new org.jfree.data.time.Day(var4);
//     long var6 = var5.getFirstMillisecond();
//     org.jfree.data.time.TimeSeries var7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
//     int var8 = var5.getYear();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-57600000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1969);
// 
//   }

  public void test486() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.Month var1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.general.SeriesChangeEvent[source=9223372036854775807]");
      fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException");
    } catch (org.jfree.data.time.TimePeriodFormatException e) {
      // Expected exception.
    }

  }

  public void test487() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }


    org.jfree.data.time.Day var1 = org.jfree.data.time.Day.parseDay("Sun Dec 21 00:23:27 PST 2014");
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var1);

  }

  public void test488() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }


    boolean var1 = org.jfree.data.time.SerialDate.isLeapYear(6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == false);

  }

  public void test489() {}
//   public void test489() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.Month var19 = new org.jfree.data.time.Month(var17);
//     long var20 = var19.getSerialIndex();
//     int var21 = var19.getMonth();
//     java.util.Calendar var22 = null;
//     long var23 = var19.getFirstMillisecond(var22);
// 
//   }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    java.lang.Class var3 = null;
    org.jfree.data.time.TimeSeries var5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(-1L));
    java.lang.Class var6 = var5.getTimePeriodClass();
    java.lang.Object var7 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", var3, var6);
    java.io.InputStream var8 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Jan", var6);
    java.lang.ClassLoader var9 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var6);
    java.lang.ClassLoader var10 = org.jfree.chart.util.ObjectUtilities.getClassLoader(var6);
    java.io.InputStream var11 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(1900);
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getLastMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.Number var24 = null;
//     org.jfree.data.time.TimeSeriesDataItem var25 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, var24);
//     int var26 = var20.getYear();
//     java.util.Date var27 = var20.getStart();
//     long var28 = var20.getSerialIndex();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     java.lang.Class var32 = null;
//     org.jfree.data.time.TimeSeries var33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var32);
//     java.util.List var34 = var33.getItems();
//     var33.setMaximumItemAge(1388563200000L);
//     java.lang.String var37 = var33.getRangeDescription();
//     var33.clear();
//     java.lang.String var39 = var33.getDomainDescription();
//     org.jfree.data.time.SerialDate var41 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var43 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var44 = var41.getEndOfCurrentMonth(var43);
//     org.jfree.data.time.Day var45 = new org.jfree.data.time.Day(var43);
//     org.jfree.data.time.RegularTimePeriod var46 = var45.next();
//     java.lang.String var47 = var45.toString();
//     long var48 = var45.getFirstMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var50 = var33.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var45, (java.lang.Number)28);
//     java.util.Collection var51 = var2.getTimePeriodsUniqueToOtherSeries(var33);
//     int var52 = var33.getItemCount();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var21 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var26 == 2014);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == 2014L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var37 + "' != '" + "Value"+ "'", var37.equals("Value"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var39 + "' != '" + "Time"+ "'", var39.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var47 + "' != '" + "9-January-1900"+ "'", var47.equals("9-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == (-2208268800000L));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var50);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var52 == 1);
// 
//   }

  public void test493() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }


    java.lang.Class var1 = null;
    java.lang.Object var2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("January 2014", var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var2);

  }

  public void test494() {}
//   public void test494() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     java.lang.String var10 = var2.getDomainDescription();
//     java.lang.String var11 = var2.getDescription();
//     java.lang.String var12 = var2.getRangeDescription();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "Time"+ "'", var10.equals("Time"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "Value"+ "'", var12.equals("Value"));
// 
//   }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getLastMillisecond(var2);
    long var4 = var1.getLastMillisecond();
    java.util.Date var5 = var1.getStart();
    org.jfree.data.time.TimeSeries var6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)var5);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var8 = var6.getDataItem(1900);
      fail("Expected exception of type java.lang.IndexOutOfBoundsException");
    } catch (java.lang.IndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.jfree.data.time.SpreadsheetDate var1 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var3 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var5 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var6 = var3.getEndOfCurrentMonth(var5);
//     org.jfree.data.time.Day var7 = new org.jfree.data.time.Day(var5);
//     org.jfree.data.time.RegularTimePeriod var8 = var7.next();
//     boolean var9 = var1.equals((java.lang.Object)var7);
//     org.jfree.data.time.SpreadsheetDate var11 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var12 = var11.getYYYY();
//     boolean var13 = var1.isAfter((org.jfree.data.time.SerialDate)var11);
//     int var14 = var1.getYYYY();
//     org.jfree.data.time.SpreadsheetDate var16 = new org.jfree.data.time.SpreadsheetDate(13);
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(2014);
//     int var19 = var16.compare(var18);
//     org.jfree.data.time.SerialDate var22 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var24 = org.jfree.data.time.SerialDate.createInstance(10);
//     org.jfree.data.time.SerialDate var25 = var22.getEndOfCurrentMonth(var24);
//     org.jfree.data.time.SerialDate var26 = org.jfree.data.time.SerialDate.addMonths(1, var25);
//     boolean var28 = var1.isInRange((org.jfree.data.time.SerialDate)var16, var26, 31);
//     org.jfree.data.time.SpreadsheetDate var31 = new org.jfree.data.time.SpreadsheetDate(13);
//     int var32 = var31.getYYYY();
//     java.lang.String var33 = var31.toString();
//     java.lang.Class var35 = null;
//     org.jfree.data.time.TimeSeries var36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var35);
//     java.util.List var37 = var36.getItems();
//     var36.setMaximumItemAge(1388563200000L);
//     java.lang.Class var40 = var36.getTimePeriodClass();
//     java.lang.Class var41 = var36.getTimePeriodClass();
//     java.lang.Class var42 = var36.getTimePeriodClass();
//     java.lang.Class var44 = null;
//     org.jfree.data.time.TimeSeries var45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var44);
//     java.lang.String var46 = var45.getDescription();
//     org.jfree.data.time.Year var47 = new org.jfree.data.time.Year();
//     long var48 = var47.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var47, 1.0d);
//     java.lang.Number var51 = null;
//     org.jfree.data.time.TimeSeriesDataItem var52 = var45.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var47, var51);
//     org.jfree.data.general.SeriesChangeListener var53 = null;
//     var45.removeChangeListener(var53);
//     org.jfree.data.time.FixedMillisecond var56 = new org.jfree.data.time.FixedMillisecond(0L);
//     var45.delete((org.jfree.data.time.RegularTimePeriod)var56);
//     java.util.Calendar var58 = null;
//     var56.peg(var58);
//     org.jfree.data.time.TimeSeriesDataItem var60 = var36.getDataItem((org.jfree.data.time.RegularTimePeriod)var56);
//     boolean var61 = var31.equals((java.lang.Object)var56);
//     org.jfree.data.time.SerialDate var62 = org.jfree.data.time.SerialDate.addYears(0, (org.jfree.data.time.SerialDate)var31);
//     int var63 = var16.compare(var62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.SerialDate var65 = var62.getFollowingDayOfWeek(520764324);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var6);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == (-2001));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var28 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == 1900);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var33 + "' != '" + "12-January-1900"+ "'", var33.equals("12-January-1900"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var40);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var48 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var61 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 0);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.jfree.data.time.FixedMillisecond var1 = new org.jfree.data.time.FixedMillisecond(0L);
    java.util.Calendar var2 = null;
    long var3 = var1.getMiddleMillisecond(var2);
    org.jfree.data.time.RegularTimePeriod var4 = var1.next();
    java.util.Date var5 = var1.getTime();
    org.jfree.data.time.RegularTimePeriod var6 = var1.previous();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0L);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.Year var4 = new org.jfree.data.time.Year();
//     long var5 = var4.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var4, 1.0d);
//     java.lang.Number var8 = null;
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var4, var8);
//     org.jfree.data.general.SeriesChangeListener var10 = null;
//     var2.removeChangeListener(var10);
//     org.jfree.data.time.Year var12 = new org.jfree.data.time.Year();
//     long var13 = var12.getMiddleMillisecond();
//     long var14 = var12.getFirstMillisecond();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var12, (java.lang.Number)1L);
//     java.util.Date var17 = var12.getStart();
//     org.jfree.data.time.SerialDate var18 = org.jfree.data.time.SerialDate.createInstance(var17);
//     org.jfree.data.time.FixedMillisecond var19 = new org.jfree.data.time.FixedMillisecond(var17);
//     java.util.TimeZone var20 = null;
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.jfree.data.time.Day var21 = new org.jfree.data.time.Day(var17, var20);
//       fail("Expected exception of type java.lang.IllegalArgumentException");
//     } catch (java.lang.IllegalArgumentException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 1404331199999L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 1388563200000L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
// 
//   }

  public void test499() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }


    org.jfree.data.time.RegularTimePeriod var0 = null;
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.jfree.data.time.TimeSeriesDataItem var2 = new org.jfree.data.time.TimeSeriesDataItem(var0, (java.lang.Number)(-19));
      fail("Expected exception of type java.lang.IllegalArgumentException");
    } catch (java.lang.IllegalArgumentException e) {
      // Expected exception.
    }

  }

  public void test500() {}
//   public void test500() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }
// 
// 
//     java.lang.Class var1 = null;
//     org.jfree.data.time.TimeSeries var2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var1);
//     java.lang.String var3 = var2.getDescription();
//     org.jfree.data.time.FixedMillisecond var5 = new org.jfree.data.time.FixedMillisecond(0L);
//     long var6 = var5.getLastMillisecond();
//     java.util.Calendar var7 = null;
//     long var8 = var5.getMiddleMillisecond(var7);
//     org.jfree.data.time.TimeSeriesDataItem var9 = var2.getDataItem((org.jfree.data.time.RegularTimePeriod)var5);
//     org.jfree.data.time.FixedMillisecond var11 = new org.jfree.data.time.FixedMillisecond(0L);
//     java.util.Calendar var12 = null;
//     long var13 = var11.getLastMillisecond(var12);
//     org.jfree.data.time.TimeSeriesDataItem var15 = var2.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var11, (-1.0d));
//     java.lang.Class var17 = null;
//     org.jfree.data.time.TimeSeries var18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable)(byte)1, var17);
//     java.lang.String var19 = var18.getDescription();
//     org.jfree.data.time.Year var20 = new org.jfree.data.time.Year();
//     long var21 = var20.getMiddleMillisecond();
//     org.jfree.data.time.TimeSeriesDataItem var23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod)var20, 1.0d);
//     java.lang.Number var24 = null;
//     org.jfree.data.time.TimeSeriesDataItem var25 = var18.addOrUpdate((org.jfree.data.time.RegularTimePeriod)var20, var24);
//     int var26 = var20.getYear();
//     java.util.Date var27 = var20.getStart();
//     long var28 = var20.getSerialIndex();
//     var2.update((org.jfree.data.time.RegularTimePeriod)var20, (java.lang.Number)10.0d);
//     java.util.Calendar var31 = null;
//     long var32 = var20.getFirstMillisecond(var31);
// 
//   }

}
